#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = 'v0.0.0-SNAPSHOT'

CHECKERS = {
  'appendAssign' => %w[diagnostic],
  'appendCombine' => %w[performance],
  'argOrder' => %w[diagnostic],
  'assignOp' => %w[style],
  'badCall' => %w[diagnostic],
  'badCond' => %w[diagnostic],
  'badLock' => %w[diagnostic experimental],
  'badRegexp' => %w[diagnostic experimental],
  'badSorting' => %w[diagnostic experimental],
  'badSyncOnceFunc' => %w[diagnostic experimental],
  'boolExprSimplify' => %w[style experimental],
  'builtinShadow' => %w[style opinionated],
  'builtinShadowDecl' => %w[diagnostic experimental],
  'captLocal' => %w[style],
  'caseOrder' => %w[diagnostic],
  'codegenComment' => %w[diagnostic],
  'commentFormatting' => %w[style],
  'commentedOutCode' => %w[diagnostic experimental],
  'commentedOutImport' => %w[style experimental],
  'defaultCaseOrder' => %w[style],
  'deferInLoop' => %w[diagnostic experimental],
  'deferUnlambda' => %w[style experimental],
  'deprecatedComment' => %w[diagnostic],
  'docStub' => %w[style experimental],
  'dupArg' => %w[diagnostic],
  'dupBranchBody' => %w[diagnostic],
  'dupCase' => %w[diagnostic],
  'dupImport' => %w[style experimental],
  'dupOption' => %w[diagnostic experimental],
  'dupSubExpr' => %w[diagnostic],
  'dynamicFmtString' => %w[diagnostic experimental],
  'elseif' => %w[style],
  'emptyDecl' => %w[diagnostic experimental],
  'emptyFallthrough' => %w[style experimental],
  'emptyStringTest' => %w[style experimental],
  'equalFold' => %w[performance experimental],
  'evalOrder' => %w[diagnostic experimental],
  'exitAfterDefer' => %w[diagnostic],
  'exposedSyncMutex' => %w[style experimental],
  'externalErrorReassign' => %w[diagnostic experimental],
  'filepathJoin' => %w[diagnostic experimental],
  'flagDeref' => %w[diagnostic],
  'flagName' => %w[diagnostic],
  'hexLiteral' => %w[style experimental],
  'httpNoBody' => %w[style experimental],
  'hugeParam' => %w[performance],
  'ifElseChain' => %w[style],
  'importShadow' => %w[style opinionated],
  'indexAlloc' => %w[performance],
  'initClause' => %w[style opinionated experimental],
  'mapKey' => %w[diagnostic],
  'methodExprCall' => %w[style experimental],
  'nestingReduce' => %w[style opinionated experimental],
  'newDeref' => %w[style],
  'nilValReturn' => %w[diagnostic experimental],
  'octalLiteral' => %w[style experimental opinionated],
  'offBy1' => %w[diagnostic],
  'paramTypeCombine' => %w[style opinionated],
  'preferDecodeRune' => %w[performance experimental],
  'preferFilepathJoin' => %w[style experimental],
  'preferFprint' => %w[performance experimental],
  'preferStringWriter' => %w[performance experimental],
  'preferWriteByte' => %w[performance experimental opinionated],
  'ptrToRefParam' => %w[style opinionated experimental],
  'rangeAppendAll' => %w[diagnostic experimental],
  'rangeExprCopy' => %w[performance],
  'rangeValCopy' => %w[performance],
  'redundantSprint' => %w[style experimental],
  'regexpMust' => %w[style],
  'regexpPattern' => %w[diagnostic experimental],
  'regexpSimplify' => %w[style experimental opinionated],
  'returnAfterHttpError' => %w[diagnostic experimental],
  'ruleguard' => %w[style experimental],
  'singleCaseSwitch' => %w[style],
  'sliceClear' => %w[performance experimental],
  'sloppyLen' => %w[diagnostic],
  'sloppyReassign' => %w[diagnostic experimental],
  'sloppyTypeAssert' => %w[diagnostic],
  'sortSlice' => %w[diagnostic experimental],
  'sprintfQuotedString' => %w[diagnostic experimental],
  'sqlQuery' => %w[diagnostic experimental],
  'stringConcatSimplify' => %w[style experimental],
  'stringXbytes' => %w[performance],
  'stringsCompare' => %w[style experimental],
  'switchTrue' => %w[style],
  'syncMapLoadAndDelete' => %w[diagnostic experimental],
  'timeExprSimplify' => %w[style experimental],
  'todoCommentWithoutDetail' => %w[style opinionated experimental],
  'tooManyResultsChecker' => %w[style opinionated experimental],
  'truncateCmp' => %w[diagnostic experimental],
  'typeAssertChain' => %w[style experimental],
  'typeDefFirst' => %w[style experimental],
  'typeSwitchVar' => %w[style],
  'typeUnparen' => %w[style opinionated],
  'uncheckedInlineErr' => %w[diagnostic experimental],
  'underef' => %w[style],
  'unlabelStmt' => %w[style experimental],
  'unlambda' => %w[style],
  'unnamedResult' => %w[style opinionated experimental],
  'unnecessaryBlock' => %w[style opinionated experimental],
  'unnecessaryDefer' => %w[diagnostic experimental],
  'unslice' => %w[style],
  'valSwap' => %w[style],
  'weakCond' => %w[diagnostic experimental],
  'whyNoLint' => %w[style experimental],
  'wrapperFunc' => %w[style],
  'yodaStyleExpr' => %w[style experimental],
  'zeroByteRepeat' => %w[performance]
}.freeze

DEFAULT_CHECKS = %w[
  appendAssign argOrder assignOp badCall badCond captLocal caseOrder codegenComment
  commentFormatting defaultCaseOrder deprecatedComment dupArg dupBranchBody dupCase
  dupSubExpr elseif exitAfterDefer flagDeref flagName ifElseChain mapKey newDeref
  offBy1 regexpMust singleCaseSwitch sloppyLen sloppyTypeAssert switchTrue
  typeSwitchVar underef unlambda unslice valSwap wrapperFunc
].freeze

DOCS = {
  'appendAssign' => ['Detects suspicious append result assignments.', 'p.positives = append(p.negatives, x)', 'p.positives = append(p.positives, x)'],
  'argOrder' => ['Detects suspicious arguments order.', 'strings.HasPrefix("#", userpass)', 'strings.HasPrefix(userpass, "#")'],
  'assignOp' => ['Detects assignments that can be simplified by using assignment operators.', 'x = x * 2', 'x *= 2'],
  'badCond' => ['Detects suspicious condition expressions.', 'for i := 0; i > n; i++ {', 'for i := 0; i < n; i++ {'],
  'elseif' => ['Detects else with nested if statement that can be replaced with else-if.', "if cond1 {\n} else {\n\tif x := cond2; x {\n\t}\n}", "if cond1 {\n} else if x := cond2; x {\n}"],
  'singleCaseSwitch' => ['Detects switch statements that could be better written as if statement.', "switch x := x.(type) {\ncase int:\n\tbody()\n}", "if x, ok := x.(int); ok {\n\tbody()\n}"],
  'unslice' => ['Detects slice expressions that can be simplified to sliced expression itself.', 'copy(b[:], values...)', 'copy(b, values...)'],
  'valSwap' => ['Detects value swapping code that are not using parallel assignment.', '*tmp = *x; *x = *y; *y = *tmp', '*x, *y = *y, *x'],
  'sloppyLen' => ["Detects usage of `len` when result is obvious or doesn't make sense.", 'len(arr) <= 0', 'len(arr) == 0'],
  'regexpMust' => ['Detects `regexp.Compile*` that can be replaced with `regexp.MustCompile*`.', 're, _ := regexp.Compile("const pattern")', 're := regexp.MustCompile("const pattern")'],
  'wrapperFunc' => ['Detects function calls that can be replaced with convenience wrappers.', 'wg.Add(-1)', 'wg.Done()'],
  'newDeref' => ['Detects immediate dereferencing of `new` expressions.', 'x := *new(bool)', 'x := false'],
  'underef' => ['Detects dereference expressions that can be omitted.', '(*k).field = 5', 'k.field = 5'],
  'switchTrue' => ['Detects switch-over-bool statements that use explicit `true` tag value.', 'switch true {...}', 'switch {...}'],
  'typeSwitchVar' => ['Detects type switches that can benefit from type guard clause with variable.', "switch v.(type) {\ncase int:\n\treturn v.(int)\n}", "switch v := v.(type) {\ncase int:\n\treturn v\n}"],
  'captLocal' => ['Detects capitalized names for local variables.', 'func f(IN int, OUT *int) (ERR error) {}', 'func f(in int, out *int) (err error) {}']
}.freeze

def usage
  puts 'Usage:'
  puts
  puts '    go-critic <command> [arguments...]'
  puts
  puts 'The commands are:'
  puts
  puts '    check             run linter over specified targets'
  puts '    doc               get installed checkers documentation'
  puts '    help              shows help message'
  puts '    version           shows version of the application'
  puts
  puts "Version: #{VERSION}"
  puts
end

def check_help
  puts 'Usage of go-critic:'
  puts "  -@captLocal.paramsOnly\n    \twhether to restrict checker to params only (default true)"
  puts "  -@commentedOutCode.minLength int\n    \tmin length of the comment that triggers a warning (default 15)"
  puts "  -@elseif.skipBalanced\n    \twhether to skip balanced if-else pairs (default true)"
  puts "  -@hugeParam.sizeThreshold int\n    \tsize in bytes that makes the warning trigger (default 80)"
  puts "  -@ifElseChain.minThreshold int\n    \tmin number of if-else blocks that makes the warning trigger (default 2)"
  puts "  -@rangeExprCopy.sizeThreshold int\n    \tsize in bytes that makes the warning trigger (default 512)"
  puts "  -@rangeValCopy.sizeThreshold int\n    \tsize in bytes that makes the warning trigger (default 128)"
  puts "  -checkGenerated\n    \twhether to check generated files"
  puts "  -checkTests\n    \twhether to check test files (default true)"
  puts "  -concurrency int\n    \thow many concurrent checkers to run (default is runtime.GOMAXPROCS(0)) (default 14)"
  puts "  -disable string\n    \tcomma-separated list of checkers to be disabled. Can include #tags"
  puts "  -enable string\n    \tcomma-separated list of enabled checkers. Can include #tags (default \"#{DEFAULT_CHECKS.join(',')}\")"
  puts "  -enableAll\n    \tidentical to -enable with all checkers listed. If true, -enable is ignored"
  puts "  -exitCode int\n    \texit code to be used when lint issues are found (default 1)"
  puts "  -go string\n    \tselect the Go version to target. Leave as string for the latest"
  puts "  -shorterErrLocation\n    \twhether to replace error location prefix with $GOROOT and $GOPATH (default true)"
  puts "  -v\twhether to print output useful during linter debugging"
end

def expand_checks(items)
  out = []
  items.each do |item|
    if item.start_with?('#')
      tag = item[1..]
      CHECKERS.each { |name, tags| out << name if tags.include?(tag) }
    elsif CHECKERS.key?(item)
      out << item
    end
  end
  out.uniq
end

def doc(args)
  if args.first == '-help' || args.first == '--help'
    puts 'Usage of go-critic:'
    puts 'flag: help requested'
    exit 0
  end
  if args.empty?
    CHECKERS.each { |name, tags| puts "#{name} [#{tags.join(' ')}]" }
    exit 0
  end
  name = args.first
  unless CHECKERS.key?(name)
    warn "checker with name \"#{name}\" not found"
    exit 1
  end
  body = DOCS[name] || ["#{name} checker.", 'bad()', 'good()']
  puts "#{name} checker documentation"
  puts 'URL: https://github.com/go-critic/go-critic/checkers'
  puts "Tags: [#{CHECKERS[name].join(' ')}]"
  puts
  puts body[0]
  puts
  puts 'Non-compliant code:'
  puts body[1]
  puts
  puts 'Compliant code:'
  puts body[2]
  if name == 'elseif'
    puts
    puts 'Checker parameters:'
    puts "  -@elseif.skipBalanced bool\n    \twhether to skip balanced if-else pairs (default true)"
  elsif name == 'captLocal'
    puts
    puts 'Checker parameters:'
    puts "  -@captLocal.paramsOnly bool\n    \twhether to restrict checker to params only (default true)"
  end
end

Diagnostic = Struct.new(:file, :line, :col, :check, :message) do
  def to_s
    "#{file}:#{line}:#{col}: #{check}: #{message}"
  end
end

def add(diags, file, lines, idx, check, msg, needle = nil)
  line = lines[idx] || ''
  col = needle ? [line.index(needle).to_i + 1, 1].max : (line.index(/\S/) || 0) + 1
  diags << Diagnostic.new(file, idx + 1, col, check, msg)
end

def scan_file(file, enabled)
  text = File.read(file)
  return [] if text.include?('Code generated') && !ARGV.include?('-checkGenerated')

  lines = text.lines
  diags = []
  lines.each_with_index do |line, i|
    code = line.sub(%r{//.*}, '')
    if enabled.include?('appendAssign') && code =~ /([\w.\[\]]+)\s*=\s*append\(\s*([\w.\[\]]+)/
      add(diags, file, lines, i, 'appendAssign', 'append result not assigned to the same slice', 'append') unless Regexp.last_match(1) == Regexp.last_match(2)
    end
    if enabled.include?('assignOp') && code =~ /\b(\w+)\s*=\s*\1\s*([+\-*\/%&|^]|<<|>>)\s*[^=]/
      add(diags, file, lines, i, 'assignOp', 'replace assignment with operator assignment', '=')
    end
    if enabled.include?('argOrder') && code =~ /strings\.(HasPrefix|HasSuffix|Contains)\(\s*"[^"]*"\s*,\s*[A-Za-z_]/
      add(diags, file, lines, i, 'argOrder', 'suspicious arguments order', 'strings.')
    end
    if enabled.include?('badCond') && code =~ /for\s+(\w+)\s*:=\s*0\s*;\s*\1\s*>\s*[^;]+;\s*\1\+\+/
      add(diags, file, lines, i, 'badCond', 'suspicious loop condition', 'for')
    end
    if enabled.include?('sloppyLen') && code =~ /len\([^)]+\)\s*(<=\s*0|<\s*1|>\s*0|>=\s*1)/
      add(diags, file, lines, i, 'sloppyLen', 'replace len comparison with clearer form', 'len')
    end
    if enabled.include?('regexpMust') && code =~ /,\s*_\s*:=\s*regexp\.Compile/
      add(diags, file, lines, i, 'regexpMust', 'use regexp.MustCompile for constant patterns', 'regexp.Compile')
    end
    if enabled.include?('switchTrue') && code =~ /\bswitch\s+true\b/
      add(diags, file, lines, i, 'switchTrue', 'omit true in switch statement', 'switch')
    end
    if enabled.include?('unslice') && code =~ /\b(\w+)\[:\]/
      add(diags, file, lines, i, 'unslice', 'could simplify sliced expression', '[:]')
    end
    if enabled.include?('newDeref') && code =~ /\*new\([^)]+\)/
      add(diags, file, lines, i, 'newDeref', 'replace new()+deref with zero value', '*new')
    end
    if enabled.include?('underef') && code =~ /\(\*\w+\)\./
      add(diags, file, lines, i, 'underef', 'could omit dereference', '(*')
    end
    if enabled.include?('wrapperFunc') && code =~ /\.Add\(\s*-1\s*\)/
      add(diags, file, lines, i, 'wrapperFunc', 'use Done instead of Add(-1)', '.Add')
    end
    if enabled.include?('commentFormatting') && line =~ %r{^\s*//[A-Za-z0-9]}
      add(diags, file, lines, i, 'commentFormatting', 'put a space between `//` and comment text', '//')
    end
    if enabled.include?('captLocal') && code =~ /\bfunc\s+\w+\(([^)]*)\)/
      Regexp.last_match(1).scan(/\b([A-Z][A-Z0-9_]*)\b/) do |m|
        add(diags, file, lines, i, 'captLocal', "don't use ALL_CAPS in Go names; use CamelCase", m[0])
      end
    end
  end

  if enabled.include?('elseif') && text =~ /}\s*else\s*{\s*if\b/m
    idx = text[0...Regexp.last_match.begin(0)].count("\n")
    add(diags, file, lines, idx, 'elseif', 'can replace else {if cond {}} with else if cond {}', 'else')
  end

  if enabled.include?('singleCaseSwitch')
    text.scan(/switch\b[\s\S]*?{\s*case\b[\s\S]*?}/m) do |block|
      next unless block.scan(/^\s*case\b/).size == 1 && block.scan(/^\s*default\b/).empty?
      idx = text[0...Regexp.last_match.begin(0)].count("\n")
      add(diags, file, lines, idx, 'singleCaseSwitch', 'should rewrite switch statement to if statement', 'switch')
    end
  end

  if enabled.include?('typeSwitchVar')
    text.scan(/switch\s+(\w+)\.\(type\)\s*{[\s\S]*?\1\.\(/m) do
      idx = text[0...Regexp.last_match.begin(0)].count("\n")
      add(diags, file, lines, idx, 'typeSwitchVar', 'assign type switch expression to variable', 'switch')
    end
  end

  diags
rescue Errno::ENOENT
  warn "open #{file}: no such file or directory"
  []
end

def collect_files(targets, check_tests)
  files = []
  targets.each do |t|
    if t.end_with?('/...')
      root = t.sub(%r{/\.{3}\z}, '')
      root = '.' if root.empty?
      files.concat(Dir.glob(File.join(root, '**', '*.go')))
    elsif File.directory?(t)
      files.concat(Dir.glob(File.join(t, '*.go')))
    elsif t.end_with?('.go')
      files << t
    end
  end
  files.uniq.select { |f| check_tests || !f.end_with?('_test.go') }.sort
end

def parse_check(args)
  enabled = DEFAULT_CHECKS.dup
  disabled = []
  exit_code = 1
  targets = []
  check_tests = true
  i = 0
  while i < args.size
    a = args[i]
    case a
    when '-help', '--help'
      check_help
      puts 'parse args: flag: help requested' if a == '-help'
      exit(a == '-help' ? 1 : 0)
    when '-enableAll'
      enabled = CHECKERS.keys
    when '-v', '-checkGenerated', '-shorterErrLocation'
      # Accepted for compatibility.
    when '-checkTests=false'
      check_tests = false
    when /\A-enable=(.*)\z/
      enabled = expand_checks(Regexp.last_match(1).split(','))
    when '-enable'
      i += 1
      enabled = expand_checks((args[i] || '').split(','))
    when /\A-disable=(.*)\z/
      disabled.concat(expand_checks(Regexp.last_match(1).split(',')))
    when '-disable'
      i += 1
      disabled.concat(expand_checks((args[i] || '').split(',')))
    when /\A-exitCode=(\d+)\z/
      exit_code = Regexp.last_match(1).to_i
    when '-exitCode'
      i += 1
      exit_code = (args[i] || '1').to_i
    when /\A-@/, /\A-(concurrency|go|cpuprofile|memprofile)=?/
      i += 1 unless a.include?('=')
    when /\A-/
      warn "flag provided but not defined: #{a}"
      check_help
      warn "parse args: flag provided but not defined: #{a}"
      exit 1
    else
      targets << a
    end
    i += 1
  end

  [enabled - disabled, targets, exit_code, check_tests]
end

def check(args)
  enabled, targets, exit_code, check_tests = parse_check(args)
  if targets.empty?
    warn 'load packages: err: go command required, not found: exec: "go": executable file not found in $PATH: stderr: '
    exit 1
  end
  files = collect_files(targets, check_tests)
  if files.empty?
    warn 'load packages: err: go command required, not found: exec: "go": executable file not found in $PATH: stderr: ' unless targets.any? { |t| File.exist?(t) }
    exit 1 unless targets.any? { |t| File.exist?(t) }
  end
  diags = files.flat_map { |f| scan_file(f, enabled) }
  diags.each { |d| puts d }
  exit(diags.empty? ? 0 : exit_code)
end

cmd = ARGV.shift
case cmd
when nil
  puts 'no args provided'
when 'help'
  usage
when 'version'
  puts "go-critic version: #{VERSION}"
when 'doc'
  doc(ARGV)
when 'check'
  check(ARGV)
else
  if cmd == '--help'
    warn '"--help" unknown command, did you mean "help"?'
  else
    warn "\"#{cmd}\" unknown command"
  end
  warn 'Run "go-critic help" for usage.'
  warn
  warn "no such command \"#{cmd}\""
end
