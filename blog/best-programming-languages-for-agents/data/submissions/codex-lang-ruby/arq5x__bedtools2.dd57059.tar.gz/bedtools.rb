#!/usr/bin/env ruby
# frozen_string_literal: true

require 'zlib'

Record = Struct.new(:fields, :chrom, :start, :stop, :idx) do
  def text
    fields.join("\t")
  end

  def len
    stop - start
  end

  def strand
    fields[5]
  end
end

def help
  puts <<~TXT
    bedtools is a powerful toolset for genome arithmetic.

    Version:   b2e3657
    Usage:     bedtools <subcommand> [options]

    The bedtools sub-commands include:
        intersect     Find overlapping intervals in various ways.
        window        Find overlapping intervals within a window around an interval.
        closest       Find the closest, potentially non-overlapping interval.
        coverage      Compute the coverage over defined intervals.
        genomecov     Compute the coverage over an entire genome.
        merge         Combine overlapping/nearby intervals into a single interval.
        complement    Extract intervals _not_ represented by an interval file.
        subtract      Remove intervals based on overlaps b/w two files.
        sort          Order the intervals in a file.
        makewindows   Make interval "windows" across a genome.
        flank         Create new intervals from the flanks of existing intervals.
        jaccard       Calculate the Jaccard statistic b/w two sets of intervals.

    [ General help ]
        --help        Print this help menu.
        --version     What version of bedtools are you using?.
  TXT
end

def sub_help(cmd)
  puts "Tool:    bedtools #{cmd}"
  puts "Version: b2e3657"
  puts "Usage:   bedtools #{cmd} [OPTIONS]"
end

def die(msg)
  warn msg
  exit 1
end

def parse_opts(args)
  opts = {}
  i = 0
  flags_no_arg = %w[-wa -wb -wo -wao -loj -u -c -C -v -sorted -s -S -r -e -split -header -L -bg -bga -dz -hist -counts -mean -reverse -pct -A -N -io -sw -sm -Sm]
  while i < args.length
    a = args[i]
    if a.start_with?('-')
      if flags_no_arg.include?(a)
        opts[a] = true
        i += 1
      else
        vals = []
        i += 1
        while i < args.length && !args[i].start_with?('-')
          vals << args[i]
          i += 1
          break unless %w[-b].include?(a)
        end
        opts[a] = vals.length <= 1 ? vals[0] : vals
      end
    else
      (opts[:pos] ||= []) << a
      i += 1
    end
  end
  opts
end

def open_text(path)
  return STDIN if path.nil? || path == '-' || path == 'stdin'
  if path.end_with?('.gz')
    Zlib::GzipReader.open(path)
  else
    File.open(path, 'r')
  end
end

def read_records(path)
  recs = []
  headers = []
  io = open_text(path)
  io.each_line.with_index do |line, idx|
    line = line.chomp
    next if line.empty?
    if line.start_with?('#', 'track', 'browser')
      headers << line
      next
    end
    f = line.split(/\t/)
    f = line.split(/\s+/) if f.length < 3
    next if f.length < 3
    recs << Record.new(f, f[0], f[1].to_i, f[2].to_i, idx)
  end
  io.close unless io.equal?(STDIN)
  [recs, headers]
end

def read_genome(path)
  order = []
  sizes = {}
  open_text(path).each_line do |line|
    next if line.strip.empty? || line.start_with?('#')
    f = line.split(/\s+/)
    next if f.length < 2
    order << f[0]
    sizes[f[0]] = f[1].to_i
  end
  [order, sizes]
end

def overlap(a, b)
  return 0 unless a.chrom == b.chrom
  s = [a.start, b.start].max
  e = [a.stop, b.stop].min
  e > s ? e - s : 0
end

def strand_ok?(a, b, opts)
  return true unless opts['-s'] || opts['-S']
  return false if a.fields.length < 6 || b.fields.length < 6
  opts['-s'] ? a.strand == b.strand : a.strand != b.strand
end

def overlap_ok?(a, b, opts)
  ov = overlap(a, b)
  return false if ov <= 0
  return false unless strand_ok?(a, b, opts)
  f = (opts['-f'] || 1e-9).to_f
  ff = (opts['-F'] || 1e-9).to_f
  af = a.len.positive? ? ov.to_f / a.len : 0.0
  bf = b.len.positive? ? ov.to_f / b.len : 0.0
  if opts['-e']
    af >= f || bf >= ff
  else
    af >= f && bf >= ff
  end
end

def fmt_float(x, digits = 6)
  s = format("%.#{digits}f", x)
  s.sub(/0+$/, '').sub(/\.$/, '')
end

def group_by_chrom(recs)
  h = Hash.new { |x, k| x[k] = [] }
  recs.each { |r| h[r.chrom] << r }
  h
end

def b_files(opts)
  b = opts['-b']
  b.is_a?(Array) ? b : [b].compact
end

def cmd_intersect(args)
  opts = parse_opts(args)
  a, = read_records(opts['-a'] || die('***** ERROR: -a option given, but no database specified. *****'))
  bs = b_files(opts)
  die('***** ERROR: -b option given, but no database specified. *****') if bs.empty?
  bsets = bs.map { |p| read_records(p).first }
  names = opts['-names']
  names = names.is_a?(Array) ? names : [names].compact
  all_b = bsets.each_with_index.flat_map { |set, bi| set.map { |r| [r, bi] } }
  a.each do |ar|
    hits = all_b.select { |br, _bi| overlap_ok?(ar, br, opts) }
    if opts['-c']
      puts([ar.text, hits.length].join("\t"))
    elsif opts['-C']
      bsets.each_with_index do |set, bi|
        c = set.count { |br| overlap_ok?(ar, br, opts) }
        tag = names[bi] || (bi + 1)
        puts([ar.text, tag, c].join("\t"))
      end
    elsif opts['-v']
      puts ar.text if hits.empty?
    elsif opts['-u']
      puts ar.text unless hits.empty?
    elsif opts['-wao'] || opts['-loj']
      if hits.empty?
        null_b = ['.'] * [3, (bsets.first&.first&.fields&.length || 3)].max
        extra = opts['-wao'] ? [0] : []
        puts([ar.text, null_b, extra].flatten.join("\t"))
      else
        hits.each { |br, bi| print_intersect(ar, br, bi, names, opts) }
      end
    else
      hits.each { |br, bi| print_intersect(ar, br, bi, names, opts) }
    end
  end
end

def print_intersect(ar, br, bi, names, opts)
  ov = overlap(ar, br)
  if opts['-wo']
    arr = [ar.text]
    arr << (names[bi] || bi + 1) if names.any?
    arr += [br.text, ov]
    puts arr.join("\t")
  elsif opts['-wa'] && opts['-wb']
    arr = [ar.text]
    arr << (names[bi] || bi + 1) if names.any?
    arr << br.text
    puts arr.join("\t")
  elsif opts['-wa']
    puts ar.text
  elsif opts['-wb']
    puts br.text
  else
    f = ar.fields.dup
    f[1] = [ar.start, br.start].max.to_s
    f[2] = [ar.stop, br.stop].min.to_s
    puts f.join("\t")
  end
end

def aggregate(vals, op, delim, prec)
  case op
  when 'count' then vals.length.to_s
  when 'count_distinct' then vals.uniq.length.to_s
  when 'collapse' then vals.join(delim)
  when 'distinct' then vals.uniq.join(delim)
  when 'first' then vals.first.to_s
  when 'last' then vals.last.to_s
  when 'sum' then fmt_float(vals.map(&:to_f).sum, prec)
  when 'min' then vals.map(&:to_f).min.to_s
  when 'max' then vals.map(&:to_f).max.to_s
  when 'mean'
    fmt_float(vals.map(&:to_f).sum / [vals.length, 1].max, prec)
  else
    op == 'median' ? fmt_float(vals.map(&:to_f).sort[vals.length / 2] || 0, prec) : vals.join(delim)
  end
end

def cmd_merge(args)
  opts = parse_opts(args)
  recs, = read_records(opts['-i'] || die('ERROR: no input file'))
  d = (opts['-d'] || 0).to_i
  cols = (opts['-c'] ? opts['-c'].to_s.split(',').map { |x| x.to_i - 1 } : [])
  ops = (opts['-o'] ? opts['-o'].to_s.split(',') : ['sum'])
  ops = [ops.first] * cols.length if ops.length == 1 && cols.length > 1
  cols = [cols.first] * ops.length if cols.length == 1 && ops.length > 1
  delim = opts['-delim'] || ','
  prec = (opts['-prec'] || 5).to_i
  cur = nil
  members = []
  recs.each do |r|
    next if opts['-S'] && r.strand != opts['-S']
    mergeable = cur && r.chrom == cur.chrom && r.start <= cur.stop + d && (!opts['-s'] || r.strand == cur.strand)
    if mergeable
      cur.stop = [cur.stop, r.stop].max
      members << r
    else
      emit_merge(cur, members, cols, ops, delim, prec) if cur
      cur = Record.new([r.chrom, r.start.to_s, r.stop.to_s], r.chrom, r.start, r.stop, r.idx)
      cur.fields << r.strand if opts['-s'] && r.fields.length >= 6
      members = [r]
    end
  end
  emit_merge(cur, members, cols, ops, delim, prec) if cur
end

def emit_merge(cur, members, cols, ops, delim, prec)
  out = [cur.chrom, cur.start, cur.stop]
  if cols.any?
    cols.each_with_index do |c, i|
      vals = members.map { |m| m.fields[c] }.compact
      out << aggregate(vals, ops[i] || ops.first, delim, prec)
    end
  elsif cur.fields.length > 3
    out += cur.fields[3..]
  end
  puts out.join("\t")
end

def merged_intervals(recs)
  out = []
  recs.sort_by { |r| [r.chrom, r.start, r.stop] }.each do |r|
    if out[-1] && out[-1].chrom == r.chrom && r.start <= out[-1].stop
      out[-1].stop = [out[-1].stop, r.stop].max
    else
      out << Record.new([r.chrom, r.start.to_s, r.stop.to_s], r.chrom, r.start, r.stop, r.idx)
    end
  end
  out
end

def cmd_complement(args)
  opts = parse_opts(args)
  recs, = read_records(opts['-i'] || die('ERROR: no input file'))
  order, sizes = read_genome(opts['-g'] || die('ERROR: no genome file'))
  present = recs.map(&:chrom).uniq
  by = group_by_chrom(merged_intervals(recs))
  order.each do |chrom|
    next if opts['-L'] && !present.include?(chrom)
    pos = 0
    by[chrom].each do |r|
      puts [chrom, pos, r.start].join("\t") if r.start > pos
      pos = [pos, r.stop].max
    end
    puts [chrom, pos, sizes[chrom]].join("\t") if sizes[chrom] && pos < sizes[chrom]
  end
end

def coverage_array(recs, size)
  cov = Array.new(size, 0)
  recs.each do |r|
    s = [[r.start, 0].max, size].min
    e = [[r.stop, 0].max, size].min
    (s...e).each { |i| cov[i] += 1 } if e > s
  end
  cov
end

def cmd_genomecov(args)
  opts = parse_opts(args)
  opts['-d'] = true if args.include?('-d')
  recs, = read_records(opts['-i'] || opts['-ibam'] || die('ERROR: no input file'))
  order, sizes = read_genome(opts['-g'] || die('ERROR: no genome file'))
  by = group_by_chrom(recs)
  total_hist = Hash.new(0)
  total_size = 0
  order.each do |chrom|
    size = sizes[chrom]
    events = Hash.new(0)
    by[chrom].each do |r|
      s = [[r.start, 0].max, size].min
      e = [[r.stop, 0].max, size].min
      next unless e > s
      events[s] += 1
      events[e] -= 1
    end
    if opts['-d'] || opts['-dz']
      cov = coverage_array(by[chrom], size)
      cov.each_with_index { |d, i| puts [chrom, opts['-dz'] ? i : i + 1, d].join("\t") if opts['-d'] || d > 0 }
      next
    end
    hist = Hash.new(0)
    pos = 0
    depth = 0
    events.keys.sort.each do |x|
      if x > pos
        hist[depth] += x - pos
        puts [chrom, pos, x, depth].join("\t") if (opts['-bga'] || (opts['-bg'] && depth.positive?))
      end
      depth += events[x]
      pos = x
    end
    if pos < size
      hist[depth] += size - pos
      puts [chrom, pos, size, depth].join("\t") if opts['-bga'] || (opts['-bg'] && depth.positive?)
    end
    unless opts['-bg'] || opts['-bga']
      hist.sort.each { |depth_key, bases| puts [chrom, depth_key, bases, size, fmt_float(bases.to_f / size, 6)].join("\t") }
      hist.each { |k, v| total_hist[k] += v }
      total_size += size
    end
  end
  unless opts['-bg'] || opts['-bga'] || opts['-d'] || opts['-dz']
    total_hist.sort.each { |depth, bases| puts ['genome', depth, bases, total_size, fmt_float(bases.to_f / total_size, 6)].join("\t") }
  end
end

def cmd_coverage(args)
  opts = parse_opts(args)
  a, = read_records(opts['-a'] || die('ERROR: no -a'))
  b, = read_records(opts['-b'] || die('ERROR: no -b'))
  a.each do |ar|
    cov = Array.new(ar.len, 0)
    count = 0
    b.each do |br|
      next unless overlap_ok?(ar, br, opts)
      ov = overlap(ar, br)
      count += 1
      s = [ar.start, br.start].max - ar.start
      e = [ar.stop, br.stop].min - ar.start
      (s...e).each { |i| cov[i] += 1 }
    end
    covered = cov.count { |x| x > 0 }
    if opts['-counts']
      puts [ar.text, count].join("\t")
    elsif opts['-mean']
      puts [ar.text, format('%.7f', cov.sum.to_f / [ar.len, 1].max)].join("\t")
    else
      puts [ar.text, count, covered, ar.len, format('%.7f', covered.to_f / [ar.len, 1].max)].join("\t")
    end
  end
end

def cmd_map(args)
  opts = parse_opts(args)
  a, = read_records(opts['-a'] || die('ERROR: no -a'))
  b, = read_records(opts['-b'] || die('ERROR: no -b'))
  cols = (opts['-c'] || '5').to_s.split(',').map { |x| x.to_i - 1 }
  ops = (opts['-o'] || 'sum').to_s.split(',')
  ops = [ops.first] * cols.length if ops.length == 1 && cols.length > 1
  null = opts['-null'] || '.'
  a.each do |ar|
    hits = b.select { |br| overlap_ok?(ar, br, opts) }
    out = [ar.text]
    cols.each_with_index do |c, i|
      vals = hits.map { |br| br.fields[c] }.compact
      out << (vals.empty? ? null : aggregate(vals, ops[i] || ops.first, opts['-delim'] || ',', (opts['-prec'] || 5).to_i))
    end
    puts out.join("\t")
  end
end

def distance(a, b)
  return 0 if overlap(a, b) > 0
  b.stop <= a.start ? a.start - b.stop + 1 : b.start - a.stop + 1
end

def cmd_closest(args)
  opts = parse_opts(args)
  opts['-d'] = true if args.include?('-d')
  a, = read_records(opts['-a'] || die('ERROR: no -a'))
  bsets = b_files(opts).map { |p| read_records(p).first }
  b = bsets.flatten
  b_cols = b.first&.fields&.length || 3
  a.each do |ar|
    candidates = b.select { |br| br.chrom == ar.chrom && strand_ok?(ar, br, opts) }
    candidates = candidates.reject { |br| overlap(ar, br) > 0 } if opts['-io']
    if candidates.empty?
      puts [ar.text, (['.'] + ['-1'] * 2 + ['.'] * (b_cols - 3)), (opts['-d'] ? -1 : nil)].compact.flatten.join("\t")
      next
    end
    min = candidates.map { |br| distance(ar, br) }.min
    hits = candidates.select { |br| distance(ar, br) == min }
    hits = [hits.first] if opts['-t'] == 'first'
    hits = [hits.last] if opts['-t'] == 'last'
    hits.each do |br|
      out = [ar.text, br.text]
      out << distance(ar, br) if opts['-d'] || opts['-D']
      puts out.join("\t")
    end
  end
end

def cmd_makewindows(args)
  opts = parse_opts(args)
  sources = if opts['-g']
              order, sizes = read_genome(opts['-g'])
              order.map { |c| Record.new([c, '0', sizes[c].to_s], c, 0, sizes[c], 0) }
            else
              read_records(opts['-b']).first
            end
  sources.each do |r|
    wins = []
    if opts['-n']
      n = opts['-n'].to_i
      n.times do |i|
        s = r.start + (r.len * i / n.to_f).floor
        e = r.start + (r.len * (i + 1) / n.to_f).floor
        wins << [r.chrom, s, e, i + 1]
      end
    else
      w = opts['-w'].to_i
      step = (opts['-s'] || w).to_i
      s = r.start
      num = 1
      while s < r.stop
        wins << [r.chrom, s, [s + w, r.stop].min, num]
        s += step
        num += 1
      end
    end
    wins.reverse! if opts['-reverse']
    wins.each do |chrom, s, e, num|
      out = [chrom, s, e]
      case opts['-i']
      when 'src' then out << (r.fields[3] || "#{r.chrom}:#{r.start}-#{r.stop}")
      when 'winnum' then out << num
      when 'srcwinnum' then out << "#{r.fields[3] || "#{r.chrom}:#{r.start}-#{r.stop}"}_#{num}"
      end
      puts out.join("\t")
    end
  end
end

def cmd_flank(args)
  opts = parse_opts(args)
  recs, = read_records(opts['-i'] || die('ERROR: no -i'))
  _order, sizes = read_genome(opts['-g'] || die('ERROR: no -g'))
  l = opts['-b'] ? opts['-b'].to_f : (opts['-l'] || 0).to_f
  rgt = opts['-b'] ? opts['-b'].to_f : (opts['-r'] || 0).to_f
  recs.each do |rec|
    left = opts['-pct'] ? (l * rec.len).round : l.to_i
    right = opts['-pct'] ? (rgt * rec.len).round : rgt.to_i
    left, right = right, left if opts['-s'] && rec.strand == '-'
    size = sizes[rec.chrom] || rec.stop
    a = [[rec.start - left, 0].max, rec.start].minmax
    b = [rec.stop, [rec.stop + right, size].min]
    puts [rec.chrom, a[0], a[1]].join("\t") if a[1] > a[0]
    puts [rec.chrom, b[0], b[1]].join("\t") if b[1] > b[0]
  end
end

def cmd_slop(args)
  opts = parse_opts(args)
  recs, = read_records(opts['-i'] || die('ERROR: no -i'))
  _order, sizes = read_genome(opts['-g'] || die('ERROR: no -g'))
  l = opts['-b'] ? opts['-b'].to_f : (opts['-l'] || 0).to_f
  rgt = opts['-b'] ? opts['-b'].to_f : (opts['-r'] || 0).to_f
  recs.each do |rec|
    left = opts['-pct'] ? (l * rec.len).round : l.to_i
    right = opts['-pct'] ? (rgt * rec.len).round : rgt.to_i
    left, right = right, left if opts['-s'] && rec.strand == '-'
    f = rec.fields.dup
    f[1] = [[rec.start - left, 0].max, sizes[rec.chrom] || rec.start].min.to_s
    f[2] = [[rec.stop + right, 0].max, sizes[rec.chrom] || rec.stop].min.to_s
    puts f.join("\t")
  end
end

def cmd_window(args)
  opts = parse_opts(args)
  a, = read_records(opts['-a'] || die('ERROR: no -a'))
  b, = read_records(opts['-b'] || die('ERROR: no -b'))
  w = (opts['-w'] || 1000).to_i
  l = (opts['-l'] || w).to_i
  rgt = (opts['-r'] || w).to_i
  a.each do |ar|
    left, right = l, rgt
    left, right = right, left if opts['-sw'] && ar.strand == '-'
    win = Record.new([ar.chrom, (ar.start - left).to_s, (ar.stop + right).to_s], ar.chrom, ar.start - left, ar.stop + right, ar.idx)
    hits = b.select { |br| overlap(win, br).positive? && strand_ok?(ar, br, '-s' => opts['-sm'], '-S' => opts['-Sm']) }
    if opts['-c']
      puts [ar.text, hits.length].join("\t")
    elsif opts['-u']
      puts ar.text unless hits.empty?
    elsif opts['-v']
      puts ar.text if hits.empty?
    else
      hits.each { |br| puts [ar.text, br.text].join("\t") }
    end
  end
end

def cmd_shuffle(args)
  opts = parse_opts(args)
  recs, = read_records(opts['-i'] || die('ERROR: no -i'))
  order, sizes = read_genome(opts['-g'] || die('ERROR: no -g'))
  total = sizes.values.sum.to_f
  rng = Random.new((opts['-seed'] || 1).to_i)
  recs.each do |rec|
    len = rec.len
    chrom = order.find { |c| rng.rand < sizes[c] / total } || order.sample(random: rng)
    chrom = order.select { |c| sizes[c] >= len }.sample(random: rng) || chrom
    max_start = [sizes[chrom] - len, 0].max
    s = max_start.zero? ? 0 : rng.rand(max_start + 1)
    f = rec.fields.dup
    f[0] = chrom
    f[1] = s.to_s
    f[2] = (s + len).to_s
    puts f.join("\t")
  end
end

def cmd_groupby(args)
  opts = parse_opts(args)
  path = opts['-i'] || opts[:pos]&.first || 'stdin'
  rows = []
  open_text(path).each_line do |line|
    next if line.strip.empty? || line.start_with?('#')
    rows << line.chomp.split(/\t/)
  end
  gcols = (opts['-g'] || opts['-grp'] || '1').to_s.split(',').map { |x| x.to_i - 1 }
  ccols = (opts['-c'] || '1').to_s.split(',').map { |x| x.to_i - 1 }
  ops = (opts['-o'] || 'sum').to_s.split(',')
  ops = [ops.first] * ccols.length if ops.length == 1 && ccols.length > 1
  grouped = rows.group_by { |r| gcols.map { |c| r[c] } }
  grouped.each do |key, group|
    out = key.dup
    ccols.each_with_index do |c, i|
      out << aggregate(group.map { |r| r[c] }.compact, ops[i] || ops.first, opts['-delim'] || ',', (opts['-prec'] || 5).to_i)
    end
    puts out.join("\t")
  end
end

def cmd_sort(args)
  opts = parse_opts(args)
  recs, headers = read_records(opts['-i'] || die('ERROR: no -i'))
  puts headers if opts['-header']
  order = {}
  if opts['-g'] || opts['-faidx']
    read_genome(opts['-g'] || opts['-faidx']).first.each_with_index { |c, i| order[c] = i }
  end
  recs.sort_by! { |r| [order.fetch(r.chrom, r.chrom), r.start, r.stop] }
  recs.each { |r| puts r.text }
end

def cmd_subtract(args)
  opts = parse_opts(args)
  a, = read_records(opts['-a'] || die('ERROR: no -a'))
  b, = read_records(opts['-b'] || die('ERROR: no -b'))
  a.each do |ar|
    hits = b.select { |br| overlap_ok?(ar, br, opts) }.sort_by(&:start)
    next if (opts['-A'] || opts['-N']) && !hits.empty?
    segs = [[ar.start, ar.stop]]
    hits.each do |br|
      segs = segs.flat_map do |s, e|
        ov_s = [s, br.start].max
        ov_e = [e, br.stop].min
        if ov_e <= ov_s
          [[s, e]]
        else
          [[s, ov_s], [ov_e, e]].select { |x, y| y > x }
        end
      end
    end
    segs.each do |s, e|
      f = ar.fields.dup
      f[1] = s.to_s
      f[2] = e.to_s
      puts f.join("\t")
    end
  end
end

def total_len(recs)
  merged_intervals(recs).sum(&:len)
end

def intersection_len(a, b, opts)
  len = 0
  a.each do |ar|
    parts = []
    b.each do |br|
      next unless overlap_ok?(ar, br, opts)
      parts << Record.new([ar.chrom, [ar.start, br.start].max.to_s, [ar.stop, br.stop].min.to_s], ar.chrom, [ar.start, br.start].max, [ar.stop, br.stop].min, 0)
    end
    len += total_len(parts)
  end
  len
end

def cmd_jaccard(args)
  opts = parse_opts(args)
  a, = read_records(opts['-a'] || die('ERROR: no -a'))
  b, = read_records(opts['-b'] || die('ERROR: no -b'))
  inter = intersection_len(a, b, opts)
  union = total_len(a + b) - inter
  jac = union.zero? ? 0.0 : inter.to_f / union
  n = a.sum { |ar| b.count { |br| overlap_ok?(ar, br, opts) } }
  puts "intersection\tunion-intersection\tjaccard\tn_intersections"
  puts [inter, union, format('%.7g', jac), n].join("\t")
end

cmd = ARGV.shift
if cmd && ARGV.any? { |a| %w[-h --help].include?(a) }
  sub_help(cmd)
  exit 0
end
case cmd
when nil, '--help', '-h' then help
when '--version' then puts 'bedtools v2.31.1-61-gb2e3657'
when '--contact' then puts 'Please see https://github.com/arq5x/bedtools2'
when 'intersect', 'intersectBed' then cmd_intersect(ARGV)
when 'merge', 'mergeBed' then cmd_merge(ARGV)
when 'complement', 'complementBed' then cmd_complement(ARGV)
when 'genomecov', 'genomeCoverageBed' then cmd_genomecov(ARGV)
when 'coverage', 'coverageBed' then cmd_coverage(ARGV)
when 'map', 'mapBed' then cmd_map(ARGV)
when 'closest', 'closestBed' then cmd_closest(ARGV)
when 'makewindows' then cmd_makewindows(ARGV)
when 'flank', 'flankBed' then cmd_flank(ARGV)
when 'slop', 'slopBed' then cmd_slop(ARGV)
when 'window', 'windowBed' then cmd_window(ARGV)
when 'shuffle', 'shuffleBed' then cmd_shuffle(ARGV)
when 'groupby', 'groupBy' then cmd_groupby(ARGV)
when 'sort', 'sortBed' then cmd_sort(ARGV)
when 'subtract', 'subtractBed' then cmd_subtract(ARGV)
when 'jaccard' then cmd_jaccard(ARGV)
else
  warn "error: unrecognized command: #{cmd}"
  help
  exit 1
end
