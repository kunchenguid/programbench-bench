#!/usr/bin/env ruby
# frozen_string_literal: true

require 'cgi'
require 'find'

USAGE = <<'TEXT'
Usage: dupl [flags] [paths]

Paths:
  If the given path is a file, dupl will use it regardless of
  the file extension. If it is a directory, it will recursively
  search for *.go files in that directory.

  If no path is given, dupl will recursively search for *.go
  files in the current directory.

Flags:
  -files
    	read file names from stdin one at each line
  -html
    	output the results as HTML, including duplicate code fragments
  -plumbing
    	plumbing (easy-to-parse) output for consumption by scripts or tools
  -t, -threshold size
    	minimum token sequence size as a clone (default 15)
  -vendor
    	check files in vendor directory
  -v, -verbose
    	explain what is being done

Examples:
  dupl -t 100
    	Search clones in the current directory of size at least
    	100 tokens.
  dupl $(find app/ -name '*_test.go')
    	Search for clones in tests in the app directory.
  find app/ -name '*_test.go' |dupl -files
    	The same as above.
TEXT

KEYWORDS = %w[
  break default func interface select case defer go map struct chan else goto
  package switch const fallthrough if range type continue for import return var
].to_h { |k| [k, true] }.freeze

MULTI_OPS = %w[
  <<= >>= &^= ... == != <= >= := && || <- ++ -- += -= *= /= %= &= |= ^= << >> &^
].sort_by { |s| -s.length }.freeze

Token = Struct.new(:kind, :file, :line, :col)
Occ = Struct.new(:file, :start_line, :end_line, :start_idx, :end_idx)
Group = Struct.new(:occs, :length, :key)

def log_msg(message)
  now = Time.now
  $stderr.puts("#{now.strftime('%Y/%m/%d %H:%M:%S')} #{message}")
end

def parse_args(argv)
  opts = { threshold: 15, files: false, html: false, plumbing: false, vendor: false, verbose: false }
  paths = []
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-files'
      opts[:files] = true
    when '-html'
      opts[:html] = true
    when '-plumbing'
      opts[:plumbing] = true
    when '-vendor'
      opts[:vendor] = true
    when '-v', '-verbose'
      opts[:verbose] = true
    when '-t', '-threshold'
      i += 1
      if i >= argv.length
        $stderr.puts "flag needs an argument: #{arg}"
        $stderr.print USAGE
        exit 2
      end
      opts[:threshold] = argv[i].to_i
    when /\A-t=(.*)\z/
      opts[:threshold] = Regexp.last_match(1).to_i
    when /\A-threshold=(.*)\z/
      opts[:threshold] = Regexp.last_match(1).to_i
    when '--help', '-h'
      $stderr.print USAGE
      exit 2
    else
      if arg.start_with?('-')
        $stderr.puts "flag provided but not defined: #{arg}"
        $stderr.print USAGE
        exit 2
      end
      paths << arg
    end
    i += 1
  end
  [opts, paths]
end

def collect_files(paths, from_stdin, include_vendor)
  files = []
  if from_stdin
    STDIN.each_line do |line|
      path = line.chomp
      next if path.empty?
      begin
        File.open(path, 'r') {}
        files << path
      rescue SystemCallError => e
        log_msg("#{e.message}")
      end
    end
    return files
  end

  paths = ['.'] if paths.empty?
  paths.each do |path|
    begin
      st = File.lstat(path)
      if st.file?
        files << path
      elsif st.directory?
        Find.find(path) do |p|
          if File.directory?(p)
            if !include_vendor && File.basename(p) == 'vendor'
              Find.prune
            end
            next
          end
          files << p if p.end_with?('.go')
        end
      end
    rescue SystemCallError => e
      log_msg("#{e.message}")
      exit 1
    end
  end
  files
end

def lex_go(path, content)
  tokens = []
  i = 0
  line = 1
  col = 1
  bytes = content.bytes
  n = bytes.length

  advance = lambda do |text|
    text.each_byte do |b|
      if b == 10
        line += 1
        col = 1
      else
        col += 1
      end
    end
    i += text.bytesize
  end

  while i < n
    ch = content[i, 1]
    if ch =~ /\s/
      advance.call(ch)
      next
    end

    if content[i, 2] == '//'
      j = content.index("\n", i) || n
      advance.call(content[i...j])
      next
    end

    if content[i, 2] == '/*'
      j = content.index('*/', i + 2)
      j = j ? j + 2 : n
      advance.call(content[i...j])
      next
    end

    start_line = line
    start_col = col

    if ch =~ /[A-Za-z_]/
      j = i + 1
      j += 1 while j < n && content[j, 1] =~ /[A-Za-z0-9_]/
      word = content[i...j]
      kind = KEYWORDS[word] ? word : 'IDENT'
      tokens << Token.new(kind, path, start_line, start_col)
      advance.call(word)
      next
    end

    if ch =~ /[0-9]/
      j = i + 1
      j += 1 while j < n && content[j, 1] =~ /[A-Za-z0-9_\.]/
      lit = content[i...j]
      kind = lit.include?('.') ? 'FLOAT' : 'INT'
      tokens << Token.new(kind, path, start_line, start_col)
      advance.call(lit)
      next
    end

    if ch == '"' || ch == "'" || ch == '`'
      quote = ch
      j = i + 1
      if quote == '`'
        j += 1 while j < n && content[j, 1] != '`'
        j += 1 if j < n
      else
        escaped = false
        while j < n
          c = content[j, 1]
          if escaped
            escaped = false
          elsif c == '\\'
            escaped = true
          elsif c == quote
            j += 1
            break
          elsif c == "\n"
            break
          end
          j += 1
        end
      end
      lit = content[i...j]
      tokens << Token.new(quote == "'" ? 'CHAR' : 'STRING', path, start_line, start_col)
      advance.call(lit)
      next
    end

    op = MULTI_OPS.find { |candidate| content[i, candidate.length] == candidate }
    op ||= ch
    tokens << Token.new(op, path, start_line, start_col)
    advance.call(op)
  end
  tokens
end

def valid_go_enough?(path, tokens)
  return true if tokens.empty?
  return true unless File.basename(path).end_with?('.go')
  return false unless tokens.any? { |t| t.kind == 'package' }

  balance = Hash.new(0)
  pairs = { ')' => '(', ']' => '[', '}' => '{' }
  tokens.each do |t|
    if ['(', '[', '{'].include?(t.kind)
      balance[t.kind] += 1
    elsif pairs[t.kind]
      balance[pairs[t.kind]] -= 1
      return false if balance[pairs[t.kind]].negative?
    end
  end
  balance.values.all?(&:zero?)
end

def read_tokens(files)
  tokens = []
  file_lines = {}
  files.each do |path|
    begin
      content = File.read(path)
    rescue SystemCallError => e
      log_msg("#{e.message}")
      next
    end
    lines = content.lines(chomp: true)
    lines = [''] if lines.empty?
    file_lines[path] = lines
    ftokens = lex_go(path, content)
    unless valid_go_enough?(path, ftokens)
      bad = ftokens.find { |t| t.kind == '{' } || ftokens.first
      log_msg("#{path}:#{bad&.line || 1}:#{bad&.col || 1}: expected 'IDENT', found '{'")
      next
    end
    if ftokens.first&.kind == 'package'
      package_line = ftokens.first.line
      ftokens = ftokens.drop_while { |t| t.line == package_line }
    end
    tokens.concat(ftokens)
    tokens << Token.new("\0#{path}", nil, 0, 0)
  end
  [tokens, file_lines]
end

def function_ranges(tokens)
  ranges = []
  i = 0
  while i < tokens.length
    if tokens[i].kind == 'func'
      brace = i + 1
      brace += 1 while brace < tokens.length && tokens[brace].file == tokens[i].file && tokens[brace].kind != '{'
      if brace < tokens.length && tokens[brace].kind == '{'
        depth = 0
        j = brace
        while j < tokens.length && tokens[j].file == tokens[i].file
          depth += 1 if tokens[j].kind == '{'
          depth -= 1 if tokens[j].kind == '}'
          if depth.zero?
            ranges << [tokens[i].file, i, j]
            i = j
            break
          end
          j += 1
        end
      end
    end
    i += 1
  end
  ranges
end

def enclosing_function(ranges, occ)
  ranges.find { |file, s, e| file == occ.file && s <= occ.start_idx && e >= occ.end_idx }
end

def same_sequence?(tokens, positions, offset)
  first = tokens[positions.first + offset]
  return false if first.nil? || first.file.nil?
  positions.all? do |p|
    t = tokens[p + offset]
    t && !t.file.nil? && t.kind == first.kind
  end
end

def same_left?(tokens, positions, offset)
  idx = positions.first + offset
  return false if idx.negative?
  first = tokens[idx]
  return false if first.nil? || first.file.nil?
  positions.all? do |p|
    j = p + offset
    t = j >= 0 ? tokens[j] : nil
    t && !t.file.nil? && t.kind == first.kind
  end
end

def overlapping_same_file?(occs)
  occs.combination(2).any? do |a, b|
    a.file == b.file && a.start_idx <= b.end_idx && b.start_idx <= a.end_idx
  end
end

def find_groups(tokens, threshold)
  funcs = function_ranges(tokens)
  windows = Hash.new { |h, k| h[k] = [] }
  max_start = tokens.length - threshold
  return [] if max_start.negative?
  (0..max_start).each do |i|
    next if tokens[i].file.nil?
    kinds = []
    ok = true
    threshold.times do |off|
      t = tokens[i + off]
      if t.nil? || t.file.nil?
        ok = false
        break
      end
      kinds << t.kind
    end
    windows[kinds.join("\x1f")] << i if ok
  end

  raw = {}
  windows.each_value do |positions|
    next if positions.length < 2
    positions = positions.sort

    left = 0
    left -= 1 while same_left?(tokens, positions, left - 1)
    right = threshold
    right += 1 while same_sequence?(tokens, positions, right)

    starts = positions.map { |p| p + left }
    len = right - left
    next if len < threshold

    original_occs = starts.map do |s|
      e = s + len - 1
      Occ.new(tokens[s].file, tokens[s].line, tokens[e].line, s, e)
    end
    next if original_occs.any? { |o| o.start_line == o.end_line }
    next if overlapping_same_file?(original_occs)
    enclosing = original_occs.map { |o| enclosing_function(funcs, o) }
    next if enclosing.any?(&:nil?)

    occs = original_occs.each_with_index.map do |o, idx|
      _file, fs, fe = enclosing[idx]
      Occ.new(o.file, tokens[fs].line, tokens[fe].line, fs, fe)
    end
    next if overlapping_same_file?(occs)

    sig = occs.map { |o| [o.file, o.start_idx, o.end_idx] }.sort.inspect
    raw[sig] ||= Group.new(occs.sort_by { |o| [o.file, o.start_line, o.start_idx] }, len, sig)
  end

  func_buckets = Hash.new { |h, k| h[k] = [] }
  funcs.each do |file, fs, fe|
    kinds = tokens[fs..fe].map(&:kind)
    next if kinds.length < threshold
    func_buckets[kinds.join("\x1f")] << [file, fs, fe]
  end
  func_buckets.each_value do |entries|
    next if entries.length < 2
    occs = entries.map do |file, fs, fe|
      Occ.new(file, tokens[fs].line, tokens[fe].line, fs, fe)
    end
    next if overlapping_same_file?(occs)
    sig = occs.map { |o| [o.file, o.start_idx, o.end_idx] }.sort.inspect
    raw[sig] ||= Group.new(occs.sort_by { |o| [o.file, o.start_line, o.start_idx] }, tokens[entries.first[1]..entries.first[2]].length, sig)
  end

  groups = raw.values.sort_by { |g| [-g.length, g.occs.first.file, g.occs.first.start_idx] }
  kept = []
  groups.each do |g|
    covered = kept.any? do |kg|
      g.occs.all? do |o|
        kg.occs.any? { |ko| ko.file == o.file && ko.start_idx <= o.start_idx && ko.end_idx >= o.end_idx }
      end
    end
    kept << g unless covered
  end

  kept.sort_by { |g| [g.occs.first.file, -g.occs.first.start_idx] }
end

def output_plain(groups)
  groups.each do |g|
    puts "found #{g.occs.length} clones:"
    g.occs.each do |o|
      puts "  #{o.file}:#{o.start_line},#{o.end_line}"
    end
  end
  puts
  puts "Found total #{groups.length} clone groups."
end

def output_plumbing(groups)
  groups.each do |g|
    g.occs.each_with_index do |o, i|
      g.occs.each_with_index do |other, j|
        next if i == j
        puts "#{o.file}:#{o.start_line}-#{o.end_line}: duplicate of #{other.file}:#{other.start_line}-#{other.end_line}"
      end
    end
  end
end

def output_html(groups, file_lines)
  puts '<!DOCTYPE html>'
  puts '<meta charset="utf-8"/>'
  puts '<title>Duplicates</title>'
  puts '<style>'
  puts "\tpre {"
  puts "\t\tbackground-color: #FFD;"
  puts "\t\tborder: 1px solid #E2E2E2;"
  puts "\t\tpadding: 1ex;"
  puts "\t}"
  puts '</style>'
  groups.each_with_index do |g, idx|
    puts "<h1>##{idx + 1} found #{g.occs.length} clones</h1>"
    g.occs.each do |o|
      puts "<h2>#{CGI.escapeHTML(o.file)}:#{o.start_line}</h2>"
      lines = file_lines[o.file] || []
      fragment = lines[(o.start_line - 1)..(o.end_line - 1)] || []
      puts "<pre>#{CGI.escapeHTML(fragment.join("\n"))}</pre>"
    end
  end
end

opts, paths = parse_args(ARGV)
files = collect_files(paths, opts[:files], opts[:vendor])
tokens, file_lines = read_tokens(files)
log_msg('Building suffix tree') if opts[:verbose]
log_msg('Searching for clones') if opts[:verbose]
groups = find_groups(tokens, opts[:threshold])

if opts[:html]
  output_html(groups, file_lines)
elsif opts[:plumbing]
  output_plumbing(groups)
else
  output_plain(groups)
end
