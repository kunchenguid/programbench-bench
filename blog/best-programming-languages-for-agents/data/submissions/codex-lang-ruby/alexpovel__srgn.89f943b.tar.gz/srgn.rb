#!/usr/bin/env ruby
# frozen_string_literal: true

begin
  require "unicode_normalize"
rescue LoadError
end

VERSION = "srgn 0.14.1"

HELP = <<~HELP
  A grep-like tool which understands source code syntax and allows for manipulation in
  addition to search

  Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]

  Arguments:
    [SCOPE]  Scope to apply to, as a regular expression pattern. [default: .*]

  Options:
        --completions <SHELL>  Print shell completions for the given shell. [possible values: bash, elvish, fish, powershell, zsh]
    -h, --help                 Print help (see more with '--help')
    -V, --version              Print version

  Composable Actions:
    -u, --upper        Uppercase anything in scope. [env: UPPER=]
    -l, --lower        Lowercase anything in scope. [env: LOWER=]
    -t, --titlecase    Titlecase anything in scope. [env: TITLECASE=]
    -n, --normalize    Normalize (Normalization Form D) anything in scope, and throw away marks. [env: NORMALIZE=]
    -g, --german       Perform substitutions on German words, such as 'Abenteuergruesse' to 'Abenteuergrüße', for anything in scope.
    -S, --symbols      Perform substitutions on symbols, such as '!=' to '≠', '->' to '→', on anything in scope.
    [REPLACEMENT]      Replace anything in scope with this value. [env: REPLACE=]

  Standalone Actions (only usable alone):
    -d, --delete   Delete anything in scope.
    -s, --squeeze  Squeeze consecutive occurrences of scope into one. [env: SQUEEZE=]

  Options (global):
    -G, --glob <GLOB>      Glob of files to work on (instead of reading stdin).
        --fail-no-files    Fail if working on files but none are found.
        --dry-run          Do not destructively overwrite files, instead print rich diff only.
    -i, --invert           Undo the effects of passed actions, where applicable. [env: INVERT=]
    -L, --literal-string   Do not interpret the scope as a regex. [env: LITERAL_STRING=]
        --fail-any         If anything at all is found to be in scope, fail.
        --fail-none        If nothing is found to be in scope, fail.
    -j, --join-language-scopes
    -H, --hidden
        --gitignored
        --sorted
        --stdin-detection <auto|force-readable|force-unreadable>
        --stdout-detection <auto|force-tty|force-pipe>
        --threads <THREADS>
    -v, --verbose...

  Language scopes:
        --python <PYTHON>  Scope Python code using a prepared query. [aliases: py]
        --rust <RUST>      Scope Rust code using a prepared query. [aliases: rs]
        --go <GO>          Scope Go code using a prepared query.
        --typescript <TS>  Scope TypeScript code using a prepared query. [aliases: ts]
        --c <C>            Scope C code using a prepared query.
        --csharp <CSHARP>  Scope C# code using a prepared query. [aliases: cs]
        --hcl <HCL>        Scope HCL code using a prepared query.
HELP

COMPLETION = <<~FISH
  complete -c srgn -l completions -d 'Print shell completions for the given shell.' -r -f -a "{bash\t'',elvish\t'',fish\t'',powershell\t'',zsh\t''}"
  complete -c srgn -s G -l glob -d 'Glob of files to work on (instead of reading stdin).' -r
  complete -c srgn -s u -l upper -d 'Uppercase anything in scope.'
  complete -c srgn -s l -l lower -d 'Lowercase anything in scope.'
  complete -c srgn -s t -l titlecase -d 'Titlecase anything in scope.'
  complete -c srgn -s n -l normalize -d 'Normalize anything in scope.'
  complete -c srgn -s g -l german -d 'Perform substitutions on German words.'
  complete -c srgn -s S -l symbols -d 'Perform substitutions on symbols.'
  complete -c srgn -s d -l delete -d 'Delete anything in scope.'
  complete -c srgn -s s -l squeeze -d 'Squeeze consecutive occurrences of scope into one.'
FISH

class Opts
  attr_accessor :scope, :replacement, :glob, :dry_run, :fail_no_files, :invert,
                :literal, :fail_any, :fail_none, :sorted, :stdin_detection,
                :actions, :langs, :join_langs, :files_mode, :files_with_matches,
                :only_matching, :count, :line_numbers

  def initialize
    @scope = nil
    @replacement = ENV["REPLACE"]
    @glob = nil
    @dry_run = false
    @fail_no_files = false
    @invert = truthy_env?("INVERT")
    @literal = truthy_env?("LITERAL_STRING")
    @fail_any = false
    @fail_none = false
    @sorted = false
    @stdin_detection = "auto"
    @actions = []
    @langs = []
    @join_langs = false
    @files_mode = false
    @files_with_matches = false
    @only_matching = false
    @count = false
    @line_numbers = false
    @actions << :upper if truthy_env?("UPPER")
    @actions << :lower if truthy_env?("LOWER")
    @actions << :title if truthy_env?("TITLECASE")
    @actions << :norm if truthy_env?("NORMALIZE")
  end

  def truthy_env?(name)
    v = ENV[name]
    v && v != "" && v != "0" && v.downcase != "false"
  end
end

def die_usage(msg, usage = "Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]")
  warn msg
  warn
  warn usage
  warn
  warn "For more information, try '--help'."
  exit 2
end

def parse_args(argv)
  opts = Opts.new
  i = 0
  positional = []
  while i < argv.length
    a = argv[i]
    if a == "--"
      opts.replacement = argv[(i + 1)..]&.join(" ") || ""
      break
    elsif a == "-h" || a == "--help"
      puts HELP
      exit 0
    elsif a == "-V" || a == "--version"
      puts VERSION
      exit 0
    elsif a == "--completions"
      i += 1
      puts COMPLETION
      exit 0
    elsif a == "-G" || a == "--glob"
      i += 1
      opts.glob = argv[i] || die_usage("error: a value is required for '--glob <GLOB>'")
    elsif a == "--dry-run"
      opts.dry_run = true
    elsif a == "--files"
      opts.files_mode = true
    elsif a == "--files-with-matches"
      opts.files_with_matches = true
    elsif a == "--only-matching"
      opts.only_matching = true
    elsif a == "--count"
      opts.count = true
    elsif a == "--line-numbers"
      opts.line_numbers = true
    elsif a == "--fail-no-files"
      opts.fail_no_files = true
    elsif a == "-i" || a == "--invert"
      opts.invert = true
    elsif a == "-L" || a == "--literal-string"
      opts.literal = true
    elsif a == "--fail-any"
      opts.fail_any = true
    elsif a == "--fail-none"
      opts.fail_none = true
    elsif a == "-j" || a == "--join-language-scopes"
      opts.join_langs = true
    elsif a == "--sorted"
      opts.sorted = true
    elsif a == "-H" || a == "--hidden" || a == "--gitignored"
      # Accepted for compatibility; this lightweight implementation does not filter.
    elsif a == "--stdin-detection"
      i += 1
      opts.stdin_detection = argv[i] || "auto"
    elsif a == "--stdout-detection" || a == "--threads"
      i += 1
    elsif a == "-v" || a.start_with?("-v")
      # Logging flag accepted.
    elsif a == "-u" || a == "--upper"
      opts.actions << :upper
    elsif a == "-l" || a == "--lower"
      opts.actions << :lower
    elsif a == "-t" || a == "--titlecase"
      opts.actions << :title
    elsif a == "-n" || a == "--normalize"
      opts.actions << :norm
    elsif a == "-g" || a == "--german"
      opts.actions << :german
    elsif a == "-S" || a == "--symbols"
      opts.actions << :symbols
    elsif a == "-d" || a == "--delete"
      opts.actions << :delete
    elsif a == "-s" || a == "--squeeze" || a == "--squeeze-repeats"
      opts.actions << :squeeze
    elsif a == "--german-naive"
      opts.actions << :german_naive
    elsif a == "--german-prefer-original"
      # Compatibility no-op for the approximation below.
    elsif %w[--python --py --rust --rs --go --typescript --ts --c --csharp --cs --hcl].include?(a)
      i += 1
      opts.langs << [a.sub(/^--/, ""), argv[i] || ""]
    elsif a =~ /^--(python|py|rust|rs|go|typescript|ts|c|csharp|cs|hcl)-query(-file)?$/
      i += 1
      opts.langs << [$1, "query"]
    elsif a.start_with?("-") && a.length > 2 && !a.start_with?("--")
      a[1..].each_char do |ch|
        case ch
        when "u" then opts.actions << :upper
        when "l" then opts.actions << :lower
        when "t" then opts.actions << :title
        when "n" then opts.actions << :norm
        when "g" then opts.actions << :german
        when "S" then opts.actions << :symbols
        when "d" then opts.actions << :delete
        when "s" then opts.actions << :squeeze
        when "i" then opts.invert = true
        when "L" then opts.literal = true
        end
      end
    else
      positional << a
    end
    i += 1
  end
  opts.scope = positional.shift
  if opts.literal && opts.scope.nil?
    die_usage("error: The following required argument was not provided: scope", "Usage: srgn [OPTIONS] [SCOPE] [-- <REPLACEMENT>]")
  end
  if opts.actions.include?(:delete) && opts.scope.nil?
    die_usage("error: the following required arguments were not provided:\n  <SCOPE>", "Usage: executable --delete <SCOPE> [-- <REPLACEMENT>]")
  end
  opts.scope ||= ".*"
  opts
end

def compile_scope(scope, literal)
  return Regexp.new(Regexp.escape(scope), Regexp::MULTILINE) if literal
  src = scope.gsub(/\(\?P<([A-Za-z_][A-Za-z0-9_]*)>/, "(?<\\1>")
  Regexp.new(src, Regexp::MULTILINE)
rescue RegexpError => e
  warn "Error: #{e.message}"
  exit 2
end

def line_offsets(s)
  offs = []
  pos = 0
  s.each_line do |line|
    offs << pos
    pos += line.length
  end
  offs << pos if s.empty?
  offs
end

def add_line_span(spans, start_pos, line)
  spans << [start_pos, start_pos + line.length]
end

def balanced_block_span(text, start_idx)
  open = text.index("{", start_idx)
  return [start_idx, text.index("\n", start_idx) || text.length] unless open
  depth = 0
  i = open
  while i < text.length
    c = text[i]
    depth += 1 if c == "{"
    if c == "}"
      depth -= 1
      return [start_idx, i + 1] if depth.zero?
    end
    i += 1
  end
  [start_idx, text.length]
end

def python_block_span(text, line_start, indent)
  rest = text[line_start..] || ""
  pos = line_start
  first = true
  rest.each_line do |line|
    if first
      pos += line.length
      first = false
      next
    end
    stripped = line.strip
    return [line_start, pos] if !stripped.empty? && (line[/\A */].length <= indent)
    pos += line.length
  end
  [line_start, text.length]
end

def lexical_spans(text, lang, kind)
  spans = []
  offs = line_offsets(text)
  case kind
  when /comments?/, "doc-comments"
    text.scan(/#[^\n]*|\/\/[^\n]*|\/\*.*?\*\//m) { spans << [Regexp.last_match.begin(0), Regexp.last_match.end(0)] }
  when /strings?/, "doc-strings"
    text.scan(/"""(?:.|\n)*?"""|'''(?:.|\n)*?'''|`[^`]*`|r#*"(?:(?!"#).|\n)*"#*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/m) { spans << [Regexp.last_match.begin(0), Regexp.last_match.end(0)] }
  when "class"
    if lang =~ /python|py/
      text.each_line.with_index do |line, idx|
        next unless line =~ /^(\s*)class\b/
        spans << python_block_span(text, offs[idx], Regexp.last_match(1).length)
      end
    else
      text.scan(/\bclass\s+\w+/) { spans << balanced_block_span(text, Regexp.last_match.begin(0)) }
    end
  when "def", "async-def", "methods", "class-methods", "static-methods"
    text.each_line.with_index do |line, idx|
      next unless line =~ /^(\s*)(async\s+)?def\b/
      spans << python_block_span(text, offs[idx], Regexp.last_match(1).length)
    end
  when "function-names"
    text.scan(/^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)/) { spans << [Regexp.last_match.begin(1), Regexp.last_match.end(1)] }
  when "function-calls"
    text.scan(/\b([A-Za-z_]\w*)\s*\(/) { spans << [Regexp.last_match.begin(1), Regexp.last_match.end(1)] }
  when "imports", "uses", "usings", "includes"
    text.each_line.with_index do |line, idx|
      add_line_span(spans, offs[idx], line) if line =~ /^\s*(import|from|use|using|#include)\b/
    end
  when "identifiers", "identifier", "type-identifier", "variable-identifiers"
    text.scan(/\b[A-Za-z_]\w*\b/) { spans << [Regexp.last_match.begin(0), Regexp.last_match.end(0)] }
  when "fn", "func", "function", "method", "free-func", "init-func", "function-def", "async-function", "sync-function"
    text.scan(/\b(fn|func|function)\s+\w+|\b\w+\s*\([^)]*\)\s*\{/) { spans << balanced_block_span(text, Regexp.last_match.begin(0)) }
  when "struct", "enum", "interface", "trait", "impl", "mod", "type-def", "union"
    kw = kind.split("-").last
    kw = "struct|enum|interface|trait|impl|mod|type|union" if kind == "type-def"
    text.scan(/\b(?:#{kw})\b/) { spans << balanced_block_span(text, Regexp.last_match.begin(0)) }
  when "if", "for", "while", "switch", "try", "with", "select", "defer", "go", "do", "lambda"
    text.scan(/\b#{Regexp.escape(kind)}\b/) { spans << balanced_block_span(text, Regexp.last_match.begin(0)) }
  else
    spans << [0, text.length]
  end
  spans.empty? ? [] : merge_spans(spans)
end

def merge_spans(spans)
  spans.sort_by!(&:first)
  out = []
  spans.each do |s, e|
    if out.empty? || s > out[-1][1]
      out << [s, e]
    else
      out[-1][1] = [out[-1][1], e].max
    end
  end
  out
end

def intersect_spans(a, b)
  i = j = 0
  out = []
  while i < a.length && j < b.length
    s = [a[i][0], b[j][0]].max
    e = [a[i][1], b[j][1]].min
    out << [s, e] if s < e
    a[i][1] < b[j][1] ? i += 1 : j += 1
  end
  out
end

def language_spans(text, opts)
  return [[0, text.length]] if opts.langs.empty?
  all = opts.langs.map { |lang, kind| lexical_spans(text, lang, kind) }
  return merge_spans(all.flatten(1)) if opts.join_langs
  all.reduce([[0, text.length]]) { |acc, spans| intersect_spans(acc, spans) }
end

SYMBOLS = [
  ["<=>", "⇔"], ["=>", "⇒"], ["->", "→"], ["<-", "←"],
  ["!=", "≠"], ["<=", "≤"], [">=", "≥"],
  ["---", "—"], ["--", "–"], ["...", "…"],
  ["&&", "∧"], ["||", "∨"], ["::", "∷"]
].freeze

def symbolize(s, invert)
  pairs = invert ? SYMBOLS.map { |a, b| [b, a] } : SYMBOLS
  pairs.each { |a, b| s = s.gsub(a, b) }
  s
end

def germanize(s, naive)
  if naive
    return s.gsub(/AE/, "Ä").gsub(/OE/, "Ö").gsub(/UE/, "Ü").gsub(/SS/, "ẞ")
            .gsub(/Ae/, "Ä").gsub(/Oe/, "Ö").gsub(/Ue/, "Ü")
            .gsub(/ae/, "ä").gsub(/oe/, "ö").gsub(/ue/, "ü").gsub(/ss/, "ß")
  end
  replacements = {
    "Gruesse" => "Grüße", "gruesse" => "grüße", "GRUESSE" => "GRÜSSE",
    "Strasse" => "Straße", "strasse" => "straße", "STRASSE" => "STRASSE",
    "Bruecke" => "Brücke", "Bruecken" => "Brücken", "bruecke" => "brücke", "bruecken" => "brücken",
    "Abenteuergruesse" => "Abenteuergrüße", "abenteuergruesse" => "abenteuergrüße"
  }
  replacements.each { |a, b| s = s.gsub(a, b) }
  s
end

def titlecase(s)
  s.gsub(/\p{L}[\p{L}\p{M}'-]*/) { |w| w[0].upcase + w[1..].to_s.downcase }
end

def normalize_text(s)
  if s.respond_to?(:unicode_normalize)
    s.unicode_normalize(:nfd).gsub(/\p{Mn}/, "")
  else
    s.tr("áàäâãåéèëêíìïîóòöôõúùüûñçÁÀÄÂÃÅÉÈËÊÍÌÏÎÓÒÖÔÕÚÙÜÛÑÇ", "aaaaaaeeeeiiiiooooouuuuncAAAAAAEEEEIIIIOOOOOUUUUNC")
  end
end

def expand_replacement(template, match)
  template.gsub(/\$([A-Za-z_][A-Za-z0-9_]*|\d+)/) do
    key = Regexp.last_match(1)
    if key =~ /^\d+$/
      match[key.to_i] || ""
    else
      begin
        match[key] || ""
      rescue IndexError
        ""
      end
    end
  end
end

def transform_match(str, match, opts)
  out = opts.replacement.nil? ? str : expand_replacement(opts.replacement, match)
  opts.actions.each do |act|
    out = case act
          when :upper then out.upcase
          when :lower then out.downcase
          when :title then titlecase(out)
          when :norm then normalize_text(out)
          when :symbols then symbolize(out, opts.invert)
          when :german then opts.invert ? out : germanize(out, false)
          when :german_naive then opts.invert ? out : germanize(out, true)
          else out
          end
  end
  out
end

def apply_in_spans(text, spans, regex, opts)
  found = false
  delta = 0
  out = text.dup
  spans.each do |s0, e0|
    s = s0 + delta
    e = e0 + delta
    segment = out[s...e] || ""
    before_len = segment.length
    new_segment =
      if opts.actions.include?(:delete)
        segment.gsub(regex) { found = true; "" }
      elsif opts.actions.include?(:squeeze)
        segment.gsub(/(?:#{regex.source})+/m) { found = true; Regexp.last_match(0)[0] || "" }
      else
        segment.gsub(regex) do |m|
          found = true
          transform_match(m, Regexp.last_match, opts)
        end
      end
    out[s...e] = new_segment
    delta += new_segment.length - before_len
  end
  [out, found]
end

def search_output(text, path, spans, regex, opts)
  found = false
  total = 0
  starts = line_offsets(text)
  text.each_line.with_index do |line, idx|
    line_start = starts[idx]
    spans_for_line = spans.select { |s, e| e > line_start && s < line_start + line.length }
    next if spans_for_line.empty?
    line.scan(regex) do
      m = Regexp.last_match
      ms = line_start + m.begin(0)
      me = line_start + m.end(0)
      next unless spans_for_line.any? { |s, e| ms >= s && me <= e }
      total += 1
      if opts.count
        # Count-only mode suppresses individual matches.
      elsif opts.only_matching
        puts m[0]
      elsif opts.line_numbers || !opts.langs.empty?
        puts "#{path}:#{idx + 1}:#{m.begin(0)}-#{m.end(0)}:#{line.chomp}"
      else
        puts line.chomp
      end
      found = true
    end
  end
  puts total if opts.count
  found
end

def process_text(text, path, opts)
  regex = compile_scope(opts.scope, opts.literal)
  spans = language_spans(text, opts)
  has_action = opts.replacement || !opts.actions.empty?
  found = spans.any? { |s, e| (text[s...e] || "").match?(regex) }

  if opts.fail_any && found
    warn "Error: Error applying: Some input was in scope"
    return [nil, true, 1]
  end
  if opts.fail_none && !found
    warn "Error: Error applying: No input was in scope"
    return [nil, false, 1]
  end

  unless has_action
    search_mode = !opts.langs.empty? || opts.only_matching || opts.count || opts.line_numbers || opts.files_with_matches
    if !search_mode
      warn "[ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any."
      return [text, found, 0]
    end
    return [nil, search_output(text, path, spans, regex, opts), 0]
  end

  new_text, did = apply_in_spans(text, spans, regex, opts)
  [new_text, did, 0]
end

def diffish(path, old_text, new_text, regex)
  old_lines = old_text.lines
  new_lines = new_text.lines
  max = [old_lines.length, new_lines.length].max
  (0...max).each do |i|
    next if old_lines[i] == new_lines[i]
    [old_lines[i], new_lines[i]].compact.each do |line|
      if (m = line.match(regex))
        puts "#{path}:#{i + 1}:#{m.begin(0)}-#{m.end(0)}:#{line.chomp}"
      else
        puts "#{path}:#{i + 1}:0-0:#{line.chomp}"
      end
    end
  end
end

opts = parse_args(ARGV)

if opts.glob
  files = Dir.glob(opts.glob, File::FNM_DOTMATCH).select { |f| File.file?(f) }
  files.sort! if opts.sorted
  if files.empty? && opts.fail_no_files
    warn "[ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any." if opts.actions.empty? && opts.replacement.nil?
    warn "Error: No files found"
    exit 1
  end
  if opts.files_mode
    puts files
    exit 0
  end
  status = 0
  files.each do |file|
    text = File.binread(file)
    if opts.files_with_matches
      regex = compile_scope(opts.scope, opts.literal)
      spans = language_spans(text, opts)
      puts file if spans.any? { |s, e| (text[s...e] || "").match?(regex) }
      next
    end
    new_text, did, code = process_text(text, file, opts)
    status = code if code != 0
    next if new_text.nil?
    if opts.dry_run
      diffish(file, text, new_text, compile_scope(opts.scope, opts.literal)) if did
    elsif did && new_text != text
      File.binwrite(file, new_text)
      puts file
    elsif opts.replacement || !opts.actions.empty?
      puts file if did
    end
  end
  exit status
else
  readable = opts.stdin_detection == "force-readable" || (opts.stdin_detection != "force-unreadable" && !STDIN.tty?)
  input = readable ? STDIN.read : ""
  output, _did, status = process_text(input, "(stdin)", opts)
  print output unless output.nil?
  exit status
end
