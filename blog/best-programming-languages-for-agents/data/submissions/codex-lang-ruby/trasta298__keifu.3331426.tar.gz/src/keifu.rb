#!/usr/bin/env ruby
# frozen_string_literal: true

require 'open3'

VERSION = 'keifu 0.2.3'

HELP = <<~TEXT
  A TUI tool to visualize Git commit graphs with branch genealogy

  Usage: executable

  Options:
    -h, --help     Print help
    -V, --version  Print version
TEXT

Commit = Struct.new(:sha, :parents, :author, :email, :time, :subject, :body, :refs, :graph, :dirty, keyword_init: true)

def plain_width(str)
  str.to_s.gsub(/\e\[[0-9;]*m/, '').each_char.sum { |c| c.ord > 0x1100 ? 2 : 1 }
end

def fit(str, width)
  return '' if width <= 0
  s = str.to_s.gsub(/\s+/, ' ')
  out = +''
  used = 0
  s.each_char do |ch|
    w = ch.ord > 0x1100 ? 2 : 1
    break if used + w > width
    out << ch
    used += w
  end
  out + (' ' * [width - used, 0].max)
end

def run_git(*args)
  out, err, st = Open3.capture3('git', *args)
  [out, err, st.success?]
end

def git_out(*args)
  out, _err, ok = run_git(*args)
  ok ? out : ''
end

def repository_root
  out, err, ok = run_git('rev-parse', '--show-toplevel')
  unless ok
    warn "Error: Git repository not found. Please run inside a Git repository.\n\nCaused by:\n    #{err.strip.empty? ? "could not find repository at '.'" : err.lines.first.to_s.strip}"
    exit 1
  end
  out.strip
end

def branch_name
  out = git_out('branch', '--show-current').strip
  out.empty? ? git_out('rev-parse', '--short', 'HEAD').strip : out
end

def refs_by_sha
  map = Hash.new { |h, k| h[k] = [] }
  git_out('for-each-ref', '--format=%(objectname)%09%(refname:short)', 'refs/heads', 'refs/remotes').each_line do |line|
    sha, ref = line.chomp.split("\t", 2)
    next if sha.to_s.empty? || ref.to_s.end_with?('/HEAD')
    map[sha] << ref
  end
  map.each_value { |v| v.sort_by! { |r| [r.start_with?('origin/') ? 1 : 0, r] } }
  map
end

def commit_details(sha)
  fmt = '%H%x1f%P%x1f%an%x1f%ae%x1f%at%x1f%s%x1f%b'
  out = git_out('show', '-s', "--format=#{fmt}", sha)
  parts = out.split("\x1f", 7)
  {
    sha: parts[0].to_s.strip,
    parents: parts[1].to_s.split,
    author: parts[2].to_s,
    email: parts[3].to_s,
    time: Time.at(parts[4].to_i),
    subject: parts[5].to_s.strip,
    body: parts[6].to_s.strip
  }
rescue StandardError
  { sha: sha, parents: [], author: '', email: '', time: Time.now, subject: sha, body: '' }
end

def commits
  refs = refs_by_sha
  lines = git_out('log', '--all', '--graph', '--date=short', '--pretty=format:%H').lines.map(&:chomp)
  result = []
  lines.each do |line|
    if (m = line.match(/^(.*?)([0-9a-f]{40})$/))
      detail = commit_details(m[2])
      result << Commit.new(**detail, refs: refs[detail[:sha]], graph: m[1].rstrip, dirty: false)
    elsif !result.empty? && !line.strip.empty?
      result.last.graph = [result.last.graph, line.strip].join("\n")
    end
  end
  if dirty_worktree?
    result.unshift(Commit.new(sha: 'WORKTREE', parents: [], author: '', email: '', time: Time.now,
                             subject: 'uncommitted changes', body: '', refs: [], graph: '●', dirty: true))
  end
  result.first(500)
end

def dirty_worktree?
  !git_out('status', '--porcelain', '--untracked-files=no').strip.empty?
end

def changed_files(commit)
  return dirty_files if commit&.dirty
  return [] unless commit
  args = if commit.parents.empty?
           ['show', '--numstat', '--name-status', '--format=', '--root', commit.sha]
         else
           ['diff', '--numstat', '--name-status', "#{commit.parents.first}..#{commit.sha}"]
         end
  git_out(*args).lines.map(&:chomp).reject(&:empty?).first(50)
end

def dirty_files
  git_out('diff', '--numstat', '--name-status').lines.map(&:chomp).reject(&:empty?).first(50)
end

def file_summary(lines)
  files = 0
  plus = 0
  minus = 0
  lines.each do |l|
    parts = l.split(/\t/)
    next unless parts.size >= 3 && parts[0] =~ /^\d+$/
    files += 1
    plus += parts[0].to_i
    minus += parts[1].to_i
  end
  [files, plus, minus]
end

class App
  def initialize
    @root = repository_root
    @repo_name = File.basename(@root)
    @commits = commits
    @selected = 0
    @offset = 0
    @message = nil
    @help = false
    @search = nil
  end

  def run
    if !$stdin.tty? || !$stdout.tty?
      warn 'Error: No such device or address (os error 6)'
      exit 1
    end
    old_stty = `stty -g 2>/dev/null`.strip
    system('stty raw -echo 2>/dev/null')
    begin
      print "\e[?1049h\e[?25l"
      loop do
        render
        ch = read_key
        break if handle_key(ch) == :quit
      end
    end
  ensure
    system("stty #{old_stty} 2>/dev/null") if old_stty && !old_stty.empty?
    print "\e[0m\e[?1049l\e[?25h"
  end

  def read_key
    c = $stdin.sysread(1)
    if c == "\e"
      rest = +''
      begin
        while IO.select([$stdin], nil, nil, 0.01)
          rest << $stdin.read_nonblock(1)
        end
      rescue IO::WaitReadable
      end
      c + rest
    else
      c
    end
  end

  def handle_key(ch)
    return :quit if ch && (ch.include?('q') || ch.include?("\u0003"))
    if @search
      return search_key(ch)
    end
    case ch
    when 'q', "\e" then :quit
    when 'j', "\e[B", "\u000e" then move(1)
    when 'k', "\e[A", "\u0010" then move(-1)
    when "\u0004" then move(10)
    when "\u0015" then move(-10)
    when 'g', "\e[H" then @selected = 0
    when 'G', "\e[F" then @selected = [@commits.length - 1, 0].max
    when ']', "\t" then jump_label(1)
    when '[', "\e[Z" then jump_label(-1)
    when '@' then jump_head
    when '?' then @help = !@help
    when '/' then @search = +''
    when 'R' then refresh
    when 'f' then git_action('fetch', 'origin')
    when "\r", "\n" then checkout_selected
    when 'b' then create_branch
    when 'd' then delete_branch
    end
    nil
  end

  def search_key(ch)
    case ch
    when "\e"
      @search = nil
    when "\r", "\n"
      jump_to_search
      @search = nil
    when "\177", "\b"
      @search.empty? ? @search = nil : @search.chop!
    when "\e[A", "\u0010"
      jump_search(-1)
    when "\e[B", "\u000e"
      jump_search(1)
    else
      @search << ch if ch && ch.bytes.all? { |b| b >= 32 && b < 127 }
      jump_to_search
    end
    nil
  end

  def move(n)
    @selected = [[@selected + n, 0].max, [@commits.length - 1, 0].max].min
  end

  def jump_label(dir)
    return if @commits.empty?
    i = @selected
    loop do
      i += dir
      break if i < 0 || i >= @commits.length
      if @commits[i].refs && !@commits[i].refs.empty?
        @selected = i
        break
      end
    end
  end

  def jump_head
    head = git_out('rev-parse', 'HEAD').strip
    idx = @commits.index { |c| c.sha == head }
    @selected = idx if idx
  end

  def matching_indices
    q = @search.to_s.downcase
    return [] if q.empty?
    @commits.each_index.select { |i| @commits[i].refs.any? { |r| r.downcase.include?(q) } }
  end

  def jump_to_search
    idx = matching_indices.first
    @selected = idx if idx
  end

  def jump_search(dir)
    ids = matching_indices
    return if ids.empty?
    cur = ids.index { |i| i >= @selected } || 0
    @selected = ids[(cur + dir) % ids.length]
  end

  def refresh
    @commits = commits
    @selected = [[@selected, 0].max, [@commits.length - 1, 0].max].min
    @message = 'Refreshed'
  end

  def git_action(*args)
    _out, err, ok = run_git(*args)
    @message = ok ? "#{args.join(' ')} complete" : err.lines.first.to_s.strip
    refresh
  end

  def selected_commit
    @commits[@selected]
  end

  def selected_ref
    c = selected_commit
    return nil unless c
    c.refs.find { |r| !r.include?('/') } || c.refs.first
  end

  def checkout_selected
    c = selected_commit
    return unless c && !c.dirty
    ref = selected_ref || c.sha
    if ref&.start_with?('origin/')
      local = ref.sub(%r{\Aorigin/}, '')
      run_git('branch', '-f', local, ref)
      git_action('checkout', local)
    else
      git_action('checkout', ref)
    end
  end

  def create_branch
    c = selected_commit
    return unless c && !c.dirty
    name = "branch-#{c.sha[0, 7]}"
    i = 1
    existing = git_out('branch', '--format=%(refname:short)').lines.map(&:strip)
    while existing.include?(name)
      i += 1
      name = "branch-#{c.sha[0, 7]}-#{i}"
    end
    git_action('branch', name, c.sha)
  end

  def delete_branch
    ref = selected_ref
    return unless ref && !ref.include?('/') && ref != branch_name
    git_action('branch', '-d', ref)
  end

  def render
    rows, cols = terminal_size
    rows = [rows, 10].max
    cols = [cols, 40].max
    list_h = [rows - 8, 3].max
    detail_h = rows - list_h - 2
    @offset = @selected if @selected < @offset
    @offset = @selected - list_h + 2 if @selected >= @offset + list_h - 2
    @offset = [@offset, 0].max

    buf = +""
    buf << "\e[H\e[0m"
    buf << box_top('Commits', cols)
    visible = list_h - 2
    visible.times do |n|
      idx = @offset + n
      line = idx < @commits.length ? commit_line(@commits[idx], cols - 2, idx == @selected) : ''
      buf << "│#{fit(line, cols - 2)}│\n"
    end
    buf << box_bottom(cols)
    left_w = cols / 2
    right_w = cols - left_w
    buf << box_pair_top('Commit Detail', 'Changed Files', left_w, right_w)
    detail_lines, file_lines = pane_lines(detail_h - 2, left_w - 2, right_w - 2)
    (detail_h - 2).times do |i|
      buf << "│#{fit(detail_lines[i], left_w - 2)}││#{fit(file_lines[i], right_w - 2)}│\n"
    end
    buf << box_pair_bottom(left_w, right_w)
    buf << status_line(cols)
    buf << help_overlay(cols, rows) if @help
    print buf
  end

  def terminal_size
    out = `stty size 2>/dev/null`.strip
    if out =~ /\A(\d+)\s+(\d+)\z/
      [$1.to_i, $2.to_i]
    else
      [24, 80]
    end
  end

  def box_top(title, width)
    "┌ #{title} #{'─' * [width - title.length - 4, 0].max}┐\n"
  end

  def box_bottom(width)
    "└#{'─' * [width - 2, 0].max}┘\n"
  end

  def box_pair_top(a, b, lw, rw)
    "┌ #{a} #{'─' * [lw - a.length - 4, 0].max}┐┌ #{b} #{'─' * [rw - b.length - 4, 0].max}┐\n"
  end

  def box_pair_bottom(lw, rw)
    "└#{'─' * [lw - 2, 0].max}┘└#{'─' * [rw - 2, 0].max}┘\n"
  end

  def label_for(c)
    return '' if c.refs.empty?
    head = branch_name
    main = c.refs.include?(head) ? head : c.refs.first
    extra = c.refs.length > 1 ? " +#{c.refs.length - 1}" : ''
    "[#{main}#{extra}]"
  end

  def commit_line(c, width, selected)
    mark = c.dirty ? '●' : graph_mark(c)
    label = label_for(c)
    date = c.dirty ? '' : c.time.strftime('%Y-%m-%d')
    auth = c.author.to_s.split(/\s+/).first.to_s
    body_w = [width - 25, 10].max
    prefix = selected ? '> ' : '  '
    "#{prefix}#{fit(mark, 4)} #{label} #{fit(c.subject, body_w)} #{date} #{fit(auth, 8)}"
  end

  def graph_mark(c)
    g = c.graph.to_s
    return '◉─╮' if c.parents.length > 1
    return '│ ●' if g.include?('|') && !g.start_with?('*')
    '●'
  end

  def pane_lines(max, lw, rw)
    c = selected_commit
    return [['Select a commit'], []] unless c
    files = changed_files(c)
    detail = if c.dirty
               ['Uncommitted changes', '', 'Modified tracked files in working tree']
             else
               ['Commit:', c.sha, "Author: #{c.author} <#{c.email}>", "Date:   #{c.time.strftime('%Y-%m-%d %H:%M:%S')}", '', c.subject]
             end
    detail += c.body.lines.map(&:chomp)
    count, plus, minus = file_summary(files)
    shown = files.map { |l| format_file_line(l, rw) }
    summary = count.zero? && !files.empty? ? ["#{files.length} files changed"] : ["#{count} files changed   +#{plus} -#{minus}"]
    [detail.first(max), (summary + [''] + shown).first(max)]
  end

  def format_file_line(line, width)
    p = line.split(/\t/)
    if p.size >= 3 && p[0] =~ /^\d+$/
      "#{p[2]} +#{p[0]} -#{p[1]}"
    elsif p.size >= 2
      "#{p[0]}  #{p[1]}"
    else
      line
    end
  end

  def status_line(width)
    text = " #{@repo_name}  #{branch_name}  j/k move  Enter checkout  b branch  f fetch  ? help  q quit"
    text += "  /#{@search}" if @search
    text += "  #{@message}" if @message
    "\e[7m#{fit(text, width)}\e[0m"
  end

  def help_overlay(_cols, _rows)
    "\e[3;5H┌ Help ─────────────────────────────┐" \
      "\e[4;5H│ j/k, arrows: move                 │" \
      "\e[5;5H│ g/G: top/bottom   @: HEAD         │" \
      "\e[6;5H│ Enter: checkout   b: branch       │" \
      "\e[7;5H│ d: delete branch  f: fetch        │" \
      "\e[8;5H│ /: search branch  R: refresh      │" \
      "\e[9;5H│ q/Esc: quit       ?: close help   │" \
      "\e[10;5H└─────────────────────────────────┘"
  end
end

case ARGV
when ['--help'], ['-h']
  print HELP
  exit 0
when ['--version'], ['-V']
  puts VERSION
  exit 0
when []
  App.new.run
else
  warn "error: unexpected argument '#{ARGV.first}' found\n\nUsage: executable\n\nFor more information, try '--help'."
  exit 2
end
