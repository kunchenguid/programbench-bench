#!/usr/bin/env ruby
# frozen_string_literal: true

$stdout.binmode
$stdin.binmode

HELP_LONG = <<~TXT
  A command-line hex viewer

  Usage: executable [OPTIONS] [FILE]

  Arguments:
    [FILE]
            The file to display. If no FILE argument is given, read from STDIN

  Options:
    -n, --length <N>
            Only read N bytes from the input. The N argument can also include a unit with a
            decimal prefix (kB, MB, ..) or binary prefix (kiB, MiB, ..), or can be specified
            using a hex number. The short option '-l' can be used as an alias.
            Examples: --length=64, --length=4KiB, --length=0xff
            
            [aliases: bytes]
            [short aliases: c]

    -s, --skip <N>
            Skip the first N bytes of the input. The N argument can also include a unit (see
            `--length` for details).
            A negative value is valid and will seek from the end of the file.

        --block-size <SIZE>
            Sets the size of the `block` unit to SIZE.
            Examples: --block-size=1024, --block-size=4kB
            
            [default: 512]

    -v, --no-squeezing
            Displays all input data. Otherwise any number of groups of output lines which
            would be identical to the preceding group of lines, are replaced with a line
            comprised of a single asterisk

        --color <WHEN>
            When to use colors
            
            [default: always]

            Possible values:
            - always: Always use colorized output
            - auto:   Only displays colors if the output goes to an interactive terminal
            - never:  Do not use colorized output
            - force:  Override the NO_COLOR environment variable

        --border <STYLE>
            Whether to draw a border
            
            [default: unicode]

            Possible values:
            - unicode: Draw a border with Unicode characters
            - ascii:   Draw a border with ASCII characters
            - none:    Do not draw a border at all

    -p, --plain
            Display output with --no-characters, --no-position, --border=none, and
            --color=never

        --no-characters
            Do not show the character panel on the right

    -C, --characters
            Show the character panel on the right. This is the default, unless
            --no-characters has been specified

        --character-table <FORMAT>
            Defines how bytes are mapped to characters
            
            [default: default]

            Possible values:
            - default:       Show printable ASCII characters as-is, '⋄' for NULL bytes, ' '
              for space, '_' for other ASCII whitespace, '•' for other ASCII characters, and
              '×' for non-ASCII bytes
            - ascii:         Show printable ASCII as-is, ' ' for space, '.' for everything
              else
            - codepage-1047: Show printable EBCDIC as-is, ' ' for space, '.' for everything
              else
            - codepage-437:  Uses code page 437 (for non-ASCII bytes)
            - braille:       Uses braille characters for non-printable bytes

        --color-scheme <FORMAT>
            Defines the color scheme for the characters
            
            [default: default]

            Possible values:
            - default:  Show the default colors: bright black for NULL bytes, green for
              ASCII space characters and non-printable ASCII, cyan for printable ASCII
              characters, and yellow for non-ASCII bytes
            - gradient: Show bright black for NULL bytes, cyan for printable ASCII
              characters, a gradient from pink to violet for non-printable ASCII characters
              and a heatmap-like gradient from red to yellow to white for non-ASCII bytes

    -P, --no-position
            Whether to display the position panel on the left

    -o, --display-offset <N>
            Add N bytes to the displayed file position. The N argument can also include a
            unit (see `--length` for details).
            A negative value is valid and calculates an offset relative to the end of the
            file.
            
            [default: 0]

        --panels <N>
            Sets the number of hex data panels to be displayed. `--panels=auto` will display
            the maximum number of hex data panels based on the current terminal width. By
            default, hexyl will show two panels, unless the terminal is not wide enough for
            that

    -g, --group-size <N>
            Number of bytes/octets that should be grouped together. You can use the
            '--endianness' option to control the ordering of the bytes within a group.
            '--groupsize' can be used as an alias (xxd-compatibility)
            
            [default: 1]

            Possible values:
            - 1: Grouped together every byte/octet
            - 2: Grouped together every 2 bytes/octets
            - 4: Grouped together every 4 bytes/octets
            - 8: Grouped together every 8 bytes/octets

        --endianness <FORMAT>
            Whether to print out groups in little-endian or big-endian format. This option
            only has an effect if the '--group-size' is larger than 1. '-e' can be used as
            an alias for '--endianness=little'
            
            [default: big]

            Possible values:
            - little: Print out groups in little-endian format
            - big:    Print out groups in big-endian format

    -b, --base <B>
            Sets the base used for the bytes. The possible options are binary, octal,
            decimal, and hexadecimal
            
            [default: hexadecimal]

        --terminal-width <N>
            Sets the number of terminal columns to be displayed.
            Since the terminal width may not be an evenly divisible by the width per hex
            data column, this will use the greatest number of hex data panels that can fit
            in the requested width but still leave some space to the right.
            Cannot be used with other width-setting options.

        --print-color-table
            Print a table showing how different types of bytes are colored

    -i, --include
            Output in C include file style

        --completion <SHELL>
            Show shell completion for a certain shell
            
            [possible values: bash, elvish, fish, powershell, zsh]

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
TXT

HELP_SHORT = <<~TXT
  A command-line hex viewer

  Usage: executable [OPTIONS] [FILE]

  Arguments:
    [FILE]  The file to display. If no FILE argument is given, read from STDIN

  Options:
    -n, --length <N>                Only read N bytes from the input. The N argument can
                                    also include a unit with a decimal prefix (kB, MB, ..)
                                    or binary prefix (kiB, MiB, ..), or can be specified
                                    using a hex number. The short option '-l' can be used as
                                    an alias.
                                    Examples: --length=64, --length=4KiB, --length=0xff
                                    [aliases: bytes] [short aliases: c]
    -s, --skip <N>                  Skip the first N bytes of the input. The N argument can
                                    also include a unit (see `--length` for details).
                                    A negative value is valid and will seek from the end of
                                    the file.
        --block-size <SIZE>         Sets the size of the `block` unit to SIZE.
                                    Examples: --block-size=1024, --block-size=4kB [default:
                                    512]
    -v, --no-squeezing              Displays all input data. Otherwise any number of groups
                                    of output lines which would be identical to the
                                    preceding group of lines, are replaced with a line
                                    comprised of a single asterisk
        --color <WHEN>              When to use colors [default: always] [possible values:
                                    always, auto, never, force]
        --border <STYLE>            Whether to draw a border [default: unicode] [possible
                                    values: unicode, ascii, none]
    -p, --plain                     Display output with --no-characters, --no-position,
                                    --border=none, and --color=never
        --no-characters             Do not show the character panel on the right
    -C, --characters                Show the character panel on the right. This is the
                                    default, unless --no-characters has been specified
        --character-table <FORMAT>  Defines how bytes are mapped to characters [default:
                                    default] [possible values: default, ascii,
                                    codepage-1047, codepage-437, braille]
        --color-scheme <FORMAT>     Defines the color scheme for the characters [default:
                                    default] [possible values: default, gradient]
    -P, --no-position               Whether to display the position panel on the left
    -o, --display-offset <N>        Add N bytes to the displayed file position. The N
                                    argument can also include a unit (see `--length` for
                                    details).
                                    A negative value is valid and calculates an offset
                                    relative to the end of the file. [default: 0]
        --panels <N>                Sets the number of hex data panels to be displayed.
                                    `--panels=auto` will display the maximum number of hex
                                    data panels based on the current terminal width. By
                                    default, hexyl will show two panels, unless the terminal
                                    is not wide enough for that
    -g, --group-size <N>            Number of bytes/octets that should be grouped together.
                                    You can use the '--endianness' option to control the
                                    ordering of the bytes within a group. '--groupsize' can
                                    be used as an alias (xxd-compatibility) [default: 1]
                                    [possible values: 1, 2, 4, 8]
        --endianness <FORMAT>       Whether to print out groups in little-endian or
                                    big-endian format. This option only has an effect if the
                                    '--group-size' is larger than 1. '-e' can be used as an
                                    alias for '--endianness=little' [default: big] [possible
                                    values: little, big]
    -b, --base <B>                  Sets the base used for the bytes. The possible options
                                    are binary, octal, decimal, and hexadecimal [default:
                                    hexadecimal]
        --terminal-width <N>        Sets the number of terminal columns to be displayed.
                                    Since the terminal width may not be an evenly divisible
                                    by the width per hex data column, this will use the
                                    greatest number of hex data panels that can fit in the
                                    requested width but still leave some space to the right.
                                    Cannot be used with other width-setting options.
        --print-color-table         Print a table showing how different types of bytes are
                                    colored
    -i, --include                   Output in C include file style
        --completion <SHELL>        Show shell completion for a certain shell [possible
                                    values: bash, elvish, fish, powershell, zsh]
    -h, --help                      Print help (see more with '--help')
    -V, --version                   Print version
TXT

class App
  DIGITS = { 'hexadecimal' => 2, 'hex' => 2, 'binary' => 8, 'octal' => 3, 'decimal' => 3 }.freeze
  CP437 = [
    "⋄", "☺", "☻", "♥", "♦", "♣", "♠", "•", "◘", "○", "◙", "♂", "♀", "♪", "♫", "☼",
    "►", "◄", "↕", "‼", "¶", "§", "▬", "↨", "↑", "↓", "→", "←", "∟", "↔", "▲", "▼",
    " ", "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/",
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ":", ";", "<", "=", ">", "?",
    "@", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O",
    "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "[", "\\", "]", "^", "_",
    "`", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o",
    "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}", "~", "⌂",
    "Ç", "ü", "é", "â", "ä", "à", "å", "ç", "ê", "ë", "è", "ï", "î", "ì", "Ä", "Å",
    "É", "æ", "Æ", "ô", "ö", "ò", "û", "ù", "ÿ", "Ö", "Ü", "¢", "£", "¥", "₧", "ƒ",
    "á", "í", "ó", "ú", "ñ", "Ñ", "ª", "º", "¿", "⌐", "¬", "½", "¼", "¡", "«", "»",
    "░", "▒", "▓", "│", "┤", "╡", "╢", "╖", "╕", "╣", "║", "╗", "╝", "╜", "╛", "┐",
    "└", "┴", "┬", "├", "─", "┼", "╞", "╟", "╚", "╔", "╩", "╦", "╠", "═", "╬", "╧",
    "╨", "╤", "╥", "╙", "╘", "╒", "╓", "╫", "╪", "┘", "┌", "█", "▄", "▌", "▐", "▀",
    "α", "ß", "Γ", "π", "Σ", "σ", "µ", "τ", "Φ", "Θ", "Ω", "δ", "∞", "φ", "ε", "∩",
    "≡", "±", "≥", "≤", "⌠", "⌡", "÷", "≈", "°", "∙", "·", "√", "ⁿ", "²", "■", "ﬀ"
  ].freeze

  def initialize(argv)
    @argv = argv.dup
    @length = nil
    @skip = 0
    @block_size = 512
    @squeeze = true
    @color = 'always'
    @border = 'unicode'
    @characters = true
    @position = true
    @display_offset = 0
    @panels = nil
    @panels_specified = false
    @group_size = 1
    @endianness = 'big'
    @base = 'hexadecimal'
    @terminal_width = 80
    @terminal_width_specified = false
    @include = false
    @char_table = 'default'
    @color_scheme = 'default'
    @file = nil
  end

  def run
    parse!
    bytes, name, total_size = read_input
    @display_offset = total_size + @display_offset if @display_offset.negative? && total_size
    @display_offset = 0 if @display_offset.negative?
    return print_include(bytes, name) if @include

    @panels ||= default_panels
    render(bytes)
  rescue Errno::ENOENT => e
    warn "Error: #{e.message}"
    exit 1
  rescue ArgumentError => e
    warn "error: #{e.message}"
    exit 2
  end

  def take_value(i, arg, opt)
    if arg.include?('=')
      [arg.split('=', 2)[1], i]
    else
      raise ArgumentError, "a value is required for '#{opt} <#{opt.upcase}>' but none was supplied" if i + 1 >= @argv.length
      [@argv[i + 1], i + 1]
    end
  end

  def parse!
    i = 0
    while i < @argv.length
      arg = @argv[i]
      case arg
      when '--help'
        print HELP_LONG
        exit 0
      when '-h'
        print HELP_SHORT
        exit 0
      when '--version', '-V'
        puts 'hexyl 0.16.0'
        exit 0
      when '--print-color-table'
        print "hexyl color reference:\n\n"
        print "\e[90m⋄ NULL bytes (0x00)\n\e[39m"
        print "\e[36ma ASCII printable characters (0x20 - 0x7E)\n\e[39m"
        print "\e[32m_ ASCII whitespace (0x09 - 0x0D, 0x20)\n\e[39m"
        print "\e[32m• ASCII control characters (except NULL and whitespace)\n\e[39m"
        print "\e[33m× Non-ASCII bytes (0x80 - 0xFF)\n\e[39m"
        exit 0
      when '--completion'
        _v, i = take_value(i, arg, 'completion')
        puts '# shell completions are not available in this reimplementation'
        exit 0
      when '-p', '--plain'
        @characters = false
        @position = false
        @border = 'none'
        @color = 'never'
      when '-v', '--no-squeezing'
        @squeeze = false
      when '-C', '--characters'
        @characters = true
      when '--no-characters'
        @characters = false
      when '-P', '--no-position'
        @position = false
      when '-e'
        @endianness = 'little'
      when '-i', '--include'
        @include = true
      when '-n', '-l', '-c', '--length', '--bytes'
        v, i = take_value(i, arg, 'length')
        @length = parse_num(v)
      when /^--length=/, /^--bytes=/
        @length = parse_num(arg.split('=', 2)[1])
      when '-s', '--skip'
        v, i = take_value(i, arg, 'skip')
        @skip = parse_num(v)
      when /^--skip=/
        @skip = parse_num(arg.split('=', 2)[1])
      when '--block-size'
        v, i = take_value(i, arg, 'block-size')
        @block_size = parse_num(v)
      when /^--block-size=/
        @block_size = parse_num(arg.split('=', 2)[1])
      when '--color'
        @color, i = take_value(i, arg, 'color')
      when /^--color=/
        @color = arg.split('=', 2)[1]
      when '--border'
        @border, i = take_value(i, arg, 'border')
      when /^--border=/
        @border = arg.split('=', 2)[1]
      when '-o', '--display-offset'
        v, i = take_value(i, arg, 'display-offset')
        @display_offset = parse_num(v)
        reject_negative_display_offset if @display_offset.negative?
      when /^--display-offset=/
        @display_offset = parse_num(arg.split('=', 2)[1])
        reject_negative_display_offset if @display_offset.negative?
      when '--panels'
        v, i = take_value(i, arg, 'panels')
        @panels_specified = true
        @panels = (v == 'auto' ? nil : Integer(v))
      when /^--panels=/
        v = arg.split('=', 2)[1]
        @panels_specified = true
        @panels = (v == 'auto' ? nil : Integer(v))
      when '-g', '--group-size', '--groupsize'
        v, i = take_value(i, arg, 'group-size')
        @group_size = Integer(v)
      when /^--group-size=/, /^--groupsize=/
        @group_size = Integer(arg.split('=', 2)[1])
      when '--endianness'
        @endianness, i = take_value(i, arg, 'endianness')
      when /^--endianness=/
        @endianness = arg.split('=', 2)[1]
      when '-b', '--base'
        @base, i = take_value(i, arg, 'base')
      when /^--base=/
        @base = arg.split('=', 2)[1]
      when '--terminal-width'
        v, i = take_value(i, arg, 'terminal-width')
        @terminal_width_specified = true
        @terminal_width = Integer(v)
      when /^--terminal-width=/
        @terminal_width_specified = true
        @terminal_width = Integer(arg.split('=', 2)[1])
      when '--character-table'
        @char_table, i = take_value(i, arg, 'character-table')
      when /^--character-table=/
        @char_table = arg.split('=', 2)[1]
      when '--color-scheme'
        @color_scheme, i = take_value(i, arg, 'color-scheme')
      when /^--color-scheme=/
        @color_scheme = arg.split('=', 2)[1]
      when /^-./
        # Support compact xxd-style forms such as -g2 or -l64.
        if arg =~ /^-([glcnsob])(.+)$/
          @argv.insert(i + 1, Regexp.last_match(2))
          @argv[i] = "-#{Regexp.last_match(1)}"
          redo
        end
        raise ArgumentError, "unexpected argument '#{arg}' found"
      else
        raise ArgumentError, "unexpected argument '#{arg}' found" if @file
        @file = arg
      end
      i += 1
    end
    raise ArgumentError, "invalid value '#{@group_size}' for '--group-size <N>'" unless [1, 2, 4, 8].include?(@group_size)
    raise ArgumentError, "the argument '--panels <N>' cannot be used with '--terminal-width <N>'" if @panels_specified && @terminal_width_specified
    @base = 'hexadecimal' if @base == 'hex'
    @base = 'binary' if @base == 'bin'
    @base = 'decimal' if @base == 'dec'
    @base = 'octal' if @base == 'oct'
  end

  def parse_num(s)
    neg = s.start_with?('-')
    t = neg ? s[1..] : s
    number = nil
    suffix = ''
    if t =~ /\A0x[0-9a-fA-F]+\z/
      number = t.to_i(16)
    elsif t =~ /\A(\d+)([A-Za-z]+)?\z/
      number = Regexp.last_match(1).to_i
      suffix = Regexp.last_match(2).to_s
    else
      raise ArgumentError, "invalid digit found in string"
    end
    mult = case suffix
           when '', nil then 1
           when 'b', 'B' then 1
           when 'block', 'blocks' then @block_size
           when 'kB', 'K', 'KB' then 1_000
           when 'MB' then 1_000_000
           when 'GB' then 1_000_000_000
           when 'TB' then 1_000_000_000_000
           when 'KiB', 'Kib', 'kiB', 'kib' then 1024
           when 'MiB' then 1024**2
           when 'GiB' then 1024**3
           when 'TiB' then 1024**4
           else raise ArgumentError, "invalid unit: #{suffix}"
           end
    val = number * mult
    neg ? -val : val
  end

  def reject_negative_display_offset
    raise ArgumentError, 'failed to parse `--display-offset` arg as byte count'
  end

  def read_input
    if @file
      data = File.binread(@file)
      name = File.basename(@file).gsub(/[^A-Za-z0-9_]/, '_')
    else
      data = STDIN.read
      name = nil
    end
    total = data.bytesize
    start = @skip.negative? ? [total + @skip, 0].max : @skip
    @input_start = start
    data = start >= total ? ''.b : data.byteslice(start, total - start)
    data = data.byteslice(0, @length) || ''.b if @length
    [data.bytes, name, total]
  end

  def print_include(bytes, name)
    if name
      puts "unsigned char #{name}[] = {"
    end
    bytes.each_slice(12).with_index do |slice, idx|
      line = '  ' + slice.map { |b| format('0x%02x', b) }.join(', ')
      line += ',' if idx < ((bytes.length - 1) / 12)
      puts line
    end
    if name
      puts '};'
      puts "unsigned int #{name}_len = #{bytes.length};"
    end
  end

  def digit_width
    DIGITS.fetch(@base, 2)
  end

  def panel_width
    groups = 8 / @group_size
    groups * digit_width * @group_size + (groups - 1) + 2
  end

  def default_panels
    max = 1
    (1..8).each do |n|
      max = n if total_width(n) <= @terminal_width
    end
    [max, 2].min
  end

  def total_width(n)
    widths = []
    widths << 8 if @position
    n.times { widths << panel_width }
    n.times { widths << 8 } if @characters
    if @border == 'none'
      total = @position ? 10 : 1
      total += n * panel_width + [n - 1, 0].max
      total += 1 + n * 8 + [n - 1, 0].max if @characters
      total + 1
    else
      widths.sum + widths.length + 1
    end
  end

  def value_token(group)
    arr = group.dup
    arr.reverse! if @endianness == 'little'
    case @base
    when 'binary'
      arr.map { |b| format('%08b', b) }.join
    when 'octal'
      arr.map { |b| format('%03o', b) }.join
    when 'decimal'
      arr.map { |b| format('%03d', b) }.join
    else
      arr.map { |b| format('%02x', b) }.join
    end
  end

  def panel_bytes_to_hex(bytes)
    groups = bytes.each_slice(@group_size).map { |g| value_token(g) }
    groups_count = 8 / @group_size
    token_w = digit_width * @group_size
    out = groups.each_with_index.map { |g, _| g.ljust(token_w) }.join(' ')
    out = out.ljust(groups_count * token_w + groups_count - 1)
    " #{out} "
  end

  def char_for_byte(b)
    case @char_table
    when 'ascii', 'codepage-1047'
      (b >= 0x21 && b <= 0x7e) || b == 0x20 ? b.chr : '.'
    when 'codepage-437'
      CP437[b] || '.'
    when 'braille'
      return '⋄' if b == 0
      return ' ' if b == 0x20
      return '→' if b == 0x09
      return '↵' if b == 0x0a
      return b.chr if b >= 0x21 && b <= 0x7e
      bits = [1, 2, 8, 16, 4, 32, 64, 128]
      pattern = 0
      8.times { |i| pattern |= bits[i] if (b & (1 << i)) != 0 }
      (0x2800 + pattern).chr(Encoding::UTF_8)
    else
      if b == 0
        '⋄'
      elsif b == 0x20
        ' '
      elsif b == 0x09 || b == 0x0a || b == 0x0b || b == 0x0c || b == 0x0d
        '_'
      elsif b >= 0x21 && b <= 0x7e
        b.chr
      elsif b < 0x80
        '•'
      else
        '×'
      end
    end
  end

  def color_code(b)
    return nil unless colored?
    return "\e[90m" if b.nil? || b == :offset || b == 0
    return "\e[32m" if b == 0x20 || (b < 0x80 && !(b >= 0x21 && b <= 0x7e))
    return "\e[36m" if b < 0x80
    "\e[33m"
  end

  def colored?
    return false if @color == 'never'
    return false if @color == 'auto' && !$stdout.tty?
    return false if ENV['NO_COLOR'] && @color != 'force'
    true
  end

  def colorize(s, b)
    c = color_code(b)
    c ? "#{c}#{s}" : s
  end

  def panel_bytes_to_chars(bytes)
    out = bytes.map { |b| colorize(char_for_byte(b), b) }.join
    out + (' ' * (8 - bytes.length))
  end

  def border_line(left, mid, right, widths)
    left + widths.map { |w| '─' * w }.join(mid) + right
  end

  def ascii_border_line(widths)
    '+' + widths.map { |w| '-' * w }.join('+') + '+'
  end

  def widths
    arr = []
    arr << 8 if @position
    @panels.times { arr << panel_width }
    @panels.times { arr << 8 } if @characters
    arr
  end

  def top_line
    return nil if @border == 'none'
    @border == 'ascii' ? ascii_border_line(widths) : border_line('┌', '┬', '┐', widths)
  end

  def bottom_line
    return nil if @border == 'none'
    @border == 'ascii' ? ascii_border_line(widths) : border_line('└', '┴', '┘', widths)
  end

  def row_line(offset, row)
    parts = []
    parts << colorize(format('%08x', offset + (@input_start || 0) + @display_offset), :offset) if @position
    panel_chunks = row.each_slice(8).to_a
    panel_chunks << [] while panel_chunks.length < @panels
    hexes = panel_chunks.first(@panels).map { |chunk| panel_bytes_to_hex(chunk) }
    chars = @characters ? panel_chunks.first(@panels).map { |chunk| panel_bytes_to_chars(chunk) } : []

    if @border == 'none'
      s = +''
      if @position
        s << " #{parts[0]} "
      else
        s << ' '
      end
      s << hexes.join(' ')
      if @characters
        s << ' '
        s << chars.join(' ')
      end
      s << ' '
      return reset_colors(s)
    end

    sep = @border == 'ascii' ? '|' : '│'
    soft = @border == 'ascii' ? '|' : '┊'
    body = +''
    body << sep
    body << parts[0] << sep if @position
    body << hexes.join(soft)
    body << sep
    body << chars.join(soft) << sep if @characters
    reset_colors(body)
  end

  def star_line
    empty_row = []
    line = row_line(0, empty_row)
    if @border == 'none'
      line.sub(/^ \h{8}/, ' *       ')
    else
      line.sub(/([│|])(?:\e\[[0-9;]+m)?00000000(?:\e\[[0-9;]+m)?([│|])/, "\\1*       \\2")
    end
  end

  def reset_colors(s)
    colored? ? "#{s}\e[39m" : s
  end

  def render(bytes)
    puts top_line if top_line
    per_row = @panels * 8
    if bytes.empty?
      puts no_content_line
      puts bottom_line if bottom_line
      return
    end
    rows = []
    (0...bytes.length).step(per_row) { |i| rows << [i, bytes[i, per_row]] }
    prev_full = nil
    squeezed = false
    ended_squeezed = false
    rows.each_with_index do |(off, row), idx|
      full = row.length == per_row
      comparable = full ? row : nil
      if @squeeze && idx.positive? && full && comparable == prev_full
        unless squeezed
          puts star_line
          squeezed = true
        end
        ended_squeezed = true
        next
      end
      puts row_line(off, row)
      squeezed = false
      ended_squeezed = false
      prev_full = comparable if comparable
    end
    puts row_line(bytes.length, []) if ended_squeezed
    puts bottom_line if bottom_line
  end

  def no_content_line
    fields = []
    fields << (' ' * 8) if @position
    @panels.times do |i|
      fields << (i.zero? ? ' No content'.ljust(panel_width) : ' ' * panel_width)
    end
    @panels.times { fields << (' ' * 8) } if @characters
    '│' + fields.join('│') + '│'
  end
end

App.new(ARGV).run
