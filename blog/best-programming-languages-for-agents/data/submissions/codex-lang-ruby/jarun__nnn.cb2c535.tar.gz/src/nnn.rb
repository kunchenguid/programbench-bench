#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'

HELP_TEXT = <<~TEXT
  usage: nnn [OPTIONS] [PATH]

  The unorthodox terminal file manager.

  positional args:
    PATH   start dir/file [default: .]

  optional args:
   -a      auto NNN_FIFO
   -A      no dir auto-enter during filter
   -b key  open bookmark key (trumps -s/S)
   -B      use bsdtar for archives
   -c      cli-only NNN_OPENER (trumps -e)
   -C      8-color scheme
   -d      detail mode
   -D      dirs in context color
   -e      text in $VISUAL/$EDITOR/vi
   -E      internal edits in EDITOR
   -f      use history file
   -F val  fifo mode [0:preview 1:explore]
   -g      regex filters
   -H      show hidden files
   -i      show current file info
   -J      no auto-advance on selection
   -K      detect key collision and exit
   -l val  set scroll lines
   -n      type-to-nav mode
   -N      use native prompt
   -o      open files only on Enter
   -p file selection file [-:stdout]
   -P key  run plugin key
   -Q      no quit confirmation
   -r      use advcpmv patched cp, mv
   -R      no rollover at edges
   -s name load session by name
   -S      persistent session
   -t secs timeout to lock
   -T key  sort order [a/d/e/r/s/t/v]
   -u      use selection (no prompt)
   -U      show user and group
   -V      show version
   -x      notis, selection sync, xterm title
   -z      in order fuzzy filters
   -0      null separator in picker mode
   -h      show help

  v5.2
  BSD 2-Clause
  https://github.com/jarun/nnn
TEXT

NO_ARG_OPTIONS = 'aABcCdDeEfgHiJKnNoQrRSuUVxz0h'
ARG_OPTIONS = {
  'b' => :bookmark,
  'F' => :fifo_mode,
  'l' => :scroll_lines,
  'p' => :selection_file,
  'P' => :plugin_key,
  's' => :session,
  't' => :timeout,
  'T' => :sort_order
}.freeze
VALID_SORTS = %w[a d e r s t v].freeze

def usage_with_error(message = nil)
  warn message if message
  $stdout.write(HELP_TEXT)
end

def parse_args(argv)
  opts = { flags: {}, args: [] }
  i = 0

  while i < argv.length
    arg = argv[i]
    if arg == '--'
      opts[:args].concat(argv[(i + 1)..] || [])
      break
    elsif arg.start_with?('-') && arg != '-'
      chars = arg[1..].chars
      chars.each_with_index do |ch, idx|
        if ARG_OPTIONS.key?(ch)
          value = nil
          rest = chars[(idx + 1)..]&.join.to_s
          if !rest.empty?
            value = rest
          elsif i + 1 < argv.length
            i += 1
            value = argv[i]
          else
            return [:error, "option requires an argument -- '#{ch}'"]
          end
          opts[ARG_OPTIONS[ch]] = value
          break
        elsif NO_ARG_OPTIONS.include?(ch)
          opts[:flags][ch] = true
        else
          return [:error, "invalid option -- '#{ch}'"]
        end
      end
    else
      opts[:args] << arg
    end
    i += 1
  end

  [:ok, opts]
end

def visible_entries(path, show_hidden)
  dir = File.directory?(path) ? path : File.dirname(path)
  Dir.children(dir).select { |name| show_hidden || !name.start_with?('.') }.sort
rescue SystemCallError
  []
end

def prepare_path(path)
  return path if File.exist?(path)

  if path.end_with?(File::SEPARATOR)
    FileUtils.mkdir_p(path)
    path
  else
    parent = File.dirname(path)
    FileUtils.mkdir_p(parent) unless parent == '.' || Dir.exist?(parent)
    parent
  end
rescue SystemCallError
  path
end

def write_selection(opts, path)
  target = opts[:selection_file]
  return unless target

  sep = opts[:flags]['0'] ? "\0" : "\n"
  selection = File.expand_path(path) + sep
  if target == '-'
    $stdout.write(selection)
  else
    File.write(target, selection)
  end
rescue SystemCallError => e
  warn e.message
end

status, result = parse_args(ARGV)
if status == :error
  usage_with_error("#{$PROGRAM_NAME}: #{result}")
  exit 1
end

opts = result

if opts[:flags]['V']
  puts '5.2'
  exit 0
end

if opts[:flags]['h']
  $stdout.write(HELP_TEXT)
  exit 0
end

if opts[:fifo_mode] && opts[:fifo_mode].to_i >= 2 && opts[:fifo_mode] =~ /\A\d+\z/
  exit 1
end

path = opts[:args].first || '.'
path = prepare_path(path)
write_selection(opts, path)

entries = visible_entries(path, opts[:flags]['H'])

if $stdout.tty? && $stdin.tty?
  puts File.expand_path(path)
  entries.each { |entry| puts entry }
else
  warn "#{entries.length} entries"
end

exit 0
