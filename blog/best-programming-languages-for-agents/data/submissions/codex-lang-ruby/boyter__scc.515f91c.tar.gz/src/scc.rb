#!/usr/bin/env ruby
# frozen_string_literal: true

require 'set'

VERSION = '3.7.0'
DEFAULT_EXCLUDE_DIRS = %w[.git .hg .svn].freeze
DEFAULT_EXCLUDE_FILES = %w[package-lock.json Cargo.lock yarn.lock pubspec.lock Podfile.lock pnpm-lock.yaml].freeze
BORDER = '─' * 79
BORDER_WIDE = '─' * 109
ASCII_BORDER = '-' * 79

LANGUAGE_TEXT = DATA.read
LANGUAGE_LINES = LANGUAGE_TEXT.lines.map(&:strip).reject(&:empty?)

Lang = Struct.new(:name, :tokens)
LANGS = LANGUAGE_LINES.map do |line|
  if line =~ /\A(.+) \((.*)\)\z/
    Lang.new($1, $2.split(',').map(&:strip))
  end
end.compact

EXT_MAP = {}
NAME_MAP = {}
LANGS.each do |lang|
  lang.tokens.each do |tok|
    key = tok.downcase
    if key.include?('.') || !key.include?('.')
      EXT_MAP[key] ||= lang.name
    end
  end
end
# Observed precedence and useful filename/suffix corrections.
%w[json].each { |e| EXT_MAP[e] = 'JSON' }
%w[yaml yml].each { |e| EXT_MAP[e] = 'YAML' }
EXT_MAP['tex'] = 'TeX'
EXT_MAP['m'] = 'Objective C'
EXT_MAP['v'] = 'Verilog'
EXT_MAP['heex'] = 'Phoenix LiveView'
EXT_MAP['d.ts'] = 'TypeScript Typings'
EXT_MAP['tf.json'] = 'Terraform'
EXT_MAP['dockerfile'] = 'Dockerfile'
EXT_MAP['makefile'] = 'Makefile'
EXT_MAP['gnumakefile'] = 'Makefile'
EXT_MAP['rakefile'] = 'Rakefile'
EXT_MAP['gemfile'] = 'Gemfile'
EXT_MAP['jenkinsfile'] = 'Jenkins Buildfile'
EXT_MAP['justfile'] = 'Just'
EXT_MAP['snakefile'] = 'Snakemake'
LANGS.each { |l| NAME_MAP[l.name.downcase] = l.name }

SLASH_BLOCK_LANGS = Set.new(%w[C C\ Header C++ C++\ Header C# Java JavaScript JSX TypeScript TypeScript\ Typings CSS SCSS Sass Go Rust PHP Swift Kotlin Scala Dart Objective\ C Objective\ C++ SQL HTML XML XHTML SVG Vue Svelte Astro JSON JSON5 JSONC Terraform Verilog SystemVerilog VHDL])
HASH_LANGS = Set.new(['Ruby','Python','BASH','Shell','Zsh','Korn Shell','C Shell','Perl','R','YAML','TOML','Dockerfile','Makefile','Rakefile','Gemfile','Nim','Elixir','Crystal','Julia','PowerShell','Powershell','Fish','AWK','TCL','Terraform','HCL'])
DASH_LANGS = Set.new(['SQL','Haskell','Lua','Elm','Ada'])
SEMICOLON_LANGS = Set.new(['Assembly','INI'])
HTML_LANGS = Set.new(['HTML','XML','XHTML','SVG','Vue','Svelte','Astro','Markdown','Ruby HTML','JavaServer Pages','ASP.NET'])
TRIPLE_QUOTE_LANGS = Set.new(['Python'])
COMPLEXITY_WORDS = /\b(if|for|while|case|catch|switch|elsif|elif|else if|when|unless|until|foreach|loop|guard|match|try|except|rescue|&&|\|\|)\b|[?]/

Stats = Struct.new(:name, :bytes, :lines, :code, :comment, :blank, :complexity, :count, :files, :uloc, :max_line, :sum_line) do
  def initialize(name)
    super(name, 0, 0, 0, 0, 0, 0, 0, [], 0, 0, 0)
  end
end
FileStats = Struct.new(:name, :path, :bytes, :lines, :code, :comment, :blank, :complexity, :uloc, :max_line, :sum_line)

class Options
  attr_accessor :format, :paths, :by_file, :no_cocomo, :no_size, :no_complexity, :sort,
                :include_ext, :exclude_ext, :exclude_dirs, :exclude_files, :output,
                :languages, :help, :version, :uloc, :dryness, :character, :wide,
                :percent, :ci, :count_as, :no_duplicates, :include_symlinks,
                :count_ignore, :no_gitignore, :no_ignore, :no_sccignore, :no_hborder,
                :avg_wage, :currency_symbol, :cocomo_type, :eaf, :overhead,
                :format_multi, :remap_unknown, :remap_all, :not_match, :sql_project,
                :locomo, :cost_comparison
  def initialize
    @format = 'tabular'; @paths = []; @by_file = false; @no_cocomo = false; @no_size = false
    @no_complexity = false; @sort = 'files'; @include_ext = nil; @exclude_ext = []
    @exclude_dirs = DEFAULT_EXCLUDE_DIRS.dup; @exclude_files = DEFAULT_EXCLUDE_FILES.dup
    @output = nil; @languages = false; @help = false; @version = false; @uloc = false
    @dryness = false; @character = false; @wide = false; @percent = false; @ci = false
    @count_as = {}; @no_duplicates = false; @include_symlinks = false; @count_ignore = false
    @no_gitignore = false; @no_ignore = false; @no_sccignore = false; @no_hborder = false
    @avg_wage = 56_286; @currency_symbol = '$'; @cocomo_type = 'organic'; @eaf = 1.0; @overhead = 2.4
    @format_multi = nil; @remap_unknown = {}; @remap_all = {}; @not_match = []; @sql_project = nil
    @locomo = false; @cost_comparison = false
  end
end

def take_arg(args, i, flag)
  val = args[i].split('=', 2)[1]
  return [val, i] if val
  raise "flag needs an argument: #{flag}" if i + 1 >= args.length
  [args[i + 1], i + 1]
end

def split_csv(s)
  s.to_s.split(',').map(&:strip).reject(&:empty?)
end

def parse_args(argv)
  opt = Options.new
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when '-h', '--help' then opt.help = true
    when '--version' then opt.version = true
    when '-l', '--languages' then opt.languages = true
    when '--by-file' then opt.by_file = true
    when '-c', '--no-complexity' then opt.no_complexity = true
    when '--no-cocomo' then opt.no_cocomo = true
    when '--no-size' then opt.no_size = true
    when '-u', '--uloc' then opt.uloc = true
    when '-a', '--dryness' then opt.dryness = true; opt.uloc = true
    when '-m', '--character' then opt.character = true
    when '-w', '--wide' then opt.wide = true
    when '-p', '--percent' then opt.percent = true
    when '--ci' then opt.ci = true
    when '-d', '--no-duplicates' then opt.no_duplicates = true
    when '--include-symlinks' then opt.include_symlinks = true
    when '--count-ignore' then opt.count_ignore = true
    when '--no-gitignore' then opt.no_gitignore = true
    when '--no-ignore' then opt.no_ignore = true
    when '--no-scc-ignore' then opt.no_sccignore = true
    when '--no-hborder' then opt.no_hborder = true
    when '--locomo' then opt.locomo = true
    when '--cost-comparison' then opt.cost_comparison = true
    when /^(-f|--format)(=|$)/
      v, i = take_arg(argv, i, a); opt.format = v
    when /^--format-multi(=|$)/
      v, i = take_arg(argv, i, a); opt.format_multi = v
    when /^(-o|--output)(=|$)/
      v, i = take_arg(argv, i, a); opt.output = v
    when /^(--sort|-s)(=|$)/
      v, i = take_arg(argv, i, a); opt.sort = v
    when /^(-i|--include-ext)(=|$)/
      v, i = take_arg(argv, i, a); opt.include_ext = split_csv(v).map { |x| x.sub(/^\./,'').downcase }
    when /^(-x|--exclude-ext)(=|$)/
      v, i = take_arg(argv, i, a); opt.exclude_ext += split_csv(v).map { |x| x.sub(/^\./,'').downcase }
    when /^(-n|--exclude-file)(=|$)/
      v, i = take_arg(argv, i, a); opt.exclude_files += split_csv(v)
    when /^--exclude-dir(=|$)/
      v, i = take_arg(argv, i, a); opt.exclude_dirs = split_csv(v)
    when /^--count-as(=|$)/
      v, i = take_arg(argv, i, a)
      split_csv(v).each do |pair|
        k, val = pair.split(':', 2); next unless k && val
        opt.count_as[k.sub(/^\./,'').downcase] = resolve_lang(val.delete('"')) || val.delete('"')
      end
    when /^--remap-unknown(=|$)/
      v, i = take_arg(argv, i, a); opt.remap_unknown.merge!(parse_remap(v))
    when /^--remap-all(=|$)/
      v, i = take_arg(argv, i, a); opt.remap_all.merge!(parse_remap(v))
    when /^(-M|--not-match)(=|$)/
      v, i = take_arg(argv, i, a); opt.not_match << Regexp.new(v) rescue nil
    when /^--avg-wage(=|$)/
      v, i = take_arg(argv, i, a); opt.avg_wage = v.to_i
    when /^--currency-symbol(=|$)/
      v, i = take_arg(argv, i, a); opt.currency_symbol = v
    when /^--cocomo-project-type(=|$)/
      v, i = take_arg(argv, i, a); opt.cocomo_type = v
    when /^--eaf(=|$)/
      v, i = take_arg(argv, i, a); opt.eaf = v.to_f
    when /^--overhead(=|$)/
      v, i = take_arg(argv, i, a); opt.overhead = v.to_f
    when /^--sql-project(=|$)/
      v, i = take_arg(argv, i, a); opt.sql_project = v
    when /^--(directory-walker-job-workers|file-gc-count|file-list-queue-size|file-process-job-workers|file-summary-job-queue-size|large-byte-count|large-line-count|min-gen-line-length|locomo-config|locomo-cycles|locomo-input-price|locomo-output-price|locomo-preset|locomo-review|locomo-tps|size-unit)(=|$)/
      _v, i = take_arg(argv, i, a)
    when '--binary','--debug','--trace','--verbose','--gen','--min','--min-gen','--no-gen','--no-min','--no-min-gen','--no-min-gen-ignore','--no-large','--sloccount-format','--size-unit-binary','--size-unit-mixed','--size-unit-xkcd','--size-unit-si','--mcp'
      # accepted no-op or implied filters not critical for normal counting
    else
      if a.start_with?('-') && a.length > 2 && !a.start_with?('--')
        a[1..].chars.each { |ch| argv.insert(i + 1, "-#{ch}") }
      else
        opt.paths << a
      end
    end
    i += 1
  end
  opt.paths = ['.'] if opt.paths.empty?
  opt
rescue => e
  warn "Error: #{e.message}"
  exit 1
end

def parse_remap(s)
  h = {}
  split_csv(s).each do |pair|
    k, v = pair.split(':', 2); next unless k && v
    h[k.delete('"')] = resolve_lang(v.delete('"')) || v.delete('"')
  end
  h
end

def resolve_lang(name)
  return nil if name.nil?
  NAME_MAP[name.downcase] || EXT_MAP[name.sub(/^\./,'').downcase] || NAME_MAP[name.tr('_',' ').downcase]
end

def help_text
  <<~TXT
    Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.
    Version #{VERSION}
    Ben Boyter <ben@boyter.org> + Contributors

    Usage:
      scc [flags] [files or directories]

    Flags:
          --avg-wage int                       average wage value used for basic COCOMO calculation (default 56286)
          --binary                             disable binary file detection
          --by-file                            display output for every file
      -m, --character                          calculate max and mean characters per line
          --ci                                 enable CI output settings where stdout is ASCII
          --cocomo-project-type string         change COCOMO model type [organic, semi-detached, embedded, "custom,1,1,1,1"] (default "organic")
          --cost-comparison                    show both COCOMO and LOCOMO estimates side by side
          --count-as string                    count extension as language [e.g. jsp:htm,chead:"C Header" maps extension jsp to html and chead to C Header]
          --count-ignore                       set to allow .gitignore and .ignore files to be counted
          --currency-symbol string             set currency symbol (default "$"")
          --debug                              enable debug output
      -a, --dryness                            calculate the DRYness of the project (implies --uloc)
          --eaf float                          the effort adjustment factor derived from the cost drivers (1.0 if rated nominal) (default 1)
          --exclude-dir strings                directories to exclude (default [.git,.hg,.svn])
      -x, --exclude-ext strings                ignore file extensions (overrides include-ext) [comma separated list: e.g. go,java,js]
      -n, --exclude-file strings               ignore files with matching names (default [package-lock.json,Cargo.lock,yarn.lock,pubspec.lock,Podfile.lock,pnpm-lock.yaml])
      -f, --format string                      set output format [tabular, wide, json, json2, csv, csv-stream, cloc-yaml, html, html-table, sql, sql-insert, openmetrics] (default "tabular")
      -h, --help                               help for scc
      -i, --include-ext strings                limit to file extensions [comma separated list: e.g. go,java,js]
      -l, --languages                          print supported languages and extensions
          --locomo                             enable LOCOMO (LLM Output COst MOdel) cost estimation
      -c, --no-complexity                      skip calculation of code complexity
      -d, --no-duplicates                      remove duplicate files from stats and output
      -o, --output string                      output filename (default stdout)
      -p, --percent                            include percentage values in output
      -s, --sort string                        column to sort by [files, name, lines, blanks, code, comments, complexity] (default "files")
      -u, --uloc                               calculate the number of unique lines of code (ULOC) for the project
          --version                            version for scc
      -w, --wide                               wider output with additional statistics (implies --complexity)
  TXT
end

def lang_for(path, opt)
  base = File.basename(path)
  lower = base.downcase
  return nil if opt.exclude_files.include?(base) && !opt.count_ignore
  return nil if !opt.count_ignore && %w[.gitignore .ignore .sccignore].include?(lower)
  ext_parts = lower.split('.')
  candidates = []
  (0...ext_parts.length).each { |idx| candidates << ext_parts[idx..].join('.') if idx > 0 }
  candidates << lower
  candidates.sort_by! { |c| -c.length }
  ext_key = candidates.find { |c| opt.count_as.key?(c) || EXT_MAP.key?(c) }
  simple_ext = ext_parts.length > 1 ? ext_parts[-1] : lower
  return nil if opt.include_ext && !opt.include_ext.include?(simple_ext) && !opt.include_ext.include?(ext_key)
  return nil if opt.exclude_ext.include?(simple_ext) || opt.exclude_ext.include?(ext_key)
  lang = opt.count_as[ext_key] || EXT_MAP[ext_key]
  lang ||= shebang_lang(path)
  lang
end

def shebang_lang(path)
  first = File.open(path, 'rb') { |f| f.readline rescue '' }
  return nil unless first.start_with?('#!')
  return 'Ruby' if first.include?('ruby')
  return 'Python' if first.include?('python')
  return 'Perl' if first.include?('perl')
  return 'BASH' if first.include?('bash')
  return 'Shell' if first.include?('sh')
  nil
end

def binary?(path)
  chunk = File.open(path, 'rb') { |f| f.read(4096) } || ''
  chunk.include?("\x00")
rescue
  true
end

def read_ignore_patterns(dir, opt)
  pats = []
  [['.gitignore', opt.no_gitignore], ['.ignore', opt.no_ignore], ['.sccignore', opt.no_sccignore]].each do |name, disabled|
    next if disabled || opt.count_ignore
    f = File.join(dir, name)
    next unless File.file?(f)
    File.readlines(f, chomp: true).each do |line|
      line = line.strip
      next if line.empty? || line.start_with?('#') || line.start_with?('!')
      pats << line.sub(%r{\A/}, '')
    end
  rescue
  end
  pats
end

def ignored_by_patterns?(rel, base, patterns)
  patterns.any? do |p|
    p = p.chomp('/')
    File.fnmatch?(p, rel, File::FNM_PATHNAME | File::FNM_DOTMATCH) || File.fnmatch?(p, base, File::FNM_DOTMATCH) || rel.start_with?(p + '/')
  end
end

def collect_files(paths, opt)
  files = []
  seen = Set.new
  paths.each do |p|
    next unless File.exist?(p)
    if File.file?(p) || (File.symlink?(p) && opt.include_symlinks)
      files << p
      next
    end
    next unless File.directory?(p)
    root = File.expand_path(p)
    stack = [[root, read_ignore_patterns(root, opt)]]
    until stack.empty?
      dir, patterns = stack.pop
      Dir.children(dir).sort.each do |child|
        path = File.join(dir, child)
        rel = path.sub(root + '/', '')
        next if opt.not_match.any? { |r| r.match?(path) || r.match?(rel) }
        if File.directory?(path) && (!File.symlink?(path) || opt.include_symlinks)
          next if opt.exclude_dirs.include?(child)
          next if ignored_by_patterns?(rel, child, patterns)
          stack << [path, patterns + read_ignore_patterns(path, opt)]
        elsif File.file?(path) || (File.symlink?(path) && opt.include_symlinks)
          next if ignored_by_patterns?(rel, child, patterns)
          real = begin
            File.realpath(path)
          rescue
            path
          end
          files << path unless seen.include?(real)
          seen << real
        end
      end
    end
  end
  files
end

def strip_inline_comments(line, lang)
  s = line.dup
  if HTML_LANGS.include?(lang)
    s = s.gsub(/<!--.*?-->/, '')
  end
  if SLASH_BLOCK_LANGS.include?(lang) || HTML_LANGS.include?(lang)
    s = s.gsub(%r{/\*.*?\*/}, '')
    s = s.sub(%r{//.*}, '') unless lang == 'URL'
  end
  s = s.sub(/#.*/, '') if HASH_LANGS.include?(lang)
  s = s.sub(/--.*/, '') if DASH_LANGS.include?(lang)
  s
end

def analyze_file(path, lang)
  content = File.binread(path)
  fs = FileStats.new(File.basename(path), path, content.bytesize, 0, 0, 0, 0, 0, 0, 0, 0)
  lines = content.each_line.to_a
  fs.lines = lines.length
  block = false
  py_triple = nil
  ulines = Set.new
  lines.each do |raw|
    line = raw.chomp("\n").chomp("\r")
    len = line.length
    fs.max_line = [fs.max_line, len].max
    fs.sum_line += len
    stripped = line.strip
    if stripped.empty?
      fs.blank += 1
      next
    end

    comment_line = false
    code_line = false
    s = stripped.dup

    if py_triple
      fs.comment += 1
      py_triple = nil if s.include?(py_triple)
      next
    end

    if block
      fs.comment += 1
      if HTML_LANGS.include?(lang)
        block = false if s.include?('-->')
      else
        block = false if s.include?('*/')
      end
      rest = s.split(HTML_LANGS.include?(lang) ? '-->' : '*/', 2)[1].to_s.strip
      if !block && !rest.empty?
        fs.code += 1
        fs.complexity += rest.scan(COMPLEXITY_WORDS).length unless lang =~ /Markdown|JSON|YAML|XML|HTML|CSS/
        ulines << rest
      end
      next
    end

    if TRIPLE_QUOTE_LANGS.include?(lang) && (s.start_with?("'''") || s.start_with?('"""'))
      delim = s[0,3]
      fs.comment += 1
      py_triple = delim unless s[3..].to_s.include?(delim)
      next
    end

    if HTML_LANGS.include?(lang) && s.start_with?('<!--')
      fs.comment += 1
      block = true unless s.include?('-->')
      rest = s.split('-->', 2)[1].to_s.strip
      if !block && !rest.empty?
        fs.code += 1; ulines << rest
      end
      next
    end

    if (SLASH_BLOCK_LANGS.include?(lang) || HTML_LANGS.include?(lang)) && s.start_with?('/*')
      fs.comment += 1
      block = true unless s.include?('*/')
      rest = s.split('*/', 2)[1].to_s.strip
      if !block && !rest.empty?
        fs.code += 1; ulines << rest
      end
      next
    end

    if HASH_LANGS.include?(lang) && s.start_with?('#')
      fs.comment += 1; next
    end
    if (SLASH_BLOCK_LANGS.include?(lang) || lang =~ /JavaScript|TypeScript|C\+\+|C#|Java|Go|Rust|Swift|Kotlin|Scala|Dart/) && s.start_with?('//')
      fs.comment += 1; next
    end
    if DASH_LANGS.include?(lang) && s.start_with?('--')
      fs.comment += 1; next
    end
    if SEMICOLON_LANGS.include?(lang) && s.start_with?(';')
      fs.comment += 1; next
    end

    if (SLASH_BLOCK_LANGS.include?(lang) || HTML_LANGS.include?(lang)) && s.include?('/*') && !s.include?('*/')
      before = s.split('/*', 2)[0].strip
      code_line = !before.empty?
      comment_line = true
      block = true
    elsif HTML_LANGS.include?(lang) && s.include?('<!--') && !s.include?('-->')
      before = s.split('<!--', 2)[0].strip
      code_line = !before.empty?
      comment_line = true
      block = true
    else
      code_line = true
      stripped_code = strip_inline_comments(s, lang).strip
      if stripped_code.empty?
        comment_line = true
        code_line = false
      end
    end

    fs.comment += 1 if comment_line && !code_line
    if code_line
      fs.code += 1
      code = strip_inline_comments(s, lang).strip
      fs.complexity += code.scan(COMPLEXITY_WORDS).length unless lang =~ /Markdown|JSON|YAML|XML|HTML|CSS|Plain Text|CSV|License/
      ulines << code unless code.empty?
    end
  end
  fs.uloc = ulines.length
  fs
rescue
  nil
end

def apply_remap(path, lang, opt)
  return lang if opt.remap_all.empty? && (lang || opt.remap_unknown.empty?)
  text = File.open(path, 'rb') { |f| f.read(8192) } rescue ''
  opt.remap_all.each { |needle, l| return l if text.include?(needle) }
  if lang.nil?
    opt.remap_unknown.each { |needle, l| return l if text.include?(needle) }
  end
  lang
end

def compute(paths, opt)
  files = collect_files(paths, opt)
  summaries = {}
  fingerprints = Set.new
  files.each do |path|
    next if binary?(path)
    lang = lang_for(path, opt)
    lang = apply_remap(path, lang, opt)
    next unless lang
    content_hash = nil
    if opt.no_duplicates
      content_hash = File.binread(path).hash rescue nil
      next if content_hash && fingerprints.include?(content_hash)
      fingerprints << content_hash if content_hash
    end
    fs = analyze_file(path, lang)
    next unless fs
    st = summaries[lang] ||= Stats.new(lang)
    st.bytes += fs.bytes; st.lines += fs.lines; st.code += fs.code; st.comment += fs.comment; st.blank += fs.blank
    st.complexity += fs.complexity unless opt.no_complexity
    st.count += 1; st.files << fs; st.uloc += fs.uloc; st.max_line = [st.max_line, fs.max_line].max; st.sum_line += fs.sum_line
  end
  summaries.values
end

def sort_stats(stats, sort)
  stats.sort_by do |s|
    case sort
    when 'name' then [s.name]
    when 'lines' then [-s.lines, s.name]
    when 'blanks' then [-s.blank, s.name]
    when 'code' then [-s.code, s.name]
    when 'comments' then [-s.comment, s.name]
    when 'complexity' then [-s.complexity, s.name]
    else [-s.count, s.name]
    end
  end
end

def totals(stats)
  t = Stats.new('Total')
  stats.each do |s|
    t.bytes += s.bytes; t.lines += s.lines; t.blank += s.blank; t.comment += s.comment; t.code += s.code
    t.complexity += s.complexity; t.count += s.count; t.uloc += s.uloc; t.max_line = [t.max_line, s.max_line].max; t.sum_line += s.sum_line
  end
  t
end

def fmt_num(n)
  return n.to_s unless n.is_a?(Numeric) || n.to_s =~ /\A-?\d+\z/
  n.to_i.to_s.reverse.gsub(/(\d{3})(?=\d)/, '\\1,').reverse
end

def trunc(s, width)
  s = s.to_s
  return s if s.length <= width
  width <= 1 ? s[0, width] : s[0, width - 1] + '…'
end

def row(name, files, lines, blanks, comments, code, complexity, width_name = 16)
  format("%-#{width_name}s %8s %11s %9s %9s %10s %10s", trunc(name, width_name), files.to_s, fmt_num(lines), fmt_num(blanks), fmt_num(comments), fmt_num(code), fmt_num(complexity))
end

def render_tabular(stats, opt)
  stats = sort_stats(stats, opt.sort)
  t = totals(stats)
  border = opt.ci ? ASCII_BORDER : BORDER
  out = []
  if opt.wide
    border = '─' * 109 unless opt.ci
    out << border unless opt.no_hborder
    out << format('%-35s %8s %9s %8s %9s %8s %10s %16s', 'Language', 'Files', 'Lines', 'Blanks', 'Comments', 'Code', 'Complexity', 'Complexity/Lines')
    out << border unless opt.no_hborder
    stats.each do |s|
      ratio = s.code.zero? ? 0.0 : (s.complexity.to_f / s.code * 100)
      out << format('%-35s %8s %9s %8s %9s %8s %10s %16.2f', trunc(s.name,35), fmt_num(s.count), fmt_num(s.lines), fmt_num(s.blank), fmt_num(s.comment), fmt_num(s.code), fmt_num(s.complexity), ratio)
    end
    out << border unless opt.no_hborder
    ratio = t.code.zero? ? 0.0 : (t.complexity.to_f / t.code * 100)
    out << format('%-35s %8s %9s %8s %9s %8s %10s %16.2f', 'Total', fmt_num(t.count), fmt_num(t.lines), fmt_num(t.blank), fmt_num(t.comment), fmt_num(t.code), fmt_num(t.complexity), ratio)
    out << border unless opt.no_hborder
    return out.join("\n") + "\n"
  end
  out << border unless opt.no_hborder
  out << row('Language', 'Files', 'Lines', 'Blanks', 'Comments', 'Code', 'Complexity')
  out << border unless opt.no_hborder
  stats.each do |s|
    out << row(s.name, s.count, s.lines, s.blank, s.comment, s.code, s.complexity)
    if opt.percent && t.lines > 0
      out << format('%-16s %8s %11s %9s %9s %10s %10s', 'Percentage', pct(s.count,t.count), pct(s.lines,t.lines), pct(s.blank,t.blank), pct(s.comment,t.comment), pct(s.code,t.code), pct(s.complexity,t.complexity))
      out << '-' * 79 unless opt.no_hborder
    end
    if opt.by_file
      out << border unless opt.no_hborder
      s.files.sort_by(&:name).each { |f| out << row(f.name, '', f.lines, f.blank, f.comment, f.code, f.complexity) }
      out << border unless opt.no_hborder
    elsif opt.uloc
      out << format('%-16s %8s %11s', '(ULOC)', '', fmt_num(s.uloc))
      out << '-' * 79 unless opt.no_hborder && s != stats.last
    elsif opt.character
      mean = s.lines.zero? ? 0 : (s.sum_line.to_f / s.lines).round
      out << format('%-16s %8s %11s', 'MaxLine / MeanLine', fmt_num(s.max_line), fmt_num(mean))
      out << '-' * 79 unless opt.no_hborder && s != stats.last
    end
  end
  out << border unless opt.no_hborder || opt.by_file
  out << row('Total', t.count, t.lines, t.blank, t.comment, t.code, t.complexity)
  out << border unless opt.no_hborder
  if opt.uloc
    out << format('%-29s %9s', 'Unique Lines of Code (ULOC)', fmt_num(t.uloc))
    if opt.dryness
      dry = t.lines.zero? ? 0.0 : t.uloc.to_f / t.lines
      out << format('%-29s %9.2f', 'DRYness %', dry)
    end
    out << border unless opt.no_hborder
  end
  unless opt.no_cocomo
    cost, schedule, people = cocomo(t.code, opt)
    out << "Estimated Cost to Develop (#{cocomo_name(opt)}) #{opt.currency_symbol}#{fmt_num(cost.floor)}"
    out << format('Estimated Schedule Effort (%s) %.2f months', cocomo_name(opt), schedule)
    out << format('Estimated People Required (%s) %.2f', cocomo_name(opt), people)
    out << border unless opt.no_hborder
  end
  unless opt.no_size
    mb = t.bytes.to_f / 1_000_000
    out << format('Processed %s bytes, %.3f megabytes (SI)', fmt_num(t.bytes), mb)
    out << border unless opt.no_hborder
  end
  out.join("\n") + "\n"
end

def pct(a,b)
  b.to_i.zero? ? '0.0%' : format('%.1f%%', a.to_f / b * 100)
end

def cocomo_name(opt)
  opt.cocomo_type.split(',').first
end

def cocomo(code, opt)
  coeff = case opt.cocomo_type
          when 'semi-detached' then [3.0, 1.12, 2.5, 0.35]
          when 'embedded' then [3.6, 1.20, 2.5, 0.32]
          when /^custom,/ then opt.cocomo_type.split(',')[1,4].map(&:to_f)
          else [2.4, 1.05, 2.5, 0.38]
          end
  a,b,c,d = coeff
  ksloc = code.to_f / 1000.0
  effort = a * (ksloc ** b) * opt.eaf
  schedule = c * (effort ** d)
  people = schedule.zero? ? 0.0 : effort / schedule
  monthly = opt.avg_wage.to_f / 12.0 * opt.overhead
  [effort * monthly, schedule, people]
end

def json_obj(s, with_files=false, include_uloc=false)
  h = { Name: s.name, Bytes: s.bytes, CodeBytes: 0, Lines: s.lines, Code: s.code, Comment: s.comment, Blank: s.blank,
        Complexity: s.complexity, Count: s.count, WeightedComplexity: 0 }
  h[:Files] = with_files ? s.files.map { |f| { Name: f.name, Location: f.path, Lines: f.lines, Code: f.code, Comment: f.comment, Blank: f.blank, Complexity: f.complexity, Bytes: f.bytes } } : []
  h[:LineLength] = nil
  h[:ULOC] = include_uloc ? (s.uloc || 0) : 0
  h
end

def render_json(stats, opt, version2=false)
  arr = sort_stats(stats, opt.sort).map { |s| json_obj(s, opt.by_file, opt.uloc) }
  if version2
    t = totals(stats); cost, schedule, people = cocomo(t.code, opt)
    json_generate({ languageSummary: arr, estimatedCost: cost, estimatedScheduleMonths: schedule, estimatedPeople: people })
  else
    json_generate(arr)
  end
end

def json_generate(obj)
  case obj
  when Hash
    '{' + obj.map { |k, v| json_generate(k.to_s) + ':' + json_generate(v) }.join(',') + '}'
  when Array
    '[' + obj.map { |v| json_generate(v) }.join(',') + ']'
  when String, Symbol
    '"' + obj.to_s.gsub(/["\\\b\f\n\r\t]/) { |c|
      { '"' => '\"', '\\' => '\\\\', "\b" => '\b', "\f" => '\f', "\n" => '\n', "\r" => '\r', "\t" => '\t' }[c]
    } + '"'
  when NilClass
    'null'
  when TrueClass
    'true'
  when FalseClass
    'false'
  else
    obj.to_s
  end
end

def render_csv(stats, opt)
  rows = [%w[Language Lines Code Comments Blanks Complexity Bytes Files ULOC]]
  sort_stats(stats, opt.sort).each { |s| rows << [s.name, s.lines, s.code, s.comment, s.blank, s.complexity, s.bytes, s.count, opt.uloc ? s.uloc : 0] }
  rows.map { |r| csv_line(r) }.join("\n") + "\n"
end

def render_csv_stream(stats, opt)
  rows = [%w[Language Provider Filename Lines Code Comments Blanks Complexity Bytes Uloc]]
  sort_stats(stats, opt.sort).each do |s|
    s.files.sort_by(&:name).each { |f| rows << [s.name, f.name, f.name, f.lines, f.code, f.comment, f.blank, f.complexity, f.bytes, opt.uloc ? f.uloc : 0] }
  end
  rows.map { |r| csv_line(r) }.join("\n") + "\n"
end

def csv_line(row)
  row.map { |v| csv_field(v) }.join(',')
end

def csv_field(v)
  s = v.to_s
  if s =~ /[",\n]/ || s.empty?
    '"' + s.gsub('"', '""') + '"'
  else
    s
  end
end

def render_yaml(stats, opt)
  t = totals(stats)
  out = ["# https://github.com/boyter/scc/", 'header:', '  url: https://github.com/boyter/scc/', "  version: #{VERSION}", '  elapsed_seconds: 0.001', "  n_files: #{t.count}", "  n_lines: #{t.lines}", '  files_per_second: 0', '  lines_per_second: 0']
  sort_stats(stats, opt.sort).each do |s|
    key = s.name.gsub(':','')
    out += ["#{key}:", "  name: #{s.name}", "  code: #{s.code}", "  comment: #{s.comment}", "  blank: #{s.blank}", "  nFiles: #{s.count}"]
  end
  out += ['SUM:', "  code: #{t.code}", "  comment: #{t.comment}", "  blank: #{t.blank}", "  nFiles: #{t.count}"]
  out.join("\n") + "\n"
end

def render_html(stats, opt, table_only=false)
  rows = sort_stats(stats, opt.sort).map { |s| "<tr><td>#{s.name}</td><td>#{s.count}</td><td>#{s.lines}</td><td>#{s.blank}</td><td>#{s.comment}</td><td>#{s.code}</td><td>#{s.complexity}</td></tr>" }.join("\n")
  table = "<table>\n<thead><tr><th>Language</th><th>Files</th><th>Lines</th><th>Blanks</th><th>Comments</th><th>Code</th><th>Complexity</th></tr></thead>\n<tbody>\n#{rows}\n</tbody>\n</table>\n"
  return table if table_only
  "<!doctype html><html><head><meta charset=\"utf-8\"><title>scc report</title></head><body>#{table}</body></html>\n"
end

def render_sql(stats, opt, inserts_only=false)
  project = opt.sql_project || 'scc'
  out = []
  unless inserts_only
    out << 'CREATE TABLE metadata (project TEXT, language TEXT, files INTEGER, lines INTEGER, blanks INTEGER, comments INTEGER, code INTEGER, complexity INTEGER, bytes INTEGER);'
  end
  sort_stats(stats, opt.sort).each do |s|
    vals = [project, s.name, s.count, s.lines, s.blank, s.comment, s.code, s.complexity, s.bytes].map { |v| v.is_a?(String) ? "'#{v.gsub("'", "''")}'" : v }.join(',')
    out << "INSERT INTO metadata VALUES (#{vals});"
  end
  out.join("\n") + "\n"
end

def render_openmetrics(stats, opt)
  out = ["# HELP scc_code_lines Lines of code counted by scc", "# TYPE scc_code_lines gauge"]
  sort_stats(stats, opt.sort).each do |s|
    label = s.name.gsub('"','\\"')
    out << "scc_files{language=\"#{label}\"} #{s.count}"
    out << "scc_lines{language=\"#{label}\"} #{s.lines}"
    out << "scc_code{language=\"#{label}\"} #{s.code}"
    out << "scc_comments{language=\"#{label}\"} #{s.comment}"
    out << "scc_blanks{language=\"#{label}\"} #{s.blank}"
  end
  out << '# EOF'
  out.join("\n") + "\n"
end

def render(stats, opt, fmt=nil)
  fmt ||= opt.format
  case fmt
  when 'json' then render_json(stats, opt)
  when 'json2' then render_json(stats, opt, true)
  when 'csv' then render_csv(stats, opt)
  when 'csv-stream' then render_csv_stream(stats, opt)
  when 'cloc-yaml' then render_yaml(stats, opt)
  when 'html' then render_html(stats, opt)
  when 'html-table' then render_html(stats, opt, true)
  when 'sql' then render_sql(stats, opt)
  when 'sql-insert' then render_sql(stats, opt, true)
  when 'openmetrics' then render_openmetrics(stats, opt)
  when 'wide' then old = opt.wide; opt.wide = true; r = render_tabular(stats, opt); opt.wide = old; r
  else render_tabular(stats, opt)
  end
end

opt = parse_args(ARGV)
if opt.help
  puts help_text
  exit 0
end
if opt.version
  puts "scc version #{VERSION}"
  exit 0
end
if opt.languages
  puts LANGUAGE_TEXT
  exit 0
end

stats = compute(opt.paths, opt)
if opt.format_multi
  opt.format_multi.split(',').each do |spec|
    fmt, dest = spec.split(':', 2)
    text = render(stats, opt, fmt)
    if dest.nil? || dest == 'stdout'
      print text
    else
      File.write(dest, text)
    end
  end
elsif opt.output
  File.write(opt.output, render(stats, opt))
else
  print render(stats, opt)
end

__END__
ABAP (abap)
ABNF (abnf)
ActionScript (as)
Ada (ada,adb,ads,pad)
Agda (agda)
Alchemist (crn)
Alex (x)
Algol 68 (a68)
Alloy (als)
Amber (ab)
Android Interface Definition Language (aidl)
Apex (apex,trigger)
APL (apl,aplf,apln,aplc,dyalog)
AppleScript (applescript)
ArkTs (ets)
Arturo (art)
AsciiDoc (adoc)
ASP (asa,asp)
ASP.NET (asax,ascx,asmx,aspx,master,sitemap,webinfo)
Assembly (s,asm)
Astro (astro)
ATS (dats,sats,ats,hats)
Autoconf (in)
AutoHotKey (ahk)
Avro (avdl,avpr,avsc)
AWK (awk)
bait (bt)
BASH (bash,bash_login,bash_logout,bash_profile,bashrc,.bash_login,.bash_logout,.bash_profile,.bashrc)
Basic (bas)
Batch (bat,btm,cmd)
Bazel (bzl,build.bazel,build,workspace)
Bean (bean,beancount)
Bicep (bicep)
Bitbake (bb,bbappend,bbclass)
Bitbucket Pipeline (bitbucket-pipelines.yml)
Blade template (blade.php)
Blueprint (blp)
Boo (boo)
Bosque (bsq)
Brainfuck (bf)
Bru (bru)
BuildStream (bst)
C (c,ec,pgc)
C Header (h)
C Shell (csh,.cshrc)
C# (cs,csx)
C++ (cc,cpp,cxx,c++,pcc,ino,ccm,cppm,cxxm,c++m,mxx)
C++ Header (hh,hpp,hxx,h++,inl,ipp,ixx,tpp)
C3 (c3)
Cabal (cabal)
Cairo (cairo)
Cangjie (cj)
Cap'n Proto (capnp)
Cassius (cassius)
Ceylon (ceylon)
Chapel (chpl)
Circom (circom)
Clipper (prg,ch)
Clojure (clj,cljc)
ClojureScript (cljs)
Closure Template (soy)
CloudFormation (JSON) (json)
CloudFormation (YAML) (yaml,yml)
CMake (cmake,cmakelists.txt)
COBOL (cob,cbl,ccp,cobol,cpy)
CodeQL (ql,qll)
CoffeeScript (coffee)
Cogent (cogent)
ColdFusion (cfm)
ColdFusion CFScript (cfc)
Coq (v)
Creole (creole)
Crystal (cr)
CSS (css)
CSV (csv)
Cuda (cu,cuh)
Cypher (cypher,cql)
Cython (pyx,pxi,pxd)
D (d)
D2 (d2)
DAML (daml)
Dart (dart)
Device Tree (dts,dtsi)
Dhall (dhall)
DM (dm)
Docker ignore (.dockerignore)
Dockerfile (dockerfile,dockerfile)
Document Type Definition (dtd)
DOT (dot,gv)
Elixir (ex,exs)
Elixir Template (eex)
Elm (elm)
Emacs Dev Env (ede)
Emacs Lisp (el)
EmiT (emit)
Erlang (erl,hrl)
Expect (exp)
Extensible Stylesheet Language Transformations (xslt,xsl)
F# (fs,fsi,fsx,fsscript)
F* (fst)
Factor (factor)
Fennel (fnl)
FIDL (fidl)
Fish (fish)
Flow9 (flow)
Forth (4th,forth,fr,frt,fth,f83,fb,fpm,e4,rx,ft)
FORTRAN Legacy (f,for,ftn,f77,pfo)
Fortran Modern (f03,f08,f90,f95)
Fragment Shader File (fsh)
Freemarker Template (ftl)
FSL (fsl)
Futhark (fut)
FXML (fxml)
Game Maker Language (gml)
Game Maker Project (yyp)
GDScript (gd)
Gemfile (gemfile)
Gherkin Specification (feature)
gitignore (.gitignore)
Gleam (gleam)
GLSL (vert,tesc,tese,geom,frag,comp,glsl)
GN (gn,gni)
Go (go)
Go Template (tmpl,gohtml,gotxt)
Go+ (gop)
Godot Scene (tscn)
Gradle (gradle)
GraphQL (graphql)
Gremlin (gremlin)
Groovy (groovy,grt,gtpl,gvy)
Gwion (gw)
HAML (haml)
Hamlet (hamlet)
Handlebars (hbs,handlebars)
Happy (y,ly)
Hare (ha)
Haskell (hs)
Haxe (hx)
HCL (hcl)
HEEx (heex)
HEX (hex)
hoon (hoon)
HTML (html,htm)
IDL (idl,webidl,widl)
Idris (idr,lidr)
ignore (.ignore)
INI (ini)
Intel HEX (ihex)
Isabelle (thy)
Jade (jade)
JAI (jai)
Janet (janet)
Java (java)
JavaScript (js,cjs,mjs)
JavaServer Pages (jsp)
JCL (jcl,jcls)
Jenkins Buildfile (jenkinsfile)
Jinja (jinja,j2,jinja2)
jq (jq)
JSON (json)
JSON5 (json5)
JSONC (jsonc)
JSONL (jsonl)
Jsonnet (jsonnet,libsonnet)
JSX (jsx)
Julia (jl)
Julius (julius)
Jupyter (ipynb,jpynb)
Just (justfile)
K (k)
Korn Shell (ksh,.kshrc)
Kotlin (kt,kts)
Koto (koto)
LALRPOP (lalrpop)
LaTeX (tex)
LD Script (lds)
Lean (lean,hlean)
LESS (less)
LEX (l)
License (license,licence,copying,copying3,unlicense,unlicence,license-apache,licence-apache,license-mit,licence-mit,copyright)
Lisp (lisp,lsp)
LiveScript (ls)
LLVM IR (ll)
LOLCODE (lol,lols)
Lua (lua)
Luau (luau)
Lucius (lucius)
Luna (luna)
m4 (m4)
Macromedia eXtensible Markup Language (mxml)
Madlang (mad)
Makefile (makefile,mak,mk,bp,makefile,gnumakefile)
Mako (mako,mao)
Markdown (md,markdown)
MATLAB (m)
Max (maxpat)
MDX (mdx)
Meson (meson.build,meson_options.txt)
Metal (metal)
MLIR (mlir)
Modula3 (m3,mg,ig,i3)
Module-Definition (def)
Mog (mog)
Mojo (mojo)
Monkey C (mc)
Moonbit (mbt)
MQL Header (mqh)
MQL4 (mq4)
MQL5 (mq5)
MSBuild (csproj,vbproj,fsproj,vcproj,vcxproj,vcxproj.filters,ilproj,myapp,props,rdlc,resx,settings,sln,targets)
MUMPS (mps)
Mustache (mustache)
Nature (n)
Nial (ndf)
Nim (nim)
Nix (nix)
Nushell (nu)
nuspec (nuspec)
Objective C (m)
Objective C++ (mm)
OCaml (ml,mli)
Odin (odin)
Opalang (opa)
OpenQASM (qasm)
OpenTofu (tofu)
Org (org)
Oz (oz)
Pascal (pas)
Patch (patch)
Perl (pl,plx,pm)
Phoenix LiveView (heex,leex)
PHP (php)
Picat (pi)
PKGBUILD (pkgbuild)
Pkl (pkl)
PL/SQL (fnc,pkb,pks,prc,trg,vw)
Plain Text (text,txt)
Polly (polly)
POML (poml)
Pony (pony)
PostScript (ps)
Powershell (ps1,psm1)
Processing (pde)
Prolog (p,pro)
Properties File (properties)
Protocol Buffers (proto)
PRQL (prql)
PSL Assertion (psl)
Puppet (pp)
PureScript (purs)
Python (py,pyw,pyi)
Q# (qs)
QCL (qcl)
QML (qml)
R (r)
Racket (rkt)
Rakefile (rake,rakefile)
Raku (raku,rakumod,rakutest,rakudoc,t)
RAML (raml,rml)
Razor (cshtml,razor)
ReasonML (re,rei)
Rebol (reb)
Redscript (reds)
Report Definition Language (rdl)
ReScript (res,resi)
ReStructuredText (rst)
Rich Text Format (rtf)
Robot Framework (robot)
Ruby (rb)
Ruby HTML (rhtml,erb)
Rust (rs)
SAS (sas)
Sass (sass,scss)
Scala (sc,scala)
Scallop (scl)
Scheme (scm,ss)
Scons (csig,sconstruct,sconscript)
sed (sed)
Seed7 (sd7,s7i)
Shell (sh,.tcshrc)
Sieve (sieve)
SKILL (il)
Slang (slang)
Slint (slint)
Smalltalk (cs.st,pck.st)
Smarty Template (tpl)
Snakemake (smk,rules,snakefile)
SNOBOL (sno)
Softbridge Basic (sbl)
Solidity (sol)
SPDX (spdx)
Specman e (e)
Spice Netlist (ckt)
SPL (spl)
SQL (sql,dml,ddl,dql)
SRecode Template (srt)
Stan (stan)
Standard ML (SML) (sml)
Stata (do,ado)
Stylus (styl)
Svelte (svelte)
SVG (svg)
Swift (swift)
Swig (i)
Systemd (automount,device,link,mount,path,scope,service,slice,socket,swap,target,timer)
SystemVerilog (sv,svh)
Tact (tact)
TaskPaper (taskpaper)
TCL (tcl)
Teal (teal)
Templ (templ)
TemplateToolkit (tt,tt2)
Tera (tera)
Terraform (tf,tfvars,tf.json)
TeX (tex,sty)
Textile (textile)
Thrift (thrift)
TL (tl)
TOML (toml)
TOON (toon)
Treetop (treetop,tt)
TTCN-3 (ttcn,ttcn3,ttcnpp)
Twig Template (twig)
TypeScript (ts,tsx,cts,mts)
TypeScript Typings (d.ts)
TypeSpec (tsp)
Typst (typ)
Unreal Script (uc,uci,upkg)
Up (up)
Ur/Web (ur,urs)
Ur/Web Project (urp)
V (v)
Vala (vala)
Varnish Configuration (vcl)
Verilog (vg,vh,v)
Verilog Args File (irunargs,xrunargs)
Vertex Shader File (vsh)
VHDL (vhd,vhdl)
Vim Script (vim,vimrc,gvimrc,_vimrc,.vimrc,_gvimrc,.gvimrc,vimrc,gvimrc)
Visual Basic (vb)
Visual Basic for Applications (cls)
Vue (vue)
W.I.S.E. Jobfile (fgmj)
Web Services Description Language (wsdl)
WebGPU Enhanced Shading Language (wesl)
WebGPU Shading Language (wgsl)
wenyan (wy)
Windows Resource-Definition Script (rc)
Wolfram (nb,wl)
Wren (wren)
XAML (xaml)
Xcode Config (xcconfig)
XHTML (xhtml,xhtm,xht)
XMake (xmake.lua,xpack.lua)
XML (xml)
XML Schema (xsd)
Xtend (xtend)
YAML (yaml,yml)
Yarn (yarn)
Zig (zig)
ZoKrates (zok)
Zsh (zsh,zshenv,zlogin,zlogout,zprofile,zshrc,.zshenv,.zlogin,.zlogout,.zprofile,.zshrc)
