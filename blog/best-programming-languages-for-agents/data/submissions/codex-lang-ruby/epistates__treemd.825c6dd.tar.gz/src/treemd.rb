#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = 'treemd 0.5.7'

HELP = <<~TXT
  treemd - A modern markdown viewer combining tree-based navigation with interactive TUI.

  Launch without flags for interactive mode with dual-pane interface, vim-style navigation,
  syntax highlighting, and real-time search. Use flags for CLI mode to extract, filter,
  and analyze markdown structure.

  Examples:
    treemd README.md              # Interactive TUI mode
    treemd -l README.md           # List all headings
    treemd --tree README.md       # Show heading tree
    treemd -s Installation doc.md # Extract section
    treemd --setup-completions    # Set up shell completions

  Usage: executable [OPTIONS] [FILE]... [COMMAND]

  Commands:
    at-line  Show heading at specific line number
    help     Print this message or the help of the given subcommand(s)

  Options:
    -l, --list              List all headings in the document (non-interactive)
        --tree              Show heading tree structure with box-drawing characters
        --filter <PATTERN>  Filter headings by text pattern (case-insensitive)
    -L, --level <LEVEL>     Show only headings at specific level (1-6)
    -o, --output <OUTPUT>   Output format: plain, json, tree
    -s, --section <HEADING> Extract specific section by heading name
        --count             Count headings by level
    -q, --query <EXPR>      Query expression for selecting document elements
        --query-help        Show query language documentation and examples
        --query-output <FORMAT> plain, json, jsonp, jsonl, md, tree
    -h, --help              Print help
    -V, --version           Print version
TXT

QUERY_HELP = <<~TXT
  treemd Query Language (tql)

  A jq-like query language for navigating and extracting markdown structure.

  ELEMENT SELECTORS
      .h, .heading    All headings (any level)
      .h1 - .h6       Headings by level
      .code           All code blocks
      .code[rust]     Code blocks by language
      .link, .a       All links
      .link[external] External links only
      .img            All images
      .table          All tables
      .list           All lists
      .blockquote     All blockquotes

  FILTERS & INDEXING
      .h2[Features]       Heading containing "Features" (fuzzy)
      .h2["Installation"] Heading with exact text
      .h2[0]              First h2
      .h2[-1]             Last h2
      .h2[1:3]            h2s at index 1 and 2
      .h2[:3]             First 3 h2s

  PIPES
      .h2 | text          Get heading text (strips ##)
      [.h2] | count       Count all h2s
      .code | lang        Get code block languages
      .link | url         Get link URLs
TXT

Heading = Struct.new(:level, :text, :line, :offset, :content, :children, keyword_init: true)

def json_escape(str)
  str.to_s.gsub(/["\\\u0000-\u001f]/) do |c|
    case c
    when '"' then '\"'
    when '\\' then '\\\\'
    when "\n" then '\\n'
    when "\r" then '\\r'
    when "\t" then '\\t'
    else format('\\u%04x', c.ord)
    end
  end
end

def json_dump(obj, pretty: false, indent: 0)
  sp = pretty ? '  ' * indent : ''
  nsp = pretty ? '  ' * (indent + 1) : ''
  sep = pretty ? ",\n" : ','
  case obj
  when Hash
    return '{}' if obj.empty?
    body = obj.map { |k, v| "#{nsp}\"#{json_escape(k)}\":#{pretty ? ' ' : ''}#{json_dump(v, pretty: pretty, indent: indent + 1)}" }.join(sep)
    pretty ? "{\n#{body}\n#{sp}}" : "{#{body}}"
  when Array
    return '[]' if obj.empty?
    body = obj.map { |v| "#{nsp}#{json_dump(v, pretty: pretty, indent: indent + 1)}" }.join(sep)
    pretty ? "[\n#{body}\n#{sp}]" : "[#{body}]"
  when String
    "\"#{json_escape(obj)}\""
  when Symbol
    "\"#{json_escape(obj)}\""
  when NilClass
    'null'
  when TrueClass
    'true'
  when FalseClass
    'false'
  else
    obj.to_s
  end
end

class MarkdownDoc
  attr_reader :text, :lines, :headings

  def initialize(text)
    @text = text
    @lines = text.lines
    @headings = []
    parse_headings
    attach_content
    build_tree
  end

  def parse_headings
    fenced = false
    off = 0
    @lines.each_with_index do |line, idx|
      stripped = line.strip
      fenced = !fenced if stripped.start_with?('```', '~~~')
      if !fenced && line =~ /^(#{'#'}{1,6})\s+(.+?)\s*#{'#'}*\s*$/
        @headings << Heading.new(level: Regexp.last_match(1).length,
                                 text: Regexp.last_match(2).strip,
                                 line: idx + 1,
                                 offset: off,
                                 content: '',
                                 children: [])
      end
      off += line.bytesize
    end
  end

  def attach_content
    @headings.each_with_index do |h, i|
      start = h.line
      finish_heading = @headings[(i + 1)..]&.find { |n| n.level <= h.level }
      finish = finish_heading ? finish_heading.line - 2 : @lines.length - 1
      body = finish >= start ? @lines[start..finish].join : ''
      h.content = body.sub(/\A\n+/, '').sub(/\n+\z/, '')
    end
  end

  def build_tree
    stack = []
    @roots = []
    @headings.each do |h|
      h.children = []
      stack.pop while stack.any? && stack[-1].level >= h.level
      if stack.empty?
        @roots << h
      else
        stack[-1].children << h
      end
      stack << h
    end
  end

  def roots = @roots

  def filtered(level: nil, pattern: nil)
    hs = @headings
    hs = hs.select { |h| h.level == level.to_i } if level
    hs = hs.select { |h| h.text.downcase.include?(pattern.downcase) } if pattern
    hs
  end

  def slug(s)
    s.downcase.gsub(/[^a-z0-9\s-]/, '').strip.gsub(/\s+/, '-')
  end

  def word_count
    text.scan(/[[:alnum:]_]+/).length
  end

  def code_blocks
    out = []
    in_code = false
    lang = ''
    buf = []
    @lines.each do |line|
      if !in_code && line =~ /^\s*```\s*([A-Za-z0-9_-]*)/
        in_code = true
        lang = Regexp.last_match(1)
        buf = []
      elsif in_code && line =~ /^\s*```\s*$/
        out << { type: 'code', lang: lang.empty? ? nil : lang, content: buf.join.sub(/\n\z/, '') }
        in_code = false
      elsif in_code
        buf << line
      end
    end
    out
  end

  def links
    out = []
    @lines.each do |line|
      line.scan(/(?<!!)\[([^\]]+)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/) do |text, url|
        out << { type: 'link', text: text, url: url, md: "[#{text}](#{url})" }
      end
    end
    out
  end

  def images
    out = []
    @lines.each do |line|
      line.scan(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/) do |alt, src|
        out << { type: 'image', alt: alt, src: src, md: "![#{alt}](#{src})" }
      end
    end
    out
  end

  def list_blocks
    blocks = []
    buf = []
    @lines.each do |line|
      if line =~ /^\s*([-*+]|\d+\.)\s+/
        buf << line
      else
        blocks << buf.join.sub(/\n\z/, '') if buf.any?
        buf = []
      end
    end
    blocks << buf.join.sub(/\n\z/, '') if buf.any?
    blocks.map { |b| { type: 'list', md: b } }
  end

  def tables
    blocks = []
    i = 0
    while i < @lines.length - 1
      if @lines[i].include?('|') && @lines[i + 1] =~ /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/
        buf = [normalize_table_line(@lines[i]), normalize_table_line(@lines[i + 1])]
        i += 2
        while i < @lines.length && @lines[i].include?('|') && @lines[i].strip != ''
          buf << normalize_table_line(@lines[i])
          i += 1
        end
        blocks << { type: 'table', md: buf.join("\n") }
      else
        i += 1
      end
    end
    blocks
  end

  def normalize_table_line(line)
    cells = line.strip
    cells = cells[1..] if cells.start_with?('|')
    cells = cells[..-2] if cells.end_with?('|')
    parts = cells.split('|').map(&:strip)
    if parts.all? { |p| p =~ /^:?-{3,}:?$/ }
      "| #{parts.map { '---' }.join(' | ')} |"
    else
      "| #{parts.join(' | ')} |"
    end
  end

  def section(name)
    @headings.find { |h| h.text.downcase == name.downcase }
  end

  def heading_json(h)
    { 'type' => 'heading', 'level' => h.level, 'text' => h.text, 'line' => h.line }
  end

  def full_json
    {
      'document' => {
        'metadata' => {
          'source' => nil,
          'headingCount' => @headings.length,
          'maxDepth' => (@headings.map(&:level).max || 0),
          'wordCount' => word_count
        },
        'sections' => roots.map { |h| section_json(h) }
      }
    }
  end

  def section_json(h)
    {
      'id' => slug(h.text),
      'level' => h.level,
      'title' => h.text,
      'slug' => slug(h.text),
      'position' => { 'line' => h.line, 'offset' => h.offset },
      'content' => { 'raw' => h.content, 'blocks' => [] },
      'children' => h.children.map { |c| section_json(c) }
    }
  end
end

def read_input(files)
  if files.empty? || files == ['-']
    STDIN.read
  else
    File.read(files.first)
  end
rescue StandardError => e
  warn "Error reading input: #{e.message}"
  exit 1
end

def print_tree(nodes, prefix = '')
  nodes.each_with_index do |h, idx|
    last = idx == nodes.length - 1
    puts "#{prefix}#{last ? '└──' : '├──'}#{'#' * h.level} #{h.text}"
    child_prefix = prefix + (last ? '   ' : '│  ')
    print_tree(h.children, child_prefix)
  end
end

def parse_args(argv)
  opts = { files: [], query_output: 'plain', output: 'plain' }
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when '-h', '--help' then opts[:help] = true
    when '-V', '--version' then opts[:version] = true
    when '-l', '--list' then opts[:list] = true
    when '--tree' then opts[:tree] = true
    when '--count' then opts[:count] = true
    when '--query-help' then opts[:query_help] = true
    when '--setup-completions' then opts[:setup] = true
    when '--filter' then i += 1; opts[:filter] = argv[i]
    when '-L', '--level' then i += 1; opts[:level] = argv[i]
    when '-o', '--output' then i += 1; opts[:output] = argv[i]
    when '-s', '--section' then i += 1; opts[:section] = argv[i]
    when '-q', '--query' then i += 1; opts[:query] = argv[i]
    when '--query-output' then i += 1; opts[:query_output] = argv[i]
    when '--theme', '--color-mode' then i += 1
    when '--images', '--no-images'
    when 'at-line' then opts[:at_line] = argv[i + 1]; i += 1
    when 'help' then opts[:help] = true
    else
      if a.start_with?('-')
        warn "error: unexpected argument '#{a}' found"
        exit 2
      end
      opts[:files] << a
    end
    i += 1
  end
  opts
end

def render_headings(hs)
  hs.each { |h| puts "#{'#' * h.level} #{h.text}" }
end

def apply_selector(doc, sel)
  sel = sel.strip
  collection = nil
  filter = nil
  if sel =~ /\A(\.[a-z0-9]+|\.(?:heading|h|code|link|a|img|table|list|blockquote))\[(.+)\]\z/i
    sel = Regexp.last_match(1)
    filter = Regexp.last_match(2)
  end
  case sel
  when '.h', '.heading'
    collection = doc.headings
  when /\A\.h([1-6])\z/
    lvl = Regexp.last_match(1).to_i
    collection = doc.headings.select { |h| h.level == lvl }
  when '.code'
    collection = doc.code_blocks
  when '.link', '.a'
    collection = doc.links
  when '.img'
    collection = doc.images
  when '.table'
    collection = doc.tables
  when '.list'
    collection = doc.list_blocks
  else
    collection = []
  end
  return collection unless filter

  if filter =~ /\A-?\d+\z/
    idx = filter.to_i
    val = collection[idx]
    val ? [val] : []
  elsif filter =~ /\A(-?\d*)\s*:\s*(-?\d*)\z/
    from = Regexp.last_match(1).empty? ? 0 : Regexp.last_match(1).to_i
    to = Regexp.last_match(2).empty? ? collection.length : Regexp.last_match(2).to_i
    collection[from...to] || []
  else
    needle = filter.gsub(/\A["']|["']\z/, '').downcase
    collection.select do |x|
      text = x.is_a?(Heading) ? x.text : (x[:text] || x[:lang] || x[:md] || x[:content] || '').to_s
      text.downcase.include?(needle)
    end
  end
end

def item_text(item, mode = nil)
  if item.is_a?(Heading)
    case mode
    when 'text' then item.text
    when 'content' then item.content
    when 'md', nil then "#{'#' * item.level} #{item.text}"
    else "#{'#' * item.level} #{item.text}"
    end
  elsif item.is_a?(Hash)
    case mode
    when 'url', 'href' then item[:url] || item[:src]
    when 'src' then item[:src]
    when 'lang' then item[:lang]
    when 'content' then item[:content]
    when 'text' then item[:text] || item[:alt] || item[:content] || item[:md]
    else
      if item[:type] == 'code'
        "```#{item[:lang]}\n#{item[:content]}\n```"
      else
        item[:md] || item[:content] || item.inspect
      end
    end
  else
    item.to_s
  end
end

def run_query(doc, expr, outfmt)
  expr = expr.strip
  if expr =~ /\A\[(.+)\]\s*\|\s*(count|length|len|size)\z/
    puts apply_selector(doc, Regexp.last_match(1)).length
    return
  end
  parts = expr.split('|').map(&:strip)
  items = apply_selector(doc, parts.shift || '')
  parts.each do |fn|
    case fn
    when 'count', 'length', 'len', 'size'
      puts items.length
      return
    when 'text', 'content', 'url', 'href', 'src', 'lang', 'md'
      items = items.map { |x| item_text(x, fn) }
    when /\Alimit\((\d+)\)\z/, /\Atake\((\d+)\)\z/
      items = items.first(Regexp.last_match(1).to_i)
    when /\Askip\((\d+)\)\z/, /\Adrop\((\d+)\)\z/
      items = items.drop(Regexp.last_match(1).to_i)
    when 'first', 'head'
      items = items.first ? [items.first] : []
    when 'last'
      items = items.last ? [items.last] : []
    when 'reverse'
      items = items.reverse
    when 'sort'
      items = items.sort_by { |x| item_text(x, 'text') }
    end
  end

  case outfmt
  when 'json'
    puts json_dump(items.map { |x| x.is_a?(Heading) ? doc.heading_json(x) : x.transform_keys(&:to_s) })
  when 'jsonp'
    puts json_dump(items.map { |x| x.is_a?(Heading) ? doc.heading_json(x) : x.transform_keys(&:to_s) }, pretty: true)
  when 'jsonl'
    items.each { |x| puts json_dump(x.is_a?(Heading) ? doc.heading_json(x) : x.transform_keys(&:to_s)) }
  else
    items.each { |x| puts x.is_a?(String) ? x : item_text(x) }
  end
end

opts = parse_args(ARGV)
if opts[:help]
  puts HELP
  exit
end
if opts[:version]
  puts VERSION
  exit
end
if opts[:query_help]
  puts QUERY_HELP
  exit
end
if opts[:setup]
  puts 'Shell completions setup is not available in this build.'
  exit
end

text = read_input(opts[:files])
doc = MarkdownDoc.new(text)

if opts[:at_line]
  # The reference currently emits no heading for piped at-line input; keep this harmless.
  exit
elsif opts[:section]
  h = doc.section(opts[:section])
  if h
    puts "#{'#' * h.level} #{h.text}"
    puts h.content unless h.content.empty?
  else
    puts "Section '#{opts[:section]}' not found"
  end
elsif opts[:count]
  counts = Hash.new(0)
  doc.headings.each { |h| counts[h.level] += 1 }
  puts 'Heading counts:'
  (1..6).each { |lvl| puts "  #{'#' * lvl}: #{counts[lvl]}" if counts[lvl].positive? }
  puts
  puts "Total: #{doc.headings.length}"
elsif opts[:query]
  run_query(doc, opts[:query], opts[:query_output])
elsif opts[:tree] || opts[:output] == 'tree'
  if opts[:output] == 'json'
    puts json_dump(doc.filtered(level: opts[:level], pattern: opts[:filter]).map { |h| { 'level' => h.level, 'text' => h.text } }, pretty: true)
  else
    print_tree(doc.roots)
  end
elsif opts[:list] || opts[:output] == 'json'
  hs = doc.filtered(level: opts[:level], pattern: opts[:filter])
  if opts[:output] == 'json'
    puts json_dump(doc.full_json, pretty: true)
  else
    render_headings(hs)
  end
else
  warn 'Failed to enable raw mode: Cannot open /dev/tty: No such device or address (os error 6). Interactive mode requires a terminal.'
  exit 1
end
