#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION_TEXT = "FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,\n" \
               "Christiaan Keet and Claudio Matsuoka\n" \
               "Internet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012\n\n" \
               "FIGlet, along with the various FIGlet fonts and documentation, may be\n" \
               "freely copied and distributed.\n\n" \
               "If you use FIGlet, please send an e-mail message to <info@figlet.org>.\n\n" \
               "The latest version of FIGlet is available from the web site,\n" \
               "\thttp://www.figlet.org/\n"

USAGE = "Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]\n" \
        "              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]\n" \
        "              [ -C controlfile ] [ -I infocode ] [ message ]"

class FigFont
  attr_reader :name, :hardblank, :height, :old_layout, :full_layout,
              :chars, :print_direction

  CODE_TAGS = {
    196 => 0x00c4, 214 => 0x00d6, 220 => 0x00dc, 228 => 0x00e4,
    246 => 0x00f6, 252 => 0x00fc, 223 => 0x00df
  }.freeze

  def initialize(path, name)
    @name = name
    @chars = {}
    parse(path)
  end

  def glyph(cp)
    @chars[cp] || @chars[63] || blank_glyph
  end

  def blank_glyph
    Array.new(@height, "")
  end

  private

  def parse(path)
    lines = File.binread(path).lines.map { |l| l.delete_suffix("\n").delete_suffix("\r") }
    header = lines.shift
    unless header && header.start_with?("flf2a", "tlf2a")
      raise "Not a figlet font"
    end
    @hardblank = header[5]
    fields = header[6..].to_s.split(/\s+/).reject(&:empty?)
    @height = fields[0].to_i
    @old_layout = fields[3].to_i
    comment_lines = fields[4].to_i
    @print_direction = fields[5] ? fields[5].to_i : 0
    @full_layout = fields[6] ? fields[6].to_i : nil
    lines.shift(comment_lines)

    (32..126).each do |cp|
      @chars[cp] = read_glyph(lines)
    end

    until lines.empty?
      tag_line = lines.first.to_s.strip
      break if tag_line.empty?
      if tag_line =~ /^(-?\d+)/
        cp = Regexp.last_match(1).to_i
        lines.shift
        @chars[CODE_TAGS.fetch(cp, cp)] = read_glyph(lines)
      else
        break
      end
    end
  end

  def read_glyph(lines)
    raw = lines.shift(@height)
    raw.map do |line|
      line = line.to_s.dup
      mark = line[-1]
      line.chop!
      line.chop! while !line.empty? && line[-1] == mark
      line.tr(@hardblank, " ")
    end
  end
end

class Figlet
  PAIRS = { "[" => "]", "{" => "}", "(" => ")" }.freeze
  HIER = ["|", "/\\", "[]", "{}", "()", "<>"].freeze

  def initialize(argv)
    @program = "executable"
    @font_dir = "/usr/local/share/figlet"
    @font_name = "standard"
    @width = 80
    @justify = :auto
    @direction = :auto
    @paragraph = false
    @german = false
    @mode_override = nil
    @info = nil
    @messages = parse(argv.dup)
  end

  def run
    return print_info unless @info.nil? || @info == -1

    font = load_font
    text = @messages.empty? ? STDIN.read : argv_text(@messages)
    text = apply_paragraph(text) if @paragraph
    text = apply_german(text) if @german
    text = text.delete_suffix("\n") if !text.empty? && text.end_with?("\n")
    render_text(font, text).each { |line| puts line }
  rescue RuntimeError => e
    warn "#{@program}: #{e.message}"
    exit 1
  end

  private

  def parse(argv)
    messages = []
    until argv.empty?
      arg = argv.shift
      if arg == "--help"
        warn "#{@program}: invalid option -- '-'"
        puts USAGE
        exit 1
      elsif arg.start_with?("-") && arg != "-"
        i = 1
        while i < arg.length
          ch = arg[i]
          case ch
          when "d", "f", "m", "w", "C", "I"
            value = arg[(i + 1)..]
            value = argv.shift if value.nil? || value.empty?
            handle_option(ch, value.to_s)
            break
          else
            handle_option(ch, nil)
            i += 1
          end
        end
      else
        messages << arg
      end
    end
    messages
  end

  def handle_option(ch, value)
    case ch
    when "d" then @font_dir = value
    when "f" then @font_name = value.sub(/\.(flf|tlf)\z/i, "")
    when "w" then @width = value.to_i
    when "t" then @width = terminal_width || @width
    when "c" then @justify = :center
    when "l" then @justify = :left
    when "r" then @justify = :right
    when "x" then @justify = :auto
    when "L" then @direction = :ltr
    when "R" then @direction = :rtl
    when "X" then @direction = :auto
    when "p" then @paragraph = true
    when "n" then @paragraph = false
    when "D" then @german = true
    when "E" then @german = false
    when "N" then nil
    when "C" then nil
    when "s" then @mode_override = :default_smush
    when "S" then @mode_override = :force_smush
    when "k" then @mode_override = :kern
    when "W" then @mode_override = :full
    when "o" then @mode_override = :force_smush
    when "m" then set_mode(value.to_i)
    when "I" then @info = value.to_i
    when "v" then @info = 0
    else
      warn "#{@program}: invalid option -- '#{ch}'"
      puts USAGE
      exit 1
    end
  end

  def set_mode(value)
    @mode_override = case value
                     when -2 then :default_smush
                     when -1 then :full
                     when 0 then :kern
                     else value & 63
                     end
  end

  def terminal_width
    out = `stty size 2>/dev/null`.split
    out.length == 2 ? out[1].to_i : nil
  end

  def print_info
    case @info
    when 0
      print VERSION_TEXT
      puts
      puts USAGE
    when 1 then puts "20205"
    when 2 then puts @font_dir
    when 3 then puts @font_name
    when 4 then puts @width
    when 5 then puts "flf2 tlf2"
    end
  end

  def load_font
    candidates = []
    supplied = @font_name
    exts = supplied =~ /\.(flf|tlf)\z/i ? [""] : [".flf", ".tlf", ""]
    if supplied.include?("/")
      exts.each { |ext| candidates << "#{supplied}#{ext}" }
    else
      dirs = [@font_dir, ".", File.expand_path("fonts", __dir__)]
      dirs.uniq.each do |dir|
        exts.each { |ext| candidates << File.join(dir, "#{supplied}#{ext}") }
      end
    end
    path = candidates.find { |p| File.file?(p) && File.readable?(p) }
    raise "#{@font_name}: Unable to open font file" unless path

    FigFont.new(path, File.basename(@font_name, ".*"))
  end

  def argv_text(args)
    out = +""
    args.each_with_index do |arg, idx|
      out << " " if idx.positive? && !args[idx - 1].empty?
      out << (arg.empty? ? "\n" : arg)
    end
    out
  end

  def apply_paragraph(text)
    chars = text.chars
    out = +""
    chars.each_with_index do |ch, idx|
      if ch == "\n" && idx.positive? && chars[idx - 1] != "\n" && chars[idx + 1] != " "
        out << " "
      else
        out << ch
      end
    end
    out
  end

  def apply_german(text)
    text.tr("[]\\{}|~", "\u00c4\u00d6\u00dc\u00e4\u00f6\u00fc\u00df")
  end

  def render_text(font, text)
    direction = @direction == :auto ? (font.print_direction == 1 ? :rtl : :ltr) : @direction
    full_layout = layout_for(font).first == :full
    blocks = []
    text.split("\n", -1).each do |line|
      next blocks.concat(justify([""], font)) if line.empty?

      line = line.reverse if direction == :rtl
      current = +""
      line.each_char do |ch|
        if @width == 1 && ch != " " && !current.empty?
          blocks.concat(finalize_line(font, current, full_layout))
          current = +""
        end
        candidate = current + ch
        if @width > 1 && !current.empty? &&
           visible_width(display_lines(raw_render_line(font, candidate), full_layout)) >= @width
          if current.include?(" ")
            before, _space, after = current.rpartition(" ")
            blocks.concat(finalize_line(font, before, full_layout)) unless before.empty?
            current = after + ch
          else
            blocks.concat(finalize_line(font, current, full_layout))
            current = ch
          end
        else
          current = candidate
        end
      end
      blocks.concat(finalize_line(font, current, full_layout)) unless current.empty?
    end
    blocks
  end

  def raw_render_line(font, text)
    previous = nil
    text.each_codepoint.reduce(Array.new(font.height, "")) do |work, cp|
      glyph = font.glyph(cp)
      rendered = previous == 32 ? merge_at(work, glyph, [2, visible_width(glyph)].min, 0, font) : append_glyph(work, glyph, font)
      previous = cp
      rendered
    end
  end

  def finalize_line(font, text, full_layout)
    work = display_lines(raw_render_line(font, text), full_layout)
    work = work.map { |line| line[0...-1] || "" } if text.end_with?(" ")
    justify(work, font)
  end

  def display_lines(lines, full_layout)
    (full_layout || @width == 1) ? lines : strip_left_margin(lines)
  end

  def visible_width(lines)
    lines.map(&:length).max || 0
  end

  def append_glyph(current, glyph, font)
    return glyph.map(&:dup) if current.all?(&:empty?)

    layout, rules = layout_for(font)
    return merge_at(current, glyph, 0, rules, font) if layout == :full

    max_overlap = [visible_width(current), visible_width(glyph)].min
    best = overlap_amount(current, glyph, layout, rules, font, max_overlap)
    best = [best, 1].max if layout == :overlap && max_overlap.positive? && visible_width(glyph) > 1
    merge_at(current, glyph, best, layout == :kern ? 0 : rules, font, layout == :overlap)
  end

  def overlap_amount(current, glyph, layout, rules, font, max_overlap)
    best = max_overlap
    constrained = false
    current.each_index do |row|
      a = current[row]
      b = glyph[row]
      ar = last_nonspace(a)
      bl = first_nonspace(b)
      next if ar.nil? || bl.nil?

      constrained = true
      row_best = (a.length - ar - 1) + bl
      if layout == :smush
        left = a[ar]
        right = b[bl]
        row_best += 1 if smush_chars(left, right, rules, font)
      end
      best = [best, row_best].min
    end
    constrained ? [best, max_overlap].min : 0
  end

  def first_nonspace(str)
    str.index(/[^ ]/)
  end

  def last_nonspace(str)
    idx = nil
    str.chars.each_with_index { |ch, i| idx = i if ch != " " }
    idx
  end

  def layout_for(font)
    case @mode_override
    when :full then [:full, 0]
    when :kern then [:kern, 0]
    when :overlap then [:overlap, 0]
    when Integer then [:smush, @mode_override]
    when :force_smush then [:smush, default_rules(font)]
    else
      if font.full_layout
        if (font.full_layout & 128) != 0
          [:smush, font.full_layout & 63]
        elsif (font.full_layout & 64) != 0
          [:kern, 0]
        else
          [:full, 0]
        end
      elsif font.old_layout < 0
        [:full, 0]
      elsif font.old_layout == 0
        [:kern, 0]
      else
        [:smush, font.old_layout & 63]
      end
    end
  end

  def default_rules(font)
    rules = font.full_layout ? font.full_layout & 63 : font.old_layout & 63
    rules.zero? ? 63 : rules
  end

  def merge_at(left_lines, right_lines, overlap, rules, font, overlap_only = false)
    left_lines.each_index.map do |row|
      a = left_lines[row]
      b = right_lines[row]
      if overlap <= 0
        a + b
      else
        prefix = a[0, [a.length - overlap, 0].max] || ""
        merged = +""
        overlap.times do |i|
          lch = a[a.length - overlap + i] || " "
          rch = b[i] || " "
          merged << if overlap_only
                      rch == " " ? lch : rch
                    else
                      smush_chars(lch, rch, rules, font) || rch
                    end
        end
        prefix + merged + (b[overlap..] || "")
      end
    end
  end

  def smush_chars(left, right, rules, font)
    return right if left == " "
    return left if right == " "
    return nil if rules.zero?
    return right if (rules & 1) != 0 && left == right && left != font.hardblank
    if (rules & 2) != 0
      under = "_"
      hard = "|/\\[]{}()<>"
      return right if left == under && hard.include?(right)
      return left if right == under && hard.include?(left)
    end
    if (rules & 4) != 0
      li = HIER.index { |grp| grp.include?(left) }
      ri = HIER.index { |grp| grp.include?(right) }
      return li > ri ? left : right if li && ri && li != ri
    end
    if (rules & 8) != 0
      return "|" if PAIRS[left] == right || PAIRS[right] == left
    end
    if (rules & 16) != 0
      return "|" if left == "/" && right == "\\"
      return "Y" if left == "\\" && right == "/"
      return "X" if left == ">" && right == "<"
    end
    return font.hardblank if (rules & 32) != 0 && left == font.hardblank && right == font.hardblank

    nil
  end

  def justify(lines, font)
    just = @justify
    if just == :auto
      dir = @direction == :auto ? (font.print_direction == 1 ? :rtl : :ltr) : @direction
      just = dir == :rtl ? :right : :left
    end
    return lines if just == :left

    line_width = lines.map { |line| line.rstrip.length }.max || 0
    pad = [@width - line_width, 0].max
    pad = [pad - 1, 0].max if just == :right
    pad = (pad / 2) if just == :center
    lines.map { |line| (" " * pad) + line }
  end

  def strip_left_margin(lines)
    margin = lines.reject { |line| line.strip.empty? }
                  .map { |line| line[/\A */].length }
                  .min || 0
    return lines if margin <= 0

    lines.map { |line| line[margin..] || "" }
  end
end

Figlet.new(ARGV).run if $PROGRAM_NAME == __FILE__
