#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'rexml/document'
require 'optparse'

VERSION = 'svd2rust 0.37.1 (e29353d 2026-03-03)'

HELP_LONG = <<~HELP
  Generate a Rust API from SVD files

  Usage: executable [OPTIONS]

  Options:
    -i <FILE>
            Input SVD file

    -o, --output-dir <PATH>
            Directory to place generated files

    -c, --config <TOML_FILE>
            Config TOML file

        --settings <YAML_FILE>
            Target-specific settings YAML file

        --edition <YEAR>
            Rust edition of generated code

        --target <ARCH>
            Target architecture

        --atomics
            Generate atomic register modification API

        --atomics-feature <FEATURE>
            add feature gating for atomic register modification API

        --ignore-groups
            Don't add alternateGroup name as prefix to register name

        --keep-list
            Keep lists when generating code of dimElement, instead of trying to generate arrays

    -g, --generic-mod
            Push generic mod in separate file

        --feature-group
            Use group_name of peripherals as feature

        --feature-peripheral
            Use independent cfg feature flags for each peripheral

    -f, --ident-format <ident_format>
            Specify `-f type:prefix:case:suffix` to change default ident formatting.
            Allowed values of `type` are ["field_writer", "cluster_mod", "register_spec", "cluster", "enum_value_accessor", "field_accessor", "cluster_accessor", "peripheral_mod", "peripheral_feature", "enum_write_name", "register_accessor", "enum_read_name", "peripheral", "peripheral_singleton", "peripheral_spec", "enum_name", "interrupt", "field_reader", "register_mod", "enum_value", "register"].
            Allowed cases are `unchanged` (''), `pascal` ('p'), `constant` ('c') and `snake` ('s').
            

        --ident-formats-theme <THEME>
            A set of `ident_format` settings. `new` or `legacy`

        --field-names-for-enums
            Use field name for enumerations even when enumeratedValues has a name

        --max-cluster-size
            Use array increment for cluster size

        --impl-debug
            implement Debug for readable blocks and registers

        --impl-debug-feature <FEATURE>
            Add feature gating for block and register debug implementation

        --impl-defmt <FEATURE>
            Add automatic defmt implementation for enumerated values

    -m, --make-mod
            Create mod.rs instead of lib.rs, without inner attributes

        --skip-crate-attributes
            Do not generate crate attributes

    -s, --strict
            Make advanced checks due to parsing SVD

        --source-type <source_type>
            Specify file/stream format

        --reexport-core-peripherals
            For Cortex-M target reexport peripherals from cortex-m crate

        --reexport-interrupt
            Reexport interrupt macro from cortex-m-rt like crates

    -b, --base-address-shift <base_address_shift>
            Add offset to all base addresses on all peripherals in the SVD file.
            Useful for soft-cores where the peripheral address range isn't necessarily fixed.
            Ignore this option if you are not building your own FPGA based soft-cores.

    -l, --log <log_level>
            Choose which messages to log (overrides RUST_LOG)
            
            [possible values: off, error, warn, info, debug, trace]

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
HELP

HELP_SHORT = HELP_LONG.gsub(/\n\s*\n(?=\s{4,}\S)/, "\n")

def log(level, target, msg)
  $stderr.puts "[#{level}  #{target}] #{msg}"
end

def text(el, path)
  n = REXML::XPath.first(el, path)
  n&.text&.strip
end

def children(el, name)
  return [] unless el
  el.elements.select { |e| e.name == name }
end

def int_value(s, default = 0)
  return default if s.nil? || s.strip.empty?
  t = s.strip.gsub('_', '')
  neg = t.start_with?('-')
  t = t[1..] if neg
  v = if t.start_with?('0x', '0X')
        t[2..].to_i(16)
      elsif t.start_with?('#')
        t[1..].to_i(2)
      elsif t =~ /\A[01]+b\z/i
        t[0...-1].to_i(2)
      else
        t.to_i
      end
  neg ? -v : v
end

def rust_hex(n)
  return '0' if n == 0
  s = n.to_i.to_s(16)
  s = '0' + s if s.length.odd?
  "0x#{s.scan(/.{1,4}/).join('_')}"
end

def words(name)
  name.to_s.gsub('%s', '').gsub(/([a-z0-9])([A-Z])/, '\1_\2').split(/[^A-Za-z0-9]+/).reject(&:empty?)
end

def snake(name)
  s = words(name).map(&:downcase).join('_')
  s = "r_#{s}" if s =~ /\A\d/ || RUST_KEYWORDS.include?(s)
  s.empty? ? 'unnamed' : s
end

def pascal(name)
  s = words(name).map { |w| w[0].to_s.upcase + w[1..].to_s.downcase }.join
  s = "R#{s}" if s =~ /\A\d/
  s.empty? ? 'Unnamed' : s
end

def const_name(name)
  s = words(name).map(&:upcase).join('_')
  s = "R_#{s}" if s =~ /\A\d/
  s.empty? ? 'UNNAMED' : s
end

RUST_KEYWORDS = %w[
  as break const continue crate else enum extern false fn for if impl in let loop match mod move mut
  pub ref return self Self static struct super trait true type unsafe use where while async await dyn
  abstract become box do final macro override priv try typeof unsized virtual yield
].freeze

def clean_doc(s)
  s.to_s.gsub(/\s+/, ' ').strip.gsub('"', '\"')
end

def doc_attr(s)
  "#[doc = \"#{clean_doc(s)}\"]"
end

class Field
  attr_accessor :name, :description, :lsb, :width, :access, :enums
  def initialize(el, inherited_access)
    @name = text(el, 'name') || 'FIELD'
    @description = text(el, 'description') || ''
    @access = text(el, 'access') || inherited_access
    if (range = text(el, 'bitRange')) && range =~ /\[(\d+):(\d+)\]/
      msb = Regexp.last_match(1).to_i
      lsb = Regexp.last_match(2).to_i
      @lsb = lsb
      @width = msb - lsb + 1
    else
      @lsb = int_value(text(el, 'bitOffset') || text(el, 'lsb'), 0)
      @width = int_value(text(el, 'bitWidth'), nil)
      @width ||= int_value(text(el, 'msb'), @lsb) - @lsb + 1
    end
    @width = 1 if @width <= 0
    @enums = []
    children(el, 'enumeratedValues').each do |evs|
      children(evs, 'enumeratedValue').each do |ev|
        @enums << {
          name: text(ev, 'name') || "VALUE#{@enums.length}",
          desc: text(ev, 'description') || '',
          value: int_value(text(ev, 'value'), @enums.length)
        }
      end
    end
  end

  def readable?
    !%w[write-only writeOnce].include?(@access)
  end

  def writable?
    !%w[read-only readOnce].include?(@access)
  end
end

class Register
  attr_accessor :name, :description, :offset, :size, :access, :reset, :fields, :dim, :dim_increment
  def initialize(el, inherited = {})
    @name = text(el, 'name') || 'REG'
    @description = text(el, 'description') || ''
    @offset = int_value(text(el, 'addressOffset'), 0)
    @size = int_value(text(el, 'size'), inherited[:size] || 32)
    @access = text(el, 'access') || inherited[:access] || 'read-write'
    @reset = int_value(text(el, 'resetValue'), inherited[:reset] || 0)
    @dim = int_value(text(el, 'dim'), 1)
    @dim_increment = int_value(text(el, 'dimIncrement'), [@size / 8, 1].max)
    @fields = []
    if (fs = REXML::XPath.first(el, 'fields'))
      children(fs, 'field').each { |f| @fields << Field.new(f, @access) }
    end
  end

  def readable?
    !%w[write-only writeOnce].include?(@access)
  end

  def writable?
    !%w[read-only readOnce].include?(@access)
  end

  def type_name
    pascal(@name)
  end

  def mod_name
    snake(@name)
  end

  def elem_bytes
    [@size / 8, 1].max
  end
end

class Peripheral
  attr_accessor :name, :description, :base, :registers, :group_name, :derived_from
  def initialize(el, device_defaults, by_name)
    @name = text(el, 'name') || 'PERIPH'
    @description = text(el, 'description') || ''
    @base = int_value(text(el, 'baseAddress'), 0)
    @group_name = text(el, 'groupName')
    @derived_from = el.attributes['derivedFrom']
    @registers = []
    if @derived_from && by_name[@derived_from]
      src = by_name[@derived_from]
      @description = src.description if @description.empty?
      @registers = src.registers.map(&:dup)
    end
    if (rs = REXML::XPath.first(el, 'registers'))
      children(rs, 'register').each { |r| @registers << Register.new(r, device_defaults) }
    end
  end

  def type_name
    pascal(@name)
  end

  def mod_name
    snake(@name)
  end
end

class Device
  attr_accessor :name, :description, :width, :peripherals, :interrupts
  def initialize(doc)
    root = doc.root
    raise 'the document does not have a root node' unless root
    @name = text(root, 'name') || 'DEVICE'
    @description = text(root, 'description') || ''
    @width = int_value(text(root, 'width'), 32)
    defaults = {
      size: @width,
      access: text(root, 'access') || 'read-write',
      reset: int_value(text(root, 'resetValue'), 0)
    }
    @peripherals = []
    by_name = {}
    if (ps = REXML::XPath.first(root, 'peripherals'))
      children(ps, 'peripheral').each do |p|
        per = Peripheral.new(p, defaults, by_name)
        @peripherals << per
        by_name[per.name] = per
      end
    end
    @interrupts = []
    @peripherals.each do |p|
      # Find source node again for interrupts.
      pel = REXML::XPath.first(root, "peripherals/peripheral[name='#{p.name}']")
      next unless pel
      children(pel, 'interrupt').each do |intr|
        @interrupts << {
          name: text(intr, 'name') || 'INTERRUPT',
          desc: text(intr, 'description') || '',
          value: int_value(text(intr, 'value'), @interrupts.length)
        }
      end
    end
    @interrupts.uniq! { |i| i[:name] }
  end
end

class Generator
  def initialize(device, opts)
    @device = device
    @opts = opts
  end

  def emit(outdir)
    FileUtils.mkdir_p(outdir)
    main = @opts[:make_mod] ? 'mod.rs' : 'lib.rs'
    File.write(File.join(outdir, main), lib_rs)
    File.write(File.join(outdir, 'generic.rs'), generic_mod) if @opts[:generic_mod]
    File.write(File.join(outdir, 'build.rs'), build_rs)
    File.write(File.join(outdir, 'device.x'), device_x)
  end

  def lib_rs
    s = +""
    unless @opts[:make_mod] || @opts[:skip_crate_attributes]
      s << "#![doc = \"Peripheral access API for #{@device.name} microcontrollers (generated using svd2rust v0.37.1 (e29353d 2026-03-03))\"]\n"
      s << "#![allow(non_camel_case_types)]\n#![allow(non_snake_case)]\n#![no_std]\n"
    end
    if @opts[:generic_mod]
      s << "mod generic;\npub use generic::*;\n"
    else
      s << generic_mod
    end
    s << interrupts
    @device.peripherals.each { |p| s << peripheral_alias(p) << peripheral_mod(p) }
    s << peripherals_struct
    s
  end

  def generic_mod
    <<~RS
      #[doc = "Common register and bit access and modify traits"]
      pub mod generic {
          use core::cell::UnsafeCell;
          use core::marker::PhantomData;
          pub struct Periph<PER: PeripheralSpec> { _marker: PhantomData<PER> }
          pub trait PeripheralSpec { type RB; const ADDRESS: usize; const NAME: &'static str; }
          unsafe impl<PER: PeripheralSpec> Send for Periph<PER> {}
          impl<PER: PeripheralSpec> Periph<PER> {
              pub const PTR: *const PER::RB = PER::ADDRESS as *const _;
              #[inline(always)] pub const fn ptr() -> *const PER::RB { Self::PTR }
              #[inline(always)] pub unsafe fn steal() -> Self { Self { _marker: PhantomData } }
          }
          impl<PER: PeripheralSpec> core::ops::Deref for Periph<PER> {
              type Target = PER::RB;
              #[inline(always)] fn deref(&self) -> &Self::Target { unsafe { &*Self::PTR } }
          }
          pub trait RegisterSpec { type Ux: Copy + Default + From<u8> + core::fmt::Debug; }
          pub trait Readable: RegisterSpec {}
          pub trait Writable: RegisterSpec { type Safety; }
          pub trait Resettable: RegisterSpec { const RESET_VALUE: Self::Ux; #[inline(always)] fn reset_value() -> Self::Ux { Self::RESET_VALUE } }
          pub struct Unsafe;
          #[repr(transparent)] pub struct Reg<REG: RegisterSpec> { register: UnsafeCell<REG::Ux> }
          unsafe impl<REG: RegisterSpec> Send for Reg<REG> {}
          impl<REG: RegisterSpec> Reg<REG> {
              #[inline(always)] pub const fn ptr(&self) -> *mut REG::Ux { self.register.get() }
          }
          pub struct R<REG: RegisterSpec> { bits: REG::Ux, _reg: PhantomData<REG> }
          impl<REG: RegisterSpec> R<REG> { #[inline(always)] pub const fn bits(&self) -> REG::Ux { self.bits } }
          pub struct W<REG: RegisterSpec> { bits: REG::Ux, _reg: PhantomData<REG> }
          impl<REG: Writable> W<REG> { #[inline(always)] pub unsafe fn bits(&mut self, bits: REG::Ux) -> &mut Self { self.bits = bits; self } }
          impl<REG: Readable> Reg<REG> {
              #[inline(always)] pub fn read(&self) -> R<REG> { R { bits: unsafe { core::ptr::read_volatile(self.ptr()) }, _reg: PhantomData } }
          }
          impl<REG: Writable> Reg<REG> {
              #[inline(always)] pub fn write<F>(&self, f: F) where F: FnOnce(&mut W<REG>) -> &mut W<REG>, REG::Ux: Default { let mut w = W { bits: Default::default(), _reg: PhantomData }; f(&mut w); unsafe { core::ptr::write_volatile(self.ptr(), w.bits) } }
              #[inline(always)] pub fn write_with_zero<F>(&self, f: F) where F: FnOnce(&mut W<REG>) -> &mut W<REG>, REG::Ux: Default { self.write(f) }
          }
          impl<REG: Writable + Readable> Reg<REG> {
              #[inline(always)] pub fn modify<F>(&self, f: F) where for<'w> F: FnOnce(&R<REG>, &'w mut W<REG>) -> &'w mut W<REG> { let bits = unsafe { core::ptr::read_volatile(self.ptr()) }; let r = R { bits, _reg: PhantomData }; let mut w = W { bits, _reg: PhantomData }; f(&r, &mut w); unsafe { core::ptr::write_volatile(self.ptr(), w.bits) } }
          }
          impl<REG: Resettable + Writable> Reg<REG> { #[inline(always)] pub fn reset(&self) { unsafe { core::ptr::write_volatile(self.ptr(), REG::RESET_VALUE) } } }
          pub struct FieldReader<FI = u8> { bits: FI }
          impl<FI: Copy> FieldReader<FI> { #[inline(always)] pub const fn new(bits: FI) -> Self { Self { bits } } #[inline(always)] pub const fn bits(&self) -> FI { self.bits } }
          impl FieldReader<bool> { #[inline(always)] pub const fn bit(&self) -> bool { self.bits } #[inline(always)] pub const fn bit_is_set(&self) -> bool { self.bits } #[inline(always)] pub const fn bit_is_clear(&self) -> bool { !self.bits } }
          pub struct BitReader<FI = bool> { bits: bool, _f: PhantomData<FI> }
          impl<FI> BitReader<FI> { #[inline(always)] pub const fn new(bits: bool) -> Self { Self { bits, _f: PhantomData } } #[inline(always)] pub const fn bit(&self) -> bool { self.bits } #[inline(always)] pub const fn bit_is_set(&self) -> bool { self.bits } #[inline(always)] pub const fn bit_is_clear(&self) -> bool { !self.bits } }
          pub struct FieldWriter<'a, REG: Writable, const WI: u8, FI = u8> { w: &'a mut W<REG>, o: u8, _f: PhantomData<FI> }
          impl<'a, REG, const WI: u8, FI> FieldWriter<'a, REG, WI, FI>
          where REG: Writable, REG::Ux: From<u8> + Copy + core::ops::Shl<u8, Output = REG::Ux> + core::ops::Sub<Output = REG::Ux> + core::ops::BitAnd<Output = REG::Ux> + core::ops::BitOr<Output = REG::Ux> + core::ops::Not<Output = REG::Ux> {
              #[inline(always)] pub fn new(w: &'a mut W<REG>, o: u8) -> Self { Self { w, o, _f: PhantomData } }
              #[inline(always)] pub unsafe fn bits(self, value: REG::Ux) -> &'a mut W<REG> { let one = REG::Ux::from(1); let mask = ((one << WI) - one) << self.o; self.w.bits = (self.w.bits & !mask) | ((value << self.o) & mask); self.w }
          }
          pub struct BitWriter<'a, REG: Writable, FI = bool> { w: &'a mut W<REG>, o: u8, _f: PhantomData<FI> }
          impl<'a, REG: Writable, FI> BitWriter<'a, REG, FI> where REG::Ux: From<u8> + Copy + core::ops::Shl<u8, Output = REG::Ux> + core::ops::BitAnd<Output = REG::Ux> + core::ops::BitOr<Output = REG::Ux> + core::ops::Not<Output = REG::Ux> {
              #[inline(always)] pub fn new(w: &'a mut W<REG>, o: u8) -> Self { Self { w, o, _f: PhantomData } }
              #[inline(always)] pub fn set_bit(self) -> &'a mut W<REG> { self.bit(true) }
              #[inline(always)] pub fn clear_bit(self) -> &'a mut W<REG> { self.bit(false) }
              #[inline(always)] pub fn bit(self, value: bool) -> &'a mut W<REG> { let mask = REG::Ux::from(1) << self.o; if value { self.w.bits = self.w.bits | mask; } else { self.w.bits = self.w.bits & !mask; } self.w }
          }
      }
      pub use generic::*;
    RS
  end

  def interrupts
    names = @device.interrupts.map { |i| "#{doc_attr(i[:desc])}\n    #{pascal(i[:name])} = #{i[:value]}," }.join("\n")
    match = @device.interrupts.map { |i| "Interrupt::#{pascal(i[:name])} => #{i[:value]}," }.join
    <<~RS
      #[cfg(feature = "rt")]
      extern "C" {}
      #[doc = r"Enumeration of all the interrupts."]
      #[derive(Copy, Clone, Debug, PartialEq, Eq)]
      #[repr(u16)]
      pub enum Interrupt {
      #{names}
      }
      impl Interrupt { #[inline(always)] pub fn number(self) -> u16 { match self { #{match} } } }
    RS
  end

  def peripheral_alias(p)
    addr = rust_hex(p.base + @opts[:base_shift].to_i)
    <<~RS
      #{doc_attr(p.description)}
      pub type #{p.type_name} = crate::Periph<#{p.type_name}Spec>;
      pub struct #{p.type_name}Spec;
      impl crate::PeripheralSpec for #{p.type_name}Spec {
          type RB = #{p.mod_name}::RegisterBlock;
          const ADDRESS: usize = #{addr};
          const NAME: &'static str = "#{p.type_name}";
      }
    RS
  end

  def peripheral_mod(p)
    regs = p.registers.sort_by(&:offset)
    body = +"#{doc_attr(p.description)}\npub mod #{p.mod_name} {\n"
    body << "    #[repr(C)]\n    #[doc = \"Register block\"]\n    pub struct RegisterBlock {\n"
    off = 0
    reserved = 0
    regs.each do |r|
      if r.offset > off
        body << "        _reserved#{reserved}: [u8; #{r.offset - off}],\n"
        reserved += 1
      end
      field_ty = r.dim > 1 ? "[#{r.type_name}; #{r.dim}]" : r.type_name
      body << "        #{snake(r.name)}: #{field_ty},\n"
      off = r.offset + (r.dim > 1 ? r.dim * r.dim_increment : r.elem_bytes)
    end
    body << "    }\n    impl RegisterBlock {\n"
    regs.each do |r|
      ret = r.dim > 1 ? "&#{r.type_name}" : "&#{r.type_name}"
      if r.dim > 1
        body << "        #{doc_attr(format('0x%02x - %s', r.offset, r.description))}\n"
        body << "        #[inline(always)] pub const fn #{snake(r.name).gsub(/_?%s/, '')}(&self, n: usize) -> #{ret} { &self.#{snake(r.name)}[n] }\n"
      else
        body << "        #{doc_attr(format('0x%02x - %s', r.offset, r.description))}\n"
        body << "        #[inline(always)] pub const fn #{r.mod_name}(&self) -> #{ret} { &self.#{r.mod_name} }\n"
      end
    end
    body << "    }\n"
    regs.each { |r| body << register_type(r) << register_mod(r) }
    body << "}\n"
    body
  end

  def register_type(r)
    rw = r.readable? && r.writable? ? 'rw' : (r.readable? ? 'r' : 'w')
    <<~RS
      #[doc = "#{r.name} (#{rw}) register accessor: #{clean_doc(r.description)}"]
      #[doc(alias = "#{r.name}")]
      pub type #{r.type_name} = crate::Reg<#{r.mod_name}::#{r.type_name}Spec>;
    RS
  end

  def ux(size)
    size <= 8 ? 'u8' : size <= 16 ? 'u16' : size <= 32 ? 'u32' : 'u64'
  end

  def register_mod(r)
    u = ux(r.size)
    m = +"#{doc_attr(r.description)}\npub mod #{r.mod_name} {\n"
    m << "    #[doc = \"Register `#{r.name}` reader\"] pub type R = crate::R<#{r.type_name}Spec>;\n" if r.readable?
    m << "    #[doc = \"Register `#{r.name}` writer\"] pub type W = crate::W<#{r.type_name}Spec>;\n" if r.writable?
    r.fields.each do |f|
      tn = pascal(f.name)
      if f.width == 1
        m << "    #{doc_attr("Field `#{f.name}` reader - #{f.description}")} pub type #{tn}R = crate::BitReader;\n" if f.readable?
        m << "    #{doc_attr("Field `#{f.name}` writer - #{f.description}")} pub type #{tn}W<'a, REG> = crate::BitWriter<'a, REG>;\n" if f.writable?
      else
        m << "    #{doc_attr("Field `#{f.name}` reader - #{f.description}")} pub type #{tn}R = crate::FieldReader<#{u}>;\n" if f.readable?
        m << "    #{doc_attr("Field `#{f.name}` writer - #{f.description}")} pub type #{tn}W<'a, REG> = crate::FieldWriter<'a, REG, #{f.width}, #{u}>;\n" if f.writable?
      end
      m << enum_mod(f, u) unless f.enums.empty?
    end
    if r.readable?
      m << "    impl R {\n"
      r.fields.select(&:readable?).each { |f| m << reader_method(f, u) }
      m << "    }\n"
    end
    if r.writable?
      m << "    impl W {\n"
      r.fields.select(&:writable?).each { |f| m << writer_method(f, r) }
      m << "    }\n"
    end
    m << "    #{doc_attr(r.description)} pub struct #{r.type_name}Spec;\n"
    m << "    impl crate::RegisterSpec for #{r.type_name}Spec { type Ux = #{u}; }\n"
    m << "    impl crate::Readable for #{r.type_name}Spec {}\n" if r.readable?
    m << "    impl crate::Writable for #{r.type_name}Spec { type Safety = crate::Unsafe; }\n" if r.writable?
    m << "    impl crate::Resettable for #{r.type_name}Spec { const RESET_VALUE: Self::Ux = #{rust_hex(r.reset)}; }\n"
    m << "}\n"
    m
  end

  def enum_mod(f, u)
    enum_name = pascal(f.name)
    variants = f.enums.map { |e| "        #{doc_attr(e[:desc])}\n        #{pascal(e[:name])} = #{e[:value]}," }.join("\n")
    <<~RS
          #[derive(Clone, Copy, Debug, PartialEq, Eq)]
          #[repr(#{u})]
          pub enum #{enum_name} {
      #{variants}
          }
          impl From<#{enum_name}> for #{u} { #[inline(always)] fn from(v: #{enum_name}) -> Self { v as Self } }
    RS
  end

  def reader_method(f, u)
    nm = snake(f.name)
    tn = pascal(f.name)
    if f.width == 1
      "        #{doc_attr("Bit #{f.lsb} - #{f.description}")}\n        #[inline(always)] pub fn #{nm}(&self) -> #{tn}R { #{tn}R::new((self.bits() & #{rust_hex(1 << f.lsb)}) != 0) }\n"
    else
      mask = (1 << f.width) - 1
      range = "Bits #{f.lsb}:#{f.lsb + f.width - 1}"
      "        #{doc_attr("#{range} - #{f.description}")}\n        #[inline(always)] pub fn #{nm}(&self) -> #{tn}R { #{tn}R::new(((self.bits() >> #{f.lsb}) & #{rust_hex(mask)}) as #{u}) }\n"
    end
  end

  def writer_method(f, r)
    nm = snake(f.name)
    tn = pascal(f.name)
    spec = "#{r.type_name}Spec"
    "        #{doc_attr("Field `#{f.name}` writer - #{f.description}")}\n        #[inline(always)] pub fn #{nm}(&mut self) -> #{tn}W<'_, #{spec}> { #{tn}W::new(self, #{f.lsb}) }\n"
  end

  def peripherals_struct
    fields = @device.peripherals.map { |p| "    #[doc = \"#{p.name}\"] pub #{p.mod_name}: #{p.type_name}," }.join("\n")
    inits = @device.peripherals.map { |p| "            #{p.mod_name}: #{p.type_name}::steal()," }.join("\n")
    <<~RS
      static mut DEVICE_PERIPHERALS: bool = false;
      #[doc = r"All the peripherals."]
      #[allow(non_snake_case)]
      pub struct Peripherals {
      #{fields}
      }
      impl Peripherals {
          #[inline] pub fn take() -> Option<Self> {
              if unsafe { DEVICE_PERIPHERALS } { None } else { Some(unsafe { Self::steal() }) }
          }
          #[inline] pub unsafe fn steal() -> Self {
              DEVICE_PERIPHERALS = true;
              Peripherals {
      #{inits}
              }
          }
      }
    RS
  end

  def build_rs
    '#![doc = r" Builder file for Peripheral access crate generated by svd2rust tool"] use std::env; use std::fs::File; use std::io::Write; use std::path::PathBuf; fn main(){ if env::var_os("CARGO_FEATURE_RT").is_some(){ let out=&PathBuf::from(env::var_os("OUT_DIR").unwrap()); File::create(out.join("device.x")).unwrap().write_all(include_bytes!("device.x")).unwrap(); println!("cargo:rustc-link-search={}", out.display()); println!("cargo:rerun-if-changed=device.x"); } println!("cargo:rerun-if-changed=build.rs"); }' + "\n"
  end

  def device_x
    @device.interrupts.map { |i| "#{const_name(i[:name])} = #{i[:value]};" }.join("\n") + "\n"
  end
end

def parse_args(argv)
  opts = { output: '.', base_shift: 0 }
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when '-h'
      puts HELP_SHORT
      exit 0
    when '--help'
      puts HELP_LONG
      exit 0
    when '-V', '--version'
      puts VERSION
      exit 0
    when '-i'
      opts[:input] = argv[i += 1]
    when '-o', '--output-dir'
      opts[:output] = argv[i += 1]
    when '-c', '--config'
      opts[:config] = argv[i += 1]
    when '--settings'
      opts[:settings] = argv[i += 1]
    when '--edition'
      opts[:edition] = argv[i += 1]
    when '--target'
      opts[:target] = argv[i += 1]
    when '--atomics'
      opts[:atomics] = true
    when '--atomics-feature'
      opts[:atomics_feature] = argv[i += 1]
    when '--ignore-groups'
      opts[:ignore_groups] = true
    when '--keep-list'
      opts[:keep_list] = true
    when '-g', '--generic-mod'
      opts[:generic_mod] = true
    when '--feature-group'
      opts[:feature_group] = true
    when '--feature-peripheral'
      opts[:feature_peripheral] = true
    when '-f', '--ident-format'
      (opts[:ident_formats] ||= []) << argv[i += 1]
    when '--ident-formats-theme'
      opts[:ident_theme] = argv[i += 1]
    when '--field-names-for-enums'
      opts[:field_names_for_enums] = true
    when '--max-cluster-size'
      opts[:max_cluster_size] = true
    when '--impl-debug'
      opts[:impl_debug] = true
    when '--impl-debug-feature'
      opts[:impl_debug_feature] = argv[i += 1]
    when '--impl-defmt'
      opts[:impl_defmt] = argv[i += 1]
    when '-m', '--make-mod'
      opts[:make_mod] = true
    when '--skip-crate-attributes'
      opts[:skip_crate_attributes] = true
    when '-s', '--strict'
      opts[:strict] = true
    when '--source-type'
      opts[:source_type] = argv[i += 1]
    when '--reexport-core-peripherals'
      opts[:reexport_core_peripherals] = true
    when '--reexport-interrupt'
      opts[:reexport_interrupt] = true
    when '-b', '--base-address-shift'
      opts[:base_shift] = int_value(argv[i += 1], 0)
    when '-l', '--log'
      opts[:log] = argv[i += 1]
    else
      if a.start_with?('-')
        $stderr.puts "error: unexpected argument '#{a}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'."
      else
        $stderr.puts "error: unexpected argument '#{a}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'."
      end
      exit 2
    end
    i += 1
  end
  opts
end

begin
  opts = parse_args(ARGV)
  log('INFO', 'svd2rust', 'Parsing device from SVD file')
  input = opts[:input]
  xml = input ? File.read(input) : STDIN.read
  doc = REXML::Document.new(xml)
  dev = Device.new(doc)
  log('INFO', 'svd2rust', 'Rendering device')
  dev.peripherals.each do |p|
    p.registers.each do |r|
      next unless r.description.empty?
      log('WARN', 'svd2rust::generate::register', "Missing description for register #{r.name}")
      log('WARN', 'svd2rust::generate::register', "Missing description for register #{r.name}") if r.fields.empty?
    end
  end
  Generator.new(dev, opts).emit(opts[:output])
rescue Errno::ENOENT => e
  log('ERROR', 'svd2rust', 'Cannot open the SVD file')
  $stderr.puts "    \n    Caused by:\n        #{e.message.sub(/ @ .*/, '')}"
  exit 1
rescue REXML::ParseException => e
  log('ERROR', 'svd2rust', 'Error parsing SVD XML file')
  msg = e.message.lines.first.to_s.strip
  msg = 'the document does not have a root node' if msg.empty? || msg.include?('Missing end tag')
  $stderr.puts "    \n    Caused by:\n        #{msg}"
  exit 1
rescue StandardError => e
  log('ERROR', 'svd2rust', e.message)
  exit 1
end
