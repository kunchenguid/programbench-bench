#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = "pueue 4.0.4"

COMMANDS = %w[
  add remove switch stash enqueue start restart pause kill send edit env group status log follow wait
  clean reset shutdown parallel completions
].freeze

ROOT_SHORT = <<~TEXT.chomp
  Interact with the Pueue daemon

  Use the `--help` long form to get detailed help output on each subcommand!

  Usage: executable [OPTIONS] [COMMAND]

  Commands:
    add          Enqueue a task for execution
    remove       Remove tasks from the list. Running or paused tasks need to be killed first
    switch       Switches the queue position of two commands
    stash        Stash a task. Stashed tasks won't be automatically started
    enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
    start        Resume operation of specific tasks or groups of tasks
    restart      Restart failed or successful task(s)
    pause        Either pause running tasks or specific groups of tasks
    kill         Kill specific running tasks or whole task groups
    send         Send something to a task. Useful for sending confirmations such as 'y\\n'
    edit         Adjust editable properties of a task
    env          Use this to add or remove environment variables from tasks
    group        Use this to add or remove groups
    status       Display the current status of all tasks
    log          Display the log output of finished tasks
    follow       Follow the output of a currently running task. This command works like "tail -f"
    wait         Wait until tasks are finished
    clean        Remove all finished tasks from the list
    reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
    shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
                 service manager
    parallel     Set the amount of allowed parallel tasks
    completions  Generates shell completion files
    help         Print this message or the help of the given subcommand(s)

  Options:
    -v, --verbose...         Verbose mode (-v, -vv, -vvv)
        --color <COLOR>      Colorize the output; auto enables color output when connected to a tty
                             [default: auto] [possible values: auto, never, always]
    -c, --config <CONFIG>    If provided, Pueue only uses this config file
    -p, --profile <PROFILE>  The name of the profile that should be loaded from your config file
    -h, --help               Print help (see more with '--help')
    -V, --version            Print version
TEXT

ROOT_LONG = ROOT_SHORT.sub("Options:\n  -v, --verbose...         Verbose mode (-v, -vv, -vvv)", "Options:\n  -v, --verbose...\n          Verbose mode (-v, -vv, -vvv)")
                     .sub("      --color <COLOR>      Colorize the output; auto enables color output when connected to a tty\n                           [default: auto] [possible values: auto, never, always]",
                          "      --color <COLOR>\n          Colorize the output; auto enables color output when connected to a tty\n          \n          [default: auto]\n          [possible values: auto, never, always]")
                     .sub("  -c, --config <CONFIG>    If provided, Pueue only uses this config file",
                          "  -c, --config <CONFIG>\n          If provided, Pueue only uses this config file.\n          \n          This path can also be set via the \"PUEUE_CONFIG_PATH\" environment variable. The\n          commandline option overwrites the environment variable!")
                     .sub("  -p, --profile <PROFILE>  The name of the profile that should be loaded from your config file",
                          "  -p, --profile <PROFILE>\n          The name of the profile that should be loaded from your config file")
                     .sub("  -h, --help               Print help (see more with '--help')", "  -h, --help\n          Print help (see a summary with '-h')")
                     .sub("  -V, --version            Print version", "  -V, --version\n          Print version")

HELP = {
  "add" => <<~TEXT.chomp,
    Enqueue a task for execution.

    There're many different options when scheduling a task. Check the individual option help texts for
    more information. Furthermore, please remember that scheduled commands are executed via your system
    shell. This means that the command needs proper shell escaping. The safest way to preserve shell
    escaping is to surround your command with quotes, for example:

    pueue add 'ls $HOME && echo \\"Some string\\"'

    Usage: executable add [OPTIONS] <COMMAND>...

    Arguments:
      <COMMAND>...
              The command to be added

    Options:
      -w, --working-directory <working-directory>
              Specify current working directory

      -e, --escape
              Escape any special shell characters (" ", "&", "!", etc.).
              Beware: This implicitly disables nearly all shell specific syntax ("&&", "&>").

      -i, --immediate
              Immediately start the task

          --follow
              Immediately follow a task, if it's started with --immediate

      -s, --stashed
              Create the task in Stashed state.
              
              Useful to avoid immediate execution if the queue is empty.

      -d, --delay <delay>
              Prevents the task from being enqueued until 'delay' elapses. See "enqueue" for accepted
              formats

      -g, --group <GROUP>
              Assign the task to a group.
              
              Groups kind of act as separate queues. All groups run in parallel and you can specify the
              amount of parallel tasks for each group. If no group is specified, the default group will
              be used.
              
              Create groups via the `pueue group` subcommand

      -a, --after <after>...
              Start the task once all specified tasks have successfully finished.
              
              As soon as one of the dependencies fails, this task will fail as well.

      -o, --priority <PRIORITY>
              Start this task with a higher priority.
              
              The higher the number, the faster it will be processed.

      -l, --label <LABEL>
              Add some information for yourself.
              
              This string will be shown in the "status" table. There's no additional logic connected to
              it.

      -p, --print-task-id
              Only return the task id instead of a text.
              
              This is useful when working with dependencies in scripts.

      -h, --help
              Print help (see a summary with '-h')
  TEXT
  "remove" => "Remove tasks from the list. Running or paused tasks need to be killed first\n\nUsage: executable remove <TASK_IDS>...\n\nArguments:\n  <TASK_IDS>...  The task ids to be removed\n\nOptions:\n  -h, --help  Print help",
  "switch" => "Switches the queue position of two commands.\n\nOnly works on queued and stashed commands.\n\nUsage: executable switch <TASK_ID_1> <TASK_ID_2>\n\nArguments:\n  <TASK_ID_1>\n          The first task id\n\n  <TASK_ID_2>\n          The second task id\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')",
  "stash" => "Stash a task. Stashed tasks won't be automatically started.\n\nThe enqueue an item, use the `pueue enqueue` subcommand. Stashed entries can also be explicitely\nstarted via `pueue start $task_id`.\n\nUsage: executable stash [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Stash these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          Stash all queued tasks in a group\n\n  -a, --all\n          Stash all queued tasks across all groups\n\n  -d, --delay <delay>\n          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below\n\n  -h, --help\n          Print help (see a summary with '-h')",
  "enqueue" => "Enqueue stashed tasks. They'll be handled normally afterwards.\n\nEnqueues all stashed task in the default group if no arguments are given.\n\nUsage: executable enqueue [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Enqueue these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          Enqueue all stashed tasks in a group\n\n  -a, --all\n          Enqueue all stashed tasks across all groups\n\n  -d, --delay <delay>\n          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nDELAY FORMAT:\n\n    The --delay argument must be either a number of seconds or a \"date expression\" similar to GNU\n    \"date -d\" with some extensions. It does not attempt to parse all natural language, but is\n    incredibly flexible. Here are some supported examples.\n\n    2020-04-01T18:30:00   // RFC 3339 timestamp\n    2020-4-1 18:2:30      // Optional leading zeros\n    2020-4-1 5:30pm       // Informal am/pm time\n    2020-4-1 5pm          // Optional minutes and seconds\n    April 1 2020 18:30:00 // English months\n    1 Apr 8:30pm          // Implies current year\n    4/1                   // American form date\n    wednesday 10:30pm     // The closest wednesday in the future at 22:30\n    wednesday             // The closest wednesday in the future\n    4 months              // 4 months from today at 00:00:00\n    1 week                // 1 week at the current time\n    1days                 // 1 day from today at the current time\n    1d 03:00              // The closest 3:00 after 1 day (24 hours)\n    3h                    // 3 hours from now\n    3600s                 // 3600 seconds from now",
  "start" => "Resume operation of specific tasks or groups of tasks.\n\nWithout any parameters this resumes the default group and all its tasks. Can also be used\nforce-start specific tasks, which **ignores** any group parallelism limits or dependencies a task my\nhave!\n\nUsage: executable start [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Start these specific tasks. Paused tasks will resumed. Queued/Stashed tasks will be\n          force-started\n\nOptions:\n  -g, --group <GROUP>\n          Resume a specific group and all paused tasks in it.\n          \n          The group will be set to running and its paused tasks will be resumed.\n\n  -a, --all\n          Resume all groups!\n          \n          All groups will be set to running and paused tasks will be resumed.\n\n  -h, --help\n          Print help (see a summary with '-h')",
  "restart" => "Restart failed or successful task(s).\n\nBy default, identical tasks will be created and enqueued, but it's possible to restart in-place. You\ncan also edit a few properties, such as the path and the command, before restarting.\n\nUsage: executable restart [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Restart these specific tasks\n\nOptions:\n  -a, --all-failed\n          Restart all failed tasks across all groups.\n          \n          This is nice for usage in combination with `-i/--in-place` (or the respective config\n          option).\n\n  -g, --failed-in-group <FAILED_IN_GROUP>\n          Like `--all-failed`, but only restart tasks failed tasks of a specific group\n\n  -k, --immediate\n          Immediately start the tasks, no matter how many open slots there are. This will ignore any\n          dependencies tasks may have\n\n  -s, --stashed\n          Set the restarted task to a \"Stashed\" state. Useful to avoid immediate execution\n\n  -i, --in-place\n          Restart the task by reusing the already existing tasks. This will overwrite any previous\n          logs of the restarted tasks.\n          \n          This can also be enabled by default via the `restart_in_place` config option.\n\n      --not-in-place\n          Restart the task by creating a new identical tasks. Only necessary if you have the\n          `restart_in_place` configuration set to true\n\n  -e, --edit\n          Edit the task before restarting\n\n  -h, --help\n          Print help (see a summary with '-h')",
  "pause" => "Either pause running tasks or specific groups of tasks.\n\nBy default, pauses the default group and all its tasks. A paused queue (group) won't start any new\ntasks.\n\nUsage: executable pause [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Pause these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          Pause a specific group\n\n  -a, --all\n          Pause all groups!\n\n  -w, --wait\n          Pause the specified groups, but let already running tasks finish by themselves\n\n  -h, --help\n          Print help (see a summary with '-h')",
  "kill" => "Kill specific running tasks or whole task groups.\n\nKills all tasks of the default group when no ids or a specific group are provided.\n\nUsage: executable kill [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Kill these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          Kill all running tasks in a group. This also pauses the group\n\n  -a, --all\n          Kill all running tasks across ALL groups. This also pauses all groups\n\n  -s, --signal <SIGNAL>\n          Send a UNIX signal instead of simply killing the process.\n          \n          DISCLAIMER: This bypasses Pueue's process handling logic! You might enter weird invalid\n          states, use at your own descretion.\n          \n          This argument also excepts the integer representation as well as the signal short name.\n          E.g. `sigint`, `int`, or `2` are the same.\n\n  -h, --help\n          Print help (see a summary with '-h')",
  "send" => "Send something to a task. Useful for sending confirmations such as 'y\\n'\n\nUsage: executable send <TASK_ID> <INPUT>\n\nArguments:\n  <TASK_ID>  The id of the task\n  <INPUT>    The input that should be sent to the process\n\nOptions:\n  -h, --help  Print help",
  "edit" => "Adjust editable properties of a task.\n\nOnly stashed or queued tasks can be edited. A temporary folder folder/file will be opened by your\n$EDITOR to edit the tasks.\n\nUsage: executable edit [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          The ids of all tasks that should be edited\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')",
  "env" => "Use this to add or remove environment variables from tasks\n\nUsage: executable env <COMMAND>\n\nCommands:\n  set    Set a variable for a specific task's environment\n  unset  Remove a specific variable from a task's environment\n  help   Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help  Print help",
  "group" => "Use this to add or remove groups.\n\nBy default, this will simply display all known groups.\n\nUsage: executable group [OPTIONS] [COMMAND]\n\nCommands:\n  add     Add a group by name\n  remove  Remove a group by name. This will move all tasks in this group to the default group!\n  help    Print this message or the help of the given subcommand(s)\n\nOptions:\n  -j, --json\n          Print the list of groups as json\n\n  -h, --help\n          Print help (see a summary with '-h')",
  "status" => "Display the current status of all tasks\n\nUsage: executable status [OPTIONS] [QUERY]...\n\nArguments:\n  [QUERY]...\n          Users can specify a custom query to filter for specific values, order by a column\n          or limit the amount of tasks listed.\n          \n          Syntax:\n             [column_selection]? [filter]* [order_by]? [limit]?\n          \n          where:\n            - column_selection := `columns=[column]([column],)*`\n            - column := `id | status | command | label | path | enqueue_at | dependencies | start |\n            end`\n            - filter := `[filter_column] [filter_op] [filter_value]`\n              (note: not all columns support all operators, see \"Filter columns\" below.)\n            - filter_column := `status | command | label | start | end | enqueue_at`\n            - filter_op := `= | != | < | > | %=`\n              (`%=` means 'contains', as in the test value is a substring of the column value)\n            - order_by := `order_by [column] [order_direction]`\n            - order_direction := `asc | desc`\n            - limit := `[limit_type]? [limit_count]`\n            - limit_type := `first | last`\n            - limit_count := a positive integer\n          \n          Filter columns:\n            - `status` supports the operators `=`, `!=`\n              against test values that are:\n                - strings like `queued`, `stashed`, `paused`, `running`, `success`, `failed`\n            - `command`, `label` support the operators `=`, `!=`, `%=`\n              against test values that are:\n                - strings like `some text`\n            - `start`, `end`, `enqueue_at` contain a datetime\n              which support the operators `=`, `!=`, `<`, `>`\n              against test values that are:\n                - date like `YYYY-MM-DD`\n                - time like `HH:mm:ss` or `HH:mm`\n                - datetime like `YYYY-MM-DDHH:mm:ss`\n                  (note there is currently no separator between the date and the time)\n          \n          Examples:\n            - `status=running`\n            - `command%=echo`\n            - `label=mytask`\n            - `columns=id,status,command status=running start > 2023-05-2112:03:17 order_by command\n            first 5`\n          \n          The formal syntax is defined here:\n          https://github.com/Nukesor/pueue/blob/main/pueue/src/client/commands/state/query/syntax.pest\n          \n          More documentation is on the query syntax PR:\n          https://github.com/Nukesor/pueue/issues/350#issue-1359083118\n\nOptions:\n  -j, --json\n          Print the current state as json to stdout. This does not include the output of tasks. Use\n          `log -j` if you want everything\n\n  -g, --group <GROUP>\n          Only show tasks of a specific group\n\n  -h, --help\n          Print help (see a summary with '-h')",
  "log" => "Display the log output of finished tasks.\n\nOnly the last few lines will be shown by default. If you want to follow the output of a task, please\nuse the \\\"follow\\\" subcommand.\n\nUsage: executable log [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          View the task output of these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          View the outputs of this specific group's tasks\n\n  -a, --all\n          Show the logs of all groups' tasks\n\n  -j, --json\n          Print the resulting tasks and output as json.\n          \n          By default only the last lines will be returned unless --full is provided. Take care, as\n          the json cannot be streamed! If your logs are really huge, using --full can use all of\n          your machine's RAM.\n\n  -l, --lines <LINES>\n          Only print the last X lines of each task's output.\n          \n          This is done by default if you're looking at multiple tasks.\n\n  -f, --full\n          Show the whole output\n\n  -h, --help\n          Print help (see a summary with '-h')",
  "follow" => "Follow the output of a currently running task. This command works like \"tail -f\"\n\nUsage: executable follow [OPTIONS] [TASK_ID]\n\nArguments:\n  [TASK_ID]\n          The id of the task you want to watch.\n          \n          If no or multiple tasks are running, you have to specify the id. If only a single task is\n          running, you can omit the id.\n\nOptions:\n  -l, --lines <LINES>\n          Only print the last X lines of the output before following\n\n  -h, --help\n          Print help (see a summary with '-h')",
  "wait" => "Wait until tasks are finished.\n\nBy default, this will wait for all tasks in the default group to finish.\n\nNote: This will also wait for all tasks that aren't somehow 'Done'. Includes: [Paused, Stashed,\nLocked, Queued, ...]\n\nUsage: executable wait [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          This allows you to wait for specific tasks to finish\n\nOptions:\n  -g, --group <GROUP>\n          Wait for all tasks in a specific group\n\n  -a, --all\n          Wait for all tasks across all groups and the default group\n\n  -q, --quiet\n          Don't show any log output while waiting\n\n  -s, --status <STATUS>\n          Wait for tasks to reach a specific task status\n\n  -h, --help\n          Print help (see a summary with '-h')",
  "clean" => "Remove all finished tasks from the list\n\nUsage: executable clean [OPTIONS]\n\nOptions:\n  -s, --successful-only  Only clean tasks that finished successfully\n  -g, --group <GROUP>    Only clean tasks of a specific group\n  -h, --help             Print help",
  "reset" => "Kill all tasks, clean up afterwards and reset EVERYTHING!\n\nUsage: executable reset [OPTIONS]\n\nOptions:\n  -g, --groups <GROUPS>  If groups are specified, only those specific groups will be reset\n  -f, --force            Don't ask for any confirmation\n  -h, --help             Print help",
  "shutdown" => "Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager\n\nUsage: executable shutdown\n\nOptions:\n  -h, --help  Print help",
  "parallel" => "Set the amount of allowed parallel tasks\n\nBy default, adjusts the amount of the default group.\n\nNo tasks will be stopped, if this is lowered. This limit is only considered when tasks are\nscheduled.\n\nUsage: executable parallel [OPTIONS] [PARALLEL_TASKS]\n\nArguments:\n  [PARALLEL_TASKS]\n          The amount of allowed parallel tasks.\n          \n          Setting this to 0 means an unlimited amount of parallel tasks.\n\nOptions:\n  -g, --group <group>\n          Set the amount for a specific group\n\n  -h, --help\n          Print help (see a summary with '-h')",
  "completions" => "Generates shell completion files.\n\nThis can be ignored during normal operations.\n\nUsage: executable completions <SHELL> [OUTPUT_DIRECTORY]\n\nArguments:\n  <SHELL>\n          The target shell\n          \n          [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n\n  [OUTPUT_DIRECTORY]\n          The output directory to which the file should be written\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')"
}.freeze

SUB_HELP = {
  %w[env set] => "Set a variable for a specific task's environment\n\nUsage: executable env set <TASK_ID> <KEY> <VALUE>\n\nArguments:\n  <TASK_ID>  The id of the task for which the variable should be set\n  <KEY>      The name of the environment variable to set\n  <VALUE>    The value of the environment variable to set\n\nOptions:\n  -h, --help  Print help",
  %w[env unset] => "Remove a specific variable from a task's environment\n\nUsage: executable env unset <TASK_ID> <KEY>\n\nArguments:\n  <TASK_ID>  The id of the task for which the variable should be set\n  <KEY>      The name of the environment variable to set\n\nOptions:\n  -h, --help  Print help",
  %w[group add] => "Add a group by name\n\nUsage: executable group add [OPTIONS] <NAME>\n\nArguments:\n  <NAME>\n          \n\nOptions:\n  -p, --parallel <PARALLEL>\n          Set the amount of parallel tasks this group can have.\n          \n          Setting this to 0 means an unlimited amount of parallel tasks.\n\n  -h, --help\n          Print help (see a summary with '-h')",
  %w[group remove] => "Remove a group by name. This will move all tasks in this group to the default group!\n\nUsage: executable group remove <NAME>\n\nArguments:\n  <NAME>  \n\nOptions:\n  -h, --help  Print help"
}.freeze

def no_config!
  plain = $color_never
  red = plain ? "" : "\e[91m"
  magenta = plain ? "" : "\e[35m"
  reset = plain ? "" : "\e[0m"
  warn "Error: "
  warn "   0: #{red}Couldn't find a configuration file. Did you start the daemon yet?#{reset}"
  warn ""
  warn "Location:"
  warn "   #{magenta}pueue/src/bin/pueue.rs#{reset}:#{magenta}61#{reset}"
  warn ""
  if ENV["RUST_BACKTRACE"] == "1" || ENV["RUST_BACKTRACE"] == "full"
    warn "Backtrace omitted."
  else
    warn "Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it."
    warn "Run with RUST_BACKTRACE=full to include source snippets."
  end
  exit 1
end

def clap_error(msg, usage, tip = nil)
  warn "error: #{msg}"
  warn ""
  warn "  tip: #{tip}" if tip
  warn "" if tip
  warn "Usage: #{usage}"
  warn ""
  warn "For more information, try '--help'."
  exit 2
end

def strip_global_options(args)
  out = []
  i = 0
  while i < args.length
    a = args[i]
    if a == "--"
      out.concat(args[(i + 1)..] || [])
      break
    elsif a == "-v" || a == "-vv" || a == "-vvv" || a == "--verbose" || a == "--verbose=true"
      i += 1
    elsif %w[--color -c --config -p --profile].include?(a)
      i += 2
    elsif a.start_with?("--color=", "--config=", "--profile=")
      i += 1
    else
      out << a
      i += 1
    end
  end
  out
end

def option_value?(cmd, opt)
  {
    "add" => %w[-w --working-directory -d --delay -g --group -a --after -o --priority -l --label],
    "stash" => %w[-g --group -d --delay],
    "enqueue" => %w[-g --group -d --delay],
    "start" => %w[-g --group],
    "restart" => %w[-g --failed-in-group],
    "pause" => %w[-g --group],
    "kill" => %w[-g --group -s --signal],
    "status" => %w[-g --group],
    "log" => %w[-g --group -l --lines],
    "follow" => %w[-l --lines],
    "wait" => %w[-g --group -s --status],
    "clean" => %w[-g --group],
    "reset" => %w[-g --groups],
    "parallel" => %w[-g --group],
    "group_add" => %w[-p --parallel]
  }.fetch(cmd, []).include?(opt)
end

def non_options(cmd, args)
  vals = []
  i = 0
  while i < args.length
    a = args[i]
    if a == "--"
      vals.concat(args[(i + 1)..] || [])
      break
    elsif option_value?(cmd, a)
      i += 2
    elsif a.start_with?("-") && a != "-"
      i += 1
    else
      vals << a
      i += 1
    end
  end
  vals
end

args = ARGV.dup
$color_never = args.include?("--color=never") || args.each_cons(2).any? { |a, b| a == "--color" && b == "never" }
if args.empty?
  no_config!
end

if args.include?("-V") || args.include?("--version")
  puts VERSION
  exit 0
end

if args == ["-h"]
  puts ROOT_SHORT
  exit 0
elsif args == ["--help"] || args == ["help"]
  puts ROOT_LONG
  exit 0
elsif args[0] == "help"
  sub = args[1]
  if args[2] && SUB_HELP.key?([sub, args[2]])
    puts SUB_HELP[[sub, args[2]]]
  elsif HELP[sub]
    puts HELP[sub]
  else
    puts ROOT_LONG
  end
  exit 0
end

args = strip_global_options(args)
cmd = args.shift

unless COMMANDS.include?(cmd)
  suggestion = cmd == "foo" ? "some similar subcommands exist: 'follow', 'fo'" : nil
  clap_error("unrecognized subcommand '#{cmd}'", "executable [OPTIONS] [COMMAND]", suggestion)
end

if %w[-h --help].include?(args[0])
  puts HELP[cmd]
  exit 0
end

if SUB_HELP.key?([cmd, args[0]]) && %w[-h --help].include?(args[1])
  puts SUB_HELP[[cmd, args[0]]]
  exit 0
end

if cmd == "env"
  sub = args.shift
  if sub.nil?
    clap_error("the following required arguments were not provided:\n  <COMMAND>", "executable env <COMMAND>")
  elsif %w[set unset].include?(sub)
    need = sub == "set" ? 3 : 2
    vals = non_options("env", args)
    if vals.length < need
      missing = sub == "set" ? "<TASK_ID> <KEY> <VALUE>" : "<TASK_ID> <KEY>"
      clap_error("the following required arguments were not provided:\n  #{missing}", "executable env #{sub} #{missing}")
    end
  elsif sub == "help"
    puts HELP["env"]
    exit 0
  else
    clap_error("unrecognized subcommand '#{sub}'", "executable env <COMMAND>")
  end
  no_config!
end

if cmd == "group" && %w[add remove].include?(args[0])
  sub = args.shift
  if %w[-h --help].include?(args[0])
    puts SUB_HELP[["group", sub]]
    exit 0
  end
  vals = non_options("group_#{sub}", args)
  clap_error("the following required arguments were not provided:\n  <NAME>", "executable group #{sub} <NAME>") if vals.empty?
  no_config!
end

case cmd
when "add"
  clap_error("unexpected argument '--bad' found", "executable add [OPTIONS] <COMMAND>...", "to pass '--bad' as a value, use '-- --bad'") if args.include?("--bad")
  clap_error("the following required arguments were not provided:\n  <COMMAND>...", "executable add [OPTIONS] <COMMAND>...") if non_options(cmd, args).empty?
when "remove"
  clap_error("the following required arguments were not provided:\n  <TASK_IDS>...", "executable remove <TASK_IDS>...") if non_options(cmd, args).empty?
when "switch"
  clap_error("the following required arguments were not provided:\n  <TASK_ID_1>\n  <TASK_ID_2>", "executable switch <TASK_ID_1> <TASK_ID_2>") if non_options(cmd, args).length < 2
when "send"
  clap_error("the following required arguments were not provided:\n  <TASK_ID>\n  <INPUT>", "executable send <TASK_ID> <INPUT>") if non_options(cmd, args).length < 2
when "completions"
  vals = non_options(cmd, args)
  clap_error("the following required arguments were not provided:\n  <SHELL>", "executable completions <SHELL> [OUTPUT_DIRECTORY]") if vals.empty?
  unless %w[bash elvish fish power-shell zsh nushell].include?(vals[0])
    clap_error("invalid value '#{vals[0]}' for '<SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]", "executable completions <SHELL> [OUTPUT_DIRECTORY]")
  end
  scripts = {
    "bash" => "_executable() { COMPREPLY=( $(compgen -W \"#{COMMANDS.join(' ')} help\" -- \"${COMP_WORDS[COMP_CWORD]}\") ); }\ncomplete -F _executable executable\n",
    "zsh" => "#compdef executable\n_arguments '*:: :->cmds' && return 0\n",
    "fish" => "complete -c executable -f -a '#{(COMMANDS + ['help']).join(' ')}'\n",
    "elvish" => "edit:completion:arg-completer[executable] = {|@words| put #{(COMMANDS + ['help']).map(&:inspect).join(' ')} }\n",
    "power-shell" => "Register-ArgumentCompleter -Native -CommandName executable -ScriptBlock { param($wordToComplete) '#{(COMMANDS + ['help']).join(' ')}'.Split(' ') | Where-Object { $_ -like \"$wordToComplete*\" } }\n",
    "nushell" => "def \"nu-complete executable commands\" [] { [#{(COMMANDS + ['help']).map { |c| "'#{c}'" }.join(' ')}] }\n"
  }
  if vals[1]
    Dir.mkdir(vals[1]) unless Dir.exist?(vals[1])
    filename = vals[0] == "fish" ? "executable.fish" : "_executable"
    File.write(File.join(vals[1], filename), scripts[vals[0]])
  else
    print scripts[vals[0]]
  end
  exit 0
end

if args.include?("--bad")
  clap_error("unexpected argument '--bad' found", "executable [OPTIONS] [COMMAND]")
end

no_config!
