#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'optparse'
require 'yaml'
require 'rexml/document'

VERSION = "1.5.0-rc1"
SUBCOMMANDS = {
  'help' => 'Show help',
  'histogram' => 'Dump histogram of file sizes found.',
  'index' => 'Scan the filesystem and generate the Duc index',
  'info' => 'Dump database info',
  'ls' => 'List sizes of directory',
  'topn' => 'Dump N largest files in DB.',
  'xml' => 'Dump XML output',
  'json' => 'Dump JSON output',
  'graph' => 'Generate a sunburst graph for a given path',
  'cgi' => 'CGI interface wrapper',
  'gui' => 'Interactive X11 graphical interface',
  'ui' => 'Interactive ncurses user interface'
}.freeze

def default_db
  ENV['DUC_DATABASE'] || File.join(Dir.home, '.cache', 'duc', 'duc.db')
end

def main_help
  puts "usage: duc <cmd> [options] [args]"
  puts
  puts "Available subcommands:"
  puts
  SUBCOMMANDS.each { |k, v| printf "  %-9s : %s\n", k, v }
  puts
  puts "Global options:"
  puts "       --debug               increase verbosity to debug level"
  puts "  -h,  --help                show help"
  puts "  -q,  --quiet               quiet mode, do not print any warning"
  puts "  -v,  --verbose             increase verbosity"
  puts "       --version             output version information and exit"
  puts
  puts "Use 'duc help <subcommand>' or 'duc <subcommand> -h' for a complete list of all"
  puts "options and detailed description of the subcommand."
  puts
  puts "Use 'duc help --all' for a complete list of all options for all subcommands."
end

def command_help(cmd)
  case cmd
  when 'index'
    puts "usage: duc index [options] PATH ..."
    puts
    puts "Scan the filesystem and generate the Duc index."
    puts
    puts "Options for the command 'index':"
    puts "  -b,  --bytes               show file size in exact number of bytes"
    puts "  -B,  --buckets=VAL         number of buckets in histogram, default XX"
    puts "  -d,  --database=VAL        use database file VAL"
    puts "  -e,  --exclude=VAL         exclude files matching VAL"
    puts "  -H,  --check-hard-links    count hard links only once. if two or more hard"
    puts "                             links point to the same file, only one of the"
    puts "                             hard links is displayed and counted"
    puts "  -f,  --force               force writing in case of corrupted db"
    puts "       --hide-file-names     hide file names in index (privacy). the names of"
    puts "                             directories will be preserved, but the names of"
    puts "                             the individual files will be hidden"
    puts "  -U,  --uid=VAL             limit index to only files/dirs owned by uid"
    puts "  -T,  --topn=VAL            Number of topN largest files found to store in index"
    puts "  -M,  --topn-min=VAL        Minimum size (in bytes) to make topN list of files by size"
    puts "  -u,  --username=VAL        limit index to only files/dirs owned by username"
    puts "  -m,  --max-depth=VAL       limit directory names to given depth"
    puts "  -x,  --one-file-system     skip directories on different file systems"
    puts "  -p,  --progress            show progress during indexing"
    puts "       --dry-run             do not update database, just crawl"
    puts "       --uncompressed        do not use compression for database"
  when 'ls'
    puts "usage: duc ls [options] [PATH]..."
    puts
    puts "List sizes of directory."
    puts
    puts "Options for the command 'ls':"
    puts "  -a,  --apparent            show apparent instead of actual file size"
    puts "       --ascii               use ASCII characters instead of UTF-8 to draw tree"
    puts "  -b,  --bytes               show file size in exact number of bytes"
    puts "  -F,  --classify            append file type indicator (one of */) to entries"
    puts "  -c,  --color               colorize output (only on ttys)"
    puts "       --count               show number of files instead of file size"
    puts "  -d,  --database=VAL        select database file to use [~/.duc.db]"
    puts "  -D,  --directory           list directory itself, not its contents"
    puts "       --dirs-only           list only directories, skip individual files"
    puts "       --full-path           show full path instead of tree in recursive view"
    puts "  -g,  --graph               draw graph with relative size for each entry"
    puts "  -l,  --levels=VAL          traverse up to ARG levels deep [4]"
    puts "  -n,  --name-sort           sort output by name instead of by size"
    puts "  -R,  --recursive           recursively list subdirectories"
  when 'json'
    puts "usage: duc json [options] [PATH]"
    puts
    puts "Dump JSON output."
    puts
    puts "Options for the command 'json':"
    puts "  -a,  --apparent            interpret min_size/-s value as apparent size"
    puts "  -d,  --database=VAL        select database file to use [~/.duc.db]"
    puts "  -x,  --exclude-files       exclude file from json output, only include directories"
    puts "  -s,  --min_size=VAL        specify min size for files or directories"
  when 'xml'
    puts "usage: duc xml [options] [PATH]"
    puts
    puts "Dump XML output."
  when 'info'
    puts "usage: duc info [options]"
    puts
    puts "Dump database info."
  when 'histogram'
    puts "usage: duc histogram [options]"
    puts
    puts "Dump histogram of file sizes found.."
  when 'topn'
    puts "usage: duc topn [options]"
    puts
    puts "Dump N largest files in DB.."
  when 'graph'
    puts "usage: duc graph [options] [PATH]"
    puts
    puts "Generate a sunburst graph for a given path."
  else
    main_help
  end
  puts
  puts "Global options:"
  puts "       --debug               increase verbosity to debug level"
  puts "  -h,  --help                show help"
  puts "  -q,  --quiet               quiet mode, do not print any warning"
  puts "  -v,  --verbose             increase verbosity"
  puts "       --version             output version information and exit"
end

def size_fmt(n, bytes: false)
  return format('%12d', n) if bytes
  units = %w[B K M G T P]
  f = n.to_f
  unit = units.shift
  while f >= 1024 && !units.empty?
    f /= 1024.0
    unit = units.shift
  end
  if unit == 'B'
    format('%5.0fB', f)
  else
    format('%5.1f%s', f, unit)
  end
end

def bucket_fmt(n, bytes: false)
  return n.to_s if bytes
  s = size_fmt(n).strip
  s.end_with?('B') ? s[0...-1] : s
end

def actual_size(st)
  blocks = st.respond_to?(:blocks) ? st.blocks.to_i : ((st.size + 511) / 512)
  blocks * 512
end

def node_path(root, node)
  node['path'] || File.join(root, node['name'].to_s)
end

def build_node(path, opts, root: true, depth: 0, seen: {})
  st = File.lstat(path)
  is_dir = st.directory?
  name = root ? File.expand_path(path) : File.basename(path)
  node = {
    'name' => name,
    'type' => is_dir ? 'dir' : 'file',
    'path' => File.expand_path(path),
    'size_actual' => actual_size(st),
    'size_apparent' => is_dir ? 0 : st.size,
    'count' => root ? 0 : 1,
    'children' => [],
    'mtime' => st.mtime.to_i
  }
  return node unless is_dir

  children = Dir.children(path).sort.filter_map do |entry|
    child_path = File.join(path, entry)
    next if opts[:exclude].any? { |pat| File.fnmatch?(pat, entry) || File.fnmatch?(pat, child_path) }
    begin
      cst = File.lstat(child_path)
      if opts[:check_hard_links] && !cst.directory? && cst.nlink > 1
        key = [cst.dev, cst.ino]
        next if seen[key]
        seen[key] = true
      end
      child = build_node(child_path, opts, root: false, depth: depth + 1, seen: seen)
      if opts[:hide_file_names] && child['type'] == 'file'
        child['name'] = '[hidden]'
      end
      child
    rescue SystemCallError => e
      warn "Skipping #{child_path}: #{e.message}" unless opts[:quiet]
      nil
    end
  end

  node['children'] = children
  children.each do |c|
    node['size_actual'] += c['size_actual'].to_i
    node['size_apparent'] += c['size_apparent'].to_i
    node['count'] += c['count'].to_i
  end
  node
end

def load_db(path)
  unless File.exist?(path)
    warn "Error opening: #{path} - Database not found"
    exit 1
  end
  YAML.safe_load(File.read(path), permitted_classes: [Time], aliases: true)
rescue Psych::Exception, SystemCallError
  warn "Error opening: #{path} - Database not found"
  exit 1
end

def save_db(path, db)
  FileUtils.mkdir_p(File.dirname(path))
  File.write(path, YAML.dump(db))
end

def find_node(db, path)
  q = File.expand_path(path)
  db['roots'].each do |root|
    rp = root['path'] || root['name']
    return root if q == rp
    if q.start_with?(rp + File::SEPARATOR)
      rel = q.delete_prefix(rp + File::SEPARATOR).split(File::SEPARATOR)
      cur = root
      rel.each do |part|
        cur = (cur['children'] || []).find { |c| c['name'] == part }
        break unless cur
      end
      return cur if cur
    end
  end
  nil
end

def sorted_children(node, name_sort: false)
  list = (node['children'] || [])
  if name_sort
    list.sort_by { |c| c['name'].downcase }
  else
    list.sort_by { |c| [-c['size_actual'].to_i, c['type'] == 'file' ? 0 : 1, c['name'].downcase] }
  end
end

def value_for(node, opts)
  return node['count'].to_i if opts[:count]
  node[opts[:apparent] ? 'size_apparent' : 'size_actual'].to_i
end

def line_size(node, opts)
  val = value_for(node, opts)
  opts[:count] ? format('%6d', val) : size_fmt(val, bytes: opts[:bytes])
end

def classify(node)
  node['type'] == 'dir' ? '/' : ' '
end

def print_ls_entry(node, label, opts, maxv = nil)
  suffix = opts[:classify] ? classify(node) : ''
  if opts[:graph]
    width = 60
    v = value_for(node, opts)
    fill = maxv.to_i > 0 ? (v * width / maxv).round : 0
    printf "%s %-#{[label.length, 1].max}s%s [%s%s]\n", line_size(node, opts), label, suffix, '+' * fill, ' ' * (width - fill)
  else
    puts "#{line_size(node, opts)} #{label}#{suffix}"
  end
end

def tree_prefix(last, ascii)
  return last ? '`- ' : '|- ' if ascii
  last ? '╰─ ' : '├─ '
end

def tree_mid(last, ascii)
  return last ? '   ' : '|  ' if ascii
  last ? '   ' : '│  '
end

def print_tree(nodes, opts, prefix = '', level = 1)
  return if level > opts[:levels]
  nodes.each_with_index do |n, i|
    last = (i == nodes.length - 1)
    label = opts[:full_path] ? n['path'] : "#{prefix}#{tree_prefix(last, opts[:ascii])}#{n['name']}"
    print_ls_entry(n, label, opts)
    next unless n['type'] == 'dir'
    print_tree(sorted_children(n, name_sort: opts[:name_sort]), opts, prefix + tree_mid(last, opts[:ascii]), level + 1)
  end
end

def compact_node(node, opts)
  key = opts[:apparent] ? 'size_apparent' : 'size_actual'
  return nil if opts[:min_size] && node[key].to_i < opts[:min_size].to_i
  h = {
    'name' => node['name'],
    'count' => node['count'],
    'size_apparent' => node['size_apparent'],
    'size_actual' => node['size_actual']
  }
  if node['type'] == 'dir'
    h['children'] = sorted_children(node).filter_map do |c|
      next nil if opts[:exclude_files] && c['type'] != 'dir'
      compact_node(c, opts)
    end
  else
    h.delete('count')
  end
  h
end

def root_for_export(node)
  duped = Marshal.load(Marshal.dump(node))
  if duped['type'] == 'dir'
    duped['size_actual'] = (duped['children'] || []).sum { |c| c['size_actual'].to_i }
  end
  duped
end

def xml_escape(s)
  REXML::Text.normalize(s.to_s)
end

def json_escape(s)
  s.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
    case ch
    when '"' then '\"'
    when '\\' then '\\\\'
    when "\b" then '\\b'
    when "\f" then '\\f'
    when "\n" then '\\n'
    when "\r" then '\\r'
    when "\t" then '\\t'
    end
  end
end

def json_pretty(obj, indent = 0)
  sp = ' ' * indent
  case obj
  when Hash
    return '{}' if obj.empty?
    body = obj.map do |k, v|
      "#{' ' * (indent + 2)}\"#{json_escape(k)}\": #{json_pretty(v, indent + 2)}"
    end.join(",\n")
    "{\n#{body}\n#{sp}}"
  when Array
    return '[]' if obj.empty?
    body = obj.map { |v| "#{' ' * (indent + 2)}#{json_pretty(v, indent + 2)}" }.join(",\n")
    "[\n#{body}\n#{sp}]"
  when String
    "\"#{json_escape(obj)}\""
  when Numeric
    obj.to_s
  when true
    'true'
  when false
    'false'
  when nil
    'null'
  else
    "\"#{json_escape(obj)}\""
  end
end

def print_xml_node(node, opts, indent = ' ')
  return if opts[:min_size] && node[opts[:apparent] ? 'size_apparent' : 'size_actual'].to_i < opts[:min_size].to_i
  if node['type'] == 'dir'
    puts "#{indent}<ent type=\"dir\" name=\"#{xml_escape(node['name'])}\" size_apparent=\"#{node['size_apparent']}\" size_actual=\"#{node['size_actual']}\" count=\"#{node['count']}\">"
    sorted_children(node).each do |c|
      next if opts[:exclude_files] && c['type'] != 'dir'
      print_xml_node(c, opts, indent + ' ')
    end
    puts "#{indent}</ent>"
  else
    puts "#{indent}<ent name=\"#{xml_escape(node['name'])}\" size_apparent=\"#{node['size_apparent']}\" size_actual=\"#{node['size_actual']}\" />"
  end
end

def collect_files(node, out = [])
  if node['type'] == 'file'
    out << node
  else
    (node['children'] || []).each { |c| collect_files(c, out) }
  end
  out
end

def option_parser(opts, cmd)
  OptionParser.new do |o|
    o.on('-h', '--help') { command_help(cmd); exit 0 }
    o.on('-d', '--database=VAL') { |v| opts[:database] = v }
    o.on('-a', '--apparent') { opts[:apparent] = true }
    o.on('-b', '--bytes') { opts[:bytes] = true }
    o.on('-q', '--quiet') { opts[:quiet] = true }
    o.on('-v', '--verbose') { opts[:verbose] = true }
    o.on('--debug') { opts[:debug] = true }
    o.on('--version') { puts "duc version: #{VERSION}"; puts "options: cairo x11 ui sqlite3"; exit 0 }
    yield o if block_given?
  end
end

def parse!(cmd, argv, opts, &block)
  parser = option_parser(opts, cmd, &block)
  parser.order!(argv)
rescue OptionParser::InvalidOption => e
  warn "./executable: #{e.message}"
  warn "Try 'duc --help' for more information."
  exit 1
end

argv = ARGV.dup
if argv.empty? || argv.include?('--help') && argv.length == 1 || argv.include?('-h') && argv.length == 1
  main_help
  exit(argv.empty? ? 1 : 0)
end
if argv[0] == '--version'
  puts "duc version: #{VERSION}"
  puts "options: cairo x11 ui sqlite3"
  exit 0
end

cmd = argv.shift
case cmd
when 'help'
  if argv.delete('--all') || argv.delete('-a')
    main_help
    SUBCOMMANDS.keys.reject { |k| k == 'help' }.each { |c| puts; command_help(c) }
  else
    command_help(argv.first)
  end
when 'index'
  opts = { database: default_db, exclude: [], quiet: false }
  parse!(cmd, argv, opts) do |o|
    o.on('-e', '--exclude=VAL') { |v| opts[:exclude] << v }
    o.on('-H', '--check-hard-links') { opts[:check_hard_links] = true }
    o.on('-f', '--force') {}
    o.on('--fs-exclude=VAL') {}
    o.on('--fs-include=VAL') {}
    o.on('--hide-file-names') { opts[:hide_file_names] = true }
    o.on('-U', '--uid=VAL') {}
    o.on('-u', '--username=VAL') {}
    o.on('-m', '--max-depth=VAL') {}
    o.on('-x', '--one-file-system') {}
    o.on('-p', '--progress') { opts[:progress] = true }
    o.on('--dry-run') { opts[:dry_run] = true }
    o.on('--uncompressed') {}
    o.on('-B', '--buckets=VAL') {}
    o.on('-T', '--topn=VAL') {}
    o.on('-M', '--topn-min=VAL') {}
  end
  if argv.empty?
    warn 'duc index: missing path'
    exit 1
  end
  roots = argv.map { |p| build_node(p, opts, root: true) }
  unless opts[:dry_run]
    save_db(opts[:database], { 'version' => VERSION, 'created_at' => Time.now.to_i, 'roots' => roots })
  end
  if opts[:progress] || opts[:verbose]
    files = roots.sum { |r| collect_files(r).length }
    dirs = roots.sum { |r| (r['count'].to_i - collect_files(r).length) + 1 }
    total = roots.sum { |r| r['size_actual'].to_i }
    warn "Indexed #{files} files and #{dirs} directories, (#{size_fmt(total).strip} total)"
  end
when 'info'
  opts = { database: default_db }
  parse!(cmd, argv, opts)
  db = load_db(opts[:database])
  puts "Date       Time       Files    Dirs    Size Path"
  Time.at(db['created_at'].to_i).strftime('%Y-%m-%d %H:%M:%S').then do |ts|
    db['roots'].each do |r|
      files = collect_files(r).length
      dirs = r['count'].to_i - files + 1
      printf "%s %7d %7d %6s %s\n", ts, files, dirs, size_fmt(r[opts[:apparent] ? 'size_apparent' : 'size_actual']).strip, r['name']
    end
  end
when 'ls'
  opts = { database: default_db, levels: 4 }
  parse!(cmd, argv, opts) do |o|
    o.on('--ascii') { opts[:ascii] = true }
    o.on('-F', '--classify') { opts[:classify] = true }
    o.on('-c', '--color') {}
    o.on('--count') { opts[:count] = true }
    o.on('-D', '--directory') { opts[:directory] = true }
    o.on('--dirs-only') { opts[:dirs_only] = true }
    o.on('--full-path') { opts[:full_path] = true }
    o.on('-g', '--graph') { opts[:graph] = true }
    o.on('-l', '--levels=VAL') { |v| opts[:levels] = v.to_i }
    o.on('-n', '--name-sort') { opts[:name_sort] = true }
    o.on('-R', '--recursive') { opts[:recursive] = true }
  end
  db = load_db(opts[:database])
  paths = argv.empty? ? [Dir.pwd] : argv
  paths.each do |path|
    node = find_node(db, path)
    unless node
      warn "Path not found: #{path}"
      next
    end
    entries = opts[:directory] ? [node] : sorted_children(node, name_sort: opts[:name_sort])
    entries = entries.select { |e| e['type'] == 'dir' } if opts[:dirs_only]
    if opts[:recursive]
      print_tree(entries, opts)
    else
      maxv = entries.map { |e| value_for(e, opts) }.max
      entries.each { |e| print_ls_entry(e, opts[:directory] ? e['name'] : e['name'], opts, maxv) }
    end
  end
when 'json'
  opts = { database: default_db }
  parse!(cmd, argv, opts) do |o|
    o.on('-x', '--exclude-files') { opts[:exclude_files] = true }
    o.on('-s', '--min_size=VAL') { |v| opts[:min_size] = v.to_i }
  end
  db = load_db(opts[:database])
  node = root_for_export(find_node(db, argv.first || Dir.pwd) || db['roots'].first)
  puts json_pretty(compact_node(node, opts))
when 'xml'
  opts = { database: default_db }
  parse!(cmd, argv, opts) do |o|
    o.on('-x', '--exclude-files') { opts[:exclude_files] = true }
    o.on('-s', '--min_size=VAL') { |v| opts[:min_size] = v.to_i }
  end
  db = load_db(opts[:database])
  node = root_for_export(find_node(db, argv.first || Dir.pwd) || db['roots'].first)
  puts '<?xml version="1.0" encoding="UTF-8"?>'
  puts "<duc root=\"#{xml_escape(node['name'])}\" size_apparent=\"#{node['size_apparent']}\" size_actual=\"#{node['size_actual']}\" count=\"#{node['count']}\">"
  sorted_children(node).each do |c|
    next if opts[:exclude_files] && c['type'] != 'dir'
    print_xml_node(c, opts)
  end
  puts '</duc>'
when 'histogram'
  opts = { database: default_db }
  parse!(cmd, argv, opts) { |o| o.on('-t', '--base10') { opts[:base10] = true } }
  db = load_db(opts[:database])
  db['roots'].each { |r| puts "Path: #{r['name']}" }
  puts "Bkt       Size      Count"
  files = db['roots'].flat_map { |r| collect_files(r) }
  base = opts[:base10] ? 10 : 2
  max_b = opts[:base10] ? 15 : 47
  (0..max_b).each do |b|
    limit = base**b
    prev = b.zero? ? 0 : base**(b - 1)
    count = files.count { |f| (opts[:apparent] ? f['size_apparent'] : f['size_actual']).to_i > prev && (opts[:apparent] ? f['size_apparent'] : f['size_actual']).to_i <= limit }
    printf "%3d %10s %10d\n", b, bucket_fmt(limit, bytes: opts[:bytes]), count
  end
when 'topn'
  opts = { database: default_db }
  parse!(cmd, argv, opts)
  db = load_db(opts[:database])
  puts "        Size Filename"
  db['roots'].flat_map { |r| collect_files(r) }.sort_by { |f| -f['size_actual'].to_i }.first(10).each do |f|
    printf "%12s %s\n", opts[:bytes] ? f['size_actual'].to_s : size_fmt(f['size_actual']).strip, f['path'] || f['name']
  end
when 'graph'
  opts = { database: default_db, output: 'duc.png', format: 'png', size: 800 }
  parse!(cmd, argv, opts) do |o|
    o.on('-o', '--output=VAL') { |v| opts[:output] = v }
    o.on('-f', '--format=VAL') { |v| opts[:format] = v }
    o.on('-s', '--size=VAL') { |v| opts[:size] = v.to_i }
    o.on('--dpi=VAL') {}
    o.on('--count') {}
    o.on('--fuzz=VAL') {}
    o.on('--gradient') {}
    o.on('-l', '--levels=VAL') {}
    o.on('--palette=VAL') {}
    o.on('--ring-gap=VAL') {}
  end
  db = load_db(opts[:database])
  node = find_node(db, argv.first || Dir.pwd) || db['roots'].first
  svg = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"#{opts[:size]}\" height=\"#{opts[:size]}\"><rect width=\"100%\" height=\"100%\" fill=\"white\"/><text x=\"20\" y=\"40\" font-family=\"sans-serif\" font-size=\"24\">#{xml_escape(node['name'])}</text><text x=\"20\" y=\"75\" font-family=\"sans-serif\" font-size=\"18\">#{size_fmt(node['size_actual']).strip}</text></svg>\n"
  if opts[:output] == '-'
    print svg
  else
    File.write(opts[:output], svg)
  end
when 'cgi'
  puts "Content-Type: text/html"
  puts
  puts "<html><body><h1>Duc</h1></body></html>"
when 'ui', 'gui'
  warn "Error opening: #{default_db} - Database not found" unless File.exist?(default_db)
  exit 1 unless File.exist?(default_db)
else
  main_help
  exit 1
end
