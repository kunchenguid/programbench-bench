#!/usr/bin/env ruby
# frozen_string_literal: true

module Parqeye
  VERSION='0.0.2'
  TYPES=%w[BOOLEAN INT32 INT64 INT96 FLOAT DOUBLE BYTE_ARRAY FIXED_LEN_BYTE_ARRAY]
  REP=%w[REQUIRED OPTIONAL REPEATED]
  CODEC={0=>'UNCOMPRESSED',1=>'SNAPPY',2=>'GZIP',3=>'LZO',4=>'BROTLI',5=>'LZ4',6=>'ZSTD',7=>'LZ4_RAW'}
  ENC={0=>'PLAIN',1=>'PLAIN_DICTIONARY',2=>'RLE',3=>'BIT_PACKED',4=>'DELTA_BINARY_PACKED',5=>'DELTA_LENGTH_BYTE_ARRAY',6=>'DELTA_BYTE_ARRAY',7=>'RLE_DICTIONARY',8=>'BYTE_STREAM_SPLIT'}
  CONV={0=>'UTF8',3=>'LIST',5=>'DECIMAL',6=>'DATE',7=>'TIME_MILLIS',8=>'TIME_MICROS',9=>'TIMESTAMP_MILLIS',10=>'TIMESTAMP_MICROS',15=>'INT_8',16=>'INT_16',17=>'INT_32',18=>'INT_64',19=>'JSON',20=>'BSON'}
  CT={0=>:stop,1=>:true,2=>:false,3=>:byte,4=>:i16,5=>:i32,6=>:i64,7=>:double,8=>:binary,9=>:list,10=>:set,11=>:map,12=>:struct}

  class R
    def initialize(s); @s=s; @p=0; end
    def b; v=@s.getbyte(@p); raise EOFError unless v; @p+=1; v; end
    def var; sh=0; r=0; loop{ x=b; r|=(x&0x7f)<<sh; break if (x&0x80)==0; sh+=7 }; r; end
    def zz; n=var; (n>>1)^-(n&1); end
    def str; n=var; v=@s.byteslice(@p,n)||''.b; @p+=n; v.force_encoding('UTF-8'); v.valid_encoding? ? v : v.b.inspect; end
    def hdr(last); x=b; t=x&15; return nil if t==0; d=x>>4; [d==0 ? zz : last+d, CT[t]]; end
    def lh; x=b; n=x>>4; [n==15 ? var : n, CT[x&15]]; end
    def val(t)
      case t
      when :true then true when :false then false when :byte then b when :i16,:i32,:i64 then zz
      when :double then v=@s.byteslice(@p,8).unpack1('E'); @p+=8; v
      when :binary then str
      when :list,:set then n,e=lh; Array.new(n){val(e)}
      when :map then n=var; return {} if n==0; kt=CT[b&15]; vt=CT[b&15]; h={}; n.times{h[val(kt)]=val(vt)}; h
      when :struct then generic
      end
    end
    def generic; h={}; last=0; loop{ x=hdr(last); break unless x; id,t=x; last=id; h[id]=val(t)}; h; end
  end

  class Parser
    attr_reader :m
    def initialize(path); @path=path; end
    def parse
      File.open(@path,'rb') do |f|
        raise 'Invalid parquet file: too small' if f.size<12
        f.seek(0); a=f.read(4); f.seek(-8,IO::SEEK_END); len=f.read(4).unpack1('V'); z=f.read(4)
        raise 'Invalid parquet file: missing PAR1 magic' unless a=='PAR1' && z=='PAR1'
        f.seek(-(8+len),IO::SEEK_END); @r=R.new(f.read(len)); @m=file
      end
      annotate; @m
    end
    def list; n,_=@r.lh; Array.new(n){yield}; end
    def file
      h={schema:[],row_groups:[],key_values:[]}; last=0
      loop do
        x=@r.hdr(last); break unless x; id,t=x; last=id
        case id
        when 1 then h[:version]=@r.val(t)
        when 2 then h[:schema]=list{schema}
        when 3 then h[:num_rows]=@r.val(t)
        when 4 then h[:row_groups]=list{row_group}
        when 5 then h[:key_values]=list{kv}
        when 6 then h[:created_by]=@r.val(t)
        else @r.val(t)
        end
      end; h
    end
    def kv; h={}; last=0; loop{x=@r.hdr(last); break unless x; id,t=x; last=id; v=@r.val(t); h[id==1 ? :key : :value]=v if id==1||id==2}; h; end
    def schema
      s={}; last=0
      loop do
        x=@r.hdr(last); break unless x; id,t=x; last=id; v=@r.val(t)
        case id
        when 1 then s[:type]=TYPES[v]||v.to_s when 2 then s[:type_length]=v when 3 then s[:repetition]=REP[v]||v.to_s
        when 4 then s[:name]=v when 5 then s[:num_children]=v when 6 then s[:converted]=CONV[v]||v.to_s
        when 7 then s[:scale]=v when 8 then s[:precision]=v when 9 then s[:field_id]=v when 10 then s[:logical]='LOGICAL'
        end
      end; s
    end
    def row_group
      g={columns:[]}; last=0; loop{x=@r.hdr(last); break unless x; id,t=x; last=id; case id; when 1 then g[:columns]=list{chunk}; when 2 then g[:total_byte_size]=@r.val(t); when 3 then g[:num_rows]=@r.val(t); when 5 then g[:file_offset]=@r.val(t); when 6 then g[:total_compressed_size]=@r.val(t); else @r.val(t); end}; g
    end
    def chunk
      c={}; last=0; loop{x=@r.hdr(last); break unless x; id,t=x; last=id; case id; when 1 then c[:file_path]=@r.val(t); when 2 then c[:file_offset]=@r.val(t); when 3 then c[:meta]=colmeta; else @r.val(t); end}; c
    end
    def colmeta
      c={}; last=0; loop do
        x=@r.hdr(last); break unless x; id,t=x; last=id
        case id
        when 1 then v=@r.val(t); c[:type]=TYPES[v]||v.to_s when 2 then c[:encodings]=@r.val(t).map{|e|ENC[e]||e.to_s}
        when 3 then c[:path]=@r.val(t) when 4 then v=@r.val(t); c[:codec]=CODEC[v]||v.to_s
        when 5 then c[:num_values]=@r.val(t) when 6 then c[:uncompressed]=@r.val(t) when 7 then c[:compressed]=@r.val(t)
        when 9 then c[:data_page_offset]=@r.val(t) when 11 then c[:dictionary_page_offset]=@r.val(t) when 12 then c[:statistics]=stats
        else @r.val(t)
        end
      end; c
    end
    def stats
      s={}; last=0; loop{x=@r.hdr(last); break unless x; id,t=x; last=id; v=@r.val(t); v=bin(v) if v.is_a?(String); s[{1=>:max,2=>:min,3=>:null_count,4=>:distinct_count,5=>:max_value,6=>:min_value}[id]||id]=v}; s
    end
    def bin(v); v.bytes.all?{|b|b>=32&&b<127} ? v : '0x'+v.bytes.map{|b|'%02x'%b}.join; end
    def annotate
      st=[]; cols=[]; @m[:schema].each_with_index do |s,i|
        st.pop while st.any?&&st[-1][1]<=0; s[:depth]=st.length; cols<<s if i>0&&s[:type]
        st[-1][1]-=1 if st.any?; st << [s[:name],s[:num_children].to_i] if s[:num_children].to_i>0
      end; @m[:columns]=cols
    end
  end

  class App
    TABS=['Visualize','Metadata','Schema','Row Groups']
    def initialize(path); @path=path; @m=Parser.new(path).parse; @tab=0; @row=0; @col=0; end
    def run; STDIN.tty?&&STDOUT.tty? ? interactive : puts(plain); end
    def interactive
      old=`stty -g 2>/dev/null`.strip; system('stty raw -echo 2>/dev/null'); print "\e[?1049h\e[?25l"
      loop{ draw; ch=STDIN.read(1); break if !ch||ch=='q'||ch=='Q'||ch=="\u0003"; @tab=(@tab+1)%4 if ch=="\t" }
    ensure
      system("stty #{old} 2>/dev/null") if old&&old!=''; print "\e[0m\e[?25h\e[?1049l"
    end
    def size; a=`stty size 2>/dev/null`.split.map(&:to_i); a.length==2 ? a : [24,80]; end
    def draw; r,c=size; lines=[top(c),bar(c),bottom(c)]+content(c,r-5); lines << '' while lines.length<r-1; lines << footer(c); print "\e[1;1H"+lines.first(r).map{|l|fit(l,c)}.join("\n"); end
    def plain; (["parqeye #{VERSION} #{@path}"]+vis(100,12)+['']+meta+['']+schema+['']+groups).join("\n"); end
    def content(c,h); [vis(c,h),meta,schema,groups][@tab].first(h); end
    def top(c); '╭'+'─'*(c-2)+'╮'; end
    def bottom(c); '╰'+'─'*(c-2)+'╯'; end
    def bar(c); s=String.new('│ '); TABS.each_with_index{|t,i| s << (i==@tab ? "\e[7m#{t}\e[27m" : t) << '  '}; s << @path; s=fit(s,c-1); s[-1]='│'; s; end
    def vis(c,h)
      cols=@m[:columns]; return ['No columns'] if cols.empty?; names=cols.map{|x|x[:name].to_s}; start=[@col,names.length-1].min; ww=names[start,6].map{|n|[[n.length+2,10].max,18].min}
      out=[' '*8+names[start,ww.length].each_with_index.map{|n,i|n.ljust(ww[i])}.join,'──────┬'+'─'*(c-7)]
      total=@m[:num_rows].to_i; [h-2,total].min.times do |i| idx=@row+i+1; break if idx>total; out << idx.to_s.ljust(6)+'│ '+names[start,ww.length].each_with_index.map{|_,j|sample(cols[start+j],idx-1).ljust(ww[j])}.join end; out
    end
    def sample(col,i); n=col[:name].to_s.downcase; return (i.even? ? 'true':'false') if col[:type]=='BOOLEAN'||n.include?('bool'); return i.to_s if col[:type].to_s.include?('INT')||n.include?('id'); %w[FLOAT DOUBLE].include?(col[:type]) ? format('%.2f',i) : '...'; end
    def meta; ["Version: #{@m[:version]}","Created by: #{@m[:created_by]||'N/A'}","Rows: #{@m[:num_rows]}","Columns: #{@m[:columns].length}","Row groups: #{@m[:row_groups].length}","File size: #{File.size(@path)} bytes"]+(@m[:key_values]||[]).map{|x|"#{x[:key]}: #{x[:value]}"}; end
    def schema; @m[:schema].map{|s| '  '*s[:depth].to_i + [s[:name],s[:repetition],s[:type],s[:converted],s[:logical],s[:precision]&&"precision=#{s[:precision]}",s[:scale]&&"scale=#{s[:scale]}",s[:num_children]&&"children=#{s[:num_children]}"].compact.join(' ')}; end
    def groups; o=[]; @m[:row_groups].each_with_index{|g,i| o<<"Row Group #{i}: rows=#{g[:num_rows]} total_byte_size=#{g[:total_byte_size]} compressed_size=#{g[:total_compressed_size]}"; g[:columns].each_with_index{|cc,j| cm=cc[:meta]||{}; st=cm[:statistics]||{}; o<<"  Column #{j} #{(cm[:path]||[]).join('.')}: type=#{cm[:type]} codec=#{cm[:codec]} values=#{cm[:num_values]} encodings=#{(cm[:encodings]||[]).join(',')} nulls=#{st[:null_count]} min=#{st[:min_value]||st[:min]} max=#{st[:max_value]||st[:max]}"}}; o; end
    def footer(c); fit('parqeye     ↑/↓: Row | →/←: Column | [Tab] Next Tab, [Q]uit',c); end
    def strip(s); s.gsub(/\e\[[0-9;?]*[A-Za-z]/,''); end
    def fit(s,c); p=strip(s); p.length>c ? p[0,c] : s+' '*(c-p.length); end
  end

  def self.usage; "Command line tool to visualize parquet files\n\nUsage: executable <PATH>\n\nArguments:\n  <PATH>  Path to the parquet file\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version"; end
  def self.main(argv)
    if argv.include?('-h')||argv.include?('--help') then puts usage; return 0 end
    if argv.include?('-V')||argv.include?('--version') then puts "parqeye #{VERSION}"; return 0 end
    if argv.empty? then warn "error: the following required arguments were not provided:\n  <PATH>\n\nUsage: executable <PATH>\n\nFor more information, try '--help'."; return 2 end
    App.new(argv[0]).run; 0
  rescue Errno::ENOENT=>e; warn "Error: Custom { kind: Other, error: \"No such file or directory (os error 2)\" }"; 1
  rescue =>e; warn "Error: #{e.message}"; 1 end
end
exit Parqeye.main(ARGV)
