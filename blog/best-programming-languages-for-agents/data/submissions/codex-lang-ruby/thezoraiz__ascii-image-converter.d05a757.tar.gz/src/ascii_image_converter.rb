#!/usr/bin/env ruby
# frozen_string_literal: true

require 'zlib'
require 'optparse'
require 'fileutils'

HELP = <<~TEXT
  This tool converts images into ascii art and prints them on the terminal.
  Further configuration can be managed with flags.

  Usage:
    ascii-image-converter [image paths/urls or piped stdin] [flags]

  Flags:
    -C, --color             Display ascii art with original colors
                            If 24-bit colors aren't supported, uses 8-bit
                            (Inverts with --negative flag)
                            (Overrides --grayscale and --font-color flags)
                            
        --color-bg          If some color flag is passed, use that color
                            on character background instead of foreground
                            (Inverts with --negative flag)
                            (Only applicable for terminal display)
                            
    -d, --dimensions ints   Set width and height for ascii art in CHARACTER length
                            e.g. -d 60,30 (defaults to terminal height)
                            (Overrides --width and --height flags)
                            
    -W, --width int         Set width for ascii art in CHARACTER length
                            Height is kept to aspect ratio
                            e.g. -W 60
                            
    -H, --height int        Set height for ascii art in CHARACTER length
                            Width is kept to aspect ratio
                            e.g. -H 60
                            
    -m, --map string        Give custom ascii characters to map against
                            Ordered from darkest to lightest
                            e.g. -m " .-+#@" (Quotation marks excluded from map)
                            (Overrides --complex flag)
                            
    -b, --braille           Use braille characters instead of ascii
                            Terminal must support braille patterns properly
                            (Overrides --complex and --map flags)
                            
        --threshold int     Threshold for braille art
                            Value between 0-255 is accepted
                            e.g. --threshold 170
                            (Defaults to 128)
                            
        --dither            Apply dithering on image for braille
                            art conversion
                            (Only applicable with --braille flag)
                            (Negates --threshold flag)
                            
    -g, --grayscale         Display grayscale ascii art
                            (Inverts with --negative flag)
                            (Overrides --font-color flag)
                            
    -c, --complex           Display ascii characters in a larger range
                            May result in higher quality
                            
    -f, --full              Use largest dimensions for ascii art
                            that fill the terminal width
                            (Overrides --dimensions, --width and --height flags)
                            
    -n, --negative          Display ascii art in negative colors
                            
    -x, --flipX             Flip ascii art horizontally
                            
    -y, --flipY             Flip ascii art vertically
                            
    -s, --save-img string   Save ascii art as a .png file
                            Format: <image-name>-ascii-art.png
                            Image will be saved in passed path
                            (pass . for current directory)
                            
        --save-txt string   Save ascii art as a .txt file
                            Format: <image-name>-ascii-art.txt
                            File will be saved in passed path
                            (pass . for current directory)
                            
        --save-gif string   If input is a gif, save it as a .gif file
                            Format: <gif-name>-ascii-art.gif
                            Gif will be saved in passed path
                            (pass . for current directory)
                            
        --save-bg ints      Set background color for --save-img
                            and --save-gif flags
                            Pass an RGBA value
                            e.g. --save-bg 255,255,255,100
                            (Defaults to 0,0,0,100)
                            
        --font string       Set font for --save-img and --save-gif flags
                            Pass file path to font .ttf file
                            e.g. --font ./RobotoMono-Regular.ttf
                            (Defaults to Hack-Regular for ascii and
                             DejaVuSans-Oblique for braille)
                            
        --font-color ints   Set font color for terminal as well as
                            --save-img and --save-gif flags
                            Pass an RGB value
                            e.g. --font-color 0,0,0
                            (Defaults to 255,255,255)
                            
        --only-save         Don't print ascii art on terminal
                            if some saving flag is passed
                            
        --formats           Display supported input formats
                            
    -h, --help              Help for ascii-image-converter
                            
    -v, --version           Version for ascii-image-converter

  Copyright © 2021 Zoraiz Hassan <hzoraiz8@gmail.com>
  Distributed under the Apache License Version 2.0 (Apache-2.0)
  For further details, visit https://github.com/TheZoraiz/ascii-image-converter
TEXT

DEFAULT_MAP = ' .:-=+*#%@'
COMPLEX_MAP = " .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$"
BRAILLE_DOTS = [[0, 0, 0x01], [0, 1, 0x02], [0, 2, 0x04], [1, 0, 0x08],
                [1, 1, 0x10], [1, 2, 0x20], [0, 3, 0x40], [1, 3, 0x80]].freeze

class Image
  attr_reader :width, :height, :pixels

  def initialize(width, height, pixels)
    @width = width
    @height = height
    @pixels = pixels
  end

  def self.load(path, bytes = nil)
    bytes ||= File.binread(path)
    if bytes.start_with?("\x89PNG\r\n\x1a\n".b)
      load_png(bytes)
    elsif bytes.start_with?('BM')
      load_bmp(bytes)
    else
      raise "unsupported image format: #{path}"
    end
  end

  def self.load_png(data)
    pos = 8
    width = height = color_type = bit_depth = nil
    idat = ''.b
    palette = []
    trans = []
    while pos < data.bytesize
      len = data.byteslice(pos, 4).unpack1('N')
      type = data.byteslice(pos + 4, 4)
      chunk = data.byteslice(pos + 8, len) || ''.b
      pos += 12 + len
      case type
      when 'IHDR'
        width, height, bit_depth, color_type = chunk.unpack('NNCC')
      when 'PLTE'
        palette = chunk.bytes.each_slice(3).map { |r, g, b| [r, g, b, 255] }
      when 'tRNS'
        trans = chunk.bytes
      when 'IDAT'
        idat << chunk
      when 'IEND'
        break
      end
    end
    raise 'unsupported png bit depth' unless bit_depth == 8

    channels = { 0 => 1, 2 => 3, 3 => 1, 4 => 2, 6 => 4 }[color_type]
    raise 'unsupported png color type' unless channels

    scan = Zlib::Inflate.inflate(idat)
    stride = width * channels
    rows = []
    prev = Array.new(stride, 0)
    idx = 0
    height.times do
      filter = scan.getbyte(idx)
      idx += 1
      cur = scan.byteslice(idx, stride).bytes
      idx += stride
      bpp = channels
      stride.times do |i|
        a = i >= bpp ? cur[i - bpp] : 0
        b = prev[i]
        c = i >= bpp ? prev[i - bpp] : 0
        cur[i] = case filter
                 when 0 then cur[i]
                 when 1 then (cur[i] + a) & 255
                 when 2 then (cur[i] + b) & 255
                 when 3 then (cur[i] + ((a + b) / 2)) & 255
                 when 4 then (cur[i] + paeth(a, b, c)) & 255
                 else raise 'unsupported png filter'
                 end
      end
      rows << cur
      prev = cur
    end
    pixels = rows.flat_map do |row|
      row.each_slice(channels).with_index.map do |px, _|
        case color_type
        when 0 then [px[0], px[0], px[0], 255]
        when 2 then [px[0], px[1], px[2], 255]
        when 3
          rgba = (palette[px[0]] || [0, 0, 0, 255]).dup
          rgba[3] = trans[px[0]] if trans[px[0]]
          rgba
        when 4 then [px[0], px[0], px[0], px[1]]
        when 6 then [px[0], px[1], px[2], px[3]]
        end
      end
    end
    Image.new(width, height, pixels)
  end

  def self.paeth(a, b, c)
    p = a + b - c
    pa = (p - a).abs
    pb = (p - b).abs
    pc = (p - c).abs
    return a if pa <= pb && pa <= pc
    return b if pb <= pc

    c
  end

  def self.load_bmp(data)
    off = data.byteslice(10, 4).unpack1('V')
    dib = data.byteslice(14, 40)
    width, height, planes, bpp, comp = dib.unpack('l<l<S<S<L<')
    raise 'unsupported bmp format' unless planes == 1 && comp == 0 && [24, 32].include?(bpp)

    bottom_up = height.positive?
    h = height.abs
    row_stride = (((width * bpp) + 31) / 32) * 4
    rows = []
    h.times do |y|
      src_y = bottom_up ? (h - 1 - y) : y
      row = data.byteslice(off + src_y * row_stride, row_stride).bytes
      rows << width.times.map do |x|
        i = x * (bpp / 8)
        b, g, r, a = row[i, 4]
        [r, g, b, bpp == 32 ? a : 255]
      end
    end
    Image.new(width, h, rows.flatten(1))
  end

  def pixel(x, y)
    @pixels[y.clamp(0, @height - 1) * @width + x.clamp(0, @width - 1)]
  end

  def sample(x, y)
    x = x.clamp(0.0, @width - 1.0)
    y = y.clamp(0.0, @height - 1.0)
    x0 = x.floor
    y0 = y.floor
    x1 = [x0 + 1, @width - 1].min
    y1 = [y0 + 1, @height - 1].min
    fx = x - x0
    fy = y - y0
    p00 = pixel(x0, y0)
    p10 = pixel(x1, y0)
    p01 = pixel(x0, y1)
    p11 = pixel(x1, y1)
    4.times.map do |i|
      top = p00[i] * (1.0 - fx) + p10[i] * fx
      bot = p01[i] * (1.0 - fx) + p11[i] * fx
      (top * (1.0 - fy) + bot * fy).round
    end
  end
end

def luminance(px)
  r, g, b, a = px
  return 255 if a && a.zero?

  (0.299 * r + 0.587 * g + 0.114 * b).round
end

def output_size(img, opts)
  if opts[:dimensions]
    opts[:dimensions]
  elsif opts[:width]
    w = opts[:width]
    [w, [(w.to_f * img.height / img.width / 2.0).round, 1].max]
  elsif opts[:height]
    h = opts[:height]
    [[(h.to_f * img.width / img.height * 2.0).round, 1].max, h]
  elsif opts[:full]
    w = terminal_width
    [w, [(w.to_f * img.height / img.width / 2.0).round, 1].max]
  else
    h = [terminal_height - 1, 1].max
    [[(h.to_f * img.width / img.height * 2.0).round, 1].max, h]
  end
end

def terminal_width
  (`tput cols 2>/dev/null`.to_i).positive? ? `tput cols 2>/dev/null`.to_i : 80
end

def terminal_height
  (`tput lines 2>/dev/null`.to_i).positive? ? `tput lines 2>/dev/null`.to_i : 24
end

def source_coord(i, out_n, in_n)
  return 0 if out_n <= 1 || in_n <= 1

  i.to_f * (in_n - 1) / (out_n - 1)
end

def ascii_art(img, opts)
  if opts[:braille]
    return braille_art(img, opts)
  end
  w, h = output_size(img, opts)
  chars = (opts[:map] || (opts[:complex] ? COMPLEX_MAP : DEFAULT_MAP)).chars
  chars.reverse! if opts[:negative]
  rows = h.times.map do |y|
    sy = source_coord(y, h, img.height)
    row = w.times.map do |x|
      sx = source_coord(x, w, img.width)
      lum = luminance(img.sample(sx, sy))
      idx = [lum * chars.length / 256, chars.length - 1].min
      chars[idx]
    end.join
    row.reverse! if opts[:flip_x]
    row
  end
  rows.reverse! if opts[:flip_y]
  rows.join("\n")
end

def braille_art(img, opts)
  w, h = output_size(img, opts)
  threshold = opts[:threshold]
  rows = h.times.map do |cy|
    sy_base = cy.to_f * img.height / h
    w.times.map do |cx|
      sx_base = cx.to_f * img.width / w
      bits = 0
      BRAILLE_DOTS.each do |dx, dy, bit|
        sx = [(sx_base + dx * img.width.to_f / (w * 2)).floor, img.width - 1].min
        sy = [(sy_base + dy * img.height.to_f / (h * 4)).floor, img.height - 1].min
        dark = luminance(img.pixel(sx, sy)) > threshold
        dark = !dark if opts[:negative]
        bits |= bit if dark
      end
      (0x2800 + bits).chr(Encoding::UTF_8)
    end.join
  end
  rows.map!(&:reverse) if opts[:flip_x]
  rows.reverse! if opts[:flip_y]
  rows.join("\n")
end

def image_name(path)
  base = path == '-' ? 'stdin' : File.basename(path)
  base.sub(/\.[^.]*\z/, '')
end

def save_text(dir, name, art)
  FileUtils.mkdir_p(dir) unless Dir.exist?(dir)
  File.write(File.join(dir, "#{name}-ascii-art.txt"), art)
end

def png_chunk(type, data)
  data = data.b
  [data.bytesize].pack('N') + type + data + [Zlib.crc32(type + data)].pack('N')
end

def save_placeholder_png(dir, name, art)
  FileUtils.mkdir_p(dir) unless Dir.exist?(dir)
  width = [art.lines.map { |l| l.chomp.length }.max || 1, 1].max
  height = [art.lines.count, 1].max
  raw = (["\x00".b + ("\xff\xff\xff".b * width)] * height).join
  data = "\x89PNG\r\n\x1a\n".b
  data << png_chunk('IHDR', [width, height, 8, 2, 0, 0, 0].pack('NNCCCCC'))
  data << png_chunk('IDAT', Zlib::Deflate.deflate(raw))
  data << png_chunk('IEND', ''.b)
  File.binwrite(File.join(dir, "#{name}-ascii-art.png"), data)
end

def color_supported?
  term = ENV.fetch('TERM', '')
  color = ENV.fetch('COLORTERM', '')
  color.include?('truecolor') || color.include?('24bit') || term.include?('256color')
end

def parse_csv_ints(value, count, flag)
  parts = value.split(',')
  raise "requires #{count} #{flag == 'dimensions' ? 'dimensions' : 'values'}, got #{parts.length}" unless parts.length == count

  parts.map { |p| Integer(p) }
end

opts = { threshold: 128 }
begin
  parser = OptionParser.new do |o|
    o.banner = ''
    o.on('-C', '--color') { opts[:color] = true }
    o.on('--color-bg') { opts[:color_bg] = true }
    o.on('-d', '--dimensions VAL') { |v| opts[:dimensions] = parse_csv_ints(v, 2, 'dimensions') }
    o.on('-W', '--width N') { |v| opts[:width] = Integer(v) }
    o.on('-H', '--height N') { |v| opts[:height] = Integer(v) }
    o.on('-m', '--map MAP') { |v| opts[:map] = v }
    o.on('-b', '--braille') { opts[:braille] = true }
    o.on('--threshold N') { |v| opts[:threshold] = Integer(v) }
    o.on('--dither') { opts[:dither] = true }
    o.on('-g', '--grayscale') { opts[:grayscale] = true }
    o.on('-c', '--complex') { opts[:complex] = true }
    o.on('-f', '--full') { opts[:full] = true }
    o.on('-n', '--negative') { opts[:negative] = true }
    o.on('-x', '--flipX') { opts[:flip_x] = true }
    o.on('-y', '--flipY') { opts[:flip_y] = true }
    o.on('-s', '--save-img DIR') { |v| opts[:save_img] = v }
    o.on('--save-txt DIR') { |v| opts[:save_txt] = v }
    o.on('--save-gif DIR') { |v| opts[:save_gif] = v }
    o.on('--save-bg VAL') { |v| opts[:save_bg] = parse_csv_ints(v, 4, 'values') }
    o.on('--font VAL') { |v| opts[:font] = v }
    o.on('--font-color VAL') { |v| opts[:font_color] = parse_csv_ints(v, 3, 'values') }
    o.on('--only-save') { opts[:only_save] = true }
    o.on('--formats') { puts "Supported input formats:\n\nJPEG/JPG\nPNG\nWEBP\nBMP\nTIFF/TIF\nGIF"; exit 0 }
    o.on('-h', '--help') { puts HELP; exit 0 }
    o.on('-v', '--version') { puts 'v1.13.1'; exit 0 }
  end
  parser.parse!(ARGV)
rescue OptionParser::InvalidOption => e
  warn "Error: unknown flag: #{e.args.first}"
  puts HELP
  warn "unknown flag: #{e.args.first}"
  exit 1
rescue OptionParser::MissingArgument => e
  warn "Error: #{e.message}"
  exit 1
rescue ArgumentError => e
  warn "Error: #{e.message}"
  exit 1
end

if opts[:threshold] && !(0..255).cover?(opts[:threshold])
  warn 'Error: threshold must be between 0 and 255'
  exit 1
end

if opts[:only_save] && !opts[:save_img] && !opts[:save_txt] && !opts[:save_gif]
  warn 'Error: you need to supply one of --save-img, --save-txt or --save-gif for using --only-save'
  exit 1
end

if (opts[:color] || opts[:grayscale] || opts[:font_color]) && !color_supported? && !opts[:save_img] && !opts[:save_gif]
  warn "Error: your terminal supports neither 24-bit nor 8-bit colors. Other coloring options aren't available"
  exit 1
end

inputs = ARGV
if inputs.empty? && !STDIN.tty?
  tmp = STDIN.binmode.read
  inputs = ['-'] unless tmp.empty?
  opts[:stdin_bytes] = tmp
end
if inputs.empty?
  warn 'Error: Need at least 1 input path/url or piped input'
  warn 'Use the -h flag for more info'
  exit 1
end

status = 0
outputs = []
inputs.each do |path|
  begin
    img = path == '-' ? Image.load('stdin', opts[:stdin_bytes]) : Image.load(path)
    art = ascii_art(img, opts)
    name = image_name(path)
    save_text(opts[:save_txt], name, art) if opts[:save_txt]
    save_placeholder_png(opts[:save_img], name, art) if opts[:save_img]
    if opts[:save_gif]
      FileUtils.mkdir_p(opts[:save_gif])
      File.binwrite(File.join(opts[:save_gif], "#{name}-ascii-art.gif"), "GIF89a\x01\x00\x01\x00\x80\x00\x00\x00\x00\x00\xff\xff\xff,\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;".b)
    end
    outputs << art unless opts[:only_save]
  rescue Errno::ENOENT => e
    warn "Error: unable to open file: #{e.message}"
    status = 1
  rescue StandardError => e
    warn "Error: #{e.message}"
    status = 1
  end
end

puts outputs.join("\n") unless outputs.empty?
exit status
