#!/usr/bin/env ruby
# frozen_string_literal: true

LINTS = {
  1 => ["bool_comparison", "Unnecessary comparison with boolean"],
  2 => ["empty_let_in", "This let-in expression is empty"],
  3 => ["manual_inherit", "Assignment instead of inherit"],
  4 => ["manual_inherit_from", "Assignment instead of inherit from"],
  5 => ["legacy_let_syntax", "Legacy let syntax"],
  6 => ["collapsible_let_in", "These let-in expressions can be merged"],
  7 => ["eta_reduction", "This function can be eta-reduced"],
  8 => ["useless_parens", "These parentheses can be omitted"],
  10 => ["empty_pattern", "Found empty pattern"],
  11 => ["redundant_pattern_bind", "Found redundant pattern bind"],
  12 => ["unquoted_uri", "Found unquoted URI expression"],
  14 => ["empty_inherit", "Found empty inherit"],
  17 => ["deprecated_to_path", "Found deprecated toPath"],
  18 => ["bool_simplification", "Boolean expression can be simplified"],
  19 => ["useless_has_attr", "This expression can use `or` instead"],
  20 => ["repeated_keys", "Found repeated keys"],
  23 => ["empty_list_concat", "Found list concatenation with empty list"]
}.freeze

EXPLAINS = {
1 => "## What it does\nChecks for expressions of the form `x == true`, `x != true` and\nsuggests using the variable directly.\n\n## Why is this bad?\nUnnecessary code.\n\n## Example\nInstead of checking the value of `x`:\n\n```nix\nif x == true then 0 else 1\n```\n\nUse `x` directly:\n\n```nix\nif x then 0 else 1\n```",
2 => "## What it does\nChecks for `let-in` expressions which create no new bindings.\n\n## Why is this bad?\n`let-in` expressions that create no new bindings are useless.\nThese are probably remnants from debugging or editing expressions.\n\n## Example\n\n```nix\nlet in pkgs.statix\n```\n\nPreserve only the body of the `let-in` expression:\n\n```nix\npkgs.statix\n```",
3 => "## What it does\nChecks for bindings of the form `a = a`.\n\n## Why is this bad?\nIf the aim is to bring attributes from a larger scope into\nthe current scope, prefer an inherit statement.\n\n## Example\n\n```nix\nlet\n  a = 2;\nin\n  { a = a; b = 3; }\n```\n\nTry `inherit` instead:\n\n```nix\nlet\n  a = 2;\nin\n  { inherit a; b = 3; }\n```",
4 => "## What it does\nChecks for bindings of the form `a = someAttr.a`.\n\n## Why is this bad?\nIf the aim is to extract or bring attributes of an attrset into\nscope, prefer an inherit statement.\n\n## Example\n\n```nix\nlet\n  mtl = pkgs.haskellPackages.mtl;\nin\n  null\n```\n\nTry `inherit` instead:\n\n```nix\nlet\n  inherit (pkgs.haskellPackages) mtl;\nin\n  null\n```",
5 => "## What it does\nChecks for legacy-let syntax that was never formalized.\n\n## Why is this bad?\nThis syntax construct is undocumented, refrain from using it.\n\n## Example\n\nLegacy let syntax makes use of an attribute set annotated with\n`let` and expects a `body` attribute.\n```nix\nlet {\n  body = x + y;\n  x = 2;\n  y = 3;\n}\n```\n\nThis is trivially representible via `rec`, which is documented\nand more widely known:\n\n```nix\nrec {\n  body = x + y;\n  x = 2;\n  y = 3;\n}.body\n```",
6 => "## What it does\nChecks for `let-in` expressions whose body is another `let-in`\nexpression.\n\n## Why is this bad?\nUnnecessary code, the `let-in` expressions can be merged.\n\n## Example\n\n```nix\nlet\n  a = 2;\nin\nlet\n  b = 3;\nin\n  a + b\n```\n\nMerge both `let-in` expressions:\n\n```nix\nlet\n  a = 2;\n  b = 3;\nin\n  a + b\n```",
7 => "## What it does\nChecks for eta-reducible functions, i.e.: converts lambda\nexpressions into free standing functions where applicable.\n\n## Why is this bad?\nOftentimes, eta-reduction results in code that is more natural\nto read.\n\n## Example\n\n```nix\nlet\n  double = i: 2 * i;\nin\nmap (x: double x) [ 1 2 3 ]\n```\n\nThe lambda passed to the `map` function is eta-reducible, and the\nresult reads more naturally:\n\n```nix\nlet\n  double = i: 2 * i;\nin\nmap double [ 1 2 3 ]\n```",
8 => "## What it does\nChecks for unnecessary parentheses.\n\n## Why is this bad?\nUnnecessarily parenthesized code is hard to read.\n\n## Example\n\n```nix\nlet\n  double = (x: 2 * x);\n  ls = map (double) [ 1 2 3 ];\nin\n  (2 + 3)\n```\n\nRemove unnecessary parentheses:\n\n```nix\nlet\n  double = x: 2 * x;\n  ls = map double [ 1 2 3 ];\nin\n  2 + 3\n```",
10 => "## What it does\nChecks for an empty variadic pattern: `{...}`, in a function\nargument.\n\n## Why is this bad?\nThe intention with empty patterns is not instantly obvious. Prefer\nan underscore identifier instead, to indicate that the argument\nis being ignored.\n\n## Example\n\n```nix\nclient = { ... }: {\n  services.irmaseal-pkg.enable = true;\n};\n```\n\nReplace the empty variadic pattern with `_` to indicate that you\nintend to ignore the argument:\n\n```nix\nclient = _: {\n  services.irmaseal-pkg.enable = true;\n};\n```",
11 => "## What it does\nChecks for binds of the form `inputs @ { ... }` in function\narguments.\n\n## Why is this bad?\nThe variadic pattern here is redundant, as it does not capture\nanything.\n\n## Example\n\n```nix\ninputs @ { ... }: inputs.nixpkgs\n```\n\nRemove the pattern altogether:\n\n```nix\ninputs: inputs.nixpkgs\n```",
12 => "## What it does\nChecks for URI expressions that are not quoted.\n\n## Why is this bad?\nThe Nix language has a special syntax for URLs even though quoted\nstrings can also be used to represent them. Unlike paths, URLs do\nnot have any special properties in the Nix expression language\nthat would make the difference useful. Moreover, using variable\nexpansion in URLs requires some URLs to be quoted strings anyway.\nSo the most consistent approach is to always use quoted strings to\nrepresent URLs. Additionally, a semicolon immediately after the\nURL can be mistaken for a part of URL by language-agnostic tools\nsuch as terminal emulators.\n\nSee RFC 00045 [1] for more.\n\n[1]: https://github.com/NixOS/rfcs/blob/master/rfcs/0045-deprecate-url-syntax.md\n\n## Example\n\n```nix\ninputs = {\n  gitignore.url = github:hercules-ci/gitignore.nix;\n}\n```\n\nQuote the URI expression:\n\n```nix\ninputs = {\n  gitignore.url = \"github:hercules-ci/gitignore.nix\";\n}\n```",
14 => "## What it does\nChecks for empty inherit statements.\n\n## Why is this bad?\nUseless code, probably the result of a refactor.\n\n## Example\n\n```nix\ninherit;\n```\n\nRemove it altogether.",
17 => "## What it does\nChecks for usage of the `toPath` function.\n\n## Why is this bad?\n`toPath` is deprecated.\n\n## Example\n\n```nix\nbuiltins.toPath \"/path\"\n```\n\nTry these instead:\n\n```nix\n# to convert the string to an absolute path:\n/. + \"/path\"\n# => /abc\n\n# to convert the string to a path relative to the current directory:\n./. + \"/bin\"\n# => /home/np/statix/bin\n```",
18 => "## What it does\nChecks for boolean expressions that can be simplified.\n\n## Why is this bad?\nComplex booleans affect readibility.\n\n## Example\n```nix\nif !(x == y) then 0 else 1\n```\n\nUse `!=` instead:\n\n```nix\nif x != y then 0 else 1\n```",
19 => "## What it does\nChecks for expressions that use the \"has attribute\" operator: `?`,\nwhere the `or` operator would suffice.\n\n## Why is this bad?\nThe `or` operator is more readable.\n\n## Example\n```nix\nif x ? a then x.a else some_default\n```\n\nUse `or` instead:\n\n```nix\nx.a or some_default\n```",
20 => "## What it does\nChecks for keys in attribute sets with repetitive keys, and suggests using\nan attribute set instead.\n\n## Why is this bad?\nAvoiding repetetion helps improve readibility.\n\n## Example\n```nix\n{\n  foo.a = 1;\n  foo.b = 2;\n  foo.c = 3;\n}\n```\n\nDon't repeat.\n```nix\n{\n  foo = {\n    a = 1;\n    b = 2;\n    c = 3;\n  };\n}\n```",
23 => "## What it does\nChecks for concatenations to empty lists\n\n## Why is this bad?\nConcatenation with the empty list is a no-op.\n\n## Example\n```nix\n[] ++ something\n```\n\nRemove the operation:\n\n```nix\nsomething\n```"
}.freeze

def main_help
  "statix 0.5.8\n\nAkshay <nerdy@peppe.rs>\n\nLints and suggestions for the Nix programming language\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nOPTIONS:\n    -h, --help       Print help information\n    -V, --version    Print version information\n\nSUBCOMMANDS:\n    check      Lints and suggestions for the nix programming language\n    dump       Dump a sample config to stdout\n    explain    Print detailed explanation for a lint warning\n    fix        Find and fix issues raised by statix-check\n    help       Print this message or the help of the given subcommand(s)\n    list       List all available lints\n    single     Fix exactly one issue at provided position"
end

def sub_help(name)
  case name
  when "check"
    "executable-check \n\nLints and suggestions for the nix programming language\n\nUSAGE:\n    executable check [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run check on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -o, --format <FORMAT>       Output format. Supported values: stderr, errfmt [default: stderr]\n    -s, --stdin                 Enable \"streaming\" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files"
  when "fix"
    "executable-fix \n\nFind and fix issues raised by statix-check\n\nUSAGE:\n    executable fix [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run fix on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run               Do not fix files in place, display a diff instead\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -s, --stdin                 Enable \"streaming\" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files"
  when "single"
    "executable-single \n\nFix exactly one issue at provided position\n\nUSAGE:\n    executable single [OPTIONS] --position <POSITION> [TARGET]\n\nARGS:\n    <TARGET>    File to run single-fix on\n\nOPTIONS:\n    -c, --config <CONF_PATH>     Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run                Do not fix files in place, display a diff instead\n    -h, --help                   Print help information\n    -p, --position <POSITION>    Position to attempt a fix at\n    -s, --stdin                  Enable \"streaming\" mode, accept file on stdin, output diagnostics\n                                 on stdout"
  when "dump" then "executable-dump \n\nDump a sample config to stdout\n\nUSAGE:\n    executable dump\n\nOPTIONS:\n    -h, --help    Print help information"
  when "explain" then "executable-explain \n\nPrint detailed explanation for a lint warning\n\nUSAGE:\n    executable explain <TARGET>\n\nARGS:\n    <TARGET>    Warning code to explain\n\nOPTIONS:\n    -h, --help    Print help information"
  when "list" then "executable-list \n\nList all available lints\n\nUSAGE:\n    executable list\n\nOPTIONS:\n    -h, --help    Print help information"
  end
end

Finding = Struct.new(:code, :line, :col, :len, :note, keyword_init: true)

def disabled_lints(config_path)
  paths = []
  paths << config_path if config_path
  paths << File.join(config_path, "statix.toml") if config_path && File.directory?(config_path)
  paths << "statix.toml"
  file = paths.find { |p| p && File.file?(p) }
  return [] unless file
  txt = File.read(file)
  m = txt.match(/disabled\s*=\s*\[([^\]]*)\]/m)
  return [] unless m
  m[1].scan(/W?(\d+)/i).flatten.map(&:to_i)
end

def line_col(text, idx)
  pre = text[0...idx]
  line = pre.count("\n") + 1
  last = pre.rindex("\n")
  col = idx - (last || -1)
  [line, col]
end

def add_finding(list, text, idx, code, len, note = nil)
  line, col = line_col(text, idx)
  note ||= default_note(code)
  list << Finding.new(code: code, line: line, col: col, len: len, note: note)
end

def default_note(code)
  case code
  when 1 then "Unnecessary comparison with boolean literal"
  when 3 then "This assignment is better written with `inherit`"
  when 4 then "This assignment is better written with `inherit`"
  when 8 then "These parentheses can be omitted"
  when 10 then "This empty pattern can be replaced with `_`"
  when 11 then "This pattern bind is redundant"
  when 12 then "This URI can be quoted"
  when 14 then "This empty inherit can be removed"
  when 17 then "`toPath` is deprecated"
  when 18 then "This boolean expression can be simplified"
  when 19 then "This expression can use `or` instead"
  when 20 then "This key prefix is repeated"
  when 23 then "This empty list concatenation can be removed"
  else LINTS[code]&.[](1) || "warning"
  end
end

def find_lints(text, disabled = [])
  fs = []
  unless disabled.include?(1)
    text.to_enum(:scan, /\b([A-Za-z_][\w.'-]*)\s*(==|!=)\s*(true|false)\b/).each do
      m = Regexp.last_match
      expr, op, lit = m[1], m[2], m[3]
      add_finding(fs, text, m.begin(0), 1, m[0].length, "Comparing `#{expr}` with boolean literal `#{lit}`")
    end
  end
  unless disabled.include?(2)
    text.to_enum(:scan, /\blet\s+in\b/).each { add_finding(fs, text, Regexp.last_match.begin(0), 2, Regexp.last_match[0].length) }
  end
  unless disabled.include?(3) && disabled.include?(4)
    text.to_enum(:scan, /^(\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'.-]*)\s*;/).each do
      m = Regexp.last_match
      lhs = m[2]
      rhs = m[3]
      if lhs == rhs && !disabled.include?(3)
        add_finding(fs, text, m.begin(2), 3, m[0].strip.length)
      elsif rhs.end_with?(".#{lhs}") && !disabled.include?(4)
        add_finding(fs, text, m.begin(2), 4, m[0].strip.length)
      end
    end
  end
  unless disabled.include?(5)
    text.to_enum(:scan, /\blet\s*\{/).each { add_finding(fs, text, Regexp.last_match.begin(0), 5, Regexp.last_match[0].length) }
  end
  unless disabled.include?(6)
    text.to_enum(:scan, /\bin\s*\n\s*let\b/).each { add_finding(fs, text, Regexp.last_match.begin(0), 6, Regexp.last_match[0].length) }
  end
  unless disabled.include?(7)
    text.to_enum(:scan, /\(\s*([A-Za-z_]\w*)\s*:\s*([A-Za-z_][\w'.-]*)\s+\1\s*\)/).each { add_finding(fs, text, Regexp.last_match.begin(0), 7, Regexp.last_match[0].length) }
  end
  unless disabled.include?(8)
    text.to_enum(:scan, /\(([A-Za-z_][\w'.-]*|\d+|[A-Za-z_]\w*\s*:\s*[^()\n]+|[^()\n]+\s+[+\-*\/]\s+[^()\n]+)\)/).each { add_finding(fs, text, Regexp.last_match.begin(0), 8, Regexp.last_match[0].length) }
  end
  unless disabled.include?(10)
    text.to_enum(:scan, /\{\s*\.\.\.\s*\}\s*:/).each { add_finding(fs, text, Regexp.last_match.begin(0), 10, Regexp.last_match[0].length) }
  end
  unless disabled.include?(11)
    text.to_enum(:scan, /\b([A-Za-z_]\w*)\s*@\s*\{\s*\.\.\.\s*\}\s*:/).each { add_finding(fs, text, Regexp.last_match.begin(0), 11, Regexp.last_match[0].length) }
  end
  unless disabled.include?(12)
    text.to_enum(:scan, /(?<!["'])\b([A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_?&=%\/.+#~-]+)(?!["'])/).each { add_finding(fs, text, Regexp.last_match.begin(1), 12, Regexp.last_match[1].length) }
  end
  unless disabled.include?(14)
    text.to_enum(:scan, /\binherit\s*;/).each { add_finding(fs, text, Regexp.last_match.begin(0), 14, Regexp.last_match[0].length) }
  end
  unless disabled.include?(17)
    text.to_enum(:scan, /\b(?:builtins\.)?toPath\b/).each { add_finding(fs, text, Regexp.last_match.begin(0), 17, Regexp.last_match[0].length) }
  end
  unless disabled.include?(18)
    text.to_enum(:scan, /!\s*\(\s*([^)]+?)\s*(==|!=)\s*([^)]+?)\s*\)/).each { add_finding(fs, text, Regexp.last_match.begin(0), 18, Regexp.last_match[0].length) }
  end
  unless disabled.include?(19)
    text.to_enum(:scan, /\bif\s+([A-Za-z_][\w'.-]*)\s*\?\s*([A-Za-z_][\w'-]*)\s+then\s+\1\.\2\s+else\s+([^\n;]+)/).each { add_finding(fs, text, Regexp.last_match.begin(0), 19, Regexp.last_match[0].length) }
  end
  unless disabled.include?(20)
    prefixes = Hash.new { |h, k| h[k] = [] }
    text.to_enum(:scan, /^\s*([A-Za-z_][\w'-]*)\.([A-Za-z_][\w'.-]*)\s*=/).each { prefixes[Regexp.last_match[1]] << Regexp.last_match.begin(1) }
    prefixes.each_value { |idxs| add_finding(fs, text, idxs.first, 20, 1) if idxs.length > 1 }
  end
  unless disabled.include?(23)
    text.to_enum(:scan, /\[\s*\]\s*\+\+|\+\+\s*\[\s*\]/).each { add_finding(fs, text, Regexp.last_match.begin(0), 23, Regexp.last_match[0].length) }
  end
  fs.sort_by { |f| [f.line, f.col, f.code] }
end

def apply_fixes(text, one_pos = nil)
  original = text.dup
  fixers = [
    proc { |s| s.gsub(/\b([A-Za-z_][\w.'-]*)\s*==\s*true\b/, '\1').gsub(/\b([A-Za-z_][\w.\'-]*)\s*!=\s*false\b/, '\1').gsub(/\b([A-Za-z_][\w.\'-]*)\s*==\s*false\b/, '!\1').gsub(/\b([A-Za-z_][\w.\'-]*)\s*!=\s*true\b/, '!\1') },
    proc { |s| s.gsub(/^(\s*)([A-Za-z_][\w'-]*)\s*=\s*\2\s*;/, '\1inherit \2;') },
    proc { |s| s.gsub(/^(\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'.-]*)\.\2\s*;/) { "#{$1}inherit (#{$3}) #{$2};" } },
    proc { |s| s.gsub(/\blet\s+in\s+/, '') },
    proc { |s| s.gsub(/\(\s*([A-Za-z_]\w*)\s*:\s*([A-Za-z_][\w'.-]*)\s+\1\s*\)/, '\2') },
    proc { |s| s.gsub(/\{\s*\.\.\.\s*\}\s*:/, '_:') },
    proc { |s| s.gsub(/\b([A-Za-z_]\w*)\s*@\s*\{\s*\.\.\.\s*\}\s*:/, '\1:') },
    proc { |s| s.gsub(/\binherit\s*;\s*\n?/, '') },
    proc { |s| s.gsub(/!\s*\(\s*([^)]+?)\s*==\s*([^)]+?)\s*\)/, '\1 != \2').gsub(/!\s*\(\s*([^)]+?)\s*!=\s*([^)]+?)\s*\)/, '\1 == \2') },
    proc { |s| s.gsub(/\bif\s+([A-Za-z_][\w'.-]*)\s*\?\s*([A-Za-z_][\w'-]*)\s+then\s+\1\.\2\s+else\s+([^\n;]+)/, '\1.\2 or \3') },
    proc { |s| s.gsub(/\[\s*\]\s*\+\+\s*/, '').gsub(/\s*\+\+\s*\[\s*\]/, '') },
    proc { |s| s.gsub(/(?<!["'])\b([A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_?&=%\/.+#~-]+)(?!["'])/, '"\1"') },
    proc do |s|
      s.gsub(/\((\s*[A-Za-z_][\w'.-]*\s*|\s*\d+\s*)\)/) do |m|
        before = Regexp.last_match.pre_match[-8, 8].to_s
        before =~ /inherit\s*$/ ? m : Regexp.last_match[1]
      end
    end
  ]
  if one_pos
    fs = find_lints(text)
    target = fs.find { |f| f.line == one_pos[0] && f.col <= one_pos[1] && one_pos[1] <= f.col + f.len } || fs.find { |f| f.line == one_pos[0] }
    return text unless target
  end
  fixers.each { |fx| text = fx.call(text) }
  text == original ? original : text
end

def parse_common(argv)
  opts = { stdin: false, dry: false, format: "stderr", config: ".", ignores: [], target: nil, position: nil }
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when "-h", "--help" then opts[:help] = true
    when "-s", "--stdin" then opts[:stdin] = true
    when "-d", "--dry-run" then opts[:dry] = true
    when "-u", "--unrestricted" then nil
    when "-o", "--format" then i += 1; opts[:format] = argv[i] || "stderr"
    when "-c", "--config" then i += 1; opts[:config] = argv[i] || "."
    when "-i", "--ignore" then i += 1; opts[:ignores] << argv[i] if argv[i]
    when "-p", "--position" then i += 1; opts[:position] = argv[i]
    when "--" then i += 1; opts[:target] = argv[i]; break
    else
      opts[:target] = a unless a.start_with?("-")
    end
    i += 1
  end
  opts
end

def target_files(target, ignores = [])
  target ||= "."
  if File.directory?(target)
    Dir.glob(File.join(target, "**", "*.nix")).reject { |p| ignores.any? { |g| File.fnmatch?(g, p) || File.fnmatch?(g, File.basename(p)) } }.sort
  elsif File.file?(target)
    [target]
  else
    warn "path error: No such file or directory (os error 2)"
    []
  end
end

def print_findings(path, text, findings, format)
  if format == "errfmt"
    findings.each { |f| puts "#{path}>#{f.line}:#{f.col}:W:#{f.code}:#{f.note}" }
  else
    findings.each do |f|
      name = LINTS[f.code][1]
      puts "[W%02d] Warning: %s" % [f.code, name]
      puts "   --> #{path}:#{f.line}:#{f.col}"
      puts "    | #{text.lines[f.line - 1].to_s.chomp}"
      puts "    = #{f.note}"
    end
  end
end

def unified_diff(path, old, new)
  return "" if old == new
  a = old.lines
  b = new.lines
  out = +"--- #{path}\n+++ #{path} [fixed]\n@@ -1,#{a.length} +1,#{b.length} @@\n"
  max = [a.length, b.length].max
  (0...max).each do |i|
    if a[i] == b[i]
      out << " #{a[i]}" if a[i]
    else
      out << "-#{a[i]}" if a[i]
      out << "+#{b[i]}" if b[i]
    end
  end
  out
end

cmd = ARGV.shift
case cmd
when nil, "help"
  if ARGV[0] && sub_help(ARGV[0])
    puts sub_help(ARGV[0])
    exit 0
  end
  puts main_help
  exit(cmd.nil? ? 2 : 0)
when "-h", "--help"
  puts main_help
when "-V", "--version"
  puts "statix 0.5.8"
when "dump"
  if ARGV.include?("-h") || ARGV.include?("--help")
    puts sub_help("dump")
  else
    puts "disabled = []\nignore = ['.direnv']\n"
  end
when "list"
  if ARGV.include?("-h") || ARGV.include?("--help")
    puts sub_help("list")
  else
    LINTS.each { |code, (name, _)| puts "W%02d %s" % [code, name] }
  end
when "explain"
  if ARGV.include?("-h") || ARGV.include?("--help")
    puts sub_help("explain")
  else
    code = ARGV[0].to_s[/\d+/].to_i
    if EXPLAINS[code]
      puts EXPLAINS[code]
    elsif ARGV[0].to_s =~ /^W?\d+$/i
      puts "explain error: lint with code `#{code}` not found"
    else
      puts "syntax error"
    end
  end
when "check"
  opts = parse_common(ARGV)
  if opts[:help]
    puts sub_help("check")
    exit 0
  end
  disabled = disabled_lints(opts[:config])
  any = false
  if opts[:stdin]
    text = STDIN.read
    fs = find_lints(text, disabled)
    print_findings("<stdin>", text, fs, opts[:format])
    any ||= !fs.empty?
  else
    target_files(opts[:target], opts[:ignores]).each do |path|
      text = File.read(path)
      fs = find_lints(text, disabled)
      print_findings(path, text, fs, opts[:format])
      any ||= !fs.empty?
    end
  end
  exit(any ? 1 : 0)
when "fix"
  opts = parse_common(ARGV)
  if opts[:help]
    puts sub_help("fix")
    exit 0
  end
  if opts[:stdin]
    print apply_fixes(STDIN.read)
  else
    target_files(opts[:target], opts[:ignores]).each do |path|
      old = File.read(path)
      new = apply_fixes(old)
      if opts[:dry]
        print unified_diff(path, old, new)
      elsif new != old
        File.write(path, new)
      end
    end
  end
when "single"
  opts = parse_common(ARGV)
  if opts[:help]
    puts sub_help("single")
    exit 0
  end
  pos = opts[:position].to_s.split(/[: ,]/).map(&:to_i)
  if opts[:stdin]
    print apply_fixes(STDIN.read, pos)
  elsif opts[:target]
    old = File.read(opts[:target])
    new = apply_fixes(old, pos)
    opts[:dry] ? print(unified_diff(opts[:target], old, new)) : File.write(opts[:target], new)
  end
else
  warn "error: Found argument '#{cmd}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help"
  exit 2
end
