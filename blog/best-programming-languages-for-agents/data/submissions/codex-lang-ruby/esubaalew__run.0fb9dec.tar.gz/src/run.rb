#!/usr/bin/env ruby
# frozen_string_literal: true

HELP = <<~TEXT
  Universal multi-language runner and REPL

  Usage: executable [OPTIONS] [ARGS]...

  Arguments:
    [ARGS]...  Positional arguments (language, code, or file)

  Options:
    -V, --version      Print version information and exit
    -l, --lang <LANG>  Explicitly choose the language to execute
    -f, --file <PATH>  Execute code from the provided file path
    -c, --code <CODE>  Execute the provided code snippet
        --no-detect    Disable heuristic language detection
    -h, --help         Print help
TEXT

VERSION = <<~TEXT
  run-kit 0.3.2
  Universal multi-language runner and smart REPL
  author: Esubalew Chekol <esubalewchekol6@gmail.com>
  homepage: https://esubalew.et
  repository: https://github.com/Esubaalew/run
  license: Apache-2.0
  commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)
  built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]
  rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)
TEXT

AVAILABLE = %w[
  bash c cpp crystal csharp dart elixir go groovy haskell java javascript julia
  kotlin lua nim perl php python r ruby rust swift typescript zig
].freeze

ALIASES = {
  'rb' => 'ruby',
  'sh' => 'bash',
  'shell' => 'bash',
  'py' => 'python',
  'python3' => 'python',
  'js' => 'javascript',
  'node' => 'javascript',
  'ts' => 'typescript',
  'rs' => 'rust',
  'c++' => 'cpp',
  'cc' => 'cpp',
  'cs' => 'csharp'
}.freeze

EXTENSIONS = {
  '.rb' => 'ruby',
  '.sh' => 'bash',
  '.bash' => 'bash',
  '.py' => 'python',
  '.js' => 'javascript',
  '.ts' => 'typescript',
  '.lua' => 'lua',
  '.c' => 'c',
  '.cc' => 'cpp',
  '.cpp' => 'cpp',
  '.cxx' => 'cpp',
  '.rs' => 'rust',
  '.go' => 'go',
  '.pl' => 'perl',
  '.php' => 'php',
  '.java' => 'java',
  '.kt' => 'kotlin',
  '.kts' => 'kotlin',
  '.swift' => 'swift',
  '.zig' => 'zig',
  '.r' => 'r',
  '.R' => 'r',
  '.ex' => 'elixir',
  '.exs' => 'elixir',
  '.dart' => 'dart',
  '.cr' => 'crystal',
  '.nim' => 'nim',
  '.groovy' => 'groovy',
  '.hs' => 'haskell'
}.freeze

def die_clap(message, status = 2)
  STDERR.puts message
  STDERR.puts
  STDERR.puts "For more information, try '--help'."
  exit status
end

def normalize_language(lang)
  return nil if lang.nil? || lang.empty?

  key = lang.downcase
  ALIASES.fetch(key, key)
end

def language_from_file(path)
  EXTENSIONS[File.extname(path)] || 'python'
end

def detect_language(code)
  s = code.to_s.strip
  return 'bash' if s =~ /\A(?:echo|cd|pwd|ls|cat|grep|sed|awk|printf|export|for |while |if \[|#!.*(?:ba|z|)sh)/m
  return 'ruby' if s =~ /\b(?:puts|p|require|def|class|module|STDIN|ARGV|end)\b/
  return 'javascript' if s.include?('console.log') || s =~ /\b(?:const|let|var|function)\b/
  return 'lua' if s =~ /\Aprint\s*\(/
  return 'python' if s =~ /\b(?:import sys|from |print\s*\(|def\s+\w+\(|class\s+\w+|if __name__)\b/

  'python'
end

def wait_status(pid)
  Process.wait(pid)
  status = $?
  exit(status.exited? ? status.exitstatus : 1)
end

def exec_child(*argv)
  pid = Process.spawn(*argv, in: STDIN, out: STDOUT, err: STDERR)
  wait_status(pid)
rescue Errno::ENOENT
  exit 127
end

def unavailable(lang)
  case lang
  when 'python'
    puts 'python is not available in the ruby-mandated arm'
    exit 127
  when 'lua'
    warn 'Error: Lua support requires the `lua` executable. Install it from https://www.lua.org/download.html and ensure it is on your PATH.'
    exit 1
  when 'rust'
    warn 'Error: Rust support requires the `rustc` executable. Install it via Rustup and ensure it is on your PATH.'
    exit 1
  when 'go'
    warn 'Error: Go support requires the `go` executable. Install it from https://go.dev/dl/ and ensure it is on your PATH.'
    exit 1
  when 'javascript', 'typescript'
    exit 127
  else
    warn "Error: #{lang.capitalize} support is not available in this build."
    exit 1
  end
end

def run_code(lang, code)
  case lang
  when 'ruby'
    exec_child('ruby', '-e', code)
  when 'bash'
    exec_child('/usr/bin/bash', '-lc', code)
  when 'perl'
    exec_child('perl', '-e', code)
  when 'php'
    exec_child('php', '-r', code)
  else
    unavailable(lang)
  end
end

def run_file(lang, path)
  case lang
  when 'ruby'
    exec_child('ruby', path)
  when 'bash'
    exec_child('/usr/bin/bash', path)
  when 'perl'
    exec_child('perl', path)
  when 'php'
    exec_child('php', path)
  else
    unavailable(lang)
  end
end

opts = { detect: true }
args = []
i = 0

while i < ARGV.length
  arg = ARGV[i]
  case arg
  when '-h', '--help'
    print HELP
    exit 0
  when '-V', '--version'
    print VERSION
    exit 0
  when '--no-detect'
    opts[:detect] = false
  when '-l', '--lang'
    i += 1
    die_clap("error: a value is required for '--lang <LANG>' but none was supplied") if i >= ARGV.length
    opts[:lang] = ARGV[i]
  when '-f', '--file'
    i += 1
    die_clap("error: a value is required for '--file <PATH>' but none was supplied") if i >= ARGV.length
    opts[:file] = ARGV[i]
  when '-c', '--code'
    i += 1
    die_clap("error: a value is required for '--code <CODE>' but none was supplied") if i >= ARGV.length
    opts[:code] = ARGV[i]
  else
    if arg.start_with?('-')
      STDERR.puts "error: unexpected argument '#{arg}' found"
      STDERR.puts
      STDERR.puts "  tip: to pass '#{arg}' as a value, use '-- #{arg}'"
      STDERR.puts
      STDERR.puts 'Usage: executable [OPTIONS] [ARGS]...'
      STDERR.puts
      STDERR.puts "For more information, try '--help'."
      exit 2
    end
    args << arg
  end
  i += 1
end

if opts[:code] && !args.empty?
  warn 'Error: Unexpected positional arguments after specifying --code'
  exit 1
end

if opts[:file] && !args.empty?
  warn 'Error: Unexpected positional arguments when --file is present'
  exit 1
end

if opts[:code] && opts[:file]
  warn 'Error: Cannot specify both --code and --file'
  exit 1
end

lang = normalize_language(opts[:lang])
file = opts[:file]
code = opts[:code]

if code.nil? && file.nil? && !args.empty?
  first = args.first
  if lang.nil? && AVAILABLE.include?(normalize_language(first))
    lang = normalize_language(first)
    code = args[1..]&.join(' ')
  elsif args.length == 1 && File.file?(first)
    file = first
  else
    code = args.join(' ')
  end
end

if lang && !AVAILABLE.include?(lang)
  warn "Error: Unknown language '#{opts[:lang]}'. Available languages: #{AVAILABLE.join(', ')}"
  exit 1
end

if file
  lang ||= opts[:detect] ? language_from_file(file) : 'python'
  run_file(lang, file)
elsif code
  lang ||= opts[:detect] ? detect_language(code) : 'python'
  run_code(lang, code)
else
  exit 0 unless STDIN.tty?
  exec_child('irb')
end
