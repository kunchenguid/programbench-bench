#!/usr/bin/env ruby
# frozen_string_literal: true

require 'etc'

DETAIL_VALUES = %w[dev ino nlink typ perm oct user uid group gid size blocks btime ctime mtime atime git none std all].freeze
SORT_VALUES = %w[dev ino nlink typ cat user uid group gid size blocks btime ctime mtime atime name cname ext inode_ nlinks_ typ_ cat_ user_ uid_ group_ gid_ size_ blocks_ btime_ ctime_ mtime_ atime_ name_ cname_ ext_ none].freeze
TYPE_VALUES = %w[dir symlink fifo socket block-device char-device file none all].freeze
BOOL_VALUES = %w[true false].freeze

SHORT_HELP = <<~HELP
  pls is a prettier and powerful ls(1) for the pros.

  Usage: executable [OPTIONS] [PATHS]...

  Arguments:
    [PATHS]...  the paths to list, each of which may be a file or directory [default: .]

  Options:
    -h, --help     Print help (see more with '--help')
    -V, --version  Print version

  Detail view:
    -d, --det <DETAILS>    the data points to show about each node [default: none] [possible values:
                           dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
                           btime, ctime, mtime, atime, git, none, std, all]
    -H, --header <HEADER>  show headers above columnar data [default: true] [possible values: true,
                           false]
    -u, --unit <UNIT>      the type of units to use for the node sizes [default: binary] [possible
                           values: binary, decimal, none]

  Grid view:
    -g, --grid <GRID>  display node names in multiple columns [default: false] [possible values: true,
                       false]
    -D, --down <DOWN>  display node names column-first [default: false] [possible values: true, false]

  Presentation:
    -i, --icon <ICON>          display icons next to node names [default: true] [possible values:
                               true, false]
    -S, --suffix <SUFFIX>      display node type suffixes after the node name [default: true]
                               [possible values: true, false]
    -l, --sym <SYM>            show symlink targets [default: true] [possible values: true, false]
    -c, --collapse <COLLAPSE>  show dependent nodes as children of their principal nodes [default:
                               true] [possible values: true, false]
    -a, --align <ALIGN>        align items accounting for leading dots [default: true] [possible
                               values: true, false]

  Filtering:
    -t, --typ <TYPES>        the set of node types to include in the output [default: all] [possible
                             values: dir, symlink, fifo, socket, block-device, char-device, file,
                             none, all]
    -I, --imp <IMP>          the importance cutoff to dim or hide unimportant files [default: 0]
    -e, --exclude <EXCLUDE>  the pattern of files to selectively hide from the output
    -o, --only <ONLY>        the pattern of files to exclusively show in the output

  Sorting:
    -s, --sort <SORT_BASES>  the set of fields to sort by, trailing `_` reverses the direction
                             [default: cat cname] [possible values: dev, ino, nlink, typ, cat, user,
                             uid, group, gid, size, blocks, btime, ctime, mtime, atime, name, cname,
                             ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_, gid_, size_,
                             blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]
HELP

LONG_HELP = <<~HELP
  pls is a prettier and powerful ls(1) for the pros.

  Read docs: https://pls.cli.rs/
  Get source: https://github.com/pls-rs/pls/
  Sponsor: https://github.com/sponsors/dhruvkb/

  Usage: executable [OPTIONS] [PATHS]...

  Arguments:
    [PATHS]...
            the paths to list, each of which may be a file or directory
            
            [default: .]

  Options:
    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version

  Detail view:
    -d, --det <DETAILS>
            the data points to show about each node
            
            [default: none]
            [possible values: dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
            btime, ctime, mtime, atime, git, none, std, all]

    -H, --header <HEADER>
            show headers above columnar data
            
            [default: true]
            [possible values: true, false]

    -u, --unit <UNIT>
            the type of units to use for the node sizes
            
            [default: binary]
            [possible values: binary, decimal, none]

  Grid view:
    -g, --grid <GRID>
            display node names in multiple columns
            
            [default: false]
            [possible values: true, false]

    -D, --down <DOWN>
            display node names column-first
            
            [default: false]
            [possible values: true, false]

  Presentation:
    -i, --icon <ICON>
            display icons next to node names
            
            [default: true]
            [possible values: true, false]

    -S, --suffix <SUFFIX>
            display node type suffixes after the node name
            
            [default: true]
            [possible values: true, false]

    -l, --sym <SYM>
            show symlink targets
            
            [default: true]
            [possible values: true, false]

    -c, --collapse <COLLAPSE>
            show dependent nodes as children of their principal nodes
            
            [default: true]
            [possible values: true, false]

    -a, --align <ALIGN>
            align items accounting for leading dots
            
            [default: true]
            [possible values: true, false]

  Filtering:
    -t, --typ <TYPES>
            the set of node types to include in the output
            
            [default: all]
            [possible values: dir, symlink, fifo, socket, block-device, char-device, file, none, all]

    -I, --imp <IMP>
            the importance cutoff to dim or hide unimportant files
            
            [default: 0]

    -e, --exclude <EXCLUDE>
            the pattern of files to selectively hide from the output

    -o, --only <ONLY>
            the pattern of files to exclusively show in the output

  Sorting:
    -s, --sort <SORT_BASES>
            the set of fields to sort by, trailing `_` reverses the direction
            
            [default: cat cname]
            [possible values: dev, ino, nlink, typ, cat, user, uid, group, gid, size, blocks, btime,
            ctime, mtime, atime, name, cname, ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_,
            gid_, size_, blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]
HELP

class Options
  attr_accessor :details, :header, :unit, :icon, :suffix, :sym, :align, :types,
                :imp, :exclude, :only, :sorts, :paths

  def initialize
    @details = []
    @header = true
    @unit = 'binary'
    @icon = true
    @suffix = true
    @sym = true
    @align = true
    @types = []
    @imp = 0
    @exclude = nil
    @only = nil
    @sorts = %w[cat cname]
    @paths = []
  end
end

def die_invalid(flag, value, values)
  warn "error: invalid value '#{value}' for '#{flag}'"
  warn "  [possible values: #{values.join(', ')}]"
  warn
  warn "For more information, try '--help'."
  exit 2
end

def take_value(args, i, flag)
  if i + 1 >= args.length
    warn "error: a value is required for '#{flag} <#{flag_name(flag)}>' but none was supplied"
    exit 2
  end
  args[i + 1]
end

def flag_name(flag)
  flag.sub(/^--?/, '').upcase
end

def parse_bool(flag, value)
  die_invalid("#{flag} <#{flag_name(flag)}>", value, BOOL_VALUES) unless BOOL_VALUES.include?(value)
  value == 'true'
end

def parse_args(argv)
  opt = Options.new
  i = 0
  positional = false
  while i < argv.length
    arg = argv[i]
    if !positional && arg.start_with?('--') && arg.include?('=')
      key, value = arg.split('=', 2)
      argv[i, 1] = [key, value]
      arg = argv[i]
    end
    if positional
      opt.paths << arg
      i += 1
      next
    end
    case arg
    when '--'
      positional = true
      i += 1
    when '-h'
      print SHORT_HELP
      exit 0
    when '--help'
      print LONG_HELP
      exit 0
    when '-V', '--version'
      puts 'pls 0.0.1-beta.9'
      exit 0
    when '-d', '--det'
      v = take_value(argv, i, '--det')
      die_invalid('--det <DETAILS>', v, DETAIL_VALUES) unless DETAIL_VALUES.include?(v)
      opt.details << v
      i += 2
    when '-H', '--header'
      opt.header = parse_bool('--header', take_value(argv, i, '--header'))
      i += 2
    when '-u', '--unit'
      v = take_value(argv, i, '--unit')
      die_invalid('--unit <UNIT>', v, %w[binary decimal none]) unless %w[binary decimal none].include?(v)
      opt.unit = v
      i += 2
    when '-g', '--grid'
      parse_bool('--grid', take_value(argv, i, '--grid'))
      i += 2
    when '-D', '--down'
      parse_bool('--down', take_value(argv, i, '--down'))
      i += 2
    when '-i', '--icon'
      opt.icon = parse_bool('--icon', take_value(argv, i, '--icon'))
      i += 2
    when '-S', '--suffix'
      opt.suffix = parse_bool('--suffix', take_value(argv, i, '--suffix'))
      i += 2
    when '-l', '--sym'
      opt.sym = parse_bool('--sym', take_value(argv, i, '--sym'))
      i += 2
    when '-c', '--collapse'
      parse_bool('--collapse', take_value(argv, i, '--collapse'))
      i += 2
    when '-a', '--align'
      opt.align = parse_bool('--align', take_value(argv, i, '--align'))
      i += 2
    when '-t', '--typ'
      v = take_value(argv, i, '--typ')
      die_invalid('--typ <TYPES>', v, TYPE_VALUES) unless TYPE_VALUES.include?(v)
      opt.types << v
      i += 2
    when '-I', '--imp'
      opt.imp = take_value(argv, i, '--imp').to_i
      i += 2
    when '-e', '--exclude'
      opt.exclude = take_value(argv, i, '--exclude')
      i += 2
    when '-o', '--only'
      opt.only = take_value(argv, i, '--only')
      i += 2
    when '-s', '--sort'
      v = take_value(argv, i, '--sort')
      die_invalid('--sort <SORT_BASES>', v, SORT_VALUES) unless SORT_VALUES.include?(v)
      opt.sorts = [] if opt.sorts == %w[cat cname]
      opt.sorts << v
      i += 2
    else
      if arg.start_with?('-')
        warn "error: unexpected argument '#{arg}' found"
        warn
        warn "  tip: to pass '#{arg}' as a value, use '-- #{arg}'"
        warn
        warn 'Usage: executable [OPTIONS] [PATHS]...'
        warn
        warn "For more information, try '--help'."
        exit 2
      end
      opt.paths << arg
      i += 1
    end
  end
  opt.paths = ['.'] if opt.paths.empty?
  opt.details = ['none'] if opt.details.empty? || opt.details.include?('none')
  opt.details = %w[nlink typ perm user group size mtime] if opt.details.include?('std')
  opt.details = %w[dev ino nlink typ perm oct user uid group gid size blocks btime ctime mtime atime git] if opt.details.include?('all')
  opt.types = ['all'] if opt.types.empty? || opt.types.include?('all')
  opt.types = ['none'] if opt.types.include?('none')
  opt
end

Node = Struct.new(:path, :display, :stat, :type, :target, keyword_init: true)

def type_of(st)
  return 'dir' if st.directory?
  return 'symlink' if st.symlink?
  return 'fifo' if st.pipe?
  return 'socket' if st.socket?
  return 'block-device' if st.blockdev?
  return 'char-device' if st.chardev?
  'file'
end

def read_nodes(path)
  st = File.lstat(path)
  if st.directory? && !st.symlink?
    Dir.children(path).map do |name|
      full = File.join(path, name)
      s = File.lstat(full)
      Node.new(path: full, display: name, stat: s, type: type_of(s), target: (File.readlink(full) if s.symlink?))
    end
  else
    [Node.new(path: path, display: path, stat: st, type: type_of(st), target: (File.readlink(path) if st.symlink?))]
  end
end

def important?(node, cutoff)
  return true if cutoff <= 0
  return false if cutoff >= 2
  !File.basename(node.display).start_with?('.')
end

def filtered(nodes, opt)
  nodes.select do |n|
    keep = opt.types.include?('all') || opt.types.include?(n.type)
    keep &&= important?(n, opt.imp)
    keep &&= !(Regexp.new(opt.exclude) =~ File.basename(n.display)) if opt.exclude
    keep &&= !!(Regexp.new(opt.only) =~ File.basename(n.display)) if opt.only
    keep
  end
rescue RegexpError
  []
end

def category(node)
  { 'dir' => 0, 'file' => 1, 'symlink' => 1, 'fifo' => 2, 'socket' => 3,
    'block-device' => 4, 'char-device' => 5 }[node.type] || 1
end

def comparable(node, base)
  case base.sub(/_$/, '')
  when 'dev' then node.stat.dev
  when 'ino', 'inode' then node.stat.ino
  when 'nlink', 'nlinks' then node.stat.nlink
  when 'typ' then node.type
  when 'cat' then category(node)
  when 'user' then user_name(node.stat.uid)
  when 'uid' then node.stat.uid
  when 'group' then group_name(node.stat.gid)
  when 'gid' then node.stat.gid
  when 'size' then node.stat.size
  when 'blocks' then node.stat.blocks rescue 0
  when 'btime', 'ctime' then node.stat.ctime.to_f
  when 'mtime' then node.stat.mtime.to_f
  when 'atime' then node.stat.atime.to_f
  when 'name' then node.display
  when 'cname' then node.display.sub(/\A\.+/, '')
  when 'ext' then File.extname(node.display)
  else node.display
  end
end

def sort_nodes(nodes, opt)
  sorts = opt.sorts.reject { |s| s == 'none' }
  nodes.sort do |a, b|
    result = 0
    sorts.each do |s|
      av = comparable(a, s)
      bv = comparable(b, s)
      result = av <=> bv
      result = -result if s.end_with?('_')
      break unless result.zero?
    end
    result
  end
end

def user_name(uid)
  Etc.getpwuid(uid).name
rescue ArgumentError
  uid.to_s
end

def group_name(gid)
  Etc.getgrgid(gid).name
rescue ArgumentError
  gid.to_s
end

def perms(mode)
  bits = [[0400, 'r'], [0200, 'w'], [0100, 'x'], [0040, 'r'], [0020, 'w'], [0010, 'x'], [0004, 'r'], [0002, 'w'], [0001, 'x']]
  s = bits.map { |bit, ch| (mode & bit) != 0 ? ch : '-' }.join
  "#{s[0, 3]} #{s[3, 3]} #{s[6, 3]}"
end

def type_letter(type)
  { 'dir' => 'd', 'symlink' => 'l', 'fifo' => 'p', 'socket' => 's',
    'block-device' => 'b', 'char-device' => 'c', 'file' => 'f' }[type] || 'f'
end

def format_time(t)
  t.strftime('%Y-%b-%d %I:%M%P')
end

def size_value(node, unit)
  return '' if node.type == 'dir'
  size = node.stat.size
  return "#{size} B" if unit == 'none'
  base = unit == 'decimal' ? 1000.0 : 1024.0
  units = unit == 'decimal' ? %w[B KB MB GB TB PB] : %w[B KiB MiB GiB TiB PiB]
  n = size.to_f
  idx = 0
  while n >= base && idx < units.length - 1
    n /= base
    idx += 1
  end
  idx.zero? ? format('%.1f   B', n) : format('%.1f %s', n, units[idx])
end

def icon(node)
  case node.type
  when 'dir' then "\u{f07b}"
  when 'symlink' then "\u{f0139}"
  when 'fifo' then "\u{f07e5}"
  else ' '
  end
end

def suffix(node, opt)
  return '' unless opt.suffix
  { 'dir' => '/', 'symlink' => '@', 'fifo' => '|', 'socket' => '=', 'file' => '' }[node.type] || ''
end

def name_cell(node, opt)
  n = node.display + suffix(node, opt)
  if node.type == 'symlink' && opt.sym && node.target
    n += " \u{f0054} #{node.target}"
  end
  n
end

def field_value(field, node, opt)
  case field
  when 'dev' then node.stat.dev.to_s
  when 'ino' then node.stat.ino.to_s
  when 'nlink' then node.stat.nlink.to_s
  when 'typ' then type_letter(node.type)
  when 'perm' then perms(node.stat.mode)
  when 'oct' then format('%03o', node.stat.mode & 0777)
  when 'user' then user_name(node.stat.uid)
  when 'uid' then node.stat.uid.to_s
  when 'group' then group_name(node.stat.gid)
  when 'gid' then node.stat.gid.to_s
  when 'size' then size_value(node, opt.unit)
  when 'blocks' then (node.stat.blocks rescue 0).to_s
  when 'btime', 'ctime' then format_time(node.stat.ctime)
  when 'mtime' then format_time(node.stat.mtime)
  when 'atime' then format_time(node.stat.atime)
  when 'git' then ''
  else ''
  end
end

HEADERS = {
  'dev' => 'Device', 'ino' => 'inode', 'nlink' => 'Link#', 'typ' => 'T',
  'perm' => 'Permissions', 'oct' => 'SUGO', 'user' => 'User', 'uid' => 'UID',
  'group' => 'Group', 'gid' => 'GID', 'size' => 'Size', 'blocks' => 'Blocks',
  'btime' => 'Created', 'ctime' => 'Changed', 'mtime' => 'Modified',
  'atime' => 'Accessed', 'git' => 'Git'
}.freeze

def detail_rows(nodes, opt)
  fields = opt.details
  rows = nodes.map { |n| [n, fields.map { |f| field_value(f, n, opt) }] }
  widths = fields.each_with_index.map do |f, i|
    ([HEADERS[f].to_s.length] + rows.map { |_, vals| vals[i].length }).max
  end
  out = []
  if opt.header
    out << fields.each_with_index.map { |f, i| HEADERS[f].to_s.rjust(widths[i]) }.join(' ') + ' Name'
  end
  rows.each do |node, vals|
    left = vals.each_with_index.map { |v, i| v.rjust(widths[i]) }.join(' ')
    out << "#{left} #{plain_name(node, opt)}"
  end
  out
end

def plain_name(node, opt)
  prefix = if opt.icon
             "#{icon(node)}  "
           elsif opt.align && !File.basename(node.display).start_with?('.')
             ' '
           else
             ''
           end
  prefix + name_cell(node, opt)
end

def simple_rows(nodes, opt)
  nodes.map { |n| plain_name(n, opt) }
end

def print_listing(path, opt)
  nodes = sort_nodes(filtered(read_nodes(path), opt), opt)
  lines = opt.details == ['none'] ? simple_rows(nodes, opt) : detail_rows(nodes, opt)
  puts lines
rescue SystemCallError => e
  puts path
  msg = e.is_a?(Errno::ENOENT) ? 'No such file or directory (os error 2)' : e.message.sub(/ @ .*$/, '')
  puts "\terror: #{msg}"
end

opt = parse_args(ARGV)
multiple = opt.paths.length > 1
opt.paths.each_with_index do |path, idx|
  if multiple
    puts unless idx.zero?
    if File.exist?(path) && File.lstat(path).directory? && !File.lstat(path).symlink?
      puts "#{path}:"
    end
  end
  print_listing(path, opt)
end
