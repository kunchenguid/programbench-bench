#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require 'json'
require 'optparse'
require 'time'

BOLD = "\e[1m"
DIM = "\e[2m"
RESET = "\e[0m"
GRAY = "\e[38;2;150;150;150m"
ORANGE = "\e[1;38;2;255;135;22m"

DEFAULT_CONFIG = {
  'message_keys' => %w[short_message msg message],
  'time_keys' => ['timestamp', 'time', '@timestamp'],
  'level_keys' => ['level', 'severity', 'log.level', 'loglevel'],
  'dump_all_exclude' => [],
  'always_print_fields' => [],
  'level_map' => {}
}

def usage
  <<~TXT
    json log viewer

    Usage: executable [OPTIONS] [INPUT]

    Arguments:
      [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]

    Options:
      -a, --additional-value <additional-value>
              adds additional values
          --config-file <config-file>
              configuration file to load
      -m, --message-key <message-key>
              Adds an additional key to detect the message in the log entry. The first matching key will be assigned to `fblog_message`.
          --print-lua
              Prints lua init expressions. Used for fblog debugging.
      -t, --time-key <time-key>
              Adds an additional key to detect the time in the log entry. The first matching key will be assigned to `fblog_timestamp`.
      -l, --level-key <level-key>
              Adds an additional key to detect the level in the log entry. The first matching key will be assigned to `fblog_level`.
          --map-level <from=to>
              Rewrite the log level from one value to another.
      -d, --dump-all
              dumps all values
      -x, --excluded-value <excluded-value>
              Excludes values (--dump-all is enabled implicitly)
      -p, --with-prefix
              consider all text before opening curly brace as prefix
      -f, --filter <filter>
              lua expression to filter log entries. `message ~= nil and string.find(message, "text.*") ~= nil`
          --no-implicit-filter-return-statement
              if you pass a filter expression 'return' is automatically prepended. Pass this switch to disable the implicit return.
          --main-line-format <main-line-format>
              Formats the main fblog output. All log values can be used. fblog provides sanitized variables starting with `fblog_`.
          --additional-value-format <additional-value-format>
              Formats the additional value fblog output.
      -s, --substitute
              Enable substitution of placeholders in the log messages with their corresponding values from the context.
      -c, --context-key <context-key>
              Use this key as the source of substitutions for the message. Value can either be an array ({1}) or an object ({key}).
      -F, --placeholder-format <placeholder-format>
              The format that should be used for substituting values in the message, where the key is the literal word `key`. Example: [[key]] or ${key}.
      -h, --help
              Print help
      -V, --version
              Print version
  TXT
end

def parse_toml(path)
  cfg = Marshal.load(Marshal.dump(DEFAULT_CONFIG))
  return cfg unless path && File.file?(path)

  section = nil
  File.readlines(path, chomp: true).each do |line|
    line = line.strip
    next if line.empty?
    next if line.start_with?('#')
    if line =~ /^\[(.+)\]$/
      section = Regexp.last_match(1)
      cfg[section] ||= {}
      next
    end
    next unless line =~ /^([A-Za-z0-9_.-]+)\s*=\s*(.+)$/

    key = Regexp.last_match(1)
    val = Regexp.last_match(2).strip
    parsed =
      if val.start_with?('[')
        val.scan(/"([^"]*)"/).flatten
      elsif val.start_with?('"')
        val[/\A"(.*)"\z/, 1] || ''
      else
        val
      end
    if section
      cfg[section][key] = parsed
    else
      cfg[key] = parsed
    end
  end
  cfg
end

opts = {
  additional: [],
  excluded: [],
  with_prefix: false,
  dump_all: false,
  substitute: false,
  context_key: 'context',
  placeholder_format: '{key}',
  filters: [],
  map_level: {},
  config_file: nil
}

parser = OptionParser.new do |o|
  o.on('-a', '--additional-value V') { |v| opts[:additional] << v }
  o.on('--config-file V') { |v| opts[:config_file] = v }
  o.on('-m', '--message-key V') { |v| (opts[:message_keys] ||= []) << v }
  o.on('-t', '--time-key V') { |v| (opts[:time_keys] ||= []) << v }
  o.on('-l', '--level-key V') { |v| (opts[:level_keys] ||= []) << v }
  o.on('--map-level V') { |v| k, val = v.split('=', 2); opts[:map_level][k] = val if k && val }
  o.on('-d', '--dump-all') { opts[:dump_all] = true }
  o.on('-x', '--excluded-value V') { |v| opts[:excluded] << v; opts[:dump_all] = true }
  o.on('-p', '--with-prefix') { opts[:with_prefix] = true }
  o.on('-f', '--filter V') { |v| opts[:filters] << v }
  o.on('--no-implicit-filter-return-statement') { opts[:no_return] = true }
  o.on('--main-line-format V') { |v| opts[:main_line_format] = v }
  o.on('--additional-value-format V') { |v| opts[:additional_value_format] = v }
  o.on('-s', '--substitute') { opts[:substitute] = true }
  o.on('-c', '--context-key V') { |v| opts[:context_key] = v }
  o.on('-F', '--placeholder-format V') { |v| opts[:placeholder_format] = v }
  o.on('--print-lua') { opts[:print_lua] = true }
  o.on('-V', '--version') { puts 'fblog 4.17.0'; exit 0 }
  o.on('-h', '--help') { puts usage; exit 0 }
end

begin
  parser.parse!(ARGV)
rescue OptionParser::InvalidOption, OptionParser::MissingArgument => e
  warn "error: #{e.message}"
  exit 2
end

config_file = opts[:config_file]
unless config_file
  home = ENV['HOME'] || Dir.home rescue nil
  candidates = []
  candidates << File.join(Dir.pwd, 'fblog.toml')
  candidates << File.join(home, '.config', 'fblog', 'fblog.toml') if home
  candidates << File.join(home, '.config', 'fblog.toml') if home
  config_file = candidates.find { |p| File.file?(p) }
end

cfg = parse_toml(config_file)
cfg['message_keys'] = (opts[:message_keys] || []) + cfg['message_keys']
cfg['time_keys'] = (opts[:time_keys] || []) + cfg['time_keys']
cfg['level_keys'] = (opts[:level_keys] || []) + cfg['level_keys']
cfg['level_map'].merge!(opts[:map_level])
opts[:additional].concat(cfg['always_print_fields'] || [])
opts[:main_line_format] ||= cfg['main_line_format'] if cfg['main_line_format'] && !cfg['main_line_format'].match?(/[()#]/)
opts[:additional_value_format] ||= cfg['additional_value_format'] if cfg['additional_value_format'] && !cfg['additional_value_format'].match?(/[()#]/)

if opts[:print_lua]
  puts '-- fblog lua initialization'
  exit 0
end

def ansi(style, text)
  case style
  when :bold then "#{BOLD}#{text}#{RESET}"
  when :dim then "#{DIM}#{text}#{RESET}"
  when :gray_bold then "#{BOLD}#{GRAY}#{text}#{RESET}#{RESET}"
  when :green then "\e[1;32m#{text}#{RESET}"
  when :yellow then "\e[1;33m#{text}#{RESET}"
  when :red then "\e[1;31m#{text}#{RESET}"
  when :blue then "\e[1;34m#{text}#{RESET}"
  when :cyan then "\e[1;36m#{text}#{RESET}"
  when :magenta then "\e[1;35m#{text}#{RESET}"
  when :cyan_bold then "#{BOLD}\e[36m#{text}#{RESET}#{RESET}"
  else text.to_s
  end
end

def value_at(obj, path)
  cur = obj
  path.split(/\s*>\s*/).each do |part|
    part.scan(/([^\[\]]+)|\[(\d+)\]/).each do |name, idx|
      if name
        cur = cur.is_a?(Hash) ? cur[name] : nil
      else
        cur = cur.is_a?(Array) ? cur[idx.to_i] : nil
      end
      return nil if cur.nil?
    end
  end
  cur
end

def get_any(obj, keys)
  keys.each do |key|
    v = value_at(obj, key.include?(' > ') ? key : key)
    return v unless v.nil?
  end
  nil
end

def format_timestamp(v)
  return '???' if v.nil? || v.to_s.empty?
  s = v.to_s
  if s =~ /\A\d{13}\z/
    s = Time.at(s.to_i / 1000.0).utc.iso8601
  end
  s = s.sub(/\.\d+/, '').sub(/Z\z/, '')
  s.length < 19 ? s.rjust(19) : s[0, 19]
end

def level_style(level)
  raw = level.nil? || level.to_s.empty? ? 'UNKNOWN' : level.to_s
  fixed = raw.upcase[0, 5].rjust(5)
  style =
    case raw.downcase
    when 'info', 'information', 'notice' then :green
    when 'warn', 'warning' then raw.downcase == 'warn' ? :yellow : :magenta
    when 'error', 'err', 'fatal', 'crit', 'critical' then :red
    when 'debug', 'trace' then :blue
    else :magenta
    end
  ansi(style, fixed)
end

def scalar_display(v)
  case v
  when String then v
  when TrueClass then 'true'
  when FalseClass then 'false'
  when NilClass then 'null'
  else v.to_s
  end
end

def pretty_value(v)
  case v
  when String
    ansi(:yellow, v)
  when Numeric
    ansi(:cyan, v.to_s)
  when TrueClass
    ansi(:green, 'true')
  when FalseClass
    ansi(:red, 'false')
  when Array
    ansi(:dim, '[') + v.map { |x| pretty_value(x) }.join(ansi(:dim, ', ')) + ansi(:dim, ']')
  when Hash
    parts = v.keys.sort.map { |k| "\e[35m#{k}#{RESET}#{ansi(:dim, ': ')}#{pretty_value(v[k])}" }
    ansi(:dim, '{') + parts.join(ansi(:dim, ', ')) + ansi(:dim, '}')
  else
    v.to_s
  end
end

def substitution_value(v)
  case v
  when String then ansi(:yellow, v)
  when Numeric then "\e[1;36m#{v}#{RESET}"
  when TrueClass then ansi(:green, 'true')
  when FalseClass then ansi(:red, 'false')
  else pretty_value(v)
  end
end

def placeholder_regex(fmt)
  pattern = Regexp.escape(fmt)
  pattern = pattern.sub(Regexp.escape('key'), '(.+?)')
  Regexp.new(pattern)
end

def substitute_message(msg, ctx, fmt)
  return msg unless ctx
  re = placeholder_regex(fmt)
  msg.gsub(/#{re}/) do
    key = Regexp.last_match(1)
    val = ctx.is_a?(Array) ? ctx[key.to_i] : ctx[key]
    val.nil? ? "#{ansi(:dim, '{')}#{ansi(:red, key)}#{ansi(:dim, '}')}" : substitution_value(val)
  end
end

def flatten(obj, prefix = nil, out = {}, array_depth = nil, direct_array_scalar = false)
  case obj
  when Hash
    obj.keys.sort.each do |k|
      path = prefix ? "#{prefix} > #{k}" : k
      flatten(obj[k], path, out, nil, false)
    end
  when Array
    obj.each_with_index do |v, i|
      idx = array_depth.nil? ? i : i + 1
      path = "#{prefix}[#{idx}]"
      flatten(v, path, out, (array_depth || 0) + 1, true)
    end
  else
    out[prefix] = direct_array_scalar && obj.is_a?(String) ? JSON.generate(obj) : obj
  end
  out
end

def filter_pass?(obj, filters)
  filters.all? do |f|
    expr = f.strip.sub(/\Areturn\s+/, '')
    if expr =~ /\A(.+?)\s*==\s*"([^"]*)"\z/
      scalar_display(value_at(obj, Regexp.last_match(1).strip)) == Regexp.last_match(2)
    elsif expr =~ /\A(.+?)\s*~=\s*"([^"]*)"\z/
      scalar_display(value_at(obj, Regexp.last_match(1).strip)) != Regexp.last_match(2)
    elsif expr =~ /\A(.+?)\s*>\s*([0-9.]+)\z/
      value_at(obj, Regexp.last_match(1).strip).to_f > Regexp.last_match(2).to_f
    elsif expr =~ /\A(.+?)\s*<\s*([0-9.]+)\z/
      value_at(obj, Regexp.last_match(1).strip).to_f < Regexp.last_match(2).to_f
    elsif expr =~ /string\.find\(([^,]+),\s*"([^"]*)"\)/
      scalar_display(value_at(obj, Regexp.last_match(1).strip)).match?(Regexp.new(Regexp.last_match(2)))
    else
      true
    end
  end
end

def custom_format(fmt, vars)
  return nil unless fmt
  fmt.gsub(/\{\{\s*([^{}]+?)\s*\}\}/) do
    name = Regexp.last_match(1).split.last
    scalar_display(vars[name] || vars[name.sub(/^fblog_/, '')])
  end
end

input = ARGV.shift || '-'
io = input == '-' ? STDIN : File.open(input, 'r')

io.each_line(chomp: true) do |line|
  prefix = nil
  json_text = line
  if opts[:with_prefix] && (idx = line.index('{')) && idx.positive?
    prefix = line[0...idx].rstrip
    json_text = line[idx..]
  end

  begin
    obj = JSON.parse(json_text)
  rescue JSON::ParserError
    puts "#{ORANGE}??? >#{RESET} #{line}"
    next
  end

  unless obj.is_a?(Hash)
    puts "#{ORANGE}??? >#{RESET} #{line}"
    next
  end

  next unless filter_pass?(obj, opts[:filters])

  msg = get_any(obj, cfg['message_keys'])
  time = get_any(obj, cfg['time_keys'])
  level = get_any(obj, cfg['level_keys'])
  level = cfg['level_map'][level.to_s] || level
  msg = substitute_message(msg.to_s, value_at(obj, opts[:context_key]), opts[:placeholder_format]) if opts[:substitute]

  vars = obj.merge('fblog_timestamp' => format_timestamp(time), 'fblog_level' => level, 'fblog_message' => msg, 'fblog_prefix' => prefix)
  line_out = custom_format(opts[:main_line_format], vars)
  unless line_out
    line_out = "#{ansi(:bold, format_timestamp(time))} #{level_style(level)}:"
    line_out += " #{ansi(:cyan_bold, prefix)}" if prefix
    line_out += " #{msg}"
  end
  puts line_out

  fields = {}
  if opts[:dump_all]
    fields = flatten(obj)
    skip = opts[:excluded] + (cfg['dump_all_exclude'] || [])
    fields.reject! { |k, _| skip.include?(k) }
  end
  opts[:additional].each { |k| fields[k] = value_at(obj, k) }
  fields.each do |k, v|
    next if v.nil?
    formatted = custom_format(opts[:additional_value_format], 'key' => k, 'value' => scalar_display(v))
    if formatted
      puts formatted
    else
      label = k.rjust(25)
      puts "#{ansi(:gray_bold, label)}: #{scalar_display(v)}"
    end
  end
end
