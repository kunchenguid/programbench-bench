#!/usr/bin/env ruby
# frozen_string_literal: true

require 'cgi'

class ElfError < StandardError; end

class ElfFile
  attr_reader :path, :data, :bits, :endian, :header, :program_headers, :section_headers

  ET = {
    0 => 'No file type (NONE)',
    1 => 'Relocatable object file (REL)',
    2 => 'Executable file (EXEC)',
    3 => 'Shared object file (DYN)',
    4 => 'Core file (CORE)'
  }.freeze

  MACH = {
    0 => 'No machine',
    3 => 'x86',
    8 => 'MIPS',
    20 => 'PowerPC',
    21 => 'PowerPC64',
    40 => 'ARM',
    50 => 'IA-64',
    62 => 'x86-64',
    183 => 'AArch64',
    243 => 'RISC-V'
  }.freeze

  PH_TYPE = {
    0 => 'NULL', 1 => 'LOAD', 2 => 'DYNAMIC', 3 => 'INTERP', 4 => 'NOTE',
    5 => 'SHLIB', 6 => 'PHDR', 7 => 'TLS', 0x6474e550 => 'GNU_EH_FRAME (OS-specific)',
    0x6474e551 => 'GNU_STACK (OS-specific)', 0x6474e552 => 'GNU_RELRO (OS-specific)',
    0x6474e553 => 'GNU_PROPERTY (OS-specific)'
  }.freeze

  SH_TYPE = {
    0 => 'NULL', 1 => 'PROGBITS', 2 => 'SYMTAB', 3 => 'STRTAB', 4 => 'RELA',
    5 => 'HASH', 6 => 'DYNAMIC', 7 => 'NOTE', 8 => 'NOBITS', 9 => 'REL',
    10 => 'SHLIB', 11 => 'DYNSYM', 14 => 'INIT_ARRAY', 15 => 'FINI_ARRAY',
    16 => 'PREINIT_ARRAY', 17 => 'GROUP', 18 => 'SYMTAB_SHNDX',
    0x6ffffff6 => 'GNU_HASH (OS-specific)', 0x6fffffff => 'HIOS',
    0x6ffffffe => 'VER_NEED (OS-specific)', 0x6ffffffd => 'VER_DEF (OS-specific)'
  }.freeze

  ABI = {
    0 => 'SysV', 1 => 'HP-UX', 2 => 'NetBSD', 3 => 'Linux', 6 => 'Solaris',
    7 => 'AIX', 8 => 'IRIX', 9 => 'FreeBSD', 12 => 'OpenBSD'
  }.freeze

  def initialize(path, data)
    @path = path
    @data = data.b
    parse
  end

  def parse
    raise ElfError, "file is smaller than ELF header's e_ident" if @data.bytesize < 16
    raise ElfError, 'mismatched magic: not an ELF file' unless @data.byteslice(0, 4) == "\x7fELF".b

    cls = byte(4)
    enc = byte(5)
    @bits = cls == 1 ? 32 : cls == 2 ? 64 : (raise ElfError, "invalid ELF class: #{cls}")
    @endian = enc == 1 ? :little : enc == 2 ? :big : (raise ElfError, "invalid ELF data encoding: #{enc}")
    min_size = @bits == 64 ? 64 : 52
    raise ElfError, 'file is smaller than ELF header' if @data.bytesize < min_size

    @header = parse_header
    @program_headers = parse_program_headers
    @section_headers = parse_section_headers
    fix_extended_counts
    load_section_names
  end

  def byte(off)
    @data.getbyte(off) || 0
  end

  def read_int(off, size)
    raw = @data.byteslice(off, size)
    raise ElfError, 'unexpected end of file while reading ELF structures' if raw.nil? || raw.bytesize < size
    code = case [size, @endian]
           when [1, :little], [1, :big] then 'C'
           when [2, :little] then 'v'
           when [2, :big] then 'n'
           when [4, :little] then 'V'
           when [4, :big] then 'N'
           when [8, :little] then 'Q<'
           when [8, :big] then 'Q>'
           end
    raw.unpack1(code)
  end

  def parse_header
    if @bits == 64
      keys = %i[e_type e_machine e_version e_entry e_phoff e_shoff e_flags e_ehsize e_phentsize e_phnum e_shentsize e_shnum e_shstrndx]
      sizes = [2, 2, 4, 8, 8, 8, 4, 2, 2, 2, 2, 2, 2]
    else
      keys = %i[e_type e_machine e_version e_entry e_phoff e_shoff e_flags e_ehsize e_phentsize e_phnum e_shentsize e_shnum e_shstrndx]
      sizes = [2, 2, 4, 4, 4, 4, 4, 2, 2, 2, 2, 2, 2]
    end
    off = 16
    keys.zip(sizes).to_h { |k, s| v = read_int(off, s); off += s; [k, v] }
  end

  def parse_program_headers
    phnum = @header[:e_phnum]
    return [] if phnum.zero? || @header[:e_phoff].zero?

    (0...phnum).map do |i|
      off = @header[:e_phoff] + i * @header[:e_phentsize]
      if @bits == 64
        vals = %i[p_type p_flags p_offset p_vaddr p_paddr p_filesz p_memsz p_align].zip([4, 4, 8, 8, 8, 8, 8, 8])
      else
        vals = %i[p_type p_offset p_vaddr p_paddr p_filesz p_memsz p_flags p_align].zip([4, 4, 4, 4, 4, 4, 4, 4])
      end
      h = { index: i }
      vals.each { |k, s| h[k] = read_int(off, s); off += s }
      h
    end
  end

  def parse_section_headers
    shnum = @header[:e_shnum]
    return [] if shnum.zero? || @header[:e_shoff].zero?

    (0...shnum).map { |i| parse_section_header(i) }
  end

  def parse_section_header(i)
    off = @header[:e_shoff] + i * @header[:e_shentsize]
    if @bits == 64
      vals = %i[sh_name sh_type sh_flags sh_addr sh_offset sh_size sh_link sh_info sh_addralign sh_entsize].zip([4, 4, 8, 8, 8, 8, 4, 4, 8, 8])
    else
      vals = %i[sh_name sh_type sh_flags sh_addr sh_offset sh_size sh_link sh_info sh_addralign sh_entsize].zip([4, 4, 4, 4, 4, 4, 4, 4, 4, 4])
    end
    h = { index: i }
    vals.each { |k, s| h[k] = read_int(off, s); off += s }
    h
  end

  def fix_extended_counts
    first = @section_headers[0]
    return unless first

    if @header[:e_shnum].zero? && first[:sh_size].positive?
      @section_headers = (0...first[:sh_size]).map { |i| parse_section_header(i) }
    end
    @header[:e_phnum] = first[:sh_info] if @header[:e_phnum] == 0xffff
    @header[:e_shstrndx] = first[:sh_link] if @header[:e_shstrndx] == 0xffff
  end

  def load_section_names
    strtab = @section_headers[@header[:e_shstrndx]]
    @section_headers.each { |s| s[:name] = '' }
    return unless strtab

    blob = @data.byteslice(strtab[:sh_offset], strtab[:sh_size]) || ''.b
    @section_headers.each do |s|
      pos = s[:sh_name]
      next if pos >= blob.bytesize
      nul = blob.index("\0", pos) || blob.bytesize
      s[:name] = blob.byteslice(pos, nul - pos).to_s
    end
  end
end

class HtmlReport
  def initialize(elf)
    @elf = elf
  end

  def render
    title = h(File.basename(@elf.path))
    <<~HTML
      <!doctype html>
      <html>
        <head>
          <meta charset='utf-8'>
          <meta name='viewport' content='width=900, initial-scale=1'>
          <title>#{title}</title>
          <style>
            html { font-family: monospace; }
            #rightmenu { vertical-align: top; text-align: right; float: right; }
            #credits { color: #ddd; text-decoration: none; margin-bottom: 0.5em; display: block; }
            #credits:hover { color: #000; }
            .textbutton { color: #222; cursor: pointer; background: none; border: none; padding: 0; margin: 0; margin-bottom: 0.5em; }
            .textbutton::before { content: "["; } .textbutton::after { content: "]"; }
            .right_hidden { text-align: left; display: none; }
            .legend_rect { float: left; margin-right: 0.4em; width: 3em; height: 1.5em; border: 1px solid rgba(0,0,0,.2); }
            ul { list-style: none; padding: 0; } li { clear: left; height: 2em; display: flex; align-items: center; }
            .number { text-decoration: underline dotted #888; }
            #offsets { display: inline-block; text-align: right; white-space: pre; }
            #bytes { border: 1px solid; display: inline-block; word-break: break-word; width: 47ch; white-space: pre; }
            #ascii { border: 1px solid; display: inline-block; width: 16ch; white-space: pre; }
            #vmap, #sticky_table { display: inline-block; vertical-align: top; position: sticky; top: 8px; }
            .conceal { display: none; border: 1px solid #000; max-width: 600px; margin-bottom: 1em; }
            .ident { background-color: #e99; } .ehdr { background-color: #99e; }
            .phdr { background-color: #eb9; } .shdr { background-color: #9be; }
            .segment { background-color: #f99; } .section { background-color: #f9f; }
            .hover:hover, .ident:hover, .ehdr:hover, .phdr:hover, .shdr:hover, .segment:hover, .section:hover { background-color: #ee9; }
            .phdr_itable::before { content: "Program header"; } .shdr_itable::before { content: "Section header"; }
            .segment_itable::before { content: "Segment"; } .section_itable::before { content: "Section"; }
          </style>
        </head>
        <body>
          <div id='rightmenu'>
            <a id='credits' href='https://github.com/rbakbashev/elfcat'>generated with elfcat 0.1.10</a>
            <button class='textbutton' id='settings_toggle'>Settings</button>
            <button class='textbutton' id='help_toggle'>Help</button>
            <div class='right_hidden' id='settings'><label for='arrow_opacity_range'>Arrow opacity:</label><input type='range' id='arrow_opacity_range' min='0' max='100' value='100'></div>
            <div class='right_hidden' id='help'>
              <p>The leftmost column shows offsets within the file. The middle column is the file dump. It has ELF structs, sections and segments highlighted. Some fields that reference areas in the file are clickable and connected with arrows. The rightmost column shows printable ASCII characters corresponding to the file bytes.</p>
              <p>Legend</p>
              <ul><li><span class='legend_rect ident'></span>ELF Identification</li><li><span class='legend_rect ehdr'></span>ELF Header</li><li><span class='legend_rect phdr'></span>Program Header</li><li><span class='legend_rect shdr'></span>Section Header</li><li><span class='legend_rect segment'></span>Segment</li><li><span class='legend_rect section'></span>Section</li></ul>
            </div>
          </div>
          #{file_info}
          <div id='offsets'>#{offsets}</div>
          <div id='bytes'>#{hex_dump}</div>
          <div id='ascii'>#{ascii_dump}</div>
          #{info_tables}
          <script type='text/javascript'>
            const settings = document.getElementById('settings');
            const help = document.getElementById('help');
            function toggleVisibility(elem) { elem.style.display = (elem.style.display === "none" || elem.style.display === "") ? "block" : "none"; }
            document.getElementById('settings_toggle').onclick = function() { toggleVisibility(settings); help.style.display = "none"; }
            document.getElementById('help_toggle').onclick = function() { toggleVisibility(help); settings.style.display = "none"; }
            let fileLen = #{@elf.data.bytesize};
          </script>
        </body>
      </html>
    HTML
  end

  def h(s) = CGI.escapeHTML(s.to_s)

  def filesize(n)
    return "#{n} B" if n < 1024
    units = %w[KiB MiB GiB]
    v = n.to_f
    unit = 'B'
    units.each do |u|
      v /= 1024.0
      unit = u
      break if v < 1024.0
    end
    "#{format('%.1f', v)} #{unit} (#{n} B)"
  end

  def num_dec_hex(n)
    "<span class='number' title='0x#{n.to_i.to_s(16)}'>#{filesize(n)}</span>"
  end

  def hex_num(n)
    "<span class='number' title='#{n}'>0x#{n.to_i.to_s(16)}</span>"
  end

  def file_info
    e = @elf.header
    <<~HTML
      <table>
        <tr class='fileinfo_file_name'> <td>File name:</td> <td>#{h(@elf.path)}</td> </tr>
        <tr class='fileinfo_file_size'> <td>File size:</td> <td>#{filesize(@elf.data.bytesize)}</td> </tr>
        <tr class='fileinfo_class'> <td>Object class:</td> <td>#{@elf.bits}-bit</td> </tr>
        <tr class='fileinfo_data'> <td>Data encoding:</td> <td>#{@elf.endian == :little ? 'Little endian' : 'Big endian'}</td> </tr>
        <tr class='fileinfo_abi'> <td>ABI:</td> <td>#{ElfFile::ABI[@elf.data.getbyte(7)] || "Unknown: #{@elf.data.getbyte(7)}"}</td> </tr>
        <tr class='fileinfo_e_type'> <td>Type:</td> <td>#{ElfFile::ET[e[:e_type]] || "Unknown: #{e[:e_type]}"}</td> </tr>
        <tr class='fileinfo_e_machine'> <td>Architecture:</td> <td>#{ElfFile::MACH[e[:e_machine]] || "Unknown: #{e[:e_machine]}"}</td> </tr>
        <tr class='fileinfo_e_entry'> <td>Entrypoint:</td> <td>#{hex_num(e[:e_entry])}</td> </tr>
        <tr class='fileinfo_ph'> <td>Program headers:</td> <td><span title='0x#{e[:e_phnum].to_s(16)}' class='number fileinfo_e_phnum'>#{e[:e_phnum]}</span> * <span title='0x#{e[:e_phentsize].to_s(16)}' class='number fileinfo_e_phentsize'>#{e[:e_phentsize]}</span> @ <span title='0x#{e[:e_phoff].to_s(16)}' class='number fileinfo_e_phoff'>#{e[:e_phoff]}</span></td> </tr>
        <tr class='fileinfo_sh'> <td>Section headers:</td> <td><span title='0x#{@elf.section_headers.length.to_s(16)}' class='number fileinfo_e_shnum'>#{@elf.section_headers.length}</span> * <span title='0x#{e[:e_shentsize].to_s(16)}' class='number fileinfo_e_shentsize'>#{e[:e_shentsize]}</span> @ <span title='0x#{e[:e_shoff].to_s(16)}' class='number fileinfo_e_shoff'>#{e[:e_shoff]}</span></td> </tr>
      </table>
    HTML
  end

  def offsets
    (0...@elf.data.bytesize).step(16).map { |i| i.to_s(16) }.join("\n")
  end

  def hex_dump
    @elf.data.bytes.each_slice(16).map do |row|
      row.map { |b| b == 0x7f ? '7f' : format('%02x', b) }.join(' ')
    end.join("\n")
  end

  def ascii_dump
    @elf.data.bytes.each_slice(16).map do |row|
      h(row.map { |b| (32..126).cover?(b) ? b.chr : '.' }.join)
    end.join("\n")
  end

  def ph_type(v) = ElfFile::PH_TYPE[v] || "Unknown: #{v}"
  def sh_type(v) = ElfFile::SH_TYPE[v] || "Unknown: #{v}"

  def pflags(v)
    s = +''
    s << 'R' if (v & 4) != 0
    s << 'W' if (v & 2) != 0
    s << 'X' if (v & 1) != 0
    s.empty? ? '0' : s
  end

  def sflags(v)
    names = [[1, 'W'], [2, 'A'], [4, 'X'], [0x10, 'M'], [0x20, 'S'], [0x40, 'I'], [0x80, 'L'], [0x100, 'O'], [0x200, 'G'], [0x400, 'T'], [0x800, 'C']]
    out = names.select { |bit, _| (v & bit) != 0 }.map(&:last).join
    out.empty? ? '0' : out
  end

  def info_tables
    out = +"<table id='sticky_table' cellspacing='0'><tr><td id='desc'></td><td class='infotables'>\n"
    @elf.program_headers.each do |p|
      out << "  <table class='conceal itable' id='info_phdr#{p[:index]}'>\n"
      out << "  <th colspan='2' class='phdr_itable'></th>\n"
      out << row('Type:', ph_type(p[:p_type]))
      out << row('Flags:', pflags(p[:p_flags]))
      out << row('Offset in file:', hex_num(p[:p_offset]))
      out << row('Size in file:', num_dec_hex(p[:p_filesz]))
      out << row('Vaddr in memory:', hex_num(p[:p_vaddr]))
      out << row('Size in memory:', num_dec_hex(p[:p_memsz]))
      out << row('Alignment:', hex_num(p[:p_align]))
      out << "  </table>\n"
    end
    @elf.section_headers.each do |s|
      out << "  <table class='conceal itable' id='info_shdr#{s[:index]}'>\n"
      out << "  <th colspan='2' class='shdr_itable'></th>\n"
      out << row('Index:', s[:index])
      out << row('Name:', h(s[:name]))
      out << row('Type:', sh_type(s[:sh_type]))
      out << row('Flags:', sflags(s[:sh_flags]))
      out << row('Vaddr in memory:', hex_num(s[:sh_addr]))
      out << row('Offset in file:', hex_num(s[:sh_offset]))
      out << row('Size in file:', num_dec_hex(s[:sh_size]))
      out << row('Linked section:', s[:sh_link])
      out << row('Extra info:', hex_num(s[:sh_info]))
      out << row('Alignment:', hex_num(s[:sh_addralign]))
      out << row('Size of entries:', num_dec_hex(s[:sh_entsize]))
      out << "  </table>\n"
    end
    @elf.program_headers.each do |p|
      out << "  <table class='conceal itable' id='info_segment#{p[:index]}'>\n"
      out << "  <th colspan='2' class='segment_itable'></th>\n"
      out << row('Type:', ph_type(p[:p_type]))
      out << row('Size in file:', num_dec_hex(p[:p_filesz]))
      out << row('Size in memory:', num_dec_hex(p[:p_memsz]))
      out << interpreter_row(p)
      out << "  </table>\n"
    end
    @elf.section_headers.each do |s|
      out << "  <table class='conceal itable' id='info_section#{s[:index]}'>\n"
      out << "  <th colspan='2' class='section_itable'></th>\n"
      out << row('Type:', sh_type(s[:sh_type]))
      out << row('Size:', num_dec_hex(s[:sh_size]))
      out << string_table_rows(s)
      out << "  </table>\n"
    end
    out << "</td></tr></table>\n"
    out
  end

  def row(k, v)
    "    <tr> <td>#{k}</td> <td>#{v}</td> </tr>\n"
  end

  def interpreter_row(p)
    return '' unless p[:p_type] == 3
    raw = @elf.data.byteslice(p[:p_offset], p[:p_filesz]) || ''.b
    interp = raw.split("\0", 2).first.to_s
    "    <tr><td><br></td></tr>\n" + row('Interpreter:', h(interp))
  end

  def string_table_rows(s)
    return '' unless s[:sh_type] == 3 && s[:sh_size].positive?
    raw = @elf.data.byteslice(s[:sh_offset], s[:sh_size]) || ''.b
    strings = raw.split("\0").reject(&:empty?).first(200)
    return '' if strings.empty?
    body = strings.map { |x| "          #{h(x)}" }.join("<br>\n")
    "    <tr><td><br></td></tr>\n    <tr><td></td><td><div>\n#{body}\n    </div></td></tr>\n"
  end
end

def usage
  warn 'Usage: elfcat <filename>'
  warn 'Writes <filename>.html to CWD.'
end

if ARGV.length != 1 || ['--help', '-h'].include?(ARGV[0])
  usage
  exit(ARGV.length == 1 && ['--help', '-h'].include?(ARGV[0]) ? 0 : 1)
end

path = ARGV[0]
begin
  data = File.binread(path)
rescue Errno::ENOENT
  warn %(Failed to read file "#{path}": No such file or directory (os error 2))
  exit 1
rescue SystemCallError => e
  warn %(Failed to read file "#{path}": #{e.message})
  exit 1
end

begin
  elf = ElfFile.new(path, data)
  out = "#{File.basename(path)}.html"
  File.write(out, HtmlReport.new(elf).render)
rescue ElfError => e
  warn "Failed to parse ELF: #{e.message}"
  exit 1
end
