#!/usr/bin/env ruby
# frozen_string_literal: true

require 'base64'
require 'cgi'
require 'digest'
require 'fileutils'
require 'find'
require 'optparse'
require 'securerandom'
require 'socket'
require 'uri'
require 'zlib'

VERSION = '0.32.0'

HELP_LONG = <<~TEXT
  For when you really just want to serve some files over HTTP right now!

  Usage: executable [OPTIONS] [PATH]

  Arguments:
    [PATH]
            Which path to serve
            
            [env: MINISERVE_PATH=]

  Options:
    -v, --verbose
            Be verbose, includes emitting access logs
            
            [env: MINISERVE_VERBOSE=]

        --temp-directory <TEMP_UPLOAD_DIRECTORY>
            The path to where file uploads will be written to before being moved to their correct
            location. It's wise to make sure that this directory will be written to disk and not into
            memory.
            
            This value will only be used **IF** file uploading is enabled. If this option is not set,
            the operating system default temporary directory will be used.
            
            [env: MINISERVER_TEMP_UPLOAD_DIRECTORY=]

        --index <INDEX>
            The name of a directory index file to serve, like "index.html"
            
            [env: MINISERVE_INDEX=]

        --spa
            Activate SPA (Single Page Application) mode
            
            [env: MINISERVE_SPA=]

        --pretty-urls
            Activate Pretty URLs mode
            
            [env: MINISERVE_PRETTY_URLS=]

    -p, --port <PORT>
            Port to use
            
            [env: MINISERVE_PORT=]
            [default: 8080]

    -i, --interfaces <INTERFACES>
            Interface to listen on
            
            [env: MINISERVE_INTERFACE=]

    -a, --auth <AUTH>
            Set authentication
            
            [env: MINISERVE_AUTH=]

        --auth-file <AUTH_FILE>
            Read authentication values from a file
            
            [env: MINISERVE_AUTH_FILE=]

        --route-prefix <ROUTE_PREFIX>
            Use a specific route prefix
            
            [env: MINISERVE_ROUTE_PREFIX=]

        --random-route
            Generate a random 6-hexdigit route
            
            [env: MINISERVE_RANDOM_ROUTE=]

    -P, --no-symlinks
            Hide symlinks in listing and prevent them from being followed
            
            [env: MINISERVE_NO_SYMLINKS=]

    -H, --hidden
            Show hidden files
            
            [env: MINISERVE_HIDDEN=]

    -S, --default-sorting-method <DEFAULT_SORTING_METHOD>
            Default sorting method for file list

            Possible values:
            - name: Sort by name
            - size: Sort by size
            - date: Sort by last modification date (natural sort: follows alphanumerical order)
            
            [env: MINISERVE_DEFAULT_SORTING_METHOD=]
            [default: name]

    -O, --default-sorting-order <DEFAULT_SORTING_ORDER>
            Default sorting order for file list

            Possible values:
            - asc:  Ascending order
            - desc: Descending order
            
            [env: MINISERVE_DEFAULT_SORTING_ORDER=]
            [default: desc]

    -c, --color-scheme <COLOR_SCHEME>
            Default color scheme
            
            [env: MINISERVE_COLOR_SCHEME=]
            [default: squirrel]
            [possible values: squirrel, archlinux, zenburn, monokai]

    -d, --color-scheme-dark <COLOR_SCHEME_DARK>
            Default color scheme
            
            [env: MINISERVE_COLOR_SCHEME_DARK=]
            [default: archlinux]
            [possible values: squirrel, archlinux, zenburn, monokai]

    -q, --qrcode
            Enable QR code display
            
            [env: MINISERVE_QRCODE=]

    -u, --upload-files [<ALLOWED_UPLOAD_DIR>]
            Enable file uploading (and optionally specify for which directory)
            
            [env: MINISERVE_ALLOWED_UPLOAD_DIR=]

        --web-upload-files-concurrency <WEB_UPLOAD_CONCURRENCY>
            Configure amount of concurrent uploads when visiting the website.
            
            [env: MINISERVE_WEB_UPLOAD_CONCURRENCY=]
            [default: 0]

        --chmod <CHMOD>
            Set unix file permissions of uploaded files
            
            [env: MINISERVE_CHMOD=]

        --directory-size
            Enable recursive directory size calculation
            
            [env: MINISERVE_DIRECTORY_SIZE=]

    -U, --mkdir
            Enable creating directories
            
            [env: MINISERVE_MKDIR_ENABLED=]

    -m, --media-type <MEDIA_TYPE>
            Specify uploadable media types
            
            [env: MINISERVE_MEDIA_TYPE=]
            [possible values: image, audio, video]

    -M, --raw-media-type <MEDIA_TYPE_RAW>
            Directly specify the uploadable media type expression
            
            [env: MINISERVE_RAW_MEDIA_TYPE=]

    -o, --on-duplicate-files <ON_DUPLICATE_FILES>
            What to do if existing files with same name is present during file upload
            
            [env: MINISERVE_ON_DUPLICATE_FILES=]
            [default: error]
            [possible values: error, overwrite, rename]

    -R, --rm-files [<ALLOWED_RM_DIR>]
            Enable file and directory deletion (and optionally specify for which directory)
            
            [env: MINISERVE_ALLOWED_RM_DIR=]

    -r, --enable-tar
            Enable uncompressed tar archive generation
            
            [env: MINISERVE_ENABLE_TAR=]

    -g, --enable-tar-gz
            Enable gz-compressed tar archive generation
            
            [env: MINISERVE_ENABLE_TAR_GZ=]

    -z, --enable-zip
            Enable zip archive generation
            
            [env: MINISERVE_ENABLE_ZIP=]

    -C, --compress-response
            Compress response
            
            [env: MINISERVE_COMPRESS_RESPONSE=]

    -D, --dirs-first
            List directories first
            
            [env: MINISERVE_DIRS_FIRST=]

    -t, --title <TITLE>
            Shown instead of host in page title and heading
            
            [env: MINISERVE_TITLE=]

        --header <HEADER>
            Inserts custom headers into the responses. Specify each header as a 'Header:Value' pair.
            
            [env: MINISERVE_HEADER=]

    -l, --show-symlink-info
            Visualize symlinks in directory listing
            
            [env: MINISERVE_SHOW_SYMLINK_INFO=]

    -F, --hide-version-footer
            Hide version footer
            
            [env: MINISERVE_HIDE_VERSION_FOOTER=]

        --hide-theme-selector
            Hide theme selector
            
            [env: MINISERVE_HIDE_THEME_SELECTOR=]

    -W, --show-wget-footer
            If enabled, display a wget command to recursively download the current directory
            
            [env: MINISERVE_SHOW_WGET_FOOTER=]

        --print-completions <shell>
            Generate completion file for a shell
            
            [possible values: bash, elvish, fish, powershell, zsh]

        --print-manpage
            Generate man page

        --tls-cert <TLS_CERT>
            TLS certificate to use
            
            [env: MINISERVE_TLS_CERT=]

        --tls-key <TLS_KEY>
            TLS private key to use
            
            [env: MINISERVE_TLS_KEY=]

        --readme
            Enable README.md rendering in directories
            
            [env: MINISERVE_README=]

    -I, --disable-indexing
            Disable indexing
            
            [env: MINISERVE_DISABLE_INDEXING=]

        --enable-webdav
            Enable read-only WebDAV support (PROPFIND requests)
            
            [env: MINISERVE_ENABLE_WEBDAV=]

        --size-display <SIZE_DISPLAY>
            Show served file size in exact bytes
            
            [env: MINISERVE_SIZE_DISPLAY=]
            [default: human]
            [possible values: human, exact]

        --file-external-url <FILE_EXTERNAL_URL>
            Optional external URL (e.g., 'http://external.example.com:8081') prepended to file links
            in listings.
            
            [env: MINISERVE_FILE_EXTERNAL_URL=]

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
TEXT

HELP_SHORT = HELP_LONG.lines.reject { |l| l.start_with?('            ') && l.length > 12 }.join

MIME = {
  '.html' => 'text/html; charset=utf-8', '.htm' => 'text/html; charset=utf-8',
  '.txt' => 'text/plain; charset=utf-8', '.css' => 'text/css', '.js' => 'application/javascript',
  '.json' => 'application/json', '.svg' => 'image/svg+xml', '.png' => 'image/png',
  '.jpg' => 'image/jpeg', '.jpeg' => 'image/jpeg', '.gif' => 'image/gif', '.pdf' => 'application/pdf',
  '.wasm' => 'application/wasm', '.xml' => 'application/xml', '.zip' => 'application/zip',
  '.gz' => 'application/gzip', '.tar' => 'application/x-tar'
}.freeze

class MiniServe
  def initialize(argv)
    @opts = {
      port: (ENV['MINISERVE_PORT'] || 8080).to_i,
      interfaces: ENV['MINISERVE_INTERFACE'] || '0.0.0.0',
      path: ENV['MINISERVE_PATH'] || '.',
      hidden: truthy?(ENV['MINISERVE_HIDDEN']),
      no_symlinks: truthy?(ENV['MINISERVE_NO_SYMLINKS']),
      index: ENV['MINISERVE_INDEX'],
      spa: truthy?(ENV['MINISERVE_SPA']),
      pretty: truthy?(ENV['MINISERVE_PRETTY_URLS']),
      sort: ENV['MINISERVE_DEFAULT_SORTING_METHOD'] || 'name',
      order: ENV['MINISERVE_DEFAULT_SORTING_ORDER'] || 'desc',
      dirs_first: truthy?(ENV['MINISERVE_DIRS_FIRST']),
      title: ENV['MINISERVE_TITLE'],
      upload: env_path_flag('MINISERVE_ALLOWED_UPLOAD_DIR'),
      mkdir: truthy?(ENV['MINISERVE_MKDIR_ENABLED']),
      rm: env_path_flag('MINISERVE_ALLOWED_RM_DIR'),
      dup: ENV['MINISERVE_ON_DUPLICATE_FILES'] || 'error',
      chmod: ENV['MINISERVE_CHMOD'],
      tar: truthy?(ENV['MINISERVE_ENABLE_TAR']),
      targz: truthy?(ENV['MINISERVE_ENABLE_TAR_GZ']),
      zip: truthy?(ENV['MINISERVE_ENABLE_ZIP']),
      readme: truthy?(ENV['MINISERVE_README']),
      disable_index: truthy?(ENV['MINISERVE_DISABLE_INDEXING']),
      size_display: ENV['MINISERVE_SIZE_DISPLAY'] || 'human',
      file_external_url: ENV['MINISERVE_FILE_EXTERNAL_URL'],
      show_wget: truthy?(ENV['MINISERVE_SHOW_WGET_FOOTER']),
      hide_version: truthy?(ENV['MINISERVE_HIDE_VERSION_FOOTER']),
      route_prefix: ENV['MINISERVE_ROUTE_PREFIX'].to_s,
      auths: [],
      headers: []
    }
    parse!(argv)
    @root = File.expand_path(@opts[:path])
    @single_file = File.file?(@root)
    @route = normalize_route(@opts[:random_route] ? "/#{SecureRandom.hex(3)}" : @opts[:route_prefix])
  end

  def run
    abort "miniserve: path does not exist: #{@root}" unless File.exist?(@root)
    server = TCPServer.new(@opts[:interfaces] == '::' ? '::' : '0.0.0.0', @opts[:port])
    $stdout.sync = true
    puts "miniserve v#{VERSION}"
    puts "Bound to [::]:#{@opts[:port]}, 0.0.0.0:#{@opts[:port]}"
    puts "Serving path #{@root}"
    puts "Available at (non-exhaustive list):"
    puts "    http://127.0.0.1:#{@opts[:port]}#{@route}"
    loop do
      sock = server.accept
      Thread.new(sock) { |s| handle_client(s) }
    end
  rescue Interrupt
    exit 0
  end

  private

  def parse!(argv)
    parser = OptionParser.new
    parser.banner = ''
    parser.on('-h', '--help') { puts HELP_SHORT; exit 0 }
    parser.on('--help') { puts HELP_LONG; exit 0 }
    parser.on('-V', '--version') { puts "miniserve #{VERSION}"; exit 0 }
    parser.on('-v', '--verbose') { @opts[:verbose] = true }
    parser.on('--temp-directory DIR') { |v| @opts[:temp] = v }
    parser.on('--index NAME') { |v| @opts[:index] = v }
    parser.on('--spa') { @opts[:spa] = true }
    parser.on('--pretty-urls') { @opts[:pretty] = true }
    parser.on('-p', '--port PORT', Integer) { |v| @opts[:port] = v }
    parser.on('-i', '--interfaces IFACE') { |v| @opts[:interfaces] = v }
    parser.on('-a', '--auth AUTH') { |v| @opts[:auths] << v }
    parser.on('--auth-file FILE') { |v| File.readlines(v, chomp: true).each { |l| @opts[:auths] << l unless l.strip.empty? } }
    parser.on('--route-prefix PREFIX') { |v| @opts[:route_prefix] = v }
    parser.on('--random-route') { @opts[:random_route] = true }
    parser.on('-P', '--no-symlinks') { @opts[:no_symlinks] = true }
    parser.on('-H', '--hidden') { @opts[:hidden] = true }
    parser.on('-S', '--default-sorting-method METHOD') { |v| @opts[:sort] = v }
    parser.on('-O', '--default-sorting-order ORDER') { |v| @opts[:order] = v }
    parser.on('-c', '--color-scheme SCHEME') { |v| @opts[:color] = v }
    parser.on('-d', '--color-scheme-dark SCHEME') { |v| @opts[:color_dark] = v }
    parser.on('-q', '--qrcode') { @opts[:qrcode] = true }
    parser.on('-u', '--upload-files [DIR]') { |v| @opts[:upload] = v || '/' }
    parser.on('--web-upload-files-concurrency N') { |v| @opts[:upload_conc] = v }
    parser.on('--chmod MODE') { |v| @opts[:chmod] = v }
    parser.on('--directory-size') { @opts[:directory_size] = true }
    parser.on('-U', '--mkdir') { @opts[:mkdir] = true }
    parser.on('-m', '--media-type TYPE') { |v| @opts[:media] = v }
    parser.on('-M', '--raw-media-type TYPE') { |v| @opts[:raw_media] = v }
    parser.on('-o', '--on-duplicate-files MODE') { |v| @opts[:dup] = v }
    parser.on('-R', '--rm-files [DIR]') { |v| @opts[:rm] = v || '/' }
    parser.on('-r', '--enable-tar') { @opts[:tar] = true }
    parser.on('-g', '--enable-tar-gz') { @opts[:targz] = true }
    parser.on('-z', '--enable-zip') { @opts[:zip] = true }
    parser.on('-C', '--compress-response') { @opts[:compress] = true }
    parser.on('-D', '--dirs-first') { @opts[:dirs_first] = true }
    parser.on('-t', '--title TITLE') { |v| @opts[:title] = v }
    parser.on('--header HEADER') { |v| @opts[:headers] << v }
    parser.on('-l', '--show-symlink-info') { @opts[:show_symlink] = true }
    parser.on('-F', '--hide-version-footer') { @opts[:hide_version] = true }
    parser.on('--hide-theme-selector') { @opts[:hide_theme] = true }
    parser.on('-W', '--show-wget-footer') { @opts[:show_wget] = true }
    parser.on('--print-completions SHELL') { |_v| puts "# completion file for executable"; exit 0 }
    parser.on('--print-manpage') { puts manpage; exit 0 }
    parser.on('--tls-cert CERT') { |v| @opts[:tls_cert] = v }
    parser.on('--tls-key KEY') { |v| @opts[:tls_key] = v }
    parser.on('--readme') { @opts[:readme] = true }
    parser.on('-I', '--disable-indexing') { @opts[:disable_index] = true }
    parser.on('--enable-webdav') { @opts[:webdav] = true }
    parser.on('--size-display MODE') { |v| @opts[:size_display] = v }
    parser.on('--file-external-url URL') { |v| @opts[:file_external_url] = v }
    parser.parse!(argv)
    @opts[:path] = argv.shift if argv[0]
  rescue OptionParser::ParseError => e
    warn "error: #{e.message}"
    exit 2
  end

  def handle_client(sock)
    reqline = sock.gets("\r\n")
    return sock.close unless reqline
    method, target, _version = reqline.split(/\s+/, 3)
    headers = {}
    while (line = sock.gets("\r\n"))
      break if line == "\r\n"
      k, v = line.split(':', 2)
      headers[k.downcase] = v.strip if k && v
    end
    len = headers['content-length'].to_i
    body = len.positive? ? sock.read(len) : ''
    uri = URI.parse(target) rescue URI.parse(CGI.escape(target))
    path = CGI.unescape(uri.path)
    query = CGI.parse(uri.query.to_s)
    status, resp_headers, resp_body = route(method, path, query, headers, body)
    resp_body = '' if method == 'HEAD'
    write_response(sock, status, resp_headers, resp_body)
    log(method, path, status) if @opts[:verbose]
  rescue StandardError => e
    write_response(sock, 500, { 'content-type' => 'text/plain; charset=utf-8' }, "#{e.class}: #{e.message}\n") rescue nil
  ensure
    sock.close rescue nil
  end

  def route(method, path, query, headers, body)
    return [405, { 'content-type' => 'text/plain; charset=utf-8' }, 'Method Not Allowed'] unless %w[GET HEAD POST PUT DELETE PROPFIND].include?(method)
    return [200, { 'content-type' => 'text/css' }, default_css] if path == "#{@route}/__miniserve_internal/style.css" || path == '/__miniserve_internal/style.css'
    return [200, { 'content-type' => 'image/svg+xml' }, default_svg] if path.include?('/__miniserve_internal/favicon.svg')
    return unauthorized unless authorized?(headers)
    return webdav(path) if method == 'PROPFIND' && @opts[:webdav]

    unless @route.empty? || path == @route || path.start_with?("#{@route}/")
      return redirect("#{@route}/") if path == '/'
      return not_found(path)
    end
    rel_url = @route.empty? ? path : path[@route.length..] || '/'
    return upload(rel_url, query, body, headers) if method == 'POST' && path.end_with?('/upload') && @opts[:upload]
    return mkdir(rel_url, query) if method == 'POST' && query.key?('mkdir') && @opts[:mkdir]
    return remove(rel_url, query) if method == 'POST' && (query.key?('rm') || path.end_with?('/rm')) && @opts[:rm]
    return not_found(path) unless %w[GET HEAD].include?(method)

    serve_get(rel_url, query, headers)
  end

  def serve_get(rel_url, query, headers)
    if @single_file
      return serve_file(@root, File.basename(@root), headers) if rel_url == '/' || rel_url == "/#{File.basename(@root)}"
      return not_found(rel_url)
    end
    fs = fs_path(rel_url)
    return forbidden if fs.nil?
    if !File.exist?(fs) && @opts[:pretty] && File.exist?("#{fs}.html")
      fs = "#{fs}.html"
    end
    if !File.exist?(fs) && @opts[:spa] && @opts[:index]
      idx = File.join(@root, @opts[:index])
      return serve_file(idx, @opts[:index], headers) if File.file?(idx)
    end
    return not_found(rel_url) unless File.exist?(fs)
    return bad_request if hidden_path?(fs) && !@opts[:hidden]
    return not_found(rel_url) if @opts[:no_symlinks] && symlink_in_path?(fs)
    if File.directory?(fs)
      return redirect(with_slash(rel_url)) unless rel_url.end_with?('/')
      if query['download']&.first
        return archive_download(fs, query['download'].first)
      end
      if @opts[:index]
        idx = File.join(fs, @opts[:index])
        return serve_file(idx, @opts[:index], headers) if File.file?(idx)
      end
      return [404, { 'content-type' => 'text/html' }, error_page('404 Not Found', 'Directory listing is disabled')] if @opts[:disable_index]
      return list_dir(fs, rel_url, query)
    end
    serve_file(fs, File.basename(fs), headers)
  end

  def fs_path(rel_url)
    rel = rel_url.sub(%r{\A/+}, '')
    base = File.expand_path(File.join(@root, rel))
    return nil unless base == @root || base.start_with?(@root + File::SEPARATOR)
    base
  end

  def serve_file(path, name, headers)
    st = File.stat(path)
    mime = MIME[File.extname(path).downcase] || 'application/octet-stream'
    disposition = inline_type?(mime) ? 'inline' : 'attachment'
    data = File.binread(path)
    status = 200
    if headers['range']&.match(/bytes=(\d*)-(\d*)/)
      a = Regexp.last_match(1)
      b = Regexp.last_match(2)
      from = a.empty? ? [data.bytesize - b.to_i, 0].max : a.to_i
      to = b.empty? ? data.bytesize - 1 : [b.to_i, data.bytesize - 1].min
      data = data.byteslice(from..to) || ''
      status = 206
      extra = { 'content-range' => "bytes #{from}-#{to}/#{st.size}" }
    else
      extra = {}
    end
    [status, {
      'content-type' => mime,
      'content-disposition' => %(#{disposition}; filename="#{name.gsub('"', '\\"')}"),
      'accept-ranges' => 'bytes',
      'last-modified' => httpdate(st.mtime),
      'etag' => %("#{st.ino.to_s(16)}:#{st.size.to_s(16)}:#{st.mtime.to_i.to_s(16)}")
    }.merge(extra), data]
  end

  def list_dir(dir, rel_url, query)
    entries = Dir.children(dir).filter_map do |name|
      next if !@opts[:hidden] && name.start_with?('.')
      full = File.join(dir, name)
      next if @opts[:no_symlinks] && File.symlink?(full)
      stat = File.lstat(full)
      { name: name, full: full, dir: File.directory?(full), size: File.directory?(full) ? nil : stat.size, mtime: stat.mtime, symlink: File.symlink?(full) }
    end
    sort = query['sort']&.first || @opts[:sort]
    order = query['order']&.first || @opts[:order]
    entries.sort_by! do |e|
      key = case sort
            when 'size' then e[:size] || 0
            when 'date' then e[:mtime]
            else natural_key(e[:name])
            end
      [(@opts[:dirs_first] && e[:dir]) ? 0 : 1, key]
    end
    entries.reverse! if order == 'desc'
    title = h(@opts[:title] || current_title(rel_url))
    rows = entries.map { |e| row_for(e, rel_url) }.join
    readme = ''
    if @opts[:readme] && File.file?(File.join(dir, 'README.md'))
      readme = "<section class=\"readme\"><pre>#{h(File.read(File.join(dir, 'README.md')))}</pre></section>"
    end
    toolbar = []
    downloads = []
    downloads << %(<a href="?download=tar_gz">Download .tar.gz</a>) if @opts[:targz]
    downloads << %(<a href="?download=tar">Download .tar</a>) if @opts[:tar]
    downloads << %(<a href="?download=zip">Download .zip</a>) if @opts[:zip]
    toolbar << '<form method="post" action="upload" enctype="multipart/form-data"><input type="file" name="path"><button>Upload</button></form>' if @opts[:upload]
    toolbar << '<form method="post"><input name="name"><button name="mkdir" value="1">Create directory</button></form>' if @opts[:mkdir]
    footer = @opts[:hide_version] ? '' : "<div class=\"footer\">miniserve v#{VERSION}</div>"
    body = <<~HTML
      <!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="#{@route}/__miniserve_internal/style.css"><title>#{title}</title></head><body><div class="container">
      <h1 class="title">#{title}</h1>
      <div class="toolbar"><div class="download">#{downloads.join}</div>#{toolbar.join}</div>
      <table><thead><tr><th><a href="?sort=name&order=asc">Name</a></th><th class="size"><a href="?sort=size&order=asc">Size</a></th><th class="date"><a href="?sort=date&order=asc">Last modified</a></th></tr></thead><tbody>
      #{parent_row(rel_url)}#{rows}
      </tbody></table>
      #{readme}
      #{wget_footer(rel_url)}
      #{footer}
      </div></body></html>
    HTML
    [200, { 'content-type' => 'text/html; charset=utf-8' }, body]
  end

  def row_for(e, rel_url)
    href = join_url(rel_url, e[:name]) + (e[:dir] ? '/' : '')
    label = h(e[:name]) + (e[:dir] ? '/' : '')
    href = @opts[:file_external_url].to_s + href unless e[:dir] || @opts[:file_external_url].to_s.empty?
    cls = e[:dir] ? 'directory' : 'file'
    cls = 'symlink' if e[:symlink] && @opts[:show_symlink]
    rm = @opts[:rm] ? %(<form method="post" style="display:inline"><button name="rm" value="#{h(e[:name])}">Delete</button></form>) : ''
    %(<tr class="entry-type-#{e[:dir] ? 'directory' : 'file'}"><td><p><a class="#{cls}" href="#{h(href)}">#{label}</a>#{rm}</p></td><td class="size-cell">#{h(size(e[:size]))}</td><td class="date-cell">#{h(e[:mtime].strftime('%Y-%m-%d %H:%M:%S'))}</td></tr>)
  end

  def parent_row(rel_url)
    return '' if rel_url == '/'
    %(<tr><td><a class="root" href="../">../</a></td><td></td><td></td></tr>)
  end

  def upload(rel_url, query, body, headers)
    dest_dir = fs_path(query['path']&.first || rel_url.sub(%r{/upload\z}, '/'))
    return forbidden unless dest_dir && File.directory?(dest_dir)
    filename = 'upload'
    data = body
    if headers['content-type'].to_s =~ /multipart\/form-data;\s*boundary=(.+)/
      parts = parse_multipart(body, Regexp.last_match(1))
      part = parts.find { |p| p[:filename] } || parts.first
      filename = File.basename(part[:filename] || filename)
      data = part[:data]
    end
    out = resolve_duplicate(File.join(dest_dir, filename))
    return [409, { 'content-type' => 'text/plain; charset=utf-8' }, 'File already exists'] unless out
    File.binwrite(out, data)
    File.chmod(@opts[:chmod].to_i(8), out) if @opts[:chmod]
    redirect(query['path']&.first || '/')
  end

  def mkdir(rel_url, query)
    base = fs_path(rel_url)
    name = File.basename(query['name']&.first.to_s)
    return forbidden if name.empty? || !base
    FileUtils.mkdir_p(File.join(base, name))
    redirect(rel_url)
  end

  def remove(rel_url, query)
    target = query['rm']&.first || query['path']&.first
    full = target ? fs_path(join_url(rel_url, target)) : fs_path(rel_url)
    return forbidden unless full && full != @root
    FileUtils.rm_rf(full)
    redirect(File.dirname(rel_url) == '.' ? '/' : File.dirname(rel_url))
  end

  def webdav(path)
    body = %(<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:"><D:response><D:href>#{h(path)}</D:href><D:propstat><D:prop><D:resourcetype/></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response></D:multistatus>)
    [207, { 'content-type' => 'application/xml; charset=utf-8' }, body]
  end

  def archive_download(dir, kind)
    case kind
    when 'tar'
      return not_found('?download=tar') unless @opts[:tar]
      data = make_tar(dir)
      [200, { 'content-type' => 'application/x-tar', 'content-disposition' => %(attachment; filename="#{File.basename(dir)}.tar") }, data]
    when 'tar_gz'
      return not_found('?download=tar_gz') unless @opts[:targz]
      data = Zlib.gzip(make_tar(dir))
      [200, { 'content-type' => 'application/gzip', 'content-disposition' => %(attachment; filename="#{File.basename(dir)}.tar.gz") }, data]
    when 'zip'
      return not_found('?download=zip') unless @opts[:zip]
      data = make_zip(dir)
      [200, { 'content-type' => 'application/zip', 'content-disposition' => %(attachment; filename="#{File.basename(dir)}.zip") }, data]
    else
      not_found("?download=#{kind}")
    end
  end

  def make_tar(dir)
    cmd = ['tar', '-C', dir, '-cf', '-', '.']
    IO.popen(cmd, 'rb', &:read)
  end

  def make_zip(dir)
    files = []
    Find.find(dir) do |p|
      next if p == dir
      rel = p.sub(%r{\A#{Regexp.escape(dir)}/?}, '')
      next if rel.empty?
      next if !@opts[:hidden] && File.basename(rel).start_with?('.')
      files << [p, rel]
    end
    out = +''
    central = +''
    files.each do |path, rel|
      is_dir = File.directory?(path)
      name = rel + (is_dir && !rel.end_with?('/') ? '/' : '')
      data = is_dir ? '' : File.binread(path)
      crc = Zlib.crc32(data)
      time, date = dos_time(File.mtime(path))
      local_offset = out.bytesize
      out << [0x04034b50, 20, 0, 0, time, date, crc, data.bytesize, data.bytesize, name.bytesize, 0].pack('VvvvvvVVVvv')
      out << name << data
      central << [0x02014b50, 20, 20, 0, 0, time, date, crc, data.bytesize, data.bytesize, name.bytesize, 0, 0, 0, 0, is_dir ? 0x10 : 0, local_offset].pack('VvvvvvvVVVvvvvvVV')
      central << name
    end
    cd_offset = out.bytesize
    out << central
    out << [0x06054b50, 0, 0, files.length, files.length, central.bytesize, cd_offset, 0].pack('VvvvvVVv')
    out
  end

  def dos_time(t)
    t = t.getlocal
    dos_t = (t.hour << 11) | (t.min << 5) | (t.sec / 2)
    dos_d = ((t.year - 1980) << 9) | (t.month << 5) | t.day
    [dos_t, dos_d]
  end

  def write_response(sock, status, headers, body)
    body ||= ''
    status_text = { 200 => 'OK', 206 => 'Partial Content', 207 => 'Multi-Status', 302 => 'Found', 307 => 'Temporary Redirect', 400 => 'Bad Request', 401 => 'Unauthorized', 403 => 'Forbidden', 404 => 'Not Found', 405 => 'Method Not Allowed', 409 => 'Conflict', 500 => 'Internal Server Error' }[status] || 'OK'
    headers = headers.transform_keys(&:downcase)
    @opts[:headers].each do |hv|
      k, v = hv.split(':', 2)
      headers[k.downcase] ||= v.to_s.strip if k && v
    end
    headers['content-length'] = body.bytesize.to_s
    headers['date'] ||= httpdate(Time.now)
    sock.write "HTTP/1.1 #{status} #{status_text}\r\n"
    headers.each { |k, v| sock.write "#{k}: #{v}\r\n" }
    sock.write "\r\n"
    sock.write body
  end

  def authorized?(headers)
    return true if @opts[:auths].empty?
    auth = headers['authorization'].to_s
    return false unless auth.start_with?('Basic ')
    user, pass = Base64.decode64(auth.sub('Basic ', '')).split(':', 2)
    @opts[:auths].any? do |entry|
      u, kind, rest = entry.split(':', 3)
      next false unless u == user
      if rest.nil?
        kind.to_s == pass.to_s
      elsif kind == 'sha256'
        Digest::SHA256.hexdigest(pass.to_s) == rest
      elsif kind == 'sha512'
        Digest::SHA512.hexdigest(pass.to_s) == rest
      else
        false
      end
    end
  rescue StandardError
    false
  end

  def unauthorized
    [401, { 'content-type' => 'text/plain; charset=utf-8', 'www-authenticate' => 'Basic realm="miniserve"' }, 'Unauthorized']
  end

  def not_found(path)
    [404, { 'content-type' => 'text/html' }, error_page('404 Not Found', "No such file or directory: #{h(path)}")]
  end

  def forbidden
    [403, { 'content-type' => 'text/html' }, error_page('403 Forbidden', 'Forbidden')]
  end

  def bad_request
    [400, { 'content-type' => 'text/html' }, error_page('400 Bad Request', 'Bad Request')]
  end

  def redirect(location)
    [307, { 'location' => location }, '']
  end

  def error_page(title, msg)
    %(<!DOCTYPE html><html><head><meta charset="utf-8"><title>#{title}</title></head><body><div class="error"><p>#{title}</p><p>#{msg}</p><p><a class="error-back" href="/">Go back</a></p></div></body></html>)
  end

  def parse_multipart(body, boundary)
    body.split("--#{boundary}").filter_map do |part|
      next if part.strip.empty? || part.start_with?('--')
      head, data = part.split("\r\n\r\n", 2)
      next unless data
      data = data.sub(/\r\n\z/, '')
      disp = head[/content-disposition:[^\r\n]+/i].to_s
      name = disp[/name="([^"]+)"/, 1]
      filename = disp[/filename="([^"]*)"/, 1]
      { name: name, filename: filename, data: data }
    end
  end

  def resolve_duplicate(path)
    return path unless File.exist?(path)
    case @opts[:dup]
    when 'overwrite' then path
    when 'rename'
      ext = File.extname(path)
      base = path[0...-ext.length]
      i = 1
      candidate = "#{base}-#{i}#{ext}"
      while File.exist?(candidate)
        i += 1
        candidate = "#{base}-#{i}#{ext}"
      end
      candidate
    else
      nil
    end
  end

  def hidden_path?(path)
    File.expand_path(path).sub(@root, '').split(File::SEPARATOR).any? { |p| p.start_with?('.') }
  end

  def symlink_in_path?(path)
    cur = @root
    File.expand_path(path).sub(@root, '').split(File::SEPARATOR).reject(&:empty?).any? do |p|
      cur = File.join(cur, p)
      File.symlink?(cur)
    end
  end

  def natural_key(str)
    str.downcase.split(/(\d+)/).map { |x| x =~ /\A\d+\z/ ? x.to_i : x }
  end

  def size(n)
    return '' if n.nil?
    return n.to_s if @opts[:size_display] == 'exact'
    units = %w[B KiB MiB GiB TiB]
    f = n.to_f
    u = 0
    while f >= 1024 && u < units.length - 1
      f /= 1024
      u += 1
    end
    u.zero? ? "#{n} B" : format('%.1f %s', f, units[u])
  end

  def h(s)
    CGI.escapeHTML(s.to_s)
  end

  def join_url(a, b)
    "#{a.end_with?('/') ? a : a + '/'}#{CGI.escape(b)}"
  end

  def with_slash(path)
    path.end_with?('/') ? path : "#{path}/"
  end

  def current_title(rel_url)
    host = "127.0.0.1:#{@opts[:port]}"
    rel_url == '/' ? host : "#{host}#{rel_url.chomp('/')}"
  end

  def inline_type?(mime)
    mime.start_with?('text/', 'image/', 'audio/', 'video/') || mime.include?('javascript') || mime.include?('json') || mime.include?('xml') || mime.include?('pdf')
  end

  def truthy?(v)
    !v.nil? && v != '' && v != '0' && v != 'false'
  end

  def env_path_flag(name)
    ENV.key?(name) ? (ENV[name].to_s.empty? ? '/' : ENV[name]) : nil
  end

  def normalize_route(prefix)
    p = prefix.to_s
    return '' if p.empty? || p == '/'
    p = "/#{p}" unless p.start_with?('/')
    p.chomp('/')
  end

  def default_css
    "body{font-family:-apple-system,BlinkMacSystemFont,\"Segoe UI\",sans-serif;margin:0;background:#fff;color:#323232}.container{padding:1.5rem 5rem}a.file{color:#0086b3}a.file:before{content:\"📃 \"}a.directory{font-weight:bold;color:#d02474}a.directory:before{content:\"📁 \"}table{margin-top:2rem;width:100%;border-collapse:collapse}td,th{padding:.55rem .65rem;text-align:left}thead{background:#323232;color:#fff}tbody tr:nth-child(odd){background:#fbfbfb}tbody tr:nth-child(even){background:#f2f2f2}.footer{text-align:center;padding-top:1.5rem;font-size:.8em;color:#777}.error{margin:2rem}.error p:first-child{font-size:1.25rem;color:#d02424}"
  end

  def default_svg
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" fill="#d02474"/><path d="M8 9h16v3H8zm0 6h16v3H8zm0 6h10v3H8z" fill="white"/></svg>'
  end

  def httpdate(t)
    t.getutc.strftime('%a, %d %b %Y %H:%M:%S GMT')
  end

  def wget_footer(rel_url)
    return '' unless @opts[:show_wget]
    %(<div class="footer"><div class="downloadDirectory">wget -r http://127.0.0.1:#{@opts[:port]}#{rel_url}</div></div>)
  end

  def log(method, path, status)
    warn "#{method} #{path} -> #{status}"
  end

  def manpage
    ".TH MINISERVE 1\n.SH NAME\nminiserve - serve files and directories over HTTP\n.SH SYNOPSIS\nexecutable [OPTIONS] [PATH]\n"
  end
end

MiniServe.new(ARGV).run
