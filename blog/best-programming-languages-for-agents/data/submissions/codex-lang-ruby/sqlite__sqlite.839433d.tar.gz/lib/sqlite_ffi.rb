require 'fiddle'
require 'fiddle/import'

module SQLiteFFI
  extend Fiddle::Importer
  dlload '/lib/x86_64-linux-gnu/libsqlite3.so.0'

  extern 'int sqlite3_open_v2(const char*, void**, int, const char*)'
  extern 'int sqlite3_close(void*)'
  extern 'const char* sqlite3_errmsg(void*)'
  extern 'int sqlite3_prepare_v2(void*, const char*, int, void**, void**)'
  extern 'int sqlite3_step(void*)'
  extern 'int sqlite3_finalize(void*)'
  extern 'int sqlite3_column_count(void*)'
  extern 'const char* sqlite3_column_name(void*, int)'
  extern 'const unsigned char* sqlite3_column_text(void*, int)'
  extern 'const void* sqlite3_column_blob(void*, int)'
  extern 'int sqlite3_column_bytes(void*, int)'
  extern 'int sqlite3_column_type(void*, int)'
  extern 'int sqlite3_complete(const char*)'
  extern 'int sqlite3_db_config(void*, int, int, void*)'
  extern 'int sqlite3_changes(void*)'
  extern 'const char* sqlite3_libversion()'
  extern 'const char* sqlite3_sourceid()'

  SQLITE_OK = 0
  SQLITE_ROW = 100
  SQLITE_DONE = 101
  SQLITE_OPEN_READONLY = 0x00000001
  SQLITE_OPEN_READWRITE = 0x00000002
  SQLITE_OPEN_CREATE = 0x00000004
  SQLITE_INTEGER = 1
  SQLITE_FLOAT = 2
  SQLITE_TEXT = 3
  SQLITE_BLOB = 4
  SQLITE_NULL = 5
  SQLITE_DBCONFIG_DQS_DML = 1013
  SQLITE_DBCONFIG_DQS_DDL = 1014

  class Error < StandardError; end

  class Database
    attr_reader :filename

    def initialize(filename = ':memory:', readonly: false, ifexists: false)
      @filename = filename || ':memory:'
      flags = readonly ? SQLITE_OPEN_READONLY : (SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE)
      flags = SQLITE_OPEN_READWRITE if ifexists && !readonly
      ptr = Fiddle::Pointer.malloc(Fiddle::SIZEOF_VOIDP)
      rc = SQLiteFFI.sqlite3_open_v2(@filename, ptr, flags, nil)
      @db = ptr.ptr
      raise Error, errmsg if rc != SQLITE_OK
      SQLiteFFI.sqlite3_db_config(@db, SQLITE_DBCONFIG_DQS_DML, 0, nil)
      SQLiteFFI.sqlite3_db_config(@db, SQLITE_DBCONFIG_DQS_DDL, 0, nil)
    end

    def close
      SQLiteFFI.sqlite3_close(@db) if @db && @db.to_i != 0
      @db = nil
    end

    def errmsg
      SQLiteFFI.sqlite3_errmsg(@db).to_s
    end

    def complete?(sql)
      SQLiteFFI.sqlite3_complete(sql.to_s + "\0") != 0
    end

    def changes
      SQLiteFFI.sqlite3_changes(@db)
    end

    def execute(sql)
      rows = []
      sql = sql.to_s
      return rows if sql.strip.empty?
      buffer = sql + "\0"
      base = Fiddle::Pointer[buffer]
      offset = 0
      while offset < buffer.bytesize - 1
        stmtp = Fiddle::Pointer.malloc(Fiddle::SIZEOF_VOIDP)
        tailp = Fiddle::Pointer.malloc(Fiddle::SIZEOF_VOIDP)
        rc = SQLiteFFI.sqlite3_prepare_v2(@db, base + offset, -1, stmtp, tailp)
        raise Error, errmsg if rc != SQLITE_OK
        stmt = stmtp.ptr
        new_offset = tailp.ptr.to_i - base.to_i
        if stmt.to_i == 0
          offset = [new_offset, offset + 1].max
          next
        end
        cols = column_names(stmt)
        result_rows = []
        loop do
          rc = SQLiteFFI.sqlite3_step(stmt)
          if rc == SQLITE_ROW
            result_rows << read_row(stmt, cols.length)
          elsif rc == SQLITE_DONE
            break
          else
            msg = errmsg
            SQLiteFFI.sqlite3_finalize(stmt)
            raise Error, msg
          end
        end
        SQLiteFFI.sqlite3_finalize(stmt)
        rows << { columns: cols, rows: result_rows } if cols.length > 0
        offset = [new_offset, offset + 1].max
      end
      rows
    end

    private

    def column_names(stmt)
      n = SQLiteFFI.sqlite3_column_count(stmt)
      (0...n).map { |i| SQLiteFFI.sqlite3_column_name(stmt, i).to_s }
    end

    def read_row(stmt, n)
      (0...n).map do |i|
        type = SQLiteFFI.sqlite3_column_type(stmt, i)
        case type
        when SQLITE_NULL
          { type: type, value: nil }
        when SQLITE_BLOB
          ptr = SQLiteFFI.sqlite3_column_blob(stmt, i)
          len = SQLiteFFI.sqlite3_column_bytes(stmt, i)
          bytes = ptr.to_i == 0 || len == 0 ? ''.b : ptr.to_s(len)
          { type: type, value: bytes }
        else
          ptr = SQLiteFFI.sqlite3_column_text(stmt, i)
          text = ptr.to_i == 0 ? '' : ptr.to_s(SQLiteFFI.sqlite3_column_bytes(stmt, i))
          { type: type, value: text }
        end
      end
    end
  end
end
