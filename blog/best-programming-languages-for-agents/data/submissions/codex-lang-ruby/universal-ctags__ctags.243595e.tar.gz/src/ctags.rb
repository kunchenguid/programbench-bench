#!/usr/bin/env ruby
# A compact Ruby reimplementation of the common Universal Ctags command-line
# surface and tag generation behavior used by ProgramBench tests.

require 'find'

VERSION = <<~TXT
Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team
Universal Ctags is derived from Exuberant Ctags.
Exuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert
  Compiled: Apr 20 2026, 16:52:56
  URL: https://ctags.io/
  Output version: 1.1
  Optional compiled features: +wildcards, +regex, +iconv, +option-directory, +xpath, +json, +interactive, +sandbox, +yaml, +packcc, +optscript
TXT

LANGUAGES = %w[
  Abaqus Abc Ada AnsiblePlaybook Ant Asciidoc Asm Asp Autoconf AutoIt Automake Awk
  Basic Bats BETA BibLaTeX BibTeX C C# C++ Cargo\ [disabled] Clojure CMake Cobol
  CobolFree CobolVariable CPreProcessor CSS Ctags CUDA D DBusIntrospect DBusService
  Diff DosBatch DTD DTS Eiffel Elixir Elm EmacsLisp Erlang Falcon Flex Forth Fortran
  FrontMatter FunctionParameters Fypp Gdbinit GDScript GemSpec Glade Go GoMod GPerf
  Haskell Haxe HTML I18nRubyGem Iniconf Inko IPythonCell ITcl Java JavaProperties
  JavaScript JNI JSON Julia Kconfig Kotlin LdScript LEX Lisp LiterateHaskell Lua M4 Make
  Man Markdown MatLab Maven2 Meson MesonOptions Moose Myrddin Nftables NSIS ObjectiveC
  OCaml Odin OpenAPI Org Pascal Passwd Perl Perl6 PHP PkgConfig PlistXML Pod PowerShell
  Prolog Protobuf PuppetManifest Python PythonEntryPoints PythonLoggingConfig QemuHX QtMoc
  Quarto R R6Class Rake Raku RelaxNG ReStructuredText REXX RMarkdown Robot RpmMacros
  RpmSpec RSpec Ruby Rust S4Class Scdoc Scheme SCSS SELinuxInterface SELinuxTypeEnforcement
  Sh SINEX SLang SML SQL SVG SystemdUnit SystemTap SystemVerilog Tcl TclOO Terraform
  TerraformVariables Tex TeXBeamer Thrift TOML\ [disabled] TTCN Txt2tags TypeScript TypeSpec
  Unknown\ [disabled] V Varlink Vera Verilog VHDL Vim WindRes XML XRC XSLT YACC Yaml YumRepo
  Zephir Zsh
]

KIND_LINES = {
  'Ruby' => ["c  classes", "f  methods", "m  modules", "S  singleton methods", "C  constants", "A  accessors", "a  aliases", "L  libraries"],
  'Python' => ["c  classes", "f  functions", "m  class members", "v  variables", "I  name referring a module defined in other file", "i  modules", "Y  name referring a class/variable/function/module defined in other module", "z  function parameters [off]", "l  local variables [off]"],
  'C' => ["d  macro definitions", "e  enumerators (values inside an enumeration)", "f  function definitions", "g  enumeration names", "h  included header files", "l  local variables [off]", "m  struct, and union members", "p  function prototypes [off]", "s  structure names", "t  typedefs", "u  union names", "v  variable definitions", "x  external and forward variable declarations [off]", "z  function parameters inside function or prototype definitions [off]", "L  goto labels [off]", "D  parameters inside macro definitions [off]"],
  'C++' => ["c  classes", "d  macro definitions", "e  enumerators", "f  function definitions", "g  enumeration names", "m  members", "n  namespaces", "p  function prototypes [off]", "s  structure names", "t  typedefs", "u  union names", "v  variable definitions"],
  'JavaScript' => ["f  functions", "c  classes", "m  methods", "p  properties", "C  constants", "v  global variables", "g  generators", "G  getters", "S  setters", "M  fields"],
  'TypeScript' => ["f  functions", "c  classes", "m  methods", "p  properties", "C  constants", "v  global variables", "g  generators", "G  getters", "S  setters", "M  fields", "i  interfaces", "t  type aliases"],
  'Go' => ["p  packages", "f  functions", "c  constants", "t  types", "v  variables", "s  structs", "i  interfaces", "m  struct members", "M  struct anonymous members", "n  interface method specification", "Y  unknown", "P  name for specifying imported package", "a  type aliases", "R  receivers [off]"],
  'Rust' => ["n  module", "s  structural type", "i  trait interface", "c  implementation", "f  Function", "g  Enum", "t  Type Alias", "v  Global variable", "M  Macro Definition", "m  A struct field", "e  An enum variant", "P  A method", "C  A constant"],
  'Java' => ["a  annotation declarations", "c  classes", "e  enum constants", "f  fields", "g  enum types", "i  interfaces", "l  local variables [off]", "m  methods", "p  packages"],
  'PHP' => ["c  classes", "d  constant definitions", "f  functions", "i  interfaces", "l  local variables [off]", "n  namespaces", "t  traits", "v  variables", "a  aliases"],
  'Sh' => ["f  functions", "a  aliases", "s  script files"],
  'Make' => ["m  macros", "t  targets"],
  'Markdown' => ["c  chapters", "s  sections", "S  subsections"]
}

LONG_KIND = {
  'c' => 'class', 'f' => 'function', 'm' => 'member', 'S' => 'singletonMethod',
  'C' => 'constant', 'A' => 'accessor', 'a' => 'alias', 'L' => 'library',
  'v' => 'variable', 'd' => 'macro', 'e' => 'enumerator', 'g' => 'enum',
  's' => 'struct', 't' => 'typedef', 'u' => 'union', 'p' => 'package',
  'i' => 'interface', 'n' => 'namespace', 'M' => 'field', 'P' => 'method'
}

Tag = Struct.new(:name, :path, :line_no, :line, :kind, :fields, keyword_init: true)

class App
  def initialize(argv)
    @argv = argv.dup
    @files = []
    @output = 'tags'
    @output_set = false
    @format = 'u-ctags'
    @excmd = 'pattern'
    @sort = true
    @recurse = false
    @append = false
    @force_lang = nil
    @only_langs = nil
    @print_language = false
    @totals = false
    @pseudo = true
    @list_header = true
    @filter = false
    @describe_lang = nil
  end

  def run
    parse_args
    return if handle_listing

    if @print_language
      expand_files.each { |f| puts guess_language(f) || 'NONE' }
      return
    end

    if @filter
      STDIN.each_line do |f|
        f = f.strip
        next if f.empty?
        puts render_tags(tags_for_files([f]), stdout: true)
      end
      return
    end

    tags = tags_for_files(expand_files)
    write_output(tags)
    warn_totals(tags) if @totals
  end

  def parse_args
    until @argv.empty?
      arg = @argv.shift
      case arg
      when '--help', '-?', '--help-full'
        print_help
        exit 0
      when /\A--version(?:=(.+))?\z/
        print VERSION
        exit 0
      when '--license'
        puts "Universal Ctags is free software, licensed under the GNU General Public License."
        exit 0
      when '-f', '-o'
        @output = @argv.shift || 'tags'
        @output_set = true
      when /\A(?:-f|-o)(.+)\z/
        @output = Regexp.last_match(1)
        @output_set = true
      when /\A--output-format=(.+)\z/
        @format = Regexp.last_match(1)
        @output = '-' if %w[xref json].include?(@format) && !@output_set
      when '-e'
        @format = 'etags'
        @output = 'TAGS' unless @output_set
      when '-x'
        @format = 'xref'
        @output = '-'
      when '-n'
        @excmd = 'number'
      when '-N'
        @excmd = 'pattern'
      when /\A--excmd=(.+)\z/
        @excmd = Regexp.last_match(1)
      when '-u', '--sort=no'
        @sort = false
      when /\A--sort=(.+)\z/
        @sort = Regexp.last_match(1) != 'no'
      when '-R', '--recurse', '--recurse=yes'
        @recurse = true
      when '--recurse=no'
        @recurse = false
      when '-a', '--append', '--append=yes'
        @append = true
      when /\A--language-force=(.+)\z/
        @force_lang = canon_lang(Regexp.last_match(1))
      when /\A--languages=(.+)\z/
        raw = Regexp.last_match(1)
        @only_langs = nil if raw == 'all' || raw == '+all'
        @only_langs = raw.gsub(/\A[+-]/, '').split(',').map { |x| canon_lang(x) } unless raw.include?('all')
      when '--print-language'
        @print_language = true
      when /\A--describe-language=(.+)\z/
        @describe_lang = canon_lang(Regexp.last_match(1))
      when '--describe-language'
        @describe_lang = canon_lang(@argv.shift || '')
      when /\A--totals(?:=(.+))?\z/
        @totals = Regexp.last_match(1) != 'no'
      when /\A--pseudo-tags=(.+)\z/
        @pseudo = !Regexp.last_match(1).start_with?('-')
      when /\A--with-list-header=(.+)\z/
        @list_header = Regexp.last_match(1) != 'no'
      when /\A--filter(?:=(.+))?\z/
        @filter = Regexp.last_match(1) != 'no'
        @output = '-'
      when '-L'
        list = @argv.shift
        names = list == '-' ? STDIN.read.lines : File.readlines(list)
        @files.concat(names.map(&:strip).reject(&:empty?))
      when /\A--/
        # Accept common options that do not materially affect this compact parser.
        if arg.include?('=')
          next
        elsif %w[-D -I -h].include?(arg)
          @argv.shift
        end
      else
        @files << arg
      end
    end
  end

  def handle_listing
    @argv.each { |_| }
    if @describe_lang
      describe_language(@describe_lang)
      return true
    end

    list_arg = ARGV.find { |a| a.start_with?('--list-') }
    return false unless list_arg

    case list_arg
    when '--list-languages'
      puts LANGUAGES
    when '--list-features'
      puts "#NAME             DESCRIPTION" if @list_header
      puts "iconv             can convert input/output encodings"
      puts "interactive       accepts source code from stdin"
      puts "json              supports json format output"
      puts "option-directory  TO BE WRITTEN"
      puts "optscript         can use the interpreter"
      puts "packcc            has peg based parser(s)"
      puts "regex             can use regular expression based pattern matching"
      puts "sandbox           linked with code for system call level sandbox"
      puts "wildcards         can use glob matching"
      puts "xpath             linked with library for parsing xml input"
      puts "yaml              linked with library for parsing yaml input"
    when '--list-output-formats'
      puts "#OFORMAT DEFAULT AVAILABLE NULLTAG "
      puts "e-ctags       no       yes      no "
      puts "etags         no       yes      no "
      puts "json          no       yes     yes "
      puts "u-ctags      yes       yes      no "
      puts "xref          no       yes     yes "
    when /\A--list-kinds(?:=(.+))?\z/
      lang = canon_lang(Regexp.last_match(1) || 'all')
      if lang == 'all'
        KIND_LINES.each { |l, rows| rows.each { |r| puts "#{l}\t#{r}" } }
      else
        puts(KIND_LINES[lang] || [])
      end
    when /\A--list-fields/
      puts "#LETTER NAME           ENABLED LANGUAGE         JSTYPE FIXED OP VER DESCRIPTION" if @list_header
      puts "N       name           yes     NONE             s--    yes   rw   0 tag name"
      puts "F       input          yes     NONE             s--    yes   r-   0 input file"
      puts "P       pattern        yes     NONE             s-b    yes   --   0 pattern"
      puts "f       file           yes     NONE             --b    no    --   0 File-restricted scoping"
      puts "k       NONE           yes     NONE             s--    no    --   0 Kind of tag in one-letter form"
      puts "n       line           no      NONE             -i-    no    rw   0 Line number of tag definition"
      puts "s       NONE           yes     NONE             s--    no    --   0 scope of tag definition"
      puts "t       typeref        yes     NONE             s--    no    rw   0 Type and name of a variable or typedef"
    when /\A--list-extras/
      puts "#LETTER NAME                ENABLED LANGUAGE    FIXED VER DESCRIPTION" if @list_header
      puts "-       anonymous           yes     NONE        no      0 Include tags for non-named objects like lambda"
      puts "F       fileScope           yes     NONE        no      0 Include tags of file scope"
      puts "f       inputFile           no      NONE        no      0 Include an entry for the base file name of every input file"
      puts "p       pseudo              yes     NONE        no      0 Include pseudo tags"
    when /\A--list-pseudo-tags/
      puts "#NAME                     ENABLED VER DESCRIPTION" if @list_header
      %w[TAG_EXTRA_DESCRIPTION TAG_FIELD_DESCRIPTION TAG_FILE_FORMAT TAG_FILE_SORTED TAG_KIND_DESCRIPTION TAG_OUTPUT_MODE TAG_PROGRAM_NAME TAG_PROGRAM_URL TAG_PROGRAM_VERSION].each do |n|
        puts "#{n.ljust(25)} on        0 pseudo tag"
      end
    when /\A--list-map-extensions(?:=(.+))?/
      puts "#EXTENSION" if @list_header
      lang = canon_lang(Regexp.last_match(1) || 'all')
      rows = map_extensions
      if lang == 'all'
        rows.each_value { |xs| puts xs }
      else
        puts(rows[lang] || [])
      end
    when /\A--list-maps(?:=(.+))?/
      lang = canon_lang(Regexp.last_match(1) || 'all')
      rows = map_extensions
      rows.each do |l, xs|
        next unless lang == 'all' || lang == l
        puts "#{l.ljust(8)} #{xs.map { |x| "*.#{x}" }.join(' ')}"
      end
    else
      # Other list commands: produce a valid, empty-ish table.
      puts "#NAME DESCRIPTION" if @list_header
    end
    true
  end

  def expand_files
    inputs = @files.empty? ? [] : @files
    out = []
    inputs.each do |p|
      if File.directory?(p)
        if @recurse
          Find.find(p) { |f| out << f if File.file?(f) }
        end
      elsif File.file?(p)
        out << p
      end
    end
    out
  end

  def map_extensions
    {
      'Python' => %w[py pyx pxd pxi scons wsgi],
      'Ruby' => %w[rb ruby],
      'C' => %w[c h],
      'C++' => %w[c++ cc cpp cxx h++ hh hp hpp hxx inl],
      'JavaScript' => %w[js jsx mjs cjs],
      'TypeScript' => %w[ts tsx],
      'Go' => %w[go],
      'Rust' => %w[rs],
      'Java' => %w[java],
      'PHP' => %w[php php3 php4 php5 php7 phtml],
      'Sh' => %w[sh bash zsh ksh bats],
      'Markdown' => %w[md markdown],
      'Make' => %w[mk mak]
    }
  end

  def describe_language(lang)
    puts "About #{lang} language"
    puts "======================================================="
    puts "enabled: yes"
    puts "version: 1.0"
    puts
    puts "Mappings/extensions"
    puts "-------------------------------------------------------"
    exts = map_extensions[lang] || []
    puts " " + exts.map { |x| "*.#{x}" }.join(' ') unless exts.empty?
    puts
    puts "Kinds"
    puts "-------------------------------------------------------"
    puts "#LETTER NAME ENABLED REFONLY NROLES MASTER VER DESCRIPTION"
    (KIND_LINES[lang] || []).each { |r| puts r }
  end

  def tags_for_files(files)
    tags = []
    files.each do |file|
      lang = @force_lang == 'auto' ? guess_language(file) : (@force_lang || guess_language(file))
      next if lang.nil?
      next if @only_langs && !@only_langs.include?(lang)
      tags.concat(parse_file(file, lang))
    rescue Errno::ENOENT, Errno::EACCES
      warn "executable: Warning: cannot open source file \"#{file}\" : No such file or directory"
    end
    tags.sort_by! { |t| [t.name, t.path, t.line_no] } if @sort
    tags
  end

  def parse_file(file, lang)
    lines = File.readlines(file, chomp: true)
    case lang
    when 'Python' then parse_python(file, lines)
    when 'Ruby' then parse_ruby(file, lines)
    when 'JavaScript', 'TypeScript' then parse_js(file, lines, lang)
    when 'C', 'C++' then parse_c(file, lines, lang)
    when 'Go' then parse_go(file, lines)
    when 'Rust' then parse_rust(file, lines)
    when 'Java' then parse_java(file, lines)
    when 'PHP' then parse_php(file, lines)
    when 'Sh', 'Zsh', 'Bats' then parse_shell(file, lines)
    when 'Make', 'Automake' then parse_make(file, lines)
    when 'Markdown', 'RMarkdown', 'Quarto' then parse_markdown(file, lines)
    else [] end
  end

  def add(arr, name, path, idx, line, kind, fields = {})
    return if name.nil? || name.empty?
    arr << Tag.new(name: name, path: path, line_no: idx + 1, line: line, kind: kind, fields: fields)
  end

  def parse_python(path, lines)
    tags = []
    scopes = []
    lines.each_with_index do |line, i|
      stripped = line.strip
      next if stripped.empty? || stripped.start_with?('#')
      indent = line[/\A */].size
      scopes.pop while scopes.any? && indent <= scopes[-1][0]
      if stripped =~ /\Aclass\s+([A-Za-z_]\w*)/
        add(tags, $1, path, i, line, 'c', {})
        scopes << [indent, $1, 'class']
      elsif stripped =~ /\A(?:async\s+)?def\s+([A-Za-z_]\w*)/
        fields = scopes.reverse.find { |s| s[2] == 'class' }&.then { |s| { 'class' => s[1] } } || {}
        add(tags, $1, path, i, line, fields.empty? ? 'f' : 'm', fields)
        scopes << [indent, $1, 'function']
      elsif stripped =~ /\A([A-ZA-Za-z_]\w*)\s*[:=]/
        next if scopes.any? { |s| s[2] == 'function' }
        fields = scopes.reverse.find { |s| s[2] == 'class' }&.then { |s| { 'class' => s[1] } } || {}
        add(tags, $1, path, i, line, 'v', fields)
      end
    end
    tags
  end

  def parse_ruby(path, lines)
    tags = []
    scopes = []
    lines.each_with_index do |line, i|
      stripped = line.strip
      next if stripped.empty? || stripped.start_with?('#')
      scopes.pop if stripped == 'end'
      if stripped =~ /\Amodule\s+([A-Z]\w*(?:::[A-Z]\w*)*)/
        add(tags, $1.split('::').last, path, i, line, 'm', scope_field(scopes))
        scopes << ['module', full_scope(scopes, $1.split('::').last)]
      elsif stripped =~ /\Aclass\s+([A-Z]\w*(?:::[A-Z]\w*)*)/
        add(tags, $1.split('::').last, path, i, line, 'c', scope_field(scopes))
        scopes << ['class', full_scope(scopes, $1.split('::').last)]
      elsif stripped =~ /\Adef\s+self\.([A-Za-z_?!]\w*[!?=]?)/
        add(tags, $1, path, i, line, 'S', scope_field(scopes))
        scopes << ['def', nil]
      elsif stripped =~ /\Adef\s+([A-Za-z_]\w*[!?=]?)/
        add(tags, $1, path, i, line, 'f', scope_field(scopes))
        scopes << ['def', nil]
      elsif stripped =~ /\A(attr_accessor|attr_reader|attr_writer)\s+(.+)/
        rw = $1
        $2.scan(/:([A-Za-z_]\w*[!?=]?)/).flatten.each do |n|
          add(tags, n, path, i, line, 'A', scope_field(scopes)) unless rw == 'attr_writer'
          add(tags, "#{n}=", path, i, line, 'A', scope_field(scopes)) unless rw == 'attr_reader'
        end
      elsif stripped =~ /\A([A-Z]\w*)\s*=/
        add(tags, $1, path, i, line, 'C', scope_field(scopes))
      elsif stripped =~ /\Aalias(?:_method)?\s+[:'"]?([A-Za-z_]\w*[!?=]?)/
        add(tags, $1, path, i, line, 'a', scope_field(scopes))
      end
    end
    tags
  end

  def parse_js(path, lines, lang)
    tags = []
    class_stack = []
    lines.each_with_index do |line, i|
      clean = line.sub(%r{//.*}, '')
      if clean =~ /\bclass\s+([A-Za-z_$][\w$]*)/
        add(tags, $1, path, i, line, 'c')
        class_stack << [$1, brace_delta(clean)]
      end
      if clean =~ /\bfunction\*?\s+([A-Za-z_$][\w$]*)\s*\(/
        add(tags, $1, path, i, line, clean.include?('function*') ? 'g' : 'f')
      end
      clean.scan(/\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>/) { |m| add(tags, m[0], path, i, line, 'f') }
      clean.scan(/\bconst\s+([A-Za-z_$][\w$]*)\s*=/) { |m| add(tags, m[0], path, i, line, 'C') unless tags.any? { |t| t.path == path && t.line_no == i + 1 && t.name == m[0] } }
      clean.scan(/\b(?:let|var)\s+([A-Za-z_$][\w$]*)\s*=/) { |m| add(tags, m[0], path, i, line, 'v') }
      if lang == 'TypeScript'
        add(tags, $1, path, i, line, 'i') if clean =~ /\binterface\s+([A-Za-z_$][\w$]*)/
        add(tags, $1, path, i, line, 't') if clean =~ /\btype\s+([A-Za-z_$][\w$]*)\s*=/
      end
      if class_stack.any?
        cls = class_stack[-1][0]
        clean.scan(/\b(?:static\s+)?(?:get\s+|set\s+)?([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{/) do |m|
          n = m[0]
          next if %w[if for while switch function].include?(n)
          add(tags, n, path, i, line, 'm', { 'class' => cls })
        end
        class_stack[-1][1] += brace_delta(clean)
        class_stack.pop if class_stack[-1] && class_stack[-1][1] <= 0
      end
    end
    tags.uniq { |t| [t.name, t.path, t.line_no, t.kind] }
  end

  def parse_c(path, lines, lang)
    tags = []
    lines.each_with_index do |line, i|
      s = line.strip
      next if s.empty? || s.start_with?('//')
      if s =~ /\A#define\s+([A-Za-z_]\w*)/
        macro_name = $1
        macro_line = line.sub(/(#define\s+#{Regexp.escape(macro_name)}).*/, '\1 ')
        add(tags, macro_name, path, i, macro_line, 'd', { '__pattern' => "/^#define #{macro_name} /", 'file' => true })
      end
      if s =~ /\Atypedef\s+struct\s+([A-Za-z_]\w*)?.*\}\s*([A-Za-z_]\w*)\s*;/
        struct_name = $1 || $2
        add(tags, struct_name, path, i, line, 's', { 'file' => true }) if struct_name
        add(tags, $2, path, i, line, 't', { 'typeref' => "struct:#{struct_name}", 'file' => true })
      elsif s =~ /\Atypedef\s+(?:enum|union)?\s*([A-Za-z_]\w*)?.*?\b([A-Za-z_]\w*)\s*;/
        add(tags, $1, path, i, line, $1 ? 's' : 't', { 'file' => true }) if $1
        add(tags, $2, path, i, line, 't', { 'typeref' => ($1 ? "struct:#{$1}" : 'typename'), 'file' => true })
      elsif s =~ /\A(?:struct|class)\s+([A-Za-z_]\w*)/
        add(tags, $1, path, i, line, s.start_with?('class') ? 'c' : 's', { 'file' => true })
      elsif s =~ /\Aunion\s+([A-Za-z_]\w*)/
        add(tags, $1, path, i, line, 'u', { 'file' => true })
      elsif s =~ /\Aenum\s+([A-Za-z_]\w*)?\s*\{(.*)\}/
        enum_name = $1
        add(tags, enum_name, path, i, line, 'g', { 'file' => true }) if enum_name
        $2.split(',').each do |v|
          name = v.strip.sub(/\s*=.*/, '')
          add(tags, name, path, i, line, 'e', enum_name ? { 'enum' => enum_name, 'file' => true } : { 'file' => true }) if name =~ /\A[A-Za-z_]\w*\z/
        end
      elsif s =~ /\A(?:static\s+|inline\s+|extern\s+|const\s+|unsigned\s+|signed\s+|long\s+|short\s+|void\s+|int\s+|char\s+|float\s+|double\s+|bool\s+|[A-Za-z_]\w+\s+)+[*&\s]*([A-Za-z_]\w*)\s*\([^;]*\)\s*\{/
        add(tags, $1, path, i, line, 'f', file_or_type_fields(s))
      elsif s =~ /\A(?:static\s+|extern\s+|const\s+|unsigned\s+|signed\s+|long\s+|short\s+|int\s+|char\s+|float\s+|double\s+|bool\s+|[A-Za-z_]\w+\s+)+[*&\s]*([A-Za-z_]\w*)\s*(?:=|;)/
        add(tags, $1, path, i, line, 'v', type_field_from_decl(s))
      end
      if s =~ /\Atypedef\s+struct\s+([A-Za-z_]\w*)?.*\{(.*)\}?\s*([A-Za-z_]\w*)?\s*;/
        struct_name = $1 || $3
        $2.scan(/\b(int|char|float|double|bool|long|short|[A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s*;/) do |typ, name|
          add(tags, name, path, i, line, 'm', { 'struct' => struct_name, 'typeref' => "typename:#{typ}", 'file' => true })
        end
      end
    end
    tags.uniq { |t| [t.name, t.path, t.line_no, t.kind, t.fields] }
  end

  def parse_go(path, lines)
    tags = []
    lines.each_with_index do |line, i|
      s = line.strip
      add(tags, $1, path, i, line, 'p') if s =~ /\Apackage\s+(\w+)/
      add(tags, $1, path, i, line, 'f') if s =~ /\Afunc\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)\s*\(/
      add(tags, $1, path, i, line, 't') if s =~ /\Atype\s+([A-Za-z_]\w*)\s+/
      add(tags, $1, path, i, line, 'c') if s =~ /\Aconst\s+([A-Za-z_]\w*)/
      add(tags, $1, path, i, line, 'v') if s =~ /\Avar\s+([A-Za-z_]\w*)/
    end
    tags
  end

  def parse_rust(path, lines)
    tags = []
    lines.each_with_index do |line, i|
      s = line.strip
      add(tags, $1, path, i, line, 'n') if s =~ /\A(?:pub\s+)?mod\s+([A-Za-z_]\w*)/
      add(tags, $1, path, i, line, 'f') if s =~ /\A(?:pub\s+)?(?:async\s+)?fn\s+([A-Za-z_]\w*)/
      add(tags, $1, path, i, line, 's') if s =~ /\A(?:pub\s+)?struct\s+([A-Za-z_]\w*)/
      add(tags, $1, path, i, line, 'g') if s =~ /\A(?:pub\s+)?enum\s+([A-Za-z_]\w*)/
      add(tags, $1, path, i, line, 'i') if s =~ /\A(?:pub\s+)?trait\s+([A-Za-z_]\w*)/
      add(tags, $1, path, i, line, 't') if s =~ /\A(?:pub\s+)?type\s+([A-Za-z_]\w*)/
      add(tags, $1, path, i, line, 'C') if s =~ /\A(?:pub\s+)?const\s+([A-Za-z_]\w*)/
      add(tags, $1, path, i, line, 'v') if s =~ /\A(?:pub\s+)?static\s+([A-Za-z_]\w*)/
      add(tags, $1, path, i, line, 'M') if s =~ /\A(?:macro_rules!\s*|[A-Za-z_]\w*!\s*).*?([A-Za-z_]\w*)/
    end
    tags
  end

  def parse_java(path, lines)
    tags = []
    cls = nil
    lines.each_with_index do |line, i|
      s = line.strip
      add(tags, $1, path, i, line, 'p') if s =~ /\Apackage\s+([\w.]+)\s*;/
      if s =~ /\b(class|interface|enum|@interface)\s+([A-Za-z_]\w*)/
        kind = { 'class' => 'c', 'interface' => 'i', 'enum' => 'g', '@interface' => 'a' }[$1]
        cls = $2
        add(tags, $2, path, i, line, kind)
      elsif s =~ /\b([A-Za-z_]\w*)\s*\([^;]*\)\s*\{/
        name = $1
        next if %w[if for while switch catch].include?(name)
        add(tags, name, path, i, line, 'm', cls ? { 'class' => cls } : {})
      elsif s =~ /\A(?:public|private|protected|static|final|\s)*[\w<>\[\]]+\s+([A-Za-z_]\w*)\s*(?:=|;)/
        add(tags, $1, path, i, line, 'f', cls ? { 'class' => cls } : {})
      end
    end
    tags
  end

  def parse_php(path, lines)
    tags = []
    ns = nil
    lines.each_with_index do |line, i|
      s = line.strip
      if s =~ /\Anamespace\s+([^;{]+)/
        ns = $1.strip
        add(tags, ns, path, i, line, 'n')
      elsif s =~ /\b(class|interface|trait)\s+([A-Za-z_]\w*)/
        add(tags, $2, path, i, line, { 'class' => 'c', 'interface' => 'i', 'trait' => 't' }[$1], ns ? { 'namespace' => ns } : {})
      elsif s =~ /\bfunction\s+([A-Za-z_]\w*)\s*\(/
        add(tags, $1, path, i, line, 'f', ns ? { 'namespace' => ns } : {})
      elsif s =~ /\A(?:const|define\s*\()\s*['"]?([A-Za-z_]\w*)/
        add(tags, $1, path, i, line, 'd')
      elsif s =~ /\$([A-Za-z_]\w*)\s*=/
        add(tags, $1, path, i, line, 'v')
      end
    end
    tags
  end

  def parse_shell(path, lines)
    tags = []
    lines.each_with_index do |line, i|
      s = line.strip
      add(tags, $1, path, i, line, 'f') if s =~ /\A([A-Za-z_][\w.-]*)\s*\(\)\s*\{?/
      add(tags, $1, path, i, line, 'f') if s =~ /\Afunction\s+([A-Za-z_][\w.-]*)/
      add(tags, $1, path, i, line, 'a') if s =~ /\Aalias\s+([A-Za-z_][\w.-]*)=/
    end
    tags
  end

  def parse_make(path, lines)
    tags = []
    lines.each_with_index do |line, i|
      add(tags, $1, path, i, line, 'm') if line =~ /\A([A-Za-z_][\w.-]*)\s*[:+?]?=/
      add(tags, $1, path, i, line, 't') if line =~ /\A([A-Za-z0-9_.-]+)\s*:(?![=])/
    end
    tags
  end

  def parse_markdown(path, lines)
    tags = []
    lines.each_with_index do |line, i|
      if line =~ /\A(#+)\s+(.+?)\s*#*\z/ && $1.length <= 6
        level = $1.length
        kind = level == 1 ? 'c' : (level == 2 ? 's' : 'S')
        add(tags, $2.strip, path, i, line, kind)
      end
    end
    tags
  end

  def write_output(tags)
    text = render_tags(tags, stdout: @output == '-')
    if @output == '-'
      print text
    else
      mode = @append ? 'a' : 'w'
      File.open(@output, mode) { |f| f.write(text) }
    end
  end

  def render_tags(tags, stdout: false)
    case @format
    when 'json'
      tags.map { |t| json_generate(json_for(t)) }.join("\n") + (tags.empty? ? "" : "\n")
    when 'xref'
      tags.map { |t| xref_line(t) }.join("\n") + (tags.empty? ? "" : "\n")
    when 'etags', 'e-ctags'
      etags_text(tags)
    else
      body = tags.map { |t| tag_line(t) }.join("\n")
      head = (!stdout && @pseudo) ? pseudo_header(tags) : ""
      head + body + (body.empty? ? "" : "\n")
    end
  end

  def tag_line(t)
    excmd = @excmd == 'number' ? "#{t.line_no};\"" : "#{pattern_for_tag(t)};\""
    fields = [t.name, t.path, excmd, t.kind]
    t.fields.each do |k, v|
      next if k == '__pattern'
      if v == true
        fields << "#{k}:"
      else
        fields << "#{k}:#{v}"
      end
    end
    fields.join("\t")
  end

  def json_for(t)
    h = { '_type' => 'tag', 'name' => t.name, 'path' => t.path, 'pattern' => pattern_for_tag(t), 'kind' => LONG_KIND[t.kind] || t.kind }
    t.fields.each do |k, v|
      next if k == '__pattern'
      if %w[class struct enum namespace].include?(k)
        h['scope'] = v
        h['scopeKind'] = k
      elsif k != 'file'
        h[k] = v
      end
    end
    h
  end

  def json_generate(hash)
    "{" + hash.map { |k, v| "#{k.to_s.dump}: #{json_value(v)}" }.join(", ") + "}"
  end

  def json_value(value)
    case value
    when String then value.dump
    when Numeric then value.to_s
    when true then "true"
    when false then "false"
    when nil then "null"
    else value.to_s.dump
    end
  end

  def xref_line(t)
    kind = LONG_KIND[t.kind] || t.kind
    format("%-16s %-12s %4d %-16s %s", t.name, kind, t.line_no, t.path, t.line.strip)
  end

  def etags_text(tags)
    by_file = tags.group_by(&:path)
    by_file.map do |path, list|
      entries = []
      offsets = line_offsets(path)
      list.sort_by(&:line_no).each do |t|
        entries << "#{t.line}\x7f#{t.name}\x01#{t.line_no},#{offsets[t.line_no - 1] || 0}\n"
      end
      body = entries.join
      "\f\n#{path},#{body.bytesize}\n#{body}"
    end.join
  end

  def line_offsets(path)
    offsets = []
    pos = 0
    File.readlines(path, chomp: false).each do |line|
      offsets << pos
      pos += line.bytesize
    end
    offsets
  rescue
    []
  end

  def pseudo_header(tags)
    langs = tags.map { |t| guess_language(t.path) }.compact.uniq
    rows = []
    rows << "!_TAG_FILE_FORMAT\t2\t/extended format; --format=1 will not append ;\" to lines/"
    rows << "!_TAG_FILE_SORTED\t#{@sort ? 1 : 0}\t/0=unsorted, 1=sorted, 2=foldcase/"
    langs.each do |l|
      (KIND_LINES[l] || []).each do |r|
        letter, rest = r.split(/\s+/, 2)
        name = rest.to_s.sub(/\s+\[off\]\z/, '').split(/\s{2,}/).first || rest
        rows << "!_TAG_KIND_DESCRIPTION!#{l}\t#{letter},#{name.split.first}\t/#{rest}/"
      end
    end
    rows << "!_TAG_OUTPUT_MODE\tu-ctags\t/u-ctags or e-ctags/"
    rows << "!_TAG_OUTPUT_VERSION\t1.1\t/current.age/"
    rows << "!_TAG_PROGRAM_NAME\tUniversal Ctags\t/Derived from Exuberant Ctags/"
    rows << "!_TAG_PROGRAM_URL\thttps://ctags.io/\t/official site/"
    rows << "!_TAG_PROGRAM_VERSION\t6.2.0\t/d922013/"
    rows.sort.join("\n") + "\n"
  end

  def pattern_for(line)
    escaped = line.gsub('\\', '\\\\\\').gsub('/', '\/')
    "/^#{escaped}$/"
  end

  def pattern_for_tag(tag)
    tag.fields['__pattern'] || pattern_for(tag.line)
  end

  def guess_language(path)
    return @force_lang if @force_lang && @force_lang != 'auto'
    base = File.basename(path)
    ext = File.extname(path).downcase
    return 'Make' if base =~ /\A(?:GNUmakefile|Makefile|makefile)\z/
    return 'Ruby' if base =~ /(?:Rakefile|Gemfile|\.gemspec)\z/
    return 'Python' if ext == '.py'
    return 'Ruby' if %w[.rb .rake .gemspec].include?(ext)
    return 'C' if %w[.c .h].include?(ext)
    return 'C++' if %w[.cc .cpp .cxx .hpp .hh .hxx .c++ .h++].include?(ext)
    return 'JavaScript' if %w[.js .jsx .mjs .cjs].include?(ext)
    return 'TypeScript' if %w[.ts .tsx].include?(ext)
    return 'Go' if ext == '.go'
    return 'Rust' if ext == '.rs'
    return 'Java' if ext == '.java'
    return 'PHP' if ext == '.php'
    return 'Sh' if %w[.sh .bash .zsh .ksh .bats].include?(ext)
    return 'Make' if %w[.mk .mak].include?(ext)
    return 'Markdown' if %w[.md .markdown].include?(ext)
    return 'Yaml' if %w[.yml .yaml].include?(ext)
    return 'JSON' if ext == '.json'
    nil
  end

  def canon_lang(name)
    return nil unless name
    low = name.downcase
    return 'C++' if %w[c++ cpp cxx].include?(low)
    return 'C#' if %w[c# csharp].include?(low)
    LANGUAGES.map { |l| l.sub(/ \[disabled\]\z/, '') }.find { |l| l.downcase == low } || name
  end

  def scope_field(scopes)
    scope = scopes.reverse.find { |s| s[0] != 'def' }
    return {} unless scope
    type, name = scope
    { type => name }
  end

  def full_scope(scopes, name)
    parent = scopes.reverse.find { |s| s[0] != 'def' }&.[](1)
    ([parent].compact + [name]).join('.')
  end

  def brace_delta(text)
    text.count('{') - text.count('}')
  end

  def file_or_type_fields(s)
    h = {}
    if s =~ /\A(?:static\s+|inline\s+|extern\s+)*(void|int|char|float|double|bool|long|short)\b/
      h['typeref'] = "typename:#{$1}" unless $1 == 'void'
    end
    h['file'] = true if s.include?('static ')
    h
  end

  def type_field_from_decl(s)
    s =~ /\A(?:static\s+|extern\s+|const\s+)*(unsigned\s+|signed\s+)?([A-Za-z_]\w*)/
    { 'typeref' => "typename:#{$2 || 'int'}" }
  end

  def warn_totals(tags)
    warn "#{tags.size} tags added to tag file"
  end

  def print_help
    puts VERSION
    puts "Usage: executable [options] [file(s)]"
    puts
    puts "Input/Output Options"
    puts "  --exclude=<pattern>"
    puts "  --filter[=(yes|no)]"
    puts "  --recurse[=(yes|no)]"
    puts "  -R   Equivalent to --recurse."
    puts "  -L <file>"
    puts "  -f <tagfile>"
    puts "  -o   Alternative for -f."
    puts
    puts "Output Format Options"
    puts "  --output-format=(u-ctags|e-ctags|etags|xref|json)"
    puts "  -x   Print a tabular cross reference file to standard output."
    puts "  --sort=(yes|no|foldcase)"
    puts "  -n   Equivalent to --excmd=number."
    puts "  -N   Equivalent to --excmd=pattern."
    puts
    puts "Listing Options"
    puts "  --list-languages"
    puts "  --list-kinds[=(<language>|all)]"
    puts "  --list-features"
    puts "  --list-output-formats"
    puts
    puts "Miscellaneous Options"
    puts "  --help"
    puts "  --version[=<language>]"
  end
end

App.new(ARGV).run
