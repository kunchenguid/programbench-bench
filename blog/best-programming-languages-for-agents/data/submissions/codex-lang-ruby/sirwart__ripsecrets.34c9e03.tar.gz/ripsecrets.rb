#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = "0.1.11"

HELP_SHORT = <<~TEXT
  A command-line tool to prevent committing secret keys into your source code

  Usage: executable [OPTIONS] [Source files]...

  Arguments:
    [Source files]...  Source files. Can be files or directories. Defaults to '.'

  Options:
        --install-pre-commit
            Install `ripsecrets` as a pre-commit hook automatically in git directory provided
        --strict-ignore
            If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit
        --only-matching
            Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line
        --additional-pattern <ADDITIONAL_PATTERNS>
            Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret
    -h, --help
            Print help (see more with '--help')
    -V, --version
            Print version
TEXT

HELP_LONG = <<~TEXT
  ripsecrets searches files and directories recursively for secret API keys.
  It's primarily designed to be used as a pre-commit to prevent committing
  secrets into version control.

  Usage: executable [OPTIONS] [Source files]...

  Arguments:
    [Source files]...
            Source files. Can be files or directories. Defaults to '.'

  Options:
        --install-pre-commit
            Install `ripsecrets` as a pre-commit hook automatically in git directory provided

        --strict-ignore
            If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit

        --only-matching
            Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line

        --additional-pattern <ADDITIONAL_PATTERNS>
            Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
TEXT

Pattern = Struct.new(:regex, :group_random, keyword_init: true)

DEFAULT_PATTERNS = [
  Pattern.new(regex: /(?i)(?:aws_access_key_id|aws_access_key|access_key_id).{0,20}[:=]\s*['"]?(AKIA[0-9A-Z]{16})/, group_random: false),
  Pattern.new(regex: /(?i)(?:aws|amazon|amzn).{0,40}(?:secret|access).{0,20}[:=]\s*['"]?([A-Za-z0-9\/+=]{40})/, group_random: false),
  Pattern.new(regex: /(?i)(?:secret|api[_-]?key|access[_-]?key|token|credential).{0,20}[:=]\s*['"]?([A-Za-z0-9_\/+=.\-]{20,})/, group_random: true),
  Pattern.new(regex: /gh[pousr]_[A-Za-z0-9_]{36}/, group_random: false),
  Pattern.new(regex: /\bgithub_pat_[A-Za-z0-9_]{20,200}\b/, group_random: false),
  Pattern.new(regex: /\bxox[abprs]-[A-Za-z0-9-]{20,120}\b/, group_random: false),
  Pattern.new(regex: /\b[rs]k_(?:live|test)_[A-Za-z0-9]{24,}\b/, group_random: false),
  Pattern.new(regex: /\bAIza[0-9A-Za-z_\-]{35}\b/, group_random: false),
  Pattern.new(regex: /\bnpm_[A-Za-z0-9]{36}\b/, group_random: false),
  Pattern.new(regex: /\b(?:eyJ[A-Za-z0-9_\-]{8,})\.(?:eyJ[A-Za-z0-9_\-]{8,})\.[A-Za-z0-9_\-]{16,}\b/, group_random: false),
  Pattern.new(regex: /-----BEGIN [A-Z ]*PRIVATE KEY-----/, group_random: false)
].freeze

def entropy(str)
  return 0.0 if str.empty?

  counts = Hash.new(0)
  str.each_char { |ch| counts[ch] += 1 }
  counts.values.sum do |count|
    p = count.to_f / str.length
    -p * Math.log2(p)
  end
end

def random_enough?(str)
  return false if str.length < 20

  classes = 0
  classes += 1 if str.match?(/[a-z]/)
  classes += 1 if str.match?(/[A-Z]/)
  classes += 1 if str.match?(/[0-9]/)
  classes += 1 if str.match?(/[^A-Za-z0-9]/)
  entropy(str) >= 4.0 && classes >= 3
end

def normalize_path(path)
  path = path.to_s
  path.start_with?("./") ? path : "./#{path}"
end

def read_ignore_file
  path_patterns = []
  secrets = []
  section = :paths
  return [path_patterns, secrets] unless File.file?(".secretsignore")

  File.readlines(".secretsignore", chomp: true).each do |line|
    s = line.strip
    next if s.empty? || s.start_with?("#")

    if s == "[secrets]"
      section = :secrets
      next
    elsif s.start_with?("[") && s.end_with?("]")
      section = :paths
      next
    end

    if section == :secrets
      secrets << s
    else
      path_patterns << s
    end
  end
  [path_patterns, secrets]
end

def glob_to_regex(pattern)
  anchored = pattern.start_with?("/")
  dir_only = pattern.end_with?("/")
  pat = pattern.sub(%r{\A/}, "").sub(%r{/\z}, "")
  pat = Regexp.escape(pat).gsub("\\*\\*", ".*").gsub("\\*", "[^/]*").gsub("\\?", "[^/]")
  body =
    if pattern.include?("/")
      "\\A#{pat}"
    else
      "(?:\\A|/)#{pat}"
    end
  body = "\\A#{pat}" if anchored
  body += dir_only ? "(?:/|\\z)" : "(?:\\z|/.*\\z)"
  Regexp.new(body)
end

def ignored_path?(path, patterns)
  rel = path.sub(%r{\A\./}, "")
  patterns.any? { |pat| rel.match?(glob_to_regex(pat)) }
end

def install_pre_commit
  unless Dir.exist?(".git")
    warn "Error: .git directory not found"
    exit 2
  end

  hooks = File.join(".git", "hooks")
  Dir.mkdir(hooks) unless Dir.exist?(hooks)
  hook = File.join(hooks, "pre-commit")
  File.write(hook, "ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n")
  File.chmod(0o744, hook)
  exit 0
end

def parse_args(argv)
  opts = { strict: false, only: false, install: false, additional: [], sources: [] }
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when "-h"
      puts HELP_SHORT
      exit 0
    when "--help"
      puts HELP_LONG
      exit 0
    when "-V", "--version"
      puts "ripsecrets #{VERSION}"
      exit 0
    when "--install-pre-commit"
      opts[:install] = true
    when "--strict-ignore"
      opts[:strict] = true
    when "--only-matching"
      opts[:only] = true
    when "--additional-pattern"
      i += 1
      if i >= argv.length
        warn "error: a value is required for '--additional-pattern <ADDITIONAL_PATTERNS>' but none was supplied"
        exit 2
      end
      opts[:additional] << argv[i]
    when /\A--additional-pattern=(.*)\z/
      opts[:additional] << Regexp.last_match(1)
    else
      if arg.start_with?("-")
        warn "error: unexpected argument '#{arg}' found"
        exit 2
      end
      opts[:sources] << arg
    end
    i += 1
  end
  opts[:sources] = ["."] if opts[:sources].empty?
  opts
end

def enumerate_files(sources, ignore_patterns, strict)
  files = []
  explicit = sources.length > 0
  sources.each do |source|
    unless File.exist?(source)
      warn "#{source}: No such file or directory (os error 2)"
      next
    end

    if File.file?(source)
      next if strict && ignored_path?(source, ignore_patterns)
      files << source
      next
    end

    if File.directory?(source)
      root = source
      stack = [root]
      until stack.empty?
        dir = stack.pop
        entries = Dir.children(dir).sort
        entries.reverse_each do |entry|
          path = File.join(dir, entry)
          rel_for_ignore = path
          next if entry == ".git"
          next if ignored_path?(rel_for_ignore, ignore_patterns)

          if File.directory?(path)
            stack << path
          elsif File.file?(path)
            files << path
          end
        end
      end
    end
  end
  files
end

def compile_additional(patterns)
  patterns.map do |source|
    begin
      Pattern.new(regex: Regexp.new(source), group_random: true)
    rescue RegexpError => e
      warn "Error parsing regex: #{e.message}"
      exit 2
    end
  end
end

def report_match(file, line_no, line, match, pattern, only, ignored_secrets, seen_outputs)
  captured = match.captures.compact.first
  value = if only
            captured || match[0]
          else
            line
          end
  tested_secret = captured || match[0]
  return false if ignored_secrets.include?(tested_secret)

  output = "#{file}:#{line_no}:#{value}"
  return false if seen_outputs[output]

  seen_outputs[output] = true
  puts output
  true
end

def scan_file(file, patterns, only, ignored_secrets)
  found = false
  seen_outputs = {}
  File.open(file, "rb") do |fh|
    fh.each_line.with_index(1) do |raw, line_no|
      next if raw.include?("\x00")

      line = raw.encode("UTF-8", invalid: :replace, undef: :replace).chomp
      line_reported = false
      patterns.each do |pattern|
        break if line_reported && !only

        line.to_enum(:scan, pattern.regex).each do
          match = Regexp.last_match
          if pattern.group_random && match.captures.compact.any?
            secret = match.captures.compact.first
            next unless random_enough?(secret)
          end
          if report_match(file, line_no, line, match, pattern, only, ignored_secrets, seen_outputs)
            found = true
            line_reported = true
            break unless only
          end
        end
      end
    end
  end
  found
rescue Errno::EACCES => e
  warn "#{file}: #{e.message}"
  false
end

opts = parse_args(ARGV)
install_pre_commit if opts[:install]

ignore_patterns, ignored_secrets = read_ignore_file
patterns = DEFAULT_PATTERNS + compile_additional(opts[:additional])
files = enumerate_files(opts[:sources], ignore_patterns, opts[:strict])
found = false
files.each do |file|
  found = true if scan_file(file, patterns, opts[:only], ignored_secrets)
end

exit(found ? 1 : 0)
