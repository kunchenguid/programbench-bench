#!/usr/bin/env ruby

VERSION = "DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8"
PLUGIN_PATH = File.expand_path("~/.DataSurgeon/plugins.json")

HELP = <<~TXT
  Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.

  Usage: executable [OPTIONS]

  Options:
    -f, --file <file>            File to extract information from [default: ""]
        --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
        --update <update>        Updates a plugin from a GitHub repository. You can also use `ds --update all` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: ""]
        --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
        --list                   List all added plugins
    -C, --clean                  Only displays the matched result, rather than the entire line
        --directory <directory>  Process all files found in the specified directory [default: ""]
        --ignore                 Silences error messages
    -l, --line                   Displays the line number where the match occurred
    -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line
    -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)
    -S, --suppress               Suppress the 'Reading standard input' message when not providing a file
        --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop "^.{1,10}$" will hide all matches not under 10 characters) [default: ""]
        --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: ""]
    -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.
    -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: ""]
    -t, --time                   Time how long the operation took
    -e, --email                  Extract email addresses
    -p, --phone                  Extracts phone numbers
    -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)
    -i, --ip-addr                Extract IP addresses
    -6, --ipv6-addr              Extract IPv6 addresses
    -m, --mac-addr               Extract MAC addresses
    -c, --credit-card            Extract credit card numbers
    -u, --url                    Extract urls
    -F, --files                  Extract filenames
    -b, --bitcoin                Extract bitcoin wallets
    -a, --aws                    Extract AWS keys
    -g, --google                 Extract Google service account private key ids (used for google automations services)
    -d, --dns                    Extract Domain Name System records
    -s, --social                 Extract social security numbers
    -h, --help                   Print help
    -V, --version                Print version
TXT

Extractor = Struct.new(:flag, :name, :regex)

EXTRACTORS = [
  Extractor.new(:email, "email", /[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/),
  Extractor.new(:phone, "phone_number", /\b\d{3}-\d{3}-\d{4}\b/),
  Extractor.new(:hash, "hashes", /\b[0-9a-fA-F]{16,128}\b/),
  Extractor.new(:mac, "mac_address", /\b[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}\b/),
  Extractor.new(:ip, "ip_address", /\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/),
  Extractor.new(:ipv6, "ipv6_address", /\b[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}\b/),
  Extractor.new(:credit, "credit_card", /\b(?:\d[ -]?){13,19}\b/),
  Extractor.new(:url, "url", %r{\bhttps?://[^\s<>"']+}),
  Extractor.new(:files, "files", /(?:^|\s)[^\s]{0,64}\.(?:txt|pdf|doc|xls|csv|zip|tar|gz|jpg|png|gif|exe|dll|log|conf|ini|yml|html|php|js|css|py|rb|go|rs|cpp)/i),
  Extractor.new(:bitcoin, "bitcoin_wallet", /\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b/),
  Extractor.new(:aws, "aws", /(?!)/),
  Extractor.new(:google, "google", /(?!)/),
  Extractor.new(:dns, "dns", /(?!)/),
  Extractor.new(:social, "social_security", /\b\d{3}-\d{2}-\d{4}\b/)
]

SHORT_FLAGS = {
  "C" => :clean, "l" => :line, "T" => :thorough, "D" => :display,
  "S" => :suppress, "X" => :hide, "t" => :time,
  "e" => :email, "p" => :phone, "H" => :hash, "i" => :ip, "6" => :ipv6,
  "m" => :mac, "c" => :credit, "u" => :url, "F" => :files, "b" => :bitcoin,
  "a" => :aws, "g" => :google, "d" => :dns, "s" => :social
}

opts = Hash.new(false)
opts[:file] = ""
opts[:directory] = ""
opts[:output] = ""
opts[:drop] = ""
opts[:filter] = ""

def plugin_warning
  puts "Failed to open plugins.json file. PLUGIN_PATH: #{PLUGIN_PATH}" unless File.exist?(PLUGIN_PATH)
end

def need_value(args, i, opt)
  val = args[i + 1]
  if val.nil? || val.start_with?("-")
    plugin_warning
    puts "error: a value is required for '#{opt} <#{opt.sub(/^--/, "")}>' but none was supplied"
    exit 2
  end
  val
end

args = ARGV.dup
i = 0
while i < args.length
  arg = args[i]
  case arg
  when "-h", "--help"
    plugin_warning
    puts HELP
    exit 0
  when "-V", "--version"
    plugin_warning
    puts VERSION
    exit 0
  when "-f", "--file"
    opts[:file] = need_value(args, i, arg); i += 1
  when "--directory"
    opts[:directory] = need_value(args, i, arg); i += 1
  when "-o", "--output"
    opts[:output] = need_value(args, i, arg); i += 1
  when "--drop"
    opts[:drop] = need_value(args, i, arg); i += 1
  when "--filter"
    opts[:filter] = need_value(args, i, arg); i += 1
  when "--ignore"
    opts[:ignore] = true
  when "--list"
    plugin_warning
    puts "No plugins found. Plugin File: #{PLUGIN_PATH}"
    exit 0
  when "--add"
    val = need_value(args, i, arg); i += 1
    plugin_warning
    puts "[-] Error: Failed to parse plugins.json from the provided URL. Reason: builder error: relative URL without a base" unless val =~ %r{\Ahttps?://}
    exit 0
  when "--remove", "--update"
    need_value(args, i, arg); i += 1
    plugin_warning
    exit 0
  else
    if arg.start_with?("--")
      plugin_warning
      puts "error: unexpected argument '#{arg}' found"
      puts
      puts "Usage: executable [OPTIONS]"
      puts
      puts "For more information, try '--help'."
      exit 2
    elsif arg.start_with?("-") && arg.length > 1
      arg[1..].each_char do |ch|
        flag = SHORT_FLAGS[ch]
        if flag
          opts[flag] = true
        else
          plugin_warning
          puts "error: unexpected argument '-#{ch}' found"
          exit 2
        end
      end
    end
  end
  i += 1
end

plugin_warning
start_time = Time.now

selected_flags = EXTRACTORS.map(&:flag).select { |f| opts[f] }
selected_flags = EXTRACTORS.map(&:flag) if selected_flags.empty?
selected = EXTRACTORS.select { |ex| selected_flags.include?(ex.flag) }

drop_re = opts[:drop].empty? ? nil : Regexp.new(opts[:drop]) rescue nil
filter_re = opts[:filter].empty? ? nil : Regexp.new(opts[:filter]) rescue nil

rows = []

def clean_file_match(text)
  text
end

def emit_match(rows, opts, ex, match, line, line_no, filename)
  data = opts[:clean] ? match.to_s : line.chomp
  data = clean_file_match(data) if ex.flag == :files && opts[:clean]
  rows << [ex.name, data, line_no, filename]
end

def process_io(io, filename, selected, opts, drop_re, filter_re, rows)
  io.each_line.with_index(1) do |line, line_no|
    line_found = false
    selected.each do |ex|
      matches = []
      line.scan(ex.regex) do
        m = Regexp.last_match[0]
        if ex.flag == :files && m.start_with?(" ")
          previous = line[0...Regexp.last_match.begin(0)].split.last
          m = "#{previous}#{m}" if previous && !previous.include?(".")
        end
        matches << m
      end
      next if matches.empty?
      matches.each do |m|
        m = clean_file_match(m) if ex.flag == :files
        m = m.rstrip if ex.flag == :credit
        next if drop_re && m =~ drop_re
        next if filter_re && !(m =~ filter_re)
        emit_match(rows, opts, ex, m, line, line_no, filename)
        line_found = true
        break unless opts[:thorough]
      end
      break if line_found && !opts[:thorough]
    end
  end
end

if !opts[:directory].empty?
  unless Dir.exist?(opts[:directory])
    puts "[-] Directory not found: #{opts[:directory]}" unless opts[:ignore]
    exit 0
  end
  Dir.glob(File.join(opts[:directory], "**", "*")).sort.each do |path|
    next unless File.file?(path)
    begin
      File.open(path, "r") { |io| process_io(io, path, selected, opts, drop_re, filter_re, rows) }
    rescue
      puts "[-] Failed to read file: #{path}" unless opts[:ignore]
    end
  end
elsif !opts[:file].empty?
  if File.file?(opts[:file])
    File.open(opts[:file], "r") { |io| process_io(io, opts[:file], selected, opts, drop_re, filter_re, rows) }
  else
    puts "[-] File not found: #{opts[:file]}" unless opts[:ignore]
    exit 0
  end
else
  puts "[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)" unless opts[:suppress]
  process_io($stdin, nil, selected, opts, drop_re, filter_re, rows)
end

def formatted(row, opts)
  name, data, line_no, filename = row
  prefix = opts[:hide] ? "" : "#{name}: "
  if opts[:display] && filename
    s = opts[:hide] ? "file: #{filename} #{data}" : "#{name}, file: #{filename} #{data}"
  else
    s = "#{prefix}#{data}"
  end
  s += ", line: #{line_no}" if opts[:line]
  s
end

if !opts[:output].empty?
  File.open(opts[:output], "w") do |f|
    f.puts "content_type, data"
    rows.each { |row| f.puts "#{row[0]}, #{row[1]}" }
  end
else
  rows.each { |row| puts formatted(row, opts) }
end

puts "Time elapsed: #{Time.now - start_time}" if opts[:time]
