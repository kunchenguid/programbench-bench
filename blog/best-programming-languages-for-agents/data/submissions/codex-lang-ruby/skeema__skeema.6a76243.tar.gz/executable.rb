#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION_TEXT = "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z"
COMMANDS = %w[add-environment diff format help init lint pull push version].freeze
HELP_ALIASES = {
  nil => 'main',
  'add-environment' => 'add-environment',
  'diff' => 'diff',
  'format' => 'format',
  'help' => 'main',
  'init' => 'init',
  'lint' => 'lint',
  'pull' => 'pull',
  'push' => 'push',
  'version' => 'version'
}.freeze

OPTIONS_WITH_VALUES = %w[
  -o --connect-options -H --host-wrapper --ignore-func --ignore-proc --ignore-schema --ignore-table
  --ssl-mode -u --user -d --dir -h --host -P --port -S --socket --schema -x --alter-wrapper
  --alter-wrapper-min-size -X --ddl-wrapper --alter-algorithm --alter-lock --partitioning
  --allow-auto-inc --allow-charset --allow-compression --allow-definer --allow-engine --allow-pk-type
  --lint-auto-inc --lint-charset --lint-compression --lint-definer --lint-display-width
  --lint-dupe-index --lint-engine --lint-fk-parent --lint-has-enum --lint-has-fk --lint-has-float
  --lint-has-routine --lint-has-time --lint-name-case --lint-pk --lint-pk-type --lint-reserved-word
  --lint-zero-date --safe-below-size -c --concurrent-servers --docker-cleanup -t --temp-schema
  --temp-schema-binlog --temp-schema-mode --temp-schema-threads -w --workspace
].freeze

BOOLEAN_OPTIONS = %w[
  --debug --my-cnf --skip-my-cnf --include-auto-inc --strip-partitioning --format --skip-format
  --new-schemas --skip-new-schemas --update-partitioning --alter-validate-virtual --compare-metadata
  --exact-match --lax-column-order --lax-comments --lint --skip-lint --allow-unsafe --dry-run
  --foreign-key-checks --verify --skip-verify -1 --first-only -q --brief --write --skip-write
].freeze

OPTION_ALIASES = {
  '-?' => '--help',
  '-p' => '--password',
  '-o' => '--connect-options',
  '-H' => '--host-wrapper',
  '-u' => '--user',
  '-d' => '--dir',
  '-h' => '--host',
  '-P' => '--port',
  '-S' => '--socket',
  '-x' => '--alter-wrapper',
  '-X' => '--ddl-wrapper',
  '-c' => '--concurrent-servers',
  '-t' => '--temp-schema',
  '-w' => '--workspace'
}.freeze

def timestamp
  Time.now.utc.strftime('%Y-%m-%d %H:%M:%S')
end

def log(level, message)
  spacing = level.length == 4 ? '  ' : ' '
  warn "#{timestamp} [#{level}]#{spacing}#{message}"
end

def error(message, code = 78)
  log('ERROR', message)
  exit code
end

def help_text(topic = nil)
  key = HELP_ALIASES[topic] || 'main'
  path = File.join(__dir__, 'help', "#{key}.txt")
  File.read(path)
end

def print_help(topic = nil)
  print help_text(topic)
  exit 0
end

def option_name(token)
  OPTION_ALIASES.fetch(token, token.split('=', 2).first)
end

def parse_args(argv)
  opts = {}
  positionals = []
  i = 0
  while i < argv.length
    arg = argv[i]
    if arg == '--'
      positionals.concat(argv[(i + 1)..] || [])
      break
    elsif arg.start_with?('-') && arg != '-'
      name, inline = arg.split('=', 2)
      name = OPTION_ALIASES.fetch(name, name)
      if name == '--version'
        opts[:version] = true
      elsif name == '--help'
        opts[:help] = inline || true
      elsif name == '--password'
        opts[:password] = inline || (argv[i + 1]&.start_with?('-') ? true : argv[i + 1])
        i += 1 if inline.nil? && opts[:password] != true
      elsif OPTIONS_WITH_VALUES.include?(name)
        value = inline
        if value.nil?
          i += 1
          value = argv[i]
          error("CLI: Option \"#{name.sub(/\A--?/, '')}\" requires a value") if value.nil?
        end
        opts[name] = value
      elsif BOOLEAN_OPTIONS.include?(name)
        opts[name] = inline.nil? ? true : inline
      else
        error("CLI: Unknown option \"#{name.sub(/\A--?/, '')}\"")
      end
    else
      positionals << arg
    end
    i += 1
  end
  [opts, positionals]
end

def read_config_file(path)
  data = {}
  current = nil
  return data unless File.file?(path)

  File.readlines(path, chomp: true).each do |line|
    stripped = line.strip
    next if stripped.empty? || stripped.start_with?('#', ';')

    if stripped =~ /\A\[([^\]]+)\]\z/
      current = Regexp.last_match(1)
      data[current] ||= {}
    elsif stripped.include?('=')
      key, value = stripped.split('=', 2).map(&:strip)
      target = current ? (data[current] ||= {}) : (data[nil] ||= {})
      target[key] = value
    end
  end
  data
end

def find_nearest_config(dir)
  cur = File.expand_path(dir)
  loop do
    candidate = File.join(cur, '.skeema')
    return candidate if File.file?(candidate)
    parent = File.dirname(cur)
    return nil if parent == cur
    cur = parent
  end
end

def config_for_dir(dir, env_name = 'production')
  cfg = find_nearest_config(dir)
  merged = {}
  if cfg
    parsed = read_config_file(cfg)
    merged.merge!(parsed[nil] || {})
    merged.merge!(parsed[env_name] || {})
  end
  merged
end

def sql_dirs(base = Dir.pwd)
  dirs = []
  FindLike.each_dir(base) do |dir|
    next if File.basename(dir) == '.git'
    begin
      has_sql = Dir.children(dir).any? { |child| child.end_with?('.sql') && File.file?(File.join(dir, child)) }
      dirs << File.expand_path(dir) if has_sql
    rescue Errno::EACCES
      next
    end
  end
  dirs
end

module FindLike
  def self.each_dir(base, &block)
    stack = [File.expand_path(base)]
    until stack.empty?
      dir = stack.shift
      yield dir
      begin
        Dir.children(dir).sort.each do |child|
          path = File.join(dir, child)
          next unless File.directory?(path)
          next if child.start_with?('.') && child != '.'
          stack << path
        end
      rescue Errno::ENOENT, Errno::EACCES
      end
    end
  end
end

def connection_error(host, port, socket, dir)
  if host.nil? || host.empty?
    "Option host must be supplied in #{find_nearest_config(dir) || File.join(Dir.pwd, '.skeema')}"
  elsif host == 'localhost'
    sock = socket || '/tmp/mysql.sock'
    "Unable to connect to localhost:#{sock} for #{dir}: dial unix #{sock}: connect: no such file or directory"
  elsif host == '127.0.0.1' || host == '::1'
    p = port || '3306'
    "Unable to connect to #{host}:#{p} for #{dir}: dial tcp #{host}:#{p}: connect: connection refused"
  else
    p = port || '3306'
    "Unable to connect to #{host}:#{p} for #{dir}: dial tcp: lookup #{host} on 192.168.65.7:53: dial udp 192.168.65.7:53: connect: network is unreachable"
  end
end

def cmd_add_environment(opts, args)
  error('Too few positional args supplied on command line; command add-environment requires at least 1 args') if args.empty?
  error("Extra command-line arg \"#{args[1]}\" supplied; command add-environment takes a max of 1 args") if args.length > 1

  env_name = args[0]
  dir = File.expand_path(opts['--dir'] || '.')
  skeema = File.join(dir, '.skeema')
  unless File.file?(skeema)
    error("Dir #{dir} does not have an existing .skeema file! Can only use `skeema add-environment` on a dir previously created by `skeema init`")
  end
  host = opts['--host']
  error('`skeema add-environment` requires --host to be supplied on command-line') if host.nil? || host.empty?

  port = opts['--port'] || '3306'
  socket = opts['--socket'] || '/tmp/mysql.sock'
  content = File.read(skeema)
  if content =~ /^\[#{Regexp.escape(env_name)}\]\s*$/i
    error("Environment #{env_name} already exists in #{skeema}")
  end

  addition = +""
  addition << "\n" unless content.end_with?("\n")
  addition << "\n" unless content.end_with?("\n\n")
  addition << "[#{env_name}]\n"
  addition << "host=#{host}\n"
  if host == 'localhost'
    addition << "socket=#{socket}\n"
  else
    addition << "port=#{port}\n"
  end
  File.open(skeema, 'a') { |f| f.write(addition) }
  log('WARN', "Unable to automatically determine database server's vendor/version. To set manually, use the \"flavor\" option in #{skeema}")
  log('INFO', "Added environment [#{env_name}] to #{skeema}")
end

def cmd_init(opts, args)
  error("Extra command-line arg \"#{args[1]}\" supplied; command init takes a max of 1 args") if args.length > 1
  host = opts['--host']
  error('Option --host must be supplied on the command-line') if host.nil? || host.empty?
  dir = File.expand_path(opts['--dir'] || host)
  msg = connection_error(host, opts['--port'], opts['--socket'], dir)
  error(msg, 2)
end

def cmd_format(opts, args)
  env_name = args.first || 'production'
  write = opts.key?('--skip-write') ? false : true
  verb = write ? 'Reformatting' : 'Checking format of'
  base = File.expand_path('.')
  log('INFO', "#{verb} #{base}")
  failures = 0
  sql_dirs(base).each do |dir|
    log('INFO', "#{verb} #{dir}") unless dir == base
    cfg = config_for_dir(dir, env_name)
    msg = connection_error(cfg['host'], cfg['port'], cfg['socket'], dir)
    log('ERROR', "Skipping #{dir}: #{msg}")
    failures += 1
  end
  exit(failures.positive? ? 78 : 0)
end

def cmd_lint(opts, args)
  env_name = args.first || 'production'
  base = File.expand_path('.')
  log('INFO', "Linting #{base}")
  failures = 0
  sql_dirs(base).each do |dir|
    log('INFO', "Linting #{dir}") unless dir == base
    cfg = config_for_dir(dir, env_name)
    msg = connection_error(cfg['host'], cfg['port'], cfg['socket'], dir)
    rel = dir.sub(%r{\A#{Regexp.escape(File.dirname(base))}/?}, '')
    log('ERROR', "Skipping directory #{rel} due to error: #{msg}")
    failures += 1
  end
  log('ERROR', "Skipped #{failures} operation due to fatal errors") if failures == 1
  log('ERROR', "Skipped #{failures} operations due to fatal errors") if failures > 1
  exit(failures.positive? ? 78 : 0)
end

def validate_common!(cmd, opts, args)
  max = %w[diff pull push lint format].include?(cmd) ? 1 : 0
  if args.length > max
    error("Extra command-line arg \"#{args[max]}\" supplied; command #{cmd} takes a max of #{max} args")
  end
  if opts['--concurrent-servers'] && opts['--concurrent-servers'].to_i < 1
    error('concurrent-instances cannot be less than 1')
  end
end

opts, args = parse_args(ARGV)
print_help(opts[:help].is_a?(String) ? opts[:help] : nil) if opts[:help] && args.empty?
if opts[:version]
  puts VERSION_TEXT
  exit 0
end

cmd = args.shift
if cmd.nil?
  print_help
elsif cmd == 'help'
  topic = args.shift
  error("Unknown command \"#{topic}\"", 2) if topic && !COMMANDS.include?(topic)
  print_help(topic)
elsif !COMMANDS.include?(cmd)
  error("Unknown command \"#{cmd}\"")
elsif opts[:help]
  print_help(opts[:help].is_a?(String) ? opts[:help] : cmd)
end

case cmd
when 'version'
  validate_common!(cmd, opts, args)
  puts VERSION_TEXT
when 'add-environment'
  cmd_add_environment(opts, args)
when 'init'
  cmd_init(opts, args)
when 'format'
  validate_common!(cmd, opts, args)
  cmd_format(opts, args)
when 'lint'
  validate_common!(cmd, opts, args)
  cmd_lint(opts, args)
when 'pull'
  validate_common!(cmd, opts, args)
  env_name = args.first || 'production'
  failures = 0
  sql_dirs(File.expand_path('.')).each do |dir|
    cfg = config_for_dir(dir, env_name)
    msg = connection_error(cfg['host'], cfg['port'], cfg['socket'], dir)
    log('WARN', "Skipping #{dir}: #{msg}")
    failures += 1
  end
  exit(failures.positive? ? 1 : 0)
when 'diff', 'push'
  validate_common!(cmd, opts, args)
  exit 0
end
