#!/usr/bin/env ruby
# frozen_string_literal: true

module MiniShellharden
  RESET = "\e[m"
  GREEN_BG = "\e[0;42m"
  CMD = "\e[0;38;2;192;0;128m"
  VAR = "\e[0;38;2;63;127;207m"
  KEY = "\e[0;1m"
  COMMENT = "\e[0;1;3;38;2;120;144;96m"

  module_function

  def help
    <<~TXT
      Shellharden: The corrective bash syntax highlighter.

      Usage:
      	shellharden [options] [files]
      	cat files | shellharden [options] ''

      Shellharden is a syntax highlighter and a tool to semi-automate the rewriting
      of scripts to ShellCheck conformance, mainly focused on quoting.

      Options:
      	--suggest         Output a colored diff suggesting changes.
      	--syntax          Output syntax highlighting with ANSI colors.
      	--syntax-suggest  Diff with syntax highlighting (default mode).
      	--transform       Output suggested changes.
      	--check           No output; exit with 2 if changes are suggested.
      	--replace         Replace file contents with suggested changes.
      	--                Don't treat further arguments as options.
      	-h|--help         Show help text.
      	--version         Show version.
    TXT
  end

  def split_words(line)
    out = []
    i = 0
    while i < line.length
      c = line[i]
      if c == '#'
        out << [:comment, line[i..]]
        break
      elsif c =~ /\s/
        j = i + 1
        j += 1 while j < line.length && line[j] =~ /\s/
        out << [:sep, line[i...j]]
        i = j
      elsif [';', '|', '&'].include?(c)
        if i + 1 < line.length && ['&&', '||', ';;', ';&'].include?(line[i, 2])
          out << [:op, line[i, 2]]; i += 2
        else
          out << [:op, c]; i += 1
        end
      else
        j = i
        sq = dq = false
        par = 0
        br = 0
        bt = false
        while j < line.length
          ch = line[j]
          if bt
            bt = false if ch == '`'
            j += 1; next
          end
          if sq
            sq = false if ch == "'"
            j += 1; next
          end
          if dq
            if ch == '\\'
              j += 2; next
            elsif ch == '"'
              dq = false; j += 1; next
            elsif ch == '$' && line[j + 1] == '('
              par += 1; j += 2; next
            elsif ch == ')' && par > 0
              par -= 1; j += 1; next
            end
            j += 1; next
          end
          if ch == "'"
            sq = true; j += 1
          elsif ch == '"'
            dq = true; j += 1
          elsif ch == '`'
            bt = true; j += 1
          elsif ch == '$' && line[j + 1] == '('
            par += 1; j += 2
          elsif ch == ')' && par > 0
            par -= 1; j += 1
          elsif ch == '$' && line[j + 1] == '{'
            br += 1; j += 2
          elsif ch == '}' && br > 0
            br -= 1; j += 1
          elsif par == 0 && br == 0 && (ch =~ /\s/ || [';', '|', '&', '#'].include?(ch))
            break
          else
            j += 1
          end
        end
        out << [:word, line[i...j]]
        i = j
      end
    end
    out
  end

  def find_matching(s, open_pos, open_ch, close_ch)
    depth = 1
    i = open_pos + 1
    sq = dq = false
    while i < s.length
      ch = s[i]
      if sq
        sq = false if ch == "'"; i += 1; next
      end
      if dq
        if ch == '\\'
          i += 2; next
        elsif ch == '"'
          dq = false; i += 1; next
        end
      else
        if ch == "'"
          sq = true; i += 1; next
        elsif ch == '"'
          dq = true; i += 1; next
        end
      end
      if ch == open_ch
        depth += 1
      elsif ch == close_ch
        depth -= 1
        return i if depth == 0
      end
      i += 1
    end
    nil
  end

  def transform_script(text)
    text.lines.map { |ln| transform_line(ln.chomp) + (ln.end_with?("\n") ? "\n" : "") }.join
  end

  def transform_line(line)
    parts = split_words(line)
    in_db = false
    in_arith = false
    in_case_head = false
    in_case_pattern = false
    cmd_pos = true
    first_word = nil
    parts.map do |type, val|
      case type
      when :word
        raw = val
        if raw == '[[ '
          raw
        end
        if raw == '[['
          in_db = true; cmd_pos = false; first_word ||= raw; raw
        elsif raw == ']]'
          in_db = false; raw
        elsif in_db
          raw
        elsif raw.start_with?('((')
          in_arith = true
          in_arith = false if raw.end_with?('))')
          raw
        elsif in_arith
          in_arith = false if raw.end_with?('))')
          raw
        elsif in_case_head
          if raw == 'in'
            in_case_head = false
            in_case_pattern = true
            raw
          else
            raw
          end
        elsif in_case_pattern
          in_case_pattern = false if raw.end_with?(')')
          raw
        else
          context = context_for(raw, cmd_pos, first_word)
          newv = transform_word(raw, context)
          if raw == 'case'
            in_case_head = true
          end
          first_word ||= raw unless raw =~ /\A\w+=/
          cmd_pos = %w[then do else elif].include?(raw)
          newv
        end
      when :op
        cmd_pos = true
        first_word = nil if [';', '&&', '||', '|'].include?(val)
        in_case_pattern = true if val == ';;'
        val
      when :comment
        val
      else
        val
      end
    end.join
  end

  def context_for(word, cmd_pos, first_word)
    return :assignment if word =~ /\A[A-Za-z_][A-Za-z0-9_]*[+]?=/ && (cmd_pos || %w[export declare local readonly typeset].include?(first_word))
    return :array_assignment if word =~ /\A[A-Za-z_][A-Za-z0-9_]*=\(.*\)\z/m
    :normal
  end

  def transform_word(word, context = :normal)
    if word =~ /\A([A-Za-z_][A-Za-z0-9_]*=\()(.*)\z/m
      return Regexp.last_match(1) + transform_inner(Regexp.last_match(2), quote_expansions: true)
    end
    if context == :array_assignment && (m = word.match(/\A([^=]+=)\((.*)\)\z/m))
      return m[1] + '(' + split_words(m[2]).map { |t, v| t == :word ? transform_word(v, :normal) : v }.join + ')'
    end
    prefix = ''
    body = word
    if context == :assignment && (m = word.match(/\A([^=]+=)(.*)\z/m))
      prefix = m[1]
      body = m[2]
      return prefix + transform_inner(body, quote_expansions: false)
    end
    prefix + transform_inner(body, quote_expansions: true)
  end

  def transform_inner(s, quote_expansions: true)
    out = +' '
    out.clear
    i = 0
    while i < s.length
      ch = s[i]
      if ch == "'"
        j = s.index("'", i + 1) || s.length - 1
        out << s[i..j]
        i = j + 1
      elsif ch == '"'
        j = i + 1
        buf = +'"'
        while j < s.length
          if s[j] == '\\'
            buf << s[j, 2]; j += 2
          elsif s[j] == '"'
            buf << '"'; j += 1; break
          elsif s[j] == '$' && s[j + 1] == '('
            k = find_matching(s, j + 1, '(', ')')
            if k
              inside = s[(j + 2)...k]
              buf << '$(%s)' % transform_script(inside)
              j = k + 1
            else
              buf << s[j]; j += 1
            end
          else
            buf << s[j]; j += 1
          end
        end
        out << buf
        i = j
      elsif ch == '$' && s[i + 1] == '('
        k = find_matching(s, i + 1, '(', ')')
        if k
          inside = transform_script(s[(i + 2)...k])
          subst = "$(#{inside})"
          out << (quote_expansions ? quote(subst) : subst)
          i = k + 1
        else
          out << ch; i += 1
        end
      elsif ch == '`'
        k = s.index('`', i + 1)
        if k
          inside = transform_script(s[(i + 1)...k])
          subst = "$(#{inside})"
          out << (quote_expansions ? quote(subst) : "`#{inside}`")
          i = k + 1
        else
          out << ch; i += 1
        end
      elsif ch == '$'
        var, len = read_var(s, i)
        if var
          if safe_unquoted_var?(var) || !quote_expansions
            out << var
          else
            out << quote(var)
          end
          i += len
        else
          out << ch; i += 1
        end
      else
        out << ch; i += 1
      end
    end
    out
  end

  def quote(x)
    %Q{"#{x}"}
  end

  def read_var(s, i)
    return nil unless s[i] == '$'
    n = s.length
    if i + 1 < n && s[i + 1] == '{'
      k = find_matching(s, i + 1, '{', '}')
      return [s[i..k], k - i + 1] if k
    elsif i + 1 < n && s[i + 1] =~ /[A-Za-z_]/
      j = i + 2
      j += 1 while j < n && s[j] =~ /[A-Za-z0-9_]/
      return [s[i...j], j - i]
    elsif i + 1 < n && s[i + 1] =~ /[0-9@*?#$!\-]/
      return [s[i, 2], 2]
    end
    nil
  end

  def safe_unquoted_var?(v)
    return true if %w[$? $$ $! $#].include?(v)
    return true if v =~ /\A\$\{#.+\}\z/
    false
  end

  def suggest_script(text)
    old = text
    new = transform_script(text)
    return old if old == new
    res = +''
    oi = ni = 0
    while oi < old.length && ni < new.length
      if old[oi] == new[ni]
        res << old[oi]; oi += 1; ni += 1
      else
        if new[ni] == '"' && old[oi] == '$'
          res << GREEN_BG << '"' << RESET
          ni += 1
        elsif old[oi] == '$' && new[ni] == '$'
          res << old[oi]; oi += 1; ni += 1
        elsif new[ni] == '"'
          res << GREEN_BG << '"' << RESET
          ni += 1
        else
          res << new[ni]; ni += 1; oi += 1 if oi < old.length && old[oi] != new[ni]
        end
      end
    end
    res << new[ni..].to_s
    res
  end

  def syntax_script(text, suggest: false)
    base = suggest ? suggest_script(text) : text
    base.lines.map do |line|
      if line.lstrip.start_with?('#')
        COMMENT + line.chomp + RESET + (line.end_with?("\n") ? "\n" : "")
      else
        line.gsub(/\b(if|then|else|elif|fi|for|in|do|done|case|esac|while|until)\b/, KEY + '\\1' + RESET)
            .gsub(/\$\{?[A-Za-z_@*0-9?#$!\-][A-Za-z0-9_]*\}?/, VAR + '\\0' + RESET)
      end
    end.join
  end

  def run(argv)
    mode = :syntax_suggest
    files = []
    parse_opts = true
    argv.each do |a|
      if parse_opts && a == '--'
        parse_opts = false
      elsif parse_opts && a.start_with?('-') && a != ''
        case a
        when '-h', '--help' then print help; return 0
        when '--version' then puts '4.3.1'; return 0
        when '--suggest' then mode = :suggest
        when '--syntax' then mode = :syntax
        when '--syntax-suggest' then mode = :syntax_suggest
        when '--transform' then mode = :transform
        when '--check' then mode = :check
        when '--replace' then mode = :replace
        else
          warn "#{a}: No such option."
          return 3
        end
      else
        files << a
      end
    end
    files = [''] if files.empty?
    changed = false
    outputs = []
    files.each do |f|
      text = f == '' ? STDIN.read : File.read(f)
      transformed = transform_script(text)
      changed ||= text != transformed
      case mode
      when :transform then outputs << transformed
      when :suggest then outputs << suggest_script(text)
      when :syntax then outputs << syntax_script(text)
      when :syntax_suggest then outputs << syntax_script(text, suggest: true)
      when :replace
        File.write(f, transformed) unless f == ''
      when :check
      end
    end
    print outputs.join
    return 2 if mode == :check && changed
    0
  rescue Errno::ENOENT => e
    warn e.message
    1
  end
end

exit MiniShellharden.run(ARGV)
