#!/usr/bin/env ruby
require "net/http"
require "uri"
require "cgi"

HELP = File.read(File.expand_path("help.txt", __dir__)) rescue "Fast directory scanning and scraping tool\n\nUsage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>\n"
VERSION = "Dirble 1.4.2 (commit d520c82, build 2026-04-17)"

class Scanner
  Result = Struct.new(:url, :code, :size, :is_directory, :is_listable, :redirect_url, :found_from_listable, keyword_init: true)
  attr_reader :opts
  def initialize(opts); @opts = opts; end

  def normalize_uri(s)
    u = URI.parse(s)
    raise URI::InvalidURIError, "relative URL without a base" unless u.scheme && u.host
    str = u.to_s
    str.end_with?("/") ? str : str + "/"
  end

  def join_url(base, path)
    URI.join(base.end_with?("/") ? base : base + "/", path.gsub(/^\/+/, "")).to_s
  end

  def request(url)
    uri = URI.parse(url)
    klass = {"head" => Net::HTTP::Head, "post" => Net::HTTP::Post}.fetch(opts[:verb], Net::HTTP::Get)
    req = klass.new(uri)
    opts[:headers].each { |k, v| req[k] = v }
    req["User-Agent"] = opts[:user_agent] if opts[:user_agent]
    req["Cookie"] = opts[:cookies].join("; ") unless opts[:cookies].empty?
    if opts[:username] || opts[:password] || uri.user
      req.basic_auth(opts[:username] || CGI.unescape(uri.user || ""), opts[:password] || CGI.unescape(uri.password || ""))
    end
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = uri.scheme == "https"
    http.open_timeout = opts[:timeout]
    http.read_timeout = opts[:timeout]
    res = http.request(req)
    body = res.body || ""
    loc = res["location"] || ""
    Result.new(url: url, code: res.code.to_i, size: body.bytesize, is_directory: directory_response?(url, res.code.to_i, loc), is_listable: listable?(body), redirect_url: loc, found_from_listable: false)
  rescue => e
    warn "Curl error after requesting #{url} : #{e.message}" if opts[:verbose] > 0
    nil
  end

  def directory_response?(url, code, loc)
    ([301, 302, 303, 307, 308].include?(code) && loc.to_s.end_with?("/")) || url.end_with?("/")
  end

  def listable?(body)
    b = body.to_s.downcase
    b.include?("index of /") || b.include?("directory listing")
  end

  def validate(base)
    return [] if opts[:disable_validator] || opts[:whitelist]
    codes = []
    alpha = ("a".."z").to_a + ("A".."Z").to_a + ("0".."9").to_a
    3.times do |i|
      token = Array.new(10 + i * 5) { alpha.sample }.join
      r = request(join_url(base, token))
      codes << r.code if r
    end
    nf = codes.tally.select { |_code, count| count >= 2 }.keys
    puts "[INFO] Detected nonexistent paths for #{base} are #{nf.map { |c| "(CODE:#{c})" }.join(", ")}" if !opts[:silent] && !nf.empty?
    nf
  end

  def hidden_length?(n)
    opts[:hide_lengths].any? { |a, b| n >= a && n <= b }
  end

  def visible?(r, not_found_codes)
    return false unless r
    return false if !opts[:show_htaccess] && r.url.include?(".ht") && r.code == 403
    return false if hidden_length?(r.size)
    return opts[:whitelist].include?(r.code) if opts[:whitelist]
    return false if opts[:blacklist].include?(r.code)
    return false if not_found_codes.include?(r.code)
    true
  end

  def marker(r)
    r.is_listable ? "L" : (r.is_directory ? "D" : "+")
  end

  def line(r)
    redir = r.redirect_url && !r.redirect_url.empty? ? "|REDIRECT:#{r.redirect_url}" : ""
    "#{marker(r)} #{r.url} (CODE:#{r.code}|SIZE:#{r.size}#{redir})"
  end

  def run
    all = []
    bases = opts[:uris].map { |u| normalize_uri(u) }
    words = File.readlines(opts[:wordlist], chomp: true).map(&:strip).reject { |w| w.empty? || w.start_with?("#") }.sort
    bases.each do |base|
      nf = validate(base)
      query_words = []
      opts[:prefixes].each { |p| words.each { |w| query_words << p + w } }
      query_words = words if query_words.empty?
      variants = []
      variants << [nil, query_words] unless opts[:force_extension]
      opts[:extensions].each { |e| variants << [e, query_words] }
      variants.each do |ext, list|
        list.each do |word|
          path = opts[:ext_sub] && ext ? word.gsub("%EXT%", ext.sub(/^\./, "")) : word + (ext || "")
          r = request(join_url(base, path))
          next unless visible?(r, nf)
          all << r
          puts line(r) unless opts[:silent]
          sleep(opts[:throttle] / 1000.0) if opts[:throttle] > 0
        end
      end
    end
    all
  end
end

def parse_list(v)
  v.to_s.split(",").map(&:strip).reject(&:empty?)
end

def parse_codes(v)
  parse_list(v).map { |x| Integer(x) }
end

def parse_lengths(v)
  parse_list(v).map do |item|
    if item.include?("-")
      a, b = item.split("-", 2).map { |x| Integer(x) }
      [a, b]
    else
      n = Integer(item)
      [n, n]
    end
  end
end

def json_string(s)
  "\"" + s.to_s.gsub("\\", "\\\\").gsub("\"", "\\\"").gsub("\n", "\\n").gsub("\r", "\\r").gsub("\t", "\\t") + "\""
end

def json_result(r)
  "{\"url\":#{json_string(r.url)},\"code\":#{r.code},\"size\":#{r.size},\"is_directory\":#{r.is_directory},\"is_listable\":#{r.is_listable},\"redirect_url\":#{json_string(r.redirect_url || "")},\"found_from_listable\":#{r.found_from_listable}}"
end

def write_reports(outputs, opts, scanner, results)
  sorted = results.sort_by(&:url)
  if outputs[:txt]
    File.open(outputs[:txt], "w") do |f|
      opts[:uris].each { |u| f.puts "Dirble Scan Report for #{scanner.normalize_uri(u)}:" }
      sorted.each { |r| f.puts scanner.line(r) }
      f.puts
    end
  end
  if outputs[:json]
    ary = sorted.map { |r| json_result(r) }
    File.write(outputs[:json], "[" + ary.join(",\n") + "]")
  end
  if outputs[:xml]
    File.open(outputs[:xml], "w") do |f|
      f.puts %(<?xml version="1.0" encoding="UTF-8"?>)
      f.puts "<dirble_scan>"
      sorted.each do |r|
        f.puts %(<path url="#{CGI.escapeHTML(r.url)}" code="#{r.code}" content_len="#{r.size}" is_directory="#{r.is_directory}" is_listable="#{r.is_listable}" redirect_url="#{CGI.escapeHTML(r.redirect_url || "")}" found_from_listable="#{r.found_from_listable}"/>)
      end
      f.puts "</dirble_scan>"
    end
  end
end

opts = {uris: [], wordlist: File.join(File.dirname(File.expand_path($0)), "dirble_wordlist.txt"), verb: "get", extensions: [], prefixes: [], timeout: 5, headers: {}, cookies: [], blacklist: [], whitelist: nil, hide_lengths: [], silent: false, verbose: 0, throttle: 0, disable_validator: false, force_extension: false, ext_sub: false, show_htaccess: false, username: nil, password: nil, user_agent: nil}
outputs = {}
args = ARGV.dup
i = 0
begin
  while i < args.length
    a = args[i]
    case a
    when "-h", "--help"
      puts HELP
      exit 0
    when "-V", "--version"
      puts VERSION
      exit 0
    when "-u", "--uri", "--url"
      i += 1; opts[:uris] << args.fetch(i)
    when "-U", "--uri-file", "--url-file"
      i += 1; opts[:uris].concat(File.readlines(args.fetch(i), chomp: true).map(&:strip).reject(&:empty?))
    when "--verb"
      i += 1; raw = args.fetch(i); opts[:verb] = raw.downcase
      unless %w[get head post].include?(opts[:verb])
        warn "error: invalid value '#{raw}' for '--verb <http_verb>'\n  [possible values: get, head, post]\n\nFor more information, try '--help'."
        exit 2
      end
    when "-w", "--wordlist"
      i += 1; opts[:wordlist] = args.fetch(i)
    when "-x", "--extensions"
      i += 1; opts[:extensions].concat(parse_list(args.fetch(i)))
    when "-X", "--extension-file"
      i += 1; opts[:extensions].concat(File.readlines(args.fetch(i), chomp: true).map(&:strip).reject(&:empty?))
    when "-p", "--prefixes"
      i += 1; opts[:prefixes].concat(parse_list(args.fetch(i)))
    when "-P", "--prefix-file"
      i += 1; opts[:prefixes].concat(File.readlines(args.fetch(i), chomp: true).map(&:strip).reject(&:empty?))
    when "--ext-sub" then opts[:ext_sub] = true
    when "-f", "--force-extension" then opts[:force_extension] = true
    when "--timeout" then i += 1; opts[:timeout] = args.fetch(i).to_f
    when "--max-errors", "-t", "--max-threads", "-T", "--wordlist-split", "--max-recursion-depth" then i += 1
    when "-z", "--throttle" then i += 1; opts[:throttle] = args.fetch(i).to_i
    when "--json-file", "--oJ" then i += 1; outputs[:json] = args.fetch(i)
    when "-o", "--output-file", "--oN" then i += 1; outputs[:txt] = args.fetch(i)
    when "--xml-file", "--oX" then i += 1; outputs[:xml] = args.fetch(i)
    when "--output-all", "--oA" then i += 1; base = args.fetch(i); outputs[:txt] = base + ".txt"; outputs[:json] = base + ".json"; outputs[:xml] = base + ".xml"
    when "--hide-lengths" then i += 1; opts[:hide_lengths].concat(parse_lengths(args.fetch(i)))
    when "-B", "--code-blacklist" then i += 1; opts[:blacklist].concat(parse_codes(args.fetch(i)))
    when "-W", "--code-whitelist" then i += 1; opts[:whitelist] ||= []; opts[:whitelist].concat(parse_codes(args.fetch(i))); opts[:disable_validator] = true
    when "--disable-validator" then opts[:disable_validator] = true
    when "--no-color", "-k", "--ignore-cert", "--burp", "--no-proxy", "-l", "--scan-listable", "-r", "--disable-recursion", "--scrape-listable", "--scan-401", "--scan-403" then nil
    when "--show-htaccess" then opts[:show_htaccess] = true
    when "--proxy" then i += 1
    when "--username" then i += 1; opts[:username] = args.fetch(i)
    when "--password" then i += 1; opts[:password] = args.fetch(i)
    when "-a", "--user-agent" then i += 1; opts[:user_agent] = args.fetch(i)
    when "-c", "--cookie" then i += 1; opts[:cookies] << args.fetch(i)
    when "-H", "--header"
      i += 1; h = args.fetch(i); k, v = h.include?(":") ? h.split(":", 2) : [h.sub(/;$/, ""), ""]; opts[:headers][k] = v
    when "-S", "--silent" then opts[:silent] = true
    when /^-v+$/ then opts[:verbose] += a.count("v")
    else
      if a.start_with?("-")
        warn "error: unexpected argument '#{a}' found\n\nUsage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>\n\nFor more information, try '--help'."
        exit 2
      end
      opts[:uris] << a
    end
    i += 1
  end
  if opts[:uris].empty?
    puts HELP
    exit 2
  end
  opts[:extensions].map! { |e| e.start_with?(".") ? e : ".#{e}" }
  scanner = Scanner.new(opts)
  results = scanner.run
  write_reports(outputs, opts, scanner, results)
rescue URI::InvalidURIError => e
  warn "error: invalid value '#{opts[:uris].first}' for '[uri]': #{e.message}\n\nFor more information, try '--help'."
  exit 2
rescue Errno::ENOENT => e
  warn e.message
  exit 1
rescue ArgumentError => e
  warn e.message
  exit 1
end
