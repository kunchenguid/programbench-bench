#!/usr/bin/env ruby
# frozen_string_literal: true

require 'strscan'

class JQError < StandardError; end

module MiniJSON
  class Parser
    def initialize(s)
      @s = s
      @i = 0
    end

    def parse
      v = value
      ws
      raise JQError, 'unexpected trailing data' unless @i >= @s.length
      v
    end

    def ws
      @i += 1 while @i < @s.length && @s[@i] =~ /\s/
    end

    def value
      ws
      c = @s[@i]
      case c
      when '{' then object
      when '[' then array
      when '"' then string
      when 't' then literal('true', true)
      when 'f' then literal('false', false)
      when 'n' then literal('null', nil)
      else number
      end
    end

    def literal(word, val)
      raise JQError, "invalid JSON literal" unless @s[@i, word.length] == word
      @i += word.length
      val
    end

    def object
      @i += 1
      h = {}
      ws
      if @s[@i] == '}'
        @i += 1
        return h
      end
      loop do
        ws
        raise JQError, 'expected object key' unless @s[@i] == '"'
        k = string
        ws
        raise JQError, 'expected colon' unless @s[@i] == ':'
        @i += 1
        h[k] = value
        ws
        if @s[@i] == '}'
          @i += 1
          return h
        end
        raise JQError, 'expected comma' unless @s[@i] == ','
        @i += 1
      end
    end

    def array
      @i += 1
      a = []
      ws
      if @s[@i] == ']'
        @i += 1
        return a
      end
      loop do
        a << value
        ws
        if @s[@i] == ']'
          @i += 1
          return a
        end
        raise JQError, 'expected comma' unless @s[@i] == ','
        @i += 1
      end
    end

    def string
      raise JQError, 'expected string' unless @s[@i] == '"'
      @i += 1
      out = +''
      until @i >= @s.length
        c = @s[@i]
        @i += 1
        return out if c == '"'
        if c == '\\'
          esc = @s[@i]
          @i += 1
          case esc
          when '"', '\\', '/' then out << esc
          when 'b' then out << "\b"
          when 'f' then out << "\f"
          when 'n' then out << "\n"
          when 'r' then out << "\r"
          when 't' then out << "\t"
          when 'u'
            cp = @s[@i, 4].to_i(16)
            @i += 4
            if cp.between?(0xD800, 0xDBFF) && @s[@i, 2] == '\\u'
              @i += 2
              lo = @s[@i, 4].to_i(16)
              @i += 4
              cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00)
            end
            out << cp.chr(Encoding::UTF_8)
          else
            raise JQError, 'invalid string escape'
          end
        else
          out << c
        end
      end
      raise JQError, 'unterminated string'
    end

    def number
      m = @s[@i..].match(/\A-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/)
      raise JQError, 'invalid numeric literal' unless m
      raw = m[0]
      @i += raw.length
      raw =~ /[.eE]/ ? raw.to_f : raw.to_i
    end
  end

  module_function

  def parse(s) = Parser.new(s).parse

  def generate(v, ascii_only: false)
    case v
    when nil then 'null'
    when true then 'true'
    when false then 'false'
    when Numeric
      v.respond_to?(:nan?) && (v.nan? || v.infinite?) ? 'null' : v.to_s
    when String then quote(v, ascii_only)
    when Array then '[' + v.map { |x| generate(x, ascii_only: ascii_only) }.join(',') + ']'
    when Hash
      '{' + v.map { |k, x| quote(k.to_s, ascii_only) + ':' + generate(x, ascii_only: ascii_only) }.join(',') + '}'
    else quote(v.to_s, ascii_only)
    end
  end

  def quote(s, ascii_only = false)
    out = +'"'
    s.each_codepoint do |cp|
      case cp
      when 34 then out << '\"'
      when 92 then out << '\\\\'
      when 8 then out << '\b'
      when 12 then out << '\f'
      when 10 then out << '\n'
      when 13 then out << '\r'
      when 9 then out << '\t'
      else
        if cp < 0x20 || (ascii_only && cp > 0x7f)
          if cp <= 0xffff
            out << format('\\u%04x', cp)
          else
            cp -= 0x10000
            out << format('\\u%04x\\u%04x', 0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3ff))
          end
        else
          out << cp.chr(Encoding::UTF_8)
        end
      end
    end
    out << '"'
  end
end

Token = Struct.new(:type, :value)

class Lexer
  KEYWORDS = %w[if then else elif end as def reduce foreach try catch label break
                and or not true false null].freeze

  def initialize(src)
    @s = StringScanner.new(src)
  end

  def tokens
    out = []
    until @s.eos?
      @s.skip(/\s+/)
      break if @s.eos?
      if @s.scan(/#[^\n]*/)
        next
      elsif (m = @s.scan(/\/\/|\|\||&&|==|!=|<=|>=|\.\.|\?\/\/|\+=|-=|\*=|\/=|%=|[|,():{}\[\].?+\-*\/%<>;]/))
        out << Token.new(m, m)
      elsif (m = @s.scan(/\$[A-Za-z_][A-Za-z0-9_]*/))
        out << Token.new(:var, m[1..])
      elsif (m = @s.scan(/-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/))
        out << Token.new(:number, m =~ /[.eE]/ ? m.to_f : m.to_i)
      elsif (m = scan_string)
        out << Token.new(:string, m)
      elsif (m = @s.scan(/[A-Za-z_][A-Za-z0-9_]*/))
        out << Token.new(KEYWORDS.include?(m) ? m : :ident, m)
      else
        raise JQError, "unexpected character #{@s.peek(1).inspect}"
      end
    end
    out << Token.new(:eof, nil)
  end

  def scan_string
    return nil unless @s.peek(1) == '"'
    start = @s.pos
    @s.getch
    esc = false
    until @s.eos?
      c = @s.getch
      if esc
        esc = false
      elsif c == '\\'
        esc = true
      elsif c == '"'
        raw = @s.string[start...@s.pos]
        return MiniJSON.parse(raw)
      end
    end
    raise JQError, 'unterminated string'
  end
end

class Parser
  def initialize(src)
    @t = Lexer.new(src).tokens
    @i = 0
  end

  def parse
    expr = parse_comma
    expect(:eof)
    expr
  end

  def cur = @t[@i]
  def eat(type = nil)
    return nil if type && cur.type != type
    tok = cur
    @i += 1
    tok
  end
  def expect(type)
    tok = eat(type)
    raise JQError, "expected #{type}, got #{cur.type}" unless tok
    tok
  end

  def parse_comma
    left = parse_pipe
    while eat(',')
      right = parse_pipe
      left = [:comma, left, right]
    end
    left
  end

  def parse_pipe
    left = parse_logic
    if eat('as')
      var = expect(:var).value
      expect('|')
      return [:as, left, var, parse_pipe]
    end
    while eat('|')
      right = parse_logic
      left = [:pipe, left, right]
    end
    left
  end

  def parse_logic
    left = parse_cmp
    while %w[and or //].include?(cur.type)
      op = eat.type
      right = parse_cmp
      left = [:bin, op, left, right]
    end
    left
  end

  def parse_cmp
    left = parse_add
    while %w[== != < > <= >=].include?(cur.type)
      op = eat.type
      right = parse_add
      left = [:bin, op, left, right]
    end
    left
  end

  def parse_add
    left = parse_mul
    while %w[+ -].include?(cur.type)
      op = eat.type
      right = parse_mul
      left = [:bin, op, left, right]
    end
    left
  end

  def parse_mul
    left = parse_unary
    while %w[* / %].include?(cur.type)
      op = eat.type
      right = parse_unary
      left = [:bin, op, left, right]
    end
    left
  end

  def parse_unary
    return [:unary, '-', parse_unary] if eat('-')
    return [:unary, 'not', parse_unary] if eat('not')
    parse_postfix
  end

  def parse_postfix
    node = parse_primary
    loop do
      if eat('.')
        if (id = eat(:ident))
          node = [:field, node, id.value, eat('?') ? true : false]
        elsif (s = eat(:string))
          node = [:field, node, s.value, eat('?') ? true : false]
        elsif eat('[')
          node = parse_bracket_post(node)
        else
          node = [:identity]
        end
      elsif eat('[')
        node = parse_bracket_post(node)
      elsif eat('?')
        node = [:optional, node]
      else
        break
      end
    end
    node
  end

  def parse_bracket_post(node)
    if eat(']')
      return [:iter, node, false]
    end
    if eat(':')
      e2 = cur.type == ']' ? nil : parse_comma
      expect(']')
      return [:slice, node, nil, e2]
    end
    e1 = parse_comma
    if eat(':')
      e2 = cur.type == ']' ? nil : parse_comma
      expect(']')
      [:slice, node, e1, e2]
    else
      expect(']')
      [:index, node, e1]
    end
  end

  def parse_primary
    if eat('.')
      if (id = eat(:ident))
        return [:field, [:identity], id.value, eat('?') ? true : false]
      elsif (s = eat(:string))
        return [:field, [:identity], s.value, eat('?') ? true : false]
      elsif eat('[')
        return parse_bracket_post([:identity])
      end
      return [:identity]
    end
    return [:literal, true] if eat('true')
    return [:literal, false] if eat('false')
    return [:literal, nil] if eat('null')
    return [:recurse] if eat('..')
    return [:literal, eat(:number).value] if cur.type == :number
    return [:literal, eat(:string).value] if cur.type == :string
    return [:var, eat(:var).value] if cur.type == :var
    return parse_array if eat('[')
    return parse_object if eat('{')
    return parse_if if eat('if')
    return parse_reduce if eat('reduce')
    if (id = eat(:ident))
      name = id.value
      if eat('(')
        args = []
        args << parse_comma unless cur.type == ')'
        while eat(';') || eat(',')
          args << parse_comma
        end
        expect(')')
        return [:call, name, args]
      end
      return [:call, name, []]
    end
    if eat('(')
      e = parse_comma
      expect(')')
      return e
    end
    raise JQError, "unexpected token #{cur.type}"
  end

  def parse_array
    if eat(']')
      [:literal, []]
    else
      e = parse_comma
      expect(']')
      [:array, e]
    end
  end

  def parse_object
    pairs = []
    unless eat('}')
      loop do
        key_expr = nil
        key = nil
        if cur.type == :ident
          key = eat.value
        elsif cur.type == :string
          key = eat.value
        elsif eat('(')
          key_expr = parse_comma
          expect(')')
        else
          raise JQError, 'expected object key'
        end
        val = eat(':') ? parse_pipe : [:field, [:identity], key, true]
        pairs << [key, key_expr, val]
        break if eat('}')
        expect(',')
      end
    end
    [:object, pairs]
  end

  def parse_if
    cond = parse_comma
    expect('then')
    yes = parse_comma
    expect('else')
    no = parse_comma
    expect('end')
    [:if, cond, yes, no]
  end

  def parse_reduce
    src = parse_logic
    expect('as')
    var = expect(:var).value
    expect('(')
    init = parse_comma
    expect(';')
    update = parse_comma
    expect(')')
    [:reduce, src, var, init, update]
  end
end

class Runtime
  attr_reader :vars
  def initialize(vars = {})
    @vars = vars
  end

  def eval(node, input)
    case node[0]
    when :identity then [input]
    when :literal then [deepcopy(node[1])]
    when :var then [@vars.fetch(node[1]) { nil }]
    when :comma then eval(node[1], input) + eval(node[2], input)
    when :pipe then eval(node[1], input).flat_map { |v| eval(node[2], v) }
    when :as
      eval(node[1], input).flat_map do |v|
        old = @vars[node[2]]
        had = @vars.key?(node[2])
        @vars[node[2]] = v
        begin
          eval(node[3], input)
        ensure
          had ? @vars[node[2]] = old : @vars.delete(node[2])
        end
      end
    when :array then [eval(node[1], input)]
    when :object
      obj = {}
      node[1].each do |key, key_expr, val_expr|
        keys = key_expr ? eval(key_expr, input) : [key]
        vals = eval(val_expr, input)
        keys.each { |k| obj[k.to_s] = vals.length <= 1 ? vals[0] : vals }
      end
      [obj]
    when :field
      eval(node[1], input).flat_map { |v| field(v, node[2], node[3]) }
    when :index
      eval(node[1], input).flat_map do |v|
        eval(node[2], input).map { |idx| index(v, idx) }
      end
    when :slice
      eval(node[1], input).map do |v|
        a = node[2] ? eval(node[2], input)[0] : nil
        b = node[3] ? eval(node[3], input)[0] : nil
        slice(v, a, b)
      end
    when :iter
      eval(node[1], input).flat_map { |v| iterate(v) }
    when :optional
      begin
        eval(node[1], input)
      rescue JQError
        []
      end
    when :unary
      eval(node[2], input).map { |v| node[1] == 'not' ? !truthy?(v) : -v }
    when :bin
      eval_bin(node[1], node[2], node[3], input)
    when :if
      eval(node[1], input).flat_map { |c| eval(truthy?(c) ? node[2] : node[3], input) }
    when :reduce
      accs = eval(node[3], input)
      eval(node[1], input).each do |item|
        accs = accs.flat_map do |acc|
          old = @vars[node[2]]
          had = @vars.key?(node[2])
          @vars[node[2]] = item
          begin
            eval(node[4], acc)
          ensure
            had ? @vars[node[2]] = old : @vars.delete(node[2])
          end
        end
      end
      accs
    when :recurse
      recurse(input)
    when :call
      call(node[1], node[2], input)
    else
      raise JQError, "unsupported AST #{node[0]}"
    end
  end

  def deepcopy(v)
    v.is_a?(Array) || v.is_a?(Hash) ? Marshal.load(Marshal.dump(v)) : v
  end

  def truthy?(v) = !(v.nil? || v == false)

  def field(v, key, optional = false)
    if v.is_a?(Hash)
      [v[key]]
    elsif v.nil? || optional
      [nil]
    else
      raise JQError, "Cannot index #{type_name(v)} with string #{key.inspect}"
    end
  end

  def index(v, idx)
    case v
    when Array
      return nil unless idx.is_a?(Integer)
      i = idx < 0 ? v.length + idx : idx
      v[i]
    when Hash
      return v[idx.to_s] if idx.is_a?(String)
      raise JQError, "Cannot index object with #{type_name(idx)}"
    when String
      idx.is_a?(Integer) ? v[idx] : nil
    when nil
      nil
    else
      nil
    end
  end

  def slice(v, a, b)
    return nil unless v.is_a?(Array) || v.is_a?(String)
    len = v.length
    from = a.nil? ? 0 : (a < 0 ? len + a : a)
    to = b.nil? ? len : (b < 0 ? len + b : b)
    v[from...to] || (v.is_a?(String) ? "" : [])
  end

  def iterate(v)
    case v
    when Array then v
    when Hash then v.values
    when nil then []
    else raise JQError, "Cannot iterate over #{type_name(v)}"
    end
  end

  def recurse(v)
    out = [v]
    case v
    when Array then v.each { |x| out.concat(recurse(x)) }
    when Hash then v.each_value { |x| out.concat(recurse(x)) }
    end
    out
  end

  def eval_bin(op, left, right, input)
    if op == 'and' || op == 'or'
      return eval(left, input).flat_map { |a| eval(right, input).map { |b| op == 'and' ? truthy?(a) && truthy?(b) : truthy?(a) || truthy?(b) } }
    end
    if op == '//'
      l = eval(left, input).select { |x| truthy?(x) }
      return l.empty? ? eval(right, input) : l
    end
    eval(left, input).flat_map do |a|
      eval(right, input).map { |b| apply_op(op, a, b) }
    end
  end

  def apply_op(op, a, b)
    case op
    when '+' then plus(a, b)
    when '-' then a - b
    when '*' then multiply(a, b)
    when '/' then a / b
    when '%' then a % b
    when '==' then a == b
    when '!=' then a != b
    when '<' then compare(a, b) < 0
    when '>' then compare(a, b) > 0
    when '<=' then compare(a, b) <= 0
    when '>=' then compare(a, b) >= 0
    else raise JQError, "unknown operator #{op}"
    end
  rescue NoMethodError, TypeError, ZeroDivisionError
    raise JQError, "#{type_name(a)} and #{type_name(b)} cannot be #{op}"
  end

  def plus(a, b)
    return b if a.nil?
    return a if b.nil?
    return a + b if (a.is_a?(Numeric) && b.is_a?(Numeric)) || (a.is_a?(String) && b.is_a?(String)) || (a.is_a?(Array) && b.is_a?(Array))
    return a.merge(b) if a.is_a?(Hash) && b.is_a?(Hash)
    raise JQError, "#{type_name(a)} and #{type_name(b)} cannot be added"
  end

  def multiply(a, b)
    return a * b if a.is_a?(Numeric) && b.is_a?(Numeric)
    return a * b if a.is_a?(String) && b.is_a?(Integer)
    return b * a if b.is_a?(String) && a.is_a?(Integer)
    raise JQError, "#{type_name(a)} and #{type_name(b)} cannot be multiplied"
  end

  ORDER = { nil => 0, false => 1, true => 1, Numeric => 2, String => 3, Array => 4, Hash => 5 }.freeze
  def compare(a, b)
    return a <=> b if a.class == b.class && (a.is_a?(Numeric) || a.is_a?(String))
    rank(a) <=> rank(b)
  end

  def rank(v)
    return 0 if v.nil?
    return 1 if v == false
    return 2 if v == true
    return 3 if v.is_a?(Numeric)
    return 4 if v.is_a?(String)
    return 5 if v.is_a?(Array)
    6
  end

  def type_name(v)
    case v
    when nil then 'null'
    when TrueClass, FalseClass then 'boolean'
    when Numeric then 'number'
    when String then 'string'
    when Array then 'array'
    when Hash then 'object'
    else v.class.to_s
    end
  end

  def call(name, args, input)
    case name
    when 'empty' then []
    when 'length' then [length(input)]
    when 'keys' then [keys(input, false)]
    when 'keys_unsorted' then [keys(input, true)]
    when 'type' then [type_name(input)]
    when 'tostring' then [input.is_a?(String) ? input : MiniJSON.generate(input)]
    when 'tonumber' then [input.is_a?(Numeric) ? input : MiniJSON.parse(input)]
    when 'not' then [!truthy?(input)]
    when 'has'
      k = eval(args[0], input)[0]
      [input.is_a?(Hash) ? input.key?(k.to_s) : input.is_a?(Array) && k.is_a?(Integer) && k >= 0 && k < input.length]
    when 'map' then [iterate(input).flat_map { |v| eval(args[0], v) }]
    when 'select' then truthy?(eval(args[0], input)[0]) ? [input] : []
    when 'add' then [iterate(input).reduce { |a, b| plus(a, b) }]
    when 'min' then [iterate(input).min { |a, b| compare(a, b) }]
    when 'max' then [iterate(input).max { |a, b| compare(a, b) }]
    when 'reverse' then [input.reverse]
    when 'sort' then [iterate(input).sort { |a, b| compare(a, b) }]
    when 'unique' then [iterate(input).sort { |a, b| compare(a, b) }.uniq]
    when 'sort_by'
      [iterate(input).sort { |a, b| compare(eval(args[0], a)[0], eval(args[0], b)[0]) }]
    when 'unique_by'
      seen = {}
      sorted = iterate(input).sort { |a, b| compare(eval(args[0], a)[0], eval(args[0], b)[0]) }
      [sorted.select { |x| k = MiniJSON.generate(eval(args[0], x)[0]); !seen[k] && (seen[k] = true) }]
    when 'min_by' then [iterate(input).min { |a, b| compare(eval(args[0], a)[0], eval(args[0], b)[0]) }]
    when 'max_by' then [iterate(input).max { |a, b| compare(eval(args[0], a)[0], eval(args[0], b)[0]) }]
    when 'group_by'
      sorted = iterate(input).sort { |a, b| compare(eval(args[0], a)[0], eval(args[0], b)[0]) }
      groups = []
      sorted.each do |x|
        k = eval(args[0], x)[0]
        if groups.empty? || compare(groups[-1][0], k) != 0
          groups << [k, [x]]
        else
          groups[-1][1] << x
        end
      end
      [groups.map(&:last)]
    when 'flatten' then [input.flatten(args[0] ? eval(args[0], input)[0] : nil)]
    when 'first' then args.empty? ? [iterate(input).first] : eval(args[0], input).first(1)
    when 'last' then args.empty? ? [iterate(input).last] : eval(args[0], input).last(1)
    when 'range'
      vals = args.map { |a| eval(a, input)[0] }
      from, to, step = vals.length == 1 ? [0, vals[0], 1] : [vals[0], vals[1], vals[2] || 1]
      out = []
      x = from
      if step.positive?
        while x < to; out << x; x += step; end
      else
        while x > to; out << x; x += step; end
      end
      out
    when 'contains'
      [contains?(input, eval(args[0], input)[0])]
    when 'startswith' then [input.to_s.start_with?(eval(args[0], input)[0].to_s)]
    when 'endswith' then [input.to_s.end_with?(eval(args[0], input)[0].to_s)]
    when 'split' then [input.to_s.split(eval(args[0], input)[0].to_s, -1)]
    when 'join' then [iterate(input).join(eval(args[0], input)[0].to_s)]
    when 'index' then [input.to_s.index(eval(args[0], input)[0].to_s)]
    when 'rindex' then [input.to_s.rindex(eval(args[0], input)[0].to_s)]
    when 'indices'
      needle = eval(args[0], input)[0]
      if input.is_a?(String)
        out = []
        pos = 0
        while (j = input.index(needle.to_s, pos))
          out << j
          pos = j + [needle.to_s.length, 1].max
        end
        [out]
      else
        [iterate(input).each_index.select { |j| input[j, needle.length] == needle }]
      end
    when 'test' then [Regexp.new(eval(args[0], input)[0]).match?(input.to_s)]
    when 'match'
      re = Regexp.new(eval(args[0], input)[0])
      m = re.match(input.to_s)
      [m ? { 'offset' => m.begin(0), 'length' => m[0].length, 'string' => m[0], 'captures' => [] } : nil].compact
    when 'sub'
      re = Regexp.new(eval(args[0], input)[0])
      repl = eval(args[1], input)[0].to_s
      [input.to_s.sub(re, repl)]
    when 'gsub'
      re = Regexp.new(eval(args[0], input)[0])
      repl = eval(args[1], input)[0].to_s
      [input.to_s.gsub(re, repl)]
    when 'ascii_downcase' then [input.to_s.downcase]
    when 'ascii_upcase' then [input.to_s.upcase]
    when 'floor' then [input.floor]
    when 'ceil' then [input.ceil]
    when 'round' then [input.round]
    when 'sqrt' then [Math.sqrt(input)]
    when 'abs' then [input.abs]
    when 'map_values'
      if input.is_a?(Hash)
        [input.transform_values { |v| vals = eval(args[0], v); vals[-1] }]
      else
        [iterate(input).map { |v| vals = eval(args[0], v); vals[-1] }]
      end
    when 'to_entries'
      if input.is_a?(Hash)
        [input.map { |k, v| { 'key' => k, 'value' => v } }]
      else
        [iterate(input).each_with_index.map { |v, j| { 'key' => j, 'value' => v } }]
      end
    when 'from_entries'
      [iterate(input).each_with_object({}) do |e, h|
        k = e.key?('key') ? e['key'] : (e.key?('Key') ? e['Key'] : e['name'])
        v = e.key?('value') ? e['value'] : e['Value']
        h[k.to_s] = v
      end]
    when 'with_entries'
      entries = call('to_entries', [], input)[0]
      [call('from_entries', [], entries.flat_map { |e| eval(args[0], e) })[0]]
    when 'env' then [ENV.to_h]
    when 'values' then input.nil? ? [] : [input]
    when 'arrays' then input.is_a?(Array) ? [input] : []
    when 'objects' then input.is_a?(Hash) ? [input] : []
    when 'numbers' then input.is_a?(Numeric) ? [input] : []
    when 'strings' then input.is_a?(String) ? [input] : []
    when 'booleans' then (input == true || input == false) ? [input] : []
    when 'nulls' then input.nil? ? [input] : []
    else
      raise JQError, "#{name}/#{args.length} is not defined"
    end
  end

  def length(v)
    case v
    when Array, Hash, String then v.length
    when Numeric then v.abs
    when nil then 0
    else 0
    end
  end

  def keys(v, unsorted)
    case v
    when Hash
      ks = v.keys
      unsorted ? ks : ks.sort
    when Array then (0...v.length).to_a
    else raise JQError, "#{type_name(v)} has no keys"
    end
  end

  def contains?(a, b)
    return a.include?(b) if a.is_a?(String) || a.is_a?(Array)
    return b.all? { |k, v| a.key?(k) && contains?(a[k], v) } if a.is_a?(Hash) && b.is_a?(Hash)
    a == b
  end
end

def split_json_stream(s)
  vals = []
  i = 0
  while i < s.length
    i += 1 while i < s.length && s[i] =~ /\s/
    break if i >= s.length
    start = i
    if s[i] == '"' || s[i] == '[' || s[i] == '{'
      stack = []
      str = false
      esc = false
      while i < s.length
        c = s[i]
        if str
          if esc then esc = false
          elsif c == '\\' then esc = true
          elsif c == '"' then str = false
          end
        elsif c == '"'
          str = true
        elsif c == '[' || c == '{'
          stack << c
        elsif c == ']' || c == '}'
          stack.pop
          if stack.empty?
            i += 1
            break
          end
        elsif stack.empty? && c =~ /\s/
          break
        end
        i += 1
      end
    else
      i += 1 while i < s.length && s[i] !~ /\s/
    end
    vals << MiniJSON.parse(s[start...i])
  end
  vals
end

def dump_json(v, compact:, sort_keys:, indent:, ascii:)
  v = sort_value(v) if sort_keys
  if compact
    MiniJSON.generate(v, ascii_only: ascii)
  else
    pretty(v, 0, indent, ascii)
  end
end

def sort_value(v)
  case v
  when Array then v.map { |x| sort_value(x) }
  when Hash then v.keys.sort.each_with_object({}) { |k, h| h[k] = sort_value(v[k]) }
  else v
  end
end

def json_string(s, ascii)
  MiniJSON.generate(s, ascii_only: ascii)
end

def pretty(v, level, indent, ascii)
  sp = indent * level
  sp2 = indent * (level + 1)
  case v
  when Array
    return '[]' if v.empty?
    "[\n" + v.map { |x| sp2 + pretty(x, level + 1, indent, ascii) }.join(",\n") + "\n#{sp}]"
  when Hash
    return '{}' if v.empty?
    "{\n" + v.map { |k, x| sp2 + json_string(k, ascii) + ': ' + pretty(x, level + 1, indent, ascii) }.join(",\n") + "\n#{sp}}"
  when String then json_string(v, ascii)
  else MiniJSON.generate(v, ascii_only: ascii)
  end
end

def usage
  <<~TXT
    jq - commandline JSON processor [version build-2b77eb1]

    Usage:\tjq [options] <jq filter> [file...]
  TXT
end

opts = { null_input: false, raw_input: false, slurp: false, compact: false, raw_output: false,
         join: false, ascii: false, sort: false, indent: '  ', exit_status: false }
vars = {}
args = ARGV.dup
filter = nil
files = []
i = 0
while i < args.length
  a = args[i]
  case a
  when '-n', '--null-input' then opts[:null_input] = true
  when '-R', '--raw-input' then opts[:raw_input] = true
  when '-s', '--slurp' then opts[:slurp] = true
  when '-c', '--compact-output' then opts[:compact] = true
  when '-r', '--raw-output' then opts[:raw_output] = true
  when '-j', '--join-output' then opts[:raw_output] = true; opts[:join] = true
  when '-a', '--ascii-output' then opts[:ascii] = true
  when '-S', '--sort-keys' then opts[:sort] = true
  when '-M', '--monochrome-output', '-C', '--color-output', '--unbuffered' then nil
  when '--tab' then opts[:indent] = "\t"
  when '--indent' then i += 1; opts[:indent] = ' ' * [[args[i].to_i, 0].max, 7].min
  when '-e', '--exit-status' then opts[:exit_status] = true
  when '-V', '--version' then puts 'jq-build-2b77eb1'; exit 0
  when '--build-configuration' then puts '--disable-docs --with-oniguruma=builtin --enable-static --enable-all-static --prefix=/usr/local'; exit 0
  when '-h', '--help' then print usage; exit 0
  when '-f', '--from-file' then i += 1; filter = File.read(args[i])
  when '--arg' then name = args[i += 1]; vars[name] = args[i += 1]
  when '--argjson' then name = args[i += 1]; vars[name] = MiniJSON.parse(args[i += 1])
  when '--rawfile' then name = args[i += 1]; vars[name] = File.read(args[i += 1])
  when '--slurpfile' then name = args[i += 1]; vars[name] = split_json_stream(File.read(args[i += 1]))
  when '--args'
    filter ||= args[i += 1]
    pos = args[(i + 1)..] || []
    vars['ARGS'] = { 'positional' => pos, 'named' => vars.dup }
    i = args.length
    next
  when '--jsonargs'
    filter ||= args[i += 1]
    pos = (args[(i + 1)..] || []).map { |x| MiniJSON.parse(x) }
    vars['ARGS'] = { 'positional' => pos, 'named' => vars.dup }
    i = args.length
    next
  when '--'
    filter ||= args[i += 1]
    files += args[(i + 1)..] || []
    break
  else
    if a.start_with?('-') && filter.nil?
      warn "jq: Unknown option #{a}"
      exit 2
    elsif filter.nil?
      filter = a
    else
      files << a
    end
  end
  i += 1
end
vars['ARGS'] ||= { 'positional' => [], 'named' => vars.dup }
filter ||= '.'

begin
  ast = Parser.new(filter).parse
  rt = Runtime.new(vars)
rescue JQError => e
  warn "jq: error: #{e.message}"
  exit 3
end

begin
  inputs =
    if opts[:null_input]
      [nil]
    else
      text = if files.empty?
               STDIN.read
             else
               files.map { |f| File.read(f) }.join("\n")
             end
      if opts[:raw_input]
        opts[:slurp] ? [text] : text.each_line(chomp: true).to_a
      else
        vals = split_json_stream(text)
        opts[:slurp] ? [vals] : vals
      end
    end
  last = nil
  any = false
  inputs.each do |inp|
    rt.eval(ast, inp).each do |v|
      any = true
      last = v
      if opts[:raw_output] && v.is_a?(String)
        print v
      else
        print dump_json(v, compact: opts[:compact], sort_keys: opts[:sort], indent: opts[:indent], ascii: opts[:ascii])
      end
      print "\n" unless opts[:join]
    end
  end
  if opts[:exit_status]
    exit(any && !(last.nil? || last == false) ? 0 : any ? 1 : 4)
  end
rescue JQError => e
  warn "jq: parse error: #{e.message}"
  exit 5
end
