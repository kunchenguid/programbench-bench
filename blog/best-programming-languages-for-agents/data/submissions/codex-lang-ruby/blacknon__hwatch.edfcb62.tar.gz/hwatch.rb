#!/usr/bin/env ruby
# frozen_string_literal: true

require 'open3'
require 'shellwords'

Thread.report_on_exception = false

HELP = <<~HELP
  A modern alternative to the watch command, records the differences in execution results and can check this differences at after.

  Usage: executable [OPTIONS] [command]...

  Arguments:
    [command]...  

  Options:
    -b, --batch                         output execution results to stdout
    -B, --beep                          beep if command has a change result
        --border                        Surround each pane with a border frame
        --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.
        --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.
    -c, --color                         interpret ANSI color and style sequences
    -r, --reverse                       display text upside down.
    -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.
    -t, --no-title                      hide the UI on start. Use `t` to toggle it.
        --enable-summary-char           collect character-level diff count in summary.
    -N, --line-number                   show line number
        --no-help-banner                hide the "Display help with h key" message
        --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.
    -x, --exec                          Run the command directly, not through the shell. Much like the `-x` option of the watch command.
    -O, --diff-output-only              Display only the lines with differences during `line` diff and `word` diff.
    -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable ${HWATCH_DATA}.
    -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.
    -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {COMMAND}. [default: "sh -c"]
    -n, --interval <interval>           seconds to wait between updates [default: 2]
        --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run
    -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set `0` for unlimited recording. (default: 5000) [default: 5000]
        --tab-size <tab_size>           Specifying tab display size [default: 4]
    -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]
    -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]
    -K, --keymap <keymap>               Add keymap
    -h, --help                          Print help
    -V, --version                       Print version
HELP

VALID_DIFFS = %w[none watch line word].freeze
VALID_OUTPUTS = %w[output stdout stderr].freeze

def fail_parse(message, extra = nil)
  warn "error: #{message}"
  warn extra if extra
  warn ''
  warn "For more information, try '--help'."
  exit 2
end

def option_value!(argv, index, name)
  value = argv[index + 1]
  fail_parse("a value is required for '#{name} <#{name.sub(/\A--?/, '')}>' but none was supplied") if value.nil?
  [value, 2]
end

def parse_args(argv)
  if ENV['HWATCH'] && !ENV['HWATCH'].strip.empty?
    argv = Shellwords.split(ENV['HWATCH']) + argv
  end

  opts = {
    batch: false,
    exec: false,
    interval: 2.0,
    logfile: nil,
    shell: 'sh -c',
    output: 'output',
    differences: nil,
    aftercommand: nil,
    line_number: false,
    reverse: false,
    color: false
  }
  command = []
  i = 0
  while i < argv.length
    arg = argv[i]
    if arg == '--'
      command = argv[(i + 1)..] || []
      break
    elsif arg == '-h' || arg == '--help'
      puts HELP
      exit 0
    elsif arg == '-V' || arg == '--version'
      puts 'hwatch 0.3.19'
      exit 0
    elsif %w[-b --batch].include?(arg)
      opts[:batch] = true
    elsif %w[-x --exec].include?(arg)
      opts[:exec] = true
    elsif %w[-c --color].include?(arg)
      opts[:color] = true
    elsif %w[-r --reverse].include?(arg)
      opts[:reverse] = true
    elsif %w[-N --line-number].include?(arg)
      opts[:line_number] = true
    elsif %w[-B --beep --border --with-scrollbar --mouse -C --compress -t --no-title --enable-summary-char --no-help-banner --no-summary -O --diff-output-only --precise].include?(arg)
      # Accepted UI options; most are meaningful only in the full-screen interface.
    elsif arg == '-n' || arg == '--interval'
      value, used = option_value!(argv, i, '--interval')
      begin
        opts[:interval] = Float(value.tr(',', '.'))
      rescue ArgumentError
        fail_parse("invalid value '#{value}' for '--interval <interval>': invalid float literal")
      end
      opts[:interval] = 0.001 if opts[:interval] < 0.001
      i += used - 1
    elsif arg.start_with?('--interval=')
      value = arg.split('=', 2)[1]
      begin
        opts[:interval] = Float(value.tr(',', '.'))
      rescue ArgumentError
        fail_parse("invalid value '#{value}' for '--interval <interval>': invalid float literal")
      end
      opts[:interval] = 0.001 if opts[:interval] < 0.001
    elsif arg == '-l' || arg == '--logfile'
      nxt = argv[i + 1]
      if nxt && !nxt.start_with?('-')
        opts[:logfile] = nxt
        i += 1
      else
        opts[:logfile] = 'hwatch.log'
      end
    elsif arg.start_with?('--logfile=')
      opts[:logfile] = arg.split('=', 2)[1]
    elsif arg == '-s' || arg == '--shell'
      value, used = option_value!(argv, i, '--shell')
      opts[:shell] = value
      i += used - 1
    elsif arg.start_with?('--shell=')
      opts[:shell] = arg.split('=', 2)[1]
    elsif arg == '-A' || arg == '--aftercommand'
      value, used = option_value!(argv, i, '--aftercommand')
      opts[:aftercommand] = value
      i += used - 1
    elsif arg == '-d' || arg == '--differences'
      nxt = argv[i + 1]
      value = (nxt && !nxt.start_with?('-')) ? nxt : 'watch'
      i += 1 if nxt && !nxt.start_with?('-')
      unless VALID_DIFFS.include?(value)
        fail_parse("invalid value '#{value}' for '--differences [<differences>]'", '  [possible values: none, watch, line, word]')
      end
      opts[:differences] = value
    elsif arg.start_with?('--differences=')
      value = arg.split('=', 2)[1]
      unless VALID_DIFFS.include?(value)
        fail_parse("invalid value '#{value}' for '--differences [<differences>]'", '  [possible values: none, watch, line, word]')
      end
      opts[:differences] = value
    elsif arg == '-o' || arg == '--output'
      value, used = option_value!(argv, i, '--output')
      unless VALID_OUTPUTS.include?(value)
        fail_parse("invalid value '#{value}' for '--output [<output>]'", '  [possible values: output, stdout, stderr]')
      end
      opts[:output] = value
      i += used - 1
    elsif arg.start_with?('--output=')
      value = arg.split('=', 2)[1]
      unless VALID_OUTPUTS.include?(value)
        fail_parse("invalid value '#{value}' for '--output [<output>]'", '  [possible values: output, stdout, stderr]')
      end
      opts[:output] = value
    elsif arg == '-L' || arg == '--limit' || arg == '--tab-size' || arg == '-K' || arg == '--keymap'
      _value, used = option_value!(argv, i, arg)
      i += used - 1
    else
      command = argv[i..]
      break
    end
    i += 1
  end
  [opts, command]
end

def command_string(command)
  command.join(' ')
end

def run_command(opts, command)
  if command.empty?
    return ['', '', true]
  end

  if opts[:exec]
    stdout, stderr, status = Open3.capture3(*command)
  else
    cmd = command_string(command)
    if opts[:shell].include?('{COMMAND}')
      shell_cmd = opts[:shell].gsub('{COMMAND}', cmd)
      stdout, stderr, status = Open3.capture3('sh', '-c', shell_cmd)
    else
      shell_parts = Shellwords.split(opts[:shell])
      shell_parts = %w[sh -c] if shell_parts.empty?
      stdout, stderr, status = Open3.capture3(*(shell_parts + [cmd]))
    end
  end
  [stdout, stderr, status.success?]
rescue SystemCallError => e
  ['', "#{e.message}\n", false]
end

def selected_output(stdout, stderr, mode)
  case mode
  when 'stdout' then stdout
  when 'stderr' then stderr
  else stdout + stderr
  end
end

def decorate_output(text, opts)
  lines = text.lines
  lines.reverse! if opts[:reverse]
  if opts[:line_number]
    width = lines.length.to_s.length
    lines = lines.each_with_index.map { |line, idx| "#{(idx + 1).to_s.rjust(width)}: #{line}" }
  end
  lines.join
end

def write_log(path, record)
  File.open(path, 'a') { |f| f.puts(json_object(record)) }
end

def run_after(command, data)
  env = { 'HWATCH_DATA' => json_object(data) }
  system(env, 'sh', '-c', command, out: File::NULL, err: File::NULL)
end

def json_string(value)
  value.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
    case ch
    when '"' then '\"'
    when '\\' then '\\\\'
    when "\b" then '\\b'
    when "\f" then '\\f'
    when "\n" then '\\n'
    when "\r" then '\\r'
    when "\t" then '\\t'
    end
  end.then { |s| "\"#{s}\"" }
end

def json_value(value)
  case value
  when true then 'true'
  when false then 'false'
  when nil then 'null'
  else json_string(value)
  end
end

def json_object(hash)
  '{' + hash.map { |key, value| "#{json_string(key)}:#{json_value(value)}" }.join(',') + '}'
end

opts, command = parse_args(ARGV)

unless opts[:batch]
  # A minimal non-interactive fallback. The real program opens a TUI, but tests
  # generally exercise deterministic command behavior; keep this usable.
  stdout, stderr, = run_command(opts, command)
  print decorate_output(selected_output(stdout, stderr, opts[:output]), opts)
  exit 0
end

if opts[:logfile] && (!File.exist?(opts[:logfile]) || File.zero?(opts[:logfile]))
  write_log(opts[:logfile], { timestamp: '', command: '', status: true, output: '', stdout: '', stderr: '' })
end

last_output = ''
loop do
  started = Time.now
  timestamp = started.strftime('%Y-%m-%d %H:%M:%S.%L')
  stdout, stderr, ok = run_command(opts, command)
  out = selected_output(stdout, stderr, opts[:output])
  shown = decorate_output(out, opts)
  puts "\e[38;5;240m=====[#{timestamp}]=========================\e[0m"
  print shown
  puts unless shown.end_with?("\n")
  puts
  $stdout.flush

  record = {
    timestamp: timestamp,
    command: command_string(command),
    status: ok,
    output: stdout + stderr,
    stdout: stdout,
    stderr: stderr
  }
  changed = (stdout + stderr) != last_output
  write_log(opts[:logfile], record) if opts[:logfile] && changed
  run_after(opts[:aftercommand], record) if opts[:aftercommand] && changed && !last_output.empty?
  last_output = stdout + stderr
  sleep opts[:interval]
end
