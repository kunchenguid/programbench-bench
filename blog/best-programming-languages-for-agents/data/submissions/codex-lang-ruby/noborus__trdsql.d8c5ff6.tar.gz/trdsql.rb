#!/usr/bin/env ruby
# frozen_string_literal: true

require 'csv'
require 'json'
require 'yaml'
require 'optparse'

HELP = <<~TEXT
  trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.

  Usage
  \ttrdsql [OPTIONS] [SQL(SELECT...)]

  Options:
    -A string           analyze the file but only suggest SQL.
    -a string           analyze the file and suggest SQL.
    -config string      configuration file location.
    -db string          specify db name of the setting.
    -dblist             display db information.
    -debug              debug print.
    -driver string      database driver.  [ mysql | postgres | sqlite3 | sqlite3_ext ]
    -dsn string         database driver specific data source name.
    -help               display usage information.
    -q string           read query from the specified file.
    -t string           read table name from the specified file.
    -version            display version information.

  Input Formats:
    -icsv               CSV format for input.
    -ig                 guess format from extension. (default "true")
    -ijson              JSON format for input.
    -iltsv              LTSV format for input.
    -itbln              TBLN format for input.
    -itext              text format for input.
    -iwidth             width specification format for input.
    -iyaml              YAML format for input.

  Input options:
    -id string          field delimiter for input. (default ",")
    -ih                 the first line is interpreted as column names(CSV only).
    -ijq string         jq expression string for input(JSON/JSONL only).
    -ilr int            limited number of rows to read. (default 0)
    -inull value        value(string) to convert to null on input.
    -inum               add row number column.
    -ir int             number of rows to preread. (default 1)
    -is int             skip header row. (default 0)

  Output Formats:
    -oat                ASCII Table format for output.
    -ocsv               CSV format for output.
    -ojson              JSON format for output.
    -ojsonl             JSON lines format for output.
    -oltsv              LTSV format for output.
    -omd                Markdown format for output.
    -oraw               Raw format for output.
    -otbln              TBLN format for output.
    -ovf                Vertical format for output.
    -oyaml              YAML format for output.

  Output options:
    -oaq                enclose all fields in quotes for output.
    -ocrlf              use CRLF for output. End each output line with '\\r\\n' instead of '\\n'.
    -od string          field delimiter for output. (default ",")
    -oh                 output column name as header.
    -onowrap            do not wrap long lines(at/md only).
    -onull value        value(string) to convert from null on output.
    -oq string          quote character for output. (default "\\"")
    -out string         output file name.
    -out-without-guess  output without guessing (when using -out).
    -oz string          output compression format. [ gz | bz2 | zstd | lz4 | xz ]

  Examples:
    $ trdsql "SELECT c1,c2 FROM test.csv"
    $ trdsql -oltsv "SELECT c1,c2 FROM test.json::.items"
    $ cat test.csv | trdsql -icsv -oltsv "SELECT c1,c2 FROM -"
TEXT

DEFAULTS = {
  input_format: nil, output_format: :csv, id: ',', od: ',', oq: '"',
  ih: false, oh: false, oaq: false, ocrlf: false, inum: false,
  is: 0, ilr: 0, inull: nil, onull: '', query_file: nil, table_file: nil,
  out: nil, ijq: nil, analyze: nil
}.freeze

def parse_args(argv)
  opts = DEFAULTS.dup
  rest = []
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-help', '--help'
      puts HELP
      exit 0
    when '-version', '--version'
      puts 'trdsql version devel'
      exit 0
    when '-dblist'
      exit 0
    when '-icsv' then opts[:input_format] = :csv
    when '-ijson' then opts[:input_format] = :json
    when '-iltsv' then opts[:input_format] = :ltsv
    when '-iyaml' then opts[:input_format] = :yaml
    when '-itbln' then opts[:input_format] = :tbln
    when '-itext', '-iwidth' then opts[:input_format] = :text
    when '-ocsv' then opts[:output_format] = :csv
    when '-ojson' then opts[:output_format] = :json
    when '-ojsonl' then opts[:output_format] = :jsonl
    when '-oltsv' then opts[:output_format] = :ltsv
    when '-omd' then opts[:output_format] = :md
    when '-oat' then opts[:output_format] = :at
    when '-oraw' then opts[:output_format] = :raw
    when '-otbln' then opts[:output_format] = :tbln
    when '-ovf' then opts[:output_format] = :vf
    when '-oyaml' then opts[:output_format] = :yaml
    when '-ih' then opts[:ih] = true
    when '-oh' then opts[:oh] = true
    when '-oaq' then opts[:oaq] = true
    when '-ocrlf' then opts[:ocrlf] = true
    when '-inum' then opts[:inum] = true
    when '-ig', '-debug', '-out-without-guess'
      # accepted no-op compatibility flags
    when '-id' then i += 1; opts[:id] = argv[i] || ','
    when '-od' then i += 1; opts[:od] = argv[i] || ','
    when '-oq' then i += 1; opts[:oq] = argv[i] || '"'
    when '-q' then i += 1; opts[:query_file] = argv[i]
    when '-t' then i += 1; opts[:table_file] = argv[i]
    when '-out' then i += 1; opts[:out] = argv[i]
    when '-ijq' then i += 1; opts[:ijq] = argv[i]
    when '-is' then i += 1; opts[:is] = (argv[i] || '0').to_i
    when '-ilr' then i += 1; opts[:ilr] = (argv[i] || '0').to_i
    when '-ir' then i += 1
    when '-inull' then i += 1; opts[:inull] = argv[i]
    when '-onull' then i += 1; opts[:onull] = argv[i] || ''
    when '-a', '-A' then i += 1; opts[:analyze] = argv[i]
    when '-config', '-db', '-driver', '-dsn', '-oz'
      i += 1
    else
      if arg.start_with?('-')
        warn "flag provided but not defined: #{arg}"
        warn HELP
        exit 2
      end
      rest << arg
    end
    i += 1
  end
  [opts, rest.join(' ')]
end

def split_csv_line(line, delim)
  CSV.parse_line(line, col_sep: delim, liberal_parsing: true) || []
end

def guess_format(path, opts)
  return opts[:input_format] if opts[:input_format]
  return :csv if path == '-'
  base = path.to_s.sub(/::.*/, '')
  case File.extname(base).downcase
  when '.json', '.jsonl', '.ndjson' then :json
  when '.yaml', '.yml' then :yaml
  when '.ltsv' then :ltsv
  when '.tbln' then :tbln
  when '.txt', '.log' then :text
  else :csv
  end
end

def apply_json_path(obj, path)
  return obj if path.nil? || path.empty?
  expr = path.sub(/\A::/, '')
  expr = expr.sub(/\A\./, '')
  expr.split('.').reject(&:empty?).each do |part|
    obj = if obj.is_a?(Array) && part =~ /\A\d+\z/
            obj[part.to_i]
          elsif obj.is_a?(Hash)
            obj[part] || obj[part.to_sym]
          else
            nil
          end
  end
  obj
end

def read_source(path)
  return STDIN.read if path == '-'
  File.read(path)
rescue Errno::ENOENT
  warn "open #{path}: no such file or directory"
  exit 1
end

def row_hash(headers, values, opts)
  h = {}
  headers.each_with_index do |name, idx|
    v = values[idx]
    v = nil if !opts[:inull].nil? && v == opts[:inull]
    h[name] = v
  end
  h
end

def load_table(path, opts)
  path_only, json_path = path.to_s.split('::', 2)
  path_only = '-' if path_only.nil? || path_only.empty?
  fmt = guess_format(path, opts)
  text = read_source(path_only)
  rows = []
  headers = []

  case fmt
  when :ltsv
    text.each_line do |line|
      next if line.strip.empty?
      h = {}
      line.chomp.split("\t").each do |field|
        k, v = field.split(':', 2)
        h[k] = (!opts[:inull].nil? && v == opts[:inull]) ? nil : v
      end
      rows << h
    end
    headers = rows.flat_map(&:keys).uniq
  when :json
    data = text.lines.map(&:strip).reject(&:empty?)
    obj = if data.length > 1 && data.all? { |l| l.start_with?('{', '[') }
            data.map { |l| JSON.parse(l) }
          else
            JSON.parse(text)
          end
    obj = apply_json_path(obj, "::#{json_path}") if json_path
    if opts[:ijq] && opts[:ijq] =~ /\A\.?([A-Za-z_][\w.-]*)(?:\[\])?\z/
      obj = apply_json_path(obj, Regexp.last_match(1))
    end
    obj = [obj] unless obj.is_a?(Array)
    rows = obj.each_with_index.map do |item, idx|
      if item.is_a?(Hash)
        item.transform_keys(&:to_s).transform_values { |v| scalar(v) }
      elsif item.is_a?(Array)
        hs = {}
        item.each_with_index { |v, j| hs["c#{j + 1}"] = scalar(v) }
        hs
      else
        { 'c1' => scalar(item) }
      end
    end
    headers = rows.flat_map(&:keys).uniq
  when :yaml
    obj = YAML.safe_load(text, permitted_classes: [Date, Time], aliases: true)
    obj = [obj] unless obj.is_a?(Array)
    rows = obj.map do |item|
      item.is_a?(Hash) ? item.transform_keys(&:to_s).transform_values { |v| scalar(v) } : { 'c1' => scalar(item) }
    end
    headers = rows.flat_map(&:keys).uniq
  when :tbln
    text.each_line do |line|
      next if line.strip.empty? || line.start_with?('#')
      vals = line.chomp.split(/\s+/)
      headers = (1..vals.length).map { |n| "c#{n}" } if headers.empty?
      rows << row_hash(headers, vals, opts)
    end
  when :text
    headers = ['c1']
    text.each_line { |line| rows << { 'c1' => line.chomp } }
  else
    lines = text.lines.map(&:chomp)
    opts[:is].times { lines.shift }
    parsed = lines.map { |l| split_csv_line(l, opts[:id]) }
    if opts[:ih] && parsed.any?
      headers = parsed.shift.map(&:to_s)
    else
      max = parsed.map(&:length).max || 0
      headers = (1..max).map { |n| "c#{n}" }
    end
    parsed.each { |vals| rows << row_hash(headers, vals, opts) }
  end

  rows = rows.first(opts[:ilr]) if opts[:ilr].positive?
  if opts[:inum]
    headers = ['rowid'] + headers
    rows = rows.each_with_index.map { |r, idx| r.merge('rowid' => (idx + 1).to_s) }
  end
  [headers, rows]
end

def scalar(v)
  case v
  when NilClass then nil
  when String then v
  when Numeric, TrueClass, FalseClass then v.to_s
  else JSON.generate(v)
  end
end

def parse_query(sql, table_file)
  return { select: '*', table: table_file, where: nil, order: nil, desc: false, limit: nil } if table_file && sql.to_s.strip.empty?
  s = sql.to_s.strip.sub(/;\s*\z/, '')
  unless s =~ /\A\s*select\s+(.+?)\s+from\s+(.+)\z/im
    warn "syntax error: #{sql}"
    exit 1
  end
  select = Regexp.last_match(1).strip
  tail = Regexp.last_match(2).strip
  limit = nil
  if tail.sub!(/\s+limit\s+(\d+)\s*\z/i, '')
    limit = Regexp.last_match(1).to_i
  end
  order = nil
  desc = false
  if tail.sub!(/\s+order\s+by\s+(.+?)(?:\s+(asc|desc))?\s*\z/i, '')
    order = Regexp.last_match(1).strip
    desc = Regexp.last_match(2).to_s.downcase == 'desc'
  end
  where = nil
  if tail.sub!(/\s+where\s+(.+)\z/i, '')
    where = Regexp.last_match(1).strip
  end
  table = tail.strip.gsub(/\A[`'"]|[`'"]\z/, '')
  { select: select, table: table, where: where, order: order, desc: desc, limit: limit }
end

def split_list(str)
  out = []
  buf = +''
  quote = nil
  depth = 0
  str.each_char do |ch|
    if quote
      quote = nil if ch == quote
      buf << ch
    elsif ch == "'" || ch == '"'
      quote = ch
      buf << ch
    elsif ch == '('
      depth += 1
      buf << ch
    elsif ch == ')'
      depth -= 1 if depth.positive?
      buf << ch
    elsif ch == ',' && depth.zero?
      out << buf.strip
      buf.clear
    else
      buf << ch
    end
  end
  out << buf.strip unless buf.strip.empty?
  out
end

def value_for(row, expr)
  e = expr.to_s.strip
  e = e.gsub(/\A[`"]|[`"]\z/, '')
  return e[1...-1] if (e.start_with?("'") && e.end_with?("'")) || (e.start_with?('"') && e.end_with?('"'))
  if e =~ /\Acast\s*\(\s*([^)]+?)\s+as\s+\w+\s*\)\z/i
    return numeric_value(value_for(row, Regexp.last_match(1)))
  end
  return e if e =~ /\A-?\d+(?:\.\d+)?\z/
  row[e] || row[e.downcase] || row[e.upcase]
end

def numeric_value(v)
  s = v.to_s
  return s.to_f if s.include?('.')
  s.to_i
end

def compare_values(left, op, right)
  if left.to_s =~ /\A-?\d+(?:\.\d+)?\z/ && right.to_s =~ /\A-?\d+(?:\.\d+)?\z/
    l = left.to_s.to_f
    r = right.to_s.to_f
  else
    l = left.to_s
    r = right.to_s
  end
  case op
  when '=', '==' then l == r
  when '!=', '<>' then l != r
  when '>' then l > r
  when '<' then l < r
  when '>=' then l >= r
  when '<=' then l <= r
  else false
  end
end

def match_where?(row, where)
  return true if where.nil? || where.empty?
  parts = where.split(/\s+and\s+/i)
  parts.all? do |part|
    if part =~ /\A(.+?)\s+(not\s+)?like\s+(.+)\z/i
      val = value_for(row, Regexp.last_match(1)).to_s
      pat = Regexp.escape(value_for(row, Regexp.last_match(3)).to_s).gsub('%', '.*').gsub('_', '.')
      ok = /\A#{pat}\z/.match?(val)
      Regexp.last_match(2) ? !ok : ok
    elsif part =~ /\A(.+?)\s*(=|==|!=|<>|>=|<=|>|<)\s*(.+)\z/
      compare_values(value_for(row, Regexp.last_match(1)), Regexp.last_match(2), value_for(row, Regexp.last_match(3)))
    else
      !!value_for(row, part)
    end
  end
end

def project(headers, rows, select)
  sel = select.strip
  distinct = false
  if sel.sub!(/\Adistinct\s+/i, '')
    distinct = true
  end
  if sel =~ /\A(count|sum|avg|min|max)\s*\(\s*(\*|[^)]+)\s*\)\s*(?:as\s+(\w+))?\z/i
    func = Regexp.last_match(1).downcase
    arg = Regexp.last_match(2).strip
    name = Regexp.last_match(3) || "#{func}(#{arg})"
    vals = arg == '*' ? rows : rows.map { |r| value_for(r, arg) }.compact
    result = case func
             when 'count' then vals.length
             when 'sum' then vals.map { |v| numeric_value(v) }.sum
             when 'avg' then vals.empty? ? nil : vals.map { |v| numeric_value(v) }.sum.to_f / vals.length
             when 'min' then vals.min_by { |v| sort_key(v) }
             when 'max' then vals.max_by { |v| sort_key(v) }
             end
    result = result.to_i if result.is_a?(Float) && result == result.to_i
    return [[name], [{ name => result&.to_s }]]
  end
  return [headers, rows.map { |r| headers.to_h { |h| [h, r[h]] } }] if sel == '*'

  cols = split_list(sel).map do |part|
    if part =~ /\A(.+?)\s+as\s+([A-Za-z_][\w]*)\z/i
      [Regexp.last_match(1).strip, Regexp.last_match(2)]
    else
      [part, part.gsub(/\A[`"]|[`"]\z/, '')]
    end
  end
  out_headers = cols.map(&:last)
  out_rows = rows.map do |row|
    h = {}
    cols.each { |expr, name| h[name] = value_for(row, expr) }
    h
  end
  if distinct
    seen = {}
    out_rows = out_rows.select do |r|
      key = out_headers.map { |h| r[h] }
      !seen.key?(key).tap { seen[key] = true }
    end
  end
  [out_headers, out_rows]
end

def run_query(sql, opts)
  query = parse_query(sql, opts[:table_file])
  headers, rows = load_table(query[:table], opts)
  rows = rows.select { |r| match_where?(r, query[:where]) }
  if query[:order]
    rows = rows.sort_by { |r| sort_key(value_for(r, query[:order])) }
    rows.reverse! if query[:desc]
  end
  rows = rows.first(query[:limit]) if query[:limit]
  project(headers, rows, query[:select])
end

def sort_key(v)
  return [0, numeric_value(v)] if v.to_s =~ /\A-?\d+(?:\.\d+)?\z/
  [1, v.to_s]
end

def csv_string(values, opts)
  CSV.generate_line(values, col_sep: opts[:od], quote_char: opts[:oq], force_quotes: opts[:oaq]).chomp
end

def output_value(v, opts)
  v.nil? ? opts[:onull] : v.to_s
end

def render(headers, rows, opts)
  lines = []
  case opts[:output_format]
  when :json
    arr = rows.map { |r| headers.to_h { |h| [h, output_value(r[h], opts)] } }
    return JSON.pretty_generate(arr) + "\n"
  when :jsonl
    rows.each { |r| lines << JSON.generate(headers.to_h { |h| [h, output_value(r[h], opts)] }) }
  when :yaml
    arr = rows.map { |r| headers.to_h { |h| [h, output_value(r[h], opts)] } }
    return YAML.dump(arr)
  when :ltsv
    rows.each { |r| lines << headers.map { |h| "#{h}:#{output_value(r[h], opts)}" }.join("\t") }
  when :raw
    rows.each { |r| lines << headers.map { |h| output_value(r[h], opts) }.join(opts[:od]) }
  when :tbln
    rows.each { |r| lines << headers.map { |h| output_value(r[h], opts) }.join("\t") }
  when :md, :at
    lines = table_lines(headers, rows, opts[:output_format], opts)
  when :vf
    rows.each_with_index do |r, idx|
      lines << "*************************** #{idx + 1}. row ***************************"
      width = headers.map(&:length).max || 0
      headers.each { |h| lines << "#{h.rjust(width)}: #{output_value(r[h], opts)}" }
    end
  else
    lines << csv_string(headers, opts) if opts[:oh]
    rows.each { |r| lines << csv_string(headers.map { |h| output_value(r[h], opts) }, opts) }
  end
  eol = opts[:ocrlf] ? "\r\n" : "\n"
  lines.join(eol) + (lines.empty? ? '' : eol)
end

def table_lines(headers, rows, fmt, opts)
  widths = headers.map(&:length)
  vals = rows.map { |r| headers.map { |h| output_value(r[h], opts) } }
  vals.each { |ary| ary.each_with_index { |v, i| widths[i] = [widths[i], v.length].max } }
  center = ->(s, w) { s.to_s.center(w) }
  left = ->(s, w) { s.to_s.ljust(w) }
  if fmt == :md
    out = []
    out << '| ' + headers.each_with_index.map { |h, i| center.call(h, widths[i]) }.join(' | ') + ' |'
    out << '|-' + widths.map { |w| '-' * w }.join('-|-') + '-|'
    vals.each { |ary| out << '| ' + ary.each_with_index.map { |v, i| center.call(v, widths[i]) }.join(' | ') + ' |' }
    out
  else
    border = '+' + widths.map { |w| '-' * (w + 2) }.join('+') + '+'
    out = [border]
    out << '| ' + headers.each_with_index.map { |h, i| center.call(h, widths[i]) }.join(' | ') + ' |'
    out << border
    vals.each { |ary| out << '| ' + ary.each_with_index.map { |v, i| left.call(v, widths[i]) }.join(' | ') + ' |' }
    out << border
    out
  end
end

opts, sql = parse_args(ARGV)
sql = File.read(opts[:query_file]) if opts[:query_file]
if opts[:analyze]
  headers, = load_table(opts[:analyze], opts)
  puts "SELECT #{headers.join(',')} FROM #{opts[:analyze]}"
  exit 0
end
headers, rows = run_query(sql, opts)
out = render(headers, rows, opts)
if opts[:out]
  File.write(opts[:out], out)
else
  print out
end
