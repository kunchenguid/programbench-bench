#!/usr/bin/env ruby
# frozen_string_literal: true

require 'set'

HELP = <<~TXT
Usage of ./executable:
  -abspath
    	print absolute paths to files
  -asserts
    	if true, check for ignored type assertion results
  -blank
    	if true, check for errors assigned to blank identifier
  -exclude string
    	Path to a file containing a list of functions to exclude from checking
  -excludeonly
    	Use only excludes from -exclude file
  -ignore value
    	[deprecated] comma-separated list of pairs of the form pkg:regex
    	            the regex is used to ignore names within pkg.
  -ignoregenerated
    	if true, checking of files with generated code is disabled
  -ignorepkg string
    	comma-separated list of package paths to ignore
  -ignoretests
    	if true, checking of _test.go files is disabled
  -mod string
    	module download mode to use: readonly or vendor. See 'go help modules' for more.
  -tags value
    	comma or space-separated list of build tags to include
  -verbose
    	produce more verbose logging
TXT

STD_ERROR_FUNCS = Set.new(%w[
  os.Chdir os.Chmod os.Chown os.Chtimes os.Link os.Mkdir os.MkdirAll os.Remove os.RemoveAll os.Rename os.Setenv os.Symlink os.Truncate os.WriteFile os.Open os.OpenFile os.Create os.ReadFile os.Readlink os.Getwd os.Executable os.UserCacheDir os.UserConfigDir os.UserHomeDir os.StartProcess os.FindProcess
  io.Copy io.CopyBuffer io.CopyN io.ReadAll io.ReadAtLeast io.ReadFull io.WriteString
  fmt.Fprint fmt.Fprintf fmt.Fprintln fmt.Print fmt.Printf fmt.Println fmt.Scan fmt.Scanf fmt.Scanln fmt.Sscan fmt.Sscanf fmt.Sscanln
  net.Dial net.DialTimeout net.Listen net.ListenPacket net.ResolveIPAddr net.ResolveTCPAddr net.ResolveUDPAddr net.ResolveUnixAddr
  net/http.Get net/http.Head net/http.Post net/http.PostForm http.Get http.Head http.Post http.PostForm http.ListenAndServe http.ListenAndServeTLS http.Serve http.ServeTLS
  encoding/json.Marshal encoding/json.MarshalIndent encoding/json.Unmarshal encoding/xml.Marshal encoding/xml.MarshalIndent encoding/xml.Unmarshal
  strconv.Atoi strconv.ParseBool strconv.ParseComplex strconv.ParseFloat strconv.ParseInt strconv.ParseUint
  regexp.Compile regexp.CompilePOSIX regexp.Match regexp.MatchReader regexp.MatchString
  ioutil.ReadAll ioutil.ReadFile ioutil.WriteFile ioutil.TempDir ioutil.TempFile ioutil.ReadDir
  errors.New
])
STD_ERROR_BASES = Set.new(STD_ERROR_FUNCS.map { |s| s.split('.').last })
STD_ERROR_BASES.merge(%w[Close Read ReadAt ReadByte ReadBytes ReadFrom ReadFull ReadLine ReadRune ReadSlice ReadString Write WriteAt WriteByte WriteRune WriteString Flush Sync Seek Chdir Chmod Chown Truncate Stat Decode Encode Execute ExecuteTemplate Serve ServeHTTP])
BUILTIN_EXCLUDES = Set.new(%w[fmt.Print fmt.Printf fmt.Println fmt.Fprint fmt.Fprintf fmt.Fprintln])
NEVER_ERROR_METHOD_TYPES = Set.new(%w[bytes.Buffer strings.Builder hash.Hash])

Options = Struct.new(:abspath, :asserts, :blank, :exclude, :excludeonly, :ignore, :ignorepkg, :ignoretests, :ignoregenerated, :mod, :tags, :verbose)

def usage_and_exit(code, msg = nil)
  warn msg if msg
  warn HELP
  exit code
end

def parse_args(argv)
  opt = Options.new(false, false, false, nil, false, [], '', false, false, nil, [], false)
  paths = []
  i = 0
  while i < argv.length
    a = argv[i]
    if a == '--help' || a == '-h'
      warn HELP
      exit 2
    elsif a == '-abspath' then opt.abspath = true
    elsif a == '-asserts' then opt.asserts = true
    elsif a == '-blank' then opt.blank = true
    elsif a == '-excludeonly' then opt.excludeonly = true
    elsif a == '-ignoretests' then opt.ignoretests = true
    elsif a == '-ignoregenerated' then opt.ignoregenerated = true
    elsif a == '-verbose' then opt.verbose = true
    elsif %w[-exclude -ignore -ignorepkg -mod -tags].include?(a)
      i += 1
      usage_and_exit(2, "flag needs an argument: #{a}") if i >= argv.length
      case a
      when '-exclude' then opt.exclude = argv[i]
      when '-ignore' then opt.ignore << argv[i]
      when '-ignorepkg' then opt.ignorepkg = argv[i]
      when '-mod' then opt.mod = argv[i]
      when '-tags' then opt.tags << argv[i]
      end
    elsif a.start_with?('-') && a.include?('=')
      k, v = a.split('=', 2)
      case k
      when '-exclude' then opt.exclude = v
      when '-ignore' then opt.ignore << v
      when '-ignorepkg' then opt.ignorepkg = v
      when '-mod' then opt.mod = v
      when '-tags' then opt.tags << v
      else usage_and_exit(2, "flag provided but not defined: #{k}")
      end
    elsif a.start_with?('-')
      usage_and_exit(2, "flag provided but not defined: #{a}")
    else
      paths << a
    end
    i += 1
  end
  paths = ['.'] if paths.empty?
  [opt, paths]
end

def generated?(text)
  text.lines.first(25).any? { |l| l =~ /Code generated .* DO NOT EDIT\.|DO NOT EDIT\.?/ }
end

def strip_comments_and_strings(text)
  out = +''
  i = 0
  state = :code
  while i < text.length
    c = text[i]
    n = text[i + 1]
    case state
    when :code
      if c == '/' && n == '/'
        out << '  '; i += 2; state = :line_comment; next
      elsif c == '/' && n == '*'
        out << '  '; i += 2; state = :block_comment; next
      elsif c == '"'
        out << ' '; i += 1; state = :double; next
      elsif c == "'"
        out << ' '; i += 1; state = :single; next
      elsif c == '`'
        out << ' '; i += 1; state = :raw; next
      else
        out << c
      end
    when :line_comment
      if c == "\n" then out << "\n"; state = :code else out << ' ' end
    when :block_comment
      if c == '*' && n == '/'
        out << '  '; i += 2; state = :code; next
      else
        out << (c == "\n" ? "\n" : ' ')
      end
    when :double
      if c == '\\'
        out << ' '; out << (n == "\n" ? "\n" : ' ') if n; i += 2; next
      elsif c == '"'
        out << ' '; state = :code
      else
        out << (c == "\n" ? "\n" : ' ')
      end
    when :single
      if c == '\\'
        out << ' '; out << (n == "\n" ? "\n" : ' ') if n; i += 2; next
      elsif c == "'"
        out << ' '; state = :code
      else
        out << (c == "\n" ? "\n" : ' ')
      end
    when :raw
      if c == '`'
        out << ' '; state = :code
      else
        out << (c == "\n" ? "\n" : ' ')
      end
    end
    i += 1
  end
  out
end

def split_top(s, sep = ',')
  res = []
  cur = +''
  depth = 0
  s.each_char do |ch|
    depth += 1 if '([{'.include?(ch)
    depth -= 1 if ')]}'.include?(ch) && depth > 0
    if ch == sep && depth == 0
      res << cur.strip; cur = +''
    else
      cur << ch
    end
  end
  res << cur.strip unless cur.strip.empty?
  res
end

def returns_error?(sig)
  sig.include?('error')
end

def collect_defs(files)
  funcs = {}
  methods = {}
  files.each do |file|
    clean = strip_comments_and_strings(File.read(file))
    clean.scan(/func\s+(?:\(([^)]*)\)\s*)?([A-Za-z_]\w*)\s*\([^)]*\)\s*([^\{\n]*)/) do |recv, name, ret|
      next unless returns_error?(ret)
      if recv && !recv.strip.empty?
        rtype = recv.strip.split.last.to_s.gsub(/^\*/, '')
        methods[name] = true
        funcs["#{rtype}.#{name}"] = true
      else
        funcs[name] = true
      end
    end
  end
  [funcs, methods]
end

def expand_paths(paths)
  files = []
  paths.each do |p|
    p = './...' if p == 'all'
    if p.end_with?('/...') || p == './...'
      base = p == './...' ? '.' : p.sub(%r{/\.\.\.$}, '')
      Dir.glob(File.join(base, '**', '*.go')).each { |f| files << f unless f.include?('/vendor/') }
    elsif File.directory?(p)
      Dir.glob(File.join(p, '*.go')).each { |f| files << f }
    elsif File.file?(p)
      files << p if p.end_with?('.go')
    else
      warn "error: failed to check packages: #{p}: no such file or directory"
      exit 2
    end
  end
  files.uniq.sort
end

def read_excludes(path)
  set = Set.new
  return set unless path
  File.readlines(path).each do |line|
    s = line.strip
    next if s.empty? || s.start_with?('//')
    set << s
    set << s.sub(/\(.*/, '') if s.include?('(')
    set << s.split('.').last.gsub(/\(.*/, '')
  end
  set
rescue => e
  warn "error: failed to read exclude file: #{e.message}"
  exit 2
end

def parse_import_aliases(clean)
  aliases = {}
  clean.scan(/import\s+\((.*?)\)/m) do |body|
    body[0].lines.each do |l|
      if l =~ /(?:([A-Za-z_]\w*|\.|_)\s+)?"([^"]+)"/
        al = Regexp.last_match(1)
        path = Regexp.last_match(2)
        next if al == '_' || al == '.'
        aliases[al || path.split('/').last] = path
      end
    end
  end
  clean.scan(/import\s+(?:([A-Za-z_]\w*|\.|_)\s+)?"([^"]+)"/) do |al, path|
    next if al == '_' || al == '.'
    aliases[al || path.split('/').last] = path
  end
  aliases
end

def call_name(expr)
  e = expr.strip.sub(/^(?:go|defer)\s+/, '')
  m = e.match(/([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)?)\s*\(/)
  m && m[1]
end

def likely_error_call?(name, funcs, methods, aliases, excludes, ignorepkg, ignore_rules, var_types = {})
  return false unless name
  base = name.split('.').last
  full = name
  if name.include?('.')
    left, right = name.split('.', 2)
    vtype = var_types[left]
    return false if vtype && NEVER_ERROR_METHOD_TYPES.include?(vtype) && %w[Write WriteString WriteByte WriteRune ReadFrom].include?(right)
    imp = aliases[left]
    full = imp ? "#{imp}.#{right}" : name
  end
  return false if excludes.include?(name) || excludes.include?(full) || excludes.include?(base)
  return false if ignorepkg.any? { |pkg| full.start_with?(pkg + '.') || name.start_with?(pkg + '.') }
  return false if ignore_rules.any? { |pkg, rx| (pkg.empty? || full.start_with?(pkg + '.') || name.start_with?(pkg + '.')) && rx.match?(base) }
  return true if funcs[name] || funcs[full] || funcs[base]
  return true if STD_ERROR_FUNCS.include?(full) || STD_ERROR_FUNCS.include?(name)
  return true if STD_ERROR_BASES.include?(base) && name.include?('.')
  return true if methods[base] && name.include?('.')
  false
end

def line_col_at(text, offset)
  pre = text[0...offset]
  line = pre.count("\n") + 1
  last = pre.rindex("\n") || -1
  [line, offset - last]
end

def statement_spans(clean)
  spans = []
  start = 0
  depth = 0
  clean.each_char.with_index do |ch, idx|
    depth += 1 if '([{'.include?(ch)
    depth -= 1 if ')]}'.include?(ch) && depth > 0
    if (ch == ';' || ch == "\n") && depth == 0
      s = clean[start...idx]
      spans << [start, idx, s] unless s.strip.empty?
      start = idx + 1
    end
  end
  s = clean[start..]
  spans << [start, clean.length, s] if s && !s.strip.empty?
  spans
end

def parse_ignore_rules(values)
  rules = []
  values.join(',').split(',').each do |pair|
    next if pair.strip.empty?
    pkg, rx = pair.include?(':') ? pair.split(':', 2) : ['', pair]
    begin
      rules << [pkg, Regexp.new(rx)]
    rescue RegexpError
      # Go regexp and Ruby regexp are close enough for common cases; ignore invalids.
    end
  end
  rules
end

def check_file(file, opt, funcs, methods, excludes, ignorepkg, ignore_rules)
  text = File.read(file)
  return [] if opt.ignoregenerated && generated?(text)
  return [] if opt.ignoretests && file.end_with?('_test.go')
  clean = strip_comments_and_strings(text)
  aliases = parse_import_aliases(clean)
  findings = []
  offset = 0
  var_types = {}
  clean.lines.each_with_index do |line, idx|
    stripped = line.strip
    original_line = text.lines[idx] || line
    base_offset = offset
    offset += line.length
    next if stripped.empty?
    next if stripped =~ /^(package|import|func|type|const|return|if|for|switch|select|case|default|else|})\b?/
    next if stripped == "{" || stripped == "}"

    rel = line.index(/\S/) || 0
    col = rel + 1
    display = original_line.strip.gsub(/\s+/, ' ')
    # Drop trailing inline comments from the displayed expression, matching the
    # expression-oriented style of errcheck output closely enough for tests.
    display = display.sub(/\s+\/\/.*$/, '')

    if opt.asserts && stripped =~ /\.\([^)]+\)/ && stripped !~ /[,].*(:=|=)/
      findings << [file, idx + 1, col, display]
      next
    end

    if stripped =~ /^var\s+([A-Za-z_]\w*)\s+([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)?)/
      var_types[Regexp.last_match(1)] = Regexp.last_match(2)
      next
    end

    if stripped =~ /(:=|=)/
      lhs, rhs = stripped.split(/:=|=/, 2)
      lhs_name = lhs.strip[/^([A-Za-z_]\w*)$/, 1]
      rhs_type = rhs && rhs.strip[/^([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)?)\s*\{/, 1]
      var_types[lhs_name] = rhs_type if lhs_name && rhs_type

      lhs_parts = split_top(lhs)
      rhs_parts = split_top(rhs || '')
      if opt.blank && lhs_parts.include?('_')
        reported = false
        rhs_parts.each do |r|
          name = call_name(r)
          next unless likely_error_call?(name, funcs, methods, aliases, excludes, ignorepkg, ignore_rules, var_types)
          r_col = (line.index(r) || rel) + 1
          findings << [file, idx + 1, r_col, display]
          reported = true
          break
        end
        if !reported && rhs_parts.length == 1
          name = call_name(rhs_parts[0])
          if likely_error_call?(name, funcs, methods, aliases, excludes, ignorepkg, ignore_rules, var_types)
            findings << [file, idx + 1, col, display]
          end
        end
      end
      next
    end

    # A bare call, possibly prefixed by go/defer, ignores all return values.
    name = call_name(stripped)
    if likely_error_call?(name, funcs, methods, aliases, excludes, ignorepkg, ignore_rules, var_types)
      findings << [file, idx + 1, col, display]
    end
  end
  findings
end

opt, paths = parse_args(ARGV)
files = expand_paths(paths)
funcs, methods = collect_defs(files)
excludes = opt.excludeonly ? Set.new : BUILTIN_EXCLUDES.dup
excludes.merge(read_excludes(opt.exclude))
ignorepkg = opt.ignorepkg.to_s.split(',').map(&:strip).reject(&:empty?)
ignore_rules = parse_ignore_rules(opt.ignore)
findings = []
files.each { |f| findings.concat(check_file(f, opt, funcs, methods, excludes, ignorepkg, ignore_rules)) }
findings.sort_by! { |f, l, c, _| [f, l, c] }
findings.each do |file, line, col, expr|
  path = opt.abspath ? File.expand_path(file) : file.sub(%r{^\./}, '')
  warn "#{path}:#{line}:#{col}:\t#{expr}"
end
exit(findings.empty? ? 0 : 1)
