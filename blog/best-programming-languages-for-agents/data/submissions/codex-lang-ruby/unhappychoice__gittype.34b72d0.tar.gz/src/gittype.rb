#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'

VERSION = 'gittype 0.8.0'

ROOT_HELP_LONG = <<~TEXT.chomp
  GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. 

  Examples:
    gittype                           # Use current directory
    gittype /path/to/repo             # Use specific repository
    gittype --repo owner/repo         # Clone and use GitHub repository
    gittype --langs rust,python       # Filter by languages

  Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

  Commands:
    history   Show session history
    stats     Show analytics
    export    Export session data
    cache     Manage challenge cache
    repo      Manage repositories
    trending  Select and practice with trending repositories from GitHub
    help      Print this message or the help of the given subcommand(s)

  Arguments:
    [REPO_PATH]
            Repository path to extract code from

  Options:
        --repo <REPO>
            GitHub repository URL or path to clone and play with. Supports formats:
              - owner/repo
              - https://github.com/owner/repo
              - git@github.com:owner/repo.git

        --langs <LANGS>
            Filter by programming languages (comma-separated). Supported languages:
              rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig
              Example: --langs rust,python,typescript

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
TEXT

ROOT_HELP_SHORT = <<~TEXT.chomp
  A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)

  Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

  Commands:
    history   Show session history
    stats     Show analytics
    export    Export session data
    cache     Manage challenge cache
    repo      Manage repositories
    trending  Select and practice with trending repositories from GitHub
    help      Print this message or the help of the given subcommand(s)

  Arguments:
    [REPO_PATH]  Repository path to extract code from

  Options:
        --repo <REPO>    GitHub repository URL or path to clone and play with
        --langs <LANGS>  Filter by programming languages (comma-separated)
    -h, --help           Print help (see more with '--help')
    -V, --version        Print version
TEXT

CACHE_HELP = <<~TEXT.chomp
  Manage challenge cache

  Usage: executable cache <COMMAND>

  Commands:
    stats  Show cache statistics
    clear  Clear all cached challenges
    list   List cached repository keys
    help   Print this message or the help of the given subcommand(s)

  Options:
    -h, --help  Print help
TEXT

REPO_HELP = <<~TEXT.chomp
  Manage repositories

  Usage: executable repo <COMMAND>

  Commands:
    list   List all cached repositories
    clear  Clear all cached repositories
    play   Play a cached repository interactively
    help   Print this message or the help of the given subcommand(s)

  Options:
    -h, --help  Print help
TEXT

TRENDING_HELP = <<~TEXT.chomp
  Select and practice with trending repositories from GitHub

  Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]

  Arguments:
    [LANGUAGE]
            Programming language to filter trending repositories.
            Supported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig

    [REPO_NAME]
            Specific repository name to select from trending list

  Options:
        --period <PERIOD>
            Time period for trending (daily, weekly, monthly)
            
            [default: daily]

    -h, --help
            Print help (see a summary with '-h')
TEXT

SUB_HELP = {
  %w[history] => "Show session history\n\nUsage: executable history\n\nOptions:\n  -h, --help  Print help",
  %w[stats] => "Show analytics\n\nUsage: executable stats\n\nOptions:\n  -h, --help  Print help",
  %w[export] => "Export session data\n\nUsage: executable export [OPTIONS]\n\nOptions:\n      --format <FORMAT>  Export format [default: json]\n      --output <OUTPUT>  Output file path\n  -h, --help             Print help",
  %w[cache stats] => "Show cache statistics\n\nUsage: executable cache stats\n\nOptions:\n  -h, --help  Print help",
  %w[cache clear] => "Clear all cached challenges\n\nUsage: executable cache clear\n\nOptions:\n  -h, --help  Print help",
  %w[cache list] => "List cached repository keys\n\nUsage: executable cache list\n\nOptions:\n  -h, --help  Print help",
  %w[repo list] => "List all cached repositories\n\nUsage: executable repo list\n\nOptions:\n  -h, --help  Print help",
  %w[repo clear] => "Clear all cached repositories\n\nUsage: executable repo clear [OPTIONS]\n\nOptions:\n      --force  Force clear without confirmation\n  -h, --help   Print help",
  %w[repo play] => "Play a cached repository interactively\n\nUsage: executable repo play\n\nOptions:\n  -h, --help  Print help"
}.freeze

SUPPORTED_LANGS = {
  'rust' => 'rust', 'rs' => 'rust',
  'typescript' => 'typescript', 'ts' => 'typescript',
  'javascript' => 'javascript', 'js' => 'javascript',
  'python' => 'python', 'py' => 'python',
  'ruby' => 'ruby', 'rb' => 'ruby',
  'go' => 'go', 'swift' => 'swift',
  'kotlin' => 'kotlin', 'kt' => 'kotlin',
  'java' => 'java', 'php' => 'php',
  'csharp' => 'csharp', 'cs' => 'csharp', 'c#' => 'csharp',
  'c' => 'c', 'cpp' => 'cpp', 'c++' => 'cpp',
  'haskell' => 'haskell', 'hs' => 'haskell',
  'dart' => 'dart', 'scala' => 'scala', 'sc' => 'scala',
  'zig' => 'zig', 'clojure' => 'clojure', 'clj' => 'clojure',
  'cljs' => 'clojure'
}.freeze

COMMANDS = %w[history stats export cache repo trending help].freeze

def puts_and_exit(text, code = 0)
  puts text
  exit code
end

def parse_error(message, usage = nil, tip = nil)
  warn "error: #{message}"
  warn ''
  warn "  tip: #{tip}" if tip
  warn '' if tip
  warn usage if usage
  warn '' if usage
  warn "For more information, try '--help'."
  exit 2
end

def unsupported_langs(value)
  bad = value.to_s.split(',').map(&:strip).reject(&:empty?).reject { |l| SUPPORTED_LANGS.key?(l.downcase) }
  return if bad.empty?

  puts "❌ Unsupported language(s): #{bad.join(', ')}"
  puts '💡 Supported languages:'
  puts '   rust, rs, typescript, ts, javascript, js'
  puts '   python, py, ruby, rb, go, swift'
  puts '   kotlin, kt, java, php, csharp, cs'
  puts '   c#, c, cpp, c++, haskell, hs'
  puts '   dart, scala, sc, zig, clojure, clj'
  puts '   cljs'
  exit 1
end

def home
  ENV['HOME'] || Dir.home
end

def challenge_dirs
  [
    File.join(home, '.gittype', 'cache', 'challenges'),
    File.join(home, '.gittype', 'challenges'),
    File.join(home, '.cache', 'gittype', 'challenges')
  ]
end

def repo_dirs
  [
    File.join(home, '.gittype', 'repositories'),
    File.join(home, '.gittype', 'repos'),
    File.join(home, '.cache', 'gittype', 'repositories'),
    File.join(home, '.cache', 'gittype', 'repos')
  ]
end

def existing_files(dirs)
  dirs.select { |d| File.directory?(d) }.flat_map do |d|
    Dir.glob(File.join(d, '**', '*'), File::FNM_DOTMATCH).reject { |p| ['.', '..'].include?(File.basename(p)) }
  end
end

def dir_size(paths)
  paths.select { |p| File.file?(p) }.sum { |p| File.size(p) rescue 0 }
end

def terminal_error
  ts = Time.now.utc.strftime('%Y%m%d_%H%M%S')
  msg = 'Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)'
  body = <<~LOG
    ERROR OCCURRED AT: #{Time.now.utc.strftime('%Y-%m-%d %H:%M:%S UTC')}
    ERROR TYPE: "gittype::domain::error::GitTypeError"
    ERROR MESSAGE: #{msg}
    EXECUTABLE: "#{File.expand_path($PROGRAM_NAME)}"
    WORKING_DIR: "#{Dir.pwd}"
    COMMAND_ARGS: #{ARGV.unshift($PROGRAM_NAME).inspect}
    OS: linux
    ARCH: x86_64

  LOG
  log = "gittype_error_#{ts}.log"
  File.write(log, body) rescue nil
  FileUtils.mkdir_p(File.join(home, '.gittype', 'logs')) rescue nil
  File.write(File.join(home, '.gittype', 'logs', "gittype_#{ts}.log"), body) rescue nil
  puts "💾 Error details written to: #{log}"
  puts "Error: #{msg}"
  exit 1
end

def maybe_help!(args, path)
  return unless args.include?('-h') || args.include?('--help')

  text = case path
         when ['cache'] then CACHE_HELP
         when ['repo'] then REPO_HELP
         when ['trending'] then TRENDING_HELP
         else SUB_HELP[path]
         end
  puts_and_exit(text || ROOT_HELP_LONG)
end

def cache_command(args)
  puts_and_exit(CACHE_HELP, 2) if args.empty?
  maybe_help!(args, ['cache'])
  sub = args.shift
  case sub
  when 'help'
    if args.empty?
      puts_and_exit(CACHE_HELP)
    else
      maybe_help!(%w[--help], ['cache', args.first])
      parse_error("unrecognized subcommand '#{args.first}'", 'Usage: executable cache <COMMAND>')
    end
  when 'stats'
    maybe_help!(args, %w[cache stats])
    parse_error("unexpected argument '#{args.first}' found", 'Usage: executable cache stats') unless args.empty?
    files = existing_files(challenge_dirs)
    count = challenge_dirs.select { |d| File.directory?(d) }.sum { |d| Dir.children(d).size rescue 0 }
    puts 'Challenge Cache Statistics:'
    puts "  Cached repositories: #{count}"
    puts "  Total size: #{dir_size(files)} bytes"
  when 'list'
    maybe_help!(args, %w[cache list])
    parse_error("unexpected argument '#{args.first}' found", 'Usage: executable cache list') unless args.empty?
    entries = challenge_dirs.select { |d| File.directory?(d) }.flat_map { |d| Dir.children(d) rescue [] }.uniq
    entries.empty? ? puts('No cached challenges found.') : entries.sort.each { |e| puts e }
  when 'clear'
    maybe_help!(args, %w[cache clear])
    parse_error("unexpected argument '#{args.first}' found", 'Usage: executable cache clear') unless args.empty?
    challenge_dirs.each { |d| FileUtils.rm_rf(d) }
    puts 'Challenge cache cleared successfully.'
  else
    parse_error("unrecognized subcommand '#{sub}'", 'Usage: executable cache <COMMAND>')
  end
end

def repo_command(args)
  puts_and_exit(REPO_HELP, 2) if args.empty?
  maybe_help!(args, ['repo'])
  sub = args.shift
  case sub
  when 'help'
    if args.empty?
      puts_and_exit(REPO_HELP)
    else
      maybe_help!(%w[--help], ['repo', args.first])
      parse_error("unrecognized subcommand '#{args.first}'", 'Usage: executable repo <COMMAND>')
    end
  when 'clear'
    maybe_help!(args, %w[repo clear])
    args.delete('--force')
    parse_error("unexpected argument '#{args.first}' found", 'Usage: executable repo clear [OPTIONS]') unless args.empty?
    dirs = repo_dirs.select { |d| File.directory?(d) }
    if dirs.empty?
      puts 'No cached repositories directory found.'
    else
      dirs.each { |d| FileUtils.rm_rf(d) }
      puts 'Cached repositories cleared successfully.'
    end
  when 'list'
    maybe_help!(args, %w[repo list])
    parse_error("unexpected argument '#{args.first}' found", 'Usage: executable repo list') unless args.empty?
    terminal_error
  when 'play'
    maybe_help!(args, %w[repo play])
    parse_error("unexpected argument '#{args.first}' found", 'Usage: executable repo play') unless args.empty?
    terminal_error
  else
    parse_error("unrecognized subcommand '#{sub}'", 'Usage: executable repo <COMMAND>')
  end
end

def export_command(args)
  maybe_help!(args, ['export'])
  format = 'json'
  output = nil
  until args.empty?
    a = args.shift
    case a
    when '--format'
      parse_error("a value is required for '--format <FORMAT>' but none was supplied") if args.empty?
      format = args.shift
    when '--output'
      parse_error("a value is required for '--output <OUTPUT>' but none was supplied") if args.empty?
      output = args.shift
    else
      parse_error("unexpected argument '#{a}' found", 'Usage: executable export [OPTIONS]')
    end
  end
  puts '❌ Export command is not yet implemented'
  puts "💡 Requested format: #{format}"
  puts "💡 Requested output: #{output}" if output
  puts '💡 This feature is planned for a future release'
  exit 1
end

def trending_command(args)
  maybe_help!(args, ['trending'])
  period = 'daily'
  positional = []
  until args.empty?
    a = args.shift
    case a
    when '--period'
      parse_error("a value is required for '--period <PERIOD>' but none was supplied") if args.empty?
      period = args.shift
    when /^-/
      parse_error("unexpected argument '#{a}' found", 'Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]')
    else
      positional << a
    end
  end
  parse_error("unexpected argument '#{positional[2]}' found", 'Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]') if positional.size > 2
  repo_name = positional[1]
  if repo_name && repo_name !~ %r{\A[^/\s]+/[^/\s]+\z}
    puts "⚠️ Repository name must be in format 'owner/repo'"
    exit 0
  end
  terminal_error
end

def root_run(args)
  puts_and_exit(ROOT_HELP_LONG) if args == ['--help'] || args == ['help']
  puts_and_exit(ROOT_HELP_SHORT) if args == ['-h']
  puts_and_exit(VERSION) if args == ['--version'] || args == ['-V']

  repo = nil
  langs = nil
  remaining = []
  until args.empty?
    a = args.shift
    case a
    when '--repo'
      parse_error("a value is required for '--repo <REPO>' but none was supplied") if args.empty?
      repo = args.shift
    when '--langs'
      parse_error("a value is required for '--langs <LANGS>' but none was supplied") if args.empty?
      langs = args.shift
    when '--help'
      puts_and_exit(ROOT_HELP_LONG)
    when '-h'
      puts_and_exit(ROOT_HELP_SHORT)
    when '--version', '-V'
      puts_and_exit(VERSION)
    when /^-/
      parse_error("unexpected argument '#{a}' found", 'Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]', "to pass '#{a}' as a value, use '-- #{a}'")
    else
      remaining << a
      remaining.concat(args)
      break
    end
  end
  unsupported_langs(langs) if langs

  return terminal_error if remaining.empty? || repo

  cmd = remaining.shift
  case cmd
  when 'help'
    target = remaining
    return puts_and_exit(ROOT_HELP_LONG) if target.empty?
    case target[0]
    when 'cache'
      target[1] ? maybe_help!(%w[--help], ['cache', target[1]]) : puts_and_exit(CACHE_HELP)
    when 'repo'
      target[1] ? maybe_help!(%w[--help], ['repo', target[1]]) : puts_and_exit(REPO_HELP)
    when 'trending'
      puts_and_exit(TRENDING_HELP)
    when 'history', 'stats', 'export'
      maybe_help!(%w[--help], [target[0]])
    else
      parse_error("unrecognized subcommand '#{target[0]}'", 'Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]')
    end
  when 'history'
    maybe_help!(remaining, ['history'])
    parse_error("unexpected argument '#{remaining.first}' found", 'Usage: executable history') unless remaining.empty?
    puts '❌ History command is not yet implemented'
    puts '💡 This feature is planned for a future release'
    exit 1
  when 'stats'
    maybe_help!(remaining, ['stats'])
    parse_error("unexpected argument '#{remaining.first}' found", 'Usage: executable stats') unless remaining.empty?
    puts '❌ Stats command is not yet implemented'
    puts '💡 This feature is planned for a future release'
    exit 1
  when 'export'
    export_command(remaining)
  when 'cache'
    cache_command(remaining)
  when 'repo'
    repo_command(remaining)
  when 'trending'
    trending_command(remaining)
  else
    terminal_error
  end
end

root_run(ARGV.dup)
