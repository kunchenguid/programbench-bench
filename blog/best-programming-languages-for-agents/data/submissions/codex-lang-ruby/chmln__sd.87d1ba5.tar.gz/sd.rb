#!/usr/bin/env ruby
# frozen_string_literal: true

HELP_LONG = <<~TEXT
  sd v1.0.0
  An intuitive find & replace CLI

  Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

  Arguments:
    <FIND>
            The regexp or string (if using `-F`) to search for

    <REPLACE_WITH>
            What to replace each match with. Unless in string mode, you may use captured values like
            $1, $2, etc

    [FILES]...
            The path to file(s). This is optional - sd can also read from STDIN.
            
            Note: sd modifies files in-place by default. See documentation for examples.

  Options:
    -p, --preview
            Display changes in a human reviewable format (the specifics of the format are likely to
            change in the future)

    -F, --fixed-strings
            Treat FIND and REPLACE_WITH args as literal strings

    -n, --max-replacements <LIMIT>
            Limit the number of replacements that can occur per file. 0 indicates unlimited
            replacements
            
            [default: 0]

    -f, --flags <FLAGS>
            Regex flags. May be combined (like `-f mc`).
            
            c - case-sensitive
            
            e - disable multi-line matching
            
            i - case-insensitive
            
            m - multi-line matching
            
            s - make `.` match newlines
            
            w - match full words only

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
TEXT

HELP_SHORT = <<~TEXT
  sd v1.0.0
  An intuitive find & replace CLI

  Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

  Arguments:
    <FIND>          The regexp or string (if using `-F`) to search for
    <REPLACE_WITH>  What to replace each match with. Unless in string mode, you may use captured
                    values like $1, $2, etc
    [FILES]...      The path to file(s). This is optional - sd can also read from STDIN

  Options:
    -p, --preview                   Display changes in a human reviewable format (the specifics of the
                                    format are likely to change in the future)
    -F, --fixed-strings             Treat FIND and REPLACE_WITH args as literal strings
    -n, --max-replacements <LIMIT>  Limit the number of replacements that can occur per file. 0
                                    indicates unlimited replacements [default: 0]
    -f, --flags <FLAGS>             Regex flags. May be combined (like `-f mc`).
    -h, --help                      Print help (see more with '--help')
    -V, --version                   Print version
TEXT

def usage_for(required = false)
  if required
    "Usage: executable <FIND> <REPLACE_WITH> [FILES]..."
  else
    "Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]..."
  end
end

def die_usage(message, usage_required: false, tip: nil)
  warn "error: #{message}"
  warn ""
  warn "  tip: #{tip}" if tip
  warn "" if tip
  warn usage_for(usage_required)
  warn ""
  warn "For more information, try '--help'."
  exit 2
end

def parse_args(argv)
  opts = { preview: false, fixed: false, limit: 0, flags: +"" }
  positional = []
  parsing = true
  i = 0
  while i < argv.length
    arg = argv[i]
    if parsing && arg == "--"
      parsing = false
    elsif parsing && (arg == "-h")
      puts HELP_SHORT
      exit 0
    elsif parsing && (arg == "--help")
      puts HELP_LONG
      exit 0
    elsif parsing && (arg == "-V" || arg == "--version")
      puts "sd 1.0.0"
      exit 0
    elsif parsing && (arg == "-p" || arg == "--preview")
      opts[:preview] = true
    elsif parsing && (arg == "-F" || arg == "--fixed-strings")
      opts[:fixed] = true
    elsif parsing && (arg == "-n" || arg == "--max-replacements")
      i += 1
      die_usage("a value is required for '#{arg} <LIMIT>'") if i >= argv.length
      value = argv[i]
      unless value.match?(/\A\d+\z/)
        warn "error: invalid value '#{value}' for '--max-replacements <LIMIT>': invalid digit found in string"
        warn ""
        warn "For more information, try '--help'."
        exit 2
      end
      opts[:limit] = value.to_i
    elsif parsing && arg.start_with?("--max-replacements=")
      value = arg.split("=", 2)[1]
      unless value.match?(/\A\d+\z/)
        warn "error: invalid value '#{value}' for '--max-replacements <LIMIT>': invalid digit found in string"
        warn ""
        warn "For more information, try '--help'."
        exit 2
      end
      opts[:limit] = value.to_i
    elsif parsing && (arg == "-f" || arg == "--flags")
      i += 1
      die_usage("a value is required for '#{arg} <FLAGS>'") if i >= argv.length
      opts[:flags] << argv[i]
    elsif parsing && arg.start_with?("--flags=")
      opts[:flags] << arg.split("=", 2)[1]
    elsif parsing && arg.start_with?("-")
      die_usage("unexpected argument '#{arg}' found", tip: "to pass '#{arg}' as a value, use '-- #{arg}'")
    else
      positional << arg
    end
    i += 1
  end

  missing = []
  missing << "  <FIND>" if positional.length < 1
  missing << "  <REPLACE_WITH>" if positional.length < 2
  unless missing.empty?
    warn "error: the following required arguments were not provided:"
    missing.each { |m| warn m }
    warn ""
    warn usage_for(true)
    warn ""
    warn "For more information, try '--help'."
    exit 2
  end

  [opts, positional[0], positional[1], positional[2..] || []]
end

def translate_regex(pattern, flags)
  pattern = pattern.gsub(/\(\?P<([A-Za-z_][A-Za-z0-9_]*)>/, "(?<\\1>")
  pattern = "(?:\\b(?:#{pattern})\\b)" if flags.include?("w")
  pattern = disable_line_anchors(pattern) if flags.include?("e") && !flags.include?("m")
  pattern
end

def disable_line_anchors(pattern)
  out = +""
  escaped = false
  in_class = false
  pattern.each_char.with_index do |ch, idx|
    if escaped
      out << ch
      escaped = false
      next
    end
    if ch == "\\"
      out << ch
      escaped = true
      next
    end
    if ch == "["
      in_class = true
      out << ch
      next
    end
    if ch == "]"
      in_class = false
      out << ch
      next
    end
    if !in_class && ch == "^"
      out << "\\A"
    elsif !in_class && ch == "$"
      out << (idx == pattern.length - 1 ? "\\z" : "\\Z")
    else
      out << ch
    end
  end
  out
end

def build_matcher(find, opts)
  if opts[:fixed]
    Regexp.new(Regexp.escape(find))
  else
    flags = opts[:flags]
    pattern = translate_regex(find, flags)
    options = 0
    options |= Regexp::IGNORECASE if flags.include?("i") && !flags.include?("c")
    options |= Regexp::MULTILINE if flags.include?("s")
    Regexp.new(pattern, options)
  end
rescue RegexpError => e
  warn "error: invalid regex #{e.message}"
  exit 1
end

def expand_replacement(template, match, fixed)
  return template if fixed

  out = +""
  i = 0
  while i < template.length
    ch = template[i]
    if ch != "$"
      out << ch
      i += 1
      next
    end

    nxt = template[i + 1]
    if nxt == "$"
      out << "$"
      i += 2
    elsif nxt == "{"
      close = template.index("}", i + 2)
      if close
        name = template[(i + 2)...close]
        out << capture_value(match, name)
        i = close + 1
      else
        out << "$"
        i += 1
      end
    elsif nxt&.match?(/[0-9]/)
      j = i + 1
      j += 1 while j < template.length && template[j].match?(/[0-9]/)
      out << capture_value(match, template[(i + 1)...j])
      i = j
    elsif nxt&.match?(/[A-Za-z_]/)
      j = i + 1
      j += 1 while j < template.length && template[j].match?(/[A-Za-z0-9_]/)
      out << capture_value(match, template[(i + 1)...j])
      i = j
    else
      out << "$"
      i += 1
    end
  end
  out
end

def capture_value(match, key)
  if key.match?(/\A\d+\z/)
    match[key.to_i] || ""
  else
    begin
      match[key] || ""
    rescue IndexError
      ""
    end
  end
end

def replace_content(content, regex, replacement, opts)
  limit = opts[:limit]
  count = 0
  content.gsub(regex) do
    if limit.positive? && count >= limit
      Regexp.last_match[0]
    else
      count += 1
      expand_replacement(replacement, Regexp.last_match, opts[:fixed])
    end
  end
end

opts, find, replacement, files = parse_args(ARGV)
regex = build_matcher(find, opts)

if files.empty?
  print replace_content(STDIN.read, regex, replacement, opts)
else
  files.each do |path|
    begin
      original = File.binread(path)
      changed = replace_content(original, regex, replacement, opts)
      if opts[:preview]
        puts "----- FILE #{path} -----" if files.length > 1
        print changed
      else
        File.binwrite(path, changed)
      end
    rescue SystemCallError => e
      warn "error: #{e.message}"
      exit 1
    end
  end
end
