#!/usr/bin/env ruby
require 'yaml'
require 'set'
require 'fileutils'

VERSION = 'dep-tree version v0.23.4'

HELP = <<~TXT

        ____         _ __       _
       |  _ \\   ___ |  _ \\    _| |_  _ __  ___   ___
       | | | | / _ \\| |_) |  |_   _||  __|/ _ \\ / _ \\
       | |_| ||  __/| .__/     | |  | |  |  __/|  __/
       |____/  \\__| |_|        | \\__|_|   \\___| \\___|

  Usage:
    dep-tree [command]

  Examples:
  $ dep-tree src/index.ts
  $ dep-tree entropy src/index.ts
  $ dep-tree tree package/main.py --unwrap-exports
  $ dep-tree check

  Visualize your dependencies graphically
    entropy     (default) Renders a 3d force-directed graph in the browser
    tree        Render the dependency tree starting from the provided entrypoint

  Check your dependencies against your own rules
    check       Checks that the dependency rules defined in the configuration file are not broken

  Display what are the dependencies between two portions of code
    explain     Shows all the dependencies between two parts of the code

  Additional Commands:
    config      Generates a sample config in case that there's not already one present
    help        Help about any command

  Flags:
    -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
        --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)
        --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
        --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
        --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
        --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
        --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
    -h, --help                                 help for dep-tree
    -v, --version                              version for dep-tree

  Use "dep-tree [command] --help" for more information about a command.
TXT

CONFIG_SAMPLE = <<~YML
  # Files that should be completely ignored by dep-tree. It's fine to ignore
  # some big files that everyone depends on and that don't add
  # value to the visualization, like auto generated code.
  exclude:
    - 'some-glob-pattern/**/*.ts'

  # The only files that will be included by dep-tree. If a file does not
  # match any of the provided patters, it is ignored.
  only:
    - 'some-glob-pattern/**/*.ts'

  # Whether to unwrap re-exports to the target file or not.
  unwrapExports: false

  check:
    entrypoints:
      - src/index.ts
    allowCircularDependencies: false
    allow:
      'src/products/**':
        - 'src/products/**'
        - 'src/helpers/**'
      'src/users/**':
        to:
         - 'src/helpers/**'
        reason: The Users domain is only allowed to import helper code, nothing else
    deny:
      'src/products/**':
        - 'src/users/**'
      'src/users/**':
        - to: 'src/products/**'
          reason: The Users domain should not import anything from the Products domain
        - to: 'src/orders/**'
          reason: The Users domain should not import anything from the Orders domain
    aliases:
      'common':
        - 'src/helpers/**'
        - 'src/utils/**'
        - 'src/generated/**'
  js:
    workspaces: true
    tsConfigPaths: true
  python:
    excludeConditionalImports: false
  rust:
YML

def command_help(cmd)
  case cmd
  when 'tree'
    "Render the dependency tree starting from the provided entrypoint\n\nUsage:\n  dep-tree tree [flags]\n\nFlags:\n  -h, --help   help for tree\n      --json   render the dependency tree in a machine readable json format\n\nGlobal Flags:\n  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)\n      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.\n      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)\n      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)\n      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.\n      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)\n      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)\n"
  when 'check'
    "Checks that the dependency rules defined in the configuration file are not broken\n\nUsage:\n  dep-tree check [flags]\n\nFlags:\n  -h, --help   help for check\n\nGlobal Flags:\n  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)\n      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.\n      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)\n      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)\n      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.\n      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)\n      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)\n"
  when 'explain'
    "Shows all the dependencies between two parts of the code\n\nUsage:\n  dep-tree explain [flags]\n\nFlags:\n  -h, --help            help for explain\n  -l, --overlap-left    When there's an overlap between the files at the left and the right, keep the ones at the left\n  -r, --overlap-right   When there's an overlap between the files at the left and the right, keep the ones at the right\n\nGlobal Flags:\n  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)\n      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.\n      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)\n      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)\n      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.\n      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)\n      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)\n"
  when 'config', 'init'
    "Generates a sample config in case that there's not already one present\n\nUsage:\n  dep-tree config [flags]\n\nAliases:\n  config, init\n\nFlags:\n  -h, --help   help for config\n\nGlobal Flags:\n  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)\n      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.\n      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)\n      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)\n      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.\n      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)\n      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)\n"
  else
    HELP
  end
end

class App
  EXTENSIONS = %w[.ts .tsx .js .jsx .mjs .cjs .py .go .rs]

  def initialize(argv)
    @argv = argv.dup
    @opts = { config: '.dep-tree.yml', only: [], exclude: [], py_exclude_cond: false }
    @root = find_root(Dir.pwd)
  end

  def run
    return puts HELP if @argv.empty? || @argv.include?('--help') && !%w[tree check explain config init].include?(@argv[0])
    return puts VERSION if @argv.delete('--version') || @argv.delete('-v')
    cmd = @argv.shift
    cmd = 'entropy' if cmd.nil?
    if @argv.include?('--help') || @argv.include?('-h') || cmd == 'help'
      return puts(command_help(cmd == 'help' ? @argv[0] : cmd))
    end
    parse_global!
    case cmd
    when 'tree' then tree_cmd
    when 'entropy' then tree_cmd
    when 'check' then check_cmd
    when 'explain' then explain_cmd
    when 'config', 'init' then config_cmd
    else
      @argv.unshift(cmd)
      tree_cmd
    end
  rescue => e
    warn "Error: #{e.message}"
    exit 1
  end

  def parse_global!
    out = []
    i = 0
    while i < @argv.length
      a = @argv[i]
      case a
      when '-c', '--config'
        @opts[:config] = @argv[i + 1]; i += 2
      when '--only'
        @opts[:only] << @argv[i + 1]; i += 2
      when '--exclude'
        @opts[:exclude] << @argv[i + 1]; i += 2
      when '--python-exclude-conditional-imports'
        @opts[:py_exclude_cond] = true; i += 1
      when '--unwrap-exports', '--js-tsconfig-paths', '--js-workspaces'
        i += 1
      else
        out << a; i += 1
      end
    end
    @argv = out
    merge_config
  end

  def merge_config
    path = File.expand_path(@opts[:config], Dir.pwd)
    return unless File.file?(path)
    cfg = YAML.load_file(path) || {}
    @config = cfg
    @config_dir = File.dirname(path)
    @opts[:only] += Array(cfg['only'])
    @opts[:exclude] += Array(cfg['exclude'])
    @opts[:py_exclude_cond] ||= cfg.dig('python', 'excludeConditionalImports') == true
  rescue
    @config = {}
  end

  def config_cmd
    path = File.expand_path(@opts[:config], Dir.pwd)
    if File.exist?(path)
      warn "Error: cannot generate config file, as one already exists in #{@opts[:config]}"
      exit 1
    end
    File.write(path, CONFIG_SAMPLE)
  end

  def tree_cmd
    json = @argv.delete('--json')
    entries = @argv.empty? ? [] : expand_args(@argv)
    raise 'accepts 1 arg(s), received 0' if entries.empty?
    graph = build_graph(entries)
    result = {}
    entries.each { |e| result[e] = nested(e, graph, Set.new) }
    if json
      puts JsonLite.pretty({ tree: result, circularDependencies: cycles(graph), errors: {} })
    else
      result.each { |k, v| print_tree(k, v, '') }
    end
  end

  def explain_cmd
    left_pat = @argv.shift or raise 'accepts 2 arg(s), received 0'
    right_pat = @argv.shift or raise 'accepts 2 arg(s), received 1'
    overlap_left = @argv.delete('--overlap-left') || @argv.delete('-l')
    overlap_right = @argv.delete('--overlap-right') || @argv.delete('-r')
    left = glob_files(left_pat).to_set
    right = glob_files(right_pat).to_set
    both = left & right
    right -= both if overlap_left
    left -= both if overlap_right
    entries = (left + right).to_a.sort
    graph = build_graph(entries)
    left.to_a.sort.each do |from|
      deps = graph[from] || []
      deps.each { |to| puts "#{from} -> #{to}" if right.include?(to) }
    end
  end

  def check_cmd
    check = (@config || {}).fetch('check', {})
    entries = Array(check['entrypoints'])
    raise 'no entrypoints were provided' if entries.empty?
    entries = expand_args(entries)
    graph = build_graph(entries)
    bad = []
    aliases = check.fetch('aliases', {})
    graph.each do |from, deps|
      deps.each do |to|
        check.fetch('allow', {}).each do |pat, rule|
          next unless glob_match?(pat, from)
          patterns, reason = rule_patterns(rule, aliases)
          unless patterns.any? { |p| glob_match?(p, to) }
            bad << [from, to, reason]
          end
        end
        check.fetch('deny', {}).each do |pat, rule|
          next unless glob_match?(pat, from)
          deny_rules(rule, aliases).each do |p, reason|
            bad << [from, to, reason] if glob_match?(p, to)
          end
        end
      end
    end
    unless check['allowCircularDependencies'] == true
      cycles(graph).each { |c| bad << [c.join(' -> '), c[0], 'Circular dependency'] }
    end
    if bad.any?
      warn "Error: Check failed, the following dependencies are not allowed:"
      bad.uniq.each do |from, to, reason|
        warn "- #{display_check_path(from)} -> #{display_check_path(to)}"
        warn "  #{reason}" if reason && !reason.empty?
      end
      exit 1
    end
  end

  def rule_patterns(rule, aliases)
    reason = nil
    vals = if rule.is_a?(Hash)
      reason = rule['reason']; Array(rule['to'])
    else
      Array(rule)
    end
    [expand_aliases(vals, aliases), reason]
  end

  def deny_rules(rule, aliases)
    Array(rule).flat_map do |r|
      if r.is_a?(Hash)
        expand_aliases([r['to']], aliases).map { |p| [p, r['reason']] }
      else
        expand_aliases([r], aliases).map { |p| [p, nil] }
      end
    end
  end

  def expand_aliases(vals, aliases)
    vals.flat_map { |v| aliases.key?(v) ? aliases[v] : v }.compact
  end

  def build_graph(entries)
    graph = {}
    queue = entries.dup
    seen = Set.new
    until queue.empty?
      f = queue.shift
      next if seen.include?(f)
      seen << f
      deps = parse_file(f).select { |d| allowed?(d) }.uniq.sort
      graph[f] = deps
      deps.each { |d| queue << d unless seen.include?(d) }
    end
    graph
  end

  def nested(file, graph, stack)
    return nil if stack.include?(file)
    deps = graph[file] || []
    return nil if deps.empty?
    deps.to_h { |d| [d, nested(d, graph, stack + [file])] }
  end

  def cycles(graph)
    found = []
    visit = lambda do |n, stack|
      if (idx = stack.index(n))
        found << stack[idx..] + [n]
        return
      end
      (graph[n] || []).each { |d| visit.call(d, stack + [n]) }
    end
    graph.keys.each { |k| visit.call(k, []) }
    found.map { |c| c.rotate(c.index(c.min)) }.uniq
  end

  def reachable_edges(from, graph, seen = Set.new)
    return [] if seen.include?(from)
    seen << from
    direct = graph[from] || []
    (direct + direct.flat_map { |d| reachable_edges(d, graph, seen) }).uniq
  end

  def parse_file(rel)
    abs = File.join(@root, rel)
    return [] unless File.file?(abs)
    text = File.read(abs)
    case File.extname(abs)
    when '.py' then parse_python(rel, text)
    when '.js', '.jsx', '.ts', '.tsx', '.mjs', '.cjs' then parse_js(rel, text)
    when '.go' then parse_go(rel, text)
    when '.rs' then parse_rust(rel, text)
    else []
    end
  end

  def parse_python(rel, text)
    base = File.dirname(rel)
    out = []
    text.each_line do |line|
      next if @opts[:py_exclude_cond] && line =~ /^\s+/
      s = line.sub(/#.*/, '').strip
      if s =~ /^import\s+(.+)/
        $1.split(',').each { |m| out << resolve_py(m.strip.split(/\s+as\s+/).first, base, 0, nil) }
      elsif s =~ /^from\s+([.\w]+)\s+import\s+(.+)/
        mod = $1; imports = $2
        dots = mod[/^\.+/].to_s.length
        name = mod.sub(/^\.+/, '')
        imports.split(',').each do |imp|
          part = imp.strip.split(/\s+as\s+/).first
          out << resolve_py(name, base, dots, part)
        end
      end
    end
    out.compact
  end

  def resolve_py(mod, base, dots, imported)
    dir = base
    (dots - 1).times { dir = File.dirname(dir) } if dots > 0
    parts = mod.to_s.empty? ? [] : mod.split('.')
    if imported && imported != '*'
          candidates = [File.join(dir, *parts) + '.py', File.join(dir, *parts, "#{imported}.py"), File.join(dir, *parts, imported, '__init__.py'), File.join(dir, *parts, '__init__.py')]
    else
      candidates = [File.join(dir, *parts) + '.py', File.join(dir, *parts, '__init__.py')]
    end
    candidates.map { |c| normalize(c) }.find { |c| File.file?(File.join(@root, c)) }
  end

  def parse_js(rel, text)
    base = File.dirname(rel)
    specs = []
    text.scan(/(?:import|export)\s+(?:[^'"]*?\s+from\s+)?['"]([^'"]+)['"]/) { |m| specs << m[0] }
    text.scan(/require\(\s*['"]([^'"]+)['"]\s*\)/) { |m| specs << m[0] }
    specs.filter_map { |s| s.start_with?('.', '/') ? resolve_path(base, s, %w[.ts .tsx .js .jsx .mjs .cjs]) : resolve_node(s) }
  end

  def parse_go(rel, text)
    mod = nil
    gomod = File.join(@root, 'go.mod')
    mod = File.read(gomod)[/^module\s+(\S+)/, 1] if File.file?(gomod)
    imports = []
    text.scan(/import\s+"([^"]+)"/) { |m| imports << m[0] }
    text.scan(/import\s*\((.*?)\)/m) { |blk| blk[0].scan(/"([^"]+)"/) { |m| imports << m[0] } }
    imports.flat_map do |s|
      if s.start_with?('./', '../')
        dir = resolve_dir(File.dirname(rel), s)
      elsif mod && s.start_with?(mod + '/')
        dir = s.sub(/^#{Regexp.escape(mod)}\//, '')
      else
        next []
      end
      Dir.glob(File.join(@root, dir, '*.go')).reject { |p| File.basename(p).end_with?('_test.go') }.map { |p| relpath(p) }
    end
  end

  def parse_rust(rel, text)
    base = File.dirname(rel)
    out = []
    text.each_line do |line|
      s = line.sub(%r{//.*}, '').strip
      if s =~ /^(?:pub\s+)?mod\s+(\w+)\s*;/
        out << resolve_rust_mod(base, $1)
      elsif s =~ /^use\s+crate::([A-Za-z0-9_:]+)/
        first = $1.split('::').first
        out << resolve_rust_mod('.', first)
      elsif s =~ /^use\s+super::([A-Za-z0-9_:]+)/
        first = $1.split('::').first
        out << resolve_rust_mod(File.dirname(base), first)
      end
    end
    out.compact
  end

  def resolve_rust_mod(base, name)
    [File.join(base, "#{name}.rs"), File.join(base, name, 'mod.rs')].map { |c| normalize(c) }.find { |c| File.file?(File.join(@root, c)) }
  end

  def resolve_node(spec)
    # Workspaces and package aliases usually map package-name/path to a local directory.
    parts = spec.split('/')
    cands = []
    (1..parts.length).each { |i| cands << File.join(parts[0...i]) }
    cands.reverse_each do |dir|
      found = resolve_path('.', dir, %w[.ts .tsx .js .jsx .mjs .cjs])
      return found if found
    end
    nil
  end

  def resolve_path(base, spec, exts)
    p = spec.start_with?('/') ? spec.sub(%r{^/+}, '') : File.join(base, spec)
    p = normalize(p)
    candidates = [p]
    candidates += exts.map { |e| p + e } unless File.extname(p) != ''
    candidates += exts.map { |e| File.join(p, 'index' + e) }
    candidates.find { |c| File.file?(File.join(@root, c)) }
  end

  def resolve_dir(base, spec)
    normalize(File.join(base, spec))
  end

  def expand_args(args)
    args.flat_map { |a| glob_files(a).empty? ? [arg_to_rel(a)] : glob_files(a) }.uniq.sort
  end

  def glob_files(pattern)
    abs_pat = File.expand_path(pattern, Dir.pwd)
    Dir.glob(abs_pat, File::FNM_EXTGLOB).select { |p| File.file?(p) }.map { |p| relpath(p) }.select { |r| allowed?(r) }.sort
  end

  def allowed?(rel)
    return false if @opts[:only].any? && !@opts[:only].any? { |p| glob_match?(p, rel) }
    return false if @opts[:exclude].any? { |p| glob_match?(p, rel) }
    true
  end

  def glob_match?(pat, rel)
    candidates = [rel, cwd_relative(rel)]
    candidates.any? do |r|
      File.fnmatch?(pat, r, File::FNM_PATHNAME | File::FNM_EXTGLOB) || File.fnmatch?(pat, r, File::FNM_EXTGLOB)
    end
  end

  def cwd_relative(rel)
    cwd_rel = relpath(Dir.pwd)
    return rel if cwd_rel == '.' || cwd_rel.empty?
    rel.sub(%r{^#{Regexp.escape(cwd_rel)}/?}, '')
  end

  def display_check_path(rel)
    cfg_rel = @config_dir ? relpath(@config_dir) : '.'
    return rel if cfg_rel == '.' || cfg_rel.empty?
    rel.sub(%r{^#{Regexp.escape(cfg_rel)}/?}, '')
  end

  def arg_to_rel(arg)
    relpath(File.expand_path(arg, Dir.pwd))
  end

  def relpath(path)
    PathnameLike.relative(File.expand_path(path), @root)
  end

  def normalize(p)
    p.split('/').each_with_object([]) { |part, a| part == '..' ? a.pop : (a << part unless part == '.' || part == '') }.join('/')
  end

  def find_root(dir)
    cur = File.expand_path(dir)
    loop do
      return cur if File.directory?(File.join(cur, '.git'))
      parent = File.dirname(cur)
      return File.expand_path(dir) if parent == cur
      cur = parent
    end
  end

  def print_tree(k, v, prefix)
    puts "#{prefix}#{k}"
    return unless v
    v.each { |ck, cv| print_tree(ck, cv, prefix + '  ') }
  end
end

module PathnameLike
  def self.relative(path, root)
    path = path.sub(%r{^#{Regexp.escape(root)}/?}, '')
    path.empty? ? '.' : path
  end
end

module JsonLite
  def self.pretty(value, indent = 0)
    case value
    when Hash
      return '{}' if value.empty?
      inner = value.map { |k, v| "#{' ' * (indent + 2)}#{pretty(k)}: #{pretty(v, indent + 2)}" }.join(",\n")
      "{\n#{inner}\n#{' ' * indent}}"
    when Array
      return '[]' if value.empty?
      inner = value.map { |v| "#{' ' * (indent + 2)}#{pretty(v, indent + 2)}" }.join(",\n")
      "[\n#{inner}\n#{' ' * indent}]"
    when String
      '"' + value.gsub('\\', '\\\\').gsub('"', '\"').gsub("\n", '\n') + '"'
    when Symbol
      pretty(value.to_s)
    when NilClass
      'null'
    when TrueClass
      'true'
    when FalseClass
      'false'
    else
      value.to_s
    end
  end
end

App.new(ARGV).run
