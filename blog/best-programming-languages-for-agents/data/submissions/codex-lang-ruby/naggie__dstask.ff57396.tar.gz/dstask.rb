#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'securerandom'
require 'yaml'

ZERO_TIME = '0001-01-01T00:00:00Z'
STATUSES = %w[pending active paused resolved template].freeze
OPEN_STATUSES = %w[pending active paused].freeze
PRIORITY_RANK = { 'P0' => 0, 'P1' => 1, 'P2' => 2, 'P3' => 3 }.freeze

def repo
  ENV['DSTASK_GIT_REPO'] || File.join(Dir.home, '.dstask')
end

def ensure_repo
  return if Dir.exist?(repo)

  FileUtils.mkdir_p(repo)
  system('git', '-C', repo, 'init')
  puts
  puts 'Add a remote repository with:'
  puts
  puts "\tdstask git remote add origin <repo>"
  puts
end

def now
  t = Time.now.utc
  format('%s.%09dZ', t.strftime('%Y-%m-%dT%H:%M:%S'), t.nsec)
end

def parse_time(v)
  v.to_s
end

def yaml_path(status, uuid)
  File.join(repo, status, "#{uuid}.yml")
end

def write_task(task)
  STATUSES.each do |st|
    path = yaml_path(st, task['uuid'])
    FileUtils.rm_f(path) if st != task['status']
  end
  FileUtils.mkdir_p(File.join(repo, task['status']))
  data = {
    'summary' => task['summary'],
    'notes' => task['notes'] || '',
    'tags' => task['tags'] || [],
    'project' => task['project'] || '',
    'priority' => task['priority'] || 'P2',
    'delegatedto' => '',
    'subtasks' => [],
    'dependencies' => [],
    'created' => task['created'],
    'resolved' => task['resolved'] || ZERO_TIME,
    'due' => task['due'] || ZERO_TIME
  }
  File.write(yaml_path(task['status'], task['uuid']), YAML.dump(data))
end

def delete_task(task)
  FileUtils.rm_f(yaml_path(task['status'], task['uuid']))
end

def load_tasks
  tasks = []
  STATUSES.each do |st|
    Dir[File.join(repo, st, '*.yml')].sort.each do |path|
      y = YAML.safe_load(File.read(path), permitted_classes: [Time], aliases: true) || {}
      uuid = File.basename(path, '.yml')
      tasks << {
        'uuid' => uuid,
        'status' => st,
        'summary' => y['summary'].to_s,
        'notes' => y['notes'].to_s,
        'tags' => Array(y['tags']).map(&:to_s),
        'project' => y['project'].to_s,
        'priority' => (y['priority'] || 'P2').to_s,
        'created' => normalize_time(y['created']),
        'resolved' => normalize_time(y['resolved'] || ZERO_TIME),
        'due' => normalize_time(y['due'] || ZERO_TIME)
      }
    rescue StandardError
      next
    end
  end
  assign_ids(tasks)
end

def normalize_time(v)
  return ZERO_TIME if v.nil? || v == ''
  return v.utc.strftime('%Y-%m-%dT%H:%M:%SZ') if v.is_a?(Time)
  v.to_s
end

def assign_ids(tasks)
  open = tasks.select { |t| OPEN_STATUSES.include?(t['status']) }.sort_by { |t| [parse_time(t['created']), t['uuid']] }
  templates = tasks.select { |t| t['status'] == 'template' }.sort_by { |t| [parse_time(t['created']), t['uuid']] }
  open.each_with_index { |t, i| t['id'] = i + 1 }
  templates.each_with_index { |t, i| t['id'] = i + 1 }
  tasks.each { |t| t['id'] ||= 0 }
  tasks
end

def public_task(t)
  {
    'uuid' => t['uuid'],
    'status' => t['status'],
    'id' => t['id'],
    'summary' => t['summary'],
    'notes' => t['notes'] || '',
    'tags' => t['tags'] || [],
    'project' => t['project'] || '',
    'priority' => t['priority'] || 'P2',
    'created' => t['created'],
    'resolved' => t['resolved'] || ZERO_TIME,
    'due' => t['due'] || ZERO_TIME
  }
end

def print_json(tasks)
  puts pretty_json(tasks.map { |t| public_task(t) })
end

def json_escape(str)
  str.to_s.gsub(/["\\\b\f\n\r\t]/) do |c|
    case c
    when '"' then '\"'
    when '\\' then '\\\\'
    when "\b" then '\\b'
    when "\f" then '\\f'
    when "\n" then '\\n'
    when "\r" then '\\r'
    when "\t" then '\\t'
    end
  end
end

def pretty_json(value, indent = 0)
  sp = ' ' * indent
  case value
  when Array
    return '[]' if value.empty?

    "[\n" + value.map { |v| "#{' ' * (indent + 2)}#{pretty_json(v, indent + 2)}" }.join(",\n") + "\n#{sp}]"
  when Hash
    return '{}' if value.empty?

    "{\n" + value.map { |k, v| "#{' ' * (indent + 2)}\"#{json_escape(k)}\": #{pretty_json(v, indent + 2)}" }.join(",\n") + "\n#{sp}}"
  when String
    "\"#{json_escape(value)}\""
  when TrueClass then 'true'
  when FalseClass then 'false'
  when NilClass then 'null'
  else value.to_s
  end
end

def sort_tasks(tasks)
  tasks.sort_by { |t| [PRIORITY_RANK.fetch(t['priority'], 2), parse_time(t['created']), t['uuid']] }
end

def commit(message)
  system('git', '-C', repo, 'add', '-A')
  system('git', '-C', repo, 'commit', '-m', message)
end

def current_context
  return ENV['DSTASK_CONTEXT'] if ENV['DSTASK_CONTEXT'] && ENV['DSTASK_CONTEXT'] != ''

  path = File.join(repo, '.dstask-context')
  File.exist?(path) ? File.read(path).strip : ''
end

def context_filters
  current_context.split(/\s+/).reject(&:empty?)
end

def split_note(args)
  idx = args.index('/')
  return [args, ''] unless idx

  [args[0...idx], args[(idx + 1)..].join(' ')]
end

def parse_attrs(args)
  attrs = { add_tags: [], remove_tags: [], clear_project: false, text: [] }
  args.each do |a|
    case a
    when /^-project(?::.*)?/
      attrs[:clear_project] = true
    when /^\+(.+)/
      attrs[:add_tags] << Regexp.last_match(1)
    when /^-(.+)/
      attrs[:remove_tags] << Regexp.last_match(1)
    when /^project:(.*)/
      attrs[:project] = Regexp.last_match(1)
    when /^template:(\d+)$/
      attrs[:template] = Regexp.last_match(1).to_i
    when /^priority:(P[0-3])$/i, /^(P[0-3])$/i
      attrs[:priority] = Regexp.last_match(1).upcase
    when /^due:(\d{4}-\d{2}-\d{2})$/
      attrs[:due] = "#{Regexp.last_match(1)}T00:00:00Z"
    else
      attrs[:text] << a
    end
  end
  attrs
end

def apply_attrs(task, attrs)
  tags = task['tags'] || []
  tags |= attrs[:add_tags]
  tags -= attrs[:remove_tags]
  task['tags'] = tags
  task['project'] = attrs[:project] if attrs.key?(:project)
  task['project'] = '' if attrs[:clear_project]
  task['priority'] = attrs[:priority] if attrs[:priority]
  task['due'] = attrs[:due] if attrs[:due]
end

def add_like(args, status, label)
  args, note = split_note(args)
  attrs = parse_attrs(args + context_filters)
  summary = attrs[:text].join(' ').strip
  base = attrs[:template] ? find_template_by_id(attrs[:template]) : nil
  summary = base['summary'] if summary.empty? && base
  summary = 'Untitled' if summary.to_s.empty?
  task = if base
           base.merge('uuid' => SecureRandom.uuid, 'status' => status)
         else
           {
             'uuid' => SecureRandom.uuid,
             'status' => status,
             'summary' => summary,
             'notes' => note,
             'tags' => [],
             'project' => '',
             'priority' => 'P2',
             'created' => now,
             'resolved' => status == 'resolved' ? now : ZERO_TIME,
             'due' => ZERO_TIME
           }
         end
  task.merge!(
    'uuid' => SecureRandom.uuid,
    'status' => status,
    'summary' => summary,
    'notes' => note.empty? ? (task['notes'] || '') : note,
    'created' => now,
    'resolved' => status == 'resolved' ? now : ZERO_TIME,
    'due' => task['due'] || ZERO_TIME
  )
  apply_attrs(task, attrs)
  write_task(task)
  assign_ids(load_tasks)
  task = load_tasks.find { |t| t['uuid'] == task['uuid'] } || task
  msg = if status == 'template'
          "Created Template #{task['id']}: #{summary}"
        elsif status == 'resolved'
          "Logged #{summary}"
        else
          "Added #{task['id']}: #{summary}"
        end
  puts msg
  commit(msg)
end

def find_open_by_id(id)
  load_tasks.find { |t| OPEN_STATUSES.include?(t['status']) && t['id'] == id.to_i }
end

def find_template_by_id(id)
  load_tasks.find { |t| t['status'] == 'template' && t['id'] == id.to_i }
end

def selected_tasks(ids)
  ids.map do |id|
    t = find_open_by_id(id)
    unless t
      warn "\e[31mno open task with ID #{id} exists\e[0m"
      exit 1
    end
    t
  end
end

def filters_match?(task, filters)
  filters.all? do |f|
    case f
    when '--'
      true
    when /^\+(.+)/
      task['tags'].include?(Regexp.last_match(1))
    when /^-(.+)/
      !task['tags'].include?(Regexp.last_match(1))
    when /^project:(.*)/
      task['project'] == Regexp.last_match(1)
    when /^(P[0-3])$/i
      task['priority'] == Regexp.last_match(1).upcase
    when /^due:(\d{4}-\d{2}-\d{2})$/
      task['due'].start_with?(Regexp.last_match(1))
    else
      hay = "#{task['summary']} #{task['notes']}".downcase
      hay.include?(f.downcase)
    end
  end
end

def list_for(command, filters)
  tasks = load_tasks
  tasks = case command
          when 'show-resolved' then tasks.select { |t| t['status'] == 'resolved' }
          when 'show-active' then tasks.select { |t| t['status'] == 'active' }
          when 'show-paused' then tasks.select { |t| t['status'] == 'paused' }
          when 'show-templates' then tasks.select { |t| t['status'] == 'template' }
          when 'show-unorganised' then tasks.select { |t| OPEN_STATUSES.include?(t['status']) && t['tags'].empty? && t['project'].empty? }
          else tasks.select { |t| OPEN_STATUSES.include?(t['status']) }
          end
  active_filters = filters.include?('--') ? (filters - ['--']) : context_filters + filters
  tasks = tasks.select { |t| filters_match?(t, active_filters) }
  print_json(sort_tasks(tasks))
end

def transition(ids, status, verb, resolved = false)
  selected_tasks(ids).each do |task|
    task['status'] = status
    task['resolved'] = now if resolved
    write_task(task)
    msg = "#{verb} #{task['id']}: #{task['summary']}"
    puts msg
    commit(msg)
  end
end

def remove_tasks(ids)
  selected_tasks(ids).each do |task|
    puts "#{task['id']}: #{task['summary']}"
    puts
    delete_task(task)
    msg = "Removed: #{task['id']}: #{task['summary']}"
    puts msg
    commit(msg)
  end
end

def show_tags
  tags = []
  sort_tasks(load_tasks.select { |t| OPEN_STATUSES.include?(t['status']) }).each { |t| tags.concat(t['tags']) }
  puts tags.uniq.join("\n")
end

def show_projects
  projects = {}
  load_tasks.each do |t|
    next if t['project'].to_s.empty?

    p = (projects[t['project']] ||= { tasks: [], resolved: [] })
    (t['status'] == 'resolved' ? p[:resolved] : p[:tasks]) << t
  end
  out = projects.map do |name, p|
    all = p[:tasks] + p[:resolved]
    first = sort_tasks(all).first
    {
      'name' => name,
      'taskCount' => all.length,
      'resolvedCount' => p[:resolved].length,
      'active' => all.any? { |t| t['status'] == 'active' },
      'created' => first ? first['created'] : ZERO_TIME,
      'resolved' => p[:tasks].empty? && p[:resolved].any? ? p[:resolved].map { |t| t['resolved'] }.max : ZERO_TIME,
      'priority' => first ? first['priority'] : 'P2'
    }
  end
  puts pretty_json(out.sort_by { |p| [PRIORITY_RANK.fetch(p['priority'], 2), p['name']] })
end

HELP = <<~TXT
  Usage: dstask [id...] <cmd> [task summary/filter]

  Where [task summary] is text with tags/project/priority specified. Tags are
  specified with + (or - for filtering) eg: +work. The project is specified with
  a project:g prefix eg: project:dstask -- no quotes. Priorities run from P3
  (low), P2 (default) to P1 (high) and P0 (critical).

  Available commands:

  next              : Show most important tasks
  add               : Add a task
  template          : Add a task template
  log               : Log a task (already resolved)
  start             : Change task status to active
  note              : Append to or edit note for a task
  stop              : Change task status to pending
  done              : Resolve a task
  context           : Set global context
  modify            : Change task attributes specified on command line
  edit              : Edit task with text editor
  undo              : Undo last n commits
  sync              : Pull then push to git repository
  open              : Open all URLs found in summary/annotations
  git               : Pass a command to git in the repository
  remove            : Remove a task
  show-projects     : List projects with completion status
  show-tags         : List tags in use
  show-active       : Show tasks that have been started
  show-paused       : Show tasks that have been started then stopped
  show-open         : Show all non-resolved tasks
  show-resolved     : Show resolved tasks
  show-templates    : Show task templates
  show-unorganised  : Show untagged tasks with no projects
  bash-completion   : Print bash completion script to stdout
  fish-completion   : Print fish completion script to stdout
  zsh-completion    : Print zsh completion script to stdout
  help              : Get help on any command or show this message
  version           : Show dstask version information
TXT

def help(cmd = nil)
  case cmd
  when 'add'
    puts "Usage: dstask add [template:<id>] [task summary] [--]\nExample: dstask add Fix main web page 500 error +bug P1 project:website\n\nAdd a task, returning the git commit output which contains the task ID, used\nlater to reference the task."
  when 'modify'
    puts "Usage: dstask <id...> modify <filter>\nUsage: dstask modify <filter>\nExample: dstask 34 modify -work +home project:workbench -project:website\n\nModifiable attributes: tags, project and priority."
  else
    puts HELP
  end
end

def completions(shell)
  case shell
  when 'bash-completion'
    puts "# wire bash completions to dstask completion engine\n_dstask() { COMPREPLY=( $(dstask _completions \"${COMP_WORDS[@]}\") ); }\ncomplete -F _dstask dstask\ncomplete -F _dstask task"
  when 'zsh-completion'
    puts "#compdef dstask\n_dstask() { compadd -- $(dstask _completions \"${words[@]}\") }\ncompdef _dstask dstask"
  when 'fish-completion'
    puts 'complete -c dstask -f'
  else
    puts '[]'
  end
end

def main(argv)
  ensure_repo
  args = argv.dup
  ids = []
  while args.first =~ /^\d+$/
    ids << args.shift
  end
  cmd = args.shift || 'next'
  if cmd == '--'
    cmd = args.shift || 'next'
    args << '--'
  end
  if cmd =~ /^\d+$/ && args.any?
    ids << cmd
    cmd = args.shift
  end

  case cmd
  when 'help' then help(args.first)
  when 'version'
    puts "Version: Unknown\nGit commit: Unknown\nBuild date: Unknown"
  when '--help'
    list_for('next', args)
  when '--version', '-v'
    list_for('next', args)
  when 'bash-completion', 'zsh-completion', 'fish-completion', 'powershell-completion'
    completions(cmd)
  when '_completions'
    puts %w[next add template log start note stop done context modify edit undo sync open git remove show-projects show-tags show-active show-paused show-open show-resolved show-templates show-unorganised help version].join("\n")
  when 'add' then add_like(args.reject { |a| a == '--' }, 'pending', 'Added')
  when 'template' then add_like(args.reject { |a| a == '--' }, 'template', 'Created Template')
  when 'log' then add_like(args.reject { |a| a == '--' }, 'resolved', 'Logged')
  when 'show-open', 'next' then list_for('show-open', args)
  when 'show-resolved', 'show-active', 'show-paused', 'show-templates', 'show-unorganised'
    list_for(cmd, args)
  when 'show-tags' then show_tags
  when 'show-projects' then show_projects
  when 'start' then transition(ids.empty? ? args.take_while { |a| a =~ /^\d+$/ } : ids, 'active', 'Started')
  when 'stop' then transition(ids.empty? ? args.take_while { |a| a =~ /^\d+$/ } : ids, 'paused', 'Stopped')
  when 'done' then transition(ids.empty? ? args.take_while { |a| a =~ /^\d+$/ } : ids, 'resolved', 'Resolved', true)
  when 'remove' then remove_tasks(ids.empty? ? args.take_while { |a| a =~ /^\d+$/ } : ids)
  when 'modify'
    targets = ids.empty? ? load_tasks.select { |t| OPEN_STATUSES.include?(t['status']) && filters_match?(t, context_filters) } : selected_tasks(ids)
    attrs = parse_attrs(args)
    targets.each do |task|
      apply_attrs(task, attrs)
      write_task(task)
      msg = "Modified #{task['id']}: #{task['summary']}"
      puts msg
      commit(msg)
    end
  when 'context'
    if args.empty?
      puts current_context
    elsif args == ['none'] || args == ['--']
      FileUtils.rm_f(File.join(repo, '.dstask-context'))
    elsif args.any? { |a| !(a.start_with?('+', '-', 'project:') || a =~ /^P[0-3]$/i) }
      warn "\e[31mcontext cannot contain text\e[0m"
      exit 1
    else
      File.write(File.join(repo, '.dstask-context'), args.join(' '))
    end
  when 'git'
    exec('git', '-C', repo, *args)
  when 'sync'
    system('git', '-C', repo, 'pull')
    system('git', '-C', repo, 'push')
  when 'undo'
    n = (args.first || '1').to_i
    system('git', '-C', repo, 'reset', "--hard", "HEAD~#{n}")
  else
    list_for('show-open', [cmd] + args)
  end
end

main(ARGV)
