#!/usr/bin/env ruby
# frozen_string_literal: true

require 'json'
require 'net/http'
require 'uri'

HELP = <<~HELP
  Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable

  Usage:
    gron [OPTIONS] [FILE|URL|-]

  Options:
    -u, --ungron     Reverse the operation (turn assignments back into JSON)
    -v, --values     Print just the values of provided assignments
    -c, --colorize   Colorize output (default on tty)
    -m, --monochrome Monochrome (don't colorize output)
    -s, --stream     Treat each line of input as a separate JSON object
    -k, --insecure   Disable certificate validation
    -x, --proxy      Set proxy configuration
        --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.
    -j, --json       Represent gron data as JSON stream
        --no-sort    Don't sort output (faster)
        --version    Print version information

  Exit Codes:
    0	OK
    1	Failed to open file
    2	Failed to read input
    3	Failed to form statements
    4	Failed to fetch URL
    5	Failed to parse statements
    6	Failed to encode JSON

  Examples:
    gron /tmp/apiresponse.json
    gron http://jsonplaceholder.typicode.com/users/1 
    curl -s http://jsonplaceholder.typicode.com/users/1 | gron
    gron http://jsonplaceholder.typicode.com/users/1 | grep company | gron --ungron
HELP

OPTS = {
  ungron: false,
  values: false,
  color: nil,
  stream: false,
  insecure: false,
  proxy: nil,
  noproxy: nil,
  json: false,
  sort: true
}

def usage_error(flag)
  warn "flag provided but not defined: #{flag}"
  warn HELP
  exit 2
end

args = []
i = 0
while i < ARGV.length
  a = ARGV[i]
  case a
  when '-u', '--ungron' then OPTS[:ungron] = true
  when '-v', '--values' then OPTS[:values] = true
  when '-c', '--colorize' then OPTS[:color] = true
  when '-m', '--monochrome' then OPTS[:color] = false
  when '-s', '--stream' then OPTS[:stream] = true
  when '-k', '--insecure' then OPTS[:insecure] = true
  when '-j', '--json' then OPTS[:json] = true
  when '--no-sort' then OPTS[:sort] = false
  when '--version'
    puts 'gron version dev'
    exit 0
  when '-x', '--proxy'
    i += 1
    usage_error(a) if i >= ARGV.length
    OPTS[:proxy] = ARGV[i]
  when '--noproxy'
    i += 1
    usage_error(a) if i >= ARGV.length
    OPTS[:noproxy] = ARGV[i]
  when '--help', '-h'
    puts HELP
    exit 0
  else
    if a.start_with?('-') && a != '-'
      usage_error(a)
    else
      args << a
    end
  end
  i += 1
end

def read_input(arg)
  return STDIN.read if arg.nil? || arg == '-'

  if arg =~ %r{\Ahttps?://}
    uri = URI(arg)
    begin
      return Net::HTTP.get(uri)
    rescue StandardError => e
      warn e.message
      exit 4
    end
  end

  begin
    File.read(arg)
  rescue Errno::ENOENT
    warn "open #{arg}: no such file or directory"
    exit 1
  rescue StandardError => e
    warn e.message.sub(/\A.*? - /, '')
    exit 1
  end
end

def parse_json_text(text)
  if OPTS[:stream]
    arr = []
    text.each_line do |line|
      next if line.strip.empty?
      arr << JSON.parse(line)
    end
    arr
  else
    JSON.parse(text)
  end
rescue JSON::ParserError => e
  warn "failed to form statements: #{e.message.sub(/\A\d+: /, '')}"
  exit 3
end

def dot_key?(key)
  !!(/\A[$_\p{L}][$_\p{L}\p{N}]*\z/u =~ key)
end

def sorted_hash_keys(hash)
  keys = hash.keys
  return keys unless OPTS[:sort]

  keys.sort_by { |k| [dot_key?(k.to_s) ? 0 : 1, k.to_s] }
end

def each_statement(value, path = [], &block)
  yield path, value
  case value
  when Hash
    sorted_hash_keys(value).each { |k| each_statement(value[k], path + [k], &block) }
  when Array
    value.each_with_index { |v, idx| each_statement(v, path + [idx], &block) }
  end
end

def json_literal(value)
  JSON.generate(value)
end

def statement_value(value)
  case value
  when Hash then {}
  when Array then []
  else value
  end
end

def path_to_js(path)
  out = +'json'
  path.each do |part|
    if part.is_a?(Integer)
      out << "[#{part}]"
    elsif dot_key?(part.to_s)
      out << ".#{part}"
    else
      out << "[#{JSON.generate(part.to_s)}]"
    end
  end
  out
end

def colorize_line(line)
  return line unless OPTS[:color]

  line
end

def emit_gron(value)
  each_statement(value) do |path, val|
    puts colorize_line("#{path_to_js(path)} = #{json_literal(statement_value(val))};")
  end
rescue JSON::GeneratorError => e
  warn "failed to encode JSON: #{e.message}"
  exit 6
end

def emit_json_stream(value)
  each_statement(value) do |path, val|
    puts JSON.generate([path, statement_value(val)])
  end
rescue JSON::GeneratorError => e
  warn "failed to encode JSON: #{e.message}"
  exit 6
end

class StatementParser
  def initialize(text)
    @text = text
    @i = 0
  end

  def parse_all
    stmts = []
    until eof?
      skip_space
      break if eof?
      stmts << parse_statement
      skip_space
    end
    stmts
  end

  private

  def eof?
    @i >= @text.length
  end

  def peek
    @text[@i]
  end

  def skip_space
    @i += 1 while !eof? && @text[@i] =~ /\s/
  end

  def expect(str)
    raise 'parse error' unless @text[@i, str.length] == str
    @i += str.length
  end

  def parse_identifier
    start = @i
    @i += 1 while !eof? && @text[@i] =~ /[A-Za-z0-9_$\p{L}]/u
    raise 'parse error' if @i == start
    @text[start...@i]
  end

  def parse_statement
    skip_space
    expect('json')
    path = []
    loop do
      case peek
      when '.'
        @i += 1
        path << parse_identifier
      when '['
        @i += 1
        skip_space
        if peek == '"' || peek == "'"
          path << parse_string
        else
          start = @i
          @i += 1 while !eof? && @text[@i] =~ /\d/
          raise 'parse error' if @i == start
          path << @text[start...@i].to_i
        end
        skip_space
        expect(']')
      else
        break
      end
    end
    skip_space
    expect('=')
    start = @i
    in_str = false
    quote = nil
    esc = false
    until eof?
      ch = @text[@i]
      if in_str
        if esc
          esc = false
        elsif ch == '\\'
          esc = true
        elsif ch == quote
          in_str = false
        end
      elsif ch == '"' || ch == "'"
        in_str = true
        quote = ch
      elsif ch == ';'
        break
      end
      @i += 1
    end
    rhs = @text[start...@i].strip
    expect(';') if peek == ';'
    [path, JSON.parse(rhs)]
  rescue JSON::ParserError
    raise 'parse error'
  end

  def parse_string
    quote = peek
    if quote == '"'
      start = @i
      @i += 1
      esc = false
      until eof?
        ch = @text[@i]
        if esc
          esc = false
        elsif ch == '\\'
          esc = true
        elsif ch == '"'
          @i += 1
          return JSON.parse(@text[start...@i])
        end
        @i += 1
      end
      raise 'parse error'
    end

    @i += 1
    out = +''
    esc = false
    until eof?
      ch = @text[@i]
      @i += 1
      if esc
        out << ch
        esc = false
      elsif ch == '\\'
        esc = true
      elsif ch == "'"
        return out
      else
        out << ch
      end
    end
    raise 'parse error'
  end
end

def assign_path(root, path, value)
  return value if path.empty?

  root = path.first.is_a?(Integer) ? [] : {} if root.nil?
  cur = root
  path.each_with_index do |part, idx|
    last = idx == path.length - 1
    if last
      if cur.is_a?(Array)
        cur[part] = value
      else
        cur[part.to_s] = value
      end
    else
      nxt = path[idx + 1].is_a?(Integer) ? [] : {}
      if cur.is_a?(Array)
        cur[part] = nxt if cur[part].nil? || !(cur[part].is_a?(Array) || cur[part].is_a?(Hash))
        cur = cur[part]
      else
        key = part.to_s
        cur[key] = nxt if cur[key].nil? || !(cur[key].is_a?(Array) || cur[key].is_a?(Hash))
        cur = cur[key]
      end
    end
  end
  root
end

def parse_gron_statements(text)
  StatementParser.new(text).parse_all
rescue StandardError
  warn 'no statements were parsed'
  exit 5
end

def parse_json_stream_statements(text)
  stmts = []
  text.each_line do |line|
    next if line.strip.empty?
    pair = JSON.parse(line)
    stmts << [pair[0], pair[1]]
  end
  stmts
rescue StandardError
  warn 'no statements were parsed'
  exit 5
end

def ungron(text)
  stmts = OPTS[:json] ? parse_json_stream_statements(text) : parse_gron_statements(text)
  if stmts.empty?
    warn 'no statements were parsed'
    exit 5
  end
  root = nil
  stmts.each do |path, val|
    path = path.map { |p| p.is_a?(Numeric) ? p.to_i : p.to_s }
    root = assign_path(root, path, val)
  end
  root
end

def emit_values(text)
  stmts = OPTS[:json] ? parse_json_stream_statements(text) : parse_gron_statements(text)
  stmts.each do |_path, val|
    next if val.is_a?(Hash) || val.is_a?(Array)
    puts(val.nil? ? 'null' : val.to_s)
  end
end

input = read_input(args.first)

if OPTS[:values]
  emit_values(input)
elsif OPTS[:ungron]
  puts JSON.pretty_generate(ungron(input))
else
  data = parse_json_text(input)
  OPTS[:json] ? emit_json_stream(data) : emit_gron(data)
end
