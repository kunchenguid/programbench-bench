#!/usr/bin/env python3
import os
import re
import sys


VERSION = "sd 1.0.0"

HELP_LONG = """sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>
          The regexp or string (if using `-F`) to search for

  <REPLACE_WITH>
          What to replace each match with. Unless in string mode, you may use captured values like
          $1, $2, etc

  [FILES]...
          The path to file(s). This is optional - sd can also read from STDIN.
          
          Note: sd modifies files in-place by default. See documentation for examples.

Options:
  -p, --preview
          Display changes in a human reviewable format (the specifics of the format are likely to
          change in the future)

  -F, --fixed-strings
          Treat FIND and REPLACE_WITH args as literal strings

  -n, --max-replacements <LIMIT>
          Limit the number of replacements that can occur per file. 0 indicates unlimited
          replacements
          
          [default: 0]

  -f, --flags <FLAGS>
          Regex flags. May be combined (like `-f mc`).
          
          c - case-sensitive
          
          e - disable multi-line matching
          
          i - case-insensitive
          
          m - multi-line matching
          
          s - make `.` match newlines
          
          w - match full words only

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

HELP_SHORT = """sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>          The regexp or string (if using `-F`) to search for
  <REPLACE_WITH>  What to replace each match with. Unless in string mode, you may use captured
                  values like $1, $2, etc
  [FILES]...      The path to file(s). This is optional - sd can also read from STDIN

Options:
  -p, --preview                   Display changes in a human reviewable format (the specifics of the
                                  format are likely to change in the future)
  -F, --fixed-strings             Treat FIND and REPLACE_WITH args as literal strings
  -n, --max-replacements <LIMIT>  Limit the number of replacements that can occur per file. 0
                                  indicates unlimited replacements [default: 0]
  -f, --flags <FLAGS>             Regex flags. May be combined (like `-f mc`).
  -h, --help                      Print help (see more with '--help')
  -V, --version                   Print version
"""


class UsageError(Exception):
    def __init__(self, msg, code=2):
        super().__init__(msg)
        self.code = code


def usage_line():
    return "Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]..."


def parse_args(argv):
    opts = {"preview": False, "fixed": False, "limit": 0, "flags": ""}
    pos = []
    i = 0
    end_flags = False
    while i < len(argv):
        arg = argv[i]
        if end_flags:
            pos.append(arg)
        elif arg == "--":
            end_flags = True
        elif arg in ("-h", "--help"):
            print(HELP_SHORT if arg == "-h" else HELP_LONG, end="")
            raise SystemExit(0)
        elif arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        elif arg in ("-p", "--preview"):
            opts["preview"] = True
        elif arg in ("-F", "--fixed-strings"):
            opts["fixed"] = True
        elif arg in ("-n", "--max-replacements"):
            i += 1
            if i >= len(argv):
                raise UsageError(f"error: a value is required for '{arg} <LIMIT>' but none was supplied")
            try:
                opts["limit"] = int(argv[i])
            except ValueError:
                raise UsageError(f"error: invalid value '{argv[i]}' for '{arg} <LIMIT>': invalid digit found in string")
        elif arg.startswith("--max-replacements="):
            val = arg.split("=", 1)[1]
            try:
                opts["limit"] = int(val)
            except ValueError:
                raise UsageError(f"error: invalid value '{val}' for '--max-replacements <LIMIT>': invalid digit found in string")
        elif arg in ("-f", "--flags"):
            i += 1
            if i >= len(argv):
                raise UsageError(f"error: a value is required for '{arg} <FLAGS>' but none was supplied")
            opts["flags"] += argv[i]
        elif arg.startswith("--flags="):
            opts["flags"] += arg.split("=", 1)[1]
        elif arg.startswith("-") and arg != "-":
            tip = ""
            if not pos:
                tip = f"\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'"
            raise UsageError(f"error: unexpected argument '{arg}' found{tip}\n\n{usage_line()}\n\nFor more information, try '--help'.")
        else:
            pos.append(arg)
        i += 1
    if len(pos) < 2:
        missing = ["  <FIND>", "  <REPLACE_WITH>"][len(pos):]
        raise UsageError("error: the following required arguments were not provided:\n" + "\n".join(missing) + f"\n\nUsage: executable <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.")
    return opts, pos[0], pos[1], pos[2:]


def convert_pattern(pattern):
    # The Rust regex crate accepts (?P<name>...), while Python accepts it too.
    # It also accepts (?<name>...), which Python spells differently.
    return re.sub(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>", r"(?P<\1>", pattern)


def compile_regex(find, flags_spec):
    pyflags = 0
    if "e" not in flags_spec:
        pyflags |= re.MULTILINE
    if "s" in flags_spec:
        pyflags |= re.DOTALL
    ignore = False
    for ch in flags_spec:
        if ch == "i":
            ignore = True
        elif ch == "c":
            ignore = False
    if ignore:
        pyflags |= re.IGNORECASE
    pat = convert_pattern(find)
    if "w" in flags_spec:
        pat = r"\b(?:" + pat + r")\b"
    try:
        return re.compile(pat, pyflags)
    except re.error as e:
        sys.stderr.write(f"error: invalid regex {e}\n")
        raise SystemExit(1)


def expand_replacement(template, match):
    out = []
    i = 0
    n = len(template)
    while i < n:
        ch = template[i]
        if ch != "$":
            out.append(ch)
            i += 1
            continue
        if i + 1 >= n:
            out.append("$")
            i += 1
            continue
        nxt = template[i + 1]
        if nxt == "$":
            out.append("$")
            i += 2
            continue
        if nxt == "{":
            j = template.find("}", i + 2)
            if j == -1:
                out.append("$")
                i += 1
                continue
            name = template[i + 2:j]
            out.append(group_value(match, name))
            i = j + 1
            continue
        if nxt.isdigit():
            j = i + 1
            while j < n and template[j].isdigit():
                j += 1
            out.append(group_value(match, template[i + 1:j]))
            i = j
            continue
        if nxt.isalpha() or nxt == "_":
            j = i + 1
            while j < n and (template[j].isalnum() or template[j] == "_"):
                j += 1
            out.append(group_value(match, template[i + 1:j]))
            i = j
            continue
        out.append("$")
        i += 1
    return "".join(out)


def group_value(match, key):
    try:
        if key.isdigit():
            val = match.group(int(key))
        else:
            val = match.group(key)
    except (IndexError, KeyError):
        return ""
    return "" if val is None else val


def replace_text(text, find, replacement, opts):
    count = opts["limit"] if opts["limit"] > 0 else 0
    if opts["fixed"]:
        return text.replace(find, replacement, count if count else -1)
    regex = compile_regex(find, opts["flags"])
    return regex.sub(lambda m: expand_replacement(replacement, m), text, count=count)


def read_text(path):
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError:
        sys.stderr.write(f"error: invalid path: {path}\n")
        raise SystemExit(1)
    return data.decode("utf-8", errors="surrogateescape")


def write_text(path, text):
    data = text.encode("utf-8", errors="surrogateescape")
    with open(path, "wb") as f:
        f.write(data)


def main(argv):
    try:
        opts, find, replacement, files = parse_args(argv)
    except UsageError as e:
        sys.stderr.write(str(e) + "\n")
        return e.code

    if files:
        for path in files:
            text = read_text(path)
            new_text = replace_text(text, find, replacement, opts)
            write_text(path, new_text)
            sys.stdout.write(new_text)
    else:
        data = sys.stdin.buffer.read().decode("utf-8", errors="surrogateescape")
        sys.stdout.write(replace_text(data, find, replacement, opts))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
