#!/usr/bin/env python3
import json
import os
import re
import sys
from dataclasses import dataclass, field


VERSION = "treemd 0.5.7"


@dataclass
class Heading:
    level: int
    text: str
    line: int
    offset: int
    start_idx: int
    content_start: int
    end_idx: int = 0
    children: list = field(default_factory=list)


def strip_inline(s):
    s = re.sub(r"\{#[^}]*\}\s*$", "", s)
    s = re.sub(r"`[^`]*`", "", s)
    s = re.sub(r"!\[([^\]]*)\]\([^)]+\)", r"\1", s)
    s = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", s)
    s = re.sub(r"[*_~]+", "", s)
    return " ".join(s.strip().split())


def slugify(s):
    s = strip_inline(s).lower()
    s = re.sub(r"[^a-z0-9\s-]", "", s)
    s = re.sub(r"\s+", "-", s.strip())
    return s


def parse_doc(text):
    lines = text.splitlines()
    offsets, pos = [], 0
    for line in lines:
        offsets.append(pos)
        pos += len(line) + 1
    headings = []
    in_fence = False
    for i, line in enumerate(lines):
        if line.startswith("```") or line.startswith("~~~"):
            in_fence = not in_fence
        if in_fence:
            continue
        m = re.match(r"^(#{1,6})\s+(.+?)\s*#*\s*$", line)
        if m:
            headings.append(Heading(len(m.group(1)), strip_inline(m.group(2)), i + 1, offsets[i], i, i + 1))
            continue
        if i > 0 and line and re.match(r"^=+\s*$", line) and lines[i - 1].strip():
            headings.append(Heading(1, strip_inline(lines[i - 1].strip()), i + 1, offsets[i], i - 1, i))
        elif i > 0 and line and re.match(r"^-+\s*$", line) and lines[i - 1].strip():
            headings.append(Heading(2, strip_inline(lines[i - 1].strip()), i + 1, offsets[i], i - 1, i))
    for idx, h in enumerate(headings):
        h.end_idx = len(lines)
        for nxt in headings[idx + 1:]:
            if nxt.level <= h.level:
                h.end_idx = nxt.start_idx
                break
    roots, stack = [], []
    for h in headings:
        while stack and stack[-1].level >= h.level:
            stack.pop()
        if stack:
            stack[-1].children.append(h)
        else:
            roots.append(h)
        stack.append(h)
    return {"text": text, "lines": lines, "headings": headings, "roots": roots}


def read_inputs(paths):
    if not paths:
        if not sys.stdin.isatty():
            return sys.stdin.read()
        return ""
    chunks = []
    for p in paths:
        if p == "-":
            chunks.append(sys.stdin.read())
        else:
            try:
                with open(p, "r", encoding="utf-8") as f:
                    chunks.append(f.read())
            except OSError as e:
                print(f"Error reading input: I/O error: {e.strerror} (os error {e.errno})", file=sys.stderr)
                sys.exit(1)
    return "\n".join(chunks)


def filtered_headings(doc, pattern=None, level=None):
    hs = doc["headings"]
    if pattern:
        pat = pattern.lower()
        hs = [h for h in hs if pat in h.text.lower()]
    if level is not None:
        hs = [h for h in hs if h.level == level]
    return hs


def print_list(hs):
    for h in hs:
        print("#" * h.level + " " + h.text)


def tree_lines(nodes, prefix=""):
    out = []
    for i, h in enumerate(nodes):
        last = i == len(nodes) - 1
        out.append(prefix + ("└──" if last else "├──") + "#" * h.level + " " + h.text)
        if h.children:
            out.extend(tree_lines(h.children, prefix + ("   " if last else "│  ")))
    return out


def selected_tree(roots, allowed):
    allowed = {id(h) for h in allowed}
    def clone(h):
        kids = [clone(c) for c in h.children if id(c) in allowed or has_allowed(c)]
        if id(h) in allowed or kids:
            n = Heading(h.level, h.text, h.line, h.offset, h.start_idx, h.content_start, h.end_idx)
            n.children = kids
            return n
        return None
    def has_allowed(h):
        return id(h) in allowed or any(has_allowed(c) for c in h.children)
    return [x for h in roots for x in [clone(h)] if x]


def content_for(doc, h):
    return "\n".join(doc["lines"][h.content_start:h.end_idx]).strip("\n")


def parse_blocks(raw):
    lines = raw.splitlines()
    blocks, i = [], 0
    while i < len(lines):
        if not lines[i].strip():
            i += 1
            continue
        if lines[i].startswith("```") or lines[i].startswith("~~~"):
            fence = lines[i][:3]
            lang = lines[i][3:].strip() or None
            j = i + 1
            body = []
            while j < len(lines) and not lines[j].startswith(fence):
                body.append(lines[j]); j += 1
            blocks.append({"type": "code", "language": lang, "content": "\n".join(body), "start_line": i, "end_line": max(i, j - 1)})
            i = j + 1
        elif lines[i].lstrip().startswith(">"):
            vals = []
            while i < len(lines) and lines[i].lstrip().startswith(">"):
                vals.append(lines[i].lstrip()[1:].strip()); i += 1
            blocks.append({"type": "blockquote", "content": "\n".join(vals), "blocks": [{"type": "paragraph", "content": "\n".join(vals), "inline": parse_inline("\n".join(vals))}]})
        elif i + 1 < len(lines) and "|" in lines[i] and re.match(r"^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$", lines[i + 1]):
            headers = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            aligns = ["none"] * len(headers)
            rows = []
            i += 2
            while i < len(lines) and "|" in lines[i]:
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")]); i += 1
            blocks.append({"type": "table", "headers": headers, "alignments": aligns, "rows": rows})
        elif re.match(r"^\s*[-*+]\s+", lines[i]):
            items = []
            while i < len(lines) and re.match(r"^\s*[-*+]\s+", lines[i]):
                val = re.sub(r"^\s*[-*+]\s+", "", lines[i])
                checked = None
                m = re.match(r"^\[([ xX])\]\s+(.*)$", val)
                if m:
                    checked = m.group(1).lower() == "x"; val = m.group(2)
                items.append({"checked": checked, "content": val, "inline": parse_inline(val)})
                i += 1
            blocks.append({"type": "list", "ordered": False, "items": items})
        else:
            vals = []
            while i < len(lines) and lines[i].strip() and not (lines[i].startswith("```") or lines[i].lstrip().startswith(">") or re.match(r"^\s*[-*+]\s+", lines[i])):
                vals.append(lines[i]); i += 1
            para = "\n".join(vals)
            blocks.append({"type": "paragraph", "content": para, "inline": parse_inline(para)})
    return blocks


def parse_inline(s):
    res, pos = [], 0
    pat = re.compile(r"(!?)\[([^\]]*)\]\(([^)\s]+)(?:\s+\"([^\"]*)\")?\)")
    for m in pat.finditer(s):
        if m.start() > pos:
            res.append({"type": "text", "value": s[pos:m.start()]})
        if m.group(1):
            res.append({"type": "image", "alt": m.group(2), "src": m.group(3), "title": m.group(4)})
        else:
            res.append({"type": "link", "text": m.group(2), "url": m.group(3), "title": m.group(4)})
        pos = m.end()
    if pos < len(s):
        res.append({"type": "text", "value": s[pos:]})
    return res


def section_json(doc, h):
    raw = content_for(doc, h)
    return {
        "id": slugify(h.text), "level": h.level, "title": h.text, "slug": slugify(h.text),
        "position": {"line": h.line + (1 if doc["lines"][h.start_idx].startswith("#") else 0), "offset": h.offset + len(doc["lines"][h.start_idx]) + 1},
        "content": {"raw": raw, "blocks": parse_blocks(raw)},
        "children": [section_json(doc, c) for c in h.children],
    }


def document_json(doc):
    words = len(re.findall(r"\S+", doc["text"]))
    return {"document": {"metadata": {"source": None, "headingCount": len(doc["headings"]), "maxDepth": max([h.level for h in doc["headings"]] or [0]), "wordCount": words}, "sections": [section_json(doc, h) for h in doc["roots"]]}}


def collect_elements(doc, kind):
    elems = []
    raw = doc["text"]
    if kind == "code":
        for m in re.finditer(r"```([^\n`]*)\n(.*?)\n```", raw, re.S):
            elems.append({"type": "code", "lang": m.group(1).strip(), "content": m.group(2)})
    elif kind == "link":
        for m in re.finditer(r"(?<!!)\[([^\]]+)\]\(([^)]+)\)", raw):
            elems.append({"type": "link", "text": m.group(1), "url": m.group(2)})
    elif kind == "img":
        for m in re.finditer(r"!\[([^\]]*)\]\(([^)]+)\)", raw):
            elems.append({"type": "image", "alt": m.group(1), "src": m.group(2)})
    elif kind == "list":
        cur = []
        for line in raw.splitlines():
            if re.match(r"^\s*[-*+]\s+", line):
                cur.append(line.strip())
            elif cur:
                elems.append({"type": "list", "lines": cur}); cur = []
        if cur:
            elems.append({"type": "list", "lines": cur})
    elif kind == "table":
        ls = raw.splitlines()
        i = 0
        while i < len(ls) - 1:
            if "|" in ls[i] and re.match(r"^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$", ls[i + 1]):
                headers = [c.strip() for c in ls[i].strip().strip("|").split("|")]
                rows = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
                j = i + 2
                while j < len(ls) and "|" in ls[j]:
                    rows.append("| " + " | ".join(c.strip() for c in ls[j].strip().strip("|").split("|")) + " |"); j += 1
                elems.append({"type": "table", "lines": rows})
                i = j
            else:
                i += 1
    elif kind == "blockquote":
        for m in re.finditer(r"(^>.*(?:\n>.*)*)", raw, re.M):
            elems.append({"type": "blockquote", "content": re.sub(r"^>\s?", "", m.group(1), flags=re.M)})
    return elems


def heading_obj(h):
    return {"type": "heading", "level": h.level, "text": h.text, "line": h.line}


def query(doc, expr):
    expr = expr.strip()
    pipe = [p.strip() for p in expr.split("|")]
    sel = pipe[0]
    if sel.startswith("[") and sel.endswith("]"):
        sel = sel[1:-1].strip()
    if sel in (".h", ".heading"):
        items = list(doc["headings"])
    elif re.match(r"^\.h[1-6]", sel):
        lvl = int(sel[2])
        items = [h for h in doc["headings"] if h.level == lvl]
    elif sel.startswith(".code"):
        items = collect_elements(doc, "code")
    elif sel.startswith(".link") or sel.startswith(".a"):
        items = collect_elements(doc, "link")
    elif sel.startswith(".img"):
        items = collect_elements(doc, "img")
    elif sel.startswith(".table"):
        items = collect_elements(doc, "table")
    elif sel.startswith(".list"):
        items = collect_elements(doc, "list")
    elif sel.startswith(".blockquote"):
        items = collect_elements(doc, "blockquote")
    elif sel == ".":
        items = [{"type": "document"}]
    else:
        items = []
    m = re.search(r"\[([^\]]+)\]", sel)
    if m:
        f = m.group(1).strip().strip('"')
        if re.match(r"-?\d+$", f):
            idx = int(f); items = [items[idx]] if -len(items) <= idx < len(items) else []
        elif ":" in f:
            a, b = f.split(":", 1)
            items = items[int(a) if a else None:int(b) if b else None]
        elif sel.startswith(".link") and f == "external":
            items = [x for x in items if x.get("url", "").startswith(("http://", "https://"))]
        elif sel.startswith(".code"):
            # The reference currently returns no rows for .code[lang]; keep that quirk.
            items = []
        else:
            items = [x for x in items if f.lower() in (x.text if isinstance(x, Heading) else str(x)).lower()]
    for fn in pipe[1:]:
        if fn in ("text",):
            items = [x.text if isinstance(x, Heading) else x.get("text", x.get("content", "")) for x in items]
        elif fn in ("url", "href", "src"):
            items = [x.get("url", x.get("src", "")) for x in items]
        elif fn == "lang":
            items = [x.get("lang", "") for x in items]
        elif fn in ("count", "length", "len", "size"):
            return len(items)
        elif fn.startswith("limit(") or fn.startswith("take("):
            n = int(re.search(r"\((\d+)\)", fn).group(1)); items = items[:n]
        elif fn.startswith("select(") or fn.startswith("where("):
            m = re.search(r'contains\("([^"]+)"\)', fn)
            if m:
                needle = m.group(1).lower()
                items = [x for x in items if needle in (x.text if isinstance(x, Heading) else str(x)).lower()]
        elif fn == "stats":
            return stats(doc)
    return items


def stats(doc):
    return {
        "headings": len(doc["headings"]),
        "code_blocks": len(collect_elements(doc, "code")),
        "links": len(collect_elements(doc, "link")),
        "images": 0,
        "tables": len(collect_elements(doc, "table")),
        "lists": len(collect_elements(doc, "list")),
        "words": len(re.findall(r"\S+", doc["text"])),
    }


def print_query_result(doc, res, fmt):
    def plain_item(x):
        if isinstance(x, Heading): return "#" * x.level + " " + x.text
        if isinstance(x, str): return x
        if isinstance(x, int): return str(x)
        if x.get("type") == "code": return "```" + x.get("lang", "") + "\n" + x.get("content", "") + "\n```"
        if x.get("type") == "link": return f"[{x.get('text','')}]({x.get('url','')})"
        if x.get("type") == "image": return f"![{x.get('alt','')}]({x.get('src','')})"
        if x.get("type") in ("list", "table"): return "\n".join(x["lines"])
        if x.get("type") == "blockquote": return x["content"]
        return "\n".join(f"{k}: {v}" for k, v in x.items())
    if isinstance(res, dict):
        if fmt.startswith("json"):
            print(json.dumps(res, indent=2 if fmt in ("json-pretty",) else None, separators=None if fmt == "json-pretty" else (",", ":")))
        else:
            for k, v in res.items(): print(f"{k}: {v}")
        return
    if isinstance(res, int):
        print(res); return
    if fmt == "json":
        print(json.dumps([heading_obj(x) if isinstance(x, Heading) else x for x in res], separators=(",", ":")))
    elif fmt == "jsonl":
        for x in res:
            print(json.dumps(heading_obj(x) if isinstance(x, Heading) else x, separators=(",", ":")))
    elif fmt in ("json-pretty", "jsonp"):
        if fmt == "jsonp":
            print("Error: Unknown output format: jsonp", file=sys.stderr); sys.exit(1)
        print(json.dumps([heading_obj(x) if isinstance(x, Heading) else x for x in res], indent=2))
    elif fmt == "md":
        for x in res:
            if isinstance(x, Heading):
                print("#" * x.level + " " + x.text + "\n")
                print(content_for(doc, x) + "\n")
            else:
                print(plain_item(x))
    else:
        for x in res:
            s = plain_item(x)
            if s:
                print(s)


HELP = """A markdown navigator with tree-based structural navigation

Usage: executable [OPTIONS] [FILE]... [COMMAND]

Commands:
  at-line  Show heading at specific line number
  help     Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]...  Markdown file(s) to view (.md or .markdown), directory, or '-' for stdin

Options:
  -l, --list                   List all headings in the document (non-interactive)
      --tree                   Show heading tree structure with box-drawing characters (non-interactive)
      --filter <PATTERN>       Filter headings by text pattern (case-insensitive)
  -L, --level <LEVEL>          Show only headings at specific level (1-6)
  -o, --output <OUTPUT>        Output format for --list and --tree modes [default: plain] [possible values: plain, json, tree]
  -s, --section <HEADING>      Extract specific section by heading name
      --count                  Count headings by level (shows statistics)
      --setup-completions      Set up shell completions interactively
      --theme <THEME>          Set theme for TUI mode
      --color-mode <MODE>      Force color mode (auto, rgb, 256) [possible values: auto, rgb, 256]
      --no-images              Disable image rendering in TUI mode
      --images                 Enable image rendering in TUI mode (override config)
  -q, --query <EXPR>           Query expression for selecting/filtering document elements
      --query-help             Show query language documentation and examples
      --query-output <FORMAT>  Output format for query results
  -h, --help                   Print help (see more with '--help')
  -V, --version                Print version"""


def query_help():
    print("treemd Query Language (tql)\n\nA jq-like query language for navigating and extracting markdown structure.\n\nELEMENT SELECTORS\n    .h, .heading    All headings (any level)\n    .h1 - .h6       Headings by level\n    .code           All code blocks\n    .link, .a       All links\n\nOUTPUT FORMATS (--query-output)\n    plain       Human-readable text (default)\n    json        Compact JSON\n    json-pretty Pretty-printed JSON (alias: jsonp)")


def completions():
    print("""Shell Completion Setup Instructions

Add the appropriate line to your shell config:

Bash (~/.bashrc):
  source <(COMPLETE=bash treemd)

Zsh (~/.zshrc):
  source <(COMPLETE=zsh treemd)

Fish (~/.config/fish/config.fish):
  COMPLETE=fish treemd | source

After adding the line, restart your shell or source the config file.""")
    print("Error setting up completions: Could not detect shell", file=sys.stderr)
    sys.exit(1)


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(HELP); return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION); return 0
    if argv[0] == "--query-help":
        query_help(); return 0
    if argv[0] == "--setup-completions":
        completions()
    if argv[0] == "at-line":
        if len(argv) < 2 or argv[1] in ("-h", "--help"):
            print("Show heading at specific line number\n\nUsage: executable at-line <LINE>"); return 0
        # No file argument is accepted by the reference. Use stdin if present.
        doc = parse_doc(sys.stdin.read() if not sys.stdin.isatty() else "")
        line = int(argv[1])
        cur = None
        for h in doc["headings"]:
            if h.line <= line: cur = h
        if cur: print("#" * cur.level + " " + cur.text)
        return 0 if cur else 1

    opts = {"list": False, "tree": False, "filter": None, "level": None, "output": "plain", "section": None, "count": False, "query": None, "query_output": "plain"}
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP); return 0
        elif a in ("-V", "--version"):
            print(VERSION); return 0
        elif a in ("-l", "--list"):
            opts["list"] = True
        elif a == "--tree":
            opts["tree"] = True
        elif a == "--filter":
            i += 1; opts["filter"] = argv[i]
        elif a in ("-L", "--level"):
            i += 1; opts["level"] = int(argv[i])
        elif a in ("-o", "--output"):
            i += 1; opts["output"] = argv[i]
            if opts["output"] not in ("plain", "json", "tree"):
                print(f"error: invalid value '{opts['output']}' for '--output <OUTPUT>'\n  [possible values: plain, json, tree]\n\nFor more information, try '--help'.", file=sys.stderr)
                return 2
        elif a in ("-s", "--section"):
            i += 1; opts["section"] = argv[i]
        elif a == "--count":
            opts["count"] = True
        elif a in ("-q", "--query"):
            i += 1; opts["query"] = argv[i]
        elif a == "--query-output":
            i += 1; opts["query_output"] = argv[i]
        elif a in ("--query-help",):
            query_help(); return 0
        elif a in ("--setup-completions",):
            completions()
        elif a in ("--theme", "--color-mode"):
            i += 1
        elif a in ("--no-images", "--images"):
            pass
        else:
            files.append(a)
        i += 1

    doc = parse_doc(read_inputs(files))
    if opts["query"] is not None:
        print_query_result(doc, query(doc, opts["query"]), opts["query_output"]); return 0
    hs = filtered_headings(doc, opts["filter"], opts["level"])
    if opts["count"]:
        print("Heading counts:")
        for lvl in range(1, 7):
            c = len([h for h in hs if h.level == lvl])
            if c: print(f"  {'#' * lvl}: {c}")
        print()
        print(f"Total: {len(hs)}")
        return 0
    if opts["section"] is not None:
        found = next((h for h in doc["headings"] if h.text.lower() == opts["section"].lower()), None)
        if not found:
            print(f"Section '{opts['section']}' not found", file=sys.stderr); return 1
        print("#" * found.level + " " + found.text)
        body = "\n".join(doc["lines"][found.start_idx + 1:found.end_idx]).strip("\n")
        if body:
            print()
            print(body)
        return 0
    if opts["output"] == "json":
        if opts["list"]:
            print(json.dumps(document_json(doc), indent=2))
        else:
            print(json.dumps([{"level": h.level, "text": h.text} for h in hs], indent=2))
        return 0
    if opts["tree"] or opts["output"] == "tree":
        roots = selected_tree(doc["roots"], hs) if (opts["filter"] or opts["level"]) else doc["roots"]
        for line in tree_lines(roots): print(line)
        return 0
    if opts["list"] or opts["filter"] or opts["level"] is not None:
        print_list(hs); return 0
    print("Failed to enable raw mode: Cannot open /dev/tty: No such device or address (os error 6). Interactive mode requires a terminal.", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
