#!/usr/bin/env python3
import argparse
import fnmatch
import os
import subprocess
import sys
import time


LONG_HELP = """Automatically trims your tracking branches whose upstream branches are merged or stray.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]
          
          The default value is a branch that tracks `git symbolic-ref refs/remotes/*/HEAD`. They might not be reflected correctly when the HEAD branch of your remote repository is changed. You can see the changed HEAD branch name with `git remote show <remote>` and apply it to your local repository with `git remote set-head <remote> --auto`.

  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]

      --no-update
          Do not update remotes [config: trim.update]

      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]

      --no-confirm
          Do not ask confirm [config: trim.confirm]

      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]

  -d, --delete <DELETE>
          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]
          
          `merged` implies `merged-local,merged-remote`.
          
          `merged-local` will delete merged tracking local branches. `merged-remote:<remote>` will delete merged upstream branches from `<remote>`. `stray` will delete tracking local branches, which is not merged, but the upstream is gone. `diverged:<remote>` will delete merged tracking local branches, and their upstreams from `<remote>` even if the upstreams are not merged and diverged from local ones. `local` will delete non-tracking merged local branches. `remote:<remote>` will delete non-upstream merged remote tracking branches. Use with caution when you are using other than `merged`. It might lose changes, and even nuke repositories.

      --dry-run
          Do not delete branches, show what branches will be deleted

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

SHORT_HELP = """Automatically trims your tracking branches whose upstream branches are merged or stray.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]
  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]
      --no-update
          Do not update remotes [config: trim.update]
      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]
      --no-confirm
          Do not ask confirm [config: trim.confirm]
      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]
  -d, --delete <DELETE>
          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]
      --dry-run
          Do not delete branches, show what branches will be deleted
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


class GitError(Exception):
    pass


def git(args, check=True, capture=True):
    p = subprocess.run(["git"] + args, text=True, capture_output=capture)
    if check and p.returncode != 0:
        raise GitError((p.stderr or p.stdout).strip())
    return p


def git_out(args, default=None):
    p = git(args, check=False)
    if p.returncode != 0:
        return default
    return p.stdout.strip()


def split_csv(value):
    if value is None or value == "":
        return []
    return [x.strip() for x in value.split(",") if x.strip()]


def cfg(name):
    return git_out(["config", "--get", name])


def bool_cfg(name, default):
    val = cfg(name)
    if val is None:
        return default
    return val.lower() not in ("false", "0", "no", "off")


def parse_args(argv):
    if argv == ["--help"]:
        print(LONG_HELP, end="")
        sys.exit(0)
    if argv == ["-h"]:
        print(SHORT_HELP, end="")
        sys.exit(0)
    if argv == ["--version"] or argv == ["-V"]:
        print("git-trim 0.4.4")
        sys.exit(0)
    parser = argparse.ArgumentParser(add_help=False, prog="executable")
    parser.add_argument("-b", "--bases")
    parser.add_argument("-p", "--protected", dest="protected")
    parser.add_argument("--no-update", action="store_false", dest="update", default=None)
    parser.add_argument("--update", action="store_true", dest="update")
    parser.add_argument("--update-interval", type=int, default=None)
    parser.add_argument("--no-confirm", action="store_false", dest="confirm", default=None)
    parser.add_argument("--confirm", action="store_true", dest="confirm")
    parser.add_argument("--no-detach", action="store_false", dest="detach", default=None)
    parser.add_argument("--detach", action="store_true", dest="detach")
    parser.add_argument("-d", "--delete", default=None)
    parser.add_argument("--dry-run", action="store_true")
    try:
        return parser.parse_args(argv)
    except SystemExit as e:
        sys.exit(e.code)


def ensure_repo():
    p = git(["rev-parse", "--git-dir"], check=False)
    if p.returncode != 0:
        print("Error: could not find repository at '.'; class=Repository (6); code=NotFound (-3)", file=sys.stderr)
        sys.exit(1)


def for_each(fmt, refs):
    p = git(["for-each-ref", f"--format={fmt}"] + refs)
    return [line for line in p.stdout.splitlines() if line]


def is_ancestor(a, b):
    if not a or not b:
        return False
    return git(["merge-base", "--is-ancestor", a, b], check=False, capture=True).returncode == 0


def remote_head_bases():
    bases = []
    for line in for_each("%(refname:short) %(symref:short)", ["refs/remotes"]):
        parts = line.split()
        if len(parts) == 2 and parts[0].endswith("/HEAD"):
            bases.append(parts[1])
    return sorted(set(bases))


def local_refs():
    rows = []
    fmt = "%(refname:short)%00%(objectname)%00%(upstream:short)"
    for line in for_each(fmt, ["refs/heads"]):
        name, sha, up = (line.split("\0") + ["", ""])[:3]
        rows.append({"kind": "local", "name": name, "sha": sha, "up": up})
    return rows


def remote_refs():
    rows = []
    fmt = "%(refname:short)%00%(objectname)"
    for line in for_each(fmt, ["refs/remotes"]):
        name, sha = (line.split("\0") + [""])[:2]
        if name.endswith("/HEAD"):
            continue
        if "/" not in name:
            continue
        remote, branch = name.split("/", 1)
        rows.append({"kind": "remote", "name": name, "remote": remote, "branch": branch, "sha": sha})
    return rows


def parse_delete(value):
    value = value or "merged:origin"
    local_ranges = set()
    remote_ranges = {}
    for item in split_csv(value):
        rng, _, remote = item.partition(":")
        if rng == "merged":
            local_ranges.add("merged-local")
            remote_ranges.setdefault("merged-remote", set()).add(remote or "origin")
        elif rng in ("merged-local", "stray", "local"):
            local_ranges.add(rng)
        elif rng == "diverged":
            local_ranges.add("diverged")
            remote_ranges.setdefault("diverged", set()).add(remote or "origin")
        elif rng in ("merged-remote", "remote"):
            remote_ranges.setdefault(rng, set()).add(remote or "origin")
        else:
            print(f"Error: invalid delete range `{rng}`", file=sys.stderr)
            sys.exit(1)
    return local_ranges, remote_ranges


def remote_allowed(remote_ranges, rng, remote):
    vals = remote_ranges.get(rng, set())
    return "*" in vals or remote in vals


def maybe_update(interval):
    if interval is None:
        interval = int(cfg("trim.updateInterval") or "5")
    if interval < 0:
        interval = 5
    gitdir = git_out(["rev-parse", "--git-dir"], ".git")
    stamp = os.path.join(gitdir, "git-trim-fetch")
    now = time.time()
    if interval and os.path.exists(stamp) and now - os.path.getmtime(stamp) < interval:
        return
    subprocess.run(["git", "fetch", "--prune", "--all"], text=True)
    try:
        with open(stamp, "w", encoding="utf-8") as f:
            f.write(str(int(now)))
    except OSError:
        pass


def main(argv):
    args = parse_args(argv)
    ensure_repo()

    update = args.update if args.update is not None else bool_cfg("trim.update", True)
    if update:
        maybe_update(args.update_interval)

    protected = split_csv(args.protected if args.protected is not None else cfg("trim.protected"))
    delete_spec = args.delete if args.delete is not None else cfg("trim.delete")
    local_ranges, remote_ranges = parse_delete(delete_spec)
    confirm = args.confirm if args.confirm is not None else bool_cfg("trim.confirm", True)
    detach = args.detach if args.detach is not None else bool_cfg("trim.detach", True)

    base_names = split_csv(args.bases if args.bases is not None else cfg("trim.bases"))
    if not base_names:
        base_names = remote_head_bases()
    expanded_bases = set(base_names)
    for name in list(expanded_bases):
        up = git_out(["rev-parse", "--abbrev-ref", f"{name}@{{upstream}}"])
        if up:
            expanded_bases.add(up)
    base_names = sorted(expanded_bases)
    base_shas = [git_out(["rev-parse", "--verify", name]) for name in base_names]
    base_shas = [x for x in base_shas if x]
    base_set = set(base_names)

    locals_ = local_refs()
    remotes = remote_refs()
    upstreams = {r["up"] for r in locals_ if r["up"]}
    current = git_out(["branch", "--show-current"], "")

    remain_locals, remain_remotes = [], []
    del_merged_local, del_stray, del_local, del_remote_merged, del_remote_other = [], [], [], [], []

    for r in sorted(locals_, key=lambda x: x["name"]):
        name, sha, up = r["name"], r["sha"], r["up"]
        reasons = []
        if name in base_set or up in base_set:
            reasons.append("base")
            remain_locals.append((name, reasons))
            continue
        merged = any(is_ancestor(sha, b) for b in base_shas)
        upstream_exists = bool(up and git_out(["rev-parse", "--verify", up]))
        pat = next((pat for pat in protected if fnmatch.fnmatch(name, pat)), None)
        if pat:
            if up and not upstream_exists:
                reasons.append(f"stray, but: protected by a pattern `{pat}`")
            elif merged:
                reasons.append(f"merged, but: protected by a pattern `{pat}`")
            else:
                reasons.append(f"protected by a pattern `{pat}`")
            remain_locals.append((name, reasons))
            continue
        if up:
            if merged and "merged-local" in local_ranges:
                del_merged_local.append(name)
            elif (not upstream_exists) and "stray" in local_ranges:
                del_stray.append(name)
            elif merged and "diverged" in local_ranges:
                del_merged_local.append(name)
            else:
                if merged:
                    reasons.append("merged, but: delete range `merged-local` was not given")
                elif not upstream_exists:
                    reasons.append("stray, but: delete range `stray` was not given")
                else:
                    reasons.append("*1")
                remain_locals.append((name, reasons))
        else:
            if merged and "local" in local_ranges:
                del_local.append(name)
            else:
                reasons.append("*2")
                remain_locals.append((name, reasons))

    for r in sorted(remotes, key=lambda x: x["name"]):
        name, sha, remote = r["name"], r["sha"], r["remote"]
        reasons = []
        if name in base_set:
            reasons.append("base")
            remain_remotes.append((name, reasons))
            continue
        merged = any(is_ancestor(sha, b) for b in base_shas)
        pat = next((pat for pat in protected if fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(r["branch"], pat)), None)
        if pat:
            if merged:
                reasons.append(f"merged, but: protected by a pattern `{pat}`")
            else:
                reasons.append(f"protected by a pattern `{pat}`")
            remain_remotes.append((name, reasons))
            continue
        if merged and remote_allowed(remote_ranges, "merged-remote", remote):
            del_remote_merged.append((remote, r["branch"], name))
        elif merged and name not in upstreams and remote_allowed(remote_ranges, "remote", remote):
            del_remote_other.append((remote, r["branch"], name))
        elif merged and remote_allowed(remote_ranges, "diverged", remote):
            del_remote_merged.append((remote, r["branch"], name))
        else:
            if merged:
                reasons.append(f"merged, but: delete range `merged-remote:{remote}` was not given")
            else:
                reasons.append("*1")
            remain_remotes.append((name, reasons))

    print("Branches that will remain:")
    print("  local branches:")
    for name, reasons in remain_locals:
        print(f"    {name} [{', '.join(reasons)}]")
    print("  remote references:")
    for name, reasons in remain_remotes:
        print(f"    {name} [{', '.join(reasons)}]")
    foot = []
    if any("*1" in rs for _, rs in remain_locals + remain_remotes):
        foot.append("    *1: Not merged.")
    if any("*2" in rs for _, rs in remain_locals):
        foot.append("    *2: Set an upstream to make it a tracking branch or add `--delete 'local'` flag.")
    if foot:
        print("  Some branches are skipped. Consider following to scan them:")
        for line in foot:
            print(line)
    print()

    if del_merged_local:
        print("Delete merged local branches:")
        for n in sorted(del_merged_local):
            print(f"  - {n}")
    if del_stray:
        print("Delete stray local branches:")
        for n in sorted(del_stray):
            print(f"  - {n}")
    if del_local:
        print("Delete merged local branches without upstream:")
        for n in sorted(del_local):
            print(f"  - {n}")
    if del_remote_merged:
        print("Delete merged remote refs:")
        for remote, branch, _ in sorted(del_remote_merged, key=lambda x: x[2]):
            print(f"  - {remote}, refs/heads/{branch}")
    if del_remote_other:
        print("Delete merged remote refs without upstream:")
        for remote, branch, _ in sorted(del_remote_other, key=lambda x: x[2]):
            print(f"  - {remote}, refs/heads/{branch}")

    to_delete_locals = sorted(set(del_merged_local + del_stray + del_local))
    to_delete_remotes = sorted(set(del_remote_merged + del_remote_other), key=lambda x: x[2])
    if not args.dry_run and confirm and (to_delete_locals or to_delete_remotes):
        ans = input("Delete the above branches? [y/N] ")
        if ans.lower() not in ("y", "yes"):
            return 0
    sys.stdout.flush()
    if current in to_delete_locals and detach:
        subprocess.run(["git", "checkout", "--detach"], text=True)
    for n in to_delete_locals:
        if args.dry_run:
            print(f"Delete branch {n} (dry run).")
            sys.stdout.flush()
        else:
            subprocess.run(["git", "branch", "-D", n], text=True)
    sys.stdout.flush()
    for remote, branch, _ in to_delete_remotes:
        refspec = f":refs/heads/{branch}"
        cmd = ["git", "push"]
        if args.dry_run:
            cmd.append("--dry-run")
        cmd += [remote, refspec]
        subprocess.run(cmd, text=True)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except GitError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
