#!/usr/bin/env python3
import fnmatch
import os
import re
import select
import shlex
import stat
import sys
import time
from pathlib import Path

VERSION = "igrep 1.3.0"
EDITORS = ["vim", "neovim", "nvim", "nano", "code", "vscode", "code-insiders", "emacs", "emacsclient", "hx", "helix", "subl", "sublime-text", "micro", "intellij", "goland", "pycharm", "less", "fresh"]
THEMES = ["light", "dark"]
VIEWERS = ["none", "vertical", "horizontal"]
SORTS = ["path", "modified", "created", "accessed"]
VALUE_OPTIONS = {
    "--editor": "EDITOR",
    "--custom-command": "CUSTOM_COMMAND",
    "--theme": "THEME",
    "--glob": "GLOB",
    "--type": "TYPE_MATCHING",
    "--type-not": "TYPE_NOT",
    "--context-viewer": "CONTEXT_VIEWER",
    "--sort": "SORT_BY",
    "--sortr": "SORT_BY_REVERSE",
}
SHORT_VALUE_OPTIONS = {"-g": "--glob", "-t": "--type", "-T": "--type-not"}
FLAGS = {"--ignore-case", "--smart-case", "--hidden", "--follow", "--word-regexp", "--fixed-strings", "--multiline", "--type-list"}
SHORT_FLAGS = {"-i": "--ignore-case", "-S": "--smart-case", "-.": "--hidden", "-L": "--follow", "-w": "--word-regexp", "-F": "--fixed-strings", "-U": "--multiline"}

HELP = """Interactive Grep

Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

Arguments:
  <PATTERN>   Regular expression used for searching
  [PATHS]...  Files or directories to search. Directories are searched recursively. If not specified, searching starts from current directory

Options:
      --editor <EDITOR>
          Text editor used to open selected match [possible values: vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh]
      --custom-command <CUSTOM_COMMAND>
          Custom command used to open selected match. Must contain {file_name} and {line_number} tokens [env: IGREP_CUSTOM_EDITOR=]
      --theme <THEME>
          UI color theme [default: dark] [possible values: light, dark]
  -i, --ignore-case
          Searches case insensitively
  -S, --smart-case
          Searches case insensitively if the pattern is all lowercase. Search case sensitively otherwise
  -., --hidden
          Search hidden files and directories. By default, hidden files and directories are skipped
  -L, --follow
          Follow symbolic links while traversing directories
  -w, --word-regexp
          Only show matches surrounded by word boundaries
  -F, --fixed-strings
          Exact matches with no regex. Useful when searching for a string full of delimiters
  -U, --multiline
          Search with pattern contains newline character ('\\n')
  -g, --glob <GLOB>
          Include files and directories for searching that match the given glob. Multiple globs may be provided
      --type-list
          Show all supported file types and their corresponding globs
  -t, --type <TYPE_MATCHING>
          Only search files matching TYPE. Multiple types may be provided
  -T, --type-not <TYPE_NOT>
          Do not search files matching TYPE-NOT. Multiple types-not may be provided
      --context-viewer <CONTEXT_VIEWER>
          Context viewer position at startup [default: none] [possible values: none, vertical, horizontal]
      --sort <SORT_BY>
          Sort results, see ripgrep for details [possible values: path, modified, created, accessed]
      --sortr <SORT_BY_REVERSE>
          Sort results reverse, see ripgrep for details [possible values: path, modified, created, accessed]
  -h, --help
          Print help
  -V, --version
          Print version
"""


def eprint(s=""):
    print(s, file=sys.stderr)


def usage_for_error():
    return "Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]..."


def clap_error(message, tip=None, usage=True):
    eprint(f"error: {message}")
    if tip:
        eprint()
        eprint(f"  tip: {tip}")
    if usage:
        eprint()
        eprint(usage_for_error())
    eprint()
    eprint("For more information, try '--help'.")
    return 2


def possible(values):
    return ", ".join(values)


def load_types():
    here = Path(__file__).resolve().parent
    p = here / "igrep_types.txt"
    try:
        return p.read_text()
    except OSError:
        return ""


def parse_type_patterns():
    out = {}
    for line in load_types().splitlines():
        if not line or ": " not in line:
            continue
        name, rest = line.split(": ", 1)
        out[name] = [x.strip() for x in rest.split(",")]
    return out


def parse_args(argv):
    opts = {
        "--editor": None,
        "--custom-command": os.environ.get("IGREP_CUSTOM_EDITOR"),
        "--theme": "dark",
        "--context-viewer": "none",
        "--glob": [],
        "--type": [],
        "--type-not": [],
        "--sort": None,
        "--sortr": None,
    }
    flags = set()
    pos = []
    i = 0
    positional_mode = False
    while i < len(argv):
        a = argv[i]
        if positional_mode:
            pos.append(a); i += 1; continue
        if a == "--":
            positional_mode = True; i += 1; continue
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a in FLAGS:
            flags.add(a); i += 1; continue
        if a in VALUE_OPTIONS:
            if i + 1 >= len(argv) or (argv[i + 1].startswith("-") and argv[i + 1] != "-"):
                return None, clap_error(f"a value is required for '{a} <{VALUE_OPTIONS[a]}>' but none was supplied", usage=False)
            val = argv[i + 1]
            if a in ("--glob", "--type", "--type-not"):
                opts[a].append(val)
            else:
                opts[a] = val
            i += 2; continue
        matched_eq = False
        for opt in VALUE_OPTIONS:
            if a.startswith(opt + "="):
                val = a.split("=", 1)[1]
                if opt in ("--glob", "--type", "--type-not"):
                    opts[opt].append(val)
                else:
                    opts[opt] = val
                matched_eq = True
                break
        if matched_eq:
            i += 1; continue
        if a in SHORT_FLAGS:
            flags.add(SHORT_FLAGS[a]); i += 1; continue
        if a in SHORT_VALUE_OPTIONS:
            long = SHORT_VALUE_OPTIONS[a]
            if i + 1 >= len(argv) or (argv[i + 1].startswith("-") and argv[i + 1] != "-"):
                return None, clap_error(f"a value is required for '{long} <{VALUE_OPTIONS[long]}>' but none was supplied", usage=False)
            opts[long].append(argv[i + 1]); i += 2; continue
        if a.startswith("-") and len(a) > 1:
            return None, clap_error(f"unexpected argument '{a}' found", tip=f"to pass '{a}' as a value, use '-- {a}'")
        pos.append(a); i += 1

    if opts["--editor"] is not None and opts["--editor"] not in EDITORS:
        eprint(f"error: invalid value '{opts['--editor']}' for '--editor <EDITOR>'")
        eprint(f"  [possible values: {possible(EDITORS)}]")
        eprint(); eprint("For more information, try '--help'.")
        return None, 2
    if opts["--theme"] not in THEMES:
        eprint(f"error: invalid value '{opts['--theme']}' for '--theme <THEME>'")
        eprint(f"  [possible values: {possible(THEMES)}]")
        eprint(); eprint("For more information, try '--help'.")
        return None, 2
    if opts["--context-viewer"] not in VIEWERS:
        eprint(f"error: invalid value '{opts['--context-viewer']}' for '--context-viewer <CONTEXT_VIEWER>'")
        eprint(f"  [possible values: {possible(VIEWERS)}]")
        eprint(); eprint("For more information, try '--help'.")
        return None, 2
    for key in ("--sort", "--sortr"):
        if opts[key] is not None and opts[key] not in SORTS:
            metavar = "SORT_BY" if key == "--sort" else "SORT_BY_REVERSE"
            eprint(f"error: invalid value '{opts[key]}' for '{key} <{metavar}>'")
            eprint(f"  [possible values: {possible(SORTS)}]")
            eprint(); eprint("For more information, try '--help'.")
            return None, 2

    if "--type-list" in flags:
        if pos:
            offender = "<PATTERN>" if argv and argv[0] != "--type-list" else "--type-list"
            other = "--type-list" if offender == "<PATTERN>" else "<PATTERN>"
            eprint(f"error: the argument '{offender}' cannot be used with '{other}'")
            eprint(); eprint("Usage: executable --type-list <PATTERN> [PATHS]...")
            eprint(); eprint("For more information, try '--help'.")
            return None, 2
        print(load_types(), end="")
        raise SystemExit(0)
    if not pos:
        eprint("error: the following required arguments were not provided:")
        eprint("  --type-list")
        eprint("  <PATTERN>")
        eprint(); eprint("Usage: executable --type-list <PATTERN> [PATHS]...")
        eprint(); eprint("For more information, try '--help'.")
        return None, 2
    return {"opts": opts, "flags": flags, "pattern": pos[0], "paths": pos[1:] or ["."]}, 0


def validate_custom(cmd):
    if not cmd:
        return 0
    for tok in ("{file_name}", "{line_number}"):
        if cmd.count(tok) != 1:
            eprint(f"Error: Incorrect editor command: '{cmd}'")
            eprint(); eprint("Caused by:")
            eprint(f"    Expected one occurrence of '{tok}'.")
            return 1
    return 0


def is_hidden(path):
    return any(part.startswith(".") and part not in (".", "..") for part in Path(path).parts)


def file_iter(paths, hidden=False, follow=False):
    for start in paths:
        p = Path(start)
        if not p.exists():
            continue
        if p.is_file():
            if hidden or not is_hidden(p):
                yield p
            continue
        for root, dirs, files in os.walk(p, followlinks=follow):
            if not hidden:
                dirs[:] = [d for d in dirs if not d.startswith(".")]
                files = [f for f in files if not f.startswith(".")]
            for f in files:
                fp = Path(root) / f
                try:
                    st = fp.stat()
                    if stat.S_ISREG(st.st_mode):
                        yield fp
                except OSError:
                    pass


def matches_type(path, names, type_map):
    if not names:
        return True
    s = str(path)
    base = path.name
    for name in names:
        for pat in type_map.get(name, []):
            if fnmatch.fnmatch(base, pat) or fnmatch.fnmatch(s, pat):
                return True
    return False


def search(args):
    opts, flags = args["opts"], args["flags"]
    type_map = parse_type_patterns()
    pattern = args["pattern"]
    icase = "--ignore-case" in flags or ("--smart-case" in flags and pattern.lower() == pattern)
    if "--fixed-strings" in flags:
        expr = re.escape(pattern)
    else:
        expr = pattern
    if "--word-regexp" in flags:
        expr = r"\b(?:" + expr + r")\b"
    re_flags = re.IGNORECASE if icase else 0
    try:
        rx = re.compile(expr, re_flags)
    except re.error as ex:
        eprint(f"Error: regex parse error: {ex}")
        return []
    rows = []
    for fp in file_iter(args["paths"], "--hidden" in flags, "--follow" in flags):
        if opts["--glob"] and not any(fnmatch.fnmatch(str(fp), g) or fnmatch.fnmatch(fp.name, g) for g in opts["--glob"]):
            continue
        if not matches_type(fp, opts["--type"], type_map):
            continue
        if opts["--type-not"] and matches_type(fp, opts["--type-not"], type_map):
            continue
        try:
            text = fp.read_text(errors="replace")
        except OSError:
            continue
        for n, line in enumerate(text.splitlines(), 1):
            if rx.search(line):
                rows.append((str(fp), n, line))
    sort_key = opts["--sort"] or opts["--sortr"]
    reverse = opts["--sortr"] is not None
    if sort_key:
        def key(row):
            p = Path(row[0])
            try: st = p.stat()
            except OSError: st = None
            if sort_key == "path": return row[0]
            if sort_key == "modified": return st.st_mtime if st else 0
            if sort_key == "created": return st.st_ctime if st else 0
            if sort_key == "accessed": return st.st_atime if st else 0
        rows.sort(key=key, reverse=reverse)
    return rows


def run_tui(args):
    rows = search(args)
    sys.stdout.write("\x1b[?25l\x1b[?1049h\x1b[2J\x1b[H")
    try:
        sys.stdout.write(f"Interactive Grep - {len(rows)} matches for {args['pattern']!r}\r\n")
        for file, line, text in rows[: max(1, os.get_terminal_size().lines - 3)]:
            snippet = text[: max(20, os.get_terminal_size().columns - len(file) - 20)]
            sys.stdout.write(f"{file}:{line}: {snippet}\r\n")
        sys.stdout.flush()
        while True:
            r, _, _ = select.select([sys.stdin], [], [], 0.25)
            if r:
                ch = os.read(sys.stdin.fileno(), 8)
                if ch in (b"q", b"\x1b", b"\x03") or b"q" in ch:
                    break
            if not sys.stdin.isatty():
                break
    finally:
        sys.stdout.write("\x1b[39m\x1b[49m\x1b[0m\x1b[?1049l\x1b[?25h")
        sys.stdout.flush()
    return 0


def main(argv):
    parsed, code = parse_args(argv)
    if code:
        return code
    if validate_custom(parsed["opts"].get("--custom-command")):
        return 1
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        eprint("Error: Resource temporarily unavailable (os error 11)")
        return 1
    return run_tui(parsed)

if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
