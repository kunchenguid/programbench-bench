#!/usr/bin/env python3
import argparse
import json
import os
import re
import stat
import sys
import time
from dataclasses import dataclass, field
from typing import List, Optional


VERSION = "Dust 1.2.3"
FORMATS = ("si", "b", "k", "m", "g", "t", "kb", "mb", "gb", "tb")


@dataclass
class Node:
    path: str
    name: str
    size: int
    own_size: int
    is_dir: bool
    is_file: bool
    children: List["Node"] = field(default_factory=list)
    depth: int = 0
    file_count: int = 0
    error: Optional[str] = None


HELP_LONG = """Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...
          Input files or directories

Options:
  -d, --depth <DEPTH>
          Depth to show

  -T, --threads <THREADS>
          Number of threads to use

      --config <FILE>
          Specify a config file to use

  -n, --number-of-lines <NUMBER>
          Number of lines of output to show. (Default is terminal_height - 10)

  -p, --full-paths
          Subdirectories will not have their path shortened

  -X, --ignore-directory <PATH>
          Exclude any file or directory with this path

  -I, --ignore-all-in-file <FILE>
          Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter

  -L, --dereference-links
          dereference sym links - Treat sym links as directories and go into them

  -x, --limit-filesystem
          Only count the files and directories on the same filesystem as the supplied directory

  -s, --apparent-size
          Use file length instead of blocks

  -r, --reverse
          Print tree upside down (biggest highest)

  -c, --no-colors
          No colors will be printed (Useful for commands like: watch)

  -C, --force-colors
          Force colors print

  -b, --no-percent-bars
          No percent bars or percentages will be displayed

  -B, --bars-on-right
          percent bars moved to right side of screen

  -z, --min-size <MIN_SIZE>
          Minimum size file to include in output

  -R, --screen-reader
          For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)

      --skip-total
          No total row will be displayed

  -f, --filecount
          Directory 'size' is number of child files instead of disk size

  -i, --ignore-hidden
          Do not display hidden files

  -v, --invert-filter <REGEX>
          Exclude filepaths matching this regex. To ignore png files type: -v "\\.png$"

  -e, --filter <REGEX>
          Only include filepaths matching this regex. For png files type: -e "\\.png$"

  -t, --file-types
          show only these file types

  -w, --terminal-width <WIDTH>
          Specify width of output overriding the auto detection of terminal width

  -P, --no-progress
          Disable the progress indication

      --print-errors
          Print path with errors

  -D, --only-dir
          Only directories will be displayed

  -F, --only-file
          Only files will be displayed. (Finds your largest files)

  -o, --output-format <FORMAT>
          Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size

          Possible values:
          - si: SI prefix (powers of 1000)
          - b:  byte (B)
          - k:  kibibyte (KiB)
          - m:  mebibyte (MiB)
          - g:  gibibyte (GiB)
          - t:  tebibyte (TiB)
          - kb: kilobyte (kB)
          - mb: megabyte (MB)
          - gb: gigabyte (GB)
          - tb: terabyte (TB)

  -S, --stack-size <STACK_SIZE>
          Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)

  -j, --output-json
          Output the directory tree as json to the current directory

  -M, --mtime <MTIME>
          +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (−∞, curr−(n+1)), n => [curr−(n+1), curr−n), and -n => (𝑐𝑢𝑟𝑟−𝑛, +∞)

  -A, --atime <ATIME>
          just like -mtime, but based on file access time

  -y, --ctime <CTIME>
          just like -mtime, but based on file change time

      --files0-from <FILES0_FROM>
          Read NUL-terminated paths from FILE (use `-` for stdin)

      --files-from <FILES_FROM>
          Read newline-terminated paths from FILE (use `-` for stdin)

      --collapse <COLLAPSE>
          Keep these directories collapsed

  -m, --filetime <FILETIME>
          Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time

          Possible values:
          - a: last accessed time
          - c: last changed time
          - m: last modified time

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version"""


class Parser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        self.exit(2, f"error: {message}\n")


def build_parser():
    p = Parser(add_help=False, prog="executable", allow_abbrev=False)
    p.add_argument("paths", nargs="*")
    p.add_argument("-d", "--depth", type=int)
    p.add_argument("-T", "--threads")
    p.add_argument("--config")
    p.add_argument("-n", "--number-of-lines", dest="lines", type=int)
    p.add_argument("-p", "--full-paths", action="store_true")
    p.add_argument("-X", "--ignore-directory", action="append", default=[])
    p.add_argument("-I", "--ignore-all-in-file")
    p.add_argument("-L", "--dereference-links", action="store_true")
    p.add_argument("-x", "--limit-filesystem", action="store_true")
    p.add_argument("-s", "--apparent-size", action="store_true")
    p.add_argument("-r", "--reverse", action="store_true")
    p.add_argument("-c", "--no-colors", action="store_true")
    p.add_argument("-C", "--force-colors", action="store_true")
    p.add_argument("-b", "--no-percent-bars", action="store_true")
    p.add_argument("-B", "--bars-on-right", action="store_true")
    p.add_argument("-z", "--min-size", default="0")
    p.add_argument("-R", "--screen-reader", action="store_true")
    p.add_argument("--skip-total", action="store_true")
    p.add_argument("-f", "--filecount", action="store_true")
    p.add_argument("-i", "--ignore-hidden", action="store_true")
    p.add_argument("-v", "--invert-filter", action="append", default=[])
    p.add_argument("-e", "--filter", action="append", default=[])
    p.add_argument("-t", "--file-types", action="store_true")
    p.add_argument("-w", "--terminal-width", type=int, default=80)
    p.add_argument("-P", "--no-progress", action="store_true")
    p.add_argument("--print-errors", action="store_true")
    p.add_argument("-D", "--only-dir", action="store_true")
    p.add_argument("-F", "--only-file", action="store_true")
    p.add_argument("-o", "--output-format", choices=FORMATS, default=None)
    p.add_argument("-S", "--stack-size")
    p.add_argument("-j", "--output-json", action="store_true")
    p.add_argument("-M", "--mtime")
    p.add_argument("-A", "--atime")
    p.add_argument("-y", "--ctime")
    p.add_argument("--files0-from")
    p.add_argument("--files-from")
    p.add_argument("--collapse", action="append", default=[])
    p.add_argument("-m", "--filetime", choices=("a", "c", "m"))
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    return p


def option_present(argv, names):
    return any(any(a == n or a.startswith(n + "=") for n in names) for a in argv)


def apply_config(argv):
    cfg = None
    for i, a in enumerate(argv):
        if a == "--config" and i + 1 < len(argv):
            cfg = argv[i + 1]
        elif a.startswith("--config="):
            cfg = a.split("=", 1)[1]
    if not cfg:
        for cand in (os.path.expanduser("~/.config/dust/config.toml"), os.path.expanduser("~/.dust.toml")):
            if os.path.exists(cand):
                cfg = cand
                break
    if not cfg or not os.path.exists(cfg):
        return argv
    prepend = []
    bools = {
        "reverse": ("-r", ["-r", "--reverse"]),
        "display-full-paths": ("-p", ["-p", "--full-paths"]),
        "display-apparent-size": ("-s", ["-s", "--apparent-size"]),
        "no-colors": ("-c", ["-c", "--no-colors"]),
        "no-bars": ("-b", ["-b", "--no-percent-bars"]),
        "skip-total": ("--skip-total", ["--skip-total"]),
        "ignore-hidden": ("-i", ["-i", "--ignore-hidden"]),
    }
    vals = {
        "output-format": ("-o", ["-o", "--output-format"]),
        "number-of-lines": ("-n", ["-n", "--number-of-lines"]),
    }
    try:
        lines = open(cfg, encoding="utf-8").read().splitlines()
    except OSError:
        return argv
    for line in lines:
        line = line.split("#", 1)[0].strip()
        if not line or "=" not in line:
            continue
        k, v = [x.strip() for x in line.split("=", 1)]
        v = v.strip().strip('"').strip("'")
        if k in bools and v.lower() == "true" and not option_present(argv, bools[k][1]):
            prepend.append(bools[k][0])
        if k in vals and v and not option_present(argv, vals[k][1]):
            prepend += [vals[k][0], v]
    return prepend + argv


def parse_size(s: str) -> int:
    s = str(s).strip()
    m = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)([kmgtKMGT]?[bB]?)?", s)
    if not m:
        return 0
    num = float(m.group(1))
    unit = (m.group(2) or "").lower()
    mult = {"": 1, "b": 1, "k": 1024, "kb": 1000, "m": 1024**2, "mb": 1000**2,
            "g": 1024**3, "gb": 1000**3, "t": 1024**4, "tb": 1000**4}.get(unit, 1)
    return int(num * mult)


def fmt_size(n: int, mode: Optional[str]) -> str:
    if mode == "b":
        return f"{n}B"
    fixed = {
        "k": (1024, "KiB"), "m": (1024**2, "MiB"), "g": (1024**3, "GiB"), "t": (1024**4, "TiB"),
        "kb": (1000, "kB"), "mb": (1000**2, "MB"), "gb": (1000**3, "GB"), "tb": (1000**4, "TB"),
    }
    if mode in fixed:
        div, suf = fixed[mode]
        return f"{n // div}{suf}"
    base = 1000 if mode == "si" else 1024
    units = ["B", "K", "M", "G", "T"] if mode != "si" else ["B", "kB", "MB", "GB", "TB"]
    val = float(n)
    idx = 0
    while val >= base and idx < len(units) - 1:
        val /= base
        idx += 1
    if idx == 0:
        return f"{int(val)}B"
    if val < 10:
        return f"{val:.1f}{units[idx]}"
    return f"{val:.0f}{units[idx]}"


def own_size(st, apparent: bool) -> int:
    return int(st.st_size if apparent else st.st_blocks * 512)


def path_matches(path: str, regs: List[re.Pattern]) -> bool:
    return any(r.search(path) for r in regs)


def time_ok(st, args) -> bool:
    for spec, val in ((args.mtime, st.st_mtime), (args.atime, st.st_atime), (args.ctime, st.st_ctime)):
        if spec and not compare_days(spec, val):
            return False
    return True


def compare_days(spec: str, ts: float) -> bool:
    try:
        if spec[0] in "+-":
            sign, n = spec[0], int(spec[1:])
        else:
            sign, n = "", int(spec)
    except Exception:
        return True
    age = int((time.time() - ts) // 86400)
    if sign == "+":
        return age > n
    if sign == "-":
        return age < n
    return age == n


def scan(path: str, args, include_regs, exclude_regs, root_dev=None, depth=0) -> Optional[Node]:
    try:
        st = os.stat(path) if args.dereference_links else os.lstat(path)
    except OSError as e:
        print(f"{e.strerror}: {path}", file=sys.stderr)
        return None
    name = os.path.basename(path.rstrip(os.sep)) or path
    if args.ignore_hidden and name.startswith(".") and depth > 0:
        return None
    norm = path
    if name in set(args.ignore_directory) or path in set(args.ignore_directory):
        return None
    if path_matches(norm, exclude_regs):
        return None
    is_dir = stat.S_ISDIR(st.st_mode)
    is_file = stat.S_ISREG(st.st_mode) or stat.S_ISLNK(st.st_mode) or not is_dir
    if args.limit_filesystem and root_dev is not None and is_dir and st.st_dev != root_dev:
        return None
    passes_filter = (not include_regs or path_matches(norm, include_regs)) and time_ok(st, args)
    own = own_size(st, args.apparent_size)
    node = Node(path=path, name=name, size=0, own_size=own, is_dir=is_dir, is_file=is_file, depth=depth)
    if is_dir and not (args.collapse and name in args.collapse):
        try:
            entries = sorted(os.listdir(path))
        except OSError as e:
            if args.print_errors:
                print(f"{e.strerror}: {path}", file=sys.stderr)
            entries = []
        for entry in entries:
            child = scan(os.path.join(path, entry), args, include_regs, exclude_regs, root_dev, depth + 1)
            if child is not None and (child.size > 0 or child.children or child.own_size > 0):
                node.children.append(child)
    if include_regs:
        node.size = (own if passes_filter and not is_dir else 0) + sum(c.size for c in node.children)
    elif args.filetime:
        vals = [getattr(st, f"st_{args.filetime}time", st.st_mtime)] + [c.size for c in node.children]
        node.size = int(max(vals)) if vals else 0
    elif args.filecount:
        node.size = (1 if stat.S_ISREG(st.st_mode) else 0) + sum(c.size for c in node.children)
    else:
        node.size = (own if passes_filter else 0) + sum(c.size for c in node.children)
    node.file_count = (1 if stat.S_ISREG(st.st_mode) else 0) + sum(c.file_count for c in node.children)
    return node


def flatten(node: Node, args, out=None):
    if out is None:
        out = []
    max_depth = args.depth
    show = True
    if args.only_dir and not node.is_dir:
        show = False
    if args.only_file and node.is_dir and node.depth != 0 and node.children:
        show = False
    if node.depth == 0:
        show = not args.skip_total
    if max_depth is not None and node.depth > max_depth:
        show = False
    if node.size < args._min_size and node.depth != 0 and not node.is_dir:
        show = False
    if max_depth is None or node.depth < max_depth:
        for c in sorted(node.children, key=lambda x: (x.size, x.name)):
            flatten(c, args, out)
    if show:
        out.append(node)
    return out


def display_name(n: Node, args):
    return n.path if args.full_paths or args.output_json else n.name


def render(nodes: List[Node], total: int, args) -> str:
    if args.reverse:
        nodes = list(reversed(nodes))
    limit = args.lines
    if limit and len(nodes) > limit:
        nodes = sorted(nodes, key=lambda x: x.size)[-limit:]
        if args.reverse:
            nodes = list(reversed(nodes))
    if args.screen_reader:
        lines = []
        for n in nodes:
            lines.append(f"{n.depth} {fmt_size(n.size, args.output_format):>6} {display_name(n, args)}")
        return "\n".join(lines)
    size_w = max([len(fmt_size(n.size, args.output_format)) for n in nodes] + [1])
    name_w = max([len(display_name(n, args)) for n in nodes] + [1])
    bar_w = max(1, args.terminal_width - size_w - name_w - 18)
    lines = []
    for i, n in enumerate(nodes):
        size = fmt_size(n.size, args.output_format).rjust(size_w)
        depthpad = "  " * max(0, n.depth)
        connector = "┌─┴ " if n.depth == 0 else ("└── " if i == len(nodes) - 1 else "├── ")
        tree = depthpad + connector + display_name(n, args)
        if args.no_percent_bars:
            lines.append(f"{size} {tree}")
            continue
        pct = 100 if total == 0 and n.depth == 0 else int(round((n.size * 100) / total)) if total else 0
        fill = max(1, int(bar_w * pct / 100)) if n.size else 1
        bar = "█" * min(fill, bar_w) + "░" * max(0, bar_w - fill)
        left = f"{size} {tree.ljust(name_w + max(0, n.depth)*2 + 4)}"
        if args.bars_on_right:
            lines.append(f"{left} {pct:>3}% │{bar}│")
        else:
            lines.append(f"{left}│{bar}│ {pct:>3}%")
    return "\n".join(lines)


def file_types(paths, args, include_regs, exclude_regs):
    buckets = {}
    total = 0
    def walk(p):
        nonlocal total
        try:
            st = os.stat(p) if args.dereference_links else os.lstat(p)
        except OSError:
            return
        name = os.path.basename(p)
        if args.ignore_hidden and name.startswith("."):
            return
        if path_matches(p, exclude_regs) or (include_regs and not path_matches(p, include_regs)):
            return
        if stat.S_ISDIR(st.st_mode):
            try:
                for e in os.listdir(p):
                    walk(os.path.join(p, e))
            except OSError:
                pass
        elif stat.S_ISREG(st.st_mode):
            ext = os.path.splitext(name)[1] or "(no extension)"
            sz = own_size(st, args.apparent_size)
            buckets[ext] = buckets.get(ext, 0) + sz
            total += sz
    for p in paths:
        walk(p)
    root = Node("(total)", "(total)", total, total, True, False, depth=0)
    root.children = [Node(k, k, v, v, False, True, depth=1) for k, v in buckets.items()]
    return root


def to_json(n: Node, args):
    return {"size": fmt_size(n.size, args.output_format), "name": display_name(n, args),
            "children": [to_json(c, args) for c in sorted(n.children, key=lambda x: (-x.size, x.name))]}


def read_paths_from(file_name: str, nul: bool):
    data = sys.stdin.buffer.read() if file_name == "-" else open(file_name, "rb").read()
    parts = data.split(b"\0" if nul else b"\n")
    return [p.decode(errors="surrogateescape") for p in parts if p]


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--help" in argv:
        print(HELP_LONG)
        return 0
    if "-h" in argv:
        print("""Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...  Input files or directories

Options:
  -d, --depth <DEPTH>              Depth to show
  -T, --threads <THREADS>          Number of threads to use
      --config <FILE>              Specify a config file to use
  -n, --number-of-lines <NUMBER>   Number of lines of output to show. (Default is terminal_height - 10)
  -p, --full-paths                 Subdirectories will not have their path shortened
  -X, --ignore-directory <PATH>    Exclude any file or directory with this path
  -s, --apparent-size              Use file length instead of blocks
  -r, --reverse                    Print tree upside down (biggest highest)
  -c, --no-colors                  No colors will be printed (Useful for commands like: watch)
  -b, --no-percent-bars            No percent bars or percentages will be displayed
  -D, --only-dir                   Only directories will be displayed
  -F, --only-file                  Only files will be displayed. (Finds your largest files)
  -o, --output-format <FORMAT>     Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version""")
        return 0
    if "-V" in argv or "--version" in argv:
        print(VERSION)
        return 0
    argv = apply_config(argv)
    parser = build_parser()
    args = parser.parse_args(argv)
    args._min_size = parse_size(args.min_size)
    paths = args.paths or ["."]
    if args.files_from:
        paths += read_paths_from(args.files_from, False)
    if args.files0_from:
        paths += read_paths_from(args.files0_from, True)
    excl = list(args.invert_filter)
    if args.ignore_all_in_file:
        try:
            excl += [line.strip() for line in open(args.ignore_all_in_file) if line.strip()]
        except OSError as e:
            print(f"{e.strerror}: {args.ignore_all_in_file}", file=sys.stderr)
            return 1
    try:
        include_regs = [re.compile(x) for x in args.filter]
        exclude_regs = [re.compile(x) for x in excl]
    except re.error as e:
        print(f"Invalid regex: {e}", file=sys.stderr)
        return 2
    roots = []
    status = 0
    if args.file_types:
        roots = [file_types(paths, args, include_regs, exclude_regs)]
    else:
        for p in paths:
            if not os.path.exists(p) and not os.path.islink(p):
                print(f"No such file or directory: {p}")
                status = 1
                continue
            root_dev = os.lstat(p).st_dev if args.limit_filesystem else None
            n = scan(p, args, include_regs, exclude_regs, root_dev)
            if n:
                roots.append(n)
    if not roots:
        return status
    if len(roots) == 1:
        root = roots[0]
    else:
        total = sum(r.size for r in roots)
        root = Node("(total)", "(total)", total, total, True, False, roots, 0)
        for r in roots:
            r.depth = 1
    if args.output_json:
        print(json.dumps(to_json(root, args), separators=(",", ":")))
    else:
        nodes = flatten(root, args)
        print(render(nodes, root.size, args))
    return status


if __name__ == "__main__":
    raise SystemExit(main())
