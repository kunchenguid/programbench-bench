#!/usr/bin/env python3
import csv
import gzip
import json
import os
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, time

VERSION = "2.0.4"
MONTHS = {m: i + 1 for i, m in enumerate("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split())}
DEFAULT_FIELDS = ["date", "status", "ref", "path"]
ALL_FIELDS = ["date", "time", "method", "status", "ip", "ref", "path"]
FIELD_ALIASES = {
    "d": "date", "date": "date", "t": "time", "time": "time",
    "m": "method", "method": "method", "s": "status", "status": "status",
    "i": "ip", "ip": "ip", "r": "ref", "ref": "ref", "referer": "ref",
    "p": "path", "path": "path",
}
RESOURCE_RE = re.compile(r"\.(?:png|jpe?g|gif|webp|svg|ico|css|js|map|woff2?|ttf|eot|mp4|mp3|avi|mov|pdf)(?:[?#].*)?$", re.I)
LOG_RE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<stamp>[^\]]+)\] "(?P<request>[^"]*)" '
    r'(?P<status>\d{3}) (?P<bytes>\S+) "(?P<referer>[^"]*)" "(?P<agent>[^"]*)".*$'
)


@dataclass
class Hit:
    raw: str
    dt: datetime
    date: str
    time: str
    ip: str
    method: str
    path: str
    status: str
    bytes_sent: int
    referer: str


def eprint(msg):
    print(msg, file=sys.stderr)


def usage():
    print(f"""rhit {VERSION}

Rhit analyzes your nginx logs.

Usage: rhit [options] [FILES]

Options:
  --help                 Print help information
  --version              Print the version
  --color <auto|yes|no>  Whether to have styles and colors
  -k, --key <KEY>        Key used in sorting and histogram, hits or bytes
  -l, --length <LENGTH>  Detail level, from 0 to 6
  -f, --fields <FIELDS>  Comma separated list of hit fields to display
  -c, --changes          Add changes tables
  -d, --date <DATE>      Filter dates
  -i, --ip <IP>          Ip address filter
  -m, --method <METHOD>  HTTP method filter
  -p, --path <PATH>      Path filter
  -r, --referer <REF>    Referer filter
  -s, --status <STATUS>  Status filter
  -t, --time <TIME>      Time of day filter
  -a, --all              Show all paths, including resources
      --no-name-check    Try to open all files
  -o, --output <OUTPUT>  tables, csv, json, or raw
      --silent-load      Don't print anything during load""")


def parse_args(argv):
    opts = {
        "files": [], "color": "auto", "key": "hits", "length": 1, "fields": None,
        "changes": False, "date": None, "ip": None, "method": None, "path": None,
        "referer": None, "status": None, "time": None, "all": False,
        "no_name_check": False, "output": "tables", "silent": False,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--help":
            usage(); sys.exit(0)
        if a == "--version":
            print(f"rhit {VERSION}"); sys.exit(0)
        if a in ("-c", "--changes"):
            opts["changes"] = True; i += 1; continue
        if a in ("-a", "--all"):
            opts["all"] = True; i += 1; continue
        if a == "--no-name-check":
            opts["no_name_check"] = True; i += 1; continue
        if a == "--silent-load":
            opts["silent"] = True; i += 1; continue
        takes = {
            "-k": "key", "--key": "key", "-l": "length", "--length": "length",
            "-f": "fields", "--fields": "fields", "--field": "fields",
            "-d": "date", "--date": "date", "-i": "ip", "--ip": "ip",
            "-m": "method", "--method": "method", "-p": "path", "--path": "path",
            "-r": "referer", "--referer": "referer", "-s": "status", "--status": "status",
            "-t": "time", "--time": "time", "-o": "output", "--output": "output",
            "--color": "color",
        }
        if a in takes:
            if i + 1 >= len(argv):
                eprint(f"error: The argument '{a}' requires a value but none was supplied")
                sys.exit(2)
            val = argv[i + 1]
            key = takes[a]
            opts[key] = val
            i += 2
            continue
        if a.startswith("-"):
            eprint(f"error: unexpected argument '{a}'")
            sys.exit(2)
        opts["files"].append(a)
        i += 1
    normalize_opts(opts)
    return opts


def normalize_opts(opts):
    out = opts["output"].lower()
    outmap = {"t": "tables", "table": "tables", "tables": "tables", "r": "raw", "raw": "raw",
              "c": "csv", "csv": "csv", "j": "json", "json": "json"}
    if out not in outmap:
        eprint(f"error: invalid value '{opts['output']}' for '--output <OUTPUT>': unrecognized output \"{opts['output']}\"")
        sys.exit(2)
    opts["output"] = outmap[out]
    key = opts["key"].lower()
    keymap = {"h": "hits", "hit": "hits", "hits": "hits", "b": "bytes", "byte": "bytes", "bytes": "bytes"}
    if key not in keymap:
        eprint(f"error: invalid value '{opts['key']}' for '--key <KEY>': unrecognized key \"{opts['key']}\"")
        sys.exit(2)
    opts["key"] = keymap[key]
    try:
        opts["length"] = max(0, int(opts["length"]))
    except ValueError:
        eprint(f"error: invalid value '{opts['length']}' for '--length <LENGTH>': invalid digit")
        sys.exit(2)
    if opts["fields"] is not None:
        opts["fields"] = parse_fields(opts["fields"])


def parse_fields(spec):
    s = spec.replace(",", "+").strip()
    if not s:
        return DEFAULT_FIELDS[:]
    fields = DEFAULT_FIELDS[:] if s[0] in "+-" else []
    pos = 0
    op = "+"
    while pos < len(s):
        if s[pos] in "+-":
            op = s[pos]; pos += 1; continue
        start = pos
        while pos < len(s) and s[pos] not in "+-":
            pos += 1
        token = s[start:pos].strip()
        if not token:
            continue
        if token in ("a", "all"):
            name = "all"
        else:
            matches = [v for k, v in FIELD_ALIASES.items() if k.startswith(token)]
            if token in FIELD_ALIASES:
                name = FIELD_ALIASES[token]
            elif matches:
                name = matches[0]
            else:
                eprint(f"error: invalid value '{spec}' for '--fields <FIELDS>': unrecognized field start '{token[0]}'")
                sys.exit(2)
        targets = ALL_FIELDS if name == "all" else [name]
        for f in targets:
            if op == "-":
                fields = [x for x in fields if x != f]
            else:
                fields = [x for x in fields if x != f] + [f]
    return fields


def candidate_files(paths, no_name_check=False):
    if not paths:
        paths = ["/var/log/nginx/access.log", "/var/log/nginx/access.log.1", "/var/log/nginx"]
    out = []
    for p in paths:
        if not os.path.exists(p):
            raise FileNotFoundError(p)
        if os.path.isdir(p):
            for root, _, files in os.walk(p):
                for name in files:
                    full = os.path.join(root, name)
                    if no_name_check or is_log_name(name):
                        out.append(full)
        else:
            out.append(p)
    return sorted(out)


def is_log_name(name):
    n = name.lower()
    return "access" in n or n.endswith(".log") or n.endswith(".log.gz") or n.endswith(".gz")


def open_text(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", errors="replace")
    return open(path, "rt", errors="replace")


def parse_line(line):
    line = line.rstrip("\n")
    m = LOG_RE.match(line)
    if not m:
        return None
    gd = m.groupdict()
    stamp = gd["stamp"].split()[0]
    try:
        left, tm = stamp.split(":", 1)
        day, mon, year = left.split("/")
        dt = datetime.strptime(f"{year}-{MONTHS[mon]:02d}-{int(day):02d} {tm}", "%Y-%m-%d %H:%M:%S")
    except Exception:
        return None
    req = gd["request"]
    parts = req.split()
    method = parts[0] if len(parts) >= 1 and parts[0] else "none"
    path = parts[1] if len(parts) >= 2 else ""
    if method not in {"GET", "POST", "HEAD", "PUT", "DELETE", "PATCH", "OPTIONS", "CONNECT", "TRACE"}:
        method = "other"
    b = 0 if gd["bytes"] == "-" else int(gd["bytes"]) if gd["bytes"].isdigit() else 0
    return Hit(line, dt, dt.strftime("%Y/%m/%d"), dt.strftime("%H:%M:%S"), gd["ip"], method, path, gd["status"], b, gd["referer"])


def load_hits(files):
    hits = []
    for path in files:
        with open_text(path) as f:
            for line in f:
                h = parse_line(line)
                if h:
                    hits.append(h)
    hits.sort(key=lambda h: h.dt)
    return hits


def simple_regex_filter(expr, value):
    neg = expr.startswith("!")
    if neg:
        expr = expr[1:]
    try:
        ok = re.search(expr, value) is not None
    except re.error as ex:
        raise ValueError(str(ex))
    return (not ok) if neg else ok


def str_filter(expr, value):
    if expr is None:
        return True
    # Commas are conjunctions. Whitespace-surrounded & and | support common complex examples.
    if "," in expr:
        return all(str_filter(part.strip(), value) for part in expr.split(",") if part.strip())
    spaced = re.split(r"\s+(\&|\|)\s+", expr)
    if len(spaced) > 1:
        res = str_filter(spaced[0].strip(), value)
        idx = 1
        while idx < len(spaced):
            op, rhs = spaced[idx], spaced[idx + 1]
            res = (res and str_filter(rhs.strip(), value)) if op == "&" else (res or str_filter(rhs.strip(), value))
            idx += 2
        return res
    if expr.startswith("!(") and expr.endswith(")"):
        return not str_filter(expr[2:-1].strip(), value)
    if expr.startswith("(") and expr.endswith(")"):
        return str_filter(expr[1:-1].strip(), value)
    return simple_regex_filter(expr, value)


def status_filter(expr, status):
    if expr is None:
        return True
    st = int(status)
    any_positive = False
    matched_positive = False
    for raw in expr.split(","):
        part = raw.strip()
        if not part:
            continue
        neg = part.startswith("!")
        if neg:
            part = part[1:]
        ok = False
        if re.fullmatch(r"\dxx", part):
            ok = st // 100 == int(part[0])
        elif re.fullmatch(r"\d{3}-\d{3}", part):
            a, b = map(int, part.split("-"))
            ok = a <= st <= b
        elif part.isdigit():
            ok = st == int(part)
        if neg and ok:
            return False
        if not neg:
            any_positive = True
            matched_positive = matched_positive or ok
    return matched_positive if any_positive else True


def parse_partial_date(s, years):
    date_part, _, time_part = s.partition("T")
    nums = [int(x) for x in date_part.split("/") if x]
    if len(nums) == 1:
        y, mo, da = nums[0], 1, 1
        gran = "year"
    elif len(nums) == 2:
        if nums[0] > 31:
            y, mo, da = nums[0], nums[1], 1; gran = "month"
        else:
            y = years[0] if len(years) == 1 else datetime.now().year
            mo, da = nums; gran = "day"
    else:
        y, mo, da = nums[0], nums[1], nums[2]; gran = "day"
    hh, mm, ss = 0, 0, 0
    if time_part:
        tnums = [int(x) for x in time_part.split(":")]
        hh = tnums[0]; mm = tnums[1] if len(tnums) > 1 else 0; ss = tnums[2] if len(tnums) > 2 else 0
        gran = "second" if len(tnums) > 2 else "minute"
    start = datetime(y, mo, da, hh, mm, ss)
    if time_part:
        if gran == "minute":
            end = start.replace(second=59)
        else:
            end = start
    elif gran == "year":
        end = datetime(y, 12, 31, 23, 59, 59)
    elif gran == "month":
        ny, nm = (y + 1, 1) if mo == 12 else (y, mo + 1)
        end = datetime(ny, nm, 1) - __import__("datetime").timedelta(seconds=1)
    else:
        end = datetime(y, mo, da, 23, 59, 59)
    return start, end


def date_filter(expr, dt, years):
    if expr is None:
        return True
    neg = expr.startswith("!")
    if neg:
        expr = expr[1:]
    if expr.startswith(">"):
        start, _ = parse_partial_date(expr[1:], years)
        ok = dt > start
    elif expr.startswith("<"):
        _, end = parse_partial_date(expr[1:], years)
        ok = dt < end
    elif "-" in expr:
        a, b = expr.split("-", 1)
        start, _ = parse_partial_date(a, years)
        _, end = parse_partial_date(b, years)
        ok = start <= dt <= end
    else:
        start, end = parse_partial_date(expr, years)
        ok = start <= dt <= end
    return not ok if neg else ok


def parse_tod(s):
    nums = [int(x) for x in s.split(":")]
    return time(nums[0], nums[1] if len(nums) > 1 else 0, nums[2] if len(nums) > 2 else 0)


def time_filter(expr, tstr):
    if expr is None:
        return True
    t = parse_tod(tstr)
    if expr.startswith(">"):
        return t > parse_tod(expr[1:])
    if expr.startswith("<"):
        return t < parse_tod(expr[1:])
    if "-" in expr:
        a, b = expr.split("-", 1)
        return parse_tod(a) <= t <= parse_tod(b)
    return t == parse_tod(expr)


def filter_hits(hits, opts):
    years = sorted({h.dt.year for h in hits})
    out = []
    for h in hits:
        if not date_filter(opts["date"], h.dt, years): continue
        if not time_filter(opts["time"], h.time): continue
        if not str_filter(opts["ip"], h.ip): continue
        if opts["method"] and not str_filter(opts["method"], h.method): continue
        if not str_filter(opts["path"], h.path): continue
        if not str_filter(opts["referer"], h.referer): continue
        if not status_filter(opts["status"], h.status): continue
        out.append(h)
    return out


def output_json(hits):
    arr = [{
        "date": h.date, "time": h.time, "remote_addr": h.ip, "method": h.method,
        "path": h.path, "status": h.status, "bytes_sent": h.bytes_sent, "referer": h.referer
    } for h in hits]
    print(json.dumps(arr, indent=2))


def output_csv(hits):
    def quoted(s):
        return '"' + str(s).replace('"', '""') + '"'
    print("date,time,remote address,method,path,status,bytes sent,referer")
    for h in hits:
        print(",".join([
            h.date, h.time, h.ip, h.method, quoted(h.path), h.status,
            str(h.bytes_sent), quoted(h.referer),
        ]))


def field_value(h, field):
    return {"date": h.date, "time": h.time[:2], "method": h.method, "status": h.status,
            "ip": h.ip, "ref": h.referer, "path": h.path}[field]


def label_for(field):
    return {"date": "date", "time": "hour", "method": "method", "status": "status",
            "ip": "IP address", "ref": "referrer", "path": "path"}[field]


def count_rows(hits, field, include_resources):
    data = defaultdict(lambda: [0, 0])
    for h in hits:
        if field == "path" and not include_resources and RESOURCE_RE.search(h.path):
            continue
        if field == "ref" and h.referer == "-":
            continue
        v = field_value(h, field)
        data[v][0] += 1
        data[v][1] += h.bytes_sent
    return data


def print_table(headers, rows):
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = min(max(widths[i], len(str(cell))), 60)
    def fmt(row):
        return "  ".join(str(c)[:widths[i]].ljust(widths[i]) for i, c in enumerate(row))
    print(fmt(headers))
    print(fmt(["-" * w for w in widths]))
    for row in rows:
        print(fmt(row))


def output_tables(hits, opts):
    total = len(hits)
    bytes_total = sum(h.bytes_sent for h in hits)
    if total:
        print(f"{total} hit{'s' if total != 1 else ''} and {bytes_total} from {hits[0].date} to {hits[-1].date}")
    else:
        print("0 hits")
    fields = opts["fields"] or DEFAULT_FIELDS
    limit = 2 + opts["length"] * 4
    for field in fields:
        data = count_rows(hits, field, opts["all"])
        if field == "date":
            rows = []
            for k in sorted(data):
                rows.append([k, data[k][0], data[k][1]])
            if rows:
                print_table(["date", "hits", "bytes"], rows)
            continue
        if field == "time":
            rows = []
            for hour in range(24):
                k = str(hour)
                vals = data.get(f"{hour:02d}", [0, 0])
                rows.append([k, vals[0], vals[1]])
            print_table(["hour", "hits", "bytes"], rows)
            continue
        plural = {"status": "HTTP status codes", "ip": "remote IP addresses", "ref": "referrers", "path": "paths", "method": "methods"}[field]
        extra = " (excluding resources like images, css, etc.)." if field == "path" and not opts["all"] else "."
        print(f"{len(data)} {plural}{extra} ")
        rows = []
        items = sorted(data.items(), key=lambda kv: (-kv[1][0 if opts["key"] == "hits" else 1], kv[0]))
        for idx, (val, (cnt, b)) in enumerate(items[:limit], 1):
            pct = f"{(cnt * 100 / total):.1f}%" if total else "0.0%"
            rows.append([idx, val, cnt, pct, b])
        if rows:
            print_table(["#", label_for(field), "hits", "%", "bytes"], rows)


def main(argv):
    opts = parse_args(argv)
    try:
        files = candidate_files(opts["files"], opts["no_name_check"])
        hits = load_hits(files)
        hits = filter_hits(hits, opts)
    except FileNotFoundError as ex:
        eprint(f'Error: PathNotFound("{ex.args[0]}")'); return 1
    except Exception as ex:
        eprint(f"Error: {ex}"); return 1
    if opts["output"] == "raw":
        for h in hits:
            print(h.raw)
    elif opts["output"] == "csv":
        output_csv(hits)
    elif opts["output"] == "json":
        output_json(hits)
    else:
        output_tables(hits, opts)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
