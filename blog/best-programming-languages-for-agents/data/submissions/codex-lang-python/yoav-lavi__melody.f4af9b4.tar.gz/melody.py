#!/usr/bin/env python3
import argparse
import re
import sys


HELP = """A CLI wrapping the Melody language compiler

Usage: executable [OPTIONS] [INPUT_FILE_PATH]

Arguments:
  [INPUT_FILE_PATH]  Read from a file
                     Use '-' and or pipe input to read from stdin

Options:
  -o, --output <OUTPUT_FILE_PATH>           Write to a file
  -n, --no-color                            Print output with no color
  -r, --repl                                Start the Melody REPL
      --generate-completions <completions>  Outputs completions for the selected shell
                                            To use, write the output to the appropriate location for your shell
  -t, --test <test>                         Test the compiled regex against a string
  -f, --test-file <test-file>               Test the compiled regex against the contents of a file
  -h, --help                                Print help
  -V, --version                             Print version
"""


COMPLETION = """_melody() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    cmd=""
    opts="-o -n -r -t -f -h -V --output --no-color --repl --generate-completions --test --test-file --help --version [INPUT_FILE_PATH]"
    COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
}
complete -F _melody melody
"""


class MelodyError(Exception):
    pass


SYMBOLS = {
    "char": ".",
    "space": " ",
    "whitespace": r"\s",
    "digit": r"\d",
    "word": r"\w",
    "start": "^",
    "end": "$",
    "boundary": r"\b",
    "newline": r"\n",
    "tab": r"\t",
    "null": r"\0",
    "backspace": r"[\b]",
    "feed": r"\f",
    "alphabetic": "[a-zA-Z]",
    "alphanumeric": "[a-zA-Z0-9]",
}

NEG_SYMBOLS = {
    "space": "[^ ]",
    "whitespace": r"\S",
    "digit": r"\D",
    "word": r"\W",
    "boundary": r"\B",
    "newline": r"[^\n]",
    "tab": r"[^\t]",
    "null": r"[^\0]",
    "backspace": r"[^\b]",
    "feed": r"[^\f]",
    "alphabetic": "[^a-zA-Z]",
    "alphanumeric": "[^a-zA-Z0-9]",
}


def escape_literal(s):
    special = set(r"\.+*?^$|()[]{}")
    out = []
    for ch in s:
        if ch == "\n":
            out.append(r"\n")
        elif ch == "\t":
            out.append(r"\t")
        elif ch == "\r":
            out.append(r"\r")
        elif ch in special:
            out.append("\\" + ch)
        else:
            out.append(ch)
    return "".join(out)


class Parser:
    def __init__(self, text):
        self.text = text
        self.i = 0
        self.n = len(text)

    def error(self, msg="expected root"):
        raise MelodyError(msg)

    def peek(self):
        return self.text[self.i] if self.i < self.n else ""

    def starts(self, s):
        return self.text.startswith(s, self.i)

    def skip_ws(self):
        while self.i < self.n:
            if self.text[self.i].isspace():
                self.i += 1
            elif self.starts("//"):
                j = self.text.find("\n", self.i)
                self.i = self.n if j < 0 else j + 1
            elif self.starts("/*"):
                j = self.text.find("*/", self.i + 2)
                self.i = self.n if j < 0 else j + 2
            else:
                break

    def consume_word(self, word):
        self.skip_ws()
        end = self.i + len(word)
        if self.text[self.i:end] == word and (end >= self.n or not (self.text[end].isalnum() or self.text[end] in "_-")):
            self.i = end
            return True
        return False

    def ident(self):
        self.skip_ws()
        m = re.match(r"[A-Za-z_][A-Za-z0-9_-]*", self.text[self.i:])
        if not m:
            return None
        self.i += len(m.group(0))
        return m.group(0)

    def number(self):
        self.skip_ws()
        m = re.match(r"\d+", self.text[self.i:])
        if not m:
            return None
        self.i += len(m.group(0))
        return int(m.group(0))

    def expect(self, ch):
        self.skip_ws()
        if self.peek() != ch:
            self.error(f"expected {ch}")
        self.i += 1

    def parse(self):
        out = self.sequence(stop=None)
        self.skip_ws()
        if self.i < self.n:
            self.error("expected root")
        return out

    def sequence(self, stop):
        parts = []
        while True:
            self.skip_ws()
            if self.i >= self.n or (stop and self.peek() == stop):
                break
            if self.peek() == ";":
                self.i += 1
                continue
            parts.append(self.expr())
            self.skip_ws()
            if self.peek() == ";":
                self.i += 1
        return "".join(parts)

    def block(self, mode):
        self.expect("{")
        if mode == "either":
            alts = []
            while True:
                self.skip_ws()
                if self.i >= self.n:
                    self.error("expected }")
                if self.peek() == "}":
                    break
                alts.append(self.expr())
                self.skip_ws()
                if self.peek() == ";":
                    self.i += 1
            self.expect("}")
            if not alts:
                self.error("expected expression")
            return "(?:" + "|".join(alts) + ")"
        body = self.sequence(stop="}")
        self.expect("}")
        if body == "":
            self.error("expected expression")
        return body

    def expr(self):
        self.skip_ws()
        save = self.i
        neg = self.consume_word("not")
        self.skip_ws()
        if neg and (self.starts("ahead") or self.starts("behind")):
            kind = self.ident()
            body = self.block(kind)
            return "(?!" + body + ")" if kind == "ahead" else "(?<!" + body + ")"
        if neg:
            return self.negated_atom()
        self.i = save

        q = self.quantifier_prefix()
        if q is not None:
            if not self.consume_word("of"):
                self.error("expected of")
            atom = self.atom()
            return atom + q
        return self.atom()

    def quantifier_prefix(self):
        self.skip_ws()
        save = self.i
        if self.consume_word("some"):
            return "+"
        if self.consume_word("any"):
            return "*"
        if self.consume_word("option"):
            return "?"
        n = self.number()
        if n is not None:
            if self.consume_word("to"):
                m = self.number()
                if m is None:
                    self.error("expected amount")
                return "{" + str(n) + "," + str(m) + "}"
            return "{" + str(n) + "}"
        self.i = save
        return None

    def atom(self):
        self.skip_ws()
        if self.peek() in "\"'":
            return escape_literal(self.string())
        if self.peek() == "`":
            return self.raw()
        if self.peek() == "<":
            return self.symbol(False)
        if self.starts("match"):
            self.ident()
            return "(?:" + self.block("match") + ")"
        if self.starts("either"):
            self.ident()
            return self.block("either")
        if self.starts("capture"):
            self.ident()
            self.skip_ws()
            name = None
            if self.peek() != "{":
                name = self.ident()
            body = self.block("capture")
            return f"(?<{name}>{body})" if name else f"({body})"
        if self.starts("ahead"):
            self.ident()
            return "(?=" + self.block("ahead") + ")"
        if self.starts("behind"):
            self.ident()
            return "(?<=" + self.block("behind") + ")"
        r = self.try_range()
        if r is not None:
            return r
        self.error("expected root")

    def negated_atom(self):
        self.skip_ws()
        if self.peek() == "<":
            return self.symbol(True)
        r = self.try_range(neg=True)
        if r is not None:
            return r
        self.error("expected amount, class_content, or assertion_type")

    def try_range(self, neg=False):
        self.skip_ws()
        save = self.i
        a = self.ident()
        if not a or len(a) != 1:
            self.i = save
            return None
        if not self.consume_word("to"):
            self.i = save
            return None
        b = self.ident()
        if not b or len(b) != 1:
            self.error("expected range")
        return "[^" + re.escape(a) + "-" + re.escape(b) + "]" if neg else "[" + re.escape(a) + "-" + re.escape(b) + "]"

    def string(self):
        quote = self.peek()
        self.i += 1
        out = []
        while self.i < self.n:
            c = self.text[self.i]
            self.i += 1
            if c == quote:
                return "".join(out)
            if c == "\\" and self.i < self.n:
                e = self.text[self.i]
                self.i += 1
                out.append({"n": "\n", "t": "\t", "r": "\r"}.get(e, e))
            else:
                out.append(c)
        self.error("expected literal")

    def raw(self):
        self.i += 1
        j = self.text.find("`", self.i)
        if j < 0:
            self.error("expected raw")
        s = self.text[self.i:j]
        self.i = j + 1
        return s

    def symbol(self, neg):
        self.expect("<")
        j = self.text.find(">", self.i)
        if j < 0:
            self.error("expected symbol")
        name = self.text[self.i:j].strip()
        self.i = j + 1
        if "::" in name:
            raise MelodyError("usage of an unrecognized symbol namespace")
        if neg:
            if name in NEG_SYMBOLS:
                return NEG_SYMBOLS[name]
            if name == "char":
                raise MelodyError("negative char not allowed")
            if name in ("start", "end"):
                raise MelodyError(f"negative {name} not allowed")
            raise MelodyError("usage of an unrecognized symbol")
        if name not in SYMBOLS:
            raise MelodyError("usage of an unrecognized symbol")
        return SYMBOLS[name]


def compile_melody(text):
    return Parser(text).parse()


def read_input(path):
    if path is None or path == "-":
        return sys.stdin.read()
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except OSError:
        print(f"Error: unable read file at path {path}", file=sys.stderr)
        sys.exit(65)


def run_repl():
    while True:
        try:
            line = input("> ")
        except EOFError:
            print()
            return
        if line.strip() in ("exit", "quit", ":q"):
            return
        try:
            print(compile_melody(line))
        except MelodyError as e:
            print(f"Error: {e}", file=sys.stderr)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--help" in argv or "-h" in argv:
        print(HELP, end="")
        return 0
    if "--version" in argv or "-V" in argv:
        print("melody_cli 0.20.0")
        return 0
    if "--generate-completions" in argv:
        print(COMPLETION, end="")
        return 0
    if "-r" in argv or "--repl" in argv:
        run_repl()
        return 0
    for a in argv:
        if a.startswith("-") and a not in ("-", "-o", "--output", "-n", "--no-color", "-t", "--test", "-f", "--test-file"):
            print(f"error: unexpected argument '{a}' found\n", file=sys.stderr)
            print(f"  tip: to pass '{a}' as a value, use '-- {a}'\n", file=sys.stderr)
            print("Usage: executable [OPTIONS] [INPUT_FILE_PATH]\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            return 2

    ap = argparse.ArgumentParser(add_help=False, prog="executable")
    ap.add_argument("-o", "--output")
    ap.add_argument("-n", "--no-color", action="store_true")
    ap.add_argument("-t", "--test")
    ap.add_argument("-f", "--test-file")
    ap.add_argument("input", nargs="?")
    try:
        ns = ap.parse_args(argv)
    except SystemExit:
        return 2

    text = read_input(ns.input)
    try:
        regex = compile_melody(text)
    except MelodyError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 65

    if ns.output:
        with open(ns.output, "w", encoding="utf-8") as f:
            f.write(regex)
        return 0
    if ns.test is not None:
        py_regex = re.sub(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>", r"(?P<\1>", regex)
        matched = re.search(py_regex, ns.test) is not None
        print(f"'{ns.test}' {'matched' if matched else 'did not match'}")
        return 0
    if ns.test_file:
        try:
            with open(ns.test_file, "r", encoding="utf-8") as f:
                data = f.read()
        except OSError:
            print(f"Error: unable read file at path {ns.test_file}", file=sys.stderr)
            return 65
        py_regex = re.sub(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>", r"(?P<\1>", regex)
        matched = re.search(py_regex, data) is not None
        print(f"{ns.test_file} {'matched' if matched else 'did not match'}")
        return 0
    print(regex)
    return 0


if __name__ == "__main__":
    sys.exit(main())
