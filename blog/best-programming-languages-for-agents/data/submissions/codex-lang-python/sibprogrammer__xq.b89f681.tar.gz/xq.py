#!/usr/bin/env python3
import argparse
import html
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict


VERSION = "xq version 1.4.0"


class XqArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        if message.startswith("unrecognized arguments:"):
            arg = message.split(":", 1)[1].strip().split()[0]
            print(f"Error: unknown flag: {arg}", file=sys.stderr)
        else:
            print(f"Error: {message}", file=sys.stderr)
        raise SystemExit(1)


def read_input(path):
    if path:
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except OSError:
            print(f"Error: open {path}: no such file or directory", file=sys.stderr)
            raise SystemExit(1)
    return sys.stdin.read()


def indent_unit(args):
    return "\t" if args.tab else " " * args.indent


def local_name(tag):
    return tag.rsplit("}", 1)[-1]


def esc_text(s):
    return html.escape(s or "", quote=False)


def esc_attr(s):
    return html.escape(s or "", quote=True)


def serialize_xml(elem):
    return ET.tostring(elem, encoding="unicode", short_empty_elements=True)


def element_text(elem):
    return "".join(elem.itertext()).strip()


def format_xml_element(elem, unit="  ", level=0):
    pad = unit * level
    if elem.tag is ET.Comment:
        return [f"{pad}<!--{elem.text or ''}-->"]
    if elem.tag is ET.ProcessingInstruction:
        return [f"{pad}<?{elem.text or ''}?>"]
    attrs = "".join(f' {k}="{esc_attr(v)}"' for k, v in elem.attrib.items())
    tag = local_name(elem.tag)
    children = list(elem)
    text = (elem.text or "").strip()
    if not children:
        if text:
            return [f"{pad}<{tag}{attrs}>{esc_text(text)}</{tag}>"]
        return [f"{pad}<{tag}{attrs}/>"]
    lines = []
    if text:
        lines.append(f"{pad}<{tag}{attrs}>{esc_text(text)}")
    else:
        lines.append(f"{pad}<{tag}{attrs}>")
    for child in children:
        lines.extend(format_xml_element(child, unit, level + 1))
        tail = (child.tail or "").strip()
        if tail:
            lines.append(f"{unit * (level + 1)}{esc_text(tail)}")
    lines.append(f"{pad}</{tag}>")
    return lines


def format_xml(data, unit):
    parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
    root = ET.fromstring(data, parser=parser)
    return "\n".join(format_xml_element(root, unit)) + "\n"


def soup_for(data):
    from bs4 import BeautifulSoup
    return BeautifulSoup(data, "html.parser")


def format_bs_node(node, unit="  ", level=0):
    from bs4 import NavigableString, Tag
    pad = unit * level
    if isinstance(node, NavigableString):
        txt = str(node).strip()
        return [pad + txt] if txt else []
    if not isinstance(node, Tag):
        return []
    attrs = []
    for k, v in node.attrs.items():
        if isinstance(v, list):
            v = " ".join(v)
        attrs.append(f' {k}="{esc_attr(str(v))}"')
    attr_s = "".join(attrs)
    children = [c for c in node.contents if not (isinstance(c, NavigableString) and not str(c).strip())]
    name = node.name
    if not children:
        if name in {"br", "img", "input", "meta", "link", "hr", "area", "base", "col", "embed", "param", "source", "track", "wbr"}:
            return [f"{pad}<{name}{attr_s}/>"]
        return [f"{pad}<{name}{attr_s}></{name}>"]
    if len(children) == 1 and isinstance(children[0], NavigableString):
        return [f"{pad}<{name}{attr_s}>{esc_text(str(children[0]).strip())}</{name}>"]
    first_text = ""
    if children and isinstance(children[0], NavigableString):
        first_text = esc_text(str(children[0]).strip())
        children = children[1:]
    lines = [f"{pad}<{name}{attr_s}>{first_text}"]
    for child in children:
        lines.extend(format_bs_node(child, unit, level + 1))
    lines.append(f"{pad}</{name}>")
    return lines


def format_html(data, unit):
    soup = soup_for(data)
    roots = [c for c in soup.contents if getattr(c, "name", None) or str(c).strip()]
    lines = []
    for r in roots:
        lines.extend(format_bs_node(r, unit, 0))
    return "\n".join(lines) + ("\n" if lines else "")


def xml_to_json_obj(elem, depth=-1, level=0):
    kids = list(elem)
    attrs = {f"@{k}": v for k, v in elem.attrib.items()}
    text = (elem.text or "").strip()
    if depth >= 0 and level >= depth:
        return element_text(elem)
    if not kids and not attrs:
        return text
    obj = {}
    if text:
        obj["#text"] = text
    obj.update(attrs)
    grouped = defaultdict(list)
    for child in kids:
        grouped[local_name(child.tag)].append(xml_to_json_obj(child, depth, level + 1))
    for k in sorted(grouped):
        vals = grouped[k]
        obj[k] = vals[0] if len(vals) == 1 else vals
    return obj


def xml_json(data, compact=False, depth=-1):
    root = ET.fromstring(data)
    obj = {local_name(root.tag): xml_to_json_obj(root, depth, 0)}
    if compact:
        return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ": ")) + "\n"
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + "\n"


def find_path(nodes, part):
    m = re.fullmatch(r"([A-Za-z_][\w.\-]*|\*)?(?:\[(\d+)\])?(?:\[@([\w:\-]+)=(['\"])(.*?)\4\])?", part)
    if not m:
        return []
    tag, index, attr, _, val = m.groups()
    out = []
    for node in nodes:
        matches = [c for c in list(node) if (tag in (None, "", "*") or local_name(c.tag) == tag)]
        if attr:
            matches = [c for c in matches if c.attrib.get(attr) == val]
        if index:
            i = int(index) - 1
            matches = [matches[i]] if 0 <= i < len(matches) else []
        out.extend(matches)
    return out


def match_xpath_part(node, part):
    m = re.fullmatch(r"([A-Za-z_][\w.\-]*|\*)?(?:\[(\d+)\])?(?:\[@([\w:\-]+)=(['\"])(.*?)\4\])?", part)
    if not m:
        return False
    tag, _index, attr, _, val = m.groups()
    if tag not in (None, "", "*") and local_name(node.tag) != tag:
        return False
    if attr and node.attrib.get(attr) != val:
        return False
    return True


def xml_xpath(data, expr):
    root = ET.fromstring(data)
    attr = None
    if "/@" in expr:
        expr, attr = expr.rsplit("/@", 1)
    expr = expr.strip()
    nodes = []
    if expr.startswith("//"):
        part = expr[2:]
        if "/" in part:
            first, rest = part.split("/", 1)
        else:
            first, rest = part, ""
        nodes = [e for e in root.iter() if match_xpath_part(e, first)]
        for p in filter(None, rest.split("/")):
            nodes = find_path(nodes, p)
    elif expr.startswith("/"):
        parts = [p for p in expr.split("/") if p]
        if parts and (parts[0] == local_name(root.tag) or parts[0] == "*"):
            nodes = [root]
            for p in parts[1:]:
                nodes = find_path(nodes, p)
        else:
            nodes = []
    else:
        nodes = find_path([root], expr)
    if attr:
        return [n.attrib[attr] for n in nodes if attr in n.attrib], True
    return nodes, False


def colorize(s):
    s = re.sub(r'(</?[\w:.-]+|/?>)', lambda m: "\033[33m" + m.group(1) + "\033[0m", s)
    s = re.sub(r'(\s[\w:.-]+)(="[^"]*")', lambda m: m.group(1) + "\033[32m" + m.group(2) + "\033[0m", s)
    return s


def parse_args(argv):
    p = XqArgumentParser(add_help=False, prog="xq", description="Command-line XML and HTML beautifier and content extractor")
    p.add_argument("-a", "--attr")
    p.add_argument("-c", "--color", action="store_true")
    p.add_argument("--compact", action="store_true")
    p.add_argument("-d", "--depth", type=int, default=-1)
    p.add_argument("-e", "--extract")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-m", "--html", action="store_true", dest="html_mode")
    p.add_argument("-i", "--in-place", action="store_true")
    p.add_argument("--indent", type=int, default=2)
    p.add_argument("-j", "--json", action="store_true")
    p.add_argument("--no-color", action="store_true")
    p.add_argument("-n", "--node", action="store_true")
    p.add_argument("-q", "--query")
    p.add_argument("--tab", action="store_true")
    p.add_argument("-v", "--version", action="store_true")
    p.add_argument("-x", "--xpath")
    p.add_argument("file", nargs="?")
    return p.parse_args(argv)


HELP = """Command-line XML and HTML beautifier and content extractor

Usage:
  xq [flags]

Flags:
  -a, --attr string      Extract an attribute value instead of node content for provided CSS query
  -c, --color            Force colorful output
      --compact          Compact JSON output (no indentation)
  -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)
  -e, --extract string   Extract a single node from XML
  -h, --help             Print this help message
  -m, --html             Use HTML formatter
  -i, --in-place         Format file in place
      --indent int       Use the given number of spaces for indentation (default 2)
  -j, --json             Output the result as JSON
      --no-color         Disable colorful output
  -n, --node             Return the node content instead of text
  -q, --query string     Extract the node(s) using CSS selector
      --tab              Use tabs for indentation
  -v, --version          Print version information
  -x, --xpath string     Extract the node(s) from XML
"""


def main(argv=None):
    args = parse_args(argv or sys.argv[1:])
    if args.help:
        print(HELP, end="")
        return 0
    if args.version:
        print(VERSION)
        return 0
    data = read_input(args.file)
    unit = indent_unit(args)
    try:
        if args.json:
            out = xml_json(data, args.compact, args.depth)
        elif args.query:
            soup = soup_for(data)
            vals = []
            for n in soup.select(args.query):
                if args.attr:
                    if n.has_attr(args.attr):
                        vals.append(str(n.get(args.attr)))
                elif args.node:
                    vals.append("\n".join(format_bs_node(n, unit, 0)))
                else:
                    vals.append(n.get_text(" ", strip=True))
            out = "\n".join(vals) + ("\n" if vals else "")
        elif args.xpath or args.extract:
            expr = args.xpath or args.extract
            vals, is_attr = xml_xpath(data, expr)
            if args.extract:
                vals = vals[:1]
            lines = []
            for v in vals:
                if is_attr:
                    lines.append(v)
                elif args.node:
                    lines.append(serialize_xml(v))
                else:
                    lines.append(element_text(v))
            out = "\n".join(lines) + ("\n" if lines else "")
        else:
            out = format_html(data, unit) if args.html_mode else format_xml(data, unit)
        if args.in_place and args.file:
            with open(args.file, "w", encoding="utf-8") as f:
                f.write(out)
        else:
            if args.color and not args.no_color:
                out = colorize(out)
            sys.stdout.write(out)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
