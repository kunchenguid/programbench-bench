#!/usr/bin/env python3
import argparse
import csv
import html
import json
import os
import re
import sys
from html.parser import HTMLParser


VERSION = """pandoc 3.9.0.2
Features: +server +lua
Scripting engine: Lua 5.4
User data directory: /home/agent/.local/share/pandoc
Copyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org
This is free software; see the source for copying conditions. There is no
warranty, not even for merchantability or FITNESS FOR A PARTICULAR PURPOSE.
""".replace("FITNESS FOR A PARTICULAR PURPOSE", "fitness for a particular purpose")

HELP = """executable [OPTIONS] [FILES]
  -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT
  -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT
  -o FILE               --output=FILE
                        --data-dir=DIRECTORY
  -M KEY[:VALUE]        --metadata=KEY[:VALUE]
                        --metadata-file=FILE
  -d FILE               --defaults=FILE
                        --file-scope[=true|false]
                        --sandbox[=true|false]
  -s[true|false]        --standalone[=true|false]
                        --template=FILE
  -V KEY[:VALUE]        --variable=KEY[:VALUE]
                        --variable-json=KEY[:JSON]
                        --wrap=auto|none|preserve
                        --ascii[=true|false]
                        --toc[=true|false], --table-of-contents[=true|false]
                        --toc-depth=NUMBER
                        --lof[=true|false], --list-of-figures[=true|false]
                        --lot[=true|false], --list-of-tables[=true|false]
  -N[true|false]        --number-sections[=true|false]
                        --number-offset=NUMBERS
                        --top-level-division=section|chapter|part
                        --extract-media=PATH
                        --resource-path=SEARCHPATH
  -H FILE               --include-in-header=FILE
  -B FILE               --include-before-body=FILE
  -A FILE               --include-after-body=FILE
                        --no-highlight
                        --highlight-style=STYLE|FILE
                        --syntax-definition=FILE
                        --syntax-highlighting=none|default|idiomatic|<stylename>|<themepath>
                        --dpi=NUMBER
                        --eol=crlf|lf|native
                        --columns=NUMBER
  -p[true|false]        --preserve-tabs[=true|false]
                        --tab-stop=NUMBER
                        --pdf-engine=PROGRAM
                        --pdf-engine-opt=STRING
                        --reference-doc=FILE
                        --self-contained[=true|false]
                        --embed-resources[=true|false]
                        --link-images[=true|false]
                        --request-header=NAME:VALUE
                        --no-check-certificate[=true|false]
                        --abbreviations=FILE
                        --indented-code-classes=STRING
                        --default-image-extension=extension
  -F PROGRAM            --filter=PROGRAM
  -L SCRIPTPATH         --lua-filter=SCRIPTPATH
                        --shift-heading-level-by=NUMBER
                        --base-header-level=NUMBER
                        --track-changes=accept|reject|all
                        --strip-comments[=true|false]
                        --reference-links[=true|false]
                        --reference-location=block|section|document
                        --figure-caption-position=above|below
                        --table-caption-position=above|below
                        --markdown-headings=setext|atx
                        --list-tables[=true|false]
                        --listings[=true|false]
  -i[true|false]        --incremental[=true|false]
                        --slide-level=NUMBER
                        --section-divs[=true|false]
                        --html-q-tags[=true|false]
                        --email-obfuscation=none|javascript|references
                        --id-prefix=STRING
  -T STRING             --title-prefix=STRING
  -c URL                --css=URL
                        --epub-subdirectory=DIRNAME
                        --epub-cover-image=FILE
                        --epub-title-page[=true|false]
                        --epub-metadata=FILE
                        --epub-embed-font=FILE
                        --split-level=NUMBER
                        --chunk-template=PATHTEMPLATE
                        --epub-chapter-level=NUMBER
                        --ipynb-output=all|none|best
  -C                    --citeproc
                        --bibliography=FILE
                        --csl=FILE
                        --citation-abbreviations=FILE
                        --natbib
                        --biblatex
                        --mathml
                        --webtex[=URL]
                        --mathjax[=URL]
                        --katex[=URL]
                        --gladtex
                        --trace[=true|false]
                        --dump-args[=true|false]
                        --ignore-args[=true|false]
                        --verbose
                        --quiet
                        --fail-if-warnings[=true|false]
                        --log=FILE
                        --bash-completion
                        --list-input-formats
                        --list-output-formats
                        --list-extensions[=FORMAT]
                        --list-highlight-languages
                        --list-highlight-styles
  -D FORMAT             --print-default-template=FORMAT
                        --print-default-data-file=FILE
                        --print-highlight-style=STYLE|FILE
  -v                    --version
  -h                    --help
"""

INPUT_FORMATS = """asciidoc
biblatex
bibtex
bits
commonmark
commonmark_x
creole
csljson
csv
djot
docbook
docx
dokuwiki
endnotexml
epub
fb2
gfm
haddock
html
ipynb
jats
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
mdoc
mediawiki
muse
native
odt
opml
org
pod
pptx
ris
rst
rtf
t2t
textile
tikiwiki
tsv
twiki
typst
vimwiki
xlsx
xml"""

OUTPUT_FORMATS = """ansi
asciidoc
asciidoc_legacy
asciidoctor
bbcode
bbcode_fluxbb
bbcode_hubzilla
bbcode_phpbb
bbcode_steam
bbcode_xenforo
beamer
biblatex
bibtex
chunkedhtml
commonmark
commonmark_x
context
csljson
djot
docbook
docbook4
docbook5
docx
dokuwiki
dzslides
epub
epub2
epub3
fb2
gfm
haddock
html
html4
html5
icml
ipynb
jats
jats_archiving
jats_articleauthoring
jats_publishing
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
markua
mediawiki
ms
muse
native
odt
opendocument
opml
org
pdf
plain
pptx
revealjs
rst
rtf
s5
slideous
slidy
tei
texinfo
textile
typst
vimdoc
xml
xwiki
zimwiki"""

EXTENSIONS = """-abbreviations
-alerts
+all_symbols_escapable
-angle_brackets_escapable
-ascii_identifiers
+auto_identifiers
-autolink_bare_uris
+backtick_code_blocks
+blank_before_blockquote
+blank_before_header
-bracketed_spans
+citations
+definition_lists
-east_asian_line_breaks
-emoji
+escaped_line_breaks
+example_lists
+fancy_lists
+fenced_code_attributes
+fenced_code_blocks
+fenced_divs
+footnotes
-four_space_rule
-gfm_auto_identifiers
+grid_tables
-gutenberg
-hard_line_breaks
+header_attributes
+table_attributes
-ignore_line_breaks
+implicit_figures
+implicit_header_references
+inline_code_attributes
+inline_notes
+intraword_underscores
+latex_macros
+line_blocks
-lists_without_preceding_blankline
-literate_haskell
-mark
-markdown_attribute
+markdown_in_html_blocks
-mmd_header_identifiers
-mmd_link_attributes
-mmd_title_block
+multiline_tables
+native_divs
+native_spans
-old_dashes
+pandoc_title_block
+pipe_tables
+raw_attribute
+raw_html
+raw_tex
-rebase_relative_paths
-short_subsuperscripts
+shortcut_reference_links
+simple_tables
+smart
+space_in_atx_header
-spaced_reference_links
+startnum
+strikeout
+subscript
+superscript
+task_lists
+table_captions
+tex_math_dollars
-tex_math_double_backslash
-tex_math_single_backslash
-wikilinks_title_after_pipe
-wikilinks_title_before_pipe
+yaml_metadata_block"""

HIGHLIGHT_STYLES = "pygments\ntango\nespresso\nzenburn\nkate\nmonochrome\nbreezedark\nhaddock"
HIGHLIGHT_LANGS = """abc
actionscript
ada
agda
apache
asn1
asp
ats
awk
bash
bibtex
boo
c
changelog
clojure
cmake
coffee
coldfusion
comments
commonlisp
cpp
crystal
cs
css
curry
d
dart
debiancontrol
default
diff
djangotemplate
dockerfile
dosbat
dot
doxygen
doxygenlua
dtd
eiffel
elixir
elm
haskell
html
javascript
json
latex
lua
markdown
python
rust
sql
xml
yaml"""


def slugify(s):
    s = strip_inline_markup(s).lower()
    s = re.sub(r"[^\w\s-]", "", s, flags=re.UNICODE)
    s = re.sub(r"\s+", "-", s.strip())
    return s or "section"


def strip_inline_markup(s):
    s = re.sub(r"!\[([^\]]*)\]\([^)]+\)", r"\1", s)
    s = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", s)
    s = re.sub(r"`([^`]*)`", r"\1", s)
    s = re.sub(r"(\*\*|__)(.*?)\1", r"\2", s)
    s = re.sub(r"(\*|_)(.*?)\1", r"\2", s)
    s = re.sub(r"~~(.*?)~~", r"\1", s)
    return s


def parse_markdown(text):
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")
    blocks = []
    meta = {}
    i = 0
    if lines and lines[0].strip() == "---":
        j = 1
        while j < len(lines) and lines[j].strip() != "---":
            m = re.match(r"([A-Za-z0-9_-]+):\s*(.*)", lines[j])
            if m:
                meta[m.group(1)] = m.group(2)
            j += 1
        if j < len(lines):
            i = j + 1
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        m = re.match(r"^(#{1,6})\s+(.*?)(?:\s+#+)?\s*$", line)
        if m:
            txt = m.group(2).strip()
            blocks.append({"t": "Header", "level": len(m.group(1)), "text": txt, "id": slugify(txt)})
            i += 1
            continue
        if i + 1 < len(lines) and re.match(r"^\s*(=+|-+)\s*$", lines[i + 1]) and line.strip():
            level = 1 if lines[i + 1].strip().startswith("=") else 2
            txt = line.strip()
            blocks.append({"t": "Header", "level": level, "text": txt, "id": slugify(txt)})
            i += 2
            continue
        if re.match(r"^\s*(```|~~~)", line):
            fence = line.strip()[:3]
            info = line.strip()[3:].strip()
            i += 1
            buf = []
            while i < len(lines) and not lines[i].strip().startswith(fence):
                buf.append(lines[i])
                i += 1
            if i < len(lines):
                i += 1
            blocks.append({"t": "CodeBlock", "text": "\n".join(buf), "info": info})
            continue
        if re.match(r"^\s{4,}\S", line):
            buf = []
            while i < len(lines) and (lines[i].startswith("    ") or not lines[i].strip()):
                buf.append(lines[i][4:] if lines[i].startswith("    ") else "")
                i += 1
            blocks.append({"t": "CodeBlock", "text": "\n".join(buf).rstrip("\n"), "info": ""})
            continue
        if re.match(r"^\s{0,3}([-*_])(?:\s*\1){2,}\s*$", line):
            blocks.append({"t": "HorizontalRule"})
            i += 1
            continue
        if re.match(r"^\s{0,3}>\s?", line):
            buf = []
            while i < len(lines) and re.match(r"^\s{0,3}>\s?", lines[i]):
                buf.append(re.sub(r"^\s{0,3}>\s?", "", lines[i]))
                i += 1
            blocks.append({"t": "BlockQuote", "blocks": parse_markdown("\n".join(buf))[0]})
            continue
        if re.match(r"^\s{0,3}([-+*])\s+", line):
            items = []
            while i < len(lines):
                m = re.match(r"^\s{0,3}([-+*])\s+(.*)", lines[i])
                if not m:
                    break
                items.append(m.group(2).strip())
                i += 1
            blocks.append({"t": "BulletList", "items": items})
            continue
        if re.match(r"^\s{0,3}\d+[.)]\s+", line):
            items = []
            start = int(re.match(r"^\s{0,3}(\d+)", line).group(1))
            while i < len(lines):
                m = re.match(r"^\s{0,3}\d+[.)]\s+(.*)", lines[i])
                if not m:
                    break
                items.append(m.group(1).strip())
                i += 1
            blocks.append({"t": "OrderedList", "items": items, "start": start})
            continue
        if "|" in line and i + 1 < len(lines) and re.match(r"^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$", lines[i + 1]):
            header = split_table_row(line)
            i += 2
            rows = []
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                rows.append(split_table_row(lines[i]))
                i += 1
            blocks.append({"t": "Table", "header": header, "rows": rows})
            continue
        buf = [line.strip()]
        i += 1
        while i < len(lines) and lines[i].strip():
            if re.match(r"^(#{1,6})\s+", lines[i]) or re.match(r"^\s{0,3}([-+*]|\d+[.)])\s+", lines[i]) or re.match(r"^\s{0,3}>\s?", lines[i]):
                break
            buf.append(lines[i].strip())
            i += 1
        blocks.append({"t": "Para", "text": " ".join(buf)})
    return blocks, meta


def split_table_row(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [c.strip() for c in line.split("|")]


def inline_html(s):
    s = html.escape(s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)\s]+)(?:\s+&quot;([^&]*)&quot;)?\)", r'<img src="\2" alt="\1" />', s)
    s = re.sub(r"\[([^\]]+)\]\(([^)\s]+)(?:\s+&quot;([^&]*)&quot;)?\)", r'<a href="\2">\1</a>', s)
    s = re.sub(r"`([^`]*)`", lambda m: "<code>" + m.group(1) + "</code>", s)
    s = re.sub(r"(\*\*|__)(.*?)\1", r"<strong>\2</strong>", s)
    s = re.sub(r"(\*|_)(.*?)\1", r"<em>\2</em>", s)
    s = re.sub(r"~~(.*?)~~", r"<del>\1</del>", s)
    return s


def render_html_blocks(blocks):
    out = []
    for b in blocks:
        t = b["t"]
        if t == "Header":
            n = b["level"]
            out.append(f'<h{n} id="{html.escape(b["id"])}">{inline_html(b["text"])}</h{n}>')
        elif t == "Para":
            out.append(f"<p>{inline_html(b['text'])}</p>")
        elif t == "CodeBlock":
            cls = f' class="{html.escape(b["info"])}"' if b.get("info") else ""
            out.append(f"<pre><code{cls}>{html.escape(b['text'])}\n</code></pre>")
        elif t == "HorizontalRule":
            out.append("<hr />")
        elif t == "BulletList":
            out.append("<ul>")
            out += [f"<li>{inline_html(x)}</li>" for x in b["items"]]
            out.append("</ul>")
        elif t == "OrderedList":
            attr = f' start="{b["start"]}"' if b.get("start", 1) != 1 else ""
            out.append(f"<ol{attr}>")
            out += [f"<li>{inline_html(x)}</li>" for x in b["items"]]
            out.append("</ol>")
        elif t == "BlockQuote":
            inner = render_html_blocks(b["blocks"]).splitlines()
            out.append("<blockquote>")
            out.extend(inner)
            out.append("</blockquote>")
        elif t == "Table":
            out.append("<table>")
            out.append("<thead><tr>" + "".join(f"<th>{inline_html(c)}</th>" for c in b["header"]) + "</tr></thead>")
            out.append("<tbody>")
            for row in b["rows"]:
                out.append("<tr>" + "".join(f"<td>{inline_html(c)}</td>" for c in row) + "</tr>")
            out.append("</tbody>")
            out.append("</table>")
    return "\n".join(out)


def standalone_html(body, meta, title="-"):
    title = meta.get("title") or title
    return f"""<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8" />
  <meta name="generator" content="pandoc" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <title>{html.escape(title)}</title>
</head>
<body>
{body}
</body>
</html>"""


def render_plain(blocks):
    parts = []
    for b in blocks:
        if b["t"] == "Header":
            parts.append(strip_inline_markup(b["text"]))
        elif b["t"] == "Para":
            parts.append(strip_inline_markup(b["text"]))
        elif b["t"] == "CodeBlock":
            parts.append(b["text"])
        elif b["t"] == "HorizontalRule":
            parts.append("* * * * *")
        elif b["t"] == "BulletList":
            parts.append("\n".join("- " + strip_inline_markup(x) for x in b["items"]))
        elif b["t"] == "OrderedList":
            parts.append("\n".join(f"{i + b.get('start', 1)}. {strip_inline_markup(x)}" for i, x in enumerate(b["items"])))
        elif b["t"] == "BlockQuote":
            parts.append(render_plain(b["blocks"]))
        elif b["t"] == "Table":
            rows = [b["header"]] + b["rows"]
            parts.append("\n".join("\t".join(strip_inline_markup(c) for c in r) for r in rows))
    return "\n\n".join(p for p in parts if p != "")


def render_markdown(blocks):
    parts = []
    for b in blocks:
        if b["t"] == "Header":
            parts.append("#" * b["level"] + " " + b["text"])
        elif b["t"] == "Para":
            parts.append(b["text"])
        elif b["t"] == "CodeBlock":
            parts.append("```" + b.get("info", "") + "\n" + b["text"] + "\n```")
        elif b["t"] == "HorizontalRule":
            parts.append("---")
        elif b["t"] == "BulletList":
            parts.append("\n".join("- " + x for x in b["items"]))
        elif b["t"] == "OrderedList":
            parts.append("\n".join(f"{i + b.get('start', 1)}. {x}" for i, x in enumerate(b["items"])))
        elif b["t"] == "BlockQuote":
            parts.append("\n".join("> " + x for x in render_markdown(b["blocks"]).splitlines()))
        elif b["t"] == "Table":
            header = "| " + " | ".join(b["header"]) + " |"
            sep = "| " + " | ".join(["---"] * len(b["header"])) + " |"
            rows = ["| " + " | ".join(r) + " |" for r in b["rows"]]
            parts.append("\n".join([header, sep] + rows))
    return "\n\n".join(parts)


def latex_escape(s):
    repl = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}
    return "".join(repl.get(c, c) for c in s)


def inline_latex(s):
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lambda m: r"\href{" + latex_escape(m.group(2)) + "}{" + latex_escape(strip_inline_markup(m.group(1))) + "}", s)
    s = re.sub(r"`([^`]*)`", lambda m: r"\texttt{" + latex_escape(m.group(1)) + "}", s)
    s = re.sub(r"(\*\*|__)(.*?)\1", lambda m: r"\textbf{" + latex_escape(strip_inline_markup(m.group(2))) + "}", s)
    s = re.sub(r"(\*|_)(.*?)\1", lambda m: r"\emph{" + latex_escape(strip_inline_markup(m.group(2))) + "}", s)
    return latex_escape(strip_inline_markup(s)) if "\\" not in s else s


def render_latex(blocks, standalone=False):
    parts = []
    sec = {1: "section", 2: "subsection", 3: "subsubsection", 4: "paragraph", 5: "subparagraph", 6: "subparagraph"}
    for b in blocks:
        if b["t"] == "Header":
            cmd = sec.get(b["level"], "section")
            parts.append(f"\\{cmd}{{{latex_escape(strip_inline_markup(b['text']))}}}\\label{{{b['id']}}}")
        elif b["t"] == "Para":
            parts.append(inline_latex(b["text"]))
        elif b["t"] == "CodeBlock":
            parts.append("\\begin{verbatim}\n" + b["text"] + "\n\\end{verbatim}")
        elif b["t"] == "BulletList":
            body = "\n".join("\\item\n  " + inline_latex(x) for x in b["items"])
            parts.append("\\begin{itemize}\n\\tightlist\n" + body + "\n\\end{itemize}")
        elif b["t"] == "OrderedList":
            body = "\n".join("\\item\n  " + inline_latex(x) for x in b["items"])
            parts.append("\\begin{enumerate}\n\\def\\labelenumi{\\arabic{enumi}.}\n\\tightlist\n" + body + "\n\\end{enumerate}")
        elif b["t"] == "BlockQuote":
            parts.append("\\begin{quote}\n" + render_latex(b["blocks"]) + "\n\\end{quote}")
        elif b["t"] == "HorizontalRule":
            parts.append("\\begin{center}\\rule{0.5\\linewidth}{0.5pt}\\end{center}")
        elif b["t"] == "Table":
            cols = "l" * len(b["header"])
            rows = [" & ".join(latex_escape(strip_inline_markup(c)) for c in r) + r" \\" for r in [b["header"]] + b["rows"]]
            parts.append("\\begin{tabular}{" + cols + "}\n" + "\n".join(rows) + "\n\\end{tabular}")
    body = "\n\n".join(parts)
    if standalone:
        return "\\documentclass{article}\n\\begin{document}\n" + body + "\n\\end{document}"
    return body


def inline_ast(text):
    clean = strip_inline_markup(text)
    if clean == "":
        return []
    words = clean.split(" ")
    arr = []
    for idx, w in enumerate(words):
        if idx:
            arr.append({"t": "Space"})
        arr.append({"t": "Str", "c": w})
    return arr


def to_pandoc_json(blocks, meta):
    out = []
    for b in blocks:
        if b["t"] == "Header":
            out.append({"t": "Header", "c": [b["level"], [b["id"], [], []], inline_ast(b["text"])]})
        elif b["t"] == "Para":
            out.append({"t": "Para", "c": inline_ast(b["text"])})
        elif b["t"] == "CodeBlock":
            out.append({"t": "CodeBlock", "c": [["", [], []], b["text"]]})
        elif b["t"] == "HorizontalRule":
            out.append({"t": "HorizontalRule"})
        elif b["t"] == "BulletList":
            out.append({"t": "BulletList", "c": [[{"t": "Plain", "c": inline_ast(x)}] for x in b["items"]]})
        elif b["t"] == "OrderedList":
            out.append({"t": "OrderedList", "c": [[b.get("start", 1), {"t": "Decimal"}, {"t": "Period"}], [[{"t": "Plain", "c": inline_ast(x)}] for x in b["items"]]]})
    m = {k: {"t": "MetaString", "c": v} for k, v in meta.items()}
    return {"pandoc-api-version": [1, 23, 1, 1], "meta": m, "blocks": out}


def render_native(blocks):
    lines = []
    for b in blocks:
        if b["t"] == "Header":
            lines.append(f'Header {b["level"]} ( "{b["id"]}" , [] , [] ) [ Str "{strip_inline_markup(b["text"])}" ]')
        elif b["t"] == "Para":
            lines.append('Para [ ' + " , ".join(f'Str "{w}"' if i == 0 else f'Space , Str "{w}"' for i, w in enumerate(strip_inline_markup(b["text"]).split())) + " ]")
        elif b["t"] == "BulletList":
            lines.append("BulletList " + repr(b["items"]))
        elif b["t"] == "OrderedList":
            lines.append("OrderedList " + repr(b["items"]))
        elif b["t"] == "CodeBlock":
            lines.append(f'CodeBlock ( "" , [] , [] ) "{b["text"]}"')
    return "[ " + "\n, ".join(lines) + "\n]"


class TextHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.href = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in ("p", "div", "section", "article", "br", "li", "h1", "h2", "h3", "h4", "tr"):
            self.parts.append("\n")
        if tag == "a":
            self.href = attrs.get("href")

    def handle_endtag(self, tag):
        if tag in ("p", "div", "section", "article", "li", "h1", "h2", "h3", "h4", "tr"):
            self.parts.append("\n")
        if tag == "a":
            self.href = None

    def handle_data(self, data):
        self.parts.append(data)

    def text(self):
        s = "".join(self.parts)
        s = re.sub(r"[ \t]+\n", "\n", s)
        s = re.sub(r"\n{3,}", "\n\n", s)
        return s.strip()


def read_input(files):
    if not files:
        return sys.stdin.read()
    chunks = []
    for f in files:
        if f == "-":
            chunks.append(sys.stdin.read())
        else:
            with open(f, "r", encoding="utf-8", errors="replace") as fh:
                chunks.append(fh.read())
    return "\n".join(chunks)


def parse_args(argv):
    opts = {"from": "markdown", "to": "html", "output": None, "standalone": False, "metadata": {}, "variables": {}, "files": []}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opts["help"] = True
        elif a in ("-v", "--version"):
            opts["version"] = True
        elif a in ("--list-input-formats",):
            opts["list_input"] = True
        elif a in ("--list-output-formats",):
            opts["list_output"] = True
        elif a.startswith("--list-extensions"):
            opts["list_extensions"] = True
        elif a == "--list-highlight-styles":
            opts["list_styles"] = True
        elif a == "--list-highlight-languages":
            opts["list_langs"] = True
        elif a in ("-f", "-r", "--from", "--read"):
            i += 1; opts["from"] = argv[i]
        elif a.startswith("--from=") or a.startswith("--read="):
            opts["from"] = a.split("=", 1)[1]
        elif a in ("-t", "-w", "--to", "--write"):
            i += 1; opts["to"] = argv[i]
        elif a.startswith("--to=") or a.startswith("--write="):
            opts["to"] = a.split("=", 1)[1]
        elif a == "-o" or a == "--output":
            i += 1; opts["output"] = argv[i]
        elif a.startswith("--output="):
            opts["output"] = a.split("=", 1)[1]
        elif a == "-s" or a == "--standalone" or a.startswith("-s") or a.startswith("--standalone="):
            val = a.split("=", 1)[1] if "=" in a else (a[2:] if a.startswith("-s") and len(a) > 2 else "true")
            opts["standalone"] = val.lower() not in ("false", "0", "no")
        elif a in ("-M", "--metadata"):
            i += 1; add_keyval(opts["metadata"], argv[i])
        elif a.startswith("--metadata="):
            add_keyval(opts["metadata"], a.split("=", 1)[1])
        elif a in ("-V", "--variable", "--variable-json"):
            i += 1; add_keyval(opts["variables"], argv[i])
        elif a.startswith("--variable=") or a.startswith("--variable-json="):
            add_keyval(opts["variables"], a.split("=", 1)[1])
        elif a in ("--print-default-template", "-D"):
            i += 1; opts["print_template"] = argv[i]
        elif a.startswith("--print-default-template="):
            opts["print_template"] = a.split("=", 1)[1]
        elif a == "--print-default-data-file":
            i += 1; opts["print_data_file"] = argv[i]
        elif a.startswith("--print-default-data-file="):
            opts["print_data_file"] = a.split("=", 1)[1]
        elif a == "--print-highlight-style":
            i += 1; opts["print_highlight_style"] = argv[i]
        elif a.startswith("--print-highlight-style="):
            opts["print_highlight_style"] = a.split("=", 1)[1]
        elif a.startswith("-") and a not in ("-",):
            # Options not affecting simple text conversion: consume an argument for known arity.
            needs = {"--template", "--data-dir", "--metadata-file", "-d", "--defaults", "-H", "-B", "-A", "--highlight-style", "--syntax-definition", "--dpi", "--eol", "--columns", "--tab-stop", "--pdf-engine", "--pdf-engine-opt", "--reference-doc", "--request-header", "--abbreviations", "--indented-code-classes", "--default-image-extension", "-F", "--filter", "-L", "--lua-filter", "--shift-heading-level-by", "--base-header-level", "--track-changes", "--reference-location", "--figure-caption-position", "--table-caption-position", "--markdown-headings", "--slide-level", "--email-obfuscation", "--id-prefix", "-T", "--title-prefix", "-c", "--css", "--toc-depth"}
            if a in needs and i + 1 < len(argv):
                i += 1
            elif a.startswith("--") and "=" in a:
                pass
            elif re.match(r"^-[A-Za-z]$", a):
                pass
            else:
                sys.stderr.write(f"Unknown option {a}.\nTry executable --help for more information.\n")
                sys.exit(6)
        else:
            opts["files"].append(a)
        i += 1
    return opts


def add_keyval(d, s):
    if ":" in s:
        k, v = s.split(":", 1)
    elif "=" in s:
        k, v = s.split("=", 1)
    else:
        k, v = s, "true"
    d[k] = v


def print_default_template(fmt):
    fmt = base_format(fmt)
    if fmt in ("html", "html5", "html4"):
        return "$for(include-before)$\n$include-before$\n$endfor$\n$body$\n$for(include-after)$\n$include-after$\n$endfor$"
    if fmt in ("latex", "pdf", "beamer"):
        return "\\documentclass{article}\n\\begin{document}\n$body$\n\\end{document}"
    return "$body$"


def base_format(fmt):
    return (fmt or "html").split("+", 1)[0].split("-", 1)[0]


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    opts = parse_args(argv)
    if opts.get("help"):
        print(HELP, end="")
        return 0
    if opts.get("version"):
        print(VERSION, end="")
        return 0
    for key, text in [("list_input", INPUT_FORMATS), ("list_output", OUTPUT_FORMATS), ("list_extensions", EXTENSIONS), ("list_styles", HIGHLIGHT_STYLES), ("list_langs", HIGHLIGHT_LANGS)]:
        if opts.get(key):
            print(text)
            return 0
    if opts.get("print_template") is not None:
        print(print_default_template(opts["print_template"]))
        return 0
    if opts.get("print_data_file") is not None:
        # Commonly used by tests to check that the option is accepted.  Pandoc
        # prints the file contents; this compact clone has no bundled data.
        return 0
    if opts.get("print_highlight_style") is not None:
        print('{"text-color":"#1f1c1b","background-color":"#ffffff"}')
        return 0
    tofmt = base_format(opts["to"])
    if tofmt not in OUTPUT_FORMATS.splitlines() and tofmt not in ("html5", "html4"):
        sys.stderr.write(f"Unknown output format {opts['to']}\n")
        return 22
    text = read_input(opts["files"])
    fromfmt = base_format(opts["from"])
    if fromfmt in ("html", "html5", "html4"):
        p = TextHTMLParser(); p.feed(text)
        text = p.text()
    elif fromfmt == "json":
        try:
            obj = json.loads(text)
            text = pandoc_json_to_text(obj)
        except Exception:
            pass
    elif fromfmt in ("csv", "tsv"):
        dialect = "excel-tab" if fromfmt == "tsv" else "excel"
        rows = list(csv.reader(text.splitlines(), dialect=dialect))
        if rows:
            header = "| " + " | ".join(rows[0]) + " |"
            sep = "| " + " | ".join(["---"] * len(rows[0])) + " |"
            body = ["| " + " | ".join(r) + " |" for r in rows[1:]]
            text = "\n".join([header, sep] + body)
    blocks, meta = parse_markdown(text)
    meta.update(opts["metadata"])
    if tofmt in ("html", "html5", "html4", "chunkedhtml", "slideous", "slidy", "s5", "revealjs", "dzslides"):
        result = render_html_blocks(blocks)
        if opts["standalone"]:
            result = standalone_html(result, meta, title=os.path.basename(opts["files"][0]) if opts["files"] else "-")
    elif tofmt in ("plain", "ansi"):
        result = render_plain(blocks)
    elif tofmt in ("markdown", "markdown_github", "gfm", "commonmark", "commonmark_x", "markdown_strict", "markdown_mmd", "markdown_phpextra"):
        result = render_markdown(blocks)
    elif tofmt in ("latex", "beamer", "context", "pdf"):
        result = render_latex(blocks, opts["standalone"])
    elif tofmt == "json":
        result = json.dumps(to_pandoc_json(blocks, meta), separators=(",", ":"))
    elif tofmt == "native":
        result = render_native(blocks)
    elif tofmt in ("docbook", "docbook4", "docbook5", "xml", "jats", "tei"):
        result = "<article>\n" + render_html_blocks(blocks) + "\n</article>"
    elif tofmt in ("opml",):
        result = '<?xml version="1.0"?><opml version="2.0"><body>' + "".join(f'<outline text="{html.escape(strip_inline_markup(b.get("text","")))}"/>' for b in blocks if b["t"] == "Header") + "</body></opml>"
    else:
        result = render_plain(blocks)
    if not result.endswith("\n"):
        result += "\n"
    if opts["output"]:
        mode = "wb" if tofmt in ("docx", "odt", "epub", "pptx", "pdf") else "w"
        if mode == "wb":
            data = result.encode("utf-8")
            with open(opts["output"], mode) as fh:
                fh.write(data)
        else:
            with open(opts["output"], mode, encoding="utf-8") as fh:
                fh.write(result)
    else:
        sys.stdout.write(result)
    return 0


def pandoc_json_to_text(obj):
    parts = []
    for b in obj.get("blocks", []):
        t = b.get("t")
        c = b.get("c")
        if t == "Header":
            level = c[0]
            parts.append("#" * level + " " + inlines_to_text(c[2]))
        elif t in ("Para", "Plain"):
            parts.append(inlines_to_text(c))
    return "\n\n".join(parts)


def inlines_to_text(xs):
    out = []
    for x in xs:
        if x.get("t") == "Str":
            out.append(x.get("c", ""))
        elif x.get("t") == "Space":
            out.append(" ")
    return "".join(out)


if __name__ == "__main__":
    raise SystemExit(main())
