#!/usr/bin/env python3
import argparse
import csv
import html
import json
import os
import re
import shlex
import sqlite3
import sys
import datetime
from pathlib import Path


VERSION = "v0.0.1 (Unknown Version) 780a7396"


HELP = """\033[1mUsage: \033[00m\033[32m./executable\033[00m\033[33m [OPTIONS] FILENAME [SQL]

\033[00m\033[1mFILENAME\033[00m is the name of a DuckDB database. A new database is created
if the file does not previously exist.

\033[1mOPTIONS:
\033[00m\033[32m  -ascii\033[00m                   set output mode to 'ascii'
\033[32m  -bail\033[00m                    stop after hitting an error
\033[32m  -batch\033[00m                   force batch I/O'
\033[32m  -box\033[00m                     set output mode to 'box'
\033[32m  -column\033[00m                  set output mode to 'column'
\033[32m  -cmd\033[00m\033[33m COMMAND\033[00m             run "COMMAND" before reading stdin
\033[32m  -csv\033[00m                     set output mode to 'csv'
\033[32m  -c\033[00m\033[33m COMMAND\033[00m               run "COMMAND" and exit
\033[32m  -echo\033[00m                    print commands before execution
\033[32m  -f\033[00m\033[33m FILENAME\033[00m              read/process named file and exit
\033[32m  -format\033[00m                  format SQL from stdin, writing result to stdout
\033[32m  -format-file\033[00m\033[33m FILENAME\033[00m    format SQL in file, writing result to stdout
\033[32m  -init\033[00m\033[33m FILENAME\033[00m           read/process named file
\033[32m  -header\033[00m                  turn headers on
\033[32m  -h\033[00m                       show help message
\033[32m  -help\033[00m                    show help message
\033[32m  -html\033[00m                    set output mode to HTML
\033[32m  -interactive\033[00m             force interactive I/O
\033[32m  -json\033[00m                    set output mode to 'json'
\033[32m  -jsonlines\033[00m               set output mode to 'jsonlines'
\033[32m  -line\033[00m                    set output mode to 'line'
\033[32m  -list\033[00m                    set output mode to 'list'
\033[32m  -markdown\033[00m                set output mode to 'markdown'
\033[32m  -newline\033[00m\033[33m SEP\033[00m             set output row separator. Default: '\\n'
\033[32m  -no-init\033[00m                 skip processing the init file
\033[32m  -no-stdin\033[00m                exit after processing options instead of reading stdin
\033[32m  -noheader\033[00m                turn headers off
\033[32m  -nullvalue\033[00m\033[33m TEXT\033[00m          set text string for NULL values. Default 'NULL'
\033[32m  -quote\033[00m                   set output mode to 'quote'
\033[32m  -readonly\033[00m                open the database read-only
\033[32m  -s\033[00m\033[33m COMMAND\033[00m               run "COMMAND" and exit
\033[32m  -safe\033[00m                    enable safe-mode
\033[32m  -separator\033[00m\033[33m SEP\033[00m           set output column separator. Default: '|'
\033[32m  -storage-version\033[00m\033[33m VER\033[00m     database storage compatibility version to use. Default: 'v0.10.0'
\033[32m  -table\033[00m                   set output mode to 'table'
\033[32m  -ui\033[00m                      launches a web interface using the ui extension (configurable with .ui_command)
\033[32m  -unredacted\033[00m              allow printing unredacted secrets
\033[32m  -unsigned\033[00m                allow loading of unsigned extensions
\033[32m  -version\033[00m                 show DuckDB version
"""


DOT_HELP = """.about                                  Show information about DuckDB
.bail on|off                             Stop after hitting an error.  Default OFF
.cd DIRECTORY                            Change the working directory to DIRECTORY
.echo on|off                             Turn command echo on or off
.exit ?CODE?                             Exit this program with return-code CODE
.headers on|off                          Turn display of headers on or off
.help ?-all? ?PATTERN?                   Show help text for PATTERN
.import FILE TABLE                       Import data from FILE into TABLE
.mode MODE ?TABLE?                       Set output mode
.nullvalue STRING                        Use STRING in place of NULL values
.open ?OPTIONS? ?FILE?                   Close existing database and reopen FILE
.print STRING...                         Print literal STRING
.quit                                    Exit this program
.read FILE                               Read input from FILE
.schema ?PATTERN?                        Show the CREATE statements matching PATTERN
.separator COL ?ROW?                     Change the column and row separators
.show                                    Show the current values for various settings
.tables ?TABLE?                          List names of tables matching LIKE pattern TABLE
.version                                 Show the version
"""


class State:
    def __init__(self):
        self.mode = "duckbox"
        self.headers = True
        self.null = "NULL"
        self.separator = "|"
        self.newline = "\n"
        self.echo = False
        self.bail = False
        self.conn = None
        self.dbfile = ":memory:"
        self.once = None
        self.imported = {}


def parse_args(argv):
    state = State()
    dbfile = None
    sqls = []
    pre = []
    file_to_read = None
    no_stdin = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "-help", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a == "-version":
            print(VERSION)
            raise SystemExit(0)
        if a in ("-csv", "-list", "-line", "-column", "-table", "-box", "-ascii", "-markdown", "-json", "-jsonlines", "-html", "-quote"):
            state.mode = a[1:]
        elif a in ("-header", "-headers"):
            state.headers = True
        elif a in ("-noheader", "-no-header"):
            state.headers = False
        elif a == "-nullvalue":
            i += 1; state.null = argv[i]
        elif a == "-separator":
            i += 1; state.separator = decode_sep(argv[i])
        elif a == "-newline":
            i += 1; state.newline = decode_sep(argv[i])
        elif a in ("-cmd",):
            i += 1; pre.append(argv[i])
        elif a in ("-c", "-s"):
            i += 1; sqls.append(argv[i]); no_stdin = True
        elif a in ("-f", "-init"):
            i += 1; file_to_read = argv[i]; no_stdin = True
        elif a == "-echo":
            state.echo = True
        elif a == "-bail":
            state.bail = True
        elif a == "-no-stdin":
            no_stdin = True
        elif a in ("-batch", "-interactive", "-safe", "-readonly", "-unsigned", "-unredacted", "-storage-version", "-ui", "-no-init"):
            if a == "-storage-version":
                i += 1
        elif a in ("-format", "-format-file"):
            text = sys.stdin.read() if a == "-format" else Path(argv[i + 1]).read_text()
            if a == "-format-file":
                i += 1
            print(format_sql(text), end="" if text.endswith("\n") else "\n")
            raise SystemExit(0)
        elif a.startswith("-"):
            print(f"Error: unknown option: {a}", file=sys.stderr)
            raise SystemExit(1)
        elif dbfile is None:
            dbfile = a
        else:
            sqls.append(a); no_stdin = True
        i += 1
    state.dbfile = dbfile or ":memory:"
    return state, pre, sqls, file_to_read, no_stdin


def decode_sep(s):
    return s.encode("utf-8").decode("unicode_escape")


def connect(state):
    if state.conn:
        state.conn.close()
    path = ":memory:" if state.dbfile in (":memory:", "") else state.dbfile
    state.conn = sqlite3.connect(path)
    state.conn.row_factory = sqlite3.Row
    state.conn.create_function("regexp_matches", 2, lambda x, y: 1 if re.search(y, str(x or "")) else 0)
    state.conn.create_function("regexp_full_match", 2, lambda x, y: 1 if re.fullmatch(y, str(x or "")) else 0)
    state.conn.create_function("version", 0, lambda: VERSION.split()[0])
    state.conn.create_function("current_date", 0, lambda: datetime.date.today().isoformat())


def split_sql(text):
    out, cur, quote, line_comment = [], [], None, False
    i = 0
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if line_comment:
            cur.append(ch)
            if ch == "\n":
                line_comment = False
        elif quote:
            cur.append(ch)
            if ch == quote:
                if nxt == quote:
                    cur.append(nxt); i += 1
                else:
                    quote = None
        elif ch in ("'", '"', "`"):
            quote = ch; cur.append(ch)
        elif ch == "-" and nxt == "-":
            line_comment = True; cur.append(ch); cur.append(nxt); i += 1
        elif ch == ";":
            s = "".join(cur).strip()
            if s:
                out.append(s)
            cur = []
        else:
            cur.append(ch)
        i += 1
    s = "".join(cur).strip()
    if s:
        out.append(s)
    return out


def duck_to_sqlite(sql, state):
    sql = re.sub(r"::\s*[A-Za-z_][A-Za-z0-9_]*(?:\([^)]*\))?", "", sql)
    sql = re.sub(r"\btrue\b", "1", sql, flags=re.I)
    sql = re.sub(r"\bfalse\b", "0", sql, flags=re.I)
    sql = re.sub(r"\bdate\s*'([^']*)'", r"'\1'", sql, flags=re.I)
    sql = re.sub(r"\btimestamp\s*'([^']*)'", r"'\1'", sql, flags=re.I)
    sql = re.sub(r"\bDOUBLE\b", "REAL", sql, flags=re.I)
    sql = re.sub(r"\bVARCHAR\b", "TEXT", sql, flags=re.I)
    sql = import_file_refs(sql, state)
    sql = translate_series(sql, state)
    return sql


def safe_name(prefix, text):
    return prefix + "_" + re.sub(r"\W+", "_", text)[-40:]


def import_file_refs(sql, state):
    for m in list(re.finditer(r"(?i)(from|join)\s+'([^']+\.(?:csv|tsv|parquet))'", sql)):
        path = m.group(2)
        table = load_data_file(path, state)
        sql = sql.replace("'" + path + "'", table)
    for m in list(re.finditer(r"(?i)read_csv_auto\s*\(\s*'([^']+)'\s*\)", sql)):
        path = m.group(1)
        table = load_data_file(path, state)
        sql = sql.replace(m.group(0), table)
    return sql


def load_data_file(path, state):
    if path in state.imported:
        return state.imported[path]
    p = Path(path)
    table = safe_name("_file", str(p))
    cur = state.conn.cursor()
    cur.execute(f'DROP TABLE IF EXISTS "{table}"')
    rows = []
    if p.suffix.lower() == ".parquet":
        try:
            import pyarrow.parquet as pq
            tbl = pq.read_table(str(p))
            cols = tbl.column_names
            data = tbl.to_pylist()
            rows = [[r.get(c) for c in cols] for r in data]
        except Exception as e:
            raise RuntimeError(f"Could not read parquet file {path}: {e}")
    else:
        with open(p, newline="") as f:
            sample = f.read(4096); f.seek(0)
            dialect = csv.Sniffer().sniff(sample, delimiters=",|\t;") if sample else csv.excel
            reader = csv.reader(f, dialect)
            all_rows = list(reader)
        if not all_rows:
            cols = ["column0"]
        else:
            cols = [c if c else f"column{i}" for i, c in enumerate(all_rows[0])]
            rows = all_rows[1:]
    qcols = [f'"{c}" TEXT' for c in cols]
    cur.execute(f'CREATE TEMP TABLE "{table}" ({",".join(qcols)})')
    if rows:
        cur.executemany(f'INSERT INTO "{table}" VALUES ({",".join(["?"]*len(cols))})', rows)
    state.imported[path] = f'"{table}"'
    return f'"{table}"'


def translate_series(sql, state):
    pat = re.compile(r"(?i)from\s+(generate_series|range)\s*\(\s*(-?\d+)\s*(?:,\s*(-?\d+))?(?:,\s*(-?\d+))?\s*\)")
    m = pat.search(sql)
    if not m:
        return sql
    fn = m.group(1).lower()
    start = int(m.group(2)); stop = int(m.group(3) or m.group(2)); step = int(m.group(4) or 1)
    if m.group(3) is None:
        start, stop = 0, start
    end = stop + (1 if step > 0 else -1) if fn == "generate_series" else stop
    vals = list(range(start, end, step))[:100000]
    table = "_" + fn
    col = fn
    cur = state.conn.cursor()
    cur.execute(f"DROP TABLE IF EXISTS {table}")
    cur.execute(f"CREATE TEMP TABLE {table}({col} INTEGER)")
    cur.executemany(f"INSERT INTO {table} VALUES (?)", [(v,) for v in vals])
    return pat.sub(f"from {table}", sql)


def script_units(text):
    buf = []
    for line in text.splitlines(True):
        if line.lstrip().startswith("."):
            for s in split_sql("".join(buf)):
                yield s
            buf = []
            yield line.strip()
        else:
            buf.append(line)
            joined = "".join(buf)
            parts = split_sql(joined)
            if joined.rstrip().endswith(";"):
                for s in parts:
                    yield s
                buf = []
    for s in split_sql("".join(buf)):
        yield s


def execute_text(text, state):
    code = 0
    for raw in script_units(text):
        if state.echo:
            print(raw + ";")
        try:
            if raw.lstrip().startswith("."):
                r = dot_command(raw, state)
                if isinstance(r, int):
                    return r
                continue
            execute_sql(raw, state)
        except SystemExit as e:
            return int(e.code or 0)
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            code = 1
            if state.bail:
                return code
    return code


def execute_sql(sql, state):
    low = sql.strip().lower()
    m = re.match(r"(?is)\s*create\s+or\s+replace\s+table\s+([A-Za-z_][A-Za-z0-9_]*)\s+(.*)$", sql)
    if m:
        state.conn.execute(f'DROP TABLE IF EXISTS {q(m.group(1))}')
        sql = f"CREATE TABLE {q(m.group(1))} {m.group(2)}"
    m = re.match(r"(?is)\s*copy\s+(?:\((.*)\)|([A-Za-z_][A-Za-z0-9_]*))\s+to\s+'([^']+)'.*$", sql)
    if m:
        source_sql = m.group(1) or f"SELECT * FROM {q(m.group(2))}"
        cur = state.conn.execute(duck_to_sqlite(source_sql, state))
        cols = [d[0] for d in cur.description]
        rows = [list(r) for r in cur.fetchall()]
        with open(m.group(3), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(cols)
            w.writerows(rows)
        return
    m = re.match(r"(?is)\s*copy\s+([A-Za-z_][A-Za-z0-9_]*)\s+from\s+'([^']+)'.*$", sql)
    if m:
        import_csv_to_table(m.group(2), m.group(1), state)
        return
    if low == "show tables":
        cur = state.conn.execute("select name from sqlite_master where type in ('table','view') and name not like 'sqlite_%' order by name")
        rows = [[r[0]] for r in cur.fetchall()]
        write_output(render(["name"], rows, state))
        return
    if low in ("pragma version", "pragma version()"):
        write_output(render(["library_version", "source_id", "codename"], [[VERSION.split()[0], "780a7396", ""]], state))
        return
    m = re.match(r"(?i)\s*(describe|desc)\s+([A-Za-z_][A-Za-z0-9_]*|'[^']+')\s*$", sql)
    if m:
        name = m.group(2).strip("'")
        cur = state.conn.execute(f"PRAGMA table_info({q(name)})")
        rows = [[r[1], duck_type(r[2]), "YES" if not r[3] else "NO", "PRI" if r[5] else None, r[4], None] for r in cur.fetchall()]
        write_output(render(["column_name", "column_type", "null", "key", "default", "extra"], rows, state))
        return
    cur = state.conn.cursor()
    cur.execute(duck_to_sqlite(sql, state))
    if cur.description:
        cols = [d[0] for d in cur.description]
        rows = [list(r) for r in cur.fetchall()]
        write_output(render(cols, rows, state))
    else:
        state.conn.commit()


def dot_command(line, state):
    parts = shlex.split(line)
    if not parts:
        return
    cmd = parts[0][1:]
    args = parts[1:]
    if cmd in ("quit", "exit"):
        raise SystemExit(int(args[0]) if args and args[0].isdigit() else 0)
    if cmd == "help":
        print(DOT_HELP, end="")
    elif cmd == "version":
        print(VERSION)
    elif cmd == "about":
        print("DuckDB Python-compatible shell")
    elif cmd in ("headers", "header"):
        state.headers = (not args) or args[0].lower() in ("on", "yes", "true", "1")
    elif cmd == "mode" and args:
        state.mode = {"tabs": "list", "duckbox": "duckbox"}.get(args[0].lower(), args[0].lower())
    elif cmd == "separator" and args:
        state.separator = args[0]
        if len(args) > 1:
            state.newline = args[1]
    elif cmd == "nullvalue" and args:
        state.null = " ".join(args)
    elif cmd == "echo" and args:
        state.echo = args[0].lower() in ("on", "yes", "true", "1")
    elif cmd == "bail" and args:
        state.bail = args[0].lower() in ("on", "yes", "true", "1")
    elif cmd == "print":
        print(" ".join(args))
    elif cmd == "cd" and args:
        os.chdir(args[0])
    elif cmd == "open":
        state.dbfile = args[-1] if args else ":memory:"
        connect(state)
    elif cmd == "read" and args:
        execute_text(Path(args[0]).read_text(), state)
    elif cmd == "tables":
        cur = state.conn.execute("select name from sqlite_master where type in ('table','view') and name not like 'sqlite_%' order by name")
        names = [r[0] for r in cur.fetchall()]
        if names:
            print(" ".join(names))
    elif cmd == "schema":
        cur = state.conn.execute("select sql from sqlite_master where sql is not null order by name")
        for r in cur.fetchall():
            print(r[0] + ";")
    elif cmd == "import" and len(args) >= 2:
        import_csv_to_table(args[0], args[1], state)
    elif cmd == "show":
        print(f"        echo: {state.echo}")
        print(f"     headers: {state.headers}")
        print(f"        mode: {state.mode}")
        print(f"   nullvalue: \"{state.null}\"")
        print(f"   separator: \"{state.separator}\"")
    else:
        print(f"Error: unknown command or invalid arguments:  \"{line}\"", file=sys.stderr)


def import_csv_to_table(path, table, state):
    with open(path, newline="") as f:
        reader = csv.reader(f)
        rows = list(reader)
    if not rows:
        return
    cols = [c or f"column{i}" for i, c in enumerate(rows[0])]
    cur = state.conn.cursor()
    cur.execute(f'DROP TABLE IF EXISTS "{table}"')
    cur.execute(f'CREATE TABLE "{table}" ({",".join(f"{q(c)} TEXT" for c in cols)})')
    if rows[1:]:
        cur.executemany(f'INSERT INTO "{table}" VALUES ({",".join(["?"]*len(cols))})', rows[1:])
    state.conn.commit()


def q(s):
    return '"' + s.replace('"', '""') + '"'


def sval(v, state):
    if v is None:
        return state.null
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v)


def infer_type(vals):
    vals = [v for v in vals if v is not None]
    if not vals:
        return "varchar"
    if all(isinstance(v, int) and not isinstance(v, bool) for v in vals):
        return "int32"
    if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in vals):
        return "double"
    return "varchar"


def duck_type(t):
    t = (t or "").upper()
    if "INT" in t:
        return "INTEGER"
    if any(x in t for x in ("CHAR", "TEXT", "CLOB")):
        return "VARCHAR"
    if any(x in t for x in ("REAL", "FLOA", "DOUB")):
        return "DOUBLE"
    if "BOOL" in t:
        return "BOOLEAN"
    return t or "VARCHAR"


def render(cols, rows, state):
    mode = state.mode
    if mode == "csv":
        return render_csv(cols, rows, state, ",")
    if mode == "list":
        return render_list(cols, rows, state)
    if mode == "json":
        return json.dumps([dict(zip(cols, r)) for r in rows], separators=(",", ":")) + "\n"
    if mode == "jsonlines":
        return "".join(json.dumps(dict(zip(cols, r)), separators=(",", ":")) + "\n" for r in rows)
    if mode == "line":
        return render_line(cols, rows, state)
    if mode == "column":
        return render_column(cols, rows, state)
    if mode == "table":
        return render_grid(cols, rows, state, ascii=True, types=False)
    if mode == "box":
        return render_grid(cols, rows, state, ascii=False, types=False)
    if mode == "duckbox":
        return render_grid(cols, rows, state, ascii=False, types=True)
    if mode == "ascii":
        lines = []
        if state.headers:
            lines.extend(cols)
        for r in rows:
            lines.extend(sval(v, state) for v in r)
        return "\n".join(lines) + ("\n" if lines else "")
    if mode == "markdown":
        return render_markdown(cols, rows, state)
    if mode == "html":
        return render_html(cols, rows, state)
    if mode == "quote":
        return render_quote(cols, rows, state)
    return render_grid(cols, rows, state, ascii=False, types=True)


def render_csv(cols, rows, state, delim):
    import io
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=delim, lineterminator="\n")
    if state.headers:
        w.writerow(cols)
    for r in rows:
        w.writerow([state.null if v is None else v for v in r])
    return buf.getvalue()


def render_list(cols, rows, state):
    out = []
    if state.headers:
        out.append(state.separator.join(cols))
    for r in rows:
        out.append(state.separator.join(sval(v, state) for v in r))
    return state.newline.join(out) + (state.newline if out else "")


def widths(cols, rows, state, types=False):
    data = []
    if state.headers:
        data.append(cols)
    if types:
        data.append([infer_type([r[i] for r in rows]) for i in range(len(cols))])
    data += [[sval(v, state) for v in r] for r in rows]
    return [max([len(str(row[i])) for row in data] + [len(cols[i])]) for i in range(len(cols))]


def render_grid(cols, rows, state, ascii=False, types=False):
    if not cols:
        return ""
    ws = widths(cols, rows, state, types)
    numeric = [all((r[i] is None or isinstance(r[i], (int, float))) for r in rows) for i in range(len(cols))]
    chars = ("+", "-", "|", "+", "+", "+", "+", "+", "+", "+", "+") if ascii else ("┌", "─", "│", "┬", "┐", "├", "┼", "┤", "└", "┴", "┘")
    tl, h, v, tj, tr, ml, mj, mr, bl, bj, br = chars
    def border(left, mid, right):
        return left + mid.join(h * (w + 2) for w in ws) + right + "\n"
    def row(vals):
        cells = []
        for i, val in enumerate(vals):
            s = str(val)
            cells.append(" " + (s.rjust(ws[i]) if numeric[i] else s.center(ws[i])) + " ")
        return v + v.join(cells) + v + "\n"
    out = border(tl, tj, tr)
    if state.headers:
        out += row(cols)
    if types:
        out += row([infer_type([r[i] for r in rows]) for i in range(len(cols))])
    if state.headers or types:
        out += border(ml, mj, mr)
    for r in rows:
        out += row([sval(x, state) for x in r])
    out += border(bl, bj, br)
    return out


def render_column(cols, rows, state):
    data = ([cols] if state.headers else []) + [[sval(v, state) for v in r] for r in rows]
    if not data:
        return ""
    ws = [max(len(str(row[i])) for row in data) for i in range(len(cols))]
    out = []
    if state.headers:
        out.append("  ".join(str(cols[i]).ljust(ws[i]) for i in range(len(cols))))
        out.append("  ".join("-" * ws[i] for i in range(len(cols))))
    for r in rows:
        out.append("  ".join(sval(r[i], state).ljust(ws[i]) for i in range(len(cols))))
    return "\n".join(out) + "\n"


def render_line(cols, rows, state):
    width = max([len(c) for c in cols] + [0])
    out = []
    for r in rows:
        for c, v in zip(cols, r):
            out.append(f"{c.rjust(width)} = {sval(v, state)}")
    return "\n".join(out) + ("\n" if out else "")


def render_markdown(cols, rows, state):
    out = []
    if state.headers:
        out.append("| " + " | ".join(cols) + " |")
        out.append("|" + "|".join("---" for _ in cols) + "|")
    for r in rows:
        out.append("| " + " | ".join(sval(v, state).replace("|", "\\|") for v in r) + " |")
    return "\n".join(out) + ("\n" if out else "")


def render_html(cols, rows, state):
    out = []
    if state.headers:
        out.append("<tr>" + "".join(f"<th>{html.escape(c)}</th>" for c in cols) + "</tr>")
    for r in rows:
        out.append("<tr>" + "".join(f"<td>{html.escape(sval(v, state))}</td>" for v in r) + "</tr>")
    return "\n".join(out) + ("\n" if out else "")


def render_quote(cols, rows, state):
    def qv(v):
        if v is None:
            return state.null
        if isinstance(v, (int, float)):
            return str(v)
        return "'" + str(v).replace("'", "''") + "'"
    out = []
    if state.headers:
        out.append("|".join(qv(c) for c in cols))
    for r in rows:
        out.append("|".join(qv(v) for v in r))
    return "\n".join(out) + ("\n" if out else "")


def write_output(text):
    sys.stdout.write(text)


def format_sql(text):
    s = re.sub(r"\s+", " ", text.strip())
    for kw in ["select", "from", "where", "group by", "order by", "limit", "insert", "update", "delete", "create table", "values"]:
        s = re.sub(r"\b" + kw + r"\b", kw.upper(), s, flags=re.I)
    return s + "\n"


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    state, pre, sqls, file_to_read, no_stdin = parse_args(argv)
    connect(state)
    code = 0
    for cmd in pre:
        code = execute_text(cmd, state) or code
    if file_to_read:
        code = execute_text(Path(file_to_read).read_text(), state) or code
    for s in sqls:
        code = execute_text(s, state) or code
    if not no_stdin and not sys.stdin.isatty():
        code = execute_text(sys.stdin.read(), state) or code
    return code


if __name__ == "__main__":
    raise SystemExit(main())
