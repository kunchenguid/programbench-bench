#!/usr/bin/env python3
import os
import re
import socket
import sys
from datetime import datetime


VERSION = "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z"

COMMANDS = {
    "add-environment": "Add a new named environment to an existing host directory",
    "diff": "Compare a DB server's schemas to the filesystem",
    "format": "Normalize format of filesystem representation of database objects",
    "help": "Display usage information",
    "init": "Save a DB server's schemas to the filesystem",
    "lint": "Check for problems in filesystem representation of database objects",
    "pull": "Update the filesystem representation of schemas",
    "push": "Alter objects on DBs to reflect the filesystem representation",
    "version": "Display program version",
}


GLOBAL_HELP = """Usage:  skeema [<options>] <command>

Skeema is a declarative schema management system for MySQL and MariaDB. It
allows you to export a database schema to the filesystem, and apply online
schema changes by modifying CREATE statements in .sql files.

Commands:
      add-environment  Add a new named environment to an existing host directory
      diff             Compare a DB server's schemas to the filesystem
      format           Normalize format of filesystem representation of database objects
      help             Display usage information
      init             Save a DB server's schemas to the filesystem
      lint             Check for problems in filesystem representation of database objects
      pull             Update the filesystem representation of schemas
      push             Alter objects on DBs to reflect the filesystem representation
      version          Display program version

Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version

Complete documentation for this command suite is available online:
https://www.skeema.io/docs/commands
"""

DESCRIPTIONS = {
    "version": "Display program version",
    "init": """Creates a filesystem representation of the schemas on a database server. For
each schema on the DB server (or just the single schema specified by --schema),
a subdir with a .skeema config file will be created. Each directory will be
populated with .sql files containing CREATE statements for every table and
routine in the schema.

When operating on all schemas on the server, this command automatically skips
pre-installed / system schemas (information_schema, performance_schema, mysql,
sys, test).

You may optionally pass an environment name as a command-line arg. This will
affect which section of .skeema config files the host-related options are
written to. For example, running `skeema init staging` will add config
directives to the [staging] section of config files. If no environment name is
supplied, the default is "production", so directives will be written to the
[production] section of the file.""",
    "diff": """Compares the schemas on database server(s) to the corresponding filesystem
representation of them. The output is a series of DDL commands that, if run on
the DB server, would cause its schemas to now match the definitions from the
filesystem.

You may optionally pass an environment name as a command-line arg. This will
affect which section of .skeema config files is used for processing. For
example, running `skeema diff staging` will apply config directives from the
[staging] section of config files, as well as any sectionless directives at the
top of the file. If no environment name is supplied, the default is
"production".

The `skeema diff` command is equivalent to running `skeema push` with its
--dry-run option enabled.

An exit code of 0 will be returned if no differences were found; 1 if some
differences were found; or 2+ if an error occurred.""",
    "push": """Modifies the schemas on database server(s) to match the corresponding filesystem
representation of them. This essentially performs the same diff logic as `skeema
diff`, but then actually runs the generated DDL. You should generally run
`skeema diff` first to see what changes will be applied.

You may optionally pass an environment name as a command-line arg. This will
affect which section of .skeema config files is used for processing.""",
    "pull": """Updates the existing filesystem representation of the schemas on a DB server.
Use this command when changes have been applied to the database manually or
outside of Skeema, in order to make the filesystem representation reflect those
changes.

You may optionally pass an environment name as a command-line arg. This will
affect which section of .skeema config files is used for processing.""",
    "lint": """Checks for problems in filesystem representation of database objects. A set of
linter rules are run against all objects. Each rule may be configured to
generate an error, a warning, or be ignored entirely. Statements that contain
invalid SQL, or otherwise return an error from the database, are always flagged
as linter errors.

By default, this command also reformats CREATE statements to their canonical
form, just like `skeema format`.

This command relies on accessing a database server to test the SQL DDL in a
temporary location. See the --workspace option for more information.""",
    "format": """Reformats the filesystem representation of database objects to match the
canonical format shown in SHOW CREATE.

This command relies on accessing a database server to test the SQL DDL in a
temporary location. See the --workspace option for more information.

You may optionally pass an environment name as a command-line arg. This will
affect which section of .skeema config files is used for workspace selection.""",
    "add-environment": """Modifies the .skeema file in an existing host directory to add a new named
environment. For example, if `skeema init` was previously used to create a dir
for a host with the default "production" environment, `skeema add-environment`
could be used to define a "staging" or "development" environment pointing at a
different host and port, or perhaps a "local" environment pointing at localhost
and a socket path.

This command currently only handles very simple cases. For many situations,
editing .skeema files directly is a better approach.""",
}

OPTION_BLOCKS = {
    "init": """Init Options:
  -d, --dir value              Subdir name to use for this host's schemas (default "<hostname>")
  -h, --host value             Database hostname or IP address
      --include-auto-inc       Include starting auto-inc values in table files
  -P, --port value             Port to use for database host (default "3306")
      --schema value           Only import the one specified schema; skip creation of subdirs for each schema
  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")
      --strip-partitioning     Omit PARTITION BY clause when writing partitioned tables to filesystem
""",
    "add-environment": """Add-Environment Options:
  -d, --dir value              Base dir for this host's schemas (default ".")
  -h, --host value             Database hostname or IP address
  -P, --port value             Port to use for database host (default "3306")
  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")
""",
    "format": """Format Options:
      --strip-partitioning         Remove PARTITION BY clauses from *.sql files
      --[skip-]write               Update files to correct format (enabled by default; disable with --skip-write)
""",
    "pull": """Pull Options:
      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)
      --include-auto-inc           Include starting auto-inc values in new table files, and update in existing files
      --[skip-]new-schemas         Detect any new schemas and populate new dirs for them (enabled by default; disable with --skip-new-schemas)
      --strip-partitioning         Omit PARTITION BY clause when writing partitioned tables to filesystem
      --update-partitioning        Update PARTITION BY clauses in existing table files
""",
}

LINTER = """Linter Rule Options:
      --allow-auto-inc value       List of allowed auto_increment column data types for --lint-auto-inc (default "int unsigned, bigint unsigned")
      --allow-charset value        List of allowed character sets for --lint-charset (default "latin1,utf8mb4")
      --allow-compression value    List of allowed compression settings for --lint-compression (default "none,4kb,8kb")
      --allow-definer value        List of allowed definer users for --lint-definer (default "%@%")
      --allow-engine value         List of allowed storage engines for --lint-engine (default "innodb")
      --allow-pk-type value        List of allowed data types for --lint-pk-type
      --lint-auto-inc value        Only allow auto_increment column data types listed in --allow-auto-inc (valid values: "ignore", "warning", "error") (default "warning")
      --lint-charset value         Only allow character sets listed in --allow-charset (valid values: "ignore", "warning", "error") (default "warning")
      --lint-compression value     Only allow compression settings listed in --allow-compression (valid values: "ignore", "warning", "error") (default "warning")
      --lint-definer value         Only allow definer users listed in --allow-definer for stored objects (valid values: "ignore", "warning", "error") (default "error")
      --lint-display-width value   Only allow default display width for int types (valid values: "ignore", "warning", "error") (default "warning")
      --lint-dupe-index value      Flag redundant secondary indexes (valid values: "ignore", "warning", "error") (default "warning")
      --lint-engine value          Only allow storage engines listed in --allow-engine (valid values: "ignore", "warning", "error") (default "warning")
      --lint-fk-parent value       Flag foreign keys where same-schema parent table is missing or lacks unique key on referenced columns (valid values: "ignore", "warning", "error") (default "warning")
      --lint-has-enum value        Flag columns using ENUM or SET data types (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-fk value          Flag any use of foreign keys; intended for environments that restrict their presence (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-float value       Flag columns using FLOAT or DOUBLE data types (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-routine value     Flag any use of stored procs or funcs; intended for environments that restrict their presence (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-time value        Flag columns using TIMESTAMP, DATETIME, or TIME data types (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-name-case value       Flag tables that have uppercase letters in their names (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-pk value              Flag tables that lack a primary key (valid values: "ignore", "warning", "error") (default "warning")
      --lint-pk-type value         Only allow primary keys to have types listed in --allow-pk-type (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-reserved-word value   Flag names of tables, columns, or routines that used reserved words (valid values: "ignore", "warning", "error") (default "warning")
      --lint-zero-date value       Flag DATE, DATETIME, and TIMESTAMP columns that have zero-date default values (valid values: "ignore", "warning", "error") (default "warning")
"""

WORKSPACE = """Workspace Options:
      --docker-cleanup value       With --workspace=docker, specifies how to clean up containers (valid values: "none", "stop", "destroy") (default "none")
  -t, --temp-schema value          Name of temporary schema for intermediate operations, created and dropped each run (default "_skeema_tmp")
      --temp-schema-binlog value   Controls whether temp schema DDL operations are replicated (valid values: "on", "off", "auto") (default "auto")
      --temp-schema-mode value     Tunes workspace load with workspace=temp-schema; heavier load makes Skeema faster but may disrupt other workloads on the database (valid values: "serial", "light", "regular", "heavy", "extreme") (default "regular")
      --temp-schema-threads value  Deprecated manner of controlling workspace load with workspace=temp-schema (default "5")
  -w, --workspace value            Specifies where to run intermediate operations (valid values: "temp-schema", "docker") (default "temp-schema")
"""

GLOBAL_OPTIONS = """Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version
"""


def stamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log(level, msg):
    print(f"{stamp()} [{level}] {msg}")


def error(msg, code=78):
    log("ERROR", msg)
    return code


def command_help(cmd):
    if cmd == "help":
        return GLOBAL_HELP
    out = [f"Usage:  skeema {cmd} [<options>]"]
    if cmd in ("init", "diff", "pull", "push", "lint", "format"):
        out[0] += " [<environment>]"
    elif cmd == "add-environment":
        out[0] += " <environment>"
    out += ["", DESCRIPTIONS.get(cmd, COMMANDS.get(cmd, "")), ""]
    if cmd in OPTION_BLOCKS:
        out.append(OPTION_BLOCKS[cmd])
    if cmd == "lint":
        out.append(OPTION_BLOCKS["format"])
        out.append(LINTER)
    if cmd in ("format", "lint", "pull"):
        out.append(WORKSPACE)
    if cmd in ("diff", "push"):
        out.append("""External Tool Options:
  -x, --alter-wrapper value           Output ALTER TABLEs as shell commands rather than just raw DDL; see manual for template vars
      --alter-wrapper-min-size value  Ignore --alter-wrapper for tables smaller than this size in bytes (default "0")
  -X, --ddl-wrapper value             Like --alter-wrapper, but applies to all DDL types (CREATE, DROP, ALTER)

SQL Generation Options:
      --alter-algorithm value         Apply an ALGORITHM clause to all ALTER TABLEs (valid values: "inplace", "copy", "instant", "nocopy")
      --alter-lock value              Apply a LOCK clause to all ALTER TABLEs (valid values: "none", "shared", "exclusive")
      --compare-metadata              For stored programs, detect changes to creation-time sql_mode or DB collation
      --exact-match                   Follow *.sql table definitions exactly, even for differences with no functional impact
      --lax-column-order              When comparing tables, don't re-order columns if they only differ by position
      --lax-comments                  When comparing tables or routines, don't modify them if they only differ by comment clauses
      --partitioning value            Specify handling of partitioning status on the database side (valid values: "keep", "remove", "modify") (default "keep")
""")
        out.append(LINTER)
        out.append("""Safety Options:
      --allow-unsafe                  Permit generating ALTER or DROP operations that are potentially destructive
      --dry-run                       Output DDL but don't run it; equivalent to `skeema diff`
      --safe-below-size value         Always permit destructive operations for tables below this size in bytes (default "0")
      --[skip-]verify                 Test all generated ALTER statements on temp schema to verify correctness (enabled by default; disable with --skip-verify)

Sharding Options:
  -q, --brief                         Don't output DDL to STDOUT; instead output list of database servers with at least one difference
  -c, --concurrent-servers value      Perform operations on this number of database servers concurrently (default "1")
  -1, --first-only                    For dirs mapping to multiple hosts or schemas, only run against the first target per dir
""")
        out.append(WORKSPACE)
    out.append(GLOBAL_OPTIONS)
    out += [f"Complete documentation for this command is available online:", f"https://www.skeema.io/docs/commands/{cmd}", ""]
    return "\n".join(out)


VALUE_OPTS = {
    "-o", "--connect-options", "-H", "--host-wrapper", "--ignore-func", "--ignore-proc",
    "--ignore-schema", "--ignore-table", "--ssl-mode", "-u", "--user", "-d", "--dir",
    "-h", "--host", "-P", "--port", "-S", "--socket", "--schema", "-x", "--alter-wrapper",
    "--alter-wrapper-min-size", "-X", "--ddl-wrapper", "--alter-algorithm", "--alter-lock",
    "--partitioning", "--allow-auto-inc", "--allow-charset", "--allow-compression",
    "--allow-definer", "--allow-engine", "--allow-pk-type", "--lint-auto-inc",
    "--lint-charset", "--lint-compression", "--lint-definer", "--lint-display-width",
    "--lint-dupe-index", "--lint-engine", "--lint-fk-parent", "--lint-has-enum",
    "--lint-has-fk", "--lint-has-float", "--lint-has-routine", "--lint-has-time",
    "--lint-name-case", "--lint-pk", "--lint-pk-type", "--lint-reserved-word",
    "--lint-zero-date", "--safe-below-size", "-c", "--concurrent-servers", "-t",
    "--temp-schema", "--temp-schema-binlog", "--temp-schema-mode", "--temp-schema-threads",
    "-w", "--workspace", "--docker-cleanup",
}
BOOL_OPTS = {
    "--debug", "--skip-my-cnf", "--my-cnf", "--include-auto-inc", "--strip-partitioning",
    "--alter-validate-virtual", "--compare-metadata", "--exact-match", "--lax-column-order",
    "--lax-comments", "--lint", "--skip-lint", "--allow-unsafe", "--verify", "--skip-verify",
    "--brief", "-q", "--first-only", "-1", "--format", "--skip-format", "--new-schemas",
    "--skip-new-schemas", "--update-partitioning", "--write", "--skip-write", "--dry-run",
    "--foreign-key-checks",
}


def parse(argv):
    opts = {"positionals": [], "debug": False, "host": None, "port": "3306", "dir": ".", "write": True}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            opts["positionals"].extend(argv[i + 1:])
            break
        if a in ("--version",):
            opts["version"] = True
        elif a in ("--help", "-?"):
            opts["help"] = True
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                opts["help_value"] = argv[i + 1]
                i += 1
        elif a.startswith("--help="):
            opts["help"] = True
            opts["help_value"] = a.split("=", 1)[1]
        elif a.startswith("--"):
            name, eq, val = a.partition("=")
            if name == "--password":
                if eq:
                    opts["password"] = val
                else:
                    opts["password_prompt"] = True
            elif name in VALUE_OPTS:
                if not eq:
                    i += 1
                    if i >= len(argv):
                        return None, f'CLI: Option "{name.lstrip("-")}" requires a value'
                    val = argv[i]
                key = name[2:].replace("-", "_")
                opts[key] = val
                if name == "--skip-write" or (name == "--write" and val.lower() == "false"):
                    opts["write"] = False
            elif name in BOOL_OPTS:
                key = name[2:].replace("-", "_")
                opts[key] = False if key.startswith("skip_") else True
                if name == "--debug":
                    opts["debug"] = True
                if name == "--skip-write" or (name == "--write" and eq and val.lower() == "false"):
                    opts["write"] = False
            else:
                return None, f'CLI: Unknown option "{name[2:]}"'
        elif a.startswith("-") and a != "-":
            if a in ("-p",):
                if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                    i += 1
                    opts["password"] = argv[i]
                else:
                    opts["password_prompt"] = True
            elif a in VALUE_OPTS:
                i += 1
                if i >= len(argv):
                    return None, f'CLI: Option "{a}" requires a value'
                keymap = {"-h": "host", "-P": "port", "-S": "socket", "-d": "dir", "-u": "user"}
                opts[keymap.get(a, a.lstrip("-"))] = argv[i]
            elif a in BOOL_OPTS:
                pass
            else:
                return None, f'CLI: Unknown option "{a.lstrip("-")}"'
        else:
            opts["positionals"].append(a)
        i += 1
    return opts, None


def read_config(path=".skeema"):
    cfg = {}
    section = ""
    if not os.path.exists(path):
        return cfg
    with open(path, encoding="utf-8") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            m = re.match(r"\[(.+)\]", s)
            if m:
                section = m.group(1)
                continue
            if "=" in s:
                k, v = [x.strip() for x in s.split("=", 1)]
                cfg[(section, k)] = v
    return cfg


def cfg_get(cfg, env, key, default=None):
    return cfg.get((env, key), cfg.get(("", key), default))


def has_sql_files(path="."):
    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if d != ".git"]
        if any(f.endswith(".sql") for f in files):
            return True
    return False


def can_connect(host, port):
    try:
        with socket.create_connection((host, int(port)), timeout=0.2):
            return True, ""
    except Exception as e:
        return False, str(e)


def go_format(kind, opts, env):
    cwd = os.getcwd()
    log("INFO", (" Checking format of " if not opts.get("write", True) else " Reformatting " if kind == "format" else " Linting ") + cwd)
    cfg = read_config()
    host = opts.get("host") or cfg_get(cfg, env, "host")
    flavor = cfg_get(cfg, env, "flavor") or cfg_get(cfg, env, "mysql-flavor")
    if has_sql_files(".") and not host and not flavor:
        if kind == "format":
            return error(f'Skipping {cwd}: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment "{env}"')
        log("ERROR", f'Skipping directory {os.path.basename(cwd)} due to error: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment "{env}"')
        log("ERROR", "Skipped 1 operation due to fatal errors")
        return 78
    return 0


def go_diff(cmd, opts, env):
    cfg = read_config()
    host = opts.get("host") or cfg_get(cfg, env, "host")
    port = opts.get("port") or cfg_get(cfg, env, "port", "3306")
    if host:
        ok, msg = can_connect(host, port)
        if not ok:
            log("ERROR", f"Skipping {host}:{port} for {os.getcwd()}: dial tcp {host}:{port}: connect: connection refused")
            log("ERROR", "Skipped 1 operation due to problem")
            return 2
    return 0


def go_init(opts, env):
    host = opts.get("host")
    if not host:
        return error("Option --host must be supplied on the command-line")
    port = opts.get("port", "3306")
    target = opts.get("dir")
    if target == ".":
        target = host
    ok, _ = can_connect(host, port)
    if not ok:
        log("ERROR", f"Unable to connect to {host}:{port} for {os.path.join(os.getcwd(), target)}: dial tcp {host}:{port}: connect: connection refused")
        return 2
    return 0


def go_add_environment(opts, env):
    d = opts.get("dir", ".")
    path = os.path.join(d, ".skeema")
    if not os.path.exists(path):
        return error(f"Dir {os.path.abspath(d)} does not have an existing .skeema file! Can only use `skeema add-environment` on a dir previously created by `skeema init`")
    host = opts.get("host")
    port = opts.get("port", "3306")
    sock = opts.get("socket")
    with open(path, "a", encoding="utf-8") as f:
        f.write(f"\n[{env}]\n")
        if host:
            f.write(f"host={host}\n")
        if port:
            f.write(f"port={port}\n")
        if sock and (host in (None, "", "localhost", "127.0.0.1")):
            f.write(f"socket={sock}\n")
    log("WARN", f' Unable to automatically determine database server\'s vendor/version. To set manually, use the "flavor" option in {os.path.abspath(path)}')
    log("INFO", f" Added environment [{env}] to {os.path.abspath(path)}")
    return 0


def main(argv):
    opts, err = parse(argv)
    if err:
        return error(err)
    pos = opts["positionals"]
    if opts.get("version"):
        print(VERSION)
        return 0
    if opts.get("help"):
        cmd = opts.get("help_value") or (pos[0] if pos else None)
        if not cmd:
            print()
            print(GLOBAL_HELP)
            return 0
        if cmd == "version":
            print(VERSION)
            return 0
        if cmd not in COMMANDS:
            return error(f'Unknown command "{cmd}"', 2)
        print()
        print(command_help(cmd))
        return 0
    if not pos:
        print()
        print(GLOBAL_HELP)
        return 0
    cmd = pos[0]
    args = pos[1:]
    if cmd not in COMMANDS:
        return error(f'Unknown command "{cmd}"')
    maxargs = 1 if cmd in ("help", "init", "diff", "pull", "push", "lint", "format", "add-environment") else 0
    minargs = 1 if cmd == "add-environment" else 0
    if len(args) < minargs:
        return error(f"Too few positional args supplied on command line; command {cmd} requires at least {minargs} args")
    if len(args) > maxargs:
        return error(f'Extra command-line arg "{args[maxargs]}" supplied; command {cmd} takes a max of {maxargs} args')
    if cmd == "help":
        if not args:
            print()
            print(GLOBAL_HELP)
        elif args[0] == "version":
            print(VERSION)
        elif args[0] in COMMANDS:
            print()
            print(command_help(args[0]))
        else:
            return error(f'Unknown command "{args[0]}"', 2)
        return 0
    if cmd == "version":
        print(VERSION)
        return 0
    env = args[0] if args else "production"
    if cmd == "init":
        code = go_init(opts, env)
    elif cmd in ("diff", "push"):
        code = go_diff(cmd, opts, env)
    elif cmd == "pull":
        code = go_format("pull", opts, env)
    elif cmd in ("lint", "format"):
        code = go_format(cmd, opts, env)
    elif cmd == "add-environment":
        code = go_add_environment(opts, env)
    else:
        code = 0
    if opts.get("debug"):
        log("DEBUG", f"Exit code {code} ({'SUCCESS' if code == 0 else 'ERROR'})")
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
