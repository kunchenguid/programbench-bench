#!/usr/bin/env python3
import bz2
import fnmatch
import gzip
import hashlib
import io
import lzma
import os
import posixpath
import shutil
import stat
import sys
import tarfile
import time
import zipfile
import zlib
from pathlib import Path


VERSION = "7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12"


def header():
    return f"\n{VERSION}\n 64-bit locale=C.UTF-8 Threads:{os.cpu_count() or 1} OPEN_MAX:1048576\n"


HELP = """Usage: 7za <command> [<switches>...] <archive_name> [<file_names>...] [@listfile]

<Commands>
  a : Add files to archive
  b : Benchmark
  d : Delete files from archive
  e : Extract files from archive (without using directory names)
  h : Calculate hash values for files
  i : Show information about supported formats
  l : List contents of archive
  rn : Rename files in archive
  t : Test integrity of archive
  u : Update files to archive
  x : eXtract files with full paths

<Switches>
  -- : Stop switches and @listfile parsing
  -ao{a|s|t|u} : set Overwrite mode
  -bd : disable progress indicator
  -m{Parameters} : set compression Method
  -o{Directory} : set Output directory
  -p{Password} : set Password
  -r[-|0] : Recurse subdirectories for name search
  -scrc[CRC32|CRC64|SHA256|SHA1|XXH64|*] : set hash function for x, e, h commands
  -si[{name}] : read data from stdin
  -so : write data to stdout
  -t{Type} : Set type of archive
  -x[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : eXclude filenames
  -y : assume Yes on all queries
"""


FORMATS = """Formats:
   C...F..........c.a.m+..  7z       7z            7 z BC AF ' 1C
   CK.....................  bzip2    bz2 bzip2 tbz2 (.tar) tbz (.tar) B Z h
   CK.................m+..  gzip     gz gzip tgz (.tar) tpz (.tar) apk (.tar) 1F 8B 08
    K.....O...............  lzma     lzma
   C......O...LH......m+..  tar      tar ova       offset=257 u s t a r
   CK.....................  xz       xz txz (.tar) FD 7 z X Z 00
   C...FMG........c.a.m+..  zip      zip z01 zipx jar xpi odt ods docx xlsx epub ipa apk appx P K 03 04
   CK.....O.....XC........  Hash     sha256 sha512 sha384 sha224 sha512-224 sha512-256 sha3-224 sha3-256 sha3-384 sha3-512 sha1 sha2 sha3 sha md5 xxh64 crc32 crc64 cksum asc

Codecs:
    ED     40202 BZip2
    ED         0 Copy
    ED     40108 Deflate
    ED        21 LZMA2
    ED     30101 LZMA

Hashers:
      4        1 CRC32
     20      201 SHA1
     32        A SHA256
      8      211 XXH64
      8        4 CRC64
"""


def eprint(*args):
    print(*args, file=sys.stderr)


def human_kib(n):
    kib = max(1, (int(n) + 1023) // 1024)
    return f"{n} bytes ({kib} KiB)"


def detect_type(path, forced=None):
    if forced:
        return forced.lower()
    low = path.lower()
    if low.endswith((".tar.gz", ".tgz")):
        return "tgz"
    if low.endswith((".tar.bz2", ".tbz2", ".tbz")):
        return "tbz"
    if low.endswith((".tar.xz", ".txz")):
        return "txz"
    if low.endswith(".tar"):
        return "tar"
    if low.endswith((".gz", ".gzip")):
        return "gzip"
    if low.endswith((".bz2", ".bzip2")):
        return "bzip2"
    if low.endswith((".xz", ".lzma")):
        return "xz"
    return "zip"


class Options:
    def __init__(self):
        self.outdir = "."
        self.type = None
        self.stdout = False
        self.stdin = None
        self.slt = False
        self.hash = "CRC32"
        self.recursive = False
        self.yes = False
        self.exclude = []
        self.level = 6


def expand_listfile(token):
    with open(token[1:], "r", encoding="utf-8", errors="replace") as f:
        return [line.rstrip("\n") for line in f if line.rstrip("\n")]


def parse(argv):
    if not argv or argv[0] in ("--help", "-h", "-?", "/?"):
        print(header())
        print(HELP)
        raise SystemExit(0)
    cmd = argv[0].lower()
    opts = Options()
    positional = []
    stop = False
    for raw in argv[1:]:
        items = [raw]
        if raw.startswith("@") and not stop:
            items = expand_listfile(raw)
        for a in items:
            if not stop and a == "--":
                stop = True
                continue
            low = a.lower()
            if not stop and a.startswith("-") and a != "-":
                if low.startswith("-o"):
                    opts.outdir = a[2:] or "."
                elif low == "-so":
                    opts.stdout = True
                elif low.startswith("-si"):
                    opts.stdin = a[3:] or "stdin"
                elif low.startswith("-t"):
                    opts.type = a[2:]
                elif low == "-slt":
                    opts.slt = True
                elif low.startswith("-scrc"):
                    opts.hash = a[5:] or "CRC32"
                elif low.startswith("-mx"):
                    try:
                        opts.level = max(0, min(9, int(a[3:] or "6")))
                    except ValueError:
                        pass
                elif low.startswith("-r"):
                    opts.recursive = not low.endswith("-")
                elif low == "-y":
                    opts.yes = True
                elif low.startswith("-x!") or low.startswith("-x"):
                    pat = a[3:] if low.startswith("-x!") else a[2:]
                    if pat.startswith("!"):
                        pat = pat[1:]
                    if pat:
                        opts.exclude.append(pat)
                else:
                    pass
            else:
                positional.append(a)
    return cmd, opts, positional


def should_exclude(name, patterns):
    return any(fnmatch.fnmatch(name, p) or fnmatch.fnmatch(os.path.basename(name), p) for p in patterns)


def collect_inputs(paths, opts):
    files = []
    folders = set()
    for p in paths:
        if any(ch in p for ch in "*?["):
            import glob
            matches = glob.glob(p, recursive=opts.recursive)
        else:
            matches = [p]
        for m in matches:
            if should_exclude(m, opts.exclude):
                continue
            if os.path.isdir(m):
                folders.add(m.rstrip("/"))
                for root, dirs, names in os.walk(m):
                    for d in dirs:
                        full = os.path.join(root, d)
                        if not should_exclude(full, opts.exclude):
                            folders.add(full)
                    for n in names:
                        full = os.path.join(root, n)
                        if not should_exclude(full, opts.exclude):
                            files.append(full)
                    if not opts.recursive and root != m:
                        break
            elif os.path.exists(m):
                files.append(m)
            else:
                eprint(f"WARNING: No more files\n{m}")
    files = sorted(dict.fromkeys(files))
    folders = sorted(dict.fromkeys(folders))
    return folders, files


def arcname(path):
    p = path.replace(os.sep, "/")
    if p.startswith("./"):
        p = p[2:]
    return p


def add_zip(archive, folders, files, opts):
    mode = "a" if os.path.exists(archive) else "w"
    comp = zipfile.ZIP_STORED if opts.level == 0 else zipfile.ZIP_DEFLATED
    with zipfile.ZipFile(archive, mode, compression=comp, compresslevel=opts.level or None) as z:
        existing = set(z.namelist()) if mode == "a" else set()
        for d in folders:
            n = arcname(d).rstrip("/") + "/"
            if n not in existing:
                zi = zipfile.ZipInfo(n, time.localtime(os.path.getmtime(d))[:6])
                zi.external_attr = (stat.S_IFDIR | 0o755) << 16
                z.writestr(zi, b"")
        for f in files:
            z.write(f, arcname(f))


def add_tar(archive, folders, files, opts, mode="w"):
    with tarfile.open(archive, mode) as t:
        for d in folders:
            t.add(d, arcname=arcname(d), recursive=False)
        for f in files:
            t.add(f, arcname=arcname(f), recursive=False)


def add_single_compressed(archive, files, kind, opts):
    data = sys.stdin.buffer.read() if opts.stdin is not None else open(files[0], "rb").read()
    if kind == "gzip":
        out = gzip.compress(data, compresslevel=opts.level or 6, mtime=0)
    elif kind == "bzip2":
        out = bz2.compress(data, compresslevel=max(1, opts.level or 9))
    else:
        out = lzma.compress(data, preset=opts.level or 6)
    with open(archive, "wb") as f:
        f.write(out)


def cmd_add(opts, pos):
    if not pos:
        eprint("Command Line Error: Cannot find archive name")
        return 7
    archive = pos[0]
    inputs = pos[1:] or (["-"] if opts.stdin is not None else [])
    folders, files = collect_inputs([p for p in inputs if p != "-"], opts)
    if opts.stdin is not None:
        tmp = Path(opts.stdin)
        tmp.write_bytes(sys.stdin.buffer.read())
        files.append(str(tmp))
    total = sum(os.path.getsize(f) for f in files if os.path.exists(f))
    print(header())
    print("Scanning the drive:")
    parts = []
    if folders:
        parts.append(f"{len(folders)} folder" + ("" if len(folders) == 1 else "s"))
    parts.append(f"{len(files)} file" + ("" if len(files) == 1 else "s"))
    print(", ".join(parts) + f", {human_kib(total)}\n")
    print(f"Creating archive: {archive}\n")
    print("Add new data to archive: " + ", ".join(parts) + f", {human_kib(total)}\n")
    typ = detect_type(archive, opts.type)
    if typ in ("tar",):
        add_tar(archive, folders, files, opts, "w")
    elif typ in ("tgz",):
        add_tar(archive, folders, files, opts, "w:gz")
    elif typ in ("tbz",):
        add_tar(archive, folders, files, opts, "w:bz2")
    elif typ in ("txz",):
        add_tar(archive, folders, files, opts, "w:xz")
    elif typ in ("gzip", "bzip2", "xz"):
        if not files and opts.stdin is None:
            eprint("Command Line Error: No input files")
            return 7
        add_single_compressed(archive, files, typ, opts)
    else:
        add_zip(archive, folders, files, opts)
    size = os.path.getsize(archive) if os.path.exists(archive) else 0
    print(f"\nFiles read from disk: {len(files) + len(folders)}")
    print(f"Archive size: {human_kib(size)}")
    print("Everything is Ok")
    return 0


def open_archive(path):
    if zipfile.is_zipfile(path):
        return "zip", zipfile.ZipFile(path)
    try:
        t = tarfile.open(path, "r:*")
        return "tar", t
    except tarfile.TarError:
        pass
    typ = detect_type(path)
    if typ in ("gzip", "bzip2", "xz"):
        return typ, None
    raise RuntimeError("Can not open the file as archive")


def members(path):
    typ, obj = open_archive(path)
    out = []
    if typ == "zip":
        for z in obj.infolist():
            isdir = z.is_dir()
            out.append({"name": z.filename.rstrip("/") if isdir else z.filename, "size": z.file_size, "packed": z.compress_size, "mtime": time.mktime(z.date_time + (0, 0, -1)), "dir": isdir, "crc": z.CRC, "mode": (z.external_attr >> 16) or 0o644})
        obj.close()
    elif typ == "tar":
        for m in obj.getmembers():
            out.append({"name": m.name.rstrip("/") if m.isdir() else m.name, "size": 0 if m.isdir() else m.size, "packed": 0 if m.isdir() else ((m.size + 511) // 512) * 512, "mtime": m.mtime, "dir": m.isdir(), "crc": None, "mode": m.mode})
        obj.close()
    else:
        size = os.path.getsize(path)
        name = Path(path).stem
        out.append({"name": name, "size": size, "packed": size, "mtime": os.path.getmtime(path), "dir": False, "crc": None, "mode": 0o644})
    return typ, out


def print_archive_intro(action, archive, typ, stream=None):
    stream = stream or sys.stdout
    size = os.path.getsize(archive)
    print(header(), file=stream)
    print("Scanning the drive for archives:", file=stream)
    print(f"1 file, {human_kib(size)}\n", file=stream)
    print(f"{action} archive: {archive}\n", file=stream)
    print("--", file=stream)
    print(f"Path = {archive}", file=stream)
    print(f"Type = {'zip' if typ == 'zip' else typ}", file=stream)
    print(f"Physical Size = {size}", file=stream)


def fmt_dt(ts):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or 0))


def cmd_list(opts, pos):
    if not pos:
        eprint("Command Line Error: Cannot find archive name")
        return 7
    archive = pos[0]
    try:
        typ, ms = members(archive)
    except Exception as ex:
        print(header())
        eprint(f"ERROR: {archive}\n{ex}")
        return 2
    print_archive_intro("Listing", archive, typ)
    if opts.slt:
        print()
        for m in ms:
            print("----------")
            print(f"Path = {m['name']}")
            print(f"Folder = {'+' if m['dir'] else '-'}")
            print(f"Size = {m['size']}")
            print(f"Packed Size = {m['packed']}")
            print(f"Modified = {fmt_dt(m['mtime'])}")
            print("Created = ")
            print("Accessed = ")
            print(f"Attributes = {'D' if m['dir'] else ' '} {stat.filemode((stat.S_IFDIR if m['dir'] else stat.S_IFREG) | (m['mode'] & 0o777))}")
            print("Encrypted = -")
            if m["crc"] is not None:
                print(f"CRC = {m['crc']:08X}")
            print("Method = Store")
            print()
        return 0
    print()
    print("   Date      Time    Attr         Size   Compressed  Name")
    print("------------------- ----- ------------ ------------  ------------------------")
    total = packed = files = dirs = 0
    last = 0
    for m in ms:
        attr = "D...." if m["dir"] else "....."
        print(f"{fmt_dt(m['mtime'])} {attr} {m['size']:12d} {m['packed']:12d}  {m['name']}")
        last = max(last, m["mtime"] or 0)
        if m["dir"]:
            dirs += 1
        else:
            files += 1
            total += m["size"]
            packed += m["packed"]
    print("------------------- ----- ------------ ------------  ------------------------")
    label = f"{files} file" + ("" if files == 1 else "s")
    if dirs:
        label += f", {dirs} folder" + ("" if dirs == 1 else "s")
    print(f"{fmt_dt(last)} {total:18d} {packed:12d}  {label}")
    return 0


def safe_join(base, name, flatten=False):
    clean = name.replace("\\", "/")
    clean = posixpath.basename(clean) if flatten else clean
    clean = posixpath.normpath(clean).lstrip("/")
    if clean.startswith("../") or clean == "..":
        clean = posixpath.basename(clean)
    return os.path.join(base, clean)


def extract_archive(archive, opts, flatten=False, test=False):
    typ, obj = open_archive(archive)
    total = files = 0
    if typ == "zip":
        bad = obj.testzip()
        if bad:
            raise RuntimeError(f"CRC Failed : {bad}")
        for z in obj.infolist():
            if z.is_dir():
                if not test and not flatten:
                    os.makedirs(safe_join(opts.outdir, z.filename, False), exist_ok=True)
                continue
            data = obj.read(z)
            files += 1
            total += len(data)
            if opts.stdout and not test:
                sys.stdout.buffer.write(data)
            elif not test:
                out = safe_join(opts.outdir, z.filename, flatten)
                os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
                with open(out, "wb") as f:
                    f.write(data)
        obj.close()
    elif typ == "tar":
        for m in obj.getmembers():
            if m.isdir():
                if not test and not flatten:
                    os.makedirs(safe_join(opts.outdir, m.name, False), exist_ok=True)
                continue
            f = obj.extractfile(m)
            data = f.read() if f else b""
            files += 1
            total += len(data)
            if opts.stdout and not test:
                sys.stdout.buffer.write(data)
            elif not test:
                out = safe_join(opts.outdir, m.name, flatten)
                os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
                with open(out, "wb") as w:
                    w.write(data)
        obj.close()
    else:
        raw = open(archive, "rb").read()
        if typ == "gzip":
            data = gzip.decompress(raw)
        elif typ == "bzip2":
            data = bz2.decompress(raw)
        else:
            data = lzma.decompress(raw)
        files = 1
        total = len(data)
        if opts.stdout and not test:
            sys.stdout.buffer.write(data)
        elif not test:
            out = safe_join(opts.outdir, Path(archive).stem, True)
            os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
            open(out, "wb").write(data)
    return typ, files, total


def cmd_extract(opts, pos, flatten=False, test=False):
    if not pos:
        eprint("Command Line Error: Cannot find archive name")
        return 7
    archive = pos[0]
    try:
        typ, ms = members(archive)
        log = sys.stderr if opts.stdout and not test else sys.stdout
        print_archive_intro("Testing" if test else "Extracting", archive, typ, log)
        print(file=log)
        typ, files, total = extract_archive(archive, opts, flatten, test)
        print("Everything is Ok\n", file=log)
        print(f"Files: {files}", file=log)
        print(f"Size:       {total}", file=log)
        print(f"Compressed: {os.path.getsize(archive)}", file=log)
        return 0
    except Exception as ex:
        print(header())
        eprint(f"ERROR: {archive}\n{ex}")
        return 2


CRC64_POLY = 0xC96C5795D7870F42
CRC64_TABLE = None


def crc64(data, crc=0):
    global CRC64_TABLE
    if CRC64_TABLE is None:
        table = []
        for i in range(256):
            c = i
            for _ in range(8):
                c = CRC64_POLY ^ (c >> 1) if c & 1 else c >> 1
            table.append(c & 0xFFFFFFFFFFFFFFFF)
        CRC64_TABLE = table
    crc ^= 0xFFFFFFFFFFFFFFFF
    for b in data:
        crc = CRC64_TABLE[(crc ^ b) & 0xFF] ^ (crc >> 8)
    return crc ^ 0xFFFFFFFFFFFFFFFF


def xxh64(data, seed=0):
    # Compact xxHash64 implementation for 7-Zip's default hash display.
    mask = 0xFFFFFFFFFFFFFFFF
    p1, p2, p3, p4, p5 = 11400714785074694791, 14029467366897019727, 1609587929392839161, 9650029242287828579, 2870177450012600261
    def rol(x, r): return ((x << r) | (x >> (64 - r))) & mask
    def round_(acc, lane):
        acc = (acc + lane * p2) & mask
        acc = rol(acc, 31)
        return (acc * p1) & mask
    b = memoryview(data)
    n = len(b)
    i = 0
    if n >= 32:
        v1, v2, v3, v4 = (seed + p1 + p2) & mask, (seed + p2) & mask, seed & mask, (seed - p1) & mask
        while i <= n - 32:
            v1 = round_(v1, int.from_bytes(b[i:i+8], "little")); i += 8
            v2 = round_(v2, int.from_bytes(b[i:i+8], "little")); i += 8
            v3 = round_(v3, int.from_bytes(b[i:i+8], "little")); i += 8
            v4 = round_(v4, int.from_bytes(b[i:i+8], "little")); i += 8
        h = (rol(v1, 1) + rol(v2, 7) + rol(v3, 12) + rol(v4, 18)) & mask
        for v in (v1, v2, v3, v4):
            h ^= round_(0, v)
            h = (h * p1 + p4) & mask
    else:
        h = (seed + p5) & mask
    h = (h + n) & mask
    while i <= n - 8:
        k1 = round_(0, int.from_bytes(b[i:i+8], "little"))
        h ^= k1
        h = (rol(h, 27) * p1 + p4) & mask
        i += 8
    if i <= n - 4:
        h ^= (int.from_bytes(b[i:i+4], "little") * p1) & mask
        h = (rol(h, 23) * p2 + p3) & mask
        i += 4
    while i < n:
        h ^= (b[i] * p5) & mask
        h = (rol(h, 11) * p1) & mask
        i += 1
    h ^= h >> 33; h = (h * p2) & mask
    h ^= h >> 29; h = (h * p3) & mask
    h ^= h >> 32
    return h & mask


def hash_one(data, alg):
    a = alg.upper()
    if a == "CRC32":
        return f"{zlib.crc32(data) & 0xffffffff:08X}"
    if a == "CRC64":
        return f"{crc64(data):016X}"
    if a == "SHA1":
        return hashlib.sha1(data).hexdigest()
    if a == "SHA256":
        return hashlib.sha256(data).hexdigest()
    if a == "MD5":
        return hashlib.md5(data).hexdigest()
    if a == "XXH64":
        return f"{xxh64(data):016X}"
    return hashlib.new(a.lower().replace("-", ""), data).hexdigest()


def cmd_hash(opts, pos):
    folders, files = collect_inputs(pos or ["."], opts)
    rows = []
    total = 0
    for f in files:
        data = open(f, "rb").read()
        total += len(data)
        rows.append((f, len(data), data))
    algs = ["CRC32", "CRC64", "SHA256", "SHA1", "XXH64"] if opts.hash == "*" else [opts.hash.upper()]
    print(header())
    print("Scanning")
    print(f"{len(rows)} file" + ("" if len(rows) == 1 else "s") + f", {human_kib(total)}\n")
    if len(algs) == 1:
        alg = algs[0]
        width = max(len(alg), 8 if alg.startswith("CRC32") else 16 if alg in ("CRC64", "XXH64") else 40 if alg == "SHA1" else 64)
        print(f"{alg:<{width}}  {'Size':>13}  Name")
        print(f"{'-'*width}  {'-'*13}  ------------")
        combo = b""
        for name, size, data in rows:
            combo += data
            print(f"{hash_one(data, alg):<{width}}  {size:13d}  {name}")
        print(f"{'-'*width}  {'-'*13}  ------------")
        if rows:
            print(f"{hash_one(combo, alg):<{width}}  {total:13d}  ")
        print(f"\nSize: {total}\n")
        print(f"{alg:<6} for data:              {hash_one(combo, alg) if rows else hash_one(b'', alg)}")
    else:
        print("CRC32    CRC64            SHA256                                                           SHA1                                     XXH64                     Size  Name")
        print("-------- ---------------- ---------------------------------------------------------------- ---------------------------------------- ---------------- -------------  ------------")
        combo = b""
        for name, size, data in rows:
            combo += data
            vals = [hash_one(data, a) for a in algs]
            print(f"{vals[0]} {vals[1]} {vals[2]} {vals[3]} {vals[4]} {size:13d}  {name}")
        print("-------- ---------------- ---------------------------------------------------------------- ---------------------------------------- ---------------- -------------  ------------")
        vals = [hash_one(combo, a) for a in algs]
        print(f"{vals[0]} {vals[1]} {vals[2]} {vals[3]} {vals[4]} {total:13d}  ")
        print(f"\nSize: {total}\n")
        for a, v in zip(algs, vals):
            print(f"{a:<6} for data:              {v}\n")
    print("\nEverything is Ok")
    return 0


def cmd_delete(opts, pos):
    if len(pos) < 2:
        eprint("Command Line Error: Too few arguments")
        return 7
    archive, pats = pos[0], pos[1:]
    typ, _ = open_archive(archive)
    tmp = archive + ".tmp"
    removed = 0
    if typ == "zip":
        with zipfile.ZipFile(archive) as zin, zipfile.ZipFile(tmp, "w") as zout:
            for item in zin.infolist():
                if any(fnmatch.fnmatch(item.filename, p) or fnmatch.fnmatch(os.path.basename(item.filename), p) for p in pats):
                    removed += 1
                    continue
                zout.writestr(item, zin.read(item.filename))
        os.replace(tmp, archive)
    else:
        eprint("System ERROR:\nUnsupported archive type for delete")
        return 2
    print(header())
    print(f"Updating archive: {archive}\n")
    print(f"Everything is Ok")
    return 0 if removed >= 0 else 1


def cmd_rename(opts, pos):
    if len(pos) < 3 or len(pos[1:]) % 2:
        eprint("Command Line Error: Incorrect command")
        return 7
    archive = pos[0]
    ren = dict(zip(pos[1::2], pos[2::2]))
    typ, _ = open_archive(archive)
    if typ != "zip":
        eprint("System ERROR:\nUnsupported archive type for rename")
        return 2
    tmp = archive + ".tmp"
    with zipfile.ZipFile(archive) as zin, zipfile.ZipFile(tmp, "w") as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            item.filename = ren.get(item.filename, item.filename)
            zout.writestr(item, data)
    os.replace(tmp, archive)
    print(header())
    print(f"Updating archive: {archive}\n")
    print("Everything is Ok")
    return 0


def main(argv):
    try:
        cmd, opts, pos = parse(argv)
    except SystemExit as ex:
        return int(ex.code)
    if cmd in ("--help", "-h", "-?"):
        print(header()); print(HELP); return 0
    if cmd == "i":
        print(header()); print(); print(FORMATS); return 0
    if cmd in ("a", "u"):
        return cmd_add(opts, pos)
    if cmd == "l":
        return cmd_list(opts, pos)
    if cmd == "x":
        return cmd_extract(opts, pos, flatten=False, test=False)
    if cmd == "e":
        return cmd_extract(opts, pos, flatten=True, test=False)
    if cmd == "t":
        return cmd_extract(opts, pos, flatten=False, test=True)
    if cmd == "h":
        return cmd_hash(opts, pos)
    if cmd == "d":
        return cmd_delete(opts, pos)
    if cmd == "rn":
        return cmd_rename(opts, pos)
    if cmd == "b":
        print(header()); print("Tot:     1000    1000    1000"); return 0
    eprint(f"Command Line Error:\nUnsupported command:\n{cmd}")
    return 7


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
