#!/usr/bin/env python3
import fnmatch
import json
import os
import re
import sys
from dataclasses import dataclass, field

VERSION_TEXT = """Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team
Universal Ctags is derived from Exuberant Ctags.
Exuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert
  Compiled: Apr 20 2026, 16:52:56
  URL: https://ctags.io/
  Output version: 1.1
  Optional compiled features: +wildcards, +regex, +iconv, +option-directory, +xpath, +json, +interactive, +sandbox, +yaml, +packcc, +optscript"""

HELP_TEXT = VERSION_TEXT + """

Usage: executable [options] [file(s)]

Input/Output Options
  --exclude=<pattern>
       Exclude files and directories matching <pattern>.
  --filter[=(yes|no)]
       Behave as a filter, reading file names from standard input and
       writing tags to standard output [no].
  --links[=(yes|no)]
       Indicate whether symbolic links should be followed [yes].
  --maxdepth=<N>
       Specify maximum recursion depth.
  --recurse[=(yes|no)]
       Recurse into directories supplied on command line [no].
  -R   Equivalent to --recurse.
  -L <file>
       A list of input file names is read from the specified <file>.
  --append[=(yes|no)]
       Should tags should be appended to existing tag file [no]?
  -a   Append the tags to an existing tag file.
  -f <tagfile>
       Write tags to specified <tagfile>. Value of "-" writes tags to stdout
       ["tags"; or "TAGS" when -e supplied].
  -o   Alternative for -f.

Output Format Options
  --format=(1|2)
       Force output of specified tag file format [2].
  --output-format=(u-ctags|e-ctags|etags|xref|json)
      Specify the output format. [u-ctags]
  -e   Output tag file for use with Emacs.
  -x   Print a tabular cross reference file to standard output.
  --sort=(yes|no|foldcase)
       Should tags be sorted (optionally ignoring case) [yes]?
  -u   Equivalent to --sort=no.
  --excmd=(number|pattern|mix|combine)
       Uses the specified type of EX command to locate tags [mix].
  -n   Equivalent to --excmd=number.
  -N   Equivalent to --excmd=pattern.
  --fields=[+|-][<flags>|*]
       Include selected extension fields (<flags>: "aCeEfFikKlmnNpPrRsStxzZ") [fks].

Language Selection and Mapping Options
  --language-force=(<language>|auto)
       Force all files to be interpreted using specified <language>.
  --languages=[+|-](<list>|all)
       Restrict files scanned for tags to those mapped to languages specified.
  --langmap=<map>[,<map>[...]]
       Override default mapping of language to input file extension.

Listing Options
  --list-features
       Output list of compiled features.
  --list-fields[=(<language>|all)]
       Output list of fields.
  --list-kinds[=(<language>|all)]
       Output a list of all tag kinds for specified <language> or all.
  --list-languages
       Output list of supported languages.
  --list-maps[=(<language>|all)]
       Output list of language mappings.
  --list-output-formats
       Output list of output formats.
  --list-pseudo-tags
       Output list of pseudo tags.
  --machinable[=(yes|no)]
       Use tab separated representation in --list-* option output. [no]
  --with-list-header[=(yes|no)]
       Prepend the column descriptions in --list- output. [yes]

Miscellaneous Options
  --help
       Print this option summary.
  -?   Print this option summary.
  --license
       Print details of software license.
  --print-language
       Don't make tags file but just print the guessed language name for
       input file.
  --quiet[=(yes|no)]
       Don't print NOTICE class messages [no].
  --totals[=(yes|no|extra)]
       Print statistics about input and tag files [no].
  --verbose[=(yes|no)]
       Enable verbose messages describing actions on each input file.
  --version[=<language>]
       Print version identifier of the program to standard output.
  -V   Equivalent to --verbose."""

LANGUAGES = [
    "Abaqus", "Abc", "Ada", "AnsiblePlaybook", "Ant", "Asciidoc", "Asm", "Asp",
    "Autoconf", "Automake", "Awk", "Basic", "Bats", "BibTeX", "C", "C#",
    "C++", "Clojure", "CMake", "CSS", "CUDA", "D", "Diff", "DTD", "Elixir",
    "Elm", "EmacsLisp", "Erlang", "Fortran", "Go", "HTML", "Java",
    "JavaScript", "JSON", "Julia", "Kotlin", "Lua", "M4", "Make", "Man",
    "Markdown", "MatLab", "Meson", "ObjectiveC", "OCaml", "Pascal", "Perl",
    "PHP", "Python", "R", "Ruby", "Rust", "Scala", "Scheme", "Sh", "SQL",
    "Tcl", "Tex", "TypeScript", "Vim", "XML", "YAML",
]

KIND_TABLES = {
    "Python": [("c", "classes"), ("f", "functions"), ("m", "class members"), ("v", "variables"),
               ("I", "name referring a module defined in other file"), ("i", "modules"),
               ("Y", "name referring a class/variable/function/module defined in other module"),
               ("z", "function parameters [off]"), ("l", "local variables [off]")],
    "C": [("d", "macro definitions"), ("e", "enumerators (values inside an enumeration)"),
          ("f", "function definitions"), ("g", "enumeration names"), ("h", "included header files"),
          ("l", "local variables [off]"), ("m", "struct, and union members"), ("p", "function prototypes [off]"),
          ("s", "structure names"), ("t", "typedefs"), ("u", "union names"), ("v", "variable definitions"),
          ("x", "external and forward variable declarations [off]"), ("z", "function parameters inside function or prototype definitions [off]"),
          ("L", "goto labels [off]"), ("D", "parameters inside macro definitions [off]")],
    "C++": [],
    "JavaScript": [("C", "constants"), ("c", "classes"), ("f", "functions"), ("m", "methods"), ("v", "variables")],
    "TypeScript": [("C", "constants"), ("c", "classes"), ("f", "functions"), ("m", "methods"), ("v", "variables"), ("i", "interfaces")],
    "Markdown": [("c", "chapters"), ("s", "sections"), ("S", "subsections")],
    "Go": [("p", "packages"), ("f", "functions"), ("m", "methods"), ("t", "type names"), ("v", "variables"), ("c", "constants")],
    "Java": [("c", "classes"), ("i", "interfaces"), ("m", "methods"), ("f", "fields"), ("e", "enum constants"), ("g", "enum types")],
    "Ruby": [("c", "classes"), ("m", "modules"), ("f", "methods"), ("F", "singleton methods"), ("C", "constants")],
    "Sh": [("f", "functions"), ("a", "aliases"), ("v", "variables")],
}
KIND_TABLES["C++"] = KIND_TABLES["C"]

EXT_LANG = {
    ".py": "Python", ".pyx": "Python", ".pxd": "Python", ".pxi": "Python", ".wsgi": "Python", ".scons": "Python",
    ".c": "C", ".h": "C", ".i": "C", ".pc": "C",
    ".cc": "C++", ".cpp": "C++", ".cxx": "C++", ".c++": "C++", ".hpp": "C++", ".hh": "C++", ".hxx": "C++",
    ".js": "JavaScript", ".jsx": "JavaScript", ".mjs": "JavaScript",
    ".ts": "TypeScript", ".tsx": "TypeScript",
    ".md": "Markdown", ".markdown": "Markdown",
    ".go": "Go", ".java": "Java", ".rb": "Ruby", ".sh": "Sh", ".bash": "Sh", ".zsh": "Sh", ".xml": "XML", ".json": "JSON",
}
KIND_NAMES = {
    "c": "class", "f": "function", "m": "member", "v": "variable", "Y": "unknown", "I": "namespace",
    "i": "module", "d": "macro", "e": "enumerator", "g": "enum", "s": "struct", "t": "typedef",
    "u": "union", "p": "package", "C": "constant", "S": "subsection",
}

@dataclass
class Tag:
    name: str
    path: str
    line: int
    text: str
    kind: str
    fields: list = field(default_factory=list)

def esc_pat(s):
    return s.rstrip("\n").replace("\\", "\\\\").replace("/", "\\/")

def lang_for(path, forced=None):
    if forced and forced.lower() != "auto":
        aliases = {"c++": "C++", "cpp": "C++", "py": "Python", "javascript": "JavaScript", "typescript": "TypeScript", "sh": "Sh"}
        return aliases.get(forced.lower(), forced[:1].upper() + forced[1:])
    base = os.path.basename(path)
    if base in ("Makefile", "makefile", "GNUmakefile"):
        return "Make"
    return EXT_LANG.get(os.path.splitext(path)[1].lower())

def is_identifier(s):
    return re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", s or "") is not None

def parse_python(path, lines):
    tags, stack = [], []
    pending_decorators = []
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        indent = len(line) - len(line.lstrip(" "))
        while stack and indent <= stack[-1][0]:
            stack.pop()
        cls = next((x for x in reversed(stack) if x[1] == "class"), None)
        if stripped.startswith("@"):
            pending_decorators.append(stripped)
            continue
        m = re.match(r"^(async\s+def|def)\s+([A-Za-z_][\w]*)\s*\(", stripped)
        if m:
            kind = "m" if cls else "f"
            fields = [f"class:{cls[2]}"] if cls else []
            tags.append(Tag(m.group(2), path, i, line, kind, fields))
            stack.append((indent, "def", m.group(2)))
            pending_decorators = []
            continue
        m = re.match(r"^class\s+([A-Za-z_][\w]*)\b", stripped)
        if m:
            fields = [f"class:{cls[2]}"] if cls else []
            tags.append(Tag(m.group(1), path, i, line, "c", fields))
            stack.append((indent, "class", m.group(1)))
            pending_decorators = []
            continue
        m = re.match(r"^from\s+[\w.]+\s+import\s+(.+)", stripped)
        if m:
            for part in m.group(1).split(","):
                part = part.strip()
                mm = re.match(r"([A-Za-z_][\w]*)\s+as\s+([A-Za-z_][\w]*)", part)
                if mm:
                    tags.append(Tag(mm.group(2), path, i, line, "Y", [f"nameref:unknown:{mm.group(1)}"]))
            continue
        m = re.match(r"^([A-Za-z_][\w]*)\s*=", stripped)
        in_class_body = bool(stack and stack[-1][1] == "class" and cls and indent > cls[0])
        if m and (not stack or in_class_body):
            fields = [f"class:{cls[2]}"] if in_class_body else []
            tags.append(Tag(m.group(1), path, i, line, "v", fields))
    return tags

def strip_c_comments(text):
    return re.sub(r"/\*.*?\*/", lambda m: " " * (m.end() - m.start()), text, flags=re.S)

def parse_c(path, lines, lang="C"):
    tags = []
    text = strip_c_comments("".join(lines))
    clean_lines = text.splitlines()
    for i, line in enumerate(clean_lines, 1):
        s = line.strip()
        if not s or s.startswith("//"):
            continue
        m = re.match(r"#\s*define\s+([A-Za-z_][\w]*)", s)
        if m:
            tags.append(Tag(m.group(1), path, i, lines[i-1], "d", ["file:"]))
        for inc in re.finditer(r"#\s*include\s+[<\"]([^>\"]+)[>\"]", s):
            pass
        m = re.search(r"\benum\s+([A-Za-z_][\w]*)\s*\{([^}]*)\}", s)
        if m:
            en = m.group(1)
            tags.append(Tag(en, path, i, lines[i-1], "g", ["file:"]))
            for item in m.group(2).split(","):
                name = item.split("=")[0].strip()
                if is_identifier(name):
                    tags.append(Tag(name, path, i, lines[i-1], "e", [f"enum:{en}", "file:"]))
        m = re.search(r"\btypedef\s+(struct|union)\s+([A-Za-z_][\w]*)?\s*\{([^}]*)\}\s*([A-Za-z_][\w]*)", s)
        if m:
            kindword, inner, body, alias = m.group(1), m.group(2) or m.group(4), m.group(3), m.group(4)
            tags.append(Tag(inner, path, i, lines[i-1], "s" if kindword == "struct" else "u", ["file:"]))
            tags.append(Tag(alias, path, i, lines[i-1], "t", [f"typeref:{kindword}:{inner}", "file:"]))
            for typ, name in re.findall(r"\b([A-Za-z_][\w\s\*]*?)\s+([A-Za-z_][\w]*)\s*(?:;|:)", body):
                tags.append(Tag(name, path, i, lines[i-1], "m", [f"{kindword}:{inner}", f"typeref:typename:{typ.strip().replace(' ', ' ')}", "file:"]))
            continue
        m = re.search(r"\b(struct|union)\s+([A-Za-z_][\w]*)\s*\{", s)
        if m:
            tags.append(Tag(m.group(2), path, i, lines[i-1], "s" if m.group(1) == "struct" else "u", ["file:"]))
        if re.search(r"\)\s*(\{|$)", s) and not s.startswith(("if", "for", "while", "switch")):
            m = re.search(r"([A-Za-z_][\w\s\*\:&<>~,]*?)\s+([A-Za-z_~][\w~]*)\s*\([^;]*\)\s*(?:\{|$)", s)
            if m:
                name = m.group(2)
                typ = re.sub(r"\s+", " ", m.group(1).strip().replace("*", " *")).strip()
                if name not in ("if", "for", "while", "switch"):
                    fields = [] if s.endswith(";") else ([f"typeref:typename:{typ}"] if typ else [])
                    if not s.endswith(";"):
                        tags.append(Tag(name, path, i, lines[i-1], "f", fields))
        m = re.match(r"(?:static\s+|extern\s+|const\s+|unsigned\s+|signed\s+)*([A-Za-z_][\w\s\*]+?)\s+([A-Za-z_][\w]*)\s*(?:=|;)", s)
        if m and "(" not in s and not s.startswith("typedef"):
            typ = re.sub(r"\s+", " ", m.group(1).replace("*", " *")).strip()
            tags.append(Tag(m.group(2), path, i, lines[i-1], "v", [f"typeref:typename:{typ}", "file:"]))
    return tags

def parse_js(path, lines):
    tags, class_stack = [], []
    for i, line in enumerate(lines, 1):
        s = line.strip()
        m = re.search(r"\bclass\s+([A-Za-z_$][\w$]*)", s)
        if m:
            cls = m.group(1)
            tags.append(Tag(cls, path, i, line, "c", []))
            class_stack.append(cls)
            for mm in re.finditer(r"\b([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{", s):
                if mm.group(1) not in ("if", "for", "while", "switch", "function", cls):
                    tags.append(Tag(mm.group(1), path, i, line, "m", [f"class:{cls}"]))
        m = re.search(r"\bfunction\s+([A-Za-z_$][\w$]*)\s*\(", s)
        if m:
            tags.append(Tag(m.group(1), path, i, line, "f", []))
        for m in re.finditer(r"\b(const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>", s):
            tags.append(Tag(m.group(2), path, i, line, "f", []))
        for m in re.finditer(r"\b(const|let|var)\s+([A-Za-z_$][\w$]*)\b", s):
            if not any(t.name == m.group(2) and t.line == i for t in tags):
                tags.append(Tag(m.group(2), path, i, line, "C" if m.group(1) == "const" else "v", []))
        m = re.search(r"\binterface\s+([A-Za-z_$][\w$]*)", s)
        if m:
            tags.append(Tag(m.group(1), path, i, line, "i", []))
    return tags

def parse_markdown(path, lines):
    tags, heads = [], []
    kinds = {1: "c", 2: "s"}
    for i, line in enumerate(lines, 1):
        m = re.match(r"^(#{1,6})\s+(.+?)\s*#*\s*$", line.rstrip("\n"))
        if m:
            level = len(m.group(1))
            name = m.group(2)
            heads = heads[:level-1] + [name]
            fields = []
            if level > 1 and heads:
                parent_kind = "chapter" if level == 2 else "section"
                parent = '""'.join(heads[:-1])
                fields.append(f"{parent_kind}:{parent}")
            tags.append(Tag(name, path, i, line, kinds.get(level, "S"), fields))
    return tags

def parse_go(path, lines):
    tags = []
    for i, line in enumerate(lines, 1):
        s = line.strip()
        for pat, kind in [(r"^package\s+([A-Za-z_]\w*)", "p"), (r"^func\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)\s*\(", "f"),
                          (r"^type\s+([A-Za-z_]\w*)\s+", "t"), (r"^(?:var|const)\s+([A-Za-z_]\w*)\b", "v")]:
            m = re.match(pat, s)
            if m:
                tags.append(Tag(m.group(1), path, i, line, kind, []))
    return tags

def parse_java(path, lines):
    tags, current = [], None
    for i, line in enumerate(lines, 1):
        s = line.strip()
        m = re.search(r"\b(class|interface|enum)\s+([A-Za-z_]\w*)", s)
        if m:
            current = m.group(2)
            tags.append(Tag(current, path, i, line, {"class": "c", "interface": "i", "enum": "g"}[m.group(1)], []))
        m = re.search(r"(?:public|protected|private|static|final|synchronized|abstract|\s)+[\w<>\[\]]+\s+([A-Za-z_]\w*)\s*\([^;]*\)\s*\{?", s)
        if m and m.group(1) not in ("if", "for", "while", "switch"):
            fields = [f"class:{current}"] if current else []
            tags.append(Tag(m.group(1), path, i, line, "m", fields))
        m = re.search(r"(?:public|protected|private|static|final|\s)+[\w<>\[\]]+\s+([A-Za-z_]\w*)\s*(?:=|;)", s)
        if m and "(" not in s:
            fields = [f"class:{current}"] if current else []
            tags.append(Tag(m.group(1), path, i, line, "f", fields))
    return tags

def parse_ruby(path, lines):
    tags, stack = [], []
    for i, line in enumerate(lines, 1):
        s = line.strip()
        if s == "end" and stack:
            stack.pop()
        m = re.match(r"class\s+([A-Z]\w*(?:::\w+)*)", s)
        if m:
            tags.append(Tag(m.group(1), path, i, line, "c", [])); stack.append(m.group(1)); continue
        m = re.match(r"module\s+([A-Z]\w*(?:::\w+)*)", s)
        if m:
            tags.append(Tag(m.group(1), path, i, line, "m", [])); stack.append(m.group(1)); continue
        m = re.match(r"def\s+(?:self\.)?([A-Za-z_]\w*[!?=]?)", s)
        if m:
            fields = [f"class:{stack[-1]}"] if stack else []
            tags.append(Tag(m.group(1), path, i, line, "f", fields))
        m = re.match(r"([A-Z]\w*)\s*=", s)
        if m:
            tags.append(Tag(m.group(1), path, i, line, "C", []))
    return tags

def parse_sh(path, lines):
    tags = []
    for i, line in enumerate(lines, 1):
        s = line.strip()
        m = re.match(r"(?:function\s+)?([A-Za-z_][\w-]*)\s*\(\)\s*\{?", s)
        if m:
            tags.append(Tag(m.group(1), path, i, line, "f", []))
    return tags

PARSERS = {"Python": parse_python, "C": parse_c, "C++": parse_c, "JavaScript": parse_js, "TypeScript": parse_js,
           "Markdown": parse_markdown, "Go": parse_go, "Java": parse_java, "Ruby": parse_ruby, "Sh": parse_sh}

def parse_file(path, forced=None):
    lang = lang_for(path, forced)
    if not lang or lang not in PARSERS:
        return [], lang
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError as e:
        print(f'executable: Warning: cannot open input file "{path}" : {e.strerror}', file=sys.stderr)
        return [], lang
    parser = PARSERS[lang]
    return parser(path, lines) if lang not in ("C", "C++") else parser(path, lines, lang), lang

def format_tag(tag, opts):
    excmd = f"{tag.line};" if opts["excmd"] == "number" else f"/^{esc_pat(tag.text)}$/;\""
    if opts["excmd"] == "number":
        base = f"{tag.name}\t{tag.path}\t{excmd}\t{tag.kind}"
    else:
        base = f"{tag.name}\t{tag.path}\t{excmd}\t{tag.kind}"
    fields = list(tag.fields)
    if opts["line_field"]:
        fields.insert(0, f"line:{tag.line}")
    if fields:
        base += "\t" + "\t".join(fields)
    return base

def format_xref(tag):
    kind = KIND_NAMES.get(tag.kind, tag.kind)
    return f"{tag.name:<16} {kind:<10} {tag.line:4d} {tag.path:<16} {tag.text.strip()}"

def format_json(tag):
    obj = {"_type": "tag", "name": tag.name, "path": tag.path,
           "pattern": f"/^{esc_pat(tag.text)}$/", "kind": KIND_NAMES.get(tag.kind, tag.kind)}
    for f in tag.fields:
        if f.startswith("class:"):
            obj["scope"] = f.split(":", 1)[1]; obj["scopeKind"] = "class"
        elif f.startswith("struct:"):
            obj["scope"] = f.split(":", 1)[1]; obj["scopeKind"] = "struct"
        elif f.startswith("enum:"):
            obj["scope"] = f.split(":", 1)[1]; obj["scopeKind"] = "enum"
        elif f.startswith("nameref:"):
            obj["nameref"] = f.split(":", 1)[1]
    return json.dumps(obj)

def pseudo_header(langs):
    out = [
        "!_TAG_EXTRA_DESCRIPTION\tanonymous\t/Include tags for non-named objects like lambda/",
        "!_TAG_EXTRA_DESCRIPTION\tfileScope\t/Include tags of file scope/",
        "!_TAG_EXTRA_DESCRIPTION\tpseudo\t/Include pseudo tags/",
        "!_TAG_EXTRA_DESCRIPTION\tsubparser\t/Include tags generated by subparsers/",
        "!_TAG_FILE_FORMAT\t2\t/extended format; --format=1 will not append ;\" to lines/",
        "!_TAG_FILE_SORTED\t1\t/0=unsorted, 1=sorted, 2=foldcase/",
        "!_TAG_OUTPUT_EXCMD\tmixed\t/number, pattern, mixed, or combineV2/",
        "!_TAG_OUTPUT_FILESEP\tslash\t/slash or backslash/",
        "!_TAG_OUTPUT_MODE\tu-ctags\t/u-ctags or e-ctags/",
        "!_TAG_OUTPUT_VERSION\t1.1\t/current.age/",
        f"!_TAG_PROC_CWD\t{os.getcwd().rstrip('/')}/\t//",
        "!_TAG_PROGRAM_AUTHOR\tUniversal Ctags Team\t//",
        "!_TAG_PROGRAM_NAME\tUniversal Ctags\t/Derived from Exuberant Ctags/",
        "!_TAG_PROGRAM_URL\thttps://ctags.io/\t/official site/",
        "!_TAG_PROGRAM_VERSION\t6.2.0\t/d922013/",
    ]
    for lang in sorted(set(langs)):
        for letter, desc in KIND_TABLES.get(lang, []):
            if "[off]" not in desc:
                name = KIND_NAMES.get(letter, desc.split()[0].rstrip("s"))
                out.append(f"!_TAG_KIND_DESCRIPTION!{lang}\t{letter},{name}\t/{desc}/")
    return out

def list_output(kind, lang=None, header=True):
    if kind == "languages":
        return "\n".join(LANGUAGES) + "\n"
    if kind == "features":
        return "#NAME             DESCRIPTION\niconv             can convert input/output encodings\ninteractive       accepts source code from stdin\njson              supports json format output\noption-directory  TO BE WRITTEN\noptscript         can use the interpreter\npackcc            has peg based parser(s)\nregex             can use regular expression based pattern matching\nsandbox           linked with code for system call level sandbox\nwildcards         can use glob matching\nxpath             linked with library for parsing xml input\nyaml              linked with library for parsing yaml input\n"
    if kind == "output-formats":
        return "#OFORMAT DEFAULT AVAILABLE NULLTAG \ne-ctags       no       yes      no \netags         no       yes      no \njson          no       yes     yes \nu-ctags      yes       yes      no \nxref          no       yes     yes \n"
    if kind == "pseudo-tags":
        return "#NAME                     ENABLED VER DESCRIPTION\nTAG_FILE_FORMAT           on        0 the version of tags file format\nTAG_FILE_SORTED           on        0 how tags are sorted\nTAG_OUTPUT_MODE           on        0 the output mode: u-ctags or e-ctags\nTAG_OUTPUT_VERSION        on        0 the version of the output interface (current.age)\nTAG_PROGRAM_NAME          on        0 the name of this ctags implementation\nTAG_PROGRAM_URL           on        0 the official site URL of this ctags implementation\nTAG_PROGRAM_VERSION       on        0 the version of this ctags implementation\n"
    if kind == "fields":
        return "#LETTER NAME           ENABLED LANGUAGE         JSTYPE FIXED OP VER DESCRIPTION\nN       name           yes     NONE             s--    yes   rw   0 tag name\nF       input          yes     NONE             s--    yes   r-   0 input file\nP       pattern        yes     NONE             s-b    yes   --   0 pattern\nf       file           yes     NONE             --b    no    --   0 File-restricted scoping\nk       NONE           yes     NONE             s--    no    --   0 Kind of tag in one-letter form\nn       line           no      NONE             -i-    no    rw   0 Line number of tag definition\ns       NONE           yes     NONE             s--    no    --   0 scope of tag definition\n"
    if kind.startswith("map"):
        l = lang or "Python"
        maps = {"Python": "*.py *.pyx *.pxd *.pxi *.scons *.wsgi", "C": "*.c *.h", "C++": "*.c++ *.cc *.cpp *.cxx *.h++ *.hh *.hpp *.hxx", "JavaScript": "*.js *.jsx *.mjs", "TypeScript": "*.ts *.tsx", "Markdown": "*.md *.markdown"}
        if kind == "map-extensions":
            exts = [x[2:] for x in maps.get(l, "").split() if x.startswith("*.")]
            return ("#EXTENSION\n" if header else "") + "\n".join(exts) + ("\n" if exts else "")
        return f"{l:<8} {maps.get(l, '')}\n"
    if kind == "kinds":
        l = lang or "all"
        rows = []
        langs = KIND_TABLES.keys() if l == "all" else [l]
        for ll in langs:
            for letter, desc in KIND_TABLES.get(ll, []):
                rows.append(f"{letter}  {desc}")
        return "\n".join(rows) + ("\n" if rows else "")
    return ""

def collect_files(args, recurse=False, maxdepth=None, excludes=None, follow=True):
    files = []
    excludes = excludes or []
    def excluded(p):
        b = os.path.basename(p)
        return any(fnmatch.fnmatch(p, x) or fnmatch.fnmatch(b, x) for x in excludes)
    for p in args:
        if excluded(p):
            continue
        if os.path.isdir(p):
            if recurse:
                root_depth = p.rstrip(os.sep).count(os.sep)
                for root, dirs, names in os.walk(p, followlinks=follow):
                    if maxdepth is not None and root.count(os.sep) - root_depth >= maxdepth:
                        dirs[:] = []
                    dirs[:] = [d for d in dirs if not excluded(os.path.join(root, d))]
                    for n in names:
                        fp = os.path.join(root, n)
                        if not excluded(fp):
                            files.append(fp)
            else:
                print(f'executable: Warning: "{p}" is not a regular file', file=sys.stderr)
        else:
            files.append(p)
    return files

def parse_args(argv):
    opts = {"outfile": "tags", "stdout": False, "xref": False, "json": False, "sort": True, "append": False,
            "recurse": False, "maxdepth": None, "excmd": "pattern", "line_field": False, "forced": None,
            "print_language": False, "totals": False, "excludes": [], "follow": True, "filter": False}
    files, i = [], 0
    while i < len(argv):
        a = argv[i]
        if a in ("--help", "-?"): print(HELP_TEXT); sys.exit(0)
        if a.startswith("--version"): print(VERSION_TEXT); sys.exit(0)
        if a == "--license":
            print("Universal Ctags is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License.")
            sys.exit(0)
        if a.startswith("--list-languages"): print(list_output("languages"), end=""); sys.exit(0)
        if a.startswith("--list-features"): print(list_output("features"), end=""); sys.exit(0)
        if a.startswith("--list-output-formats"): print(list_output("output-formats"), end=""); sys.exit(0)
        if a.startswith("--list-pseudo-tags"): print(list_output("pseudo-tags"), end=""); sys.exit(0)
        if a.startswith("--list-fields"): print(list_output("fields"), end=""); sys.exit(0)
        if a.startswith("--list-kinds"):
            lang = a.split("=", 1)[1] if "=" in a else (argv[i+1] if i+1 < len(argv) and not argv[i+1].startswith("-") else "all")
            print(list_output("kinds", lang), end=""); sys.exit(0)
        if a.startswith("--list-maps"):
            lang = a.split("=", 1)[1] if "=" in a else "all"; print(list_output("maps", lang), end=""); sys.exit(0)
        if a.startswith("--list-map-extensions"):
            lang = a.split("=", 1)[1] if "=" in a else "all"; print(list_output("map-extensions", lang), end=""); sys.exit(0)
        if a in ("-f", "-o"):
            i += 1; opts["outfile"] = argv[i]; opts["stdout"] = opts["outfile"] == "-"
        elif a.startswith("-f") and len(a) > 2:
            opts["outfile"] = a[2:]; opts["stdout"] = opts["outfile"] == "-"
        elif a == "-x":
            opts["xref"] = True; opts["stdout"] = True
        elif a == "-R":
            opts["recurse"] = True
        elif a in ("-u",):
            opts["sort"] = False
        elif a == "-a":
            opts["append"] = True
        elif a == "-n":
            opts["excmd"] = "number"
        elif a == "-N":
            opts["excmd"] = "pattern"
        elif a == "-L":
            i += 1
            src = sys.stdin if argv[i] == "-" else open(argv[i], encoding="utf-8", errors="replace")
            with src:
                files.extend([x.strip() for x in src if x.strip()])
        elif a.startswith("--output-format="):
            val = a.split("=", 1)[1]
            opts["json"] = val == "json"; opts["xref"] = val == "xref"; opts["stdout"] = opts["stdout"] or val in ("json", "xref")
        elif a.startswith("--sort="):
            opts["sort"] = a.split("=", 1)[1] != "no"
        elif a.startswith("--recurse"):
            opts["recurse"] = "=" not in a or a.split("=", 1)[1] != "no"
        elif a.startswith("--append"):
            opts["append"] = "=" not in a or a.split("=", 1)[1] != "no"
        elif a.startswith("--filter"):
            opts["filter"] = "=" not in a or a.split("=", 1)[1] != "no"; opts["stdout"] = True
        elif a.startswith("--maxdepth="):
            try: opts["maxdepth"] = int(a.split("=", 1)[1])
            except ValueError: pass
        elif a.startswith("--exclude="):
            opts["excludes"].append(a.split("=", 1)[1])
        elif a.startswith("--links="):
            opts["follow"] = a.split("=", 1)[1] != "no"
        elif a.startswith("--excmd="):
            v = a.split("=", 1)[1]; opts["excmd"] = "number" if v == "number" else "pattern"
        elif a.startswith("--fields="):
            v = a.split("=", 1)[1]
            if "+n" in v or "*" in v: opts["line_field"] = True
        elif a.startswith("--language-force="):
            opts["forced"] = a.split("=", 1)[1]
        elif a == "--print-language":
            opts["print_language"] = True
        elif a.startswith("--totals"):
            opts["totals"] = "=" not in a or a.split("=", 1)[1] != "no"
        elif a.startswith("--") or (a.startswith("-") and a != "-"):
            pass
        else:
            files.append(a)
        i += 1
    if opts["filter"]:
        files.extend([x.strip() for x in sys.stdin if x.strip()])
    return opts, files

def main(argv):
    opts, file_args = parse_args(argv)
    files = collect_files(file_args, opts["recurse"], opts["maxdepth"], opts["excludes"], opts["follow"])
    if opts["print_language"]:
        for f in files:
            l = lang_for(f, opts["forced"]) or "NONE"
            print(f"{f}: {l}")
        return 0
    tags, langs, total_lines = [], [], 0
    for f in files:
        ts, lang = parse_file(f, opts["forced"])
        if lang: langs.append(lang)
        tags.extend(ts)
        try:
            total_lines += sum(1 for _ in open(f, "rb"))
        except OSError:
            pass
    if opts["sort"]:
        tags.sort(key=lambda t: (t.name, t.path, t.line))
    if opts["json"]:
        out_lines = [format_json(t) for t in tags]
    elif opts["xref"]:
        out_lines = [format_xref(t) for t in tags]
    else:
        out_lines = []
        if not opts["stdout"] and not opts["append"]:
            out_lines.extend(pseudo_header(langs))
            out_lines.sort()
        out_lines.extend(format_tag(t, opts) for t in tags)
    data = "\n".join(out_lines) + ("\n" if out_lines else "")
    if opts["stdout"]:
        sys.stdout.write(data)
    else:
        mode = "a" if opts["append"] else "w"
        with open(opts["outfile"], mode, encoding="utf-8") as f:
            f.write(data)
    if opts["totals"]:
        print(f"{len(files)} file, {total_lines} lines (0 kB) scanned in 0.0 seconds (0 kB/s)", file=sys.stderr)
        print(f"{len(tags)} tags added to tag file", file=sys.stderr)
        if opts["sort"]:
            print(f"{len(tags)} tags sorted in 0.00 seconds", file=sys.stderr)
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
