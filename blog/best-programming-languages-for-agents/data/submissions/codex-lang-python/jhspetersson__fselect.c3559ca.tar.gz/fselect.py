#!/usr/bin/env python3
import base64
import calendar
import csv
import fnmatch
import grp
import hashlib
import html
import json
import math
import mimetypes
import os
import pwd
import random
import re
import stat
import sys
import time
from datetime import datetime, date, timedelta
from io import StringIO


ARCHIVE_EXT = {".7z", ".bz2", ".bzip2", ".gz", ".gzip", ".lz", ".rar", ".tar", ".xz", ".zip"}
AUDIO_EXT = {".aac", ".aiff", ".amr", ".flac", ".gsm", ".m4a", ".m4b", ".m4p", ".mp3", ".ogg", ".wav", ".wma"}
BOOK_EXT = {".azw3", ".chm", ".djv", ".djvu", ".epub", ".fb2", ".mobi", ".pdf"}
DOC_EXT = {".accdb", ".doc", ".docm", ".docx", ".dot", ".dotm", ".dotx", ".mdb", ".odp", ".ods", ".odt", ".pdf", ".potm", ".potx", ".ppt", ".pptm", ".pptx", ".rtf", ".xlm", ".xls", ".xlsm", ".xlsx", ".xlt", ".xltm", ".xltx", ".xps"}
FONT_EXT = {".eot", ".fon", ".otc", ".otf", ".ttc", ".ttf", ".woff", ".woff2"}
IMAGE_EXT = {".bmp", ".exr", ".gif", ".heic", ".jpeg", ".jpg", ".jxl", ".png", ".psb", ".psd", ".svg", ".tga", ".tiff", ".webp"}
SOURCE_EXT = {".asm", ".awk", ".bas", ".c", ".cc", ".ceylon", ".clj", ".coffee", ".cpp", ".cs", ".d", ".dart", ".elm", ".erl", ".go", ".gradle", ".groovy", ".h", ".hh", ".hpp", ".java", ".jl", ".js", ".jsp", ".jsx", ".kt", ".kts", ".lua", ".nim", ".pas", ".php", ".pl", ".pm", ".py", ".rb", ".rs", ".scala", ".sol", ".swift", ".tcl", ".ts", ".tsx", ".vala", ".vb", ".zig"}
VIDEO_EXT = {".3gp", ".avi", ".flv", ".m4p", ".m4v", ".mkv", ".mov", ".mp4", ".mpeg", ".mpg", ".webm", ".wmv"}

BOOL_TRUE = {"true", "1", "yes", "on"}
BOOL_FALSE = {"false", "0", "no", "off"}
ZERO_ARG_FUNCS = {"pi", "current_date", "cur_date", "curdate", "current_time", "cur_time", "curtime",
                  "current_timestamp", "now", "current_uid", "current_gid", "current_user", "current_group"}
KNOWN_COLUMNS = {
    "name", "filename", "fname", "ext", "extension", "path", "abspath", "dir", "directory", "dirname", "absdir",
    "size", "fsize", "hsize", "uid", "gid", "user", "group", "created", "accessed", "modified", "atime", "mtime",
    "ctime", "is_dir", "is_file", "is_symlink", "is_pipe", "is_fifo", "is_char", "is_character", "is_block",
    "is_socket", "device", "rdev", "inode", "blocks", "hardlinks", "mode", "user_read", "user_write", "user_exec",
    "user_all", "user_rwx", "group_read", "group_write", "group_exec", "group_all", "group_rwx", "other_read",
    "other_write", "other_exec", "other_all", "other_rwx", "suid", "is_suid", "sgid", "is_sgid", "is_sticky",
    "sticky", "is_hidden", "is_empty", "has_xattrs", "xattr_count", "extattrs", "has_extattrs", "acl", "has_acl",
    "default_acl", "has_default_acl", "has_capabilities", "has_caps", "capabilities", "caps", "is_shebang",
    "width", "height", "duration", "mp3_bitrate", "bitrate", "mp3_freq", "freq", "mp3_title", "title",
    "mp3_artist", "artist", "mp3_album", "album", "mp3_year", "mp3_genre", "genre", "mime", "line_count",
    "is_binary", "is_text", "is_archive", "is_audio", "is_book", "is_doc", "is_font", "is_image", "is_source",
    "is_video", "sha1", "sha2_256", "sha256", "sha2_512", "sha512", "sha3_512", "sha3",
}


class FSelectError(Exception):
    pass


def print_help():
    print("""fselect 0.10.0
Find files with SQL-like queries.
https://github.com/jhspetersson/fselect

Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]

Format:
    tabs                            Tab-separated values (default)
    lines                           One item per line
    list                            Entire output onto a single line for xargs
    csv                             Comma-separated values
    json                            JSON format
    html                            HTML format
""")


def tokenize(s):
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            i += 1
            continue
        if c in ("'", '"', "`"):
            q = c
            j = i + 1
            val = ""
            while j < len(s):
                if s[j] == "\\" and j + 1 < len(s):
                    val += s[j + 1]
                    j += 2
                elif s[j] == q:
                    break
                else:
                    val += s[j]
                    j += 1
            out.append(("STR", val))
            i = j + 1 if j < len(s) else j
            continue
        three = s[i:i + 3]
        if three in ("!==", "!=~", "!~="):
            out.append(("SYM", three))
            i += 3
            continue
        two = s[i:i + 2]
        if two in ("==", "!=", "<=", ">=", "<>", "=~", "~="):
            out.append(("SYM", two))
            i += 2
            continue
        if c in "(),{}+-*/%<>=":
            out.append(("SYM", "(" if c == "{" else ")" if c == "}" else c))
            i += 1
            continue
        j = i
        while j < len(s) and not s[j].isspace() and s[j] not in "(),{}+-*/%<>=`'\"":
            if s[j:j + 2] in ("!=", "<=", ">=", "<>", "=~", "~="):
                break
            j += 1
        out.append(("WORD", s[i:j]))
        i = j
    return out


def token_text(tok):
    return tok[1]


def lower(tok):
    return tok[1].lower()


def find_keyword(tokens, words, start=0):
    words = [w.lower() for w in words]
    depth = 0
    for i in range(start, len(tokens)):
        t = token_text(tokens[i])
        if t == "(":
            depth += 1
        elif t == ")":
            depth -= 1
        if depth == 0 and i + len(words) <= len(tokens):
            if [lower(x) for x in tokens[i:i + len(words)]] == words:
                return i
    return -1


def split_top(tokens, sep=","):
    parts, cur, depth = [], [], 0
    for tok in tokens:
        txt = token_text(tok)
        if txt == "(":
            depth += 1
        elif txt == ")":
            depth -= 1
        if depth == 0 and txt == sep:
            if cur:
                parts.append(cur)
                cur = []
        else:
            cur.append(tok)
    if cur:
        parts.append(cur)
    return parts


def expr_to_string(tokens):
    s = ""
    prev_word = False
    prev_txt = ""
    for typ, txt in tokens:
        is_word = typ in ("WORD", "STR") or re.match(r"^[\w./~:-]+$", txt or "")
        tight_before = txt in ("/", ".", ")", ",")
        tight_after_prev = prev_txt in ("/", ".", "(", "")
        if s and prev_word and is_word and not tight_before and not tight_after_prev:
            s += " "
        if typ == "STR":
            s += txt
        else:
            s += txt
        prev_word = is_word
        prev_txt = txt
    return s


def parse_query(argv):
    args = []
    i = 0
    opts = {"errors": True}
    while i < len(argv):
        a = argv[i]
        if a in ("--help", "-h", "/?", "/h"):
            return {"help": True}
        if a in ("--interactive", "-i", "/i"):
            return {"interactive": True}
        if a in ("--nocolor", "--no-color", "/nocolor", "--us-dates"):
            i += 1
            continue
        if a == "--no-errors":
            opts["errors"] = False
            i += 1
            continue
        if a in ("--config", "-c", "/config"):
            i += 2
            continue
        args.append(a)
        i += 1
    q = " ".join(args).strip()
    if not q:
        raise FSelectError("No columns specified")
    tokens = tokenize(q)
    if tokens and lower(tokens[0]) == "select":
        tokens = tokens[1:]
    into_i = find_keyword(tokens, ["into"])
    fmt = "tabs"
    if into_i >= 0:
        if into_i + 1 < len(tokens):
            fmt = lower(tokens[into_i + 1])
        tokens = tokens[:into_i]
    limit_i = find_keyword(tokens, ["limit"])
    limit = None
    if limit_i >= 0:
        if limit_i + 1 < len(tokens):
            try:
                limit = int(token_text(tokens[limit_i + 1]))
            except ValueError:
                limit = 0
        tokens = tokens[:limit_i] + tokens[limit_i + 2:]
    offset_i = find_keyword(tokens, ["offset"])
    offset = 0
    if offset_i >= 0:
        if offset_i + 1 < len(tokens):
            try:
                offset = int(token_text(tokens[offset_i + 1]))
            except ValueError:
                offset = 0
        tokens = tokens[:offset_i] + tokens[offset_i + 2:]
    order_i = find_keyword(tokens, ["order", "by"])
    order = []
    if order_i >= 0:
        order = split_top(tokens[order_i + 2:])
        tokens = tokens[:order_i]
    group_i = find_keyword(tokens, ["group", "by"])
    group = []
    if group_i >= 0:
        group = split_top(tokens[group_i + 2:])
        tokens = tokens[:group_i]
    where_i = find_keyword(tokens, ["where"])
    where = []
    if where_i >= 0:
        where = tokens[where_i + 1:]
        tokens = tokens[:where_i]
    from_i = find_keyword(tokens, ["from"])
    roots = [[("WORD", ".")]]
    columns = tokens
    if from_i >= 0:
        columns = tokens[:from_i]
        roots = split_top(tokens[from_i + 1:]) or roots
    cols = split_top(columns)
    return {"help": False, "interactive": False, "columns": cols, "roots": roots, "where": where,
            "group": group, "order": order, "limit": limit, "offset": offset, "format": fmt, **opts}


def root_specs(root_tokens):
    specs = []
    for part in root_tokens:
        if not part:
            continue
        path_tokens = []
        opts = {"follow": False, "min": 0, "max": None, "dfs": False}
        i = 0
        while i < len(part):
            w = lower(part[i])
            if w in ("mindepth",):
                opts["min"] = int(token_text(part[i + 1])); i += 2
            elif w in ("maxdepth", "depth"):
                opts["max"] = int(token_text(part[i + 1])); i += 2
            elif w in ("symlinks", "sym"):
                opts["follow"] = True; i += 1
            elif w in ("dfs",):
                opts["dfs"] = True; i += 1
            elif w in ("bfs", "archives", "arc", "gitignore", "git", "nogitignore", "nogit",
                       "hgignore", "hg", "nohgignore", "nohg", "dockerignore", "docker",
                       "nodockerignore", "nodocker", "regexp", "rx"):
                i += 1
            elif w == "as":
                break
            else:
                path_tokens.append(part[i]); i += 1
        p = expr_to_string(path_tokens).strip() or "."
        p = os.path.expanduser(p)
        specs.append((p, opts))
    return specs or [(".", {"follow": False, "min": 0, "max": None, "dfs": False})]


class Row:
    def __init__(self, root, path, st, lst):
        self.root = os.path.abspath(root)
        self.abspath = os.path.abspath(path)
        self.relpath = os.path.relpath(self.abspath, self.root)
        if self.relpath == ".":
            self.relpath = os.path.basename(self.abspath)
        self.st = st
        self.lst = lst
        self._cache = {}

    def col(self, name):
        n = name.lower()
        aliases = {
            "fname": "filename", "extension": "ext", "directory": "dir", "dirname": "dir",
            "hsize": "fsize", "is_fifo": "is_pipe", "is_character": "is_char",
            "user_rwx": "user_all", "group_rwx": "group_all", "other_rwx": "other_all",
            "is_suid": "suid", "is_sgid": "sgid", "sticky": "is_sticky",
            "sha2_256": "sha256", "sha2_512": "sha512", "sha3": "sha3_512",
            "bitrate": "mp3_bitrate", "freq": "mp3_freq", "title": "mp3_title",
            "artist": "mp3_artist", "album": "mp3_album", "genre": "mp3_genre",
        }
        n = aliases.get(n, n)
        if n in self._cache:
            return self._cache[n]
        base = os.path.basename(self.abspath)
        root, ext = os.path.splitext(base)
        extl = ext.lower()
        mode = self.lst.st_mode
        val = ""
        try:
            if n == "name": val = base
            elif n == "filename": val = root
            elif n == "ext": val = ext[1:] if ext else ""
            elif n == "path": val = self.relpath
            elif n == "abspath": val = self.abspath
            elif n == "dir":
                d = os.path.dirname(self.relpath)
                val = "" if d == "." else d
            elif n == "absdir": val = os.path.dirname(self.abspath)
            elif n == "size": val = self.st.st_size
            elif n == "fsize": val = format_size(self.st.st_size)
            elif n == "uid": val = self.st.st_uid
            elif n == "gid": val = self.st.st_gid
            elif n == "user": val = pwd.getpwuid(self.st.st_uid).pw_name
            elif n == "group": val = grp.getgrgid(self.st.st_gid).gr_name
            elif n == "accessed": val = fmt_time(self.st.st_atime)
            elif n == "modified": val = fmt_time(self.st.st_mtime)
            elif n == "created": val = fmt_time(getattr(self.st, "st_birthtime", self.st.st_ctime))
            elif n == "atime": val = int(self.st.st_atime)
            elif n == "mtime": val = int(self.st.st_mtime)
            elif n == "ctime": val = int(self.st.st_ctime)
            elif n == "is_dir": val = stat.S_ISDIR(mode)
            elif n == "is_file": val = stat.S_ISREG(mode)
            elif n == "is_symlink": val = stat.S_ISLNK(self.lst.st_mode)
            elif n == "is_pipe": val = stat.S_ISFIFO(mode)
            elif n == "is_char": val = stat.S_ISCHR(mode)
            elif n == "is_block": val = stat.S_ISBLK(mode)
            elif n == "is_socket": val = stat.S_ISSOCK(mode)
            elif n == "device": val = self.st.st_dev
            elif n == "rdev": val = self.st.st_rdev
            elif n == "inode": val = self.st.st_ino
            elif n == "blocks": val = getattr(self.st, "st_blocks", 0) * 2
            elif n == "hardlinks": val = self.st.st_nlink
            elif n == "mode": val = stat.filemode(self.lst.st_mode)
            elif n == "user_read": val = bool(mode & stat.S_IRUSR)
            elif n == "user_write": val = bool(mode & stat.S_IWUSR)
            elif n == "user_exec": val = bool(mode & stat.S_IXUSR)
            elif n == "user_all": val = bool((mode & 0o700) == 0o700)
            elif n == "group_read": val = bool(mode & stat.S_IRGRP)
            elif n == "group_write": val = bool(mode & stat.S_IWGRP)
            elif n == "group_exec": val = bool(mode & stat.S_IXGRP)
            elif n == "group_all": val = bool((mode & 0o070) == 0o070)
            elif n == "other_read": val = bool(mode & stat.S_IROTH)
            elif n == "other_write": val = bool(mode & stat.S_IWOTH)
            elif n == "other_exec": val = bool(mode & stat.S_IXOTH)
            elif n == "other_all": val = bool((mode & 0o007) == 0o007)
            elif n == "suid": val = bool(mode & stat.S_ISUID)
            elif n == "sgid": val = bool(mode & stat.S_ISGID)
            elif n == "is_sticky": val = bool(mode & stat.S_ISVTX)
            elif n == "is_hidden": val = base.startswith(".")
            elif n == "is_empty": val = is_empty(self.abspath, self.st)
            elif n == "is_shebang": val = starts_with(self.abspath, b"#!")
            elif n == "mime": val = mimetypes.guess_type(self.abspath)[0] or "application/octet-stream"
            elif n == "is_binary": val = is_binary(self.abspath)
            elif n == "is_text": val = not is_binary(self.abspath) if stat.S_ISREG(mode) else False
            elif n == "line_count": val = line_count(self.abspath) if (stat.S_ISREG(mode) or stat.S_ISLNK(self.lst.st_mode)) else ""
            elif n == "is_archive": val = extl in ARCHIVE_EXT
            elif n == "is_audio": val = extl in AUDIO_EXT
            elif n == "is_book": val = extl in BOOK_EXT
            elif n == "is_doc": val = extl in DOC_EXT
            elif n == "is_font": val = extl in FONT_EXT
            elif n == "is_image": val = extl in IMAGE_EXT
            elif n == "is_source": val = extl in SOURCE_EXT
            elif n == "is_video": val = extl in VIDEO_EXT
            elif n in ("sha1", "sha256", "sha512", "sha3_512"): val = digest(self.abspath, n)
            elif n in ("width", "height"): val = image_dim(self.abspath, n)
            elif n in ("has_xattrs", "xattr_count", "has_extattrs", "has_acl", "has_default_acl", "has_capabilities"):
                val = False if n != "xattr_count" else 0
            elif n in ("extattrs", "acl", "default_acl", "capabilities"):
                val = ""
            else:
                val = ""
        except Exception:
            val = ""
        self._cache[n] = val
        return val


def fmt_time(ts):
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


def format_size(n):
    n = int(n)
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    v = float(n)
    u = 0
    while abs(v) >= 1024 and u < len(units) - 1:
        v /= 1024.0; u += 1
    if u == 0:
        return f"{n}B"
    return f"{int(v) if v.is_integer() else round(v, 1)}{units[u]}"


def is_empty(path, st):
    if stat.S_ISDIR(st.st_mode):
        try:
            return len(os.listdir(path)) == 0
        except Exception:
            return False
    return st.st_size == 0


def starts_with(path, prefix):
    try:
        with open(path, "rb") as f:
            return f.read(len(prefix)) == prefix
    except Exception:
        return False


def is_binary(path):
    try:
        with open(path, "rb") as f:
            data = f.read(4096)
        if b"\0" in data:
            return True
        if not data:
            return False
        text = sum(1 for b in data if b in b"\n\r\t\b\f" or 32 <= b < 127)
        return text / len(data) < 0.80
    except Exception:
        return False


def line_count(path):
    try:
        with open(path, "rb") as f:
            return f.read().count(b"\n")
    except Exception:
        return 0


def digest(path, kind):
    try:
        h = {"sha1": hashlib.sha1, "sha256": hashlib.sha256,
             "sha512": hashlib.sha512, "sha3_512": hashlib.sha3_512}[kind]()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ""


def image_dim(path, which):
    try:
        with open(path, "rb") as f:
            data = f.read(64)
        if data.startswith(b"\x89PNG\r\n\x1a\n"):
            w = int.from_bytes(data[16:20], "big"); h = int.from_bytes(data[20:24], "big")
            return w if which == "width" else h
        if data[:6] in (b"GIF87a", b"GIF89a"):
            w = int.from_bytes(data[6:8], "little"); h = int.from_bytes(data[8:10], "little")
            return w if which == "width" else h
    except Exception:
        pass
    return ""


def walk_rows(specs):
    for root, opts in specs:
        if not os.path.exists(root) and not os.path.islink(root):
            continue
        root_abs = os.path.abspath(root)
        if os.path.isfile(root_abs) or os.path.islink(root_abs):
            yield make_row(root_abs, root_abs, opts["follow"])
            continue
        if opts.get("dfs"):
            for dirpath, dirs, files in os.walk(root_abs, followlinks=opts["follow"], topdown=False):
                for name in sorted(dirs) + sorted(files):
                    p = os.path.join(dirpath, name)
                    depth = rel_depth(root_abs, p)
                    if depth >= opts["min"] and (opts["max"] is None or depth <= opts["max"]):
                        r = make_row(root_abs, p, opts["follow"])
                        if r: yield r
        else:
            queue = [root_abs]
            while queue:
                d = queue.pop(0)
                try:
                    entries = list(os.scandir(d))
                except Exception:
                    continue
                dirs = []
                nondirs = []
                for e in entries:
                    try:
                        isdir = e.is_dir(follow_symlinks=opts["follow"])
                    except Exception:
                        isdir = False
                    (dirs if isdir else nondirs).append(e)
                for e in nondirs + dirs:
                    p = e.path
                    depth = rel_depth(root_abs, p)
                    if depth >= opts["min"] and (opts["max"] is None or depth <= opts["max"]):
                        r = make_row(root_abs, p, opts["follow"])
                        if r: yield r
                    if e in dirs and (opts["max"] is None or depth < opts["max"]):
                        if opts["follow"] or not e.is_symlink():
                            queue.append(p)


def rel_depth(root, path):
    rel = os.path.relpath(path, root)
    return 1 if rel == "." else rel.count(os.sep) + 1


def make_row(root, path, follow):
    try:
        lst = os.lstat(path)
        st = os.stat(path) if follow or not stat.S_ISLNK(lst.st_mode) else lst
        return Row(root, path, st, lst)
    except Exception:
        return None


def eval_expr(tokens, row=None, group=None):
    tokens = trim_parens(tokens)
    if not tokens:
        return ""
    if len(tokens) == 1:
        typ, txt = tokens[0]
        if typ == "STR":
            return txt
        if re.fullmatch(r"-?\d+(\.\d+)?", txt):
            return float(txt) if "." in txt else int(txt)
        if txt.lower() in ZERO_ARG_FUNCS:
            return call_func(txt, [], row, group)
        if row is not None and txt.lower() in KNOWN_COLUMNS:
            return row.col(txt)
        return txt
    if len(tokens) >= 3 and token_text(tokens[1]) in ("+", "-", "*", "/", "%", "plus", "minus", "mul", "div", "mod"):
        return eval_arith(tokens, row, group)
    if len(tokens) >= 3 and token_text(tokens[1]) == ".":
        return eval_expr(tokens[2:], row, group)
    if len(tokens) >= 3 and token_text(tokens[1]) == "(" and token_text(tokens[-1]) == ")":
        fname = lower(tokens[0])
        args = split_top(tokens[2:-1])
        return call_func(fname, args, row, group)
    txt = expr_to_string(tokens)
    if row is not None and txt.lower() in KNOWN_COLUMNS and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", txt):
        return row.col(txt)
    return txt


def trim_parens(tokens):
    while len(tokens) >= 2 and token_text(tokens[0]) == "(" and token_text(tokens[-1]) == ")":
        depth = 0; ok = True
        for i, t in enumerate(tokens):
            if token_text(t) == "(": depth += 1
            elif token_text(t) == ")": depth -= 1
            if depth == 0 and i != len(tokens) - 1:
                ok = False; break
        if ok: tokens = tokens[1:-1]
        else: break
    return tokens


def eval_arith(tokens, row, group):
    vals, ops, cur, depth = [], [], [], 0
    for tok in tokens + [("SYM", "+")]:
        txt = token_text(tok)
        if txt == "(": depth += 1
        elif txt == ")": depth -= 1
        if depth == 0 and txt in ("+", "-", "*", "/", "%", "plus", "minus", "mul", "div", "mod"):
            if cur:
                vals.append(to_num(eval_expr(cur, row, group))); cur = []
            ops.append(txt)
        else:
            cur.append(tok)
    res = vals[0] if vals else 0
    for op, val in zip(ops, vals[1:]):
        if op in ("+", "plus"): res += val
        elif op in ("-", "minus"): res -= val
        elif op in ("*", "mul"): res *= val
        elif op in ("/", "div"): res = res / val if val else 0
        elif op in ("%", "mod"): res = res % val if val else 0
    return int(res) if isinstance(res, float) and res.is_integer() else res


def call_func(fname, args, row, group):
    vals = [eval_expr(a, row, group) for a in args]
    up = fname.upper()
    if up in ("COUNT",):
        return len(group or ([] if row is None else [row]))
    if up in ("MIN", "MAX", "SUM", "AVG", "STDDEV_POP", "STDDEV", "STD", "STDDEV_SAMP", "VAR_POP", "VARIANCE", "VAR_SAMP"):
        rs = group or ([] if row is None else [row])
        nums = [eval_expr(args[0], r, None) for r in rs] if args else []
        nums2 = [to_num(x) for x in nums if x != ""]
        if not nums2: return ""
        if up == "MIN": return min(nums)
        if up == "MAX": return max(nums)
        if up == "SUM": return sum(nums2)
        if up == "AVG": return sum(nums2) / len(nums2)
        mean = sum(nums2) / len(nums2)
        var = sum((x - mean) ** 2 for x in nums2) / (len(nums2) if "SAMP" not in up else max(1, len(nums2) - 1))
        if up.startswith("STD"): return math.sqrt(var)
        return var
    svals = ["" if v is None else str(v) for v in vals]
    if up in ("LOWER", "LOWERCASE", "LCASE"): return svals[0].lower() if svals else ""
    if up in ("UPPER", "UPPERCASE", "UCASE"): return svals[0].upper() if svals else ""
    if up == "INITCAP": return svals[0].title() if svals else ""
    if up in ("LENGTH", "LEN"): return len(svals[0]) if svals else 0
    if up in ("TO_BASE64", "BASE64"): return base64.b64encode(svals[0].encode()).decode() if svals else ""
    if up == "FROM_BASE64":
        try: return base64.b64decode(svals[0]).decode()
        except Exception: return ""
    if up == "CONCAT": return "".join(svals)
    if up == "CONCAT_WS": return svals[0].join(svals[1:]) if svals else ""
    if up in ("LOCATE", "POSITION"): return (svals[1].find(svals[0]) + 1) if len(svals) >= 2 else 0
    if up in ("SUBSTR", "SUBSTRING"):
        if not svals: return ""
        start = int(to_num(vals[1])) - 1 if len(vals) > 1 else 0
        ln = int(to_num(vals[2])) if len(vals) > 2 else None
        return svals[0][start:] if ln is None else svals[0][start:start + ln]
    if up == "REPLACE": return svals[0].replace(svals[1], svals[2]) if len(svals) >= 3 else (svals[0] if svals else "")
    if up == "TRIM": return svals[0].strip() if svals else ""
    if up == "LTRIM": return svals[0].lstrip() if svals else ""
    if up == "RTRIM": return svals[0].rstrip() if svals else ""
    if up == "BIN": return bin(int(to_num(vals[0])))[2:] if vals else ""
    if up == "HEX": return hex(int(to_num(vals[0])))[2:] if vals else ""
    if up == "OCT": return oct(int(to_num(vals[0])))[2:] if vals else ""
    if up == "ABS": return abs(to_num(vals[0])) if vals else 0
    if up in ("POWER", "POW"): return math.pow(to_num(vals[0]), to_num(vals[1])) if len(vals) >= 2 else ""
    if up == "SQRT": return math.sqrt(to_num(vals[0])) if vals else ""
    if up == "LOG": return math.log(to_num(vals[0]), to_num(vals[1])) if len(vals) >= 2 else math.log10(to_num(vals[0]))
    if up == "LN": return math.log(to_num(vals[0])) if vals else ""
    if up == "EXP": return math.exp(to_num(vals[0])) if vals else ""
    if up == "LEAST": return min(vals) if vals else ""
    if up == "GREATEST": return max(vals) if vals else ""
    if up == "PI": return math.pi
    if up == "FLOOR": return math.floor(to_num(vals[0])) if vals else ""
    if up in ("CEIL", "CEILING"): return math.ceil(to_num(vals[0])) if vals else ""
    if up == "ROUND": return round(to_num(vals[0]), int(to_num(vals[1])) if len(vals) > 1 else 0) if vals else ""
    if up in ("RAND", "RANDOM"):
        if len(vals) >= 2: return random.uniform(to_num(vals[0]), to_num(vals[1]))
        return random.uniform(0, to_num(vals[0]) if vals else 1)
    if up in ("FORMAT_SIZE", "FORMAT_FILESIZE"): return format_size(to_num(vals[0])) if vals else ""
    if up in ("CURRENT_DATE", "CUR_DATE", "CURDATE"): return date.today().isoformat()
    if up in ("CURRENT_TIME", "CUR_TIME", "CURTIME"): return datetime.now().strftime("%H:%M:%S")
    if up in ("CURRENT_TIMESTAMP", "NOW"): return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if up == "YEAR": return parse_dt(svals[0]).year if svals else ""
    if up == "MONTH": return parse_dt(svals[0]).month if svals else ""
    if up == "DAY": return parse_dt(svals[0]).day if svals else ""
    if up in ("DAYOFWEEK", "DOW"): return parse_dt(svals[0]).isoweekday() if svals else ""
    if up == "DAYNAME": return calendar.day_name[parse_dt(svals[0]).weekday()] if svals else ""
    if up in ("DAYOFYEAR", "DOY"): return parse_dt(svals[0]).timetuple().tm_yday if svals else ""
    if up in ("CURRENT_UID",): return os.getuid()
    if up in ("CURRENT_GID",): return os.getgid()
    if up in ("CURRENT_USER",): return pwd.getpwuid(os.getuid()).pw_name
    if up in ("CURRENT_GROUP",): return grp.getgrgid(os.getgid()).gr_name
    if up == "COALESCE":
        for v in vals:
            if v not in ("", None): return v
        return ""
    if up == "CONTAINS" and row is not None and vals:
        try:
            with open(row.abspath, "rb") as f:
                return vals[0].encode() in f.read()
        except Exception:
            return False
    return ""


def to_num(v):
    if isinstance(v, bool): return 1 if v else 0
    if isinstance(v, (int, float)): return v
    s = str(v).strip()
    m = re.fullmatch(r"(-?\d+(?:\.\d+)?)([kmgt]i?b?|b)?", s, re.I)
    if m:
        n = float(m.group(1)); unit = (m.group(2) or "").lower()
        mult = {"k": 1024, "kb": 1024, "kib": 1024, "m": 1024**2, "mb": 1024**2, "mib": 1024**2,
                "g": 1024**3, "gb": 1024**3, "gib": 1024**3, "t": 1024**4, "tb": 1024**4, "tib": 1024**4,
                "b": 1}.get(unit, 1)
        return n * mult
    return 0


def parse_dt(s):
    s = str(s)
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%d/%m/%Y", "%d/%m"):
        try:
            d = datetime.strptime(s, fmt)
            if fmt == "%d/%m":
                d = d.replace(year=datetime.now().year)
            return d
        except Exception:
            pass
    return datetime.fromtimestamp(to_num(s))


def where_ok(tokens, row):
    if not tokens:
        return True
    return eval_bool(tokens, row)


def eval_bool(tokens, row):
    tokens = trim_parens(tokens)
    idx = find_bool_op(tokens, "or")
    if idx >= 0:
        return eval_bool(tokens[:idx], row) or eval_bool(tokens[idx + 1:], row)
    idx = find_bool_op(tokens, "and")
    if idx >= 0:
        return eval_bool(tokens[:idx], row) and eval_bool(tokens[idx + 1:], row)
    if tokens and lower(tokens[0]) == "not":
        return not eval_bool(tokens[1:], row)
    for ops in (["not", "in"], ["not", "like"]):
        idx = find_keyword(tokens, ops)
        if idx >= 0:
            return not compare_values(eval_expr(tokens[:idx], row), ops[-1], tokens[idx + len(ops):], row)
    idx = find_keyword(tokens, ["between"])
    if idx >= 0:
        and_i = find_keyword(tokens, ["and"], idx + 1)
        v = to_num(eval_expr(tokens[:idx], row))
        a = to_num(eval_expr(tokens[idx + 1:and_i], row))
        b = to_num(eval_expr(tokens[and_i + 1:], row))
        return a <= v <= b
    for i, tok in enumerate(tokens):
        op = lower(tok)
        if op in ("=", "==", "eq", "===", "eeq", "!=", "<>", "ne", "!==", "ene", "<", "lt", "<=", "lte", "le", ">", "gt", ">=", "gte", "ge", "=~", "~=", "regexp", "rx", "!=~", "!~=", "notrx", "like", "in"):
            return compare_values(eval_expr(tokens[:i], row), op, tokens[i + 1:], row)
    return truthy(eval_expr(tokens, row))


def find_bool_op(tokens, word):
    depth = 0
    for i in range(len(tokens) - 1, -1, -1):
        txt = token_text(tokens[i])
        if txt == ")": depth += 1
        elif txt == "(": depth -= 1
        elif depth == 0 and lower(tokens[i]) == word:
            return i
    return -1


def compare_values(left, op, right_tokens, row):
    op = op.lower()
    right = eval_expr(trim_parens(right_tokens), row)
    if op in ("in",):
        parts = split_top(trim_parens(right_tokens))
        vals = [eval_expr(p, row) for p in parts] if len(parts) > 1 else [right]
        return any(str(left) == str(v) for v in vals)
    if op in ("like",):
        return re.fullmatch(sql_like_to_re(str(right)), str(left), flags=re.S) is not None
    if op in ("=~", "~=", "regexp", "rx"):
        try: return re.search(str(right), str(left)) is not None
        except re.error: return False
    if op in ("!=~", "!~=", "notrx"):
        try: return re.search(str(right), str(left)) is None
        except re.error: return True
    if op in ("=", "==", "eq"):
        if has_glob(str(right)):
            return fnmatch.fnmatch(str(left), str(right))
        return norm(left) == norm(right)
    if op in ("===", "eeq"):
        return str(left) == str(right)
    if op in ("!=", "<>", "ne"):
        if has_glob(str(right)):
            return not fnmatch.fnmatch(str(left), str(right))
        return norm(left) != norm(right)
    if op in ("!==", "ene"):
        return str(left) != str(right)
    lnum, rnum = to_num(left), to_num(right)
    if op in ("<", "lt"): return lnum < rnum
    if op in ("<=", "lte", "le"): return lnum <= rnum
    if op in (">", "gt"): return lnum > rnum
    if op in (">=", "gte", "ge"): return lnum >= rnum
    return False


def norm(v):
    if isinstance(v, bool): return "true" if v else "false"
    s = str(v)
    if s.lower() in BOOL_TRUE: return "true"
    if s.lower() in BOOL_FALSE: return "false"
    return s


def truthy(v):
    if isinstance(v, bool): return v
    if isinstance(v, (int, float)): return v != 0
    return str(v).lower() in BOOL_TRUE


def has_glob(s):
    return any(c in s for c in "*?[")


def sql_like_to_re(p):
    out = ""
    for c in p:
        if c == "%": out += ".*"
        elif c == "_": out += "."
        else: out += re.escape(c)
    return out


def label_for(expr):
    if len(expr) == 1:
        return token_text(expr[0]).capitalize()
    return expr_to_string(expr)


def value_str(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def run_query(argv):
    q = parse_query(argv)
    if q.get("help"):
        print_help(); return 0
    if q.get("interactive"):
        return interactive()
    specs = root_specs(q["roots"])
    rows = [r for r in walk_rows(specs) if where_ok(q["where"], r)]
    if q["group"]:
        groups = {}
        for r in rows:
            key = tuple(value_str(eval_expr(g, r)) for g in q["group"])
            groups.setdefault(key, []).append(r)
        out_rows = [(None, g) for g in groups.values()]
    elif any(is_aggregate(c) for c in q["columns"]):
        out_rows = [(None, rows)]
    else:
        out_rows = [(r, None) for r in rows]
    if q["order"]:
        for part in reversed(q["order"]):
            desc = bool(part and lower(part[-1]) == "desc")
            expr = part[:-1] if desc or (part and lower(part[-1]) == "asc") else part
            out_rows.sort(key=lambda rg, e=expr: one_order_key(e, q["columns"], rg[0], rg[1]), reverse=desc)
    start = max(0, q["offset"])
    end = None if q["limit"] is None else start + max(0, q["limit"])
    out_rows = out_rows[start:end]
    matrix = [[value_str(eval_expr(c, r if r is not None else (g[0] if g else None), g)) for c in q["columns"]] for r, g in out_rows]
    emit(matrix, [label_for(c) for c in q["columns"]], q["format"])
    return 0


def is_aggregate(c):
    return len(c) >= 2 and lower(c[0]) in {"count", "min", "max", "avg", "sum", "stddev_pop", "stddev", "std", "stddev_samp", "var_pop", "variance", "var_samp"}


def one_order_key(part, cols, row, group):
    if len(part) == 1 and re.fullmatch(r"\d+", token_text(part[0])):
        idx = int(token_text(part[0])) - 1
        val = eval_expr(cols[idx], row if row is not None else (group[0] if group else None), group) if 0 <= idx < len(cols) else ""
    else:
        val = eval_expr(part, row if row is not None else (group[0] if group else None), group)
    return (0, to_num(val)) if str(val).lstrip("-").replace(".", "", 1).isdigit() else (1, str(val))


def emit(matrix, labels, fmt):
    if fmt == "json":
        arr = []
        for row in matrix:
            arr.append({labels[i]: row[i] for i in range(len(labels))})
        sys.stdout.write(json.dumps(arr, separators=(",", ":")))
    elif fmt == "csv":
        sio = StringIO()
        w = csv.writer(sio, lineterminator="\n")
        w.writerows(matrix)
        sys.stdout.write(sio.getvalue())
    elif fmt == "lines":
        for row in matrix:
            for v in row:
                print(v)
    elif fmt == "list":
        sys.stdout.write("\0".join(v for row in matrix for v in row))
        if matrix:
            sys.stdout.write("\0")
    elif fmt == "html":
        print("<!DOCTYPE html><html><body><table>")
        for row in matrix:
            print("<tr>" + "".join(f"<td>{html.escape(v)}</td>" for v in row) + "</tr>")
        print("</table></body></html>")
    else:
        for row in matrix:
            print("\t".join(row))


def interactive():
    while True:
        try:
            line = input("> ")
        except (EOFError, KeyboardInterrupt):
            break
        cmd = line.strip()
        if cmd in ("exit", "quit"):
            break
        if cmd == "pwd":
            print(os.getcwd()); continue
        if cmd.startswith("cd "):
            try: os.chdir(os.path.expanduser(cmd[3:].strip()))
            except Exception as e: print(e, file=sys.stderr)
            continue
        if cmd == "help":
            print_help(); continue
        if cmd:
            try: run_query([cmd])
            except Exception as e: print(e, file=sys.stderr)
    return 0


def main():
    try:
        return run_query(sys.argv[1:])
    except FSelectError as e:
        print(str(e), file=sys.stderr)
        return 2
    except BrokenPipeError:
        return 0
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
