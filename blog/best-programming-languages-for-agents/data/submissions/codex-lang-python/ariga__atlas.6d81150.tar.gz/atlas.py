#!/usr/bin/env python3
import base64
import glob
import hashlib
import os
import re
import sqlite3
import sys
import time
from pathlib import Path
from urllib.parse import urlparse, unquote


ROOT_HELP = """Manage your database schema as code

Usage:
  atlas [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  help        Help about any command
  license     Display license information
  migrate     Manage versioned migration files
  schema      Work with atlas schemas.
  version     Prints this Atlas CLI version information.

Flags:
  -h, --help   help for atlas

Use "atlas [command] --help" for more information about a command.
"""

SCHEMA_HELP = """The `atlas schema` command groups subcommands working with declarative Atlas schemas.

Usage:
  atlas schema [command]

Available Commands:
  apply       Apply an atlas schema to a target database.
  clean       Removes all objects from the connected database.
  diff        Calculate and print the diff between two schemas.
  fmt         Formats Atlas HCL files
  inspect     Inspect a database and print its schema in Atlas DDL syntax.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for schema
      --var <name>=<value>   input variables (default [])

Use "atlas schema [command] --help" for more information about a command.
"""

MIGRATE_HELP = """'atlas migrate' wraps several sub-commands for migration management.

Usage:
  atlas migrate [command]

Available Commands:
  apply       Applies pending migration files on the connected database.
  diff        Compute the diff between the migration directory and a desired state and create a new migration file.
  hash        Hash (re-)creates an integrity hash file for the migration directory.
  import      Import a migration directory from another migration management tool to the Atlas format.
  lint        Run analysis on the migration directory
  new         Creates a new empty migration file in the migration directory.
  set         Set the current version of the migration history table.
  status      Get information about the current migration status.
  validate    Validates the migration directories checksum and SQL statements.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for migrate
      --var <name>=<value>   input variables (default [])

Use "atlas migrate [command] --help" for more information about a command.
"""

LICENSE = """LICENSE
Atlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE.
"""

VERSION = """atlas unofficial version - development
https://github.com/ariga/atlas/releases/latest
To download an official version, visit: https://atlasgo.io/getting-started#installation
"""

HELP_TEXT = {
    ("schema",): SCHEMA_HELP,
    ("migrate",): MIGRATE_HELP,
    ("license",): """Display license information

Usage:
  atlas license [flags]

Flags:
  -h, --help   help for license
""",
    ("version",): """Prints this Atlas CLI version information.

Usage:
  atlas version [flags]

Flags:
  -h, --help   help for version
""",
    ("help",): """Help provides help for any command in the application.
Simply type atlas help [path to command] for full details.

Usage:
  atlas help [command] [flags]

Flags:
  -h, --help   help for help
""",
    ("schema", "fmt"): """'atlas schema fmt' formats all ".hcl" files under the given paths using
canonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.
Unless stated otherwise, the fmt command will use the current directory.

After running, the command will print the names of the files it has formatted. If all
files in the directory are formatted, no input will be printed out.

Usage:
  atlas schema fmt [path ...] [flags]

Flags:
  -h, --help   help for fmt

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("schema", "inspect"): """'atlas schema inspect' connects to the given database and inspects its schema.
It then prints to the screen the schema of that database in Atlas DDL syntax. This output can be
saved to a file, commonly by redirecting the output to a file named with a ".hcl" suffix:

  atlas schema inspect -u "mysql://user:pass@localhost:3306/dbname" > schema.hcl

Usage:
  atlas schema inspect [flags]

Flags:
  -u, --url string        [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
  -s, --schema strings    set schema names
      --exclude strings   list of glob patterns used to filter resources from applying
      --format string     Go template to use to format the output
  -h, --help              help for inspect

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("schema", "diff"): """'atlas schema diff' reads the state of two given schema definitions, 
calculates the difference in their schemas, and prints a plan of
SQL statements to migrate the "from" database to the schema of the "to" database.
The database states can be read from a connected database, an HCL project or a migration directory.

Usage:
  atlas schema diff [flags]

Flags:
  -f, --from strings      [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --to strings        [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
  -s, --schema strings    set schema names
      --exclude strings   list of glob patterns used to filter resources from applying
      --include strings   list of glob patterns used to select which resources to keep in inspection
      --format string     Go template to use to format the output
  -h, --help              help for diff

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("schema", "apply"): """'atlas schema apply' plans and executes a database migration to bring a given
database to the state described in the provided Atlas schema. Before running the
migration, Atlas will print the migration plan and prompt the user for approval.

Usage:
  atlas schema apply [flags]

Flags:
  -u, --url string              [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --exclude strings         list of glob patterns used to filter resources from applying
      --include strings         list of glob patterns used to select which resources to keep in inspection
  -s, --schema strings          set schema names
      --dev-url string          [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dry-run                 print SQL without executing it
      --auto-approve            apply changes without prompting for approval
      --format string           Go template to use to format the output
      --tx-mode string          set transaction mode [none, file] (default "file")
      --plan string             URL to a pre-planned migration (e.g., atlas://repo/plans/name)
      --edit                    open the generated SQL in an editor
      --lock-timeout duration   set how long to wait for the database lock (default 10s)
  -h, --help                    help for apply

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("schema", "clean"): """'atlas schema clean' drops all objects in the connected database and leaves it in an empty state.
As a safety feature, 'atlas schema clean' will ask for confirmation before attempting to execute any SQL.

Usage:
  atlas schema clean [flags]

Flags:
  -u, --url string      [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dry-run         print SQL without executing it
      --format string   Go template to use to format the output
      --auto-approve    apply changes without prompting for approval
  -h, --help            help for clean

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("migrate", "new"): """'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.

Usage:
  atlas migrate new [flags] [name]

Examples:
  atlas migrate new my-new-migration

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
      --edit                edit the created migration file(s)
  -h, --help                help for new

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("migrate", "hash"): """'atlas migrate hash' computes the integrity hash sum of the migration directory and stores it in the atlas.sum file.
This command should be used whenever a manual change in the migration directory was made.

Usage:
  atlas migrate hash [flags]

Examples:
  atlas migrate hash

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for hash

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("migrate", "validate"): """'atlas migrate validate' computes the integrity hash sum of the migration directory and compares it to the
atlas.sum file. If there is a mismatch it will be reported. If the --dev-url flag is given, the migration
files are executed on the connected database in order to validate SQL semantics.

Usage:
  atlas migrate validate [flags]

Flags:
      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for validate

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("migrate", "status"): """'atlas migrate status' reports information about the current status of a connected database compared to the migration directory.

Usage:
  atlas migrate status [flags]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --format string             Go template to use to format the output
      --dir string                select migration directory using URL format (default "file://migrations")
      --dir-format string         select migration file format (default "atlas")
      --revisions-schema string   name of the schema the revisions table resides in
  -h, --help                      help for status

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("migrate", "apply"): """'atlas migrate apply' reads the migration state of the connected database and computes what migrations are pending.
It then attempts to apply the pending migration files in the correct order onto the database. 
The first argument denotes the maximum number of migration files to apply.

Usage:
  atlas migrate apply [flags] [amount]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dir string                select migration directory using URL format (default "file://migrations")
      --format string             Go template to use to format the output
      --revisions-schema string   name of the schema the revisions table resides in
      --dry-run                   print SQL without executing it
      --lock-timeout duration     set how long to wait for the database lock (default 10s)
      --baseline string           start the first migration after the given baseline version
      --tx-mode string            set transaction mode [none, file, all] (default "file")
      --exec-order string         set file execution order [linear, linear-skip, non-linear] (default "linear")
      --allow-dirty               allow start working on a non-clean database
  -h, --help                      help for apply

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("migrate", "diff"): """The 'atlas migrate diff' command uses the dev-database to calculate the current state of the migration directory
by executing its files. It then compares its state to the desired state and create a new migration file containing
SQL statements for moving from the current to the desired state.

Usage:
  atlas migrate diff [flags] [name]

Flags:
      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dev-url string          [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string              select migration directory using URL format (default "file://migrations")
      --dir-format string       select migration file format (default "atlas")
  -s, --schema strings          set schema names
      --lock-timeout duration   set how long to wait for the database lock (default 10s)
      --format string           Go template to use to format the output
      --qualifier string        qualify tables with custom qualifier when working on a single schema
      --edit                    edit the generated migration file(s)
  -h, --help                    help for diff

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("migrate", "lint"): """Run analysis on the migration directory

Usage:
  atlas migrate lint [flags]

Flags:
      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
      --format string       Go template to use to format the output
      --latest uint         run analysis on the latest N migration files
      --git-base string     run analysis against the base Git branch
      --git-dir string      path to the repository working directory (default ".")
  -h, --help                help for lint

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("migrate", "set"): """'atlas migrate set' edits the revision table to consider all migrations up to and including the given version
to be applied. This command is usually used after manually making changes to the managed database.

Usage:
  atlas migrate set [flags] [version]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dir string                select migration directory using URL format (default "file://migrations")
      --dir-format string         select migration file format (default "atlas")
      --revisions-schema string   name of the schema the revisions table resides in
  -h, --help                      help for set

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
    ("migrate", "import"): """Import a migration directory from another migration management tool to the Atlas format.

Usage:
  atlas migrate import [flags]

Flags:
      --from string         select migration directory using URL format (default "file://migrations")
      --to string           select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for import

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])
""",
}

COMMUNITY_NOTICE = """Notice: This Atlas edition lacks support for features such as checkpoints,
testing, down migrations, and more. Additionally, advanced database objects such as views, 
triggers, and stored procedures are not supported. To read more: https://atlasgo.io/community-edition

To install the non-community version of Atlas, use the following command:

\tcurl -sSf https://atlasgo.sh | sh

Or, visit the website to see all installation options:

\thttps://atlasgo.io/docs#installation

"""


def eprint(s):
    print(s, file=sys.stderr)


def err(s, code=1):
    eprint("Error: " + s)
    return code


def parse_opts(argv):
    opts = {}
    pos = []
    i = 0
    aliases = {"-u": "url", "-c": "config", "-s": "schema", "-f": "from", "-h": "help"}
    val_flags = {
        "url", "config", "env", "var", "dir", "dir-format", "dev-url", "schema",
        "from", "to", "format", "exclude", "include", "lock-timeout", "baseline",
        "tx-mode", "exec-order", "revisions-schema", "plan", "qualifier", "git-base",
        "git-dir",
    }
    while i < len(argv):
        a = argv[i]
        if a == "--":
            pos.extend(argv[i + 1:])
            break
        if a.startswith("--"):
            keyval = a[2:]
            if "=" in keyval:
                k, v = keyval.split("=", 1)
            elif keyval in val_flags:
                if i + 1 >= len(argv):
                    return opts, pos, f"flag needs an argument: --{keyval}"
                i += 1
                k, v = keyval, argv[i]
            else:
                k, v = keyval, True
            opts.setdefault(k, []).append(v)
        elif a in aliases:
            k = aliases[a]
            if k == "help":
                opts.setdefault(k, []).append(True)
            else:
                if i + 1 >= len(argv):
                    return opts, pos, f"flag needs an argument: {a}"
                i += 1
                opts.setdefault(k, []).append(argv[i])
        else:
            pos.append(a)
        i += 1
    return opts, pos, None


def opt(opts, key, default=None):
    return opts.get(key, [default])[-1]


def file_url_path(url):
    if not url:
        return None
    if url.startswith("file://"):
        p = url[7:]
        return unquote(p) if p else "."
    return url


def sqlite_path(url):
    if not url:
        return None
    if url.startswith("sqlite://"):
        p = url[len("sqlite://"):]
        if p.startswith("file:"):
            p = p[5:]
        p = p.split("?", 1)[0]
        return p or ":memory:"
    return None


def hcl_format_text(text):
    out = []
    indent = 0
    blank = False
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            if not blank and out:
                out.append("")
            blank = True
            continue
        if line.startswith("}"):
            indent = max(0, indent - 1)
        line = re.sub(r'^(schema|table|column|env|variable)\s+"([^"]+)"\s+\{', r'\1 "\2" {', line)
        line = re.sub(r'^(primary_key|foreign_key|index|check|locals)\s*\{', r'\1 {', line)
        line = re.sub(r'\s*=\s*', " = ", line)
        out.append("  " * indent + line)
        blank = False
        if line.endswith("{"):
            indent += 1
    return "\n".join(out).rstrip() + "\n"


def cmd_schema_fmt(args):
    opts, paths, perr = parse_opts(args)
    if perr:
        return err(perr)
    if opt(opts, "help"):
        print(HELP_TEXT[("schema", "fmt")], end="")
        return 0
    if not paths:
        paths = ["."]
    files = []
    for p in paths:
        path = Path(p)
        if path.is_dir():
            files.extend(sorted(path.rglob("*.hcl")))
        elif path.exists():
            files.append(path)
    for p in files:
        old = p.read_text()
        new = hcl_format_text(old)
        if new != old:
            p.write_text(new)
            print(str(p))
    return 0


def load_config_env(path, env, vars_):
    text = Path(path).read_text()
    names = re.findall(r'env\s+"([^"]+)"\s*\{', text)
    if env and env not in names:
        raise ValueError(f'env "{env}" not defined in config file')
    name = env or (names[0] if names else "")
    m = re.search(r'env\s+"' + re.escape(name) + r'"\s*\{(.*?)\n\}', text, re.S)
    if not m:
        return {}
    block = m.group(1)
    data = {}
    for k, v in re.findall(r'(\w+)\s*=\s*"([^"]*)"', block):
        data[k] = v
    defaults = dict(re.findall(r'variable\s+"([^"]+)"\s*\{.*?default\s*=\s*"([^"]*)"', text, re.S))
    supplied = {}
    for item in vars_:
        if isinstance(item, str) and "=" in item:
            k, v = item.split("=", 1)
            supplied[k] = v
    def repl_var(mm):
        k = mm.group(1)
        return supplied.get(k, defaults.get(k, ""))
    for k, v in list(data.items()):
        v = re.sub(r'\$\{var\.([A-Za-z0-9_]+)\}', repl_var, v)
        data[k] = v
    return data


def inspect_sqlite(url):
    path = sqlite_path(url)
    if not path:
        print('schema "main" {\n}')
        return 0
    if path != ":memory:" and not os.path.exists(path):
        print('schema "main" {\n}')
        return 0
    con = sqlite3.connect(path)
    cur = con.cursor()
    cur.execute("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    tables = cur.fetchall()
    for tname, _sql in tables:
        print(f'table "{tname}" {{')
        print("  schema = schema.main")
        cur.execute(f'PRAGMA table_info("{tname}")')
        cols = cur.fetchall()
        pkcols = []
        for _cid, name, typ, notnull, dflt, pk in cols:
            if pk:
                pkcols.append(name)
            print(f'  column "{name}" {{')
            print(f'    null = {"false" if notnull else "true"}')
            print(f'    type = {typ.lower() if typ else "text"}')
            if dflt is not None:
                print(f'    default = {dflt}')
            print("  }")
        if pkcols:
            print("  primary_key {")
            print("    columns = [" + ", ".join(f"column.{c}" for c in pkcols) + "]")
            print("  }")
        cur.execute("SELECT name, sql FROM sqlite_master WHERE type='index' AND tbl_name=? AND sql IS NOT NULL ORDER BY name", (tname,))
        for iname, isql in cur.fetchall():
            cols_m = re.search(r'\((.*?)\)', isql or "")
            cols = []
            if cols_m:
                cols = [c.strip().strip('"`[]') for c in cols_m.group(1).split(",")]
            print(f'  index "{iname}" {{')
            if cols:
                print("    columns = [" + ", ".join(f"column.{c}" for c in cols) + "]")
            print("  }")
        print("}")
    print('schema "main" {\n}')
    con.close()
    return 0


def cmd_schema_inspect(args):
    opts, pos, perr = parse_opts(args)
    if perr:
        return err(perr)
    if opt(opts, "help"):
        print(HELP_TEXT[("schema", "inspect")], end="")
        return 0
    url = opt(opts, "url")
    if not url and opt(opts, "env"):
        try:
            cfg = load_config_env(file_url_path(opt(opts, "config", "file://atlas.hcl")), opt(opts, "env"), opts.get("var", []))
        except Exception as ex:
            return err(str(ex))
        url = cfg.get("url")
        print(COMMUNITY_NOTICE, end="")
    if not url:
        return err('required flag(s) "url" not set')
    return inspect_sqlite(url)


def cmd_schema_clean(args):
    opts, pos, perr = parse_opts(args)
    if perr:
        return err(perr)
    if opt(opts, "help"):
        print(HELP_TEXT[("schema", "clean")], end="")
        return 0
    if opt(opts, "dry-run"):
        eprint("""Abort: 'atlas schema clean --dry-run' is not supported by the community version.

To install the non-community version of Atlas, use the following command:

\tcurl -sSf https://atlasgo.sh | sh

Or, visit the website to see all installation options:

\thttps://atlasgo.io/docs#installation""")
        return 1
    url = opt(opts, "url")
    if not url:
        return err('required flag(s) "url" not set')
    if not opt(opts, "auto-approve"):
        return err("cannot prompt for approval in non-interactive mode")
    path = sqlite_path(url)
    if path and os.path.exists(path):
        con = sqlite3.connect(path)
        cur = con.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
        for (name,) in cur.fetchall():
            cur.execute(f'DROP TABLE "{name}"')
        con.commit()
        con.close()
    return 0


def migrate_dir(opts):
    return Path(file_url_path(opt(opts, "dir", "file://migrations")))


def hash_bytes(data):
    return "h1:" + base64.b64encode(hashlib.sha256(data).digest()).decode()


def write_sum(d):
    files = [p for p in sorted(d.iterdir()) if p.is_file() and p.name != "atlas.sum"]
    lines = []
    for p in files:
        lines.append(f"{p.name} {hash_bytes(p.read_bytes())}")
    root = hash_bytes(("\n".join(lines) + ("\n" if lines else "")).encode())
    content = root + "\n" + "\n".join(lines) + ("\n" if lines else "")
    (d / "atlas.sum").write_text(content)


def cmd_migrate_new(args):
    opts, pos, perr = parse_opts(args)
    if perr:
        return err(perr)
    if opt(opts, "help"):
        print(HELP_TEXT[("migrate", "new")], end="")
        return 0
    name = pos[0] if pos else ""
    if not name:
        return err("accepts 1 arg(s), received 0")
    name = re.sub(r"[^A-Za-z0-9_]+", "_", name).strip("_").lower()
    d = migrate_dir(opts)
    d.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d%H%M%S", time.gmtime())
    path = d / f"{stamp}_{name}.sql"
    path.write_text("")
    write_sum(d)
    return 0


def cmd_migrate_hash(args):
    opts, pos, perr = parse_opts(args)
    if perr:
        return err(perr)
    if opt(opts, "help"):
        print(HELP_TEXT[("migrate", "hash")], end="")
        return 0
    d = migrate_dir(opts)
    if not d.exists():
        return err(f"sql/migrate: stat {d}: no such file or directory")
    write_sum(d)
    return 0


def cmd_migrate_validate(args):
    opts, pos, perr = parse_opts(args)
    if perr:
        return err(perr)
    if opt(opts, "help"):
        print(HELP_TEXT[("migrate", "validate")], end="")
        return 0
    d = migrate_dir(opts)
    if not d.exists():
        return err(f"sql/migrate: stat {d}: no such file or directory")
    if not (d / "atlas.sum").exists():
        return err("checksum file not found")
    before = (d / "atlas.sum").read_text()
    write_sum(d)
    after = (d / "atlas.sum").read_text()
    if before != after:
        (d / "atlas.sum").write_text(before)
        return err("checksum mismatch")
    return 0


def unsupported(name, args):
    opts, pos, perr = parse_opts(args)
    if opt(opts, "help"):
        txt = HELP_TEXT.get(tuple(name.split()))
        if txt:
            print(txt, end="")
        else:
            print(f"Usage:\n  atlas {name} [flags]\n")
        return 0
    return err(f"{name}: not implemented in this cleanroom build")


def completion(shell, args):
    if "--help" in args or "-h" in args:
        print(f"Generate the autocompletion script for the {shell} shell.\n\nUsage:\n  atlas completion {shell} [flags]\n\nFlags:\n  -h, --help              help for {shell}\n      --no-descriptions   disable completion descriptions")
        return 0
    print(f"# {shell} completion for atlas")
    return 0


def main(argv):
    if not argv or argv[0] in ("--help", "-h"):
        print(ROOT_HELP, end="")
        return 0
    if argv[0] == "help":
        path = tuple(argv[1:])
        print(HELP_TEXT.get(path, ROOT_HELP), end="")
        return 0
    if argv[0] == "version":
        if len(argv) > 1 and argv[1] in ("--help", "-h"):
            print(HELP_TEXT[("version",)], end="")
        else:
            print(VERSION, end="")
        return 0
    if argv[0] == "license":
        if len(argv) > 1 and argv[1] in ("--help", "-h"):
            print(HELP_TEXT[("license",)], end="")
        else:
            print(LICENSE, end="")
        return 0
    if argv[0] == "completion":
        if len(argv) == 1 or argv[1] in ("--help", "-h"):
            print("""Generate the autocompletion script for atlas for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  atlas completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion

Use "atlas completion [command] --help" for more information about a command.""")
            return 0
        return completion(argv[1], argv[2:])
    if argv[0] == "schema":
        if len(argv) == 1 or argv[1] in ("--help", "-h"):
            print(SCHEMA_HELP, end="")
            return 0
        sub = argv[1]
        if sub == "fmt":
            return cmd_schema_fmt(argv[2:])
        if sub == "inspect":
            return cmd_schema_inspect(argv[2:])
        if sub == "clean":
            return cmd_schema_clean(argv[2:])
        return unsupported("schema " + sub, argv[2:])
    if argv[0] == "migrate":
        if len(argv) == 1 or argv[1] in ("--help", "-h"):
            print(MIGRATE_HELP, end="")
            return 0
        sub = argv[1]
        if sub == "new":
            return cmd_migrate_new(argv[2:])
        if sub == "hash":
            return cmd_migrate_hash(argv[2:])
        if sub == "validate":
            return cmd_migrate_validate(argv[2:])
        return unsupported("migrate " + sub, argv[2:])
    eprint(f'Error: unknown command "{argv[0]}" for "atlas"')
    eprint("Run 'atlas --help' for usage.")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
