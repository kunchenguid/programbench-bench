#!/usr/bin/env python3
import argparse
import os
import re
import shlex
import subprocess
import sys
import time


RESET = "\033[0m"
COLORS = {
    "red": "\033[31m",
    "green": "\033[32m",
    "yellow": "\033[33m",
    "blue": "\033[34m",
    "magenta": "\033[35m",
    "cyan": "\033[36m",
}

GROUPS = {
    "numbers", "urls", "pointers", "dates", "paths", "quotes",
    "key-value-pairs", "uuids", "ip-addresses", "processes", "json",
}


HELP_LONG = """A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          Filepath

Options:
  -f, --follow
          Follow the contents of a file

  -p, --print
          Print the output to stdout

      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file

  -e, --exec <EXEC>
          Run command and view the output in a pager

      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
          
          [possible values: red, green, yellow, blue, magenta, cyan]

      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)

      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. `--pager="ov -f [FILE]"`)
          
          [env: TAILSPIN_PAGER=]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

HELP_SHORT = """A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]  Filepath

Options:
  -f, --follow
          Follow the contents of a file
  -p, --print
          Print the output to stdout
      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file
  -e, --exec <EXEC>
          Run command and view the output in a pager
      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
          quotes, key-value-pairs, uuids, ip-addresses, processes, json]
      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
          quotes, key-value-pairs, uuids, ip-addresses, processes, json]
      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)
      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. `--pager="ov -f [FILE]"`) [env:
          TAILSPIN_PAGER=]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


def sgr(code, s):
    return f"\033[{code}m{s}{RESET}"


def color_name(name, s):
    return COLORS[name] + s + RESET


def parse_csv(values):
    out = set()
    for value in values or []:
        for part in value.split(","):
            part = part.strip()
            if part:
                out.add(part)
    return out


def parse_args(argv):
    if "--help" in argv:
        print(HELP_LONG, end="")
        raise SystemExit(0)
    if "-h" in argv:
        print(HELP_SHORT, end="")
        raise SystemExit(0)
    if "--version" in argv or "-V" in argv:
        print("tspin 5.6.0")
        raise SystemExit(0)

    parser = argparse.ArgumentParser(add_help=False, prog="executable", allow_abbrev=False)
    parser.add_argument("-f", "--follow", action="store_true")
    parser.add_argument("-p", "--print", dest="do_print", action="store_true")
    parser.add_argument("--config-path")
    parser.add_argument("-e", "--exec", dest="exec_cmd")
    parser.add_argument("--highlight", action="append", default=[])
    parser.add_argument("--enable", action="append", default=[])
    parser.add_argument("--disable", action="append", default=[])
    parser.add_argument("--disable-builtin-keywords", action="store_true")
    parser.add_argument("--pager")
    parser.add_argument("file", nargs="?")
    try:
        ns, extras = parser.parse_known_args(argv)
    except SystemExit:
        sys.exit(2)
    if extras:
        bad = extras[0]
        print(f"error: unexpected argument '{bad}' found\n", file=sys.stderr)
        print(f"  tip: to pass '{bad}' as a value, use '-- {bad}'\n", file=sys.stderr)
        print("Usage: executable [OPTIONS] [FILE]\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    if ns.enable and ns.disable:
        print('Error:   × cannot both enable and disable highlighters\n', file=sys.stderr)
        sys.exit(1)
    en = parse_csv(ns.enable)
    dis = parse_csv(ns.disable)
    for g in sorted(en | dis):
        if g not in GROUPS:
            print(f"error: invalid value '{g}'", file=sys.stderr)
            sys.exit(2)
    return ns, en, dis


TOKEN_RE = re.compile(
    r"https?://[^\s\"'<>]+"
    r"|[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}"
    r"|\b(?:\d{1,3}\.){3}\d{1,3}\b"
    r"|\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:[.,]\d+)?Z?"
    r"|\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?)?"
    r"|\"(?:\\.|[^\"\\])*\""
    r"|(?:^|(?<=\s))/?(?:[A-Za-z0-9_.-]+/)+[A-Za-z0-9_.-]+"
    r"|\b[A-Za-z_][A-Za-z0-9_.-]*=(?:\"(?:\\.|[^\"\\])*\"|[^\s]+)"
    r"|\b(?:ERROR|WARN|INFO|DEBUG|TRACE|FATAL)\b"
    r"|\b(?:GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\b"
    r"|\b(?:true|false|null)\b"
    r"|-?\b\d+(?:\.\d+)?\b"
    r"|[\[\]{}(),?:=-]"
)


def active_group(group, enabled, disabled):
    if enabled:
        return group in enabled
    return group not in disabled


def highlight_url(tok):
    m = re.match(r"(https?)(://)([^/?#]+)(.*)", tok)
    if not m:
        return tok
    scheme, sep, host, rest = m.groups()
    out = sgr("2;31" if scheme == "http" else "2;32", scheme) + sep + sgr("2;34", host)
    if rest:
        if "?" in rest:
            path, query = rest.split("?", 1)
        else:
            path, query = rest, ""
        if path:
            out += sgr("34", path)
        if query or "?" in rest:
            out += sgr("31", "?")
            parts = re.split(r"([=&])", query)
            expect_value = False
            for part in parts:
                if part in ("=", "&"):
                    out += sgr("31", part)
                    expect_value = part == "="
                elif part:
                    if expect_value and re.fullmatch(r"\d+", part):
                        out += sgr("36", part)
                    else:
                        out += sgr("35" if not expect_value else "34", part)
    return out


def highlight_date(tok):
    if "T" in tok:
        return re.sub(r"\d{4}|\d{2}(?=[-T])", lambda m: sgr("35", m.group(0)), tok)\
            .replace("-", sgr("2", "-"), 2)\
            .replace("T", sgr("31", "T"), 1)\
            .replace(":", sgr("2", ":"))\
            .replace(".", sgr("2", "."))\
            .replace(",", sgr("2", ","))\
            .replace("Z", sgr("31", "Z"))
    if " " in tok:
        date, times = tok.split(" ", 1)
        return highlight_date(date) + sgr("31", " ") + highlight_time(times)
    return re.sub(r"(\d{4})-(\d{2})-(\d{2})",
                  lambda m: sgr("35", m.group(1)) + sgr("2", "-") + sgr("35", m.group(2)) + sgr("2", "-") + sgr("35", m.group(3)),
                  tok)


def highlight_time(tok):
    return re.sub(r"\d+(?:\.\d+)?", lambda m: sgr("34", m.group(0)), tok).replace(":", sgr("2", ":")).replace(".", sgr("2", "."))


def highlight_path(tok):
    res = []
    for ch in tok:
        if ch == "/":
            res.append(sgr("33", ch))
        elif ch == ".":
            res.append(sgr("32", ch))
        else:
            res.append(sgr("32", ch))
    return "".join(res)


def highlight_kv(tok, enabled, disabled, builtin):
    key, val = tok.split("=", 1)
    out = sgr("2", key) + sgr("37", "=")
    if val.startswith('"') and val.endswith('"') and active_group("quotes", enabled, disabled):
        out += sgr("33", val)
    else:
        out += highlight_text(val, enabled, disabled, builtin, top=False)
    return out


def classify(tok):
    if tok.startswith("http://") or tok.startswith("https://"):
        return "urls"
    if re.fullmatch(r"[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}", tok):
        return "uuids"
    if re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", tok):
        return "ip-addresses"
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}(?:[T ].*)?", tok):
        return "dates"
    if tok.startswith('"') and tok.endswith('"'):
        return "quotes"
    if "=" in tok and re.match(r"^[A-Za-z_][A-Za-z0-9_.-]*=", tok):
        return "key-value-pairs"
    if "/" in tok and re.match(r"^/?(?:[A-Za-z0-9_.-]+/)+[A-Za-z0-9_.-]+$", tok):
        return "paths"
    if re.fullmatch(r"-?\d+(?:\.\d+)?", tok):
        return "numbers"
    return None


def highlight_token(tok, enabled, disabled, builtin):
    group = classify(tok)
    if group and not active_group(group, enabled, disabled):
        return tok
    if group == "urls":
        return highlight_url(tok)
    if group == "uuids":
        out = []
        for ch in tok:
            if ch == "-":
                out.append(sgr("31", ch))
            elif ch.isdigit():
                out.append(sgr("3;34", ch))
            else:
                out.append(sgr("3;35", ch))
        return "".join(out)
    if group == "ip-addresses":
        return ".".join(sgr("3;34", p) for p in tok.split(".")).replace(".", sgr("31", "."))
    if group == "dates":
        return highlight_date(tok)
    if group == "quotes":
        return sgr("33", tok)
    if group == "paths":
        return highlight_path(tok)
    if group == "key-value-pairs":
        return highlight_kv(tok, enabled, disabled, builtin)
    if group == "numbers":
        return sgr("36", tok)
    if not builtin:
        return tok
    if tok in ("true", "false", "null"):
        return sgr("3;31", tok)
    sev = {"ERROR": "31", "WARN": "33", "INFO": "37", "DEBUG": "32", "TRACE": "2", "FATAL": "31"}
    if tok in sev:
        return sgr(sev[tok], tok)
    rest = {"GET": "42;30", "POST": "43;30", "PUT": "45;30", "DELETE": "41;30", "PATCH": "45;30", "HEAD": "46;30", "OPTIONS": "44;30"}
    if tok in rest:
        return sgr(rest[tok], f" {tok} ")
    if tok in "[]{}(),?:=-":
        return sgr("31" if tok not in ("=",) else "37", tok)
    return tok


def apply_custom(text, highlights):
    for item in highlights:
        if ":" not in item:
            continue
        color, words = item.split(":", 1)
        if color not in COLORS:
            continue
        for word in [w for w in words.split(",") if w]:
            text = re.sub(re.escape(word), lambda m, c=color: color_name(c, m.group(0)), text)
    return text


def highlight_text(text, enabled, disabled, builtin=True, top=True, custom=None):
    out = []
    pos = 0
    for m in TOKEN_RE.finditer(text):
        s, e = m.span()
        if s > pos:
            out.append(text[pos:s])
        out.append(highlight_token(m.group(0), enabled, disabled, builtin))
        pos = e
    out.append(text[pos:])
    result = "".join(out)
    if top and custom:
        result = apply_custom(result, custom)
    return result


def read_input(ns):
    if ns.exec_cmd:
        p = subprocess.run(ns.exec_cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        return p.stdout
    if ns.file:
        try:
            with open(ns.file, "r", encoding="utf-8", errors="replace") as f:
                if ns.follow:
                    data = f.read()
                    sys.stdout.write(data)
                    sys.stdout.flush()
                    while True:
                        chunk = f.read()
                        if chunk:
                            sys.stdout.write(chunk)
                            sys.stdout.flush()
                        time.sleep(0.2)
                return f.read()
        except OSError as e:
            print(f"Error:   ⚠ \033[33m{ns.file}\033[0m: {e.strerror}", file=sys.stderr)
            sys.exit(1)
    return sys.stdin.read()


def main(argv=None):
    ns, enabled, disabled = parse_args(sys.argv[1:] if argv is None else argv)
    data = read_input(ns)
    sys.stdout.write(highlight_text(data, enabled, disabled, not ns.disable_builtin_keywords, custom=ns.highlight))


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        try:
            sys.stdout.close()
        finally:
            sys.exit(0)
