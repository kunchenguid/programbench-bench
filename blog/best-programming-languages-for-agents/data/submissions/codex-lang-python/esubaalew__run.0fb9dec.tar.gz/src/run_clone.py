#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
import tempfile


AVAILABLE = [
    "bash", "c", "cpp", "crystal", "csharp", "dart", "elixir", "go",
    "groovy", "haskell", "java", "javascript", "julia", "kotlin", "lua",
    "nim", "perl", "php", "python", "r", "ruby", "rust", "swift",
    "typescript", "zig",
]

PYTHON = "/usr/bin/python3" if os.path.exists("/usr/bin/python3") else "python3"

ALIASES = {
    "py": "python",
    "python3": "python",
    "sh": "bash",
    "shell": "bash",
    "pl": "perl",
    "c++": "cpp",
    "js": "javascript",
    "node": "javascript",
    "ts": "typescript",
}

EXT_LANG = {
    ".py": "python",
    ".sh": "bash",
    ".bash": "bash",
    ".c": "c",
    ".h": "c",
    ".cc": "cpp",
    ".cpp": "cpp",
    ".cxx": "cpp",
    ".hpp": "cpp",
    ".pl": "perl",
    ".pm": "perl",
    ".js": "javascript",
    ".mjs": "javascript",
    ".ts": "typescript",
    ".lua": "lua",
    ".rb": "ruby",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".php": "php",
}


VERSION_TEXT = """run-kit 0.3.2
Universal multi-language runner and smart REPL
author: Esubalew Chekol <esubalewchekol6@gmail.com>
homepage: https://esubalew.et
repository: https://github.com/Esubaalew/run
license: Apache-2.0
commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)
built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]
rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)"""

HELP_TEXT = """Universal multi-language runner and REPL

Usage: executable [OPTIONS] [ARGS]...

Arguments:
  [ARGS]...  Positional arguments (language, code, or file)

Options:
  -V, --version      Print version information and exit
  -l, --lang <LANG>  Explicitly choose the language to execute
  -f, --file <PATH>  Execute code from the provided file path
  -c, --code <CODE>  Execute the provided code snippet
      --no-detect    Disable heuristic language detection
  -h, --help         Print help"""


def eprint(msg=""):
    print(msg, file=sys.stderr)


def clap_missing(opt, meta):
    eprint(f"error: a value is required for '{opt} <{meta}>' but none was supplied")
    eprint()
    eprint("For more information, try '--help'.")
    return 2


def unknown_arg(arg):
    eprint(f"error: unexpected argument '{arg}' found")
    eprint()
    eprint(f"  tip: to pass '{arg}' as a value, use '-- {arg}'")
    eprint()
    eprint("Usage: executable [OPTIONS] [ARGS]...")
    eprint()
    eprint("For more information, try '--help'.")
    return 2


def normalize_lang(lang):
    if lang is None:
        return None
    low = lang.lower()
    return ALIASES.get(low, low)


def unknown_language(lang):
    eprint(f"Error: Unknown language '{lang}'. Available languages: {', '.join(AVAILABLE)}")
    return 1


def parse(argv):
    opts = {"lang": None, "file": None, "code": None, "no_detect": False}
    args = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            args.extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            print(HELP_TEXT)
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION_TEXT)
            raise SystemExit(0)
        if a in ("-l", "--lang"):
            if i + 1 >= len(argv):
                raise SystemExit(clap_missing("--lang" if a == "--lang" else "-l", "LANG"))
            opts["lang"] = argv[i + 1]
            i += 2
            continue
        if a.startswith("--lang="):
            opts["lang"] = a.split("=", 1)[1]
            i += 1
            continue
        if a in ("-f", "--file"):
            if i + 1 >= len(argv):
                raise SystemExit(clap_missing("--file" if a == "--file" else "-f", "PATH"))
            opts["file"] = argv[i + 1]
            i += 2
            continue
        if a.startswith("--file="):
            opts["file"] = a.split("=", 1)[1]
            i += 1
            continue
        if a in ("-c", "--code"):
            if i + 1 >= len(argv):
                raise SystemExit(clap_missing("--code" if a == "--code" else "-c", "CODE"))
            opts["code"] = argv[i + 1]
            i += 2
            continue
        if a.startswith("--code="):
            opts["code"] = a.split("=", 1)[1]
            i += 1
            continue
        if a == "--no-detect":
            opts["no_detect"] = True
            i += 1
            continue
        if a.startswith("-"):
            raise SystemExit(unknown_arg(a))
        args.append(a)
        i += 1
    return opts, args


def detect_from_code(code):
    s = code.lstrip()
    if s.startswith("#include") or "int main" in s:
        return "c"
    if "#include <iostream>" in s or "std::" in s:
        return "cpp"
    if s.startswith("package main"):
        return "go"
    if s.startswith("fn main") or "println!" in s:
        return "rust"
    if s.startswith("import ") or s.startswith("from ") or "sys." in s:
        return "python"
    if s.startswith("echo ") or s.startswith("#!/bin/sh") or s.startswith("#!/bin/bash"):
        return "bash"
    if s.startswith("console.log") or "=> " in s:
        return "javascript"
    if s.startswith("puts "):
        return "ruby"
    if s.startswith("print("):
        return "lua"
    return "python"


def detect_from_file(path, no_detect=False):
    if no_detect:
        return "python"
    _, ext = os.path.splitext(path)
    return EXT_LANG.get(ext.lower(), "python")


def choose(opts, args):
    lang = normalize_lang(opts["lang"])
    code = opts["code"]
    path = opts["file"]

    if args and lang is None and normalize_lang(args[0]) in AVAILABLE:
        lang = normalize_lang(args[0])
        args = args[1:]

    if code is not None and args:
        eprint("Error: Unexpected positional arguments after specifying --code")
        raise SystemExit(1)
    if path is not None and args:
        eprint("Error: Unexpected positional arguments when --file is present")
        raise SystemExit(1)

    if args:
        joined = " ".join(args)
        if len(args) == 1 and os.path.exists(args[0]):
            path = args[0]
        else:
            code = joined

    if lang is not None and lang not in AVAILABLE:
        raise SystemExit(unknown_language(opts["lang"]))

    if path is not None and lang is None:
        lang = detect_from_file(path, opts["no_detect"])
    if code is not None and lang is None:
        lang = "python" if opts["no_detect"] else detect_from_code(code)
    if lang is None:
        lang = "python"
    return lang, code, path


def run_cmd(cmd, input_stdin=True):
    try:
        p = subprocess.run(cmd, stdin=None if input_stdin else subprocess.DEVNULL)
        return p.returncode
    except FileNotFoundError:
        return 127


def need_tool(lang, exe, url, install="Install it from"):
    if shutil.which(exe):
        return True
    eprint(f"Error: {lang} support requires the `{exe}` executable. {install} {url} and ensure it is on your PATH.")
    return False


def temp_write(td, name, code):
    path = os.path.join(td, name)
    with open(path, "w", encoding="utf-8") as f:
        f.write(code)
        if not code.endswith("\n"):
            f.write("\n")
    return path


def execute(lang, code, path):
    if lang == "python":
        if code is not None:
            return run_cmd([PYTHON, "-c", code])
        if path is not None:
            return run_cmd([PYTHON, path])
        return run_cmd([PYTHON])

    if lang == "bash":
        if code is not None:
            return run_cmd(["/usr/bin/bash" if os.path.exists("/usr/bin/bash") else "bash", "-c", code])
        if path is not None:
            return run_cmd(["/usr/bin/bash" if os.path.exists("/usr/bin/bash") else "bash", path])
        return run_cmd(["/usr/bin/bash" if os.path.exists("/usr/bin/bash") else "bash"])

    if lang == "perl":
        if code is not None:
            return run_cmd(["perl", "-e", code])
        if path is not None:
            return run_cmd(["perl", path])
        return run_cmd(["perl"])

    if lang == "javascript":
        exe = "node"
        if code is not None:
            return run_cmd([exe, "-e", code])
        if path is not None:
            return run_cmd([exe, path])
        return run_cmd([exe])

    if lang == "typescript":
        exe = "tsx"
        if code is not None:
            return run_cmd([exe, "-e", code])
        if path is not None:
            return run_cmd([exe, path])
        return run_cmd([exe])

    if lang == "ruby":
        if code is not None:
            return run_cmd(["ruby", "-e", code])
        if path is not None:
            return run_cmd(["ruby", path])
        return run_cmd(["ruby"])

    if lang == "lua":
        if not need_tool("Lua", "lua", "https://www.lua.org/download.html"):
            return 1
        if code is not None:
            return run_cmd(["lua", "-e", code])
        if path is not None:
            return run_cmd(["lua", path])
        return run_cmd(["lua"])

    if lang == "go":
        if not need_tool("Go", "go", "https://go.dev/dl/"):
            return 1
        if code is not None:
            with tempfile.TemporaryDirectory(prefix="run-go") as td:
                src = temp_write(td, "main.go", code)
                return run_cmd(["go", "run", src])
        if path is not None:
            return run_cmd(["go", "run", path])
        return run_cmd(["go"])

    if lang == "rust":
        if not need_tool("Rust", "rustc", "Rustup", "Install it via"):
            return 1
        with tempfile.TemporaryDirectory(prefix="run-rust") as td:
            src = path if path is not None else temp_write(td, "main.rs", code or "")
            out = os.path.join(td, "main")
            rc = run_cmd(["rustc", src, "-o", out], input_stdin=False)
            if rc != 0:
                return rc
            return run_cmd([out])

    if lang in ("c", "cpp"):
        compiler = "gcc" if lang == "c" else "g++"
        with tempfile.TemporaryDirectory(prefix=f"run-{lang}") as td:
            srcname = "main.c" if lang == "c" else "main.cpp"
            src = path if path is not None else temp_write(td, srcname, code or "")
            out = os.path.join(td, "main")
            rc = run_cmd([compiler, src, "-o", out], input_stdin=False)
            if rc != 0:
                return rc
            return run_cmd([out])

    if lang == "java":
        if code is not None:
            with tempfile.TemporaryDirectory(prefix="run-java") as td:
                src = temp_write(td, "Main.java", code)
                rc = run_cmd(["javac", src], input_stdin=False)
                if rc != 0:
                    return rc
                return run_cmd(["java", "-cp", td, "Main"])
        if path is not None:
            rc = run_cmd(["javac", path], input_stdin=False)
            if rc != 0:
                return rc
            cls = os.path.splitext(os.path.basename(path))[0]
            return run_cmd(["java", "-cp", os.path.dirname(path) or ".", cls])

    return 127


def main(argv):
    opts, args = parse(argv)
    lang, code, path = choose(opts, args)
    return execute(lang, code, path)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
