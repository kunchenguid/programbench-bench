#!/usr/bin/env python3
import ast
import fnmatch
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys

try:
    import yaml
except Exception:
    yaml = None

VERSION = "dep-tree version v0.23.4"
SOURCE_EXTS = {".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".go", ".rs"}

BANNER = r"""
      ____         _ __       _
     |  _ \   ___ |  _ \    _| |_  _ __  ___   ___
     | | | | / _ \| |_) |  |_   _||  __|/ _ \ / _ \
     | |_| ||  __/| .__/     | |  | |  |  __/|  __/
     |____/  \__| |_|        | \__|_|   \___| \___|
"""

MAIN_HELP = BANNER + """
Usage:
  dep-tree [command]

Examples:
$ dep-tree src/index.ts
$ dep-tree entropy src/index.ts
$ dep-tree tree package/main.py --unwrap-exports
$ dep-tree check

Visualize your dependencies graphically
  entropy     (default) Renders a 3d force-directed graph in the browser
  tree        Render the dependency tree starting from the provided entrypoint

Check your dependencies against your own rules
  check       Checks that the dependency rules defined in the configuration file are not broken

Display what are the dependencies between two portions of code
  explain     Shows all the dependencies between two parts of the code

Additional Commands:
  config      Generates a sample config in case that there's not already one present
  help        Help about any command

Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
  -h, --help                                 help for dep-tree
  -v, --version                              version for dep-tree

Use "dep-tree [command] --help" for more information about a command.
""".lstrip("\n")

HELP = {
    "entropy": """(default) Renders a 3d force-directed graph in the browser

Usage:
  dep-tree entropy [flags]

Flags:
      --enable-gui           Enables a GUI for changing rendering settings
  -h, --help                 help for entropy
      --no-browser-open      Disable the automatic browser open while rendering entropy
      --render-path string   Sets the output path of the rendered html file
""",
    "tree": """Render the dependency tree starting from the provided entrypoint

Usage:
  dep-tree tree [flags]

Flags:
  -h, --help   help for tree
      --json   render the dependency tree in a machine readable json format
""",
    "check": """Checks that the dependency rules defined in the configuration file are not broken

Usage:
  dep-tree check [flags]

Flags:
  -h, --help   help for check
""",
    "explain": """Shows all the dependencies between two parts of the code

Usage:
  dep-tree explain [flags]

Flags:
  -h, --help            help for explain
  -l, --overlap-left    When there's an overlap between the files at the left and the right, keep the ones at the left
  -r, --overlap-right   When there's an overlap between the files at the left and the right, keep the ones at the right
""",
    "config": """Generates a sample config in case that there's not already one present

Usage:
  dep-tree config [flags]

Aliases:
  config, init

Flags:
  -h, --help   help for config
""",
}

GLOBAL_FLAGS = """
Global Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)
"""

CONFIG_SAMPLE = """exclude:
  - 'some-glob-pattern/**/*.ts'
only:
  - 'some-glob-pattern/**/*.ts'
unwrapExports: false
check:
  entrypoints:
    - src/index.ts
  allowCircularDependencies: false
  allow:
    'src/products/**':
      - 'src/products/**'
      - 'src/helpers/**'
  deny:
    'src/products/**':
      - 'src/users/**'
  aliases:
    'common':
      - 'src/helpers/**'
      - 'src/utils/**'
      - 'src/generated/**'
js:
  workspaces: true
  tsConfigPaths: true
python:
  excludeConditionalImports: false
rust: {}
"""


def eprint(msg):
    print(msg, file=sys.stderr)


def find_root(cwd: Path) -> Path:
    cur = cwd.resolve()
    for p in [cur] + list(cur.parents):
        if (p / ".git").exists():
            return p
    return cur


def rel(path: Path, base: Path) -> str:
    try:
        return path.resolve().relative_to(base.resolve()).as_posix()
    except ValueError:
        return path.resolve().as_posix()


def norm(s: str) -> str:
    return s.replace("\\", "/").lstrip("./")


def matches(path: str, pat: str) -> bool:
    path = norm(path)
    pat = norm(str(pat).strip("'\""))
    if not pat:
        return False
    if pat.endswith("/**") and (path == pat[:-3].rstrip("/") or path.startswith(pat[:-3])):
        return True
    return fnmatch.fnmatch(path, pat) or PurePosixPath(path).match(pat)


def parse_args(argv):
    opts = {
        "config": ".dep-tree.yml",
        "only": [],
        "exclude": [],
        "json": False,
        "overlap_left": False,
        "overlap_right": False,
        "render_path": "",
        "no_browser_open": False,
        "python_exclude_conditional": False,
    }
    args = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-c", "--config"):
            i += 1
            opts["config"] = argv[i] if i < len(argv) else opts["config"]
        elif a == "--only":
            i += 1
            if i < len(argv):
                opts["only"].append(argv[i])
        elif a == "--exclude":
            i += 1
            if i < len(argv):
                opts["exclude"].append(argv[i])
        elif a == "--json":
            opts["json"] = True
        elif a in ("-l", "--overlap-left"):
            opts["overlap_left"] = True
        elif a in ("-r", "--overlap-right"):
            opts["overlap_right"] = True
        elif a == "--render-path":
            i += 1
            opts["render_path"] = argv[i] if i < len(argv) else ""
        elif a == "--no-browser-open":
            opts["no_browser_open"] = True
        elif a == "--python-exclude-conditional-imports":
            opts["python_exclude_conditional"] = True
        elif a in ("--unwrap-exports", "--js-tsconfig-paths", "--js-workspaces", "--enable-gui"):
            pass
        else:
            args.append(a)
        i += 1
    return args, opts


def load_config(path: str):
    p = Path(path)
    if not p.exists():
        return {}
    if yaml:
        with p.open() as f:
            return yaml.safe_load(f) or {}
    return {}


class Graph:
    def __init__(self, cwd: Path, opts):
        self.cwd = cwd.resolve()
        self.root = find_root(self.cwd)
        self.opts = opts
        self.config = load_config(opts.get("config", ".dep-tree.yml"))
        self.files = []
        self.by_rel_root = {}
        self.by_rel_cwd = {}
        self.deps = {}
        self.errors = {}
        self.go_module = self._go_module()
        self._discover()
        self._build()

    def _go_module(self):
        p = self.cwd / "go.mod"
        if not p.exists():
            p = self.root / "go.mod"
        if p.exists():
            for line in p.read_text(errors="ignore").splitlines():
                if line.startswith("module "):
                    return line.split(None, 1)[1].strip()
        return ""

    def display(self, p: Path, base=None):
        return rel(p, base or self.root)

    def cwd_rel(self, p: Path):
        return rel(p, self.cwd)

    def _include_file(self, p: Path):
        rr = self.display(p)
        rc = self.cwd_rel(p)
        only = list(self.config.get("only") or []) + self.opts.get("only", [])
        exclude = list(self.config.get("exclude") or []) + self.opts.get("exclude", [])
        if only and not any(matches(rr, pat) or matches(rc, pat) for pat in only):
            return False
        if any(matches(rr, pat) or matches(rc, pat) for pat in exclude):
            return False
        return True

    def _discover(self):
        for p in self.root.rglob("*"):
            if not p.is_file() or p.suffix not in SOURCE_EXTS:
                continue
            parts = set(p.parts)
            if ".git" in parts or "__pycache__" in parts or "node_modules" in parts or ".venv" in parts or "vendor" in parts:
                continue
            if self._include_file(p):
                rp = self.display(p)
                self.files.append(p.resolve())
                self.by_rel_root[rp] = p.resolve()
                self.by_rel_cwd[self.cwd_rel(p)] = p.resolve()
        self.files.sort(key=lambda x: self.display(x))

    def _build(self):
        for p in self.files:
            try:
                imports = self._imports(p)
                deps = []
                for spec in imports:
                    q = self._resolve(p, spec)
                    if q and q in self.files and q != p:
                        deps.append(q)
                self.deps[p] = sorted(set(deps), key=lambda x: self.display(x))
            except Exception as ex:
                self.errors[self.display(p)] = str(ex)
                self.deps[p] = []

    def _imports(self, p: Path):
        ext = p.suffix
        text = p.read_text(errors="ignore")
        if ext == ".py":
            return self._py_imports(p, text)
        if ext in {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"}:
            return self._js_imports(text)
        if ext == ".go":
            return self._go_imports(text)
        if ext == ".rs":
            return self._rs_imports(text)
        return []

    def _py_imports(self, p: Path, text: str):
        try:
            tree = ast.parse(text)
        except SyntaxError:
            return []
        out = []
        exclude_cond = self.opts.get("python_exclude_conditional") or (self.config.get("python") or {}).get("excludeConditionalImports")

        def visit(node, conditional=False):
            cond = conditional or isinstance(node, (ast.If, ast.Try, ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda, ast.ClassDef))
            if isinstance(node, ast.Import) and not (exclude_cond and cond):
                for a in node.names:
                    out.append(("py", 0, a.name, None))
            elif isinstance(node, ast.ImportFrom) and not (exclude_cond and cond):
                names = [a.name for a in node.names if a.name != "*"]
                out.append(("py", node.level, node.module or "", names))
            for ch in ast.iter_child_nodes(node):
                visit(ch, cond)
        visit(tree, False)
        return out

    def _js_imports(self, text: str):
        pats = [
            r"""(?:import|export)\s+(?:[^'"]*?\s+from\s+)?['"]([^'"]+)['"]""",
            r"""require\s*\(\s*['"]([^'"]+)['"]\s*\)""",
            r"""import\s*\(\s*['"]([^'"]+)['"]\s*\)""",
        ]
        out = []
        for pat in pats:
            out.extend(("path", m.group(1)) for m in re.finditer(pat, text, re.M))
        return out

    def _go_imports(self, text: str):
        out = []
        for m in re.finditer(r'import\s+(?:[._\w]+\s+)?\"([^\"]+)\"', text):
            out.append(("go", m.group(1)))
        block = re.search(r'import\s*\((.*?)\)', text, re.S)
        if block:
            for m in re.finditer(r'(?:[._\w]+\s+)?\"([^\"]+)\"', block.group(1)):
                out.append(("go", m.group(1)))
        return out

    def _rs_imports(self, text: str):
        out = []
        for m in re.finditer(r'^\s*(?:pub\s+)?mod\s+([A-Za-z_][A-Za-z0-9_]*)\s*;', text, re.M):
            out.append(("rsmod", m.group(1)))
        for m in re.finditer(r'^\s*use\s+(?:crate|self)::([A-Za-z_][A-Za-z0-9_:]*)', text, re.M):
            out.append(("rsuse", m.group(1).split("::")[0]))
        return out

    def _candidate(self, base: Path, spec: str, exts):
        raw = (base / spec).resolve()
        cands = [raw]
        for ext in exts:
            cands.append(raw.with_suffix(ext))
        for ext in exts:
            cands.append(raw / ("index" + ext))
            cands.append(raw / ("__init__" + ext))
            cands.append(raw / ("mod" + ext))
        for c in cands:
            if c in self.files:
                return c
        return None

    def _resolve(self, p: Path, spec):
        kind = spec[0]
        if kind == "path":
            s = spec[1]
            if s.startswith("."):
                return self._candidate(p.parent, s, [".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"])
            return self._resolve_alias_or_abs(s, [".js", ".jsx", ".ts", ".tsx"])
        if kind == "go":
            s = spec[1]
            if s.startswith("."):
                return self._candidate(p.parent, s, [".go"])
            if self.go_module and s.startswith(self.go_module + "/"):
                s = s[len(self.go_module) + 1:]
            return self._candidate(self.cwd, s, [".go"]) or self._package_main(s)
        if kind == "rsmod":
            return self._candidate(p.parent, spec[1], [".rs"])
        if kind == "rsuse":
            return self._candidate(self.root / "src", spec[1], [".rs"]) or self._candidate(p.parent, spec[1], [".rs"])
        if kind == "py":
            _, level, module, names = spec
            if level:
                base = p.parent
                for _ in range(level - 1):
                    base = base.parent
                mod_path = module.replace(".", "/") if module else ""
                if names:
                    for name in names:
                        found = self._candidate(base, (mod_path + "/" + name).strip("/"), [".py"])
                        if found:
                            return found
                return self._candidate(base, mod_path, [".py"])
            if names:
                for name in names:
                    found = self._candidate(self.cwd, (module + "." + name).replace(".", "/"), [".py"])
                    if found:
                        return found
                found = self._candidate(self.cwd, module.replace(".", "/"), [".py"])
                if found:
                    return found
            return self._candidate(self.cwd, module.replace(".", "/"), [".py"])
        return None

    def _resolve_alias_or_abs(self, s, exts):
        tsconfig = self.root / "tsconfig.json"
        if tsconfig.exists():
            try:
                data = json.loads(tsconfig.read_text(errors="ignore"))
                paths = data.get("compilerOptions", {}).get("paths", {})
                base_url = data.get("compilerOptions", {}).get("baseUrl", ".")
                for pat, repls in paths.items():
                    prefix = pat.split("*", 1)[0]
                    if s.startswith(prefix):
                        rest = s[len(prefix):]
                        for repl in repls:
                            cand = repl.replace("*", rest)
                            q = self._candidate(self.root / base_url, cand, exts)
                            if q:
                                return q
            except Exception:
                pass
        return self._candidate(self.cwd, s, exts) or self._candidate(self.root, s, exts)

    def _package_main(self, s):
        d = self.cwd / s
        if d.exists():
            gos = sorted(d.glob("*.go"))
            return gos[0].resolve() if gos else None
        return None

    def entry(self, arg: str):
        p = (self.cwd / arg).resolve()
        if p in self.files:
            return p
        matches_ = [v for k, v in self.by_rel_cwd.items() if matches(k, arg)]
        return matches_[0] if len(matches_) == 1 else None

    def tree(self, start: Path, base=None):
        seen = set()
        circular = []

        def rec(p, stack):
            if p in stack:
                cyc = stack[stack.index(p):] + [p]
                circular.append([self.display(x, base) for x in cyc])
                return None
            if p in seen:
                return None
            seen.add(p)
            children = {}
            for d in self.deps.get(p, []):
                if d in stack:
                    cyc = stack[stack.index(d):] + [d]
                    circular.append([self.display(x, base) for x in cyc])
                    continue
                children[self.display(d, base)] = rec(d, stack + [p])
            return children or None
        return {self.display(start, base): rec(start, [])}, circular

    def reachable_edges(self, starts):
        seen = set()
        edges = []

        def dfs(p):
            if p in seen:
                return
            seen.add(p)
            for d in self.deps.get(p, []):
                edges.append((p, d))
                dfs(d)
        for s in starts:
            dfs(s)
        return edges

    def circulars(self, starts, base=None):
        out = []
        stack = []
        visiting = set()
        done = set()

        def dfs(p):
            visiting.add(p)
            stack.append(p)
            for d in self.deps.get(p, []):
                if d in visiting:
                    cyc = stack[stack.index(d):] + [d]
                    out.append([self.display(x, base) for x in cyc])
                elif d not in done:
                    dfs(d)
            stack.pop()
            visiting.discard(p)
            done.add(p)
        for s in starts:
            if s not in done:
                dfs(s)
        return out


def run_tree(args, opts):
    if not args:
        eprint("Error: requires at least 1 arg(s), only received 0")
        return 1
    g = Graph(Path.cwd(), opts)
    start = g.entry(args[0])
    if not start:
        eprint(f"Error: {args[0]} does not match with any existing file")
        return 1
    tree, circs = g.tree(start)
    if opts["json"]:
        print(json.dumps({"tree": tree, "circularDependencies": circs, "errors": g.errors}, indent=2))
    else:
        print_tree(tree)
    return 0


def print_tree(t, indent=""):
    for k, v in t.items():
        print(indent + k)
        if isinstance(v, dict):
            print_tree(v, indent + "  ")


def glob_files(g: Graph, pat: str):
    return sorted([p for p in g.files if matches(g.cwd_rel(p), pat) or matches(g.display(p), pat)], key=lambda x: g.display(x))


def run_explain(args, opts):
    if len(args) < 2:
        eprint(f"Error: requires at least 2 arg(s), only received {len(args)}")
        return 1
    g = Graph(Path.cwd(), opts)
    left = set(glob_files(g, args[0]))
    right = set(glob_files(g, args[1]))
    overlap = left & right
    if opts["overlap_left"]:
        right -= overlap
    if opts["overlap_right"]:
        left -= overlap
    if not left or not right:
        eprint("Error: at least 1 file must be provided for inferring the language")
        return 1
    for a in sorted(left, key=lambda x: g.display(x)):
        for b in g.deps.get(a, []):
            if b in right:
                print(f"{g.cwd_rel(a)} -> {g.cwd_rel(b)}")
    return 0


def restriction_patterns(obj):
    reason = ""
    if obj is None:
        return [], reason
    if isinstance(obj, dict):
        reason = str(obj.get("reason", ""))
        obj = obj.get("to", [])
    if isinstance(obj, str):
        return [obj], reason
    if isinstance(obj, list):
        pats = []
        for x in obj:
            if isinstance(x, dict):
                to = x.get("to", [])
                if isinstance(to, list):
                    pats.extend(map(str, to))
                else:
                    pats.append(str(to))
            else:
                pats.append(str(x))
        return pats, reason
    return [], reason


def run_check(args, opts):
    g = Graph(Path.cwd(), opts)
    check = (g.config or {}).get("check") or {}
    entries = check.get("entrypoints") or []
    starts = []
    for ent in entries:
        p = g.entry(str(ent))
        if not p:
            eprint(f"Error: {ent} does not match with any existing file")
            return 1
        starts.append(p)
    if not starts:
        eprint("Error: requires at least 1 entrypoint")
        return 1
    edges = g.reachable_edges(starts)
    aliases = check.get("aliases") or {}

    def expand(pats):
        out = []
        for pat in pats:
            val = aliases.get(pat)
            if isinstance(val, list):
                out.extend(map(str, val))
            else:
                out.append(str(pat))
        return out

    violations = []
    reasons = []
    for a, b in edges:
        ar = g.cwd_rel(a)
        br = g.cwd_rel(b)
        for src_pat, val in (check.get("allow") or {}).items():
            if matches(ar, src_pat):
                pats, reason = restriction_patterns(val)
                pats = expand(pats)
                if pats and not any(matches(br, p) for p in pats):
                    violations.append((ar, br))
                    if reason:
                        reasons.append(reason)
        for src_pat, val in (check.get("deny") or {}).items():
            if matches(ar, src_pat):
                pats, reason = restriction_patterns(val)
                pats = expand(pats)
                if any(matches(br, p) for p in pats):
                    violations.append((ar, br))
                    if reason:
                        reasons.append(reason)
    circs = [] if check.get("allowCircularDependencies") else g.circulars(starts, g.cwd)
    if violations or circs:
        eprint("Error: Check failed, the following dependencies are not allowed:")
        for a, b in sorted(set(violations)):
            eprint(f"- {a} -> {b}")
        if circs:
            eprint("")
            eprint("detected circular dependencies:")
            for c in circs:
                eprint("- " + " -> ".join(c))
        for r in sorted(set(reasons)):
            eprint(r)
        return 1
    return 0


def run_config(opts):
    p = Path(opts.get("config") or ".dep-tree.yml")
    if p.exists():
        eprint(f"Error: config file {p} already exists")
        return 1
    p.write_text(CONFIG_SAMPLE)
    os.chmod(p, 0o600)
    return 0


def run_entropy(args, opts):
    render = opts.get("render_path") or "dep-tree.html"
    html = "<!doctype html><html><head><meta charset='utf-8'><title>dep-tree</title></head><body><h1>dep-tree</h1><pre id='data'></pre></body></html>\n"
    Path(render).write_text(html)
    print(f"Rendered entropy graph at {render}")
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ("-h", "--help", "help"):
        if len(argv) > 1 and argv[0] == "help" and argv[1] in HELP:
            print(HELP[argv[1]] + GLOBAL_FLAGS)
        else:
            print(MAIN_HELP)
        return 0
    if argv[0] in ("-v", "--version"):
        print(VERSION)
        return 0
    cmd = argv.pop(0)
    if cmd not in {"entropy", "tree", "check", "explain", "config", "init"}:
        argv.insert(0, cmd)
        cmd = "entropy"
    if "-h" in argv or "--help" in argv:
        key = "config" if cmd == "init" else cmd
        print(HELP[key] + GLOBAL_FLAGS)
        return 0
    args, opts = parse_args(argv)
    if cmd == "tree":
        return run_tree(args, opts)
    if cmd == "explain":
        return run_explain(args, opts)
    if cmd == "check":
        return run_check(args, opts)
    if cmd in ("config", "init"):
        return run_config(opts)
    if cmd == "entropy":
        return run_entropy(args, opts)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
