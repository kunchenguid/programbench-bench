#!/usr/bin/env python3
import curses
import os
import sys
from pathlib import Path


HELP = """A simple terminal UI for search and replace, ala VS Code

Usage: executable [OPTIONS]

Options:
  -p, --project-root <PATH>  Path to the project root [default: .]
  -h, --help                 Print help
  -V, --version              Print version"""

VERSION = """serpl 0.3.4- (2026-04-20)

Authors: Yassine Bridi <ybridi@gmail.com>

Config directory: {config_dir}"""

IGNORE_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "__pycache__",
    "node_modules",
    "target",
    "build",
    "dist",
}


def config_dir() -> str:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return str(Path(xdg) / "serpl")
    return str(Path.home() / ".config" / "serpl")


def usage_error(message: str) -> int:
    print(f"error: {message}", file=sys.stderr)
    print("", file=sys.stderr)
    print("Usage: executable [OPTIONS]", file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def value_error(flag: str) -> int:
    print(f"error: a value is required for '{flag} <PATH>' but none was supplied", file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def parse_args(argv):
    project_root = "."
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP)
            return None, 0
        if arg in ("-V", "--version"):
            print(VERSION.format(config_dir=config_dir()))
            return None, 0
        if arg in ("-p", "--project-root"):
            if i + 1 >= len(argv):
                return None, value_error("--project-root" if arg == "--project-root" else "-p")
            project_root = argv[i + 1]
            i += 2
            continue
        if arg.startswith("--project-root="):
            project_root = arg.split("=", 1)[1]
            i += 1
            continue
        if arg.startswith("-p="):
            project_root = arg.split("=", 1)[1]
            i += 1
            continue
        return None, usage_error(f"unexpected argument '{arg}' found")
    return Path(project_root), None


def print_runtime_error(message: str) -> int:
    print("serpl error: Something went wrong", file=sys.stderr)
    print("Error: ", file=sys.stderr)
    print(f"   0: \x1b[91m{message}\x1b[0m", file=sys.stderr)
    return 1


def is_probably_text(path: Path) -> bool:
    try:
        with path.open("rb") as f:
            chunk = f.read(4096)
    except OSError:
        return False
    if b"\0" in chunk:
        return False
    return True


def iter_text_files(root: Path):
    root = root.resolve()
    if root.is_file():
        if is_probably_text(root):
            yield root
        return
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in IGNORE_DIRS and not d.startswith(".serpl")]
        for name in filenames:
            path = Path(dirpath) / name
            if path.name == "executable":
                continue
            if is_probably_text(path):
                yield path


def scan(root: Path, needle: str):
    if not needle:
        return []
    matches = []
    for path in iter_text_files(root):
        try:
            text = path.read_text(errors="replace")
        except OSError:
            continue
        count = text.count(needle)
        if count:
            matches.append((path, count))
    return matches


def replace_all(root: Path, needle: str, repl: str):
    changed = 0
    occurrences = 0
    if not needle:
        return changed, occurrences
    for path in iter_text_files(root):
        try:
            text = path.read_text(errors="surrogateescape")
        except (OSError, UnicodeError):
            continue
        count = text.count(needle)
        if not count:
            continue
        try:
            path.write_text(text.replace(needle, repl), errors="surrogateescape")
        except OSError:
            continue
        changed += 1
        occurrences += count
    return changed, occurrences


def draw(stdscr, root, search_text, replace_text, focus, message):
    stdscr.erase()
    h, w = stdscr.getmaxyx()
    title = "serpl - search and replace"
    stdscr.addnstr(0, 0, title, max(0, w - 1), curses.A_BOLD)
    stdscr.addnstr(1, 0, f"Project: {root}", max(0, w - 1))
    fields = [("Search ", search_text), ("Replace", replace_text)]
    y = 3
    for idx, (label, value) in enumerate(fields):
        attr = curses.A_REVERSE if idx == focus else curses.A_NORMAL
        stdscr.addnstr(y + idx, 0, f"{label}: ", max(0, w - 1), curses.A_BOLD)
        stdscr.addnstr(y + idx, 10, value, max(0, w - 11), attr)
    stdscr.addnstr(6, 0, "Tab: switch  Ctrl-O: replace all  Ctrl-R: refresh  Ctrl-B: help  Ctrl-C/Ctrl-D: quit", max(0, w - 1))
    if message:
        stdscr.addnstr(8, 0, message, max(0, w - 1))
    matches = scan(root, search_text)[: max(0, h - 11)]
    stdscr.addnstr(10, 0, "Matches", max(0, w - 1), curses.A_BOLD)
    for row, (path, count) in enumerate(matches, start=11):
        try:
            display = str(path.relative_to(root.resolve()))
        except ValueError:
            display = str(path)
        stdscr.addnstr(row, 0, f"{count:>5}  {display}", max(0, w - 1))
    stdscr.refresh()


def tui(root: Path) -> int:
    root = root.expanduser()
    search_text = ""
    replace_text = ""
    focus = 0
    message = ""

    def run(stdscr):
        nonlocal search_text, replace_text, focus, message
        curses.curs_set(1)
        stdscr.keypad(True)
        while True:
            draw(stdscr, root, search_text, replace_text, focus, message)
            ch = stdscr.get_wch()
            if ch in ("\x03", "\x04"):
                return 0
            if ch == "\t" or ch == curses.KEY_BTAB:
                focus = 1 - focus
                continue
            if ch == "\x12":
                message = "Refreshed"
                continue
            if ch == "\x02":
                message = "Enter search text, replacement text, then press Ctrl-O."
                continue
            if ch == "\x0f":
                files, occ = replace_all(root, search_text, replace_text)
                message = f"Replaced {occ} occurrence(s) in {files} file(s)."
                continue
            target = search_text if focus == 0 else replace_text
            if ch in ("\b", "\x7f") or ch == curses.KEY_BACKSPACE:
                target = target[:-1]
            elif ch in ("\n", "\r"):
                focus = 1 - focus
            elif isinstance(ch, str) and ch.isprintable():
                target += ch
            if focus == 0:
                search_text = target
            else:
                replace_text = target
        return 0

    return curses.wrapper(run)


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    root, early = parse_args(argv)
    if early is not None:
        return early
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        term = os.environ.get("TERM", "")
        if term == "dumb":
            return print_runtime_error("No such device or address (os error 6)")
        return print_runtime_error("Resource temporarily unavailable (os error 11)")
    try:
        return tui(root)
    except Exception as exc:
        return print_runtime_error(str(exc) or "Resource temporarily unavailable (os error 11)")


if __name__ == "__main__":
    raise SystemExit(main())
