#!/usr/bin/env python3
import os
import re
import sys
import termios
import tty


HELP = """Usage: executable [OPTIONS] [FILENAME]

Arguments:
  [FILENAME]  Profile data filename

Options:
      --sorted   Whether to sort the stacks by time spent
      --echo     Print data to stdout on exit. Useful when piping to other tools
      --debug    Show debug info
  -h, --help     Print help
  -V, --version  Print version
"""

VERSION = "flamelens 0.3.1\n"
WOULD_BLOCK = 'Error: Os { code: 11, kind: WouldBlock, message: "Resource temporarily unavailable" }\n'


def usage_error(arg: str, tip: bool) -> int:
    sys.stderr.write(f"error: unexpected argument '{arg}' found\n\n")
    if tip:
        sys.stderr.write(f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n")
    sys.stderr.write("Usage: executable [OPTIONS] [FILENAME]\n\n")
    sys.stderr.write("For more information, try '--help'.\n")
    return 2


def parse_args(argv):
    opts = {"sorted": False, "echo": False, "debug": False}
    filename = None
    positional_mode = False
    i = 0
    while i < len(argv):
        arg = argv[i]
        if not positional_mode and arg == "--":
            positional_mode = True
            i += 1
            continue
        if not positional_mode and arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            raise SystemExit(0)
        if not positional_mode and arg in ("-V", "--version"):
            sys.stdout.write(VERSION)
            raise SystemExit(0)
        if not positional_mode and arg == "--sorted":
            opts["sorted"] = True
        elif not positional_mode and arg == "--echo":
            opts["echo"] = True
        elif not positional_mode and arg == "--debug":
            opts["debug"] = True
        elif not positional_mode and arg.startswith("-"):
            raise SystemExit(usage_error(arg, True))
        else:
            if filename is None:
                filename = arg
            else:
                raise SystemExit(usage_error(arg, False))
        i += 1
    return opts, filename


def panic_read_file(path: str, exc: OSError) -> int:
    code = getattr(exc, "errno", 2) or 2
    if code == 2:
        kind = "NotFound"
        msg = "No such file or directory"
    elif code == 13:
        kind = "PermissionDenied"
        msg = "Permission denied"
    else:
        kind = "Other"
        msg = str(exc)
    sys.stderr.write(
        f"\nthread 'main' ({os.getpid()}) panicked at src/main.rs:44:47:\n"
        f'Could not read file: Os {{ code: {code}, kind: {kind}, message: "{msg}" }}\n'
        "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n"
    )
    return 101


def read_input(filename):
    if filename is not None:
        try:
            with open(filename, "rb") as f:
                return f.read()
        except OSError as e:
            raise RuntimeError(panic_read_file(filename, e))
    return sys.stdin.buffer.read()


def echo_data(data: bytes) -> None:
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.write(b"\n")
    sys.stdout.flush()


def parse_folded(text: str):
    rows = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        m = re.match(r"^(.*)\s+(-?\d+(?:\.\d+)?)$", line)
        if m:
            stack = m.group(1)
            try:
                value = float(m.group(2))
            except ValueError:
                value = 0.0
        else:
            stack = line
            value = 0.0
        frames = [x for x in stack.split(";") if x]
        rows.append((frames, value, raw))
    return rows


def render_tui(data: bytes, sorted_flag: bool, debug: bool) -> int:
    text = data.decode("utf-8", "replace")
    rows = parse_folded(text)
    if sorted_flag:
        rows.sort(key=lambda r: r[1], reverse=True)
    total = sum(v for _, v, _ in rows)
    try:
        width = os.get_terminal_size().columns
    except OSError:
        width = 80
    lines = ["flamelens"]
    if debug:
        lines.append(f"stacks: {len(rows)} total: {total:g}")
    for frames, value, raw in rows[: max(1, min(20, width))]:
        label = frames[-1] if frames else raw
        pct = (value / total * 100.0) if total else 0.0
        bar_len = max(1, min(40, int(pct / 2))) if value else 1
        lines.append(f"{value:g} {pct:5.1f}% {'#' * bar_len} {label}")
    lines.append("q: quit")

    sys.stdout.write("\x1b[?1049h\x1b[?25l\x1b[2J\x1b[H")
    sys.stdout.write("\n".join(line[:width] for line in lines))
    sys.stdout.flush()
    fd = sys.stdin.fileno()
    old = None
    try:
        if sys.stdin.isatty():
            old = termios.tcgetattr(fd)
            tty.setcbreak(fd)
        while True:
            ch = sys.stdin.read(1)
            if ch in ("q", "\x03", ""):
                break
    finally:
        if old is not None:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        sys.stdout.write("\x1b[?1049l\x1b[?1006l\x1b[?1015l\x1b[?1003l\x1b[?1002l\x1b[?1000l\x1b[?25h")
        sys.stdout.flush()
    return 0


def main(argv) -> int:
    try:
        opts, filename = parse_args(argv)
        data = read_input(filename)
    except RuntimeError as e:
        return int(str(e))

    if opts["echo"]:
        echo_data(data)

    if not sys.stdin.isatty() or not sys.stdout.isatty():
        sys.stderr.write(WOULD_BLOCK)
        return 1

    return render_tui(data, opts["sorted"], opts["debug"])


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
