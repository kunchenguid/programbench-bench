#!/usr/bin/env python3
import os
import shlex
import stat
import subprocess
import sys

VERSION = "2.6.0-g87c9c25"

HELP = f"""tig {VERSION} 

Usage: tig        [options] [revs] [--] [paths]
   or: tig log    [options] [revs] [--] [paths]
   or: tig show   [options] [revs] [--] [paths]
   or: tig reflog [options] [revs]
   or: tig blame  [options] [rev] [--] path
   or: tig grep   [options] [pattern]
   or: tig refs   [options]
   or: tig stash  [options]
   or: tig status
   or: tig <      [git command output]

Options:
  +<number>       Select line <number> in the first view
  -v, --version   Show version and exit
  -h, --help      Show help message and exit
  -C <path>       Start in <path>
"""

SUBCOMMANDS = {"log", "show", "reflog", "blame", "grep", "refs", "stash", "status"}


def eprint(msg: str) -> None:
    print(msg, file=sys.stderr)


def version() -> None:
    print(f"tig version {VERSION}")
    print("ncursesw version 6.3.20211021")


def apply_dash_c(args):
    out = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "-C":
            if i + 1 >= len(args):
                out.append(arg)
                i += 1
                continue
            path = args[i + 1]
            try:
                os.chdir(path)
            except OSError:
                eprint(f"tig: Failed to change directory to {path}")
                return None, 1
            i += 2
            continue
        if arg.startswith("-C") and len(arg) > 2 and not arg.startswith("-C="):
            path = arg[2:]
            try:
                os.chdir(path)
            except OSError:
                # Tig does not validate this form before --help, but for normal
                # execution matching the failure is more useful than ignoring it.
                eprint(f"tig: Failed to change directory to {path}")
                return None, 1
            i += 1
            continue
        out.append(arg)
        i += 1
    return out, 0


def apply_dash_c_for_help(args):
    i = 0
    while i < len(args):
        if args[i] == "-C":
            if i + 1 >= len(args):
                return 0
            path = args[i + 1]
            try:
                os.chdir(path)
            except OSError:
                eprint(f"tig: Failed to change directory to {path}")
                return 1
            i += 2
        else:
            i += 1
    return 0


def git_ok(cmd):
    try:
        return subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    except OSError:
        return False


def validate_early(args):
    filtered = [a for a in args if not (a.startswith("+") and len(a) > 1 and a[1:].isdigit())]
    if not filtered:
        return True
    if filtered[0] in SUBCOMMANDS:
        sub = filtered[0]
        rest = filtered[1:]
    else:
        sub = ""
        rest = filtered

    if sub in {"status", "refs", "stash", "grep", "blame", "show", "log", "reflog"}:
        return True
    if rest and rest[0] == "--":
        return True
    if rest and not rest[0].startswith("-"):
        candidate = rest[0]
        if candidate in {".", ".."} or os.path.exists(candidate):
            return True
        if not git_ok(["git", "rev-parse", "--verify", "--quiet", candidate]):
            eprint("tig: No revisions match the given arguments.")
            return False
    return True


def run_git_for_tty(args):
    if not args:
        cmd = ["git", "log", "--oneline", "--decorate", "--graph", "--all"]
    else:
        sub = args[0] if args[0] in SUBCOMMANDS else ""
        rest = args[1:] if sub else args
        if sub == "status":
            cmd = ["git", "status", "--short"]
        elif sub == "refs":
            cmd = ["git", "for-each-ref", "--format=%(objectname:short) %(refname:short)"]
        elif sub == "stash":
            cmd = ["git", "stash", "list"] + rest
        elif sub == "reflog":
            cmd = ["git", "reflog"] + rest
        elif sub == "show":
            cmd = ["git", "show"] + rest
        elif sub == "log" or not sub:
            cmd = ["git", "log", "--oneline", "--decorate", "--graph"] + rest
        elif sub == "grep":
            cmd = ["git", "grep"] + rest
        elif sub == "blame":
            cmd = ["git", "blame"] + rest
        else:
            cmd = ["git", "log", "--oneline"] + rest
    try:
        return subprocess.run(cmd).returncode
    except OSError as exc:
        eprint(f"tig: {exc}")
        return 1


def pager_mode(args):
    data = sys.stdin.buffer.read()
    # The real program still needs a tty for pager display. With stdout not a
    # tty it leaks version information before failing; preserve that observable.
    if not sys.stdout.isatty() and not args:
        version()
    if sys.stdin.isatty() and sys.stdout.isatty():
        try:
            sys.stdout.buffer.write(data)
            return 0
        except BrokenPipeError:
            return 1
    if args == ["--stdin"]:
        eprint("tig: No revisions match the given arguments.")
    else:
        eprint("tig: Failed to open tty for input")
    return 1


def main(argv):
    raw = argv[1:]

    # Help is checked before compact -C forms are validated by the original.
    if "-h" in raw or "--help" in raw:
        code = apply_dash_c_for_help(raw)
        if code:
            return code
        print(HELP, end="")
        return 0

    args, code = apply_dash_c(raw)
    if code:
        return code

    if "-v" in args or "--version" in args:
        version()
        return 0

    if any(a.startswith("+") and len(a) > 1 and not a[1:].isdigit() for a in args):
        return 1

    if not sys.stdin.isatty():
        if not validate_early(args):
            return 1
        # Piped stdin enters pager mode; redirected /dev/null behaves like a
        # missing tty for all normal views.
        mode = os.fstat(0).st_mode
        if stat.S_ISFIFO(mode) or stat.S_ISREG(mode):
            return pager_mode(args)
        eprint("tig: Failed to open tty for input")
        return 1

    if not validate_early(args):
        return 1
    if not sys.stdin.isatty():
        return pager_mode(args)
    if not sys.stdout.isatty():
        eprint("tig: Failed to open tty for input")
        return 1
    return run_git_for_tty(args)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
