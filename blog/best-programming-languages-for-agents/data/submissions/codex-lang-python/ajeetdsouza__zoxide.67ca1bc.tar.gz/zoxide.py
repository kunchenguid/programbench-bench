#!/usr/bin/env python3
import fnmatch
import math
import os
import shlex
import struct
import subprocess
import sys
import time
from pathlib import Path

VERSION = "0.9.9"
HEADER_VERSION = 3
SHELLS = {"bash", "elvish", "fish", "nushell", "posix", "powershell", "tcsh", "xonsh", "zsh"}
HOOKS = {"none", "prompt", "pwd"}


def eprint(*args):
    print(*args, file=sys.stderr)


def data_dir():
    if os.environ.get("_ZO_DATA_DIR"):
        return Path(os.environ["_ZO_DATA_DIR"])
    xdg = os.environ.get("XDG_DATA_HOME")
    if xdg:
        return Path(xdg) / "zoxide"
    return Path.home() / ".local" / "share" / "zoxide"


def db_path():
    return data_dir() / "db.zo"


def read_db():
    p = db_path()
    if not p.exists():
        return []
    b = p.read_bytes()
    if len(b) < 12:
        return []
    try:
        ver, count = struct.unpack_from("<IQ", b, 0)
    except struct.error:
        return []
    if ver != HEADER_VERSION:
        return []
    off = 12
    out = []
    for _ in range(count):
        if off + 8 > len(b):
            break
        n = struct.unpack_from("<Q", b, off)[0]
        off += 8
        raw = b[off:off + n]
        off += n
        if off + 16 > len(b):
            break
        score = struct.unpack_from("<d", b, off)[0]
        off += 8
        ts = struct.unpack_from("<q", b, off)[0]
        off += 8
        try:
            path = raw.decode()
        except UnicodeDecodeError:
            path = raw.decode(errors="replace")
        out.append({"path": path, "score": float(score), "time": int(ts)})
    return out


def write_db(entries):
    p = db_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    parts = [struct.pack("<IQ", HEADER_VERSION, len(entries))]
    for ent in entries:
        raw = ent["path"].encode()
        parts.append(struct.pack("<Q", len(raw)))
        parts.append(raw)
        parts.append(struct.pack("<d", float(ent["score"])))
        parts.append(struct.pack("<q", int(ent["time"])))
    tmp = p.with_suffix(".zo.tmp")
    tmp.write_bytes(b"".join(parts))
    tmp.replace(p)


def canonical(path):
    s = os.fspath(path)
    if os.environ.get("_ZO_RESOLVE_SYMLINKS") == "1":
        return os.path.realpath(s)
    return os.path.abspath(s)


def is_excluded(path):
    pats = os.environ.get("_ZO_EXCLUDE_DIRS")
    if pats is None:
        pats = str(Path.home())
    if not pats:
        return False
    for pat in pats.split(os.pathsep):
        if pat and fnmatch.fnmatch(path, os.path.expanduser(pat)):
            return True
    return False


def age_entries(entries):
    try:
        maxage = float(os.environ.get("_ZO_MAXAGE", "10000"))
    except ValueError:
        maxage = 10000.0
    total = sum(max(0.0, e["score"]) for e in entries)
    if maxage > 0 and total > maxage:
        factor = maxage * 0.9 / total
        for e in entries:
            e["score"] *= factor
        entries[:] = [e for e in entries if e["score"] >= 1.0]


def cmd_add(argv):
    score = 1.0
    paths = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            paths.extend(argv[i + 1:])
            break
        if a in ("-s", "--score"):
            i += 1
            if i >= len(argv):
                return usage_error("a value is required for '--score <SCORE>'")
            try:
                score = float(argv[i])
            except ValueError:
                eprint(f"error: invalid value '{argv[i]}' for '--score <SCORE>'")
                return 2
        elif a.startswith("--score="):
            try:
                score = float(a.split("=", 1)[1])
            except ValueError:
                eprint(f"error: invalid value '{a.split('=',1)[1]}' for '--score <SCORE>'")
                return 2
        elif a in ("-h", "--help"):
            print_help("add")
            return 0
        elif a in ("-V", "--version"):
            print("zoxide-add", VERSION)
            return 0
        else:
            paths.append(a)
        i += 1
    if not paths:
        eprint("error: the following required arguments were not provided:\n  <PATHS>...\n\nUsage: executable add <PATHS>...\n\nFor more information, try '--help'.")
        return 2
    entries = read_db()
    now = int(time.time())
    by_path = {e["path"]: e for e in entries}
    for p in paths:
        cp = canonical(p)
        if not os.path.isdir(cp):
            eprint(f"zoxide: not a directory: {p}")
            return 1
        if is_excluded(cp):
            continue
        if cp in by_path:
            by_path[cp]["score"] += score
            by_path[cp]["time"] = now
        else:
            ent = {"path": cp, "score": score, "time": now}
            entries.append(ent)
            by_path[cp] = ent
    age_entries(entries)
    write_db(entries)
    return 0


def cmd_remove(argv):
    paths = []
    for a in argv:
        if a == "--":
            continue
        if a in ("-h", "--help"):
            print_help("remove")
            return 0
        if a in ("-V", "--version"):
            print("zoxide-remove", VERSION)
            return 0
        paths.append(a)
    entries = read_db()
    if not paths:
        live = [e for e in entries if os.path.isdir(e["path"])]
        if len(live) != len(entries):
            write_db(live)
        return 0
    removed = False
    for p in paths:
        cp = canonical(p)
        before = len(entries)
        entries = [e for e in entries if e["path"] != cp]
        if len(entries) == before:
            eprint(f"zoxide: path not found in database: {p}")
            return 1
        removed = True
    if removed:
        write_db(entries)
    return 0


def frecency(ent):
    age = time.time() - ent["time"]
    if age < 3600:
        mult = 4.0
    elif age < 86400:
        mult = 2.0
    elif age < 604800:
        mult = 0.5
    else:
        mult = 0.25
    return ent["score"] * mult


def keyword_match(path, kw, is_last=True):
    lp = path.lower()
    lk = kw.lower()
    if kw.endswith("/"):
        prefix = lk[:-1]
        return any(part.lower().startswith(prefix) for part in path.split(os.sep) if part)
    if os.sep in kw:
        return lp == os.path.abspath(os.path.expanduser(kw)).lower()
    if is_last:
        return lk in os.path.basename(lp)
    return lk in lp


def all_match(path, kws):
    return all(keyword_match(path, k, i == len(kws) - 1) for i, k in enumerate(kws))


def match_score(ent, kws):
    return frecency(ent)


def cmd_query(argv):
    show_all = False
    interactive = False
    list_mode = False
    score_mode = False
    exclude = None
    base_dir = None
    kws = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            kws.extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            print_help("query")
            return 0
        if a in ("-V", "--version"):
            print("zoxide-query", VERSION)
            return 0
        if a.startswith("-") and a != "-":
            if a == "--exclude":
                i += 1
                exclude = canonical(argv[i]) if i < len(argv) else ""
            elif a.startswith("--exclude="):
                exclude = canonical(a.split("=", 1)[1])
            elif a == "--base-dir":
                i += 1
                base_dir = canonical(argv[i]) if i < len(argv) else ""
            elif a.startswith("--base-dir="):
                base_dir = canonical(a.split("=", 1)[1])
            elif a in ("-a", "--all"):
                show_all = True
            elif a in ("-i", "--interactive"):
                interactive = True
            elif a in ("-l", "--list"):
                list_mode = True
            elif a in ("-s", "--score"):
                score_mode = True
            elif a.startswith("-") and not a.startswith("--"):
                for ch in a[1:]:
                    if ch == "a":
                        show_all = True
                    elif ch == "i":
                        interactive = True
                    elif ch == "l":
                        list_mode = True
                    elif ch == "s":
                        score_mode = True
                    else:
                        eprint(f"error: unexpected argument '-{ch}' found")
                        return 2
            else:
                eprint(f"error: unexpected argument '{a}' found")
                return 2
        else:
            kws.append(a)
        i += 1
    entries = read_db()
    candidates = []
    for e in entries:
        p = e["path"]
        if exclude and p == exclude:
            continue
        if base_dir and not (p == base_dir or p.startswith(base_dir.rstrip(os.sep) + os.sep)):
            continue
        if not show_all and not os.path.isdir(p):
            continue
        if kws and not all_match(p, kws):
            continue
        candidates.append(e)
    if not candidates:
        eprint("zoxide: no match found")
        return 1
    candidates.sort(key=lambda e: (match_score(e, kws), e["time"], e["path"]), reverse=True)
    if interactive:
        fzf = os.environ.get("_ZO_FZF_OPTS", "")
        lines = "\n".join(e["path"] for e in candidates) + "\n"
        try:
            proc = subprocess.run(["fzf"] + shlex.split(fzf), input=lines, text=True, stdout=subprocess.PIPE)
            if proc.returncode == 0 and proc.stdout.strip():
                print(proc.stdout.rstrip("\n"))
                return 0
        except FileNotFoundError:
            pass
        print(candidates[0]["path"])
        return 0
    out = candidates if list_mode or score_mode else candidates[:1]
    for e in out:
        if score_mode:
            print(f"{frecency(e):6.1f} {e['path']}")
        else:
            print(e["path"])
    return 0


def cmd_import(argv):
    fmt = None
    merge = False
    path = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print_help("import")
            return 0
        if a in ("-V", "--version"):
            print("zoxide-import", VERSION)
            return 0
        if a == "--merge":
            merge = True
        elif a == "--from":
            i += 1
            fmt = argv[i] if i < len(argv) else None
        elif a.startswith("--from="):
            fmt = a.split("=", 1)[1]
        elif a == "--":
            if i + 1 < len(argv):
                path = argv[i + 1]
            break
        else:
            path = a
        i += 1
    if fmt not in ("autojump", "z"):
        eprint("error: the following required arguments were not provided:\n  --from <FROM>")
        return 2
    if not path:
        eprint("error: the following required arguments were not provided:\n  <PATH>")
        return 2
    entries = read_db() if merge else []
    by = {e["path"]: e for e in entries}
    try:
        lines = Path(path).read_text(errors="replace").splitlines()
    except OSError as ex:
        eprint(f"zoxide: {ex}")
        return 1
    for line in lines:
        if not line.strip():
            continue
        try:
            if fmt == "z":
                p, sc, ts = line.rsplit("|", 2)
            else:
                # autojump commonly stores: path<TAB>weight<TAB>time
                parts = line.replace("\t", " ").split()
                if len(parts) >= 3:
                    p, sc, ts = " ".join(parts[:-2]), parts[-2], parts[-1]
                elif len(parts) == 2:
                    p, sc, ts = parts[0], parts[1], int(time.time())
                else:
                    continue
            cp = canonical(os.path.expanduser(p))
            ent = {"path": cp, "score": float(sc), "time": int(float(ts))}
            if cp in by:
                by[cp].update(ent)
            else:
                entries.append(ent)
                by[cp] = ent
        except Exception:
            continue
    write_db(entries)
    return 0


def cmd_edit(argv):
    if any(a in ("-h", "--help") for a in argv):
        print_help("edit")
        return 0
    if any(a in ("-V", "--version") for a in argv):
        print("zoxide-edit", VERSION)
        return 0
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL")
    if not editor:
        eprint("zoxide: EDITOR not set")
        return 1
    return subprocess.call(shlex.split(editor) + [str(db_path())])


def init_script(shell, cmd="z", hook="pwd", no_cmd=False):
    zi = cmd + "i"
    lines = [
        "# Code generated by zoxide. DO NOT EDIT.",
        "",
        f"# shell: {shell}",
        "__zoxide_pwd() { command pwd -L; }",
        "__zoxide_cd() { command cd \"$@\"; }",
    ]
    if hook != "none":
        lines += [
            "__zoxide_hook() { command zoxide add -- \"$(__zoxide_pwd)\"; }",
        ]
        if shell in ("bash", "posix"):
            lines.append("PROMPT_COMMAND=\"${PROMPT_COMMAND:+$PROMPT_COMMAND;}__zoxide_hook\"")
        elif shell == "zsh":
            lines.append("chpwd_functions+=(__zoxide_hook)")
        elif shell == "fish":
            aliases = "" if no_cmd else f"alias {cmd}=__zoxide_z\nalias {zi}=__zoxide_zi"
            return f"""# Code generated by zoxide. DO NOT EDIT.
function __zoxide_pwd
    builtin pwd -L
end
function __zoxide_z
    set -l result (command zoxide query --exclude (__zoxide_pwd) -- $argv)
    and cd $result
end
function __zoxide_zi
    set -l result (command zoxide query --interactive -- $argv)
    and cd $result
end
{aliases}
"""
    lines += [
        "__zoxide_z() {",
        "    if [ \"$#\" -eq 0 ]; then __zoxide_cd ~; elif [ \"$#\" -eq 1 ] && [ -d \"$1\" ]; then __zoxide_cd \"$1\"; else",
        "        __zoxide_result=\"$(command zoxide query --exclude \"$(__zoxide_pwd)\" -- \"$@\")\" && __zoxide_cd \"$__zoxide_result\"",
        "    fi",
        "}",
        "__zoxide_zi() { __zoxide_result=\"$(command zoxide query --interactive -- \"$@\")\" && __zoxide_cd \"$__zoxide_result\"; }",
    ]
    if not no_cmd:
        lines += [f"{cmd}() {{ __zoxide_z \"$@\"; }}", f"{zi}() {{ __zoxide_zi \"$@\"; }}"]
    return "\n".join(lines) + "\n"


def cmd_init(argv):
    no_cmd = False
    cmd = "z"
    hook = "pwd"
    shell = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print_help("init")
            return 0
        if a in ("-V", "--version"):
            print("zoxide-init", VERSION)
            return 0
        if a == "--no-cmd":
            no_cmd = True
        elif a == "--cmd":
            i += 1
            cmd = argv[i] if i < len(argv) else "z"
        elif a.startswith("--cmd="):
            cmd = a.split("=", 1)[1]
        elif a == "--hook":
            i += 1
            hook = argv[i] if i < len(argv) else "pwd"
        elif a.startswith("--hook="):
            hook = a.split("=", 1)[1]
        else:
            shell = a
        i += 1
    if shell not in SHELLS:
        eprint(f"error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nFor more information, try '--help'.")
        return 2
    if hook not in HOOKS:
        eprint(f"error: invalid value '{hook}' for '--hook <HOOK>'\n  [possible values: none, prompt, pwd]\n\nFor more information, try '--help'.")
        return 2
    print(init_script(shell, cmd, hook, no_cmd), end="")
    return 0


def print_help(cmd=None):
    env = """Environment variables:
  _ZO_DATA_DIR          Path for zoxide data files
  _ZO_ECHO              Print the matched directory before navigating to it when set to 1
  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded
  _ZO_FZF_OPTS          Custom flags to pass to fzf
  _ZO_MAXAGE            Maximum total age after which entries start getting deleted
  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths"""
    if cmd is None:
        print(f"""zoxide {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

A smarter cd command for your terminal

Usage:
  executable <COMMAND>

Commands:
  add     Add a new directory or increment its rank
  edit    Edit the database
  import  Import entries from another application
  init    Generate shell configuration
  query   Search for a directory in the database
  remove  Remove a directory from the database

Options:
  -h, --help     Print help
  -V, --version  Print version

{env}""")
    elif cmd == "add":
        print(f"""zoxide-add {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Add a new directory or increment its rank

Usage:
  executable add [OPTIONS] <PATHS>...

Arguments:
  <PATHS>...  

Options:
  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't
  -h, --help           Print help
  -V, --version        Print version

{env}""")
    elif cmd == "query":
        print(f"""zoxide-query {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Search for a directory in the database

Usage:
  executable query [OPTIONS] [KEYWORDS]...

Arguments:
  [KEYWORDS]...  

Options:
  -a, --all              Show unavailable directories
  -i, --interactive      Use interactive selection
  -l, --list             List all matching directories
  -s, --score            Print score with results
      --exclude <path>   Exclude the current directory
      --base-dir <path>  Only search within this directory
  -h, --help             Print help
  -V, --version          Print version

{env}""")
    elif cmd == "init":
        print(f"""zoxide-init {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Generate shell configuration

Usage:
  executable init [OPTIONS] <SHELL>

Arguments:
  <SHELL>  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]

Options:
      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands
      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]
      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]
  -h, --help         Print help
  -V, --version      Print version

{env}""")
    elif cmd == "import":
        print(f"""zoxide-import {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Import entries from another application

Usage:
  executable import [OPTIONS] --from <FROM> <PATH>

Arguments:
  <PATH>  

Options:
      --from <FROM>  Application to import from [possible values: autojump, z]
      --merge        Merge into existing database
  -h, --help         Print help
  -V, --version      Print version

{env}""")
    elif cmd == "remove":
        print(f"""zoxide-remove {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Remove a directory from the database

Usage:
  executable remove [PATHS]...

Arguments:
  [PATHS]...  

Options:
  -h, --help     Print help
  -V, --version  Print version

{env}""")
    elif cmd == "edit":
        print(f"""zoxide-edit {VERSION}
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

Edit the database

Usage:
  executable edit

Options:
  -h, --help     Print help
  -V, --version  Print version

{env}""")


def usage_error(msg):
    eprint("error:", msg)
    return 2


def main():
    argv = sys.argv[1:]
    if not argv:
        print_help()
        return 2
    if argv[0] in ("-h", "--help"):
        print_help()
        return 0
    if argv[0] in ("-V", "--version"):
        print("zoxide", VERSION)
        return 0
    cmd, rest = argv[0], argv[1:]
    if cmd == "add":
        return cmd_add(rest)
    if cmd == "remove":
        return cmd_remove(rest)
    if cmd == "query":
        return cmd_query(rest)
    if cmd == "import":
        return cmd_import(rest)
    if cmd == "init":
        return cmd_init(rest)
    if cmd == "edit":
        return cmd_edit(rest)
    eprint(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
