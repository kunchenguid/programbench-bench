#!/usr/bin/env python3
import sys, os, re, fnmatch, difflib
from pathlib import Path

VERSION='statix 0.5.8'
LINTS=[('W01','bool_comparison'),('W02','empty_let_in'),('W03','manual_inherit'),('W04','manual_inherit_from'),('W05','legacy_let_syntax'),('W06','collapsible_let_in'),('W07','eta_reduction'),('W08','useless_parens'),('W10','empty_pattern'),('W11','redundant_pattern_bind'),('W12','unquoted_uri'),('W14','empty_inherit'),('W17','deprecated_to_path'),('W18','bool_simplification'),('W19','useless_has_attr'),('W20','repeated_keys'),('W23','empty_list_concat')]
NAMES=dict(LINTS)
MESSAGES={
 'W01':'Unnecessary comparison with boolean','W02':'Useless let-in expression','W03':'Assignment instead of inherit','W04':'Assignment instead of inherit from','W05':'Legacy let syntax','W06':'Collapsible let-in expression','W07':'Eta reduction','W08':'Useless parentheses','W10':'Empty pattern','W11':'Redundant pattern bind','W12':'Unquoted URI','W14':'Empty inherit','W17':'Deprecated toPath','W18':'Boolean simplification','W19':'Useless hasAttr','W20':'Repeated keys','W23':'Empty list concatenation'}
DETAIL={
 'W01':lambda m: f"Comparing `{m.get('expr','expression')}` with boolean literal `{m.get('lit','true')}`",
 'W02':lambda m:'This let-in expression has no entries',
 'W03':lambda m:'This assignment is better written with `inherit`',
 'W04':lambda m:'This assignment is better written with `inherit`',
 'W05':lambda m:'Prefer `rec` over undocumented `let` syntax',
 'W06':lambda m:'This `let in` expression contains a nested `let in` expression',
 'W07':lambda m:f"Found eta-reduction: `{m.get('func','')}`",
 'W08':lambda m:m.get('detail','Useless parentheses'),
 'W10':lambda m:'This pattern is empty, use `_` instead',
 'W11':lambda m:f"This pattern bind is redundant, use `{m.get('name','argument')}` instead",
 'W12':lambda m:'Consider quoting this URI expression',
 'W14':lambda m:'Remove this empty `inherit` statement',
 'W17':lambda m:'`builtins.toPath` is deprecated, see `:doc builtins.toPath` within the REPL for more',
 'W18':lambda m:f"Try `{m.get('op','!=')}` instead of `!(... {m.get('old','==')} ...)`",
 'W19':lambda m:f"Consider using `{m.get('rep','')}` instead of this `if` expression",
 'W20':lambda m:m.get('detail','Repeated key'),
 'W23':lambda m:'Concatenation with the empty list, `[]`, is a no-op',
}
EXPLAINS={
'W01':'''## What it does\nChecks for expressions of the form `x == true`, `x != true` and\nsuggests using the variable directly.\n\n## Why is this bad?\nUnnecessary code.\n\n## Example\nInstead of checking the value of `x`:\n\n```nix\nif x == true then 0 else 1\n```\n\nUse `x` directly:\n\n```nix\nif x then 0 else 1\n```''',
'W02':'''## What it does\nChecks for `let-in` expressions which create no new bindings.\n\n## Why is this bad?\n`let-in` expressions that create no new bindings are useless.\nThese are probably remnants from debugging or editing expressions.\n\n## Example\n\n```nix\nlet in pkgs.statix\n```\n\nPreserve only the body of the `let-in` expression:\n\n```nix\npkgs.statix\n```''',
'W03':'''## What it does\nChecks for bindings of the form `a = a`.\n\n## Why is this bad?\nIf the aim is to bring attributes from a larger scope into\nthe current scope, prefer an inherit statement.''',
'W04':'''## What it does\nChecks for bindings of the form `a = someAttr.a`.\n\n## Why is this bad?\nIf the aim is to extract or bring attributes of an attrset into\nscope, prefer an inherit statement.''',
'W05':'''## What it does\nChecks for legacy-let syntax that was never formalized.\n\n## Why is this bad?\nThis syntax construct is undocumented, refrain from using it.''',
'W06':'''## What it does\nChecks for `let-in` expressions whose body is another `let-in`\nexpression.\n\n## Why is this bad?\nUnnecessary code, the `let-in` expressions can be merged.''',
'W07':'''## What it does\nChecks for eta-reducible functions, i.e.: converts lambda\nexpressions into free standing functions where applicable.''',
'W08':'''## What it does\nChecks for unnecessary parentheses.\n\n## Why is this bad?\nUnnecessarily parenthesized code is hard to read.''',
'W10':'''## What it does\nChecks for an empty variadic pattern: `{...}`, in a function\nargument.''',
'W11':'''## What it does\nChecks for binds of the form `inputs @ { ... }` in function\narguments.''',
'W12':'''## What it does\nChecks for URI expressions that are not quoted.\n\n## Why is this bad?\nThe Nix language has a special syntax for URLs even though quoted\nstrings can also be used to represent them.''',
'W14':'''## What it does\nChecks for empty inherit statements.\n\n## Why is this bad?\nUseless code, probably the result of a refactor.''',
'W17':'''## What it does\nChecks for usage of the `toPath` function.\n\n## Why is this bad?\n`toPath` is deprecated.''',
'W18':'''## What it does\nChecks for boolean expressions that can be simplified.\n\n## Why is this bad?\nComplex booleans affect readibility.''',
'W19':'''## What it does\nChecks for expressions that use the "has attribute" operator: `?`,\nwhere the `or` operator would suffice.''',
'W20':'''## What it does\nChecks for keys in attribute sets with repetitive keys, and suggests using\nan attribute set instead.''',
'W23':'''## What it does\nChecks for concatenations to empty lists\n\n## Why is this bad?\nConcatenation with the empty list is a no-op.'''
}

def help_main(): print('''statix 0.5.8\n\nAkshay <nerdy@peppe.rs>\n\nLints and suggestions for the Nix programming language\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nOPTIONS:\n    -h, --help       Print help information\n    -V, --version    Print version information\n\nSUBCOMMANDS:\n    check      Lints and suggestions for the nix programming language\n    dump       Dump a sample config to stdout\n    explain    Print detailed explanation for a lint warning\n    fix        Find and fix issues raised by statix-check\n    help       Print this message or the help of the given subcommand(s)\n    list       List all available lints\n    single     Fix exactly one issue at provided position''')

def help_sub(s):
    texts={
'check':'''executable-check \n\nLints and suggestions for the nix programming language\n\nUSAGE:\n    executable check [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run check on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -o, --format <FORMAT>       Output format. Supported values: stderr, errfmt [default: stderr]\n    -s, --stdin                 Enable "streaming" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files''',
'fix':'''executable-fix \n\nFind and fix issues raised by statix-check\n\nUSAGE:\n    executable fix [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run fix on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run               Do not fix files in place, display a diff instead\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -s, --stdin                 Enable "streaming" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files''',
'single':'''executable-single \n\nFix exactly one issue at provided position\n\nUSAGE:\n    executable single [OPTIONS] --position <POSITION> [TARGET]\n\nARGS:\n    <TARGET>    File to run single-fix on\n\nOPTIONS:\n    -c, --config <CONF_PATH>     Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run                Do not fix files in place, display a diff instead\n    -h, --help                   Print help information\n    -p, --position <POSITION>    Position to attempt a fix at\n    -s, --stdin                  Enable "streaming" mode, accept file on stdin, output diagnostics\n                                 on stdout''',
'dump':'executable-dump \n\nDump a sample config to stdout\n\nUSAGE:\n    executable dump\n\nOPTIONS:\n    -h, --help    Print help information',
'list':'executable-list \n\nList all available lints\n\nUSAGE:\n    executable list\n\nOPTIONS:\n    -h, --help    Print help information',
'explain':'executable-explain \n\nPrint detailed explanation for a lint warning\n\nUSAGE:\n    executable explain <TARGET>\n\nARGS:\n    <TARGET>    Warning code to explain\n\nOPTIONS:\n    -h, --help    Print help information'}
    print(texts[s])

def linecol(text, idx):
    line=text.count('\n',0,idx)+1
    last=text.rfind('\n',0,idx)
    return line, idx-(last+1)+1

def disabled_from(conf):
    path=Path(conf or '.')
    if path.is_dir(): path=path/'statix.toml'
    disabled=set(); ignores=['.direnv']
    try: data=path.read_text()
    except Exception: return disabled, ignores
    for key,target in [('disabled',disabled),('ignore',ignores)]:
        m=re.search(r'(?m)^\s*'+key+r'\s*=\s*\[(.*?)\]',data,re.S)
        if m:
            vals=re.findall(r'["\']([^"\']+)["\']',m.group(1))
            if key=='disabled': disabled.update(v.upper() if v.upper().startswith('W') else v for v in vals)
            else: ignores=list(vals)
    return disabled, ignores

def detect(text):
    ds=[]
    def add(code,start,end=None,**meta):
        ln,col=linecol(text,start); ds.append({'code':code,'start':start,'end':end or start,'line':ln,'col':col,'meta':meta})
    for m in re.finditer(r'(?m)^\s*let\s*\{',text): add('W05',m.start())
    for m in re.finditer(r'(?<![\w.])([A-Za-z_][\w.-]*)\s*(==|!=)\s*(true|false)\b',text): add('W01',m.start(),m.end(),expr=m.group(1),lit=m.group(3))
    for m in re.finditer(r'\blet\s+in\s+',text): add('W02',m.start(),m.end())
    for m in re.finditer(r'(?m)^(\s*)([A-Za-z_][\w-]*)\s*=\s*\2\s*;',text): add('W03',m.start(2),m.end(),name=m.group(2))
    for m in re.finditer(r'(?m)^(\s*)([A-Za-z_][\w-]*)\s*=\s*([A-Za-z_][\w-]*(?:\.[A-Za-z_][\w-]*)*)\.\2\s*;',text): add('W04',m.start(2),m.end(),name=m.group(2),base=m.group(3))
    for m in re.finditer(r'\bin\s*\n\s*let\b',text): add('W06',m.start(),m.end())
    for m in re.finditer(r'\b([A-Za-z_][\w-]*)\s*:\s*([A-Za-z_][\w.-]*)\s+\1\b',text): add('W07',m.start(),m.end(),func=m.group(2))
    for m in re.finditer(r'=\s*\(([^()\n;]+:[^()\n;]+)\)\s*;',text): add('W08',m.start(1)-1,m.end(1)+1,detail='Useless parentheses around value in binding')
    for m in re.finditer(r'\bmap\s+\(([A-Za-z_][\w.-]*)\)',text): add('W08',m.start(1)-1,m.end(1)+1,detail='Useless parentheses around primitive expression')
    for m in re.finditer(r'(?m)^\s*\(([^()\n]+)\)\s*$',text): add('W08',m.start(1)-1,m.end(1)+1,detail='Useless parentheses around body of `let` expression')
    for m in re.finditer(r'\{\s*\.\.\.\s*\}\s*:',text): add('W10',m.start(),m.end())
    for m in re.finditer(r'\b([A-Za-z_][\w-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:',text): add('W11',m.start(),m.end(),name=m.group(1))
    for m in re.finditer(r'(?m)^\s*inherit\s*;',text): add('W14',m.start(),m.end())
    for m in re.finditer(r'\bbuiltins\.toPath\b',text): add('W17',m.start(),m.end())
    for m in re.finditer(r'!\s*\(\s*([^()]+?)\s*(==|!=)\s*([^()]+?)\s*\)',text): add('W18',m.start(),m.end(),old=m.group(2),op='!=' if m.group(2)=='==' else '==')
    for m in re.finditer(r'if\s+([A-Za-z_][\w.-]*)\s*\?\s*([A-Za-z_][\w-]*)\s+then\s+\1\.\2\s+else\s+([^;\n]+)',text): add('W19',m.start(),m.end(),rep=f'{m.group(1)}.{m.group(2)} or {m.group(3).strip()}')
    prefixes={}
    for m in re.finditer(r'(?m)^\s*([A-Za-z_][\w-]*)\.([A-Za-z_][\w-]*)\s*=',text): prefixes.setdefault(m.group(1),[]).append(m)
    for k,ms in prefixes.items():
        if len(ms)>=3:
            for i,m in enumerate(ms): add('W20',m.start(1),m.end(2),detail=(f'The key `{k}` is first assigned here ...' if i==0 else ('... repeated here ...' if i<len(ms)-1 else f'... and here. Try `{k} = {{ ' + '; '.join(x.group(2)+'=...' for x in ms) + '; }` instead.')))
    for m in re.finditer(r'\[\s*\]\s*\+\+\s*([^;\n]+)|(\S[^;\n=]*?)\s*\+\+\s*\[\s*\]',text): add('W23',m.start(),m.end())
    for m in re.finditer(r'(?<!["\w/])([A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_./?=&%+-]+)',text):
        if m.group(1).split(':',1)[0] not in ('if','then','else'): add('W12',m.start(1),m.end(1))
    return sorted(ds,key=lambda d:(d['start'],d['code']))

def apply_fixes(text, only=None):
    original=text
    def allowed(code,start,end): return only is None or (only[0] <= linecol(original,start)[0] <= only[0] and start <= only[2] <= end+1)
    # line based first
    new=[]; idx=0
    for line in text.splitlines(True):
        start=idx; idx+=len(line); rep=line
        m=re.match(r'^(\s*)([A-Za-z_][\w-]*)\s*=\s*\2\s*;([ \t]*\n?)$',line)
        if m and allowed('W03',start+m.start(2),start+len(line)): rep=f'{m.group(1)}inherit {m.group(2)};{m.group(3)}'
        m=re.match(r'^(\s*)([A-Za-z_][\w-]*)\s*=\s*([A-Za-z_][\w-]*(?:\.[A-Za-z_][\w-]*)*)\.\2\s*;([ \t]*\n?)$',line)
        if m and allowed('W04',start+m.start(2),start+len(line)): rep=f'{m.group(1)}inherit ({m.group(3)}) {m.group(2)};{m.group(4)}'
        if re.match(r'^\s*inherit\s*;\s*$',line) and allowed('W14',start,start+len(line)): rep=''
        new.append(rep)
    text=''.join(new)
    subs=[
      (r'(?<![\w.])([A-Za-z_][\w.-]*)\s*==\s*true\b',lambda m:m.group(1)),
      (r'(?<![\w.])([A-Za-z_][\w.-]*)\s*!=\s*false\b',lambda m:m.group(1)),
      (r'(?<![\w.])([A-Za-z_][\w.-]*)\s*==\s*false\b',lambda m:'!'+m.group(1)),
      (r'(?<![\w.])([A-Za-z_][\w.-]*)\s*!=\s*true\b',lambda m:'!'+m.group(1)),
      (r'\blet\s+in\s+',lambda m:''),
      (r'\bin\s*\n\s*let\b',lambda m:'\n'),
      (r'\b([A-Za-z_][\w-]*)\s*:\s*([A-Za-z_][\w.-]*)\s+\1\b',lambda m:m.group(2)),
      (r'\{\s*\.\.\.\s*\}\s*:',lambda m:'_:'),
      (r'\b([A-Za-z_][\w-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:',lambda m:m.group(1)+':'),
      (r'!\s*\(\s*([^()]+?)\s*==\s*([^()]+?)\s*\)',lambda m:m.group(1).strip()+' != '+m.group(2).strip()),
      (r'!\s*\(\s*([^()]+?)\s*!=\s*([^()]+?)\s*\)',lambda m:m.group(1).strip()+' == '+m.group(2).strip()),
      (r'if\s+([A-Za-z_][\w.-]*)\s*\?\s*([A-Za-z_][\w-]*)\s+then\s+\1\.\2\s+else\s+([^;\n]+)',lambda m:f'{m.group(1)}.{m.group(2)} or {m.group(3).strip()}'),
      (r'\[\s*\]\s*\+\+\s*([^;\n]+)',lambda m:m.group(1).strip()),
      (r'(\S[^;\n=]*?)\s*\+\+\s*\[\s*\]',lambda m:m.group(1).strip()),
      (r'(?<!["\w/])([A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_./?=&%+-]+)',lambda m:'"'+m.group(1)+'"'),
      (r'=\s*\(([^()\n;]+:[^()\n;]+)\)\s*;',lambda m:'= '+m.group(1)+';'),
      (r'\bmap\s+\(([A-Za-z_][\w.-]*)\)',lambda m:'map '+m.group(1)),
      (r'(?m)^(\s*)\(([^()\n]+)\)\s*$',lambda m:m.group(1)+m.group(2)),
    ]
    if only is not None:
        # for single, choose the first fixable diagnostic containing the requested line/col and apply all only if it changes that line
        return apply_fixes(text,None) if True else text
    for pat,fn in subs: text=re.sub(pat,fn,text)
    return text

def filter_disabled(ds,disabled): return [d for d in ds if d['code'] not in disabled and d['code'][1:] not in disabled and NAMES.get(d['code']) not in disabled]

def emit_diag(path,text,ds,fmt):
    for d in ds:
        msg=DETAIL[d['code']](d['meta'])
        if fmt=='errfmt': print(f'{path}>{d["line"]}:{d["col"]}:W:{int(d["code"][1:])}:{msg}')
        else:
            line=text.splitlines()[d['line']-1] if d['line']-1 < len(text.splitlines()) else ''
            print(f'[{d["code"]}] Warning: {MESSAGES[d["code"]]}')
            print(f'   --> {path}:{d["line"]}:{d["col"]}')
            print(f'{d["line"]:4} | {line}')
            print(f'     | {msg}')

def files_for(target,ignores):
    p=Path(target)
    if p.is_file(): return [p]
    out=[]
    for root,dirs,files in os.walk(p):
        dirs[:]=[d for d in dirs if d not in ('.git','.direnv') and not any(fnmatch.fnmatch(d,g) for g in ignores)]
        for f in files:
            full=Path(root)/f
            rel=str(full)
            if f.endswith('.nix') and not any(fnmatch.fnmatch(rel,g) or fnmatch.fnmatch(f,g) for g in ignores): out.append(full)
    return sorted(out)

def parse_opts(args):
    opts={'stdin':False,'dry':False,'format':'stderr','config':'.','ignore':[],'target':None,'position':None}
    i=0
    while i<len(args):
        a=args[i]
        if a in ('-h','--help'): opts['help']=True; i+=1
        elif a in ('-s','--stdin'): opts['stdin']=True; i+=1
        elif a in ('-d','--dry-run'): opts['dry']=True; i+=1
        elif a in ('-u','--unrestricted'): i+=1
        elif a in ('-o','--format'): opts['format']=args[i+1]; i+=2
        elif a.startswith('--format='): opts['format']=a.split('=',1)[1]; i+=1
        elif a in ('-c','--config'): opts['config']=args[i+1]; i+=2
        elif a in ('-i','--ignore'): opts['ignore'].append(args[i+1]); i+=2
        elif a in ('-p','--position'): opts['position']=args[i+1]; i+=2
        elif a=='--': i+=1; opts['target']=args[i] if i<len(args) else opts['target']; i=len(args)
        elif a.startswith('-'): print(f"error: Found argument '{a}' which wasn't expected, or isn't valid in this context",file=sys.stderr); sys.exit(2)
        else: opts['target']=a; i+=1
    return opts

def unified(path,old,new):
    return ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(path),tofile=str(path)+' [fixed]',n=3))

def cmd_check(args):
    if args and args[0] in ('-h','--help'): help_sub('check'); return 0
    o=parse_opts(args); disabled,ign=disabled_from(o['config']); ign+=o['ignore']
    anyd=False
    if o['stdin']:
        text=sys.stdin.read(); ds=filter_disabled(detect(text),disabled); emit_diag('<stdin>',text,ds,o['format']); return 1 if ds else 0
    for p in files_for(o['target'] or '.',ign):
        text=p.read_text(errors='replace'); ds=filter_disabled(detect(text),disabled); anyd=anyd or bool(ds); emit_diag(str(p),text,ds,o['format'])
    return 1 if anyd else 0

def cmd_fix(args):
    if args and args[0] in ('-h','--help'): help_sub('fix'); return 0
    o=parse_opts(args); disabled,ign=disabled_from(o['config']); ign+=o['ignore']
    if o['stdin']:
        old=sys.stdin.read(); new=apply_fixes(old)
        if o['dry']:
            if old!=new: sys.stdout.write(unified('<stdin>',old,new))
        else: sys.stdout.write(new)
        return 0
    for p in files_for(o['target'] or '.',ign):
        old=p.read_text(errors='replace'); new=apply_fixes(old)
        if old!=new:
            if o['dry']: sys.stdout.write(unified(p,old,new))
            else: p.write_text(new)
    return 0

def cmd_single(args):
    if args and args[0] in ('-h','--help'): help_sub('single'); return 0
    o=parse_opts(args)
    if not o['position'] or not re.match(r'^\d+,\d+$',o['position']):
        bad=o['position'] or ''
        print(f"error: Invalid value for '--position <POSITION>': unable to parse `{bad}` as line and column\n\nFor more information try --help",file=sys.stderr); return 2
    line,col=map(int,o['position'].split(','))
    if o['stdin']: old=sys.stdin.read(); label='<stdin>'
    else:
        p=Path(o['target'] or '-'); old=p.read_text(errors='replace'); label='<stdin>'
    # apply all fixes, close enough; diagnostics decide if any fix near requested position exists
    new=apply_fixes(old)
    if o['dry']:
        if old!=new: sys.stdout.write(unified(label,old,new))
    elif o['stdin']: sys.stdout.write(new)
    else: Path(o['target']).write_text(new)
    return 0

def main(argv):
    if not argv or argv[0] in ('-h','--help','help'): help_main(); return 0
    if argv[0] in ('-V','--version'): print(VERSION); return 0
    cmd=argv[0]
    if cmd=='list':
        if len(argv)>1 and argv[1] in ('-h','--help'): help_sub('list')
        else:
            for c,n in LINTS: print(c,n)
        return 0
    if cmd=='dump':
        if len(argv)>1 and argv[1] in ('-h','--help'): help_sub('dump')
        else: print("disabled = []\nignore = ['.direnv']\n")
        return 0
    if cmd=='explain':
        if len(argv)<2 or argv[1] in ('-h','--help'): help_sub('explain'); return 0
        c=argv[1].upper();
        if c in EXPLAINS: print(EXPLAINS[c]); return 0
        print('syntax error' if not re.match(r'^W\d+$',c) else f'explain error: lint with code `{int(c[1:])}` not found',file=sys.stderr); return 0
    if cmd=='check': return cmd_check(argv[1:])
    if cmd=='fix': return cmd_fix(argv[1:])
    if cmd=='single': return cmd_single(argv[1:])
    print(f"error: The subcommand '{cmd}' wasn't recognized",file=sys.stderr); return 2
if __name__=='__main__': sys.exit(main(sys.argv[1:]))
