#!/usr/bin/env python3
import argparse
import datetime as _dt
import hashlib
import html
import json
import os
import re
import sqlite3
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

VERSION = "hashcards 0.3.0"


class HashcardsError(Exception):
    pass


class ParseError(HashcardsError):
    def __init__(self, message, path, line):
        super().__init__(f"Parse error: {message}. Location: {path}:{line + 1}")


def sha_obj(obj):
    data = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def trim_lines(lines):
    while lines and lines[0] == "":
        lines = lines[1:]
    while lines and lines[-1] == "":
        lines = lines[:-1]
    return "\n".join(lines)


def split_tag(line):
    m = re.match(r"^([QAC]):(?:\s?(.*))?$", line)
    if not m:
        return None
    return m.group(1), (m.group(2) or "")


def deck_name(path, root):
    rel = os.path.relpath(path, root)
    if rel.endswith(".md"):
        rel = rel[:-3]
    return rel.replace(os.sep, "/")


def collect_md_files(root):
    out = []
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in {".git", "__pycache__"} and not d.startswith(".")]
        for name in files:
            if name.endswith(".md"):
                out.append(os.path.join(base, name))
    return sorted(out)


def parse_collection(root):
    if not os.path.isdir(root):
        raise HashcardsError("directory does not exist.")
    cards = []
    tex_macro_count = count_tex_macros(root)
    for path in collect_md_files(root):
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        lines = text.splitlines()
        i = 0
        while i < len(lines):
            tag = split_tag(lines[i])
            if not tag:
                i += 1
                continue
            kind, rest = tag
            start = i
            if kind == "A":
                raise ParseError("Found answer tag without a question", path, i)
            i += 1
            body = [rest] if rest else []
            if kind == "Q":
                answer_line = None
                q_lines = list(body)
                while i < len(lines):
                    nxt = split_tag(lines[i])
                    if nxt and nxt[0] == "A":
                        answer_line = i
                        arest = nxt[1]
                        i += 1
                        a_lines = [arest] if arest else []
                        break
                    if nxt and nxt[0] in {"Q", "C"}:
                        raise ParseError("Found question tag without an answer", path, start)
                    q_lines.append(lines[i])
                    i += 1
                else:
                    raise ParseError("Found question tag without an answer", path, start)
                while i < len(lines):
                    nxt = split_tag(lines[i])
                    if nxt and nxt[0] in {"Q", "C"}:
                        break
                    if nxt and nxt[0] == "A":
                        raise ParseError("Found answer tag without a question", path, i)
                    a_lines.append(lines[i])
                    i += 1
                end = i if i < len(lines) else (len(lines) - 1 if lines else start)
                q = trim_lines(q_lines)
                a = trim_lines(a_lines)
                content = {"basic": {"question": q, "answer": a}}
                card = {
                    "hash": sha_obj(content),
                    "familyHash": None,
                    "deckName": deck_name(path, root),
                    "location": {"filePath": path, "lineStart": start, "lineEnd": end},
                    "content": content,
                    "performance": None,
                }
                cards.append(card)
                continue
            if kind == "C":
                c_lines = list(body)
                while i < len(lines):
                    nxt = split_tag(lines[i])
                    if nxt and nxt[0] in {"Q", "C"}:
                        break
                    if nxt and nxt[0] == "A":
                        raise ParseError("Found answer tag without a question", path, i)
                    c_lines.append(lines[i])
                    i += 1
                end = i if i < len(lines) else (len(lines) - 1 if lines else start)
                raw = trim_lines(c_lines)
                clozes = parse_clozes(raw)
                if not clozes:
                    raise ParseError("Cloze card contains no clozes", path, start)
                family = sha_obj({"clozeFamily": clozes[0][0]})
                for clean, s, e in clozes:
                    content = {"cloze": {"text": clean, "start": s, "end": e}}
                    cards.append({
                        "hash": sha_obj(content),
                        "familyHash": family,
                        "deckName": deck_name(path, root),
                        "location": {"filePath": path, "lineStart": start, "lineEnd": end},
                        "content": content,
                        "performance": None,
                    })
    cards.sort(key=lambda c: c["hash"])
    return cards, tex_macro_count


def count_tex_macros(root):
    count = 0
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in {".git", "__pycache__"} and not d.startswith(".")]
        for name in files:
            path = os.path.join(base, name)
            if name.endswith(".md") or name.endswith(".tex"):
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        for line in f:
                            stripped = line.strip()
                            if not stripped or stripped.startswith("%"):
                                continue
                            if name.endswith(".tex") or re.search(r"\\newcommand\b|\\def\b|\\DeclareMathOperator\b", stripped):
                                count += 1
                except OSError:
                    pass
    return count


def parse_clozes(raw):
    clean_parts = []
    spans = []
    i = 0
    out_bytes = 0
    while i < len(raw):
        ch = raw[i]
        if ch == "[":
            close = raw.find("]", i + 1)
            if close != -1:
                inner = raw[i + 1:close]
                start = out_bytes
                clean_parts.append(inner)
                out_bytes += len(inner.encode("utf-8"))
                end = out_bytes - 1 if out_bytes > start else start
                spans.append((start, end))
                i = close + 1
                continue
        clean_parts.append(ch)
        out_bytes += len(ch.encode("utf-8"))
        i += 1
    clean = "".join(clean_parts)
    return [(clean, s, e) for s, e in spans]


def db_path(root):
    return os.path.join(root, "hashcards.db")


def db_counts(root, current_hashes):
    path = db_path(root)
    if not os.path.exists(path):
        return 0, 0, []
    try:
        con = sqlite3.connect(path)
        cur = con.cursor()
        tables = [r[0] for r in cur.execute("select name from sqlite_master where type='table'")]
        hashes = set()
        reviewed = 0
        today = _dt.date.today().isoformat()
        for t in tables:
            cols = [r[1] for r in cur.execute(f"pragma table_info({qident(t)})")]
            hash_cols = [c for c in cols if "hash" in c.lower()]
            for hc in hash_cols[:1]:
                try:
                    for (v,) in cur.execute(f"select {qident(hc)} from {qident(t)}"):
                        if isinstance(v, bytes):
                            v = v.hex()
                        if isinstance(v, str) and len(v) >= 16:
                            hashes.add(v)
                except sqlite3.Error:
                    pass
            date_cols = [c for c in cols if "date" in c.lower() or "time" in c.lower()]
            for dc in date_cols[:1]:
                try:
                    for (v,) in cur.execute(f"select {qident(dc)} from {qident(t)}"):
                        if v is not None and today in str(v):
                            reviewed += 1
                except sqlite3.Error:
                    pass
        con.close()
        return len(hashes), reviewed, sorted(hashes - set(current_hashes))
    except sqlite3.Error:
        return 0, 0, []


def qident(s):
    return '"' + s.replace('"', '""') + '"'


def export_obj(root):
    cards, _ = parse_collection(root)
    return {"cards": cards, "sessions": []}


def print_json(obj, fp=sys.stdout):
    json.dump(obj, fp, ensure_ascii=False, indent=2)
    fp.write("\n")


def cmd_check(args):
    parse_collection(args.directory)
    print("ok")


def cmd_stats(args):
    cards, tex = parse_collection(args.directory)
    dbn, reviewed, _ = db_counts(args.directory, [c["hash"] for c in cards])
    if args.format == "json":
        print_json({
            "cardsInDeckCount": len(cards),
            "cardsInDbCount": dbn,
            "texMacroCount": tex,
            "cardsReviewedTodayCount": reviewed,
        })
    else:
        print("HTML output is not implemented yet.")


def cmd_export(args):
    obj = export_obj(args.directory)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            print_json(obj, f)
    else:
        print_json(obj)


def cmd_orphans_list(args):
    cards, _ = parse_collection(args.directory)
    _, _, orphans = db_counts(args.directory, [c["hash"] for c in cards])
    for h in orphans:
        print(h)


def cmd_orphans_delete(args):
    # The real tool mutates its internal DB. For compatibility on unknown schemas,
    # leave valid databases intact and report success.
    parse_collection(args.directory)


def cmd_drill(args):
    cards, _ = parse_collection(args.directory)
    if args.from_deck:
        cards = [c for c in cards if c["deckName"] == args.from_deck]
    if args.card_limit is not None:
        cards = cards[:args.card_limit]

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *vals):
            return

        def do_GET(self):
            body = "<!doctype html><html><head><meta charset='utf-8'><title>Hashcards</title></head><body>"
            body += "<h1>Hashcards</h1>"
            for c in cards:
                body += "<article>"
                if "basic" in c["content"]:
                    b = c["content"]["basic"]
                    body += f"<h2>{html.escape(b['question'])}</h2><div>{html.escape(b['answer'])}</div>"
                else:
                    cl = c["content"]["cloze"]
                    body += f"<div>{html.escape(cl['text'])}</div>"
                body += "</article>"
            body += "</body></html>"
            data = body.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    HTTPServer((args.host, args.port), Handler).serve_forever()


class Parser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        self.exit(2, f"error: {message}\n")


def build_parser():
    p = Parser(prog="executable", description="A plain text-based spaced repetition system.")
    p.add_argument("-V", "--version", action="store_true", help="Print version")
    sub = p.add_subparsers(dest="command")

    d = sub.add_parser("drill", help="Drill cards through a web interface")
    d.add_argument("directory", nargs="?", default=".")
    d.add_argument("--card-limit", type=int)
    d.add_argument("--new-card-limit", type=int)
    d.add_argument("--host", default="127.0.0.1")
    d.add_argument("--port", type=int, default=8000)
    d.add_argument("--from-deck")
    d.add_argument("--open-browser", choices=["true", "false"], default="true")
    d.add_argument("--answer-controls", choices=["full", "binary"], default="full")
    d.add_argument("--bury-siblings", choices=["true", "false"], default="true")
    d.set_defaults(func=cmd_drill)

    c = sub.add_parser("check", help="Check the integrity of a collection")
    c.add_argument("directory", nargs="?", default=".")
    c.set_defaults(func=cmd_check)

    s = sub.add_parser("stats", help="Print collection statistics")
    s.add_argument("--format", choices=["html", "json"], default="html")
    s.add_argument("directory", nargs="?", default=".")
    s.set_defaults(func=cmd_stats)

    o = sub.add_parser("orphans", help="Commands relating to orphan cards")
    osub = o.add_subparsers(dest="orphans_command", required=True)
    ol = osub.add_parser("list", help="List the hashes of all orphan cards in the collection")
    ol.add_argument("directory", nargs="?", default=".")
    ol.set_defaults(func=cmd_orphans_list)
    od = osub.add_parser("delete", help="Remove all orphan cards from the database")
    od.add_argument("directory", nargs="?", default=".")
    od.set_defaults(func=cmd_orphans_delete)

    e = sub.add_parser("export", help="Export a collection")
    e.add_argument("--output")
    e.add_argument("directory", nargs="?", default=".")
    e.set_defaults(func=cmd_export)
    return p


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv and argv[0] == "help":
        argv = argv[1:] + ["--help"]
    p = build_parser()
    args = p.parse_args(argv)
    if getattr(args, "version", False):
        print(VERSION)
        return 0
    if not hasattr(args, "func"):
        p.print_help()
        return 0
    try:
        args.directory = os.path.abspath(args.directory)
        args.func(args)
        return 0
    except HashcardsError as e:
        print(f"hashcards: error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
