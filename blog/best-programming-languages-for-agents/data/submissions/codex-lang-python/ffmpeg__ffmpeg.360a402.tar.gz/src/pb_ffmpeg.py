#!/usr/bin/env python3
import math
import os
import re
import shutil
import struct
import sys
import wave
import zlib

VERSION = "git-2026-04-13-10ea080"
LIBS = [
    ("libavutil", "60. 25.100"),
    ("libavcodec", "62. 23.103"),
    ("libavformat", "62.  9.101"),
    ("libavdevice", "62.  2.100"),
    ("libavfilter", "11. 12.100"),
    ("libswscale", "9.  3.100"),
    ("libswresample", "6.  2.100"),
]


def eprint(s=""):
    print(s, file=sys.stderr)


def banner(stream=sys.stderr, indent=True):
    print(f"ffmpeg version {VERSION} Copyright (c) 2000-2026 the FFmpeg developers", file=stream)
    lead = "  " if indent else ""
    print(f"{lead}built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)", file=stream)
    print(f"{lead}configuration: --disable-ffplay --disable-ffprobe", file=stream)
    lines = [
        "libavutil      60. 25.100 / 60. 25.100",
        "libavcodec     62. 23.103 / 62. 23.103",
        "libavformat    62.  9.101 / 62.  9.101",
        "libavdevice    62.  2.100 / 62.  2.100",
        "libavfilter    11. 12.100 / 11. 12.100",
        "libswscale      9.  3.100 /  9.  3.100",
        "libswresample   6.  2.100 /  6.  2.100",
    ]
    for line in lines:
        print(f"{lead}{line}", file=stream)


HELP = """Universal media converter
usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...

Getting help:
    -h      -- print basic options
    -h long -- print more options
    -h full -- print all options (including all format and codec specific options, very long)
    -h type=name -- print all options for the named decoder/encoder/demuxer/muxer/filter/bsf/protocol
    See man ffmpeg for detailed description of the options.

Per-stream options can be followed by :<stream_spec> to apply that option to specific streams only. <stream_spec> can be a stream index, or v/a/s for video/audio/subtitle (see manual for full syntax).

Print help / information / capabilities:
-L                  show license
-license            show license
-h <topic>          show help
-version            show version
-muxers             show available muxers
-demuxers           show available demuxers
-devices            show available devices
-decoders           show available decoders
-encoders           show available encoders
-filters            show available filters
-pix_fmts           show available pixel formats
-layouts            show standard channel layouts
-sample_fmts        show available audio sample formats

Global options (affect whole program instead of just one file):
-v <loglevel>       set logging level
-y                  overwrite output files
-n                  never overwrite output files
-print_graphs       print execution graph data to stderr
-print_graphs_file <filename>  write execution graph data to the specified file
-print_graphs_format <format>  set the output printing format (available formats are: default, compact, csv, flat, ini, json, xml, mermaid, mermaidhtml)
-stats              print progress report during encoding

Per-file options (input and output):
-f <fmt>            force container format (auto-detected otherwise)
-t <duration>       stop transcoding after specified duration
-to <time_stop>     stop transcoding after specified time is reached
-ss <time_off>      start transcoding at specified time


Per-file options (output-only):
-metadata[:<spec>] <key=value>  add metadata

Per-stream options:
-c[:<stream_spec>] <codec>  select encoder/decoder ('copy' to copy stream without reencoding)
-filter[:<stream_spec>] <filter_graph>  apply specified filters to audio/video

Video options:
-r[:<stream_spec>] <rate>  override input framerate/convert to given output framerate (Hz value, fraction or abbreviation)
-aspect[:<stream_spec>] <aspect>  set aspect ratio (4:3, 16:9 or 1.3333, 1.7777)
-vn                 disable video
-vcodec <codec>     alias for -c:v (select encoder/decoder for video streams)
-vf <filter_graph>  alias for -filter:v (apply filters to video streams)
-b <bitrate>        video bitrate (please use -b:v)

Audio options:
-aq <quality>       set audio quality (codec-specific)
-ar[:<stream_spec>] <rate>  set audio sampling rate (in Hz)
-ac[:<stream_spec>] <channels>  set number of audio channels
-an                 disable audio
-acodec <codec>     alias for -c:a (select encoder/decoder for audio streams)
-ab <bitrate>       alias for -b:a (select bitrate for audio streams)
-af <filter_graph>  alias for -filter:a (apply filters to audio streams)

Subtitle options:
-sn                 disable subtitle
-scodec <codec>     alias for -c:s (select encoder/decoder for subtitle streams)
"""


def parse_duration(s, default=0.0):
    if s is None:
        return default
    try:
        if ":" in s:
            parts = [float(x) for x in s.split(":")]
            val = 0.0
            for x in parts:
                val = val * 60 + x
            return val
        return float(s)
    except Exception:
        return default


def parse_kv_filter(spec):
    if "=" not in spec:
        return spec, {}
    name, rest = spec.split("=", 1)
    opts = {}
    parts = rest.split(":")
    if parts and "=" not in parts[0] and name in ("sine", "color", "testsrc"):
        opts["value"] = parts[0]
        parts = parts[1:]
    for p in parts:
        if "=" in p:
            k, v = p.split("=", 1)
            opts[k] = v
    return name, opts


def wav_write(path, pcm, rate=44100, channels=1):
    with wave.open(path, "wb") as w:
        w.setnchannels(channels)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)


def wav_read(path):
    with wave.open(path, "rb") as w:
        channels = w.getnchannels()
        rate = w.getframerate()
        width = w.getsampwidth()
        frames = w.getnframes()
        raw = w.readframes(frames)
    if width == 2:
        return raw, rate, channels
    if width == 1:
        out = bytearray()
        for b in raw:
            out.extend(struct.pack("<h", (b - 128) << 8))
        return bytes(out), rate, channels
    raise ValueError("unsupported WAV sample width")


def gen_sine(opts, duration):
    freq = float(opts.get("frequency", opts.get("f", opts.get("value", 440))))
    rate = int(float(opts.get("sample_rate", opts.get("r", 44100))))
    dur = parse_duration(opts.get("duration", opts.get("d")), duration or 1.0)
    n = max(0, int(round(rate * dur)))
    amp = 4095
    data = bytearray()
    for i in range(n):
        data.extend(struct.pack("<h", int(amp * math.sin(2 * math.pi * freq * i / rate))))
    return bytes(data), rate, 1


def gen_silence(opts, duration):
    rate = int(float(opts.get("r", opts.get("sample_rate", 44100))))
    dur = duration or parse_duration(opts.get("duration", opts.get("d")), 1.0)
    n = max(0, int(round(rate * dur)))
    return b"\x00\x00" * n, rate, 1


def parse_size(s, default=(320, 240)):
    if not s:
        return default
    m = re.match(r"(\d+)x(\d+)$", s)
    return (int(m.group(1)), int(m.group(2))) if m else default


COLORS = {
    "black": (0, 0, 0), "white": (255, 255, 255), "red": (255, 0, 0),
    "green": (0, 128, 0), "blue": (0, 0, 255), "yellow": (255, 255, 0),
    "cyan": (0, 255, 255), "magenta": (255, 0, 255),
}


def color_value(s):
    s = (s or "black").lower()
    if s in COLORS:
        return COLORS[s]
    if s.startswith("0x") and len(s) >= 8:
        return tuple(int(s[i:i+2], 16) for i in (2, 4, 6))
    if s.startswith("#") and len(s) >= 7:
        return tuple(int(s[i:i+2], 16) for i in (1, 3, 5))
    return (0, 0, 0)


def gen_image(spec):
    name, opts = parse_kv_filter(spec)
    w, h = parse_size(opts.get("size", opts.get("s")), (320, 240))
    pixels = bytearray()
    if name == "color":
        rgb = color_value(opts.get("color", opts.get("c", opts.get("value", "black"))))
        pixels = bytearray(rgb * (w * h))
    else:
        bars = [(255,255,255),(255,255,0),(0,255,255),(0,255,0),(255,0,255),(255,0,0),(0,0,255),(0,0,0)]
        for y in range(h):
            for x in range(w):
                if y > h * 2 // 3:
                    v = int((x ^ y) & 255)
                    pixels.extend((v, v, v))
                else:
                    pixels.extend(bars[(x * len(bars)) // max(1, w)])
    return w, h, bytes(pixels)


def png_write(path, w, h, rgb):
    def chunk(t, data):
        return struct.pack(">I", len(data)) + t + data + struct.pack(">I", zlib.crc32(t + data) & 0xffffffff)
    raw = b"".join(b"\x00" + rgb[y*w*3:(y+1)*w*3] for y in range(h))
    data = b"\x89PNG\r\n\x1a\n"
    data += chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
    data += chunk(b"IDAT", zlib.compress(raw))
    data += chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(data)


def ppm_write(path, w, h, rgb):
    with open(path, "wb") as f:
        f.write(f"P6\n{w} {h}\n255\n".encode())
        f.write(rgb)


def help_topic(topic):
    banner()
    if topic.startswith("muxer=wav"):
        eprint("""Muxer wav [WAV / WAVE (Waveform Audio)]:
    Common extensions: wav.
    Mime type: audio/x-wav.
    Default audio codec: pcm_s16le.
WAV muxer AVOptions:
  -write_bext        <boolean>    E.......... Write BEXT chunk. (default false)
  -write_peak        <int>        E.......... Write Peak Envelope chunk. (from 0 to 2) (default off)
  -rf64              <int>        E.......... Use RF64 header rather than RIFF for large files. (from -1 to 1) (default never)""")
    elif topic.startswith("filter=sine"):
        eprint("""Filter sine
  Generate sine wave audio signal.
    Inputs:
        none (source filter)
    Outputs:
       #0: default (audio)
sine AVOptions:
   frequency         <double>     ..F.A...... set the sine frequency (from 0 to DBL_MAX) (default 440)
   f                 <double>     ..F.A...... set the sine frequency (from 0 to DBL_MAX) (default 440)
   sample_rate       <int>        ..F.A...... set the sample rate (from 1 to INT_MAX) (default 44100)
   duration          <duration>   ..F.A...... set the audio duration (default 0)""")
    else:
        eprint(HELP)
    eprint("\nExiting with exit code 0")


def list_caps(kind):
    banner()
    tables = {
        "-sample_fmts": "name   depth\nu8        8 \ns16      16 \ns32      32 \nflt      32 \ndbl      64 \nu8p       8 \ns16p     16 \ns32p     32 \nfltp     32 \ndblp     64 \ns64      64 \ns64p     64 ",
        "-devices": "Devices:\n D. = Demuxing supported\n .E = Muxing supported\n ---\n DE fbdev           Linux framebuffer\n D  lavfi           Libavfilter virtual input device\n DE oss             OSS (Open Sound System) playback\n DE video4linux2,v4l2 Video4Linux2 output device",
        "-pix_fmts": "Pixel formats:\nI.... = Supported Input  format for conversion\n.O... = Supported Output format for conversion\n..H.. = Hardware accelerated format\n...P. = Paletted format\n....B = Bitstream format\nFLAGS NAME            NB_COMPONENTS BITS_PER_PIXEL BIT_DEPTHS\n-----\nIO... yuv420p                3             12      8-8-8\nIO... rgb24                  3             24      8-8-8\nIO... bgr24                  3             24      8-8-8\nIO... gray                   1              8      8",
        "-layouts": "Individual channels:\nNAME           DESCRIPTION\nFL             front left\nFR             front right\nFC             front center\nLFE            low frequency\nBL             back left\nBR             back right\n\nStandard channel layouts:\nNAME           DECOMPOSITION\nmono           FC\nstereo         FL+FR\n5.1            FL+FR+FC+LFE+BL+BR",
        "-filters": "Filters:\n  T.. = Timeline support\n  .S. = Slice threading\n  A = Audio input/output\n  V = Video input/output\n  N = Dynamic number and/or type of input/output\n  | = Source or sink filter\n  ------\n .. anull             A->A       Pass the source unchanged to the output.\n .. sine              |->A       Generate sine wave audio signal.\n .. anullsrc          |->A       Null audio source, return empty audio frames.\n .. testsrc           |->V       Generate test pattern.\n .. color             |->V       Provide an uniformly colored input.",
        "-encoders": "Encoders:\n V..... = Video\n A..... = Audio\n S..... = Subtitle\n ------\n A....D pcm_s16le            PCM signed 16-bit little-endian\n V....D png                  PNG (Portable Network Graphics) image\n V....D ppm                  PPM (Portable PixelMap) image",
        "-decoders": "Decoders:\n V..... = Video\n A..... = Audio\n S..... = Subtitle\n ------\n A....D pcm_s16le            PCM signed 16-bit little-endian\n A....D pcm_u8               PCM unsigned 8-bit\n V....D png                  PNG (Portable Network Graphics) image",
        "-muxers": "Formats:\n D.. = Demuxing supported\n .E. = Muxing supported\n ..d = Is a device\n ---\n  E  wav             WAV / WAVE (Waveform Audio)\n  E  s16le           PCM signed 16-bit little-endian\n  E  null            raw null video\n  E  image2          image2 sequence\n  E  png             PNG image\n  E  ppm             PPM image",
        "-demuxers": "Formats:\n D.. = Demuxing supported\n .E. = Muxing supported\n ..d = Is a device\n ---\n D   wav             WAV / WAVE (Waveform Audio)\n D   s16le           PCM signed 16-bit little-endian\n D   lavfi           Libavfilter virtual input device",
        "-formats": "Formats:\n D.. = Demuxing supported\n .E. = Muxing supported\n ..d = Is a device\n ---\n DE  wav             WAV / WAVE (Waveform Audio)\n DE  s16le           PCM signed 16-bit little-endian\n D   lavfi           Libavfilter virtual input device\n  E  null            raw null video\n  E  image2          image2 sequence\n  E  png             PNG image\n  E  ppm             PPM image",
        "-protocols": "Supported file protocols:\nInput:\n  file\n  pipe\nOutput:\n  file\n  pipe",
    }
    if kind == "-codecs":
        eprint("Codecs:\n D..... = Decoding supported\n .E.... = Encoding supported\n ..V... = Video codec\n ..A... = Audio codec\n -------\n DEA..S pcm_s16le            PCM signed 16-bit little-endian\n DEV..S png                  PNG (Portable Network Graphics) image\n DEV..S ppm                  PPM (Portable PixelMap) image")
    elif kind == "-buildconf":
        eprint("\n  configuration:\n    --disable-ffplay\n    --disable-ffprobe")
    else:
        eprint(tables.get(kind, ""))
    eprint("\nExiting with exit code 0")


def infer_fmt(path, forced):
    if forced:
        return forced
    ext = os.path.splitext(path)[1].lower()
    return {".wav": "wav", ".raw": "s16le", ".pcm": "s16le", ".png": "png", ".ppm": "ppm"}.get(ext, ext[1:] or "unknown")


def convert(cfg):
    inp = cfg.get("input")
    out = cfg.get("output")
    if not out:
        banner()
        eprint("At least one output file must be specified")
        return 1
    if os.path.exists(out) and not cfg.get("overwrite") and not cfg.get("never"):
        banner()
        eprint(f"File '{out}' already exists. Overwrite? [y/N] Not overwriting - exiting")
        return 1
    if cfg.get("never") and os.path.exists(out):
        banner()
        eprint(f"File '{out}' already exists. Exiting.")
        return 1

    infmt = cfg.get("input_format")
    outfmt = infer_fmt(out, cfg.get("output_format"))
    duration = cfg.get("duration")
    ss = cfg.get("ss", 0.0)
    media = None
    if not cfg.get("hide_banner"):
        banner()

    if infmt == "lavfi":
        spec = inp or ""
        name, opts = parse_kv_filter(spec)
        if name in ("sine", "anullsrc"):
            pcm, rate, ch = gen_sine(opts, duration) if name == "sine" else gen_silence(opts, duration)
            media = ("audio", pcm, rate, ch)
            eprint(f"Input #0, lavfi, from '{spec}':")
            eprint("  Duration: N/A, start: 0.000000, bitrate: 705 kb/s")
            eprint(f"  Stream #0:0: Audio: pcm_s16le, {rate} Hz, mono, s16, {rate*16//1000} kb/s")
        elif name in ("testsrc", "color"):
            w, h, rgb = gen_image(spec)
            media = ("video", w, h, rgb)
            eprint(f"Input #0, lavfi, from '{spec}':")
            eprint("  Duration: N/A, start: 0.000000, bitrate: N/A")
            eprint(f"  Stream #0:0: Video: wrapped_avframe, rgb24, {w}x{h} [SAR 1:1 DAR {w}:{h}], 25 fps, 25 tbr, 25 tbn")
        else:
            eprint(f"[lavfi @ 0x555557400000] No such filter: '{name}'")
            return 1
    else:
        if not inp or not os.path.exists(inp):
            eprint("[in#0 @ 0x55555744e600] Error opening input: No such file or directory")
            eprint(f"Error opening input file {inp}.")
            eprint("Error opening input files: No such file or directory")
            return 1
        infmt = infer_fmt(inp, infmt)
        if infmt == "wav":
            try:
                pcm, rate, ch = wav_read(inp)
            except Exception as ex:
                eprint(f"{inp}: Invalid data found when processing input")
                return 1
            if ss:
                start = int(ss * rate) * ch * 2
                pcm = pcm[start:]
            if duration is not None:
                pcm = pcm[: int(duration * rate) * ch * 2]
            media = ("audio", pcm, rate, ch)
            dur = len(pcm) / (rate * ch * 2) if rate and ch else 0
            eprint(f"Input #0, wav, from '{inp}':")
            eprint(f"  Duration: {fmt_time(dur)}, bitrate: {int((len(pcm)+78)*8/max(dur,0.001)/1000)} kb/s")
            eprint(f"  Stream #0:0: Audio: pcm_s16le, {rate} Hz, {'mono' if ch == 1 else 'stereo'}, s16, {rate*ch*16//1000} kb/s")
        elif infmt == "s16le":
            with open(inp, "rb") as f:
                pcm = f.read()
            rate = int(cfg.get("ar") or 44100)
            ch = int(cfg.get("ac") or 1)
            media = ("audio", pcm, rate, ch)
        else:
            if cfg.get("codec") == "copy":
                shutil.copyfile(inp, out)
                return 0
            eprint(f"{inp}: Invalid data found when processing input")
            return 1

    if outfmt == "null":
        eprint("Output #0, null, to 'pipe:':")
    elif media[0] == "audio":
        _, pcm, rate, ch = media
        eprint("Stream mapping:")
        eprint("  Stream #0:0 -> #0:0 (pcm_s16le (native) -> pcm_s16le (native))")
        eprint("Press [q] to stop, [?] for help")
        if out == "-" and outfmt in ("s16le", "pcm"):
            sys.stdout.buffer.write(pcm)
            eprint("Output #0, s16le, to 'pipe:':")
        elif out == "-" and outfmt in ("wav", "wave"):
            import io
            bio = io.BytesIO()
            with wave.open(bio, "wb") as wv:
                wv.setnchannels(ch); wv.setsampwidth(2); wv.setframerate(rate); wv.writeframes(pcm)
            sys.stdout.buffer.write(bio.getvalue())
            eprint("Output #0, wav, to 'pipe:':")
        elif outfmt in ("wav", "wave"):
            wav_write(out, pcm, rate, ch)
            eprint(f"Output #0, wav, to '{out}':")
        elif outfmt in ("s16le", "pcm"):
            with open(out, "wb") as f:
                f.write(pcm)
            eprint(f"Output #0, s16le, to '{out}':")
        else:
            wav_write(out, pcm, rate, ch)
            eprint(f"Output #0, {outfmt}, to '{out}':")
        dur = len(pcm) / (rate * ch * 2) if rate and ch else 0
        eprint(f"  Stream #0:0: Audio: pcm_s16le, {rate} Hz, {'mono' if ch == 1 else 'stereo'}, s16, {rate*ch*16//1000} kb/s")
        size = 0 if out == "-" else (os.path.getsize(out) if os.path.exists(out) else 0)
        eprint(f"size={math.ceil(size/1024):8d}KiB time={fmt_time(dur)} bitrate=N/A speed=1x")
    else:
        _, w, h, rgb = media
        eprint("Stream mapping:")
        eprint("  Stream #0:0 -> #0:0 (wrapped_avframe (native) -> image (native))")
        eprint("Press [q] to stop, [?] for help")
        if out == "-":
            if outfmt == "png":
                import io
                tmp = f"/tmp/pb_ffmpeg_{os.getpid()}.png"
                png_write(tmp, w, h, rgb)
                with open(tmp, "rb") as f:
                    sys.stdout.buffer.write(f.read())
                os.unlink(tmp)
            else:
                sys.stdout.buffer.write(f"P6\n{w} {h}\n255\n".encode() + rgb)
        elif outfmt == "png":
            png_write(out, w, h, rgb)
        elif outfmt == "ppm":
            ppm_write(out, w, h, rgb)
        else:
            ppm_write(out, w, h, rgb)
        eprint(f"Output #0, image2, to '{out}':")
        eprint(f"  Stream #0:0: Video: {outfmt}, rgb24, {w}x{h}, 25 fps, 25 tbn")
        eprint("frame=    1 fps=0.0 q=-0.0 Lsize=N/A time=00:00:00.04 bitrate=N/A speed=1x")
    return 0


def fmt_time(t):
    h = int(t // 3600); t -= h * 3600
    m = int(t // 60); t -= m * 60
    return f"{h:02d}:{m:02d}:{t:05.2f}"


def parse_args(argv):
    cfg = {"overwrite": False, "never": False}
    i = 0
    seen_input = False
    while i < len(argv):
        a = argv[i]
        if a in ("-y", "-stats", "-nostats", "-hide_banner", "-nostdin", "-shortest"):
            if a == "-y": cfg["overwrite"] = True
            if a == "-hide_banner": cfg["hide_banner"] = True
            i += 1
        elif a == "-n":
            cfg["never"] = True; i += 1
        elif a == "-i":
            i += 1; cfg["input"] = argv[i] if i < len(argv) else ""; seen_input = True; i += 1
        elif a == "-f":
            i += 1
            val = argv[i] if i < len(argv) else ""
            if not seen_input and "input" not in cfg:
                cfg["input_format"] = val
            else:
                cfg["output_format"] = val
            i += 1
        elif a in ("-t", "-to"):
            i += 1; cfg["duration"] = parse_duration(argv[i] if i < len(argv) else "0"); i += 1
        elif a == "-ss":
            i += 1; cfg["ss"] = parse_duration(argv[i] if i < len(argv) else "0"); i += 1
        elif a in ("-c", "-codec", "-acodec", "-vcodec") or a.startswith("-c:"):
            i += 1; cfg["codec"] = argv[i] if i < len(argv) else ""; i += 1
        elif a.startswith("-ar"):
            i += 1; cfg["ar"] = argv[i] if i < len(argv) else "44100"; i += 1
        elif a.startswith("-ac"):
            i += 1; cfg["ac"] = argv[i] if i < len(argv) else "1"; i += 1
        elif a in ("-frames:v", "-vframes", "-r", "-vf", "-af", "-filter:v", "-filter:a", "-metadata", "-b", "-ab", "-aq", "-aspect", "-v", "-loglevel", "-map", "-threads", "-filter_complex", "-pix_fmt"):
            i += 2
        elif a in ("-vn", "-an", "-sn"):
            i += 1
        elif a.startswith("-"):
            raise ValueError(a)
        else:
            cfg["output"] = a; i += 1
    return cfg


def main(argv):
    if not argv:
        banner(); eprint("Universal media converter\nusage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...\n\nUse -h to get full help or, even better, run 'man ffmpeg'")
        return 0
    if argv[0] in ("-h", "--help") or argv[0] == "-help":
        if len(argv) > 1 and "=" in argv[1]:
            help_topic(argv[1])
        else:
            banner(); eprint(HELP); eprint("\nExiting with exit code 0")
        return 0
    if argv[0] in ("-version", "--version"):
        banner(sys.stdout, indent=False); print("\nExiting with exit code 0"); return 0
    if argv[0] in ("-L", "-license", "--license"):
        banner(); eprint("""ffmpeg is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

ffmpeg is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with ffmpeg; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA""")
        return 0
    if argv[0] in ("-formats", "-muxers", "-demuxers", "-devices", "-decoders", "-encoders", "-filters", "-pix_fmts", "-layouts", "-sample_fmts", "-codecs", "-protocols", "-buildconf"):
        list_caps(argv[0]); return 0
    try:
        cfg = parse_args(argv)
    except ValueError as ex:
        banner(); opt = str(ex).lstrip("-"); eprint(f"Unrecognized option '{opt}'.\nError splitting the argument list: Option not found"); return 1
    return convert(cfg)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
