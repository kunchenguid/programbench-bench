#!/usr/bin/env python3
import json
import math
import os
import re
import sys
import time

VERSION = "2025-09-13"

HELP = f"""QuickJS version {VERSION}
usage: qjs [options] [file [args]]
-h  --help         list options
-e  --eval EXPR    evaluate EXPR
-i  --interactive  go to interactive mode
-m  --module       load as ES6 module (default=autodetect)
    --script       load as ES6 script (default=autodetect)
    --strict       force strict mode
-I  --include file include an additional file
    --std          make 'std' and 'os' available to the loaded script
-T  --trace        trace memory allocation
-d  --dump         dump the memory usage stats
    --memory-limit n  limit the memory usage to 'n' bytes (SI suffixes allowed)
    --stack-size n    limit the stack size to 'n' bytes (SI suffixes allowed)
    --no-unhandled-rejection  ignore unhandled promise rejections
-s                    strip all the debug info
    --strip-source    strip the source code
-q  --quit         just instantiate the interpreter and quit"""


class JSUndefined:
    pass


undefined = JSUndefined()


class JSError(Exception):
    pass


class JSObj(dict):
    def __getattr__(self, name):
        return self.get(name, undefined)

    def __setattr__(self, name, value):
        self[name] = value


def js_repr(v):
    if isinstance(v, JSUndefined):
        return "undefined"
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, float):
        if math.isnan(v):
            return "NaN"
        if math.isinf(v):
            return "Infinity" if v > 0 else "-Infinity"
        if v.is_integer():
            return str(int(v))
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, str):
        return v
    if isinstance(v, list):
        return "[ " + ", ".join(js_repr(x) for x in v) + " ]"
    if isinstance(v, dict):
        return "{ " + ", ".join(f"{k}: {js_repr(val)}" for k, val in v.items()) + " }"
    return str(v)


def js_print(*args):
    print(" ".join(js_repr(x) for x in args))


def js_join(arr, sep=","):
    return str(sep).join("" if isinstance(x, JSUndefined) or x is None else js_repr(x) for x in arr)


def js_push(arr, *items):
    arr.extend(items)
    return len(arr)


def js_json_stringify(v):
    def conv(x):
        if isinstance(x, JSUndefined):
            return None
        if isinstance(x, list):
            return [conv(y) for y in x]
        if isinstance(x, dict):
            return {k: conv(y) for k, y in x.items() if not isinstance(y, JSUndefined)}
        return x
    return json.dumps(conv(v), separators=(",", ":"))


def js_json_parse(s):
    return json.loads(s)


def parse_int(x, base=10):
    try:
        return int(str(x).strip(), int(base))
    except Exception:
        return float("nan")


def parse_float(x):
    try:
        return float(str(x).strip())
    except Exception:
        return float("nan")


def js_typeof_name(name, env):
    parts = name.split(".")
    if parts[0] not in env or isinstance(env.get(parts[0]), JSUndefined):
        return "undefined"
    v = env.get(parts[0])
    for part in parts[1:]:
        try:
            v = getattr(v, part)
        except Exception:
            if isinstance(v, dict):
                v = v.get(part, undefined)
            else:
                v = undefined
        if isinstance(v, JSUndefined):
            return "undefined"
    if v is None:
        return "object"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, (int, float)):
        return "number"
    if isinstance(v, str):
        return "string"
    if callable(v) and not isinstance(v, type):
        return "function"
    return "object"


class Std:
    SEEK_SET = os.SEEK_SET
    SEEK_CUR = os.SEEK_CUR
    SEEK_END = os.SEEK_END
    Error = Exception

    def puts(self, s):
        sys.stdout.write(str(s))
        if not str(s).endswith("\n"):
            sys.stdout.write("\n")

    def printf(self, fmt, *args):
        sys.stdout.write(fmt % args)

    def sprintf(self, fmt, *args):
        return fmt % args

    def exit(self, code=0):
        raise SystemExit(int(code))

    def getenv(self, name):
        return os.environ.get(str(name), None)

    def setenv(self, name, value):
        os.environ[str(name)] = str(value)

    def unsetenv(self, name):
        os.environ.pop(str(name), None)

    def getenviron(self):
        return dict(os.environ)

    def loadFile(self, path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

    readFile = loadFile

    def strerror(self, errno):
        return os.strerror(int(errno))

    def gc(self):
        return None

    def parseExtJSON(self, s):
        return json.loads(s)


class OSMod:
    platform = sys.platform

    def getcwd(self):
        return os.getcwd()

    def chdir(self, p):
        os.chdir(p)

    def remove(self, p):
        os.remove(p)

    def rename(self, a, b):
        os.rename(a, b)

    def mkdir(self, p, mode=0o777):
        os.mkdir(p, int(mode))

    def readdir(self, p):
        return os.listdir(p)

    def stat(self, p):
        st = os.stat(p)
        return {"size": st.st_size, "mtime": st.st_mtime, "mode": st.st_mode}

    lstat = stat

    def sleep(self, ms):
        time.sleep(float(ms) / 1000.0)


class Console:
    log = staticmethod(js_print)
    error = staticmethod(lambda *a: print(" ".join(js_repr(x) for x in a), file=sys.stderr))


class MathObj:
    PI = math.pi
    E = math.e
    abs = staticmethod(abs)
    max = staticmethod(lambda *a: max(a))
    min = staticmethod(lambda *a: min(a))
    floor = staticmethod(math.floor)
    ceil = staticmethod(math.ceil)
    round = staticmethod(round)
    sqrt = staticmethod(math.sqrt)
    pow = staticmethod(pow)
    sin = staticmethod(math.sin)
    cos = staticmethod(math.cos)
    tan = staticmethod(math.tan)
    random = staticmethod(lambda: 0.5)


def strip_comments(code):
    out = []
    i = 0
    quote = None
    while i < len(code):
        c = code[i]
        n = code[i + 1] if i + 1 < len(code) else ""
        if quote:
            out.append(c)
            if c == "\\" and i + 1 < len(code):
                i += 1
                out.append(code[i])
            elif c == quote:
                quote = None
        elif c in "'\"`":
            quote = c
            out.append(c)
        elif c == "/" and n == "/":
            while i < len(code) and code[i] != "\n":
                i += 1
            out.append("\n")
        elif c == "/" and n == "*":
            i += 2
            while i + 1 < len(code) and not (code[i] == "*" and code[i + 1] == "/"):
                i += 1
            i += 1
        else:
            out.append(c)
        i += 1
    return "".join(out)


def tokenize(code):
    code = strip_comments(code)
    toks, buf = [], []
    quote = None
    depth = 0
    i = 0
    while i < len(code):
        c = code[i]
        if quote:
            buf.append(c)
            if c == "\\" and i + 1 < len(code):
                i += 1
                buf.append(code[i])
            elif c == quote:
                quote = None
        elif c in "'\"`":
            quote = c
            buf.append(c)
        elif c in "([{":
            lead = "".join(buf).strip()
            if c == "{" and depth == 0 and (not lead or re.match(r"^(if|else|for|while|function|switch|try|catch|finally|do)\b", lead)):
                s = "".join(buf).strip()
                if s:
                    toks.append(s)
                toks.append("{")
                buf = []
            else:
                depth += 1
                buf.append(c)
        elif c in ")]}":
            if c == "}" and depth == 0:
                s = "".join(buf).strip()
                if s:
                    toks.append(s)
                toks.append("}")
                buf = []
            else:
                depth -= 1
                buf.append(c)
        elif c == ";" and depth == 0:
            s = "".join(buf).strip()
            if s:
                toks.append(s)
            buf = []
        elif c == "\n" and depth == 0:
            s = "".join(buf).strip()
            if s and (s.startswith(("import ", "let ", "const ", "var ", "return ", "throw ")) or re.match(r"^(console|print|std\\.|os\\.)", s)):
                toks.append(s)
                buf = []
            else:
                buf.append(c)
        else:
            buf.append(c)
        i += 1
    s = "".join(buf).strip()
    if s:
        toks.append(s)
    return toks


def quote_object_keys(expr):
    def repl(m):
        return m.group(1) + repr(m.group(2)) + ":"
    prev = None
    while prev != expr:
        prev = expr
        expr = re.sub(r"([,{]\s*)([A-Za-z_$][\w$]*)\s*:", repl, expr)
    if expr.strip().startswith("{"):
        expr = re.sub(r"(^\s*{\s*)([A-Za-z_$][\w$]*)\s*:", repl, expr)
    return expr


def wrap_object_literals(expr):
    def repl(m):
        return "JSObj(" + m.group(0) + ")"
    prev = None
    pat = re.compile(r"(?<!JSObj\()\{[^{}\n]*:[^{}\n]*\}")
    while prev != expr:
        prev = expr
        expr = pat.sub(repl, expr)
    return expr


def split_args(s):
    args, buf = [], []
    quote = None
    depth = 0
    for c in s:
        if quote:
            buf.append(c)
            if c == quote:
                quote = None
        elif c in "'\"`":
            quote = c
            buf.append(c)
        elif c in "([{":
            depth += 1
            buf.append(c)
        elif c in ")]}":
            depth -= 1
            buf.append(c)
        elif c == "," and depth == 0:
            args.append("".join(buf).strip())
            buf = []
        else:
            buf.append(c)
    if buf or s.strip():
        args.append("".join(buf).strip())
    return args


def transform_expr(expr):
    expr = expr.strip()
    if expr.startswith("`") and expr.endswith("`"):
        expr = repr(expr[1:-1])
    expr = quote_object_keys(expr)
    expr = wrap_object_literals(expr)
    expr = re.sub(r"\btrue\b", "True", expr)
    expr = re.sub(r"\bfalse\b", "False", expr)
    expr = re.sub(r"\bnull\b", "None", expr)
    expr = re.sub(r"\bundefined\b", "undefined", expr)
    expr = expr.replace("===", "==").replace("!==", "!=")
    expr = re.sub(r"(?<![=!<>])!(?!=)", " not ", expr)
    expr = expr.replace("&&", " and ").replace("||", " or ")
    expr = re.sub(r"\bMath\.", "Math.", expr)
    expr = re.sub(r"\bJSON\.stringify\s*\(", "js_json_stringify(", expr)
    expr = re.sub(r"\bJSON\.parse\s*\(", "js_json_parse(", expr)
    expr = re.sub(r"\bparseInt\s*\(", "parse_int(", expr)
    expr = re.sub(r"\bparseFloat\s*\(", "parse_float(", expr)
    expr = re.sub(r"\bNumber\s*\(", "float(", expr)
    expr = re.sub(r"\bBigInt\s*\(", "int(", expr)
    expr = re.sub(r"\bString\s*\(", "str(", expr)
    expr = re.sub(r"\b(\d+)n\b", r"\1", expr)
    expr = re.sub(r"\btypeof\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)", r"js_typeof_name('\1', __env__)", expr)
    expr = re.sub(r"([A-Za-z_$][\w$]*)\.length\b", r"len(\1)", expr)
    expr = re.sub(r"([A-Za-z_$][\w$]*)\.join\((.*?)\)", r"js_join(\1, \2)", expr)
    expr = re.sub(r"([A-Za-z_$][\w$]*)\.join\(\)", r"js_join(\1)", expr)
    expr = re.sub(r"([A-Za-z_$][\w$]*)\.push\((.*?)\)", r"js_push(\1, \2)", expr)
    expr = re.sub(r"([A-Za-z_$][\w$]*)\.toUpperCase\(\)", r"\1.upper()", expr)
    expr = re.sub(r"([A-Za-z_$][\w$]*)\.toLowerCase\(\)", r"\1.lower()", expr)
    expr = re.sub(r"([A-Za-z_$][\w$]*)\.trim\(\)", r"\1.strip()", expr)
    return expr


class Compiler:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0
        self.lines = []

    def emit(self, indent, line):
        self.lines.append("    " * indent + line)

    def compile(self):
        self.block(0)
        return "\n".join(self.lines) + "\n"

    def block(self, indent, until_brace=False, post=None):
        while self.pos < len(self.tokens):
            tok = self.tokens[self.pos]
            if tok == "}":
                self.pos += 1
                return
            self.pos += 1
            if tok == "{":
                self.block(indent, True, post)
                continue
            self.statement(tok, indent)
        if until_brace:
            return

    def compile_body(self, indent, post=None):
        if self.pos < len(self.tokens) and self.tokens[self.pos] == "{":
            self.pos += 1
            start = len(self.lines)
            self.block(indent, True)
            if post:
                self.emit(indent, post)
            if len(self.lines) == start:
                self.emit(indent, "pass")
        else:
            if self.pos < len(self.tokens):
                tok = self.tokens[self.pos]
                self.pos += 1
                self.statement(tok, indent)
                if post:
                    self.emit(indent, post)
            else:
                self.emit(indent, "pass")

    def statement(self, tok, indent):
        tok = tok.strip()
        if not tok or tok.startswith("import "):
            return
        tok = re.sub(r"^(export\s+default|export)\s+", "", tok)
        if tok.startswith(("let ", "const ", "var ")):
            tok = re.sub(r"^(let|const|var)\s+", "", tok)
        m = re.match(r"function\s+([A-Za-z_$][\w$]*)\s*\((.*?)\)$", tok)
        if m:
            self.emit(indent, f"def {m.group(1)}({m.group(2)}):")
            self.compile_body(indent + 1)
            return
        m = re.match(r"if\s*\((.*)\)$", tok)
        if m:
            self.emit(indent, f"if {transform_expr(m.group(1))}:")
            self.compile_body(indent + 1)
            if self.pos < len(self.tokens) and self.tokens[self.pos].startswith("else"):
                etok = self.tokens[self.pos]
                self.pos += 1
                if etok.startswith("else if"):
                    cond = re.match(r"else if\s*\((.*)\)$", etok).group(1)
                    self.emit(indent, f"elif {transform_expr(cond)}:")
                else:
                    self.emit(indent, "else:")
                self.compile_body(indent + 1)
            return
        m = re.match(r"while\s*\((.*)\)$", tok)
        if m:
            self.emit(indent, f"while {transform_expr(m.group(1))}:")
            self.compile_body(indent + 1)
            return
        m = re.match(r"for\s*\((.*?);(.*?);(.*)\)$", tok)
        if m:
            init, cond, inc = [x.strip() for x in m.groups()]
            if init:
                self.statement(init, indent)
            self.emit(indent, f"while {transform_expr(cond) if cond else 'True'}:")
            inc_py = self.simple_stmt(inc)
            self.compile_body(indent + 1, inc_py)
            return
        if tok.startswith("return"):
            expr = tok[6:].strip()
            self.emit(indent, "return" + ((" " + transform_expr(expr)) if expr else ""))
            return
        if tok.startswith("throw"):
            msg = tok[5:].strip()
            m = re.match(r"new\s+Error\s*\((.*)\)", msg)
            if m:
                self.emit(indent, f"raise JSError({transform_expr(m.group(1))})")
            else:
                self.emit(indent, f"raise JSError({transform_expr(msg)})")
            return
        self.emit(indent, self.simple_stmt(tok))

    def simple_stmt(self, tok):
        tok = re.sub(r"^(let|const|var)\s+", "", tok.strip())
        m = re.match(r"(.+)\+\+$", tok)
        if m:
            return transform_expr(m.group(1)) + " += 1"
        m = re.match(r"(.+)--$", tok)
        if m:
            return transform_expr(m.group(1)) + " -= 1"
        m = re.match(r"(?:console\.log|print)\s*\((.*)\)$", tok)
        if m:
            return "js_print(" + ", ".join(transform_expr(a) for a in split_args(m.group(1))) + ")"
        m = re.match(r"console\.error\s*\((.*)\)$", tok)
        if m:
            return "Console.error(" + ", ".join(transform_expr(a) for a in split_args(m.group(1))) + ")"
        return transform_expr(tok)


def run_js(code, filename="<eval>", script_args=None, env=None):
    if env is None:
        env = base_env(script_args or [])
    py = Compiler(tokenize(code)).compile()
    try:
        exec(py, env, env)
    except JSError as e:
        loc = "<cmdline>:1:1" if filename == "<eval>" else f"{filename}:1"
        print(f"Error: {e}", file=sys.stderr)
        print(f"    at {filename} ({loc})", file=sys.stderr)
        return 1
    except SyntaxError as e:
        print(f"SyntaxError: {e.msg}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"{type(e).__name__}: {e}", file=sys.stderr)
        return 1
    return 0


def base_env(script_args):
    env = {
        "__builtins__": {"len": len, "str": str, "int": int, "float": float, "round": round, "abs": abs, "range": range},
        "undefined": undefined,
        "console": Console,
        "print": js_print,
        "std": Std(),
        "os": OSMod(),
        "Math": MathObj,
        "js_print": js_print,
        "js_repr": js_repr,
        "js_join": js_join,
        "js_push": js_push,
        "js_json_stringify": js_json_stringify,
        "js_json_parse": js_json_parse,
        "parse_int": parse_int,
        "parse_float": parse_float,
        "js_typeof_name": js_typeof_name,
        "JSError": JSError,
        "JSObj": JSObj,
        "scriptArgs": script_args,
        "arguments": script_args[1:] if script_args else [],
        "NaN": float("nan"),
        "Infinity": float("inf"),
    }
    env["__env__"] = env
    return env


def main(argv):
    evals = []
    includes = []
    interactive = False
    dump = False
    quit_only = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP)
            return 0
        if a in ("-e", "--eval"):
            if i + 1 >= len(argv):
                print("qjs: missing expression for -e", file=sys.stderr)
                return 1
            evals.append(argv[i + 1])
            i += 2
            continue
        if a in ("-I", "--include"):
            includes.append(argv[i + 1])
            i += 2
            continue
        if a in ("-i", "--interactive"):
            interactive = True
            i += 1
            continue
        if a in ("-q", "--quit"):
            quit_only = True
            i += 1
            continue
        if a in ("-d", "--dump"):
            dump = True
            i += 1
            continue
        if a in ("-m", "--module", "--script", "--strict", "--std", "-T", "--trace", "-s", "--strip-source", "--no-unhandled-rejection"):
            i += 1
            continue
        if a in ("--memory-limit", "--stack-size"):
            i += 2
            continue
        if a.startswith("-"):
            print(f"qjs: unknown option '{a}'", file=sys.stderr)
            print(HELP, file=sys.stderr)
            return 1
        break
    if quit_only:
        return 0
    env = base_env([])
    status = 0
    for path in includes:
        try:
            with open(path, encoding="utf-8") as f:
                status = run_js(f.read(), path, [], env)
        except OSError as e:
            print(f"Could not load '{path}': {e}", file=sys.stderr)
            return 1
        if status:
            return status
    for expr in evals:
        status = run_js(expr, "<eval>", [], env)
        if status:
            return status
    if i < len(argv):
        path = argv[i]
        sargs = argv[i:]
        env["scriptArgs"] = sargs
        env["arguments"] = sargs[1:]
        try:
            with open(path, encoding="utf-8") as f:
                status = run_js(f.read(), path, sargs, env)
        except OSError as e:
            print(f"Could not load '{path}': {e}", file=sys.stderr)
            return 1
    elif interactive:
        print(f"QuickJS - Type Ctrl-D to exit")
        for line in sys.stdin:
            run_js(line, "<stdin>", [], env)
    if dump:
        print("QuickJS memory usage -- Python compatibility implementation")
    return status


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
