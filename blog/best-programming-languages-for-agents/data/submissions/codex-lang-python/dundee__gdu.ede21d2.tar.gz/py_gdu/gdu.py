#!/usr/bin/env python3
import argparse
import fnmatch
import json
import os
import re
import shutil
import stat
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path

VERSION_TEXT = "Version:\t dev\nBuilt time:\t Fri Apr 17 19:59:35 UTC 2026\nBuilt user:\t root"
HELP_TEXT = """Pretty fast disk usage analyzer written in Go.

Gdu is intended primarily for SSD disks where it can fully utilize parallel processing.
However HDDs work as well, but the performance gain is not so huge.

Usage:
  gdu [directory_to_scan] [flags]

Flags:
      --archive-browsing              Enable browsing of zip/jar archives
      --collapse-path                 Collapse single-child directory chains
      --config-file string            Read config from file (default is $HOME/.gdu.yaml)
  -D, --db string                     Store analysis in database (*.sqlite for SQLite, *.badger for BadgerDB)
      --depth int                     Show directory structure up to specified depth in non-interactive mode (0 means the flag is ignored)
      --enable-profiling              Enable collection of profiling data and provide it on http://localhost:6060/debug/pprof/
  -E, --exclude-type strings          File types to exclude (e.g., --exclude-type yaml,json)
  -L, --follow-symlinks               Follow symlinks for files, i.e. show the size of the file to which symlink points to (symlinks to directories are not followed)
  -h, --help                          help for gdu
  -i, --ignore-dirs strings           Paths to ignore (separated by comma). Can be absolute or relative to current directory (default [/proc,/dev,/sys,/run])
  -I, --ignore-dirs-pattern strings   Path patterns to ignore (separated by comma)
  -X, --ignore-from string            Read path patterns to ignore from file
  -f, --input-file string             Import analysis from JSON file
  -l, --log-file string               Path to a logfile (default "/dev/null")
      --max-age string                Include files with mtime no older than DURATION (e.g., 7d, 2h30m, 1y2mo)
  -m, --max-cores int                 Set max cores that Gdu will use. 14 cores available (default 14)
      --min-age string                Include files with mtime at least DURATION old (e.g., 30d, 1w)
      --mouse                         Use mouse
  -c, --no-color                      Do not use colorized output
  -x, --no-cross                      Do not cross filesystem boundaries
      --no-delete                     Do not allow deletions
  -H, --no-hidden                     Ignore hidden directories (beginning with dot)
      --no-prefix                     Show sizes as raw numbers without any prefixes (SI or binary) in non-interactive mode
  -p, --no-progress                   Do not show progress in non-interactive mode
      --no-spawn-shell                Do not allow spawning shell
  -u, --no-unicode                    Do not use Unicode symbols (for size bar)
  -n, --non-interactive               Do not run in interactive mode
  -o, --output-file string            Export all info into file as JSON
  -r, --read-from-storage             Use existing database instead of re-scanning
      --reverse-sort                  Reverse sorting order (smallest to largest) in non-interactive mode
      --sequential                    Use sequential scanning (intended for rotating HDDs)
  -A, --show-annexed-size             Use apparent size of git-annex'ed files in case files are not present locally (real usage is zero)
  -a, --show-apparent-size            Show apparent size
  -d, --show-disks                    Show all mounted disks
  -k, --show-in-kib                   Show sizes in KiB (or kB with --si) in non-interactive mode
  -C, --show-item-count               Show number of items in directory
  -M, --show-mtime                    Show latest mtime of items in directory
  -B, --show-relative-size            Show relative size
      --si                            Show sizes with decimal SI prefixes (kB, MB, GB) instead of binary prefixes (KiB, MiB, GiB)
      --since string                  Include files with mtime >= WHEN. WHEN accepts RFC3339 timestamp (e.g., 2025-08-11T01:00:00-07:00) or date only YYYY-MM-DD (calendar-day compare; includes the whole day)
  -s, --summarize                     Show only a total in non-interactive mode
  -t, --top int                       Show only top X largest files in non-interactive mode
  -T, --type strings                  File types to include (e.g., --type yaml,json)
      --until string                  Include files with mtime <= WHEN. WHEN accepts RFC3339 timestamp or date only YYYY-MM-DD
  -v, --version                       Print version
      --write-config                  Write current configuration to file
"""

@dataclass
class Node:
    path: str
    name: str
    is_dir: bool = False
    is_link: bool = False
    notreg: bool = False
    hard: bool = False
    error: bool = False
    dsize: int = 0
    asize: int = 0
    mtime: int = 0
    children: list = field(default_factory=list)
    from_json: bool = False

    @property
    def empty_dir(self):
        return self.is_dir and not self.children and not self.from_json

    def shown_size(self, apparent=False):
        return self.asize if apparent else self.dsize


def split_csv(values):
    out=[]
    for v in values or []:
        for p in str(v).split(','):
            p=p.strip()
            if p:
                out.append(p)
    return out


def ext_of(path):
    base=os.path.basename(path)
    if '.' in base:
        return base.rsplit('.',1)[1]
    return ''


def parse_duration(s):
    if not s:
        return None
    units={'s':1,'m':60,'h':3600,'d':86400,'w':604800,'mo':2592000,'y':31536000}
    total=0; pos=0
    for m in re.finditer(r'(\d+)(mo|[smhdwy])', s):
        if m.start()!=pos:
            return None
        total += int(m.group(1))*units[m.group(2)]
        pos=m.end()
    return total if pos==len(s) else None


def parse_when(s, end=False):
    if not s:
        return None
    try:
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}', s):
            dt=datetime.strptime(s, '%Y-%m-%d').replace(tzinfo=timezone.utc)
            if end:
                dt += timedelta(days=1)
                return dt.timestamp()-1e-6
            return dt.timestamp()
        return datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
    except Exception:
        return None


def should_skip(path, st, args, root_abs):
    name=os.path.basename(path)
    if args.no_hidden and name.startswith('.') and os.path.abspath(path)!=root_abs:
        return True
    abs_path=os.path.abspath(path)
    rel=os.path.relpath(abs_path, os.getcwd())
    for ign in split_csv(args.ignore_dirs):
        if ign in ('/proc','/dev','/sys','/run') and not abs_path.startswith(ign.rstrip('/') + '/') and abs_path != ign:
            continue
        if os.path.isabs(ign):
            if abs_path == ign or abs_path.startswith(ign.rstrip('/') + '/'):
                return True
        elif rel == ign or rel.startswith(ign.rstrip('/') + '/') or name == ign:
            return True
    for pat in args.ignore_patterns_all:
        try:
            if re.search(pat, abs_path) or re.search(pat, path):
                return True
        except re.error:
            if fnmatch.fnmatch(abs_path, pat):
                return True
    exts=split_csv(args.types)
    excl=split_csv(args.exclude_types)
    e=ext_of(path)
    if excl and e in excl:
        return True
    since=parse_when(args.since, False)
    until=parse_when(args.until, True)
    now=time.time()
    maxage=parse_duration(args.max_age)
    minage=parse_duration(args.min_age)
    mt=st.st_mtime
    if since is not None and mt < since: return True
    if until is not None and mt > until: return True
    if maxage is not None and mt < now - maxage: return True
    if minage is not None and mt > now - minage: return True
    return False


def scan(path, args, seen, root_abs):
    try:
        st=os.lstat(path)
    except OSError as e:
        raise
    mode=st.st_mode
    is_link=stat.S_ISLNK(mode)
    is_dir=stat.S_ISDIR(mode)
    st_size=st.st_size
    blocks=st.st_blocks*512 if hasattr(st,'st_blocks') else st.st_size
    if is_link and args.follow_symlinks:
        try:
            tgt=os.stat(path)
            if not stat.S_ISDIR(tgt.st_mode):
                st_size=tgt.st_size; blocks=tgt.st_blocks*512
        except OSError:
            pass
    node=Node(path=os.path.abspath(path), name=os.path.basename(path) or path, is_dir=is_dir, is_link=is_link, notreg=(is_link or not stat.S_ISREG(mode) and not is_dir), dsize=blocks, asize=st_size, mtime=int(st.st_mtime))
    key=(st.st_dev, st.st_ino)
    if not is_dir and st.st_nlink>1:
        node.hard=True
    if is_dir:
        try:
            entries=sorted(os.listdir(path))
        except OSError:
            node.error=True
            return node
        for ent in entries:
            child_path=os.path.join(path, ent)
            try:
                cst=os.lstat(child_path)
            except OSError:
                continue
            # Type include is lenient for directories: keep ancestors, filter leaves.
            if should_skip(child_path, cst, args, root_abs):
                continue
            child=scan(child_path, args, seen, root_abs)
            type_filter=split_csv(args.types)
            if type_filter and not child.is_dir and ext_of(child.path) not in type_filter:
                continue
            if child.is_dir and type_filter and not contains_type(child, type_filter):
                # keep empty dirs like gdu does in several listings
                pass
            node.children.append(child)
            node.dsize += child.dsize
            node.asize += child.asize
            node.mtime=max(node.mtime, child.mtime)
    return node


def contains_type(node, types):
    if not node.is_dir:
        return ext_of(node.path) in types
    return any(contains_type(c, types) for c in node.children)


def node_to_json(node):
    meta={"name": node.path if os.path.isabs(node.path) else node.name}
    if not os.path.isabs(meta['name']): meta['name']=node.name
    meta['mtime']=node.mtime
    if node.asize: meta['asize']=node.asize
    if node.dsize: meta['dsize']=node.dsize
    if node.notreg: meta['notreg']=True
    if node.hard: meta['hlnkc']=True
    if node.is_dir:
        arr=[{"name": node.path, "mtime": node.mtime}]
        arr[0].pop('asize', None); arr[0].pop('dsize', None)
        for c in node.children:
            arr.append(node_to_json(c))
        return arr
    d={"name": node.name, "mtime": node.mtime}
    if node.asize: d['asize']=node.asize
    if node.dsize: d['dsize']=node.dsize
    if node.notreg: d['notreg']=True
    if node.hard: d['hlnkc']=True
    return d


def json_to_node(obj, parent=''):
    if isinstance(obj, list):
        meta=obj[0]
        name=meta.get('name','')
        path=name if os.path.isabs(name) else os.path.join(parent, name)
        n=Node(path=path, name=os.path.basename(path), is_dir=True, mtime=int(meta.get('mtime',0)), from_json=True)
        n.dsize=int(meta.get('dsize',4096) or 4096); n.asize=int(meta.get('asize',4096) or 4096)
        for item in obj[1:]:
            c=json_to_node(item, path)
            n.children.append(c)
            n.dsize += c.dsize
            n.asize += c.asize
            n.mtime=max(n.mtime,c.mtime)
        return n
    path=os.path.join(parent, obj.get('name',''))
    return Node(path=path, name=obj.get('name',''), is_dir=False, is_link=bool(obj.get('notreg')), notreg=bool(obj.get('notreg')), hard=bool(obj.get('hlnkc')), dsize=int(obj.get('dsize',0) or 0), asize=int(obj.get('asize',0) or 0), mtime=int(obj.get('mtime',0) or 0))


def format_size(n, args, compact=False):
    if args.no_prefix:
        return f"{int(n):10d}" if not compact else f"{int(n):8d}"
    base=1000 if args.si else 1024
    units=['B','kB','MB','GB','TB','PB'] if args.si else ['B','KiB','MiB','GiB','TiB','PiB']
    if args.show_in_kib:
        val=n/base
        return f"{val:6.1f} {units[1]}" if not compact else f"{val:4.1f} {units[1]}"
    if abs(n) < base:
        return f"{int(n):8d} B" if not compact else f"{int(n):6d} B"
    val=float(n); idx=0
    while abs(val) >= base and idx < len(units)-1:
        val/=base; idx+=1
    return f"{val:6.1f} {units[idx]}" if not compact else f"{val:4.1f} {units[idx]}"


def line_for(node, name, args, flags=True, compact=False):
    flag=' '
    if flags:
        if node.error: flag='!'
        elif node.hard: flag='H'
        elif node.empty_dir: flag='e'
        elif node.notreg or node.is_link: flag='@'
    return f"{flag}{format_size(node.shown_size(args.show_apparent_size), args, compact)} {name}"

def child_display_name(root, child):
    if child.is_dir:
        return '/' + child.name
    return child.name


def sort_nodes(nodes, args):
    rev=not args.reverse_sort
    return sorted(nodes, key=lambda n: (n.dsize, n.name), reverse=rev)


def flatten(node, max_depth, cur=0):
    out=[node]
    if max_depth and cur>=max_depth:
        return out
    for c in sort_nodes(node.children, argparse.Namespace(reverse_sort=False)):
        if c.is_dir:
            out.extend(flatten(c, max_depth, cur+1))
        else:
            out.append(c)
    return out


def print_listing(root, args):
    if args.summarize:
        print(line_for(root, os.path.basename(root.path.rstrip(os.sep)) or root.path, args, flags=False, compact=True))
        return
    if args.depth and args.depth>0:
        nodes=flatten(root, args.depth)
        if args.top and args.top>0:
            nodes=[n for n in nodes if not n.is_dir][:args.top]
        for n in nodes:
            print(line_for(n, n.path, args, flags=False, compact=True))
        return
    nodes=sort_nodes(root.children, args)
    if args.top and args.top>0:
        leaves=[]
        def rec(n):
            if n.is_dir:
                for c in n.children: rec(c)
            else:
                leaves.append(n)
        rec(root)
        nodes=sort_nodes(leaves, args)[:args.top]
        for n in nodes:
            print(line_for(n, n.path, args, flags=False, compact=True))
        return
    for c in nodes:
        print(line_for(c, child_display_name(root, c), args))


def show_disks(args):
    print("   Device      Size      Used      Free Used% Mount point")
    try:
        seen=set()
        with open('/proc/mounts') as f:
            for line in f:
                parts=line.split()
                if len(parts)<2: continue
                dev, mp=parts[0], parts[1]
                if not dev.startswith('/dev/') or (dev,mp) in seen: continue
                seen.add((dev,mp))
                try:
                    u=shutil.disk_usage(mp)
                except OSError:
                    continue
                pct=int(round((u.used/u.total)*100)) if u.total else 0
                ns=argparse.Namespace(si=False, show_in_kib=False, no_prefix=False)
                print(f"{dev:<8} {format_size(u.total, ns).strip():>9} {format_size(u.used, ns).strip():>9} {format_size(u.free, ns).strip():>9} {pct:>4}% {mp}")
    except Exception:
        pass


def write_config(path):
    text='''style:\n    footer:\n        text-color: '#000000'\n        background-color: '#2479D0'\n        number-color: '#FFFFFF'\nsorting:\n    by: ""\n    order: ""\nlog-file: /dev/null\ninput-file: ""\noutput-file: ""\nignore-from-file: ""\nignore-dirs:\n    - /proc\n    - /dev\n    - /sys\n    - /run\nignore-dir-patterns: []\ntype: []\nexclude-type: []\nmax-cores: 14\ntop: 0\ndepth: 0\nsequential-scanning: false\nshow-apparent-size: false\nshow-relative-size: false\nshow-annexed-size: false\nshow-item-count: false\nshow-mtime: false\nno-color: false\nmouse: false\nnon-interactive: false\nno-progress: false\nno-unicode: false\nno-cross: false\nno-hidden: false\nno-delete: false\nno-spawn-shell: false\nfollow-symlinks: false\nprofiling: false\nread-from-storage: false\ndb: ""\nsummarize: false\nuse-si-prefix: false\nno-prefix: false\nshow-in-kib: false\nreverse-sort: false\nchange-cwd: false\ndelete-in-background: false\ndelete-in-parallel: false\nsince: ""\nuntil: ""\nmax-age: ""\nmin-age: ""\narchive-browsing: false\ncollapse-path: false\n'''
    with open(path,'w') as f: f.write(text)


class GduParser(argparse.ArgumentParser):
    def error(self, message):
        if message.startswith('unrecognized arguments:'):
            arg=message.split(':',1)[1].strip().split()[0]
            self.exit(1, f"Error: unknown flag: {arg}\n")
        self.exit(1, f"Error: {message}\n")

def build_parser():
    p=GduParser(add_help=False, prog='gdu')
    p.add_argument('directory', nargs='?')
    p.add_argument('-h','--help', action='store_true')
    p.add_argument('-v','--version', action='store_true')
    p.add_argument('-n','--non-interactive', action='store_true')
    p.add_argument('-p','--no-progress', action='store_true')
    p.add_argument('-c','--no-color', action='store_true')
    p.add_argument('-a','--show-apparent-size', action='store_true')
    p.add_argument('-s','--summarize', action='store_true')
    p.add_argument('-d','--show-disks', action='store_true')
    p.add_argument('-k','--show-in-kib', action='store_true')
    p.add_argument('-H','--no-hidden', action='store_true')
    p.add_argument('-L','--follow-symlinks', action='store_true')
    p.add_argument('-C','--show-item-count', action='store_true')
    p.add_argument('-M','--show-mtime', action='store_true')
    p.add_argument('-B','--show-relative-size', action='store_true')
    p.add_argument('-x','--no-cross', action='store_true')
    p.add_argument('-u','--no-unicode', action='store_true')
    p.add_argument('-A','--show-annexed-size', action='store_true')
    p.add_argument('-r','--read-from-storage', action='store_true')
    p.add_argument('--si', action='store_true')
    p.add_argument('--no-prefix', action='store_true')
    p.add_argument('--reverse-sort', action='store_true')
    p.add_argument('--write-config', action='store_true')
    p.add_argument('--archive-browsing', action='store_true')
    p.add_argument('--collapse-path', action='store_true')
    p.add_argument('--enable-profiling', action='store_true')
    p.add_argument('--mouse', action='store_true')
    p.add_argument('--no-delete', action='store_true')
    p.add_argument('--no-spawn-shell', action='store_true')
    p.add_argument('--sequential', action='store_true')
    p.add_argument('--depth', type=int, default=0)
    p.add_argument('-t','--top', type=int, default=0)
    p.add_argument('-m','--max-cores', type=int, default=14)
    p.add_argument('-o','--output-file')
    p.add_argument('-f','--input-file')
    p.add_argument('-l','--log-file', default='/dev/null')
    p.add_argument('-D','--db')
    p.add_argument('--config-file', default=os.path.expanduser('~/.gdu.yaml'))
    p.add_argument('-i','--ignore-dirs', action='append', default=['/proc,/dev,/sys,/run'])
    p.add_argument('-I','--ignore-dirs-pattern', dest='ignore_patterns', action='append', default=[])
    p.add_argument('-X','--ignore-from')
    p.add_argument('-T','--type', dest='types', action='append', default=[])
    p.add_argument('-E','--exclude-type', dest='exclude_types', action='append', default=[])
    p.add_argument('--since', default='')
    p.add_argument('--until', default='')
    p.add_argument('--max-age', default='')
    p.add_argument('--min-age', default='')
    return p


def main(argv=None):
    argv=sys.argv[1:] if argv is None else argv
    p=build_parser()
    try:
        args=p.parse_args(argv)
    except SystemExit:
        # argparse already printed; mimic cobra prefix for common unknown flag
        return 1
    if args.help:
        print(HELP_TEXT, end='')
        return 0
    if args.version:
        print(VERSION_TEXT)
        return 0
    args.ignore_patterns_all=list(args.ignore_patterns or [])
    if args.ignore_from:
        try:
            with open(args.ignore_from) as f:
                args.ignore_patterns_all += [line.strip() for line in f if line.strip()]
        except OSError as e:
            print(f"Error: {e}", file=sys.stderr); return 1
    if args.write_config:
        write_config(args.config_file)
    if args.show_disks:
        show_disks(args)
        return 0 if not args.write_config else 0
    try:
        if args.input_file:
            with open(args.input_file) as f: data=json.load(f)
            root=json_to_node(data[3] if isinstance(data,list) and len(data)>3 else data)
        else:
            target=args.directory or os.getcwd()
            st=os.lstat(target)
            if should_skip(target, st, args, os.path.abspath(target)):
                root=Node(path=os.path.abspath(target), name=os.path.basename(target), is_dir=stat.S_ISDIR(st.st_mode), dsize=0, asize=0, mtime=int(st.st_mtime))
            else:
                root=scan(target, args, set(), os.path.abspath(target))
        if args.output_file:
            payload=[1,2,{"progname":"gdu","progver":"dev","timestamp":int(time.time())}, node_to_json(root)]
            with open(args.output_file,'w') as f:
                json.dump(payload, f, separators=(',',':'))
                f.write('\n')
            return 0
        print_listing(root, args)
        return 0
    except OSError as e:
        msg = f"stat {getattr(e, 'filename', '')}: {str(e.strerror).lower()}" if isinstance(e, FileNotFoundError) else str(e)
        print(f"Error: {msg}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

if __name__ == '__main__':
    sys.exit(main())
