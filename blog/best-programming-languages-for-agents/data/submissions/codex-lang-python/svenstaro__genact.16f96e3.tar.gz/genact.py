#!/usr/bin/env python3
import argparse
import random
import signal
import sys
import time
from datetime import datetime

MODULES = [
    "ansible", "bootlog", "botnet", "bruteforce", "cargo", "cc", "composer",
    "cryptomining", "docker_build", "docker_image_rm", "download", "julia",
    "kernel_compile", "memdump", "mkinitcpio", "rkhunter", "simcity",
    "terraform", "uv", "weblog", "wpt",
]
SHELLS = ["bash", "elvish", "fish", "powershell", "zsh"]
GREEN = "\033[1;32m"
BOLD = "\033[1m"
RESET = "\033[0m"


def out(s="", end="\n"):
    try:
        sys.stdout.write(s + end)
        sys.stdout.flush()
    except BrokenPipeError:
        sys.exit(0)


def err(s):
    sys.stderr.write(s)
    sys.stderr.flush()


def help_text(prog):
    return f"""A nonsense activity generator

Usage: {prog} [OPTIONS]

Options:
  -l, --list-modules
          List available modules
  -m, --modules <MODULES>
          Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,
          composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,
          memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]
  -s, --speed-factor <SPEED_FACTOR>
          Global speed factor [default: 1]
  -i, --instant-print-lines <INSTANT_PRINT_LINES>
          Instantly print this many lines [default: 0]
      --inhibit
          Keep the computer awake and the display on while genact is running
      --exit-after-time <EXIT_AFTER_TIME>
          Exit after running for this long (format example: 2h10min)
      --exit-after-modules <EXIT_AFTER_MODULES>
          Exit after running this many modules
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,
          zsh]
      --print-manpage
          Generate man page
  -h, --help
          Print help
  -V, --version
          Print version
"""


class Parser(argparse.ArgumentParser):
    def error(self, message):
        if message.startswith("argument -m/--modules: invalid choice:"):
            val = message.split("'", 2)[1]
            invalid_module(val)
        if message.startswith("argument --print-completions: invalid choice:"):
            val = message.split("'", 2)[1]
            invalid_shell(val)
        err(f"error: {message}\n\nFor more information, try '--help'.\n")
        raise SystemExit(2)


def invalid_module(val):
    err(f"error: invalid value '{val}' for '--modules <MODULES>'\n")
    err("  [possible values: " + ", ".join(MODULES) + "]\n")
    sim = closest(val, MODULES)
    if sim:
        err(f"\n  tip: a similar value exists: '{sim}'\n")
    err("\nFor more information, try '--help'.\n")
    raise SystemExit(2)


def invalid_shell(val):
    err(f"error: invalid value '{val}' for '--print-completions <shell>'\n")
    err("  [possible values: " + ", ".join(SHELLS) + "]\n\n")
    err("For more information, try '--help'.\n")
    raise SystemExit(2)


def closest(v, choices):
    import difflib
    m = difflib.get_close_matches(v, choices, n=1, cutoff=0.45)
    return m[0] if m else None


def parse_duration(s):
    import re
    total = 0.0
    found = False
    for num, unit in re.findall(r"(\d+(?:\.\d+)?)(h|min|m|s|sec|secs|second|seconds)?", s):
        found = True
        n = float(num)
        if unit == "h":
            total += n * 3600
        elif unit in ("min", "m"):
            total += n * 60
        else:
            total += n
    return total if found else None


def list_modules():
    out("Available modules:")
    for m in MODULES:
        out(f"  {m}")


def print_manpage():
    out(""".ie \\n(.g .ds Aq \\(aq
.el .ds Aq '
.TH genact 1  "genact 1.5.1"
.SH NAME
genact \\- A nonsense activity generator
.SH SYNOPSIS
\\fBgenact\\fR [\\fB\\-l\\fR|\\fB\\-\\-list\\-modules\\fR] [\\fB\\-m\\fR|\\fB\\-\\-modules\\fR] [OPTIONS]
.SH DESCRIPTION
A nonsense activity generator
.SH OPTIONS
.TP
\\fB\\-l\\fR, \\fB\\-\\-list\\-modules\\fR
List available modules
.TP
\\fB\\-m\\fR, \\fB\\-\\-modules\\fR \\fI<MODULES>\\fR
Run only these modules
.TP
\\fB\\-s\\fR, \\fB\\-\\-speed\\-factor\\fR \\fI<SPEED_FACTOR>\\fR [default: 1]
Global speed factor
.TP
\\fB\\-i\\fR, \\fB\\-\\-instant\\-print\\-lines\\fR \\fI<INSTANT_PRINT_LINES>\\fR [default: 0]
Instantly print this many lines
""")


def print_completions(shell):
    opts = "-l -m -s -i -h -V --list-modules --modules --speed-factor --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage --help --version"
    mods = " ".join(MODULES)
    if shell == "bash":
        out(f"""_genact() {{
    local cur prev opts
    COMPREPLY=()
    cur="${{COMP_WORDS[COMP_CWORD]}}"
    prev="${{COMP_WORDS[COMP_CWORD-1]}}"
    opts="{opts}"
    case "${{prev}}" in
        --modules|-m) COMPREPLY=($(compgen -W "{mods}" -- "${{cur}}")); return 0 ;;
        --print-completions) COMPREPLY=($(compgen -W "bash elvish fish powershell zsh" -- "${{cur}}")); return 0 ;;
    esac
    COMPREPLY=($(compgen -W "${{opts}}" -- "${{cur}}"))
}}
complete -F _genact genact""")
    elif shell == "fish":
        out("complete -c genact -s l -l list-modules -d 'List available modules'")
        out(f"complete -c genact -s m -l modules -a '{mods}' -d 'Run only these modules'")
    elif shell == "zsh":
        out(f"#compdef genact\n_arguments '*--modules[{mods}]' '--help[Print help]'")
    elif shell == "powershell":
        out("Register-ArgumentCompleter -CommandName genact -ScriptBlock { param($wordToComplete) @(")
        out(", ".join("'" + x + "'" for x in opts.split()))
        out(") | Where-Object { $_ -like \"$wordToComplete*\" } }")
    else:
        out(f"set edit:completion:arg-completer[genact] = [@words]{{ put {' '.join(opts.split())} }}")


WORDS = ["alpha", "cache", "core", "driver", "lib", "net", "parser", "sys", "test", "utils"]


def gen_line(module, i):
    r = random
    if module == "cargo":
        verbs = ["Downloading", "Compiling", "Checking", "Fresh", "Building"]
        crates = ["serde", "tokio", "clap", "rand", "regex", "openssl-sys", "syn", "quote", "hyper", "genact"]
        return f"{GREEN}{r.choice(verbs):>12}{RESET} {r.choice(crates)} v{r.randint(0,3)}.{r.randint(0,99)}.{r.randint(0,20)}"
    if module in ("cc", "kernel_compile"):
        path = f"{r.choice(['arch','drivers','fs','net','kernel','mm','sound'])}/{r.choice(WORDS)}/{r.choice(WORDS)}.o"
        return f"clang -c -O{r.randint(1,3)} -Wall -Wextra -march=x86-64 -I{r.choice(['include','kernel/trace','drivers/net'])} -D{r.choice(['DEBUG','NDEBUG','CONFIG_X86'])} -o {path}"
    if module == "bootlog":
        samples = ["BIOS-e820: [mem 0x0000000000001000-0x000000000009ffff] usable", "NX (Execute Disable) protection: active", "Freeing unused kernel memory", f"{BOLD}EXT4-fs{RESET}: mounted filesystem with ordered data mode", "systemd[1]: Started Journal Service."]
        return r.choice(samples)
    if module == "botnet":
        return f"\rEstablishing connections: {i:4d}/{r.randint(1200,9999)}"
    if module == "bruteforce":
        return f"Trying {r.choice(['admin','root','oracle','guest'])}@{r.randint(1,254)}.{r.randint(0,255)}.{r.randint(0,255)}.{r.randint(1,254)} password={r.choice(['password','123456','letmein','qwerty'])} ... failed"
    if module == "composer":
        return r.choice(["Loading composer repositories with package information", "Updating dependencies", "Installing psr/log (3.0.0)", "Generating autoload files"])
    if module == "cryptomining":
        return f"[{datetime.now().strftime('%H:%M:%S')}] accepted: {i}/{i+r.randint(1,10)} ({r.uniform(12.0,99.0):.2f} MH/s) yay!!!"
    if module == "docker_build":
        return r.choice([f"Step {r.randint(1,18)}/18 : RUN apt-get update", " ---> Using cache", f" ---> {r.randrange(16**12):012x}", "Successfully built " + f"{r.randrange(16**12):012x}"])
    if module == "docker_image_rm":
        return r.choice(["Untagged: local/image:latest", "Deleted: sha256:" + f"{r.randrange(16**32):032x}", "Deleted: " + f"{r.randrange(16**12):012x}"])
    if module == "download":
        return f"{r.randint(1,99):3d}% [{('=' * r.randint(3,24)).ljust(24)}] {r.uniform(0.1,99.9):5.1f} MiB/s"
    if module == "julia":
        return f"Precompiling project... {r.choice(['DataFrames','Flux','Plots','LinearAlgebra'])} [{r.randrange(16**8):08x}]"
    if module == "memdump":
        bs = " ".join(f"{r.randrange(256):02x}" for _ in range(16))
        asc = "".join(chr(r.randint(33,126)) for _ in range(16))
        return f"{i*16:08x}: {bs}  |{asc}|"
    if module == "mkinitcpio":
        return r.choice(["==> Building image from preset: /etc/mkinitcpio.d/linux.preset", "  -> Running build hook: [udev]", "==> Generating module dependencies", "==> Image generation successful"])
    if module == "rkhunter":
        return f"Checking {r.choice(['/bin/ls','/usr/bin/ssh','/etc/passwd','network interfaces'])} [{r.choice(['OK','Warning','Not found'])}]"
    if module == "simcity":
        return r.choice(["Funding transport department", "Constructing residential zone", "Power grid overload detected", "Reticulating splines"])
    if module == "terraform":
        return r.choice(["Refreshing Terraform state in-memory prior to plan...", "aws_instance.web: Creating...", "Plan: 4 to add, 2 to change, 0 to destroy.", "Apply complete! Resources: 4 added, 0 changed, 0 destroyed."])
    if module == "uv":
        return r.choice(["Resolved 83 packages in 17ms", "Prepared 12 packages in 420ms", "Installed 12 packages in 37ms", " + fastapi==0.115.0"])
    if module == "weblog":
        return f'{r.randint(1,223)}.{r.randint(0,255)}.{r.randint(0,255)}.{r.randint(1,254)} - - [{datetime.now().strftime("%d/%b/%Y:%H:%M:%S +0000")}] "GET /{r.choice(["","index.html","api/v1/users","assets/app.js"])} HTTP/1.1" {r.choice([200,200,301,404,500])} {r.randint(128,65535)}'
    if module == "wpt":
        return r.choice(["Running 1632 tests in 84 chunks", "PASS /html/dom/documents/document.html", "OK /css/css-grid/grid-template-areas.html", "Harness status: OK"])
    if module == "ansible":
        return r.choice(["PLAY [all] *********************************************************************", "TASK [Gathering Facts] *********************************************************", "ok: [web01]", "changed: [db01]", "PLAY RECAP *********************************************************************"])
    return f"{module}: processing {r.choice(WORDS)} #{i}"


def run_modules(mods, instant, speed, max_modules, until):
    delay = 0 if instant else max(0.005, 0.1 / max(speed, 0.001))
    completed = 0
    i = 0
    while True:
        for m in mods:
            line_count = instant if instant > 0 else 80
            for _ in range(max(1, line_count)):
                if until and time.time() >= until:
                    return
                out(gen_line(m, i))
                i += 1
                if delay:
                    time.sleep(delay)
            completed += 1
            if max_modules and completed >= max_modules:
                return
        if max_modules:
            return


def main(argv=None):
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    argv = sys.argv[1:] if argv is None else argv
    prog = sys.argv[0].split("/")[-1]
    if "-h" in argv or "--help" in argv:
        out(help_text(prog), end="")
        return 0
    if "-V" in argv or "--version" in argv:
        out("genact 1.5.1")
        return 0
    p = Parser(add_help=False)
    p.add_argument("-l", "--list-modules", action="store_true")
    p.add_argument("-m", "--modules", action="append", choices=MODULES)
    p.add_argument("-s", "--speed-factor", type=float, default=1.0)
    p.add_argument("-i", "--instant-print-lines", type=int, default=0)
    p.add_argument("--inhibit", action="store_true")
    p.add_argument("--exit-after-time")
    p.add_argument("--exit-after-modules", type=int)
    p.add_argument("--print-completions", choices=SHELLS)
    p.add_argument("--print-manpage", action="store_true")
    ns, extra = p.parse_known_args(argv)
    if extra:
        err(f"error: unexpected argument '{extra[0]}' found\n\nUsage: {prog} [OPTIONS]\n\nFor more information, try '--help'.\n")
        return 2
    if ns.list_modules:
        list_modules()
        return 0
    if ns.print_manpage:
        print_manpage()
        return 0
    if ns.print_completions:
        print_completions(ns.print_completions)
        return 0
    until = time.time() + parse_duration(ns.exit_after_time) if ns.exit_after_time else None
    mods = ns.modules or [random.choice(MODULES)]
    try:
        run_modules(mods, ns.instant_print_lines, ns.speed_factor, ns.exit_after_modules, until)
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
