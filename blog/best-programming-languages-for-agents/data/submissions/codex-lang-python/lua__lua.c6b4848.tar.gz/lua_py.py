#!/usr/bin/env python3
import math
import os
import re
import sys
import traceback


VERSION_LINE = "Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio"


class LuaError(Exception):
    pass


class ReturnSignal(Exception):
    def __init__(self, values):
        self.values = values


class BreakSignal(Exception):
    pass


def lua_truth(v):
    return not (v is None or v is False)


def lua_num(v):
    if isinstance(v, (int, float)):
        return v
    if isinstance(v, str):
        try:
            return int(v, 0)
        except Exception:
            try:
                return float(v)
            except Exception:
                pass
    raise LuaError(f"attempt to perform arithmetic on a {lua_type(v)} value")


def lua_str(v):
    if v is None:
        return "nil"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, float):
        if v.is_integer():
            return str(int(v))
        return repr(v)
    return str(v)


def lua_type(v):
    if v is None:
        return "nil"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, (int, float)):
        return "number"
    if isinstance(v, str):
        return "string"
    if isinstance(v, LuaTable):
        return "table"
    if callable(v):
        return "function"
    return "userdata"


class LuaTable:
    def __init__(self, initial=None):
        self.data = {}
        if initial:
            self.data.update(initial)

    def get(self, key):
        return self.data.get(key, None)

    def set(self, key, value):
        if value is None:
            self.data.pop(key, None)
        else:
            self.data[key] = value

    def length(self):
        i = 1
        while i in self.data and self.data[i] is not None:
            i += 1
        return i - 1

    def append(self, value):
        self.set(self.length() + 1, value)

    def items_for_pairs(self):
        return list(self.data.items())

    def __repr__(self):
        return "table: 0x%x" % (id(self) & 0xFFFFFFFF)


class LuaIterator:
    def __init__(self, kind, table):
        self.kind = kind
        self.table = table


class Env:
    def __init__(self, parent=None):
        self.vars = {}
        self.parent = parent

    def get(self, name):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        return None

    def set_local(self, name, value):
        self.vars[name] = value

    def set(self, name, value):
        if name in self.vars or self.parent is None:
            self.vars[name] = value
        else:
            self.parent.set(name, value)


class Token:
    def __init__(self, typ, val, line):
        self.typ = typ
        self.val = val
        self.line = line

    def __repr__(self):
        return f"Token({self.typ!r},{self.val!r})"


KEYWORDS = {
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
    "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return",
    "then", "true", "until", "while",
}


def tokenize(src):
    if src.startswith("#!"):
        src = "--" + src[2:]
    toks = []
    i = 0
    line = 1
    two = {"==", "~=", "<=", ">=", "//", "..", "<<", ">>"}
    three = {"..."}
    while i < len(src):
        c = src[i]
        if c in " \t\r\f\v":
            i += 1
            continue
        if c == "\n":
            line += 1
            i += 1
            continue
        if src.startswith("--[[", i):
            j = src.find("]]", i + 4)
            if j < 0:
                break
            line += src[i:j + 2].count("\n")
            i = j + 2
            continue
        if src.startswith("--", i):
            j = src.find("\n", i)
            if j < 0:
                break
            i = j
            continue
        if src.startswith("[[", i):
            j = src.find("]]", i + 2)
            if j < 0:
                raise LuaError("unfinished long string")
            val = src[i + 2:j]
            toks.append(Token("str", val, line))
            line += src[i:j + 2].count("\n")
            i = j + 2
            continue
        if c in "'\"":
            q = c
            i += 1
            out = []
            while i < len(src) and src[i] != q:
                if src[i] == "\\":
                    i += 1
                    if i >= len(src):
                        break
                    esc = src[i]
                    mp = {"n": "\n", "t": "\t", "r": "\r", "\\": "\\", '"': '"', "'": "'"}
                    out.append(mp.get(esc, esc))
                else:
                    out.append(src[i])
                    if src[i] == "\n":
                        line += 1
                i += 1
            i += 1
            toks.append(Token("str", "".join(out), line))
            continue
        if c.isdigit() or (c == "." and i + 1 < len(src) and src[i + 1].isdigit()):
            j = i
            if src.startswith(("0x", "0X"), i):
                j += 2
                while j < len(src) and re.match(r"[0-9a-fA-F]", src[j]):
                    j += 1
                val = int(src[i:j], 16)
            else:
                while j < len(src) and re.match(r"[0-9.eE+-]", src[j]):
                    if src[j] in "+-" and src[j - 1] not in "eE":
                        break
                    j += 1
                text = src[i:j]
                val = float(text) if any(ch in text for ch in ".eE") else int(text)
            toks.append(Token("num", val, line))
            i = j
            continue
        if c.isalpha() or c == "_":
            j = i + 1
            while j < len(src) and (src[j].isalnum() or src[j] == "_"):
                j += 1
            word = src[i:j]
            toks.append(Token("kw" if word in KEYWORDS else "name", word, line))
            i = j
            continue
        if src[i:i + 3] in three:
            toks.append(Token("sym", src[i:i + 3], line)); i += 3; continue
        if src[i:i + 2] in two:
            toks.append(Token("sym", src[i:i + 2], line)); i += 2; continue
        toks.append(Token("sym", c, line))
        i += 1
    toks.append(Token("eof", "eof", line))
    return toks


class Parser:
    def __init__(self, src):
        self.toks = tokenize(src)
        self.i = 0

    def peek(self):
        return self.toks[self.i]

    def pop(self):
        t = self.peek(); self.i += 1; return t

    def accept(self, val):
        if self.peek().val == val:
            self.pop(); return True
        return False

    def expect(self, val):
        if not self.accept(val):
            raise LuaError(f"syntax error near '{self.peek().val}'")

    def parse(self):
        return self.block({"eof"})

    def block(self, stops):
        out = []
        while self.peek().val not in stops and self.peek().typ != "eof":
            if self.accept(";"):
                continue
            out.append(self.statement())
        return out

    def statement(self):
        t = self.peek()
        if t.val == "return":
            self.pop()
            vals = [] if self.peek().val in {"end", "else", "elseif", "until", "eof", ";"} else self.exprlist()
            self.accept(";")
            return ("return", vals)
        if t.val == "break":
            self.pop(); return ("break",)
        if t.val == "local":
            self.pop()
            if self.accept("function"):
                name = self.pop().val
                func = self.funcbody()
                return ("local", [name], [func])
            names = [self.pop().val]
            while self.accept(","):
                names.append(self.pop().val)
            vals = self.exprlist() if self.accept("=") else []
            return ("local", names, vals)
        if t.val == "function":
            self.pop()
            target = self.variable()
            func = self.funcbody()
            return ("assign", [target], [func])
        if t.val == "if":
            self.pop()
            branches = []
            cond = self.expr(); self.expect("then")
            branches.append((cond, self.block({"elseif", "else", "end"})))
            while self.accept("elseif"):
                cond = self.expr(); self.expect("then")
                branches.append((cond, self.block({"elseif", "else", "end"})))
            elseblk = None
            if self.accept("else"):
                elseblk = self.block({"end"})
            self.expect("end")
            return ("if", branches, elseblk)
        if t.val == "while":
            self.pop(); cond = self.expr(); self.expect("do")
            body = self.block({"end"}); self.expect("end")
            return ("while", cond, body)
        if t.val == "repeat":
            self.pop(); body = self.block({"until"}); self.expect("until")
            return ("repeat", body, self.expr())
        if t.val == "do":
            self.pop(); body = self.block({"end"}); self.expect("end")
            return ("do", body)
        if t.val == "for":
            self.pop(); name = self.pop().val
            if self.accept("="):
                a = self.expr(); self.expect(","); b = self.expr()
                step = self.expr() if self.accept(",") else ("num", 1)
                self.expect("do"); body = self.block({"end"}); self.expect("end")
                return ("fornum", name, a, b, step, body)
            names = [name]
            while self.accept(","):
                names.append(self.pop().val)
            self.expect("in"); vals = self.exprlist(); self.expect("do")
            body = self.block({"end"}); self.expect("end")
            return ("forin", names, vals, body)
        lhs = [self.prefix()]
        if self.peek().val in {",", "="}:
            while self.accept(","):
                lhs.append(self.prefix())
            self.expect("=")
            return ("assign", lhs, self.exprlist())
        return ("exprstmt", lhs[0])

    def funcbody(self):
        self.expect("(")
        params = []
        vararg = False
        if not self.accept(")"):
            if self.accept("..."):
                vararg = True
            else:
                params.append(self.pop().val)
                while self.accept(","):
                    if self.accept("..."):
                        vararg = True; break
                    params.append(self.pop().val)
            self.expect(")")
        body = self.block({"end"})
        self.expect("end")
        return ("function", params, vararg, body)

    def exprlist(self):
        vals = [self.expr()]
        while self.accept(","):
            vals.append(self.expr())
        return vals

    def expr(self, minp=0):
        t = self.pop()
        if t.typ == "num":
            left = ("num", t.val)
        elif t.typ == "str":
            left = ("str", t.val)
        elif t.val == "nil":
            left = ("nil",)
        elif t.val == "true":
            left = ("bool", True)
        elif t.val == "false":
            left = ("bool", False)
        elif t.val in {"not", "-", "#", "~"}:
            left = ("un", t.val, self.expr(7))
        elif t.val == "(":
            left = self.expr(); self.expect(")")
        elif t.val == "{":
            left = self.tablector()
        elif t.val == "function":
            left = self.funcbody()
        elif t.typ == "name" or t.val == "...":
            left = ("var", t.val)
        else:
            raise LuaError(f"syntax error near '{t.val}'")
        left = self.postfix(left)
        while True:
            op = self.peek().val
            prec = {"or": 1, "and": 2, "==": 3, "~=": 3, "<": 3, ">": 3, "<=": 3, ">=": 3,
                    "|": 4, "~": 5, "&": 6, "<<": 7, ">>": 7,
                    "..": 8, "+": 9, "-": 9, "*": 10, "/": 10, "//": 10, "%": 10, "^": 12}.get(op)
            if prec is None or prec < minp:
                break
            self.pop()
            right = self.expr(prec if op in {"^", ".."} else prec + 1)
            left = ("bin", op, left, right)
        return left

    def tablector(self):
        fields = []
        idx = 1
        while not self.accept("}"):
            if self.accept("["):
                key = self.expr(); self.expect("]"); self.expect("="); val = self.expr()
                fields.append((key, val))
            elif self.peek().typ == "name" and self.toks[self.i + 1].val == "=":
                key = ("str", self.pop().val); self.expect("="); val = self.expr()
                fields.append((key, val))
            else:
                fields.append((("num", idx), self.expr())); idx += 1
            self.accept(",") or self.accept(";")
        return ("table", fields)

    def variable(self):
        return self.postfix(("var", self.pop().val), calls=False)

    def prefix(self):
        if self.accept("("):
            e = self.expr(); self.expect(")")
        else:
            e = ("var", self.pop().val)
        return self.postfix(e)

    def postfix(self, e, calls=True):
        while True:
            if self.accept("."):
                e = ("index", e, ("str", self.pop().val))
            elif self.accept("["):
                k = self.expr(); self.expect("]")
                e = ("index", e, k)
            elif self.accept(":"):
                name = self.pop().val
                self.expect("(")
                closed = self.accept(")")
                args = [] if closed else self.exprlist()
                if not closed:
                    self.expect(")")
                e = ("callmethod", e, name, args)
            elif calls and self.accept("("):
                closed = self.accept(")")
                args = [] if closed else self.exprlist()
                if not closed:
                    self.expect(")")
                e = ("call", e, args)
            else:
                return e


class LuaFunction:
    def __init__(self, params, vararg, body, env, interp):
        self.params = params
        self.vararg = vararg
        self.body = body
        self.env = env
        self.interp = interp

    def __call__(self, *args):
        env = Env(self.env)
        for i, p in enumerate(self.params):
            env.set_local(p, args[i] if i < len(args) else None)
        if self.vararg:
            env.set_local("...", list(args[len(self.params):]))
        try:
            self.interp.exec_block(self.body, env)
        except ReturnSignal as r:
            return r.values[0] if len(r.values) == 1 else tuple(r.values)
        return None


class Interpreter:
    def __init__(self):
        self.global_env = Env()
        self.install_builtins()

    def install_builtins(self):
        g = self.global_env
        g.set_local("_VERSION", "Lua 5.5")
        g.set_local("print", lambda *a: print("\t".join(lua_str(x) for x in a)))
        g.set_local("type", lua_type)
        g.set_local("tostring", lua_str)
        g.set_local("tonumber", lambda x=None, base=None: self.tonumber(x, base))
        g.set_local("assert", self.lua_assert)
        g.set_local("error", lambda msg="", level=None: (_ for _ in ()).throw(LuaError(lua_str(msg))))
        g.set_local("pcall", self.lua_pcall)
        g.set_local("select", self.lua_select)
        g.set_local("rawget", lambda t, k: t.get(k) if isinstance(t, LuaTable) else None)
        g.set_local("rawset", self.lua_rawset)
        g.set_local("require", self.lua_require)
        g.set_local("dofile", self.lua_dofile)
        g.set_local("loadfile", lambda path: (lambda: self.lua_dofile(path)))
        g.set_local("ipairs", lambda t: LuaIterator("ipairs", t))
        g.set_local("pairs", lambda t: LuaIterator("pairs", t))
        g.set_local("next", self.lua_next)
        math_t = LuaTable({k: getattr(math, k) for k in dir(math) if not k.startswith("_")})
        math_t.set("max", lambda *a: max(a)); math_t.set("min", lambda *a: min(a))
        math_t.set("type", lambda x: "integer" if isinstance(x, int) and not isinstance(x, bool) else ("float" if isinstance(x, float) else None))
        g.set_local("math", math_t)
        g.set_local("string", LuaTable({"len": lambda s: len(str(s)), "sub": self.str_sub, "upper": lambda s: str(s).upper(),
                                        "lower": lambda s: str(s).lower(), "rep": lambda s, n: str(s) * int(n),
                                        "format": lambda fmt, *a: fmt % a}))
        g.set_local("table", LuaTable({"insert": self.tbl_insert, "remove": self.tbl_remove, "concat": self.tbl_concat}))
        g.set_local("os", LuaTable({"exit": lambda code=0: sys.exit(int(code or 0)), "getenv": lambda k: os.environ.get(k)}))
        g.set_local("io", LuaTable({"write": self.io_write, "read": self.io_read, "flush": lambda: sys.stdout.flush()}))
        g.set_local("package", LuaTable({"loaded": LuaTable()}))

    def tonumber(self, x=None, base=None):
        if x is None:
            return None
        try:
            if base:
                return int(str(x), int(base))
            return int(x) if re.fullmatch(r"[+-]?\d+", str(x)) else float(x)
        except Exception:
            return None

    def lua_assert(self, v, msg="assertion failed!"):
        if not lua_truth(v):
            raise LuaError(lua_str(msg))
        return v

    def lua_pcall(self, fn, *args):
        try:
            res = self.call(fn, list(args))
            return (True,) + res if isinstance(res, tuple) else (True, res)
        except Exception as e:
            return (False, str(e))

    def lua_select(self, what, *args):
        if what == "#":
            return len(args)
        return args[int(what) - 1] if 1 <= int(what) <= len(args) else None

    def lua_rawset(self, t, k, v):
        if isinstance(t, LuaTable):
            t.set(k, v)
        return t

    def lua_require(self, name):
        pkg = self.global_env.get("package")
        loaded = pkg.get("loaded") if isinstance(pkg, LuaTable) else None
        if isinstance(loaded, LuaTable) and loaded.get(name) is not None:
            return loaded.get(name)
        val = self.global_env.get(str(name))
        if val is None:
            raise LuaError(f"module '{name}' not found")
        if isinstance(loaded, LuaTable):
            loaded.set(name, val)
        return val

    def lua_dofile(self, path=None):
        data = sys.stdin.read() if path is None else open(str(path), encoding="utf-8").read()
        return self.run(data, str(path or "stdin"))

    def io_write(self, *args):
        sys.stdout.write("".join(lua_str(a) for a in args))
        return True

    def io_read(self, fmt="l"):
        if fmt in ("*a", "a"):
            return sys.stdin.read()
        line = sys.stdin.readline()
        if line == "":
            return None
        return line[:-1] if line.endswith("\n") else line

    def lua_next(self, t, key=None):
        if not isinstance(t, LuaTable):
            return None
        keys = list(t.data.keys())
        if key is None:
            return (keys[0], t.get(keys[0])) if keys else None
        try:
            i = keys.index(key) + 1
            return (keys[i], t.get(keys[i])) if i < len(keys) else None
        except ValueError:
            return None

    def str_sub(self, s, i, j=None):
        s = str(s); i = int(i); j = len(s) if j is None else int(j)
        if i < 0: i = len(s) + i + 1
        if j < 0: j = len(s) + j + 1
        return s[max(i - 1, 0):j]

    def tbl_insert(self, t, *args):
        if len(args) == 1:
            t.append(args[0])
        else:
            pos, val = int(args[0]), args[1]
            for i in range(t.length() + 1, pos, -1):
                t.set(i, t.get(i - 1))
            t.set(pos, val)

    def tbl_remove(self, t, pos=None):
        pos = t.length() if pos is None else int(pos)
        val = t.get(pos)
        for i in range(pos, t.length()):
            t.set(i, t.get(i + 1))
        t.set(t.length(), None)
        return val

    def tbl_concat(self, t, sep="", i=1, j=None):
        j = t.length() if j is None else int(j)
        return str(sep).join(lua_str(t.get(k)) for k in range(int(i), j + 1))

    def run(self, src, chunk="(command line)"):
        ast = Parser(src).parse()
        self.exec_block(ast, self.global_env)

    def exec_block(self, body, env):
        for st in body:
            self.exec_stmt(st, env)

    def exec_stmt(self, st, env):
        kind = st[0]
        if kind == "return":
            raise ReturnSignal(self.eval_exprs(st[1], env))
        if kind == "break":
            raise BreakSignal()
        if kind == "local":
            vals = self.eval_exprs(st[2], env)
            for i, n in enumerate(st[1]):
                env.set_local(n, vals[i] if i < len(vals) else None)
        elif kind == "assign":
            vals = self.eval_exprs(st[2], env)
            for i, target in enumerate(st[1]):
                self.assign(target, vals[i] if i < len(vals) else None, env)
        elif kind == "exprstmt":
            self.eval(st[1], env)
        elif kind == "if":
            for cond, body in st[1]:
                if lua_truth(self.eval(cond, env)):
                    self.exec_block(body, Env(env)); return
            if st[2] is not None:
                self.exec_block(st[2], Env(env))
        elif kind == "while":
            while lua_truth(self.eval(st[1], env)):
                try:
                    self.exec_block(st[2], Env(env))
                except BreakSignal:
                    break
        elif kind == "repeat":
            while True:
                try:
                    self.exec_block(st[1], Env(env))
                except BreakSignal:
                    break
                if lua_truth(self.eval(st[2], env)):
                    break
        elif kind == "do":
            self.exec_block(st[1], Env(env))
        elif kind == "fornum":
            name, a, b, step, body = st[1:]
            start, stop, inc = int(lua_num(self.eval(a, env))), int(lua_num(self.eval(b, env))), int(lua_num(self.eval(step, env)))
            i = start
            cmp = (lambda x: x <= stop) if inc >= 0 else (lambda x: x >= stop)
            while cmp(i):
                loop = Env(env); loop.set_local(name, i)
                try:
                    self.exec_block(body, loop)
                except BreakSignal:
                    break
                i += inc
        elif kind == "forin":
            vals = self.eval_exprs(st[2], env)
            iterator = vals[0] if vals else None
            seq = []
            if isinstance(iterator, LuaIterator) and iterator.kind == "ipairs":
                t = iterator.table
                seq = [(i, t.get(i)) for i in range(1, t.length() + 1)]
            elif isinstance(iterator, LuaIterator) and iterator.kind == "pairs":
                seq = iterator.table.items_for_pairs()
            for item in seq:
                loop = Env(env)
                vals2 = item if isinstance(item, tuple) else (item,)
                for i, n in enumerate(st[1]):
                    loop.set_local(n, vals2[i] if i < len(vals2) else None)
                try:
                    self.exec_block(st[3], loop)
                except BreakSignal:
                    break

    def assign(self, target, val, env):
        if target[0] == "var":
            env.set(target[1], val)
        elif target[0] == "index":
            tbl = self.eval(target[1], env); key = self.eval(target[2], env)
            if isinstance(tbl, LuaTable):
                tbl.set(key, val)
            else:
                raise LuaError("attempt to index a nil value")

    def eval_exprs(self, exprs, env):
        vals = []
        for idx, ex in enumerate(exprs):
            if idx == len(exprs) - 1 and ex[0] in {"call", "callmethod"}:
                res = self.eval_call_raw(ex, env)
                if isinstance(res, tuple):
                    vals.extend(res)
                else:
                    vals.append(res)
            else:
                vals.append(self.eval(ex, env))
        return vals

    def eval_call_raw(self, e, env):
        if e[0] == "call":
            fn = self.eval(e[1], env); args = self.eval_exprs(e[2], env)
            return self.call(fn, args)
        obj = self.eval(e[1], env); fn = None
        if isinstance(obj, LuaTable): fn = obj.get(e[2])
        elif isinstance(obj, str):
            st = env.get("string"); fn = st.get(e[2]) if isinstance(st, LuaTable) else None
        return self.call(fn, [obj] + self.eval_exprs(e[3], env))

    def eval(self, e, env):
        k = e[0]
        if k == "num": return e[1]
        if k == "str": return e[1]
        if k == "nil": return None
        if k == "bool": return e[1]
        if k == "var":
            if e[1] == "...":
                vals = env.get("...")
                return vals[0] if vals else None
            return env.get(e[1])
        if k == "table":
            t = LuaTable()
            for keye, vale in e[1]:
                t.set(self.eval(keye, env), self.eval(vale, env))
            return t
        if k == "function":
            return LuaFunction(e[1], e[2], e[3], env, self)
        if k == "index":
            obj = self.eval(e[1], env); key = self.eval(e[2], env)
            if isinstance(obj, LuaTable):
                return obj.get(key)
            if isinstance(obj, str) and isinstance(key, str):
                st = env.get("string")
                return st.get(key) if isinstance(st, LuaTable) else None
            return None
        if k == "un":
            op, v = e[1], self.eval(e[2], env)
            if op == "not": return not lua_truth(v)
            if op == "-": return -lua_num(v)
            if op == "~": return ~int(lua_num(v))
            if op == "#": return v.length() if isinstance(v, LuaTable) else len(str(v))
        if k == "bin":
            op = e[1]
            if op == "and":
                a = self.eval(e[2], env); return self.eval(e[3], env) if lua_truth(a) else a
            if op == "or":
                a = self.eval(e[2], env); return a if lua_truth(a) else self.eval(e[3], env)
            a = self.eval(e[2], env); b = self.eval(e[3], env)
            if op == "+": return lua_num(a) + lua_num(b)
            if op == "-": return lua_num(a) - lua_num(b)
            if op == "*": return lua_num(a) * lua_num(b)
            if op == "/": return lua_num(a) / lua_num(b)
            if op == "//": return math.floor(lua_num(a) / lua_num(b))
            if op == "%": return lua_num(a) % lua_num(b)
            if op == "^": return lua_num(a) ** lua_num(b)
            if op == "&": return int(lua_num(a)) & int(lua_num(b))
            if op == "|": return int(lua_num(a)) | int(lua_num(b))
            if op == "~": return int(lua_num(a)) ^ int(lua_num(b))
            if op == "<<": return int(lua_num(a)) << int(lua_num(b))
            if op == ">>": return int(lua_num(a)) >> int(lua_num(b))
            if op == "..": return lua_str(a) + lua_str(b)
            if op == "==": return a == b
            if op == "~=": return a != b
            if op == "<": return a < b
            if op == ">": return a > b
            if op == "<=": return a <= b
            if op == ">=": return a >= b
        if k == "call":
            res = self.eval_call_raw(e, env)
            return res[0] if isinstance(res, tuple) and res else (None if res == () else res)
        if k == "callmethod":
            res = self.eval_call_raw(e, env)
            return res[0] if isinstance(res, tuple) and res else (None if res == () else res)
        raise LuaError("internal error")

    def call(self, fn, args):
        if fn is None:
            raise LuaError("attempt to call a nil value")
        res = fn(*args)
        return res


USAGE = """usage: ./executable [options] [script [args]]
Available options are:
  -e stat   execute string 'stat'
  -i        enter interactive mode after executing 'script'
  -l mod    require library 'mod' into global 'mod'
  -l g=mod  require library 'mod' into global 'g'
  -v        show version information
  -E        ignore environment variables
  -W        turn warnings on
  --        stop handling options
  -         stop handling options and execute stdin"""


def main(argv):
    interp = Interpreter()
    chunks = []
    libs = []
    interactive = False
    script = None
    script_args = []
    i = 1
    while i < len(argv):
        a = argv[i]
        if a == "--":
            i += 1
            if i < len(argv):
                script = argv[i]; script_args = argv[i + 1:]
            break
        if a == "-":
            script = "-"; script_args = argv[i + 1:]; break
        if not a.startswith("-") or a == "":
            script = a; script_args = argv[i + 1:]; break
        if a == "-v":
            print(VERSION_LINE)
        elif a == "-i":
            interactive = True
        elif a == "-E" or a == "-W":
            pass
        elif a == "-e":
            i += 1
            if i >= len(argv):
                print("./executable: '-e' needs argument", file=sys.stderr); return 1
            chunks.append(argv[i])
        elif a.startswith("-e") and len(a) > 2:
            chunks.append(a[2:])
        elif a == "-l":
            i += 1
            if i >= len(argv):
                print("./executable: '-l' needs argument", file=sys.stderr); return 1
            libs.append(argv[i])
        elif a.startswith("-l"):
            libs.append(a[2:])
        else:
            print(f"./executable: unrecognized option '{a}'", file=sys.stderr)
            print(USAGE, file=sys.stderr)
            return 1
        i += 1
    argt = LuaTable()
    if script is not None:
        argt.set(0, script)
        for idx, val in enumerate(script_args, 1):
            argt.set(idx, val)
    interp.global_env.set_local("arg", argt)
    try:
        for spec in libs:
            if "=" in spec:
                name, mod = spec.split("=", 1)
            else:
                mod = spec
                name = mod.split(".")[-1]
            interp.global_env.set(name, interp.lua_require(mod))
        for c in chunks:
            interp.run(c)
        if script == "-":
            interp.run(sys.stdin.read(), "stdin")
        elif script is not None:
            try:
                with open(script, "r", encoding="utf-8") as f:
                    interp.run(f.read(), script)
            except FileNotFoundError:
                print(f"./executable: cannot open {script}: No such file or directory", file=sys.stderr)
                return 1
        elif not chunks or interactive:
            if sys.stdin.isatty() or interactive:
                print(VERSION_LINE)
            interp.run(sys.stdin.read(), "stdin")
    except SystemExit as e:
        return int(e.code or 0)
    except Exception as e:
        msg = str(e) or e.__class__.__name__
        print(f"./executable: {msg}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
