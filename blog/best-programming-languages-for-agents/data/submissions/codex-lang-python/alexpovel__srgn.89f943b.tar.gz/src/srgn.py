#!/usr/bin/env python3
import ast
import fnmatch
import glob as globmod
import io
import os
import re
import sys
import tokenize
import unicodedata

VERSION = "srgn 0.14.1"

HELP_SHORT = """A grep-like tool which understands source code syntax and allows for manipulation in
addition to search

Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]

Arguments:
  [SCOPE]  Scope to apply to, as a regular expression pattern. [default: .*]

Options:
      --completions <SHELL>  Print shell completions for the given shell. [possible values: bash, elvish, fish, powershell, zsh]
  -h, --help                 Print help (see more with '--help')
  -V, --version              Print version

Composable Actions:
  -u, --upper        Uppercase anything in scope. [env: UPPER=]
  -l, --lower        Lowercase anything in scope. [env: LOWER=]
  -t, --titlecase    Titlecase anything in scope. [env: TITLECASE=]
  -n, --normalize    Normalize (Normalization Form D) anything in scope, and throw away marks. [env: NORMALIZE=]
  -g, --german       Perform substitutions on German words, such as 'Abenteuergruesse' to 'Abenteuergrüße', for anything in scope.
  -S, --symbols      Perform substitutions on symbols, such as '!=' to '≠', '->' to '→', on anything in scope.
  [REPLACEMENT]  Replace anything in scope with this value. [env: REPLACE=]

Standalone Actions (only usable alone):
  -d, --delete   Delete anything in scope.
  -s, --squeeze  Squeeze consecutive occurrences of scope into one. [env: SQUEEZE=]

Options (global):
  -G, --glob <GLOB>          Glob of files to work on (instead of reading stdin).
      --dry-run              Do not destructively overwrite files, instead print rich diff only.
  -i, --invert               Undo the effects of passed actions, where applicable. [env: INVERT=]
  -L, --literal-string       Do not interpret the scope as a regex.
      --fail-any             If anything at all is found to be in scope, fail.
      --fail-none            If nothing is found to be in scope, fail.
      --line-numbers         Print line numbers in search output.
      --only-matching        Print only matching portions.
      --files                List files that would be processed.
      --sorted               Process files in lexicographically sorted order.

Language scopes:
      --python <PYTHON>      Scope Python code using a prepared query. [aliases: py]
      --rust <RUST>          Scope Rust code using a prepared query. [aliases: rs]
      --go <GO>              Scope Go code using a prepared query.
      --typescript <TS>      Scope TypeScript code using a prepared query. [aliases: ts]
      --c <C>                Scope C code using a prepared query.
      --csharp <CSHARP>      Scope C# code using a prepared query. [aliases: cs]
      --hcl <HCL>            Scope HCL code using a prepared query.
"""

SYMBOLS = [
    ("<--", "⟵"), ("-->", "⟶"), ("<->", "↔"), ("=>", "⇒"), ("->", "→"), ("<-", "←"),
    ("!=", "≠"), ("<=", "≤"), (">=", "≥"), ("===", "≡"), ("==", "="), ("::", "∷"),
]
INV_SYMBOLS = [(b, a) for a, b in SYMBOLS]

LANG_OPTS = {
    "--python": "python", "--py": "python", "--rust": "rust", "--rs": "rust",
    "--go": "go", "--typescript": "typescript", "--ts": "typescript",
    "--c": "c", "--csharp": "csharp", "--cs": "csharp", "--hcl": "hcl",
}


class Opt:
    def __init__(self):
        self.upper = bool(os.getenv("UPPER"))
        self.lower = bool(os.getenv("LOWER"))
        self.title = bool(os.getenv("TITLECASE"))
        self.normalize = bool(os.getenv("NORMALIZE"))
        self.german = False
        self.german_naive = bool(os.getenv("GERMAN_NAIVE"))
        self.symbols = False
        self.invert = bool(os.getenv("INVERT"))
        self.literal = bool(os.getenv("LITERAL_STRING"))
        self.delete = False
        self.squeeze = bool(os.getenv("SQUEEZE"))
        self.glob = None
        self.dry_run = False
        self.fail_no_files = False
        self.fail_any = False
        self.fail_none = False
        self.files = False
        self.sorted = False
        self.only_matching = False
        self.line_numbers = False
        self.join_lang = False
        self.lang = []
        self.scope = os.getenv("SCOPE", ".*")
        self.replacement = os.getenv("REPLACE")


def parse(argv):
    opt = Opt()
    positional = []
    i = 0
    after = False
    while i < len(argv):
        a = argv[i]
        if after:
            positional.append(a); i += 1; continue
        if a == "--":
            after = True; i += 1; continue
        if a in ("-h", "--help"):
            print(HELP_SHORT); raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION); raise SystemExit(0)
        if a == "--completions":
            shell = argv[i+1] if i+1 < len(argv) else ""
            print(f"# {shell} completions are not available in this reimplementation")
            raise SystemExit(0)
        if a in ("-u", "--upper"): opt.upper = True
        elif a in ("-l", "--lower"): opt.lower = True
        elif a in ("-t", "--titlecase"): opt.title = True
        elif a in ("-n", "--normalize"): opt.normalize = True
        elif a in ("-g", "--german"): opt.german = True
        elif a == "--german-naive": opt.german = True; opt.german_naive = True
        elif a == "--german-prefer-original": pass
        elif a in ("-S", "--symbols"): opt.symbols = True
        elif a in ("-i", "--invert"): opt.invert = True
        elif a in ("-L", "--literal-string"): opt.literal = True
        elif a in ("-d", "--delete"): opt.delete = True
        elif a in ("-s", "--squeeze", "--squeeze-repeats"): opt.squeeze = True
        elif a in ("-G", "--glob"):
            i += 1
            if i >= len(argv): die("error: a value is required for '--glob <GLOB>' but none was supplied")
            opt.glob = argv[i]
        elif a == "--dry-run": opt.dry_run = True
        elif a == "--fail-no-files": opt.fail_no_files = True
        elif a == "--fail-any": opt.fail_any = True
        elif a == "--fail-none": opt.fail_none = True
        elif a == "--files": opt.files = True
        elif a == "--sorted": opt.sorted = True
        elif a == "--only-matching": opt.only_matching = True
        elif a == "--line-numbers": opt.line_numbers = True
        elif a == "-j" or a == "--join-language-scopes": opt.join_lang = True
        elif a in ("-H", "--hidden", "--gitignored"): pass
        elif a in ("--stdin-detection", "--stdout-detection", "--threads"):
            i += 1
        elif a.startswith("-v"): pass
        elif a in LANG_OPTS:
            i += 1
            if i >= len(argv): die(f"error: a value is required for '{a}'")
            opt.lang.append((LANG_OPTS[a], argv[i]))
        elif any(a.startswith(x + "-query") for x in LANG_OPTS):
            i += 1
        elif a.startswith("-") and len(a) > 2 and not a.startswith("--"):
            for ch in a[1:]:
                if ch == "u": opt.upper = True
                elif ch == "l": opt.lower = True
                elif ch == "t": opt.title = True
                elif ch == "n": opt.normalize = True
                elif ch == "g": opt.german = True
                elif ch == "S": opt.symbols = True
                elif ch == "i": opt.invert = True
                elif ch == "L": opt.literal = True
                elif ch == "d": opt.delete = True
                elif ch == "s": opt.squeeze = True
                else: positional.append(a); break
        elif a.startswith("-"):
            positional.append(a)
        else:
            positional.append(a)
        i += 1
    if positional:
        opt.scope = positional[0]
    if len(positional) > 1:
        opt.replacement = positional[1]
    return opt


def die(msg, code=2):
    print(msg, file=sys.stderr)
    raise SystemExit(code)


def line_offsets(s):
    offs, pos = [], 0
    for line in s.splitlines(True):
        offs.append(pos); pos += len(line)
    if not offs:
        offs = [0]
    return offs


def pos_from_linecol(offs, line, col):
    if line <= 0: return col
    return offs[min(line-1, len(offs)-1)] + col


def node_range(node, offs, text):
    if not hasattr(node, "lineno") or not hasattr(node, "end_lineno"):
        return None
    start = pos_from_linecol(offs, node.lineno, node.col_offset)
    end = pos_from_linecol(offs, node.end_lineno, node.end_col_offset)
    while end < len(text) and text[end:end+1] == "\n":
        end += 1
        break
    return (start, end)


def py_ranges(text, kind):
    offs = line_offsets(text); ranges = []
    try:
        tree = ast.parse(text)
    except SyntaxError:
        tree = None
    if kind in ("comments", "strings", "doc-strings"):
        try:
            toks = tokenize.generate_tokens(io.StringIO(text).readline)
            for tok in toks:
                if kind == "comments" and tok.type == tokenize.COMMENT:
                    ranges.append((pos_from_linecol(offs,*tok.start), pos_from_linecol(offs,*tok.end)))
                elif kind in ("strings", "doc-strings") and tok.type == tokenize.STRING:
                    s = pos_from_linecol(offs,*tok.start); e = pos_from_linecol(offs,*tok.end)
                    ranges.append(trim_string_span(text, s, e))
        except tokenize.TokenError:
            pass
    if tree:
        for node in ast.walk(tree):
            if kind == "class" and isinstance(node, ast.ClassDef):
                r = node_range(node, offs, text); ranges.append(r) if r else None
            elif kind in ("def", "methods", "class-methods", "static-methods") and isinstance(node, ast.FunctionDef):
                r = node_range(node, offs, text); ranges.append(r) if r else None
            elif kind == "async-def" and isinstance(node, ast.AsyncFunctionDef):
                r = node_range(node, offs, text); ranges.append(r) if r else None
            elif kind == "function-names" and isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                line_start = offs[node.lineno-1]
                idx = text.find(node.name, line_start, line_start + 300)
                if idx >= 0: ranges.append((idx, idx+len(node.name)))
            elif kind == "function-calls" and isinstance(node, ast.Call):
                r = node_range(node.func, offs, text); ranges.append(r) if r else None
            elif kind == "imports" and isinstance(node, (ast.Import, ast.ImportFrom)):
                line_start = offs[node.lineno-1]
                line_end = text.find("\n", line_start)
                if line_end < 0: line_end = len(text)
                if isinstance(node, ast.Import):
                    cursor = line_start
                    for alias in node.names:
                        idx = text.find(alias.name, cursor, line_end)
                        if idx >= 0:
                            ranges.append((idx, idx + len(alias.name)))
                            cursor = idx + len(alias.name)
                elif node.module:
                    idx = text.find(node.module, line_start, line_end)
                    if idx >= 0: ranges.append((idx, idx + len(node.module)))
            elif kind == "globals" and isinstance(node, (ast.Assign, ast.AnnAssign)) and getattr(node, "col_offset", 1) == 0:
                r = node_range(node, offs, text); ranges.append(r) if r else None
            elif kind in ("variable-identifiers", "identifiers") and isinstance(node, ast.Name):
                r = node_range(node, offs, text); ranges.append(r) if r else None
            elif kind == "types" and isinstance(node, (ast.arg, ast.AnnAssign)):
                ann = getattr(node, "annotation", None)
                r = node_range(ann, offs, text) if ann else None
                ranges.append(r) if r else None
            elif kind in ("with", "try", "lambda") and node.__class__.__name__.lower().startswith(kind.replace("-", "")):
                r = node_range(node, offs, text); ranges.append(r) if r else None
    return clean_ranges(ranges)


def brace_end(text, start):
    level = 0; seen = False; i = start
    while i < len(text):
        if text[i] == "{": level += 1; seen = True
        elif text[i] == "}":
            level -= 1
            if seen and level <= 0:
                return i + 1
        elif seen is False and text[i] == ";":
            return i + 1
        i += 1
    nl = text.find("\n", start)
    return len(text) if nl < 0 else nl


def trim_string_span(text, s, e):
    q = s
    while q < e and text[q] not in "\"'`":
        q += 1
    if q >= e:
        return (s, e)
    quote = text[q]
    if text.startswith(quote * 3, q) and e - q >= 6:
        return (q + 3, e - 3)
    return (q + 1, e - 1 if e > q else e)


def regex_lang_ranges(text, lang, kind):
    ranges = []
    def add_lines(pattern, flags=re.M):
        for m in re.finditer(pattern, text, flags):
            s = m.start()
            e = brace_end(text, s) if "{" in m.group(0) or kind in ("class","struct","enum","interface","trait","impl","function","fn","def","method","resource","variable","data","module","provider","output","terraform","locals") else (text.find("\n", s) if text.find("\n", s) >= 0 else len(text))
            ranges.append((s, e))
    if kind.split("~",1)[0] in ("comments", "doc-comments"):
        for pat in [r"//[^\n]*", r"/\*.*?\*/", r"#[^\n]*"]:
            for m in re.finditer(pat, text, re.S): ranges.append(m.span())
    elif kind in ("strings", "struct-tags"):
        for pat in [r'"(?:\\.|[^"\\])*"', r"'(?:\\.|[^'\\])*'", r'`[^`]*`']:
            for m in re.finditer(pat, text, re.S): ranges.append(trim_string_span(text, *m.span()))
    elif kind in ("imports", "includes", "uses", "usings"):
        add_lines(r"^\s*(?:use|import|from|#include|using)\b[^\n;]*(?:;)?")
    elif kind.startswith(("struct", "pub-struct", "priv-struct")):
        add_lines(r"^\s*(?:pub(?:\([^)]*\))?\s+)?struct\s+\w+[^{;\n]*(?:\{|;)?")
    elif kind.startswith(("enum", "pub-enum", "priv-enum")):
        add_lines(r"^\s*(?:pub(?:\([^)]*\))?\s+)?enum\s+\w+[^{;\n]*(?:\{|;)?")
    elif kind in ("fn","function","func","method","free-func","init-func","pub-fn","priv-fn","const-fn","async-fn","unsafe-fn","extern-fn","test-fn","function-def","function-decl"):
        if lang == "go":
            add_lines(r"^\s*func\b[^{\n]*(?:\{)?")
        elif lang == "typescript":
            add_lines(r"^\s*(?:export\s+)?(?:async\s+)?function\b[^{\n]*(?:\{)?|^\s*\w+\s*\([^)]*\)\s*\{")
        else:
            add_lines(r"^\s*(?:pub(?:\([^)]*\))?\s+)?(?:const\s+|async\s+|unsafe\s+|extern\s+)*fn\s+\w+[^{;\n]*(?:\{|;)?")
    elif kind in ("class", "interface", "trait", "impl", "mod", "namespace", "type-def", "type-alias", "union"):
        kw = {"type-def": r"(?:type|struct|enum|union)", "type-alias": "type"}.get(kind, kind)
        add_lines(r"^\s*(?:export\s+|pub\s+)?"+kw+r"\b[^{;\n]*(?:\{|;)?")
    elif kind in ("identifier","identifiers","type-identifier"):
        for m in re.finditer(r"\b[A-Za-z_][A-Za-z0-9_]*\b", text): ranges.append(m.span())
    elif kind in ("attribute",):
        for m in re.finditer(r"#\[[^\]]+\]|\[[A-Za-z_][^\]]*\]", text): ranges.append(m.span())
    elif kind in ("unsafe",):
        for m in re.finditer(r"\bunsafe\b", text): ranges.append(m.span())
    else:
        add_lines(r"^\s*"+re.escape(kind.split("~",1)[0]).replace("\\-", r"[-_\s]*")+r"\b[^\n]*(?:\{)?")
    if "~" in kind:
        base, pat = kind.split("~", 1)
        ranges = [r for r in ranges if re.search(pat, text[r[0]:r[1]])]
    return clean_ranges(ranges)


def lang_ranges(text, lang_specs):
    if not lang_specs:
        return [(0, len(text))]
    result = None
    for lang, kind in lang_specs:
        r = py_ranges(text, kind) if lang == "python" else regex_lang_ranges(text, lang, kind)
        if result is None:
            result = r
        else:
            result = intersect_ranges(result, r)
    return result or []


def clean_ranges(ranges):
    ranges = sorted([r for r in ranges if r and r[0] <= r[1]])
    out = []
    for s, e in ranges:
        if out and s <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], e))
        else:
            out.append((s, e))
    return out


def intersect_ranges(a, b):
    out = []
    for s1, e1 in a:
        for s2, e2 in b:
            s, e = max(s1, s2), min(e1, e2)
            if s <= e: out.append((s, e))
    return clean_ranges(out)


def compile_scope(opt):
    pat = re.escape(opt.scope) if opt.literal else opt.scope
    try:
        return re.compile(pat, re.S | re.M)
    except re.error as e:
        die(f"Error: regex parse error: {e}", 1)


def scoped_matches(text, opt):
    rx = compile_scope(opt)
    allowed = lang_ranges(text, opt.lang)
    matches = []
    for s, e in allowed:
        for m in rx.finditer(text, s, e):
            ms, me = m.span()
            if ms == me and opt.scope == ".*":
                continue
            if ms >= s and me <= e:
                matches.append(m)
    return matches


def dollar_repl(repl, m):
    def sub(mm):
        key = mm.group(1) or mm.group(2)
        try:
            return m.group(key) or ""
        except (IndexError, KeyError):
            return ""
    return re.sub(r"\$(?:\{([^}]+)\}|([A-Za-z_][A-Za-z0-9_]*|\d+))", sub, repl)


def germanize(s, naive=False):
    def word(w):
        orig = w.group(0)
        x = orig
        if naive:
            reps = [("AE","Ä"),("OE","Ö"),("UE","Ü"),("SS","ẞ"),("Ae","Ä"),("Oe","Ö"),("Ue","Ü"),("ae","ä"),("oe","ö"),("ue","ü"),("ss","ß")]
        else:
            reps = [("GRUESSE","GRÜẞE"),("BRUECKEN","BRÜCKEN"),("Gruesse","Grüße"),("gruesse","grüße"),("Bruecken","Brücken"),("bruecken","brücken"),
                    ("UE","Ü"),("AE","Ä"),
                    ("ue","ü"),("ae","ä"),("Schoen","Schön"),("schoen","schön"),("ss","ß")]
        for a,b in reps:
            x = x.replace(a,b)
        x = x.replace("Köff", "Koeff").replace("köff", "koeff")
        return x
    return re.sub(r"[A-Za-zÄÖÜäöüß]+", word, s)


def symbolize(s, invert=False):
    pairs = INV_SYMBOLS if invert else SYMBOLS
    # Longest textual keys first avoids partial replacements.
    for a, b in sorted(pairs, key=lambda p: len(p[0]), reverse=True):
        s = s.replace(a, b)
    return s


def apply_actions_piece(piece, opt, match=None):
    if opt.replacement is not None:
        piece = dollar_repl(opt.replacement, match) if match else opt.replacement
    if opt.upper: piece = piece.upper()
    if opt.lower: piece = piece.lower()
    if opt.title: piece = piece.title()
    if opt.normalize:
        piece = "".join(c for c in unicodedata.normalize("NFD", piece) if unicodedata.category(c) != "Mn")
    if opt.german: piece = germanize(piece, opt.german_naive)
    if opt.symbols: piece = symbolize(piece, opt.invert)
    return piece


def transform(text, opt):
    matches = scoped_matches(text, opt)
    if opt.fail_any and matches:
        print("Error: Error applying: Some input was in scope", file=sys.stderr)
    if opt.fail_none and not matches:
        print("Error: Error applying: No input was in scope", file=sys.stderr)
    if opt.squeeze:
        if opt.literal and len(opt.scope) == 1:
            return re.sub(re.escape(opt.scope) + r"+", opt.scope, text), matches
        if (not opt.literal) and len(opt.scope) == 1 and opt.scope not in ".^$*+?{}[]\\|()":
            ch = opt.scope
            return re.sub(re.escape(ch) + r"+", ch, text), matches
        rx = compile_scope(opt)
        return rx.sub(lambda m: m.group(0), text), matches
    if opt.delete:
        repl = ""
    elif any([opt.upper,opt.lower,opt.title,opt.normalize,opt.german,opt.symbols,opt.replacement is not None]):
        repl = None
    else:
        print("[2026-05-28T00:00:00Z ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.", file=sys.stderr)
        return text, matches
    out, last = [], 0
    for m in matches:
        s, e = m.span()
        out.append(text[last:s])
        if opt.delete:
            out.append("")
        else:
            out.append(apply_actions_piece(text[s:e], opt, m))
        last = e
    out.append(text[last:])
    return "".join(out), matches


def line_col(text, pos):
    line = text.count("\n", 0, pos) + 1
    start = text.rfind("\n", 0, pos) + 1
    return line, pos - start


def search_output(text, opt, name="(stdin)"):
    matches = scoped_matches(text, opt)
    if not opt.lang and not opt.only_matching and not opt.line_numbers:
        print("[2026-05-28T00:00:00Z ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.", file=sys.stderr)
        return text
    by_line = {}
    lines = text.splitlines(True)
    starts = line_offsets(text)
    for m in matches:
        s, e = m.span()
        l1, c1 = line_col(text, s); l2, c2 = line_col(text, max(s, e-1))
        for ln in range(l1, l2+1):
            ls = starts[ln-1]
            le = ls + len(lines[ln-1].rstrip("\n")) if ln-1 < len(lines) else len(text)
            by_line.setdefault(ln, []).append((max(s, ls)-ls, min(e, le)-ls))
    out = []
    if opt.line_numbers and not opt.lang:
        iterable = range(1, len(lines)+1)
    else:
        iterable = sorted(by_line)
    for ln in iterable:
        line = lines[ln-1].rstrip("\n") if ln-1 < len(lines) else ""
        spans = by_line.get(ln, [])
        spanstr = ";".join(f"{a}-{b}" for a,b in spans)
        if opt.only_matching and not opt.line_numbers and not opt.lang:
            out.append(f"{name}:{spanstr}:{line}")
        else:
            out.append(f"{name}:{ln}:{spanstr}:{line}")
    return "\n".join(out) + ("\n" if out else "")


def process_text(text, opt, name="(stdin)"):
    has_action = any([opt.upper,opt.lower,opt.title,opt.normalize,opt.german,opt.symbols,opt.replacement is not None,opt.delete,opt.squeeze])
    if has_action:
        return transform(text, opt)[0]
    return search_output(text, opt, name)


def files_for(opt):
    if opt.glob:
        files = [p for p in globmod.glob(opt.glob, recursive=True) if os.path.isfile(p)]
    else:
        exts = {".py",".rs",".go",".ts",".tsx",".c",".h",".cs",".tf",".hcl"}
        files = []
        for root, dirs, names in os.walk("."):
            dirs[:] = [d for d in dirs if d != ".git" and not d.startswith(".")]
            for n in names:
                if os.path.splitext(n)[1] in exts:
                    files.append(os.path.join(root,n).lstrip("./"))
    if opt.sorted:
        files.sort()
    return files


def main(argv):
    opt = parse(argv)
    if opt.files:
        for f in files_for(opt): print(f)
        return 0
    if opt.glob is not None:
        files = files_for(opt)
        if opt.fail_no_files and not files:
            print("Error: no files found", file=sys.stderr); return 1
        for f in files:
            with open(f, "r", encoding="utf-8", errors="surrogateescape") as fh: data = fh.read()
            new = process_text(data, opt, f)
            has_action = any([opt.upper,opt.lower,opt.title,opt.normalize,opt.german,opt.symbols,opt.replacement is not None,opt.delete,opt.squeeze])
            if has_action:
                if new != data:
                    print(f)
                    if opt.dry_run:
                        sys.stdout.write(new)
                    else:
                        with open(f, "w", encoding="utf-8", errors="surrogateescape") as fh: fh.write(new)
            else:
                sys.stdout.write(new)
        return 0
    data = sys.stdin.read()
    sys.stdout.write(process_text(data, opt))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
