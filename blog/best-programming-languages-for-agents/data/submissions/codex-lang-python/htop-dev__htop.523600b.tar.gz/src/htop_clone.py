#!/usr/bin/env python3
import os
import pwd
import shutil
import signal
import sys
import time
from dataclasses import dataclass, field


VERSION = "htop 3.5.0-dev-878e0ce"

HELP = """htop 3.5.0-dev-878e0ce
(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.
Released under the GNU GPLv2+.

-C --no-color                   Use a monochrome color scheme
-d --delay=DELAY                Set the delay between updates, in tenths of seconds
-F --filter=FILTER              Show only the commands matching the given filter
   --no-function-bar             Hide the function bar
-h --help                       Print this help screen
-H --highlight-changes[=DELAY]  Highlight new and old processes
-M --no-mouse                   Disable the mouse
   --no-meters                  Hide meters
-n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates
-p --pid=PID[,PID,PID...]       Show only the given PIDs
   --readonly                   Disable all system and process changing features
-s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)
-t --tree                       Show the tree view (can be combined with -s)
-u --user[=USERNAME]            Show only processes for a given user (or $USER)
-U --no-unicode                 Do not use unicode but plain ASCII
-V --version                    Print version info

Press F1 inside htop for online help.
See 'man htop' for more information.
"""

SORT_COLUMNS = [
    ("PID", "Process/thread ID"),
    ("Command", "Command line (insert as last column only)"),
    ("STATE", "Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)"),
    ("PPID", "Parent process ID"),
    ("PGRP", "Process group ID"),
    ("SESSION", "Process's session ID"),
    ("TTY", "Controlling terminal"),
    ("TPGID", "Process ID of the fg process group of the controlling terminal"),
    ("MINFLT", "Number of minor faults which have not required loading a memory page from disk"),
    ("CMINFLT", "Children processes' minor faults"),
    ("MAJFLT", "Number of major faults which have required loading a memory page from disk"),
    ("CMAJFLT", "Children processes' major faults"),
    ("UTIME", "User CPU time - time the process spent executing in user mode"),
    ("STIME", "System CPU time - time the kernel spent running system calls for this process"),
    ("CUTIME", "Children processes' user CPU time"),
    ("CSTIME", "Children processes' system CPU time"),
    ("PRIORITY", "Kernel's internal priority for the process"),
    ("NICE", "Nice value (the higher the value, the more it lets other processes take priority)"),
    ("STARTTIME", "Time the process was started"),
    ("PROCESSOR", "Id of the CPU the process last executed on"),
    ("M_VIRT", "Total program size in virtual memory"),
    ("M_RESIDENT", "Resident set size, size of the text and data sections, plus stack usage"),
    ("M_SHARE", "Size of the process's shared pages"),
    ("M_TRS", "Size of the .text segment of the process (CODE)"),
    ("M_DRS", "Size of the .data segment plus stack usage of the process (DATA)"),
    ("M_LRS", "The library size of the process (calculated from memory maps)"),
    ("ST_UID", "User ID of the process owner"),
    ("PERCENT_CPU", "Percentage of the CPU time the process used in the last sampling"),
    ("PERCENT_MEM", "Percentage of the memory the process is using, based on resident memory size"),
    ("USER", "Username of the process owner (or user ID if name cannot be determined)"),
    ("TIME", "Total time the process has spent in user and system time"),
    ("NLWP", "Number of threads in the process"),
    ("TGID", "Thread group ID (i.e. process ID)"),
    ("PERCENT_NORM_CPU", "Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)"),
    ("ELAPSED", "Time since the process was started"),
    ("SCHEDULERPOLICY", "Current scheduling policy of the process"),
    ("RCHAR", "Number of bytes the process has read"),
    ("WCHAR", "Number of bytes the process has written"),
    ("SYSCR", "Number of read(2) syscalls for the process"),
    ("SYSCW", "Number of write(2) syscalls for the process"),
    ("RBYTES", "Bytes of read(2) I/O for the process"),
    ("WBYTES", "Bytes of write(2) I/O for the process"),
    ("CNCLWB", "Bytes of cancelled write(2) I/O"),
    ("IO_READ_RATE", "The I/O rate of read(2) in bytes per second for the process"),
    ("IO_WRITE_RATE", "The I/O rate of write(2) in bytes per second for the process"),
    ("IO_RATE", "Total I/O rate in bytes per second"),
    ("CGROUP", "Which cgroup the process is in"),
    ("OOM", "OOM (Out-of-Memory) killer score"),
    ("IO_PRIORITY", "I/O priority"),
    ("M_PSS", "proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it"),
    ("M_SWAP", "Size of the process's swapped pages"),
    ("M_PSSWP", 'shows proportional swap share of this mapping, unlike "Swap", this does not take into account swapped out page of underlying shmem objects'),
    ("CTXT", "Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)"),
    ("SECATTR", "Security attribute of the process (e.g. SELinux or AppArmor)"),
    ("COMM", "comm string of the process from /proc/[pid]/comm"),
    ("EXE", "Basename of exe of the process from /proc/[pid]/exe"),
    ("CWD", "The current working directory of the process"),
    ("AUTOGROUP_ID", "The autogroup identifier of the process"),
    ("AUTOGROUP_NICE", "Nice value (the higher the value, the more other processes take priority) associated with the process autogroup"),
    ("CCGROUP", "Which cgroup the process is in (condensed to essentials)"),
    ("CONTAINER", "Name of the container the process is in (guessed by heuristics)"),
    ("M_PRIV", "The private memory size of the process - resident set size minus shared memory"),
    ("GPU_TIME", "Total GPU time"),
    ("GPU_PERCENT", "Percentage of the GPU time the process used in the last sampling"),
    ("ISCONTAINER", "Whether the process is running inside a child container"),
]

VALID_SORTS = {name.upper() for name, _ in SORT_COLUMNS}
VALID_SORTS.add("COMMAND")


@dataclass
class Options:
    delay: int = 15
    max_iterations: int | None = None
    pids: set[int] | None = None
    user: str | None = None
    uid: int | None = None
    filter_terms: list[str] = field(default_factory=list)
    sort_key: str = "PERCENT_CPU"
    tree: bool = False
    monochrome: bool = False
    no_meters: bool = False
    no_function_bar: bool = False
    readonly: bool = False
    no_unicode: bool = False


def eprint(msg: str) -> None:
    print(msg, file=sys.stderr)


def usage_error(msg: str) -> int:
    eprint(f"{sys.argv[0]}: {msg}")
    return 1


def need_arg(args: list[str], i: int, opt: str) -> tuple[str | None, int | None]:
    if i + 1 >= len(args):
        if opt.startswith("--"):
            eprint(f"{sys.argv[0]}: option '{opt}' requires an argument")
        else:
            eprint(f"{sys.argv[0]}: option requires an argument -- '{opt[1:]}'")
        return None, None
    return args[i + 1], i + 1


def resolve_user(value: str | None) -> tuple[str, int] | None:
    if value in (None, ""):
        value = os.environ.get("USER") or str(os.getuid())
    if value.isdigit():
        try:
            entry = pwd.getpwuid(int(value))
            return entry.pw_name, entry.pw_uid
        except KeyError:
            return value, int(value)
    try:
        entry = pwd.getpwnam(value)
        return entry.pw_name, entry.pw_uid
    except KeyError:
        return None


def parse_int(value: str, what: str) -> int | None:
    try:
        return int(value, 10)
    except ValueError:
        eprint(f'Error: invalid {what} "{value}".')
        return None


def parse_args(args: list[str]) -> tuple[Options | None, int | None]:
    opts = Options()
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--":
            i += 1
            break
        if arg in ("--help",):
            print(HELP, end="")
            return None, 0
        if arg in ("--version",):
            print(VERSION)
            return None, 0
        if arg == "--sort-key=help" or arg == "--sort-key" and i + 1 < len(args) and args[i + 1] == "help":
            print_sort_columns()
            return None, 0
        if arg.startswith("--"):
            name, eq, val = arg.partition("=")
            if name in ("--no-color", "--no-colour"):
                opts.monochrome = True
            elif name == "--no-function-bar":
                opts.no_function_bar = True
            elif name == "--no-meters":
                opts.no_meters = True
            elif name == "--readonly":
                opts.readonly = True
            elif name == "--no-mouse":
                pass
            elif name == "--no-unicode":
                opts.no_unicode = True
            elif name == "--tree":
                opts.tree = True
            elif name == "--delay":
                if not eq:
                    val, ni = need_arg(args, i, name)
                    if ni is None:
                        return None, 1
                    i = ni
                parsed = parse_int(val, "delay value")
                if parsed is None:
                    return None, 1
                opts.delay = max(1, min(100, parsed))
            elif name == "--filter":
                if not eq:
                    val, ni = need_arg(args, i, name)
                    if ni is None:
                        return None, 1
                    i = ni
                opts.filter_terms = [x.lower() for x in val.split("|") if x]
            elif name == "--pid":
                if not eq:
                    val, ni = need_arg(args, i, name)
                    if ni is None:
                        return None, 1
                    i = ni
                opts.pids = parse_pid_list(val)
            elif name == "--sort-key":
                if not eq:
                    val, ni = need_arg(args, i, name)
                    if ni is None:
                        return None, 1
                    i = ni
                if val.lower() == "help":
                    print_sort_columns()
                    return None, 0
                if val.upper() not in VALID_SORTS:
                    eprint(f'Error: invalid column "{val}".')
                    return None, 1
                opts.sort_key = val.upper()
            elif name == "--user":
                if not eq:
                    if i + 1 < len(args) and not args[i + 1].startswith("-"):
                        val = args[i + 1]
                        i += 1
                    else:
                        val = None
                resolved = resolve_user(val)
                if resolved is None:
                    eprint(f'Error: invalid user "{val}".')
                    return None, 1
                opts.user, opts.uid = resolved
            elif name == "--max-iterations":
                if not eq:
                    val, ni = need_arg(args, i, name)
                    if ni is None:
                        return None, 1
                    i = ni
                parsed = parse_int(val, "maximum iteration count")
                if parsed is None:
                    return None, 1
                if parsed <= 0:
                    eprint("Error: maximum iteration count must be positive.")
                    return None, 1
                opts.max_iterations = parsed
            elif name == "--highlight-changes":
                pass
            else:
                return None, usage_error(f"unrecognized option '{arg}'")
        elif arg.startswith("-") and arg != "-":
            j = 1
            while j < len(arg):
                ch = arg[j]
                opt = "-" + ch
                if ch == "h":
                    print(HELP, end="")
                    return None, 0
                if ch == "V":
                    print(VERSION)
                    return None, 0
                if ch == "C":
                    opts.monochrome = True
                elif ch == "U":
                    opts.no_unicode = True
                elif ch == "M":
                    pass
                elif ch == "t":
                    opts.tree = True
                elif ch == "H":
                    if j + 1 < len(arg):
                        j = len(arg)
                    pass
                elif ch in ("d", "F", "p", "s", "u", "n"):
                    if j + 1 < len(arg):
                        val = arg[j + 1 :]
                        j = len(arg)
                    elif ch == "u" and (i + 1 >= len(args) or args[i + 1].startswith("-")):
                        val = None
                        j = len(arg)
                    else:
                        val, ni = need_arg(args, i, opt)
                        if ni is None:
                            return None, 1
                        i = ni
                        j = len(arg)
                    if ch == "d":
                        parsed = parse_int(val, "delay value")
                        if parsed is None:
                            return None, 1
                        opts.delay = max(1, min(100, parsed))
                    elif ch == "F":
                        opts.filter_terms = [x.lower() for x in val.split("|") if x]
                    elif ch == "p":
                        opts.pids = parse_pid_list(val)
                    elif ch == "s":
                        if val.lower() == "help":
                            print_sort_columns()
                            return None, 0
                        if val.upper() not in VALID_SORTS:
                            eprint(f'Error: invalid column "{val}".')
                            return None, 1
                        opts.sort_key = val.upper()
                    elif ch == "u":
                        resolved = resolve_user(val)
                        if resolved is None:
                            eprint(f'Error: invalid user "{val}".')
                            return None, 1
                        opts.user, opts.uid = resolved
                    elif ch == "n":
                        parsed = parse_int(val, "maximum iteration count")
                        if parsed is None:
                            return None, 1
                        if parsed <= 0:
                            eprint("Error: maximum iteration count must be positive.")
                            return None, 1
                        opts.max_iterations = parsed
                    continue
                else:
                    return None, usage_error(f"invalid option -- '{ch}'")
                j += 1
        else:
            return None, usage_error(f"invalid option -- '{arg}'")
        i += 1
    if i < len(args):
        return None, usage_error(f"invalid option -- '{args[i]}'")
    return opts, None


def parse_pid_list(value: str) -> set[int]:
    pids: set[int] = set()
    for part in value.split(","):
        try:
            pids.add(int(part))
        except ValueError:
            pass
    return pids


def print_sort_columns() -> None:
    for name, desc in SORT_COLUMNS:
        print(f"{name:>19} {desc}")


def read_meminfo() -> tuple[int, int, int, int]:
    vals: dict[str, int] = {}
    try:
        with open("/proc/meminfo", "r", encoding="ascii") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    vals[parts[0].rstrip(":")] = int(parts[1])
    except OSError:
        return 0, 0, 0, 0
    total = vals.get("MemTotal", 0)
    avail = vals.get("MemAvailable", vals.get("MemFree", 0))
    swap_total = vals.get("SwapTotal", 0)
    swap_free = vals.get("SwapFree", 0)
    return total, max(0, total - avail), swap_total, max(0, swap_total - swap_free)


def human_kb(kb: int) -> str:
    if kb >= 1024 * 1024:
        return f"{kb / (1024 * 1024):.2f}G"
    if kb >= 1024:
        return f"{kb / 1024:.0f}M"
    return f"{kb}K"


def username(uid: int) -> str:
    try:
        return pwd.getpwuid(uid).pw_name[:8]
    except KeyError:
        return str(uid)


def parse_proc(pid: int) -> dict | None:
    base = f"/proc/{pid}"
    try:
        with open(f"{base}/stat", "r", encoding="ascii", errors="replace") as f:
            stat = f.read()
        l = stat.rfind(")")
        r = stat.find("(")
        comm = stat[r + 1 : l]
        fields = stat[l + 2 :].split()
        state = fields[0]
        ppid = int(fields[1])
        utime = int(fields[11])
        stime = int(fields[12])
        priority = int(fields[15])
        nice = int(fields[16])
        threads = int(fields[17])
        vsize = int(fields[20]) // 1024
        rss_pages = int(fields[21])
        page = os.sysconf("SC_PAGE_SIZE") // 1024
        rss = max(0, rss_pages * page)
        uid = os.stat(base).st_uid
        try:
            with open(f"{base}/cmdline", "rb") as f:
                raw = f.read().replace(b"\0", b" ").strip()
            command = raw.decode("utf-8", "replace") if raw else comm
        except OSError:
            command = comm
        return {
            "pid": pid,
            "ppid": ppid,
            "uid": uid,
            "user": username(uid),
            "priority": priority,
            "nice": nice,
            "virt": vsize,
            "res": rss,
            "shr": 0,
            "state": state,
            "cpu": 0.0,
            "mem": 0.0,
            "time": (utime + stime) / max(1, os.sysconf("SC_CLK_TCK")),
            "command": command,
            "comm": comm,
            "threads": threads,
        }
    except (OSError, ValueError, IndexError):
        return None


def processes(opts: Options) -> list[dict]:
    rows = []
    mem_total, _, _, _ = read_meminfo()
    for name in os.listdir("/proc"):
        if not name.isdigit():
            continue
        row = parse_proc(int(name))
        if not row:
            continue
        if opts.pids is not None and row["pid"] not in opts.pids:
            continue
        if opts.uid is not None and row["uid"] != opts.uid:
            continue
        if opts.filter_terms:
            cmd = row["command"].lower()
            if not any(term in cmd for term in opts.filter_terms):
                continue
        if mem_total:
            row["mem"] = row["res"] * 100.0 / mem_total
        rows.append(row)
    key = opts.sort_key
    if key == "PID":
        rows.sort(key=lambda r: r["pid"])
    elif key in ("PERCENT_MEM", "M_RESIDENT"):
        rows.sort(key=lambda r: r["res"], reverse=True)
    elif key in ("USER", "ST_UID"):
        rows.sort(key=lambda r: (r["user"], r["pid"]))
    elif key in ("COMMAND", "Command", "COMM"):
        rows.sort(key=lambda r: r["command"])
    elif key == "TIME":
        rows.sort(key=lambda r: r["time"], reverse=True)
    else:
        rows.sort(key=lambda r: r["pid"])
    return rows


def fmt_time(seconds: float) -> str:
    seconds = int(seconds)
    return f"{seconds // 60}:{seconds % 60:02d}.00"


def snapshot(opts: Options) -> str:
    rows = processes(opts)
    width = shutil.get_terminal_size((80, 24)).columns
    cpus = os.cpu_count() or 1
    load = os.getloadavg() if hasattr(os, "getloadavg") else (0.0, 0.0, 0.0)
    mem_total, mem_used, swap_total, swap_used = read_meminfo()
    uptime = 0.0
    try:
        with open("/proc/uptime", "r", encoding="ascii") as f:
            uptime = float(f.read().split()[0])
    except OSError:
        pass
    days, rem = divmod(int(uptime), 86400)
    hours, rem = divmod(rem, 3600)
    minutes, seconds = divmod(rem, 60)
    uptime_s = f"{days} day, {hours:02d}:{minutes:02d}:{seconds:02d}" if days == 1 else (
        f"{days} days, {hours:02d}:{minutes:02d}:{seconds:02d}" if days else f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    )
    out: list[str] = []
    if not opts.no_meters:
        for start in range(0, min(cpus, 16), 4):
            meters = []
            for c in range(start, min(start + 4, cpus)):
                meters.append(f"{c:>3}[{'#' * 8:8}100.0%]")
            out.append(" ".join(meters)[:width])
        out.append(f"  Mem[{'|' * 12:<20}{human_kb(mem_used)}/{human_kb(mem_total)}] Tasks: {len(rows)}, 0 thr, 0 kthr; {sum(1 for r in rows if r['state'] == 'R')} running"[:width])
        out.append(f"  Swp[{'|' if swap_total else '':<20}{human_kb(swap_used)}/{human_kb(swap_total)}] Load average: {load[0]:.2f} {load[1]:.2f} {load[2]:.2f}"[:width])
        out.append(f"  Uptime: {uptime_s}"[:width])
        out.append("")
    out.append("  PID USER      PRI  NI  VIRT   RES   SHR S  CPU% MEM%   TIME+  Command"[:width])
    for row in rows[: max(1, shutil.get_terminal_size((80, 24)).lines - len(out) - 2)]:
        prefix = ""
        if opts.tree and row["ppid"] not in (0, row["pid"]):
            prefix = "`- "
        cmd = prefix + row["command"]
        line = (
            f"{row['pid']:5d} {row['user']:<8} {row['priority']:3d} {row['nice']:3d} "
            f"{human_kb(row['virt']):>5} {human_kb(row['res']):>5} {human_kb(row['shr']):>5} "
            f"{row['state']:<1} {row['cpu']:5.1f} {row['mem']:4.1f} {fmt_time(row['time']):>8}  {cmd}"
        )
        out.append(line[:width])
    if not opts.no_function_bar:
        out.append("F1Help  F2Setup F3SearchF4FilterF5Tree  F6SortByF7Nice -F8Nice +F9Kill  F10Quit"[:width])
    return "\n".join(out) + "\n"


def run(opts: Options) -> int:
    term = os.environ.get("TERM")
    if not term:
        eprint("Error opening terminal: unknown.")
        return 1
    iterations = opts.max_iterations or 1
    for idx in range(iterations):
        if idx:
            time.sleep(opts.delay / 10.0)
        if sys.stdout.isatty():
            sys.stdout.write("\033[H\033[2J")
        sys.stdout.write(snapshot(opts))
        sys.stdout.flush()
    return 0


def main() -> int:
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    opts, status = parse_args(sys.argv[1:])
    if status is not None:
        return status
    assert opts is not None
    return run(opts)


if __name__ == "__main__":
    raise SystemExit(main())
