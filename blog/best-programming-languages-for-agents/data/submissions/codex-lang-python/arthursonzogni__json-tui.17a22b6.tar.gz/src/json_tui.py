#!/usr/bin/env python3
import json
import os
import sys

VERSION = "1.4.1"

HELP = """  json-tui {OPTIONS} [file]

    A JSON terminal UI

  OPTIONS:

      file                              A JSON file. Omit to read from stdin.
      -h, --help                        Display this help menu.
      -v, --version                     Print version.
      -k, --key, --keybinding           Display key binding.
      -f, --fullscreen                  Display the JSON in fullscreen, in an
                                        alternate buffer
      \"--\" can be used to terminate flag options and force all following
      arguments to be treated as positional options

    If no file is given, json-tui reads JSON from the standard input
    Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues
"""

KEY_TABLE = (
"┌───────────┬────────────────┐\r\n"
"│\x1b[36m\x1b[49mkeys       \x1b[39m\x1b[49m│\x1b[36m\x1b[49maction          \x1b[39m\x1b[49m│\r\n"
"├───────────┼────────────────┤\r\n"
"│Navigate   │← ↑ ↓ →         │\r\n"
"│           │h j k l         │\r\n"
"│           │Mouse::WheelUp  │\r\n"
"│           │Mouse::WheelDown│\r\n"
"├───────────┼────────────────┤\r\n"
"│Toggle     │enter           │\r\n"
"│           │Mouse::Left     │\r\n"
"├───────────┼────────────────┤\r\n"
"│Deep       │                │\r\n"
"│ - Expand  │+               │\r\n"
"│ - Collapse│-               │\r\n"
"├───────────┼────────────────┤\r\n"
"│Exit       │Escape          │\r\n"
"│           │q               │\r\n"
"├───────────┼────────────────┤\r\n"
"│Navigate   │                │\r\n"
"│ - first   │page-up         │\r\n"
"│ - last    │page-down       │\r\n"
"│ - top     │gg              │\r\n"
"│ - bottom  │G               │\r\n"
"└───────────┴────────────────┘\x00\n"
)

BLUE='\x1b[94m\x1b[49m'; CYAN='\x1b[96m\x1b[49m'; RESET='\x1b[39m\x1b[49m'
BOLD='\x1b[1m'; NBOLD='\x1b[22m'; GRAY='\x1b[90m\x1b[49m'
REV='\x1b[7m'; NREV='\x1b[27m'


def parse_args(argv):
    fullscreen = False
    files = []
    stop = False
    for a in argv:
        if stop:
            files.append(a); continue
        if a == '--':
            stop = True
        elif a in ('-h','--help'):
            return 'help', fullscreen, files
        elif a in ('-v','--version'):
            return 'version', fullscreen, files
        elif a in ('-k','--key','-key','--keybinding','-keybinding'):
            return 'keys', fullscreen, files
        elif a in ('-f','--fullscreen'):
            fullscreen = True
        elif a.startswith('-'):
            return 'invalid', fullscreen, files
        else:
            files.append(a)
    if len(files) > 1:
        return 'invalid', fullscreen, files
    return 'run', fullscreen, files


def jdump(v):
    return json.dumps(v, ensure_ascii=False, separators=(',', ': '))


def scalar(v):
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False)
    if v is True: return 'true'
    if v is False: return 'false'
    if v is None: return 'null'
    return json.dumps(v, ensure_ascii=False)


def is_table_array(v):
    return isinstance(v, list) and len(v) > 0 and all(isinstance(x, dict) for x in v)


def render_value(v, indent=0, root=False, comma=False, selected_line=[False]):
    sp = ' ' * indent
    lines = []
    c = ',' if comma else ''
    if isinstance(v, dict):
        keys = sorted(v.keys())
        first = REV+'{'+NREV if root and not selected_line[0] else '{'
        selected_line[0] = True
        lines.append(sp + first)
        for i,k in enumerate(keys):
            val = v[k]
            last = i == len(keys)-1
            prefix = ' '*(indent+2) + f'{BLUE}{json.dumps(str(k), ensure_ascii=False)}{RESET}: '
            tail = ',' if not last else ''
            if isinstance(val, dict):
                if not val:
                    lines.append(prefix + BOLD + '{' + NBOLD)
                    lines.append(' '*(indent+2) + '}' + tail)
                else:
                    lines.append(prefix + BOLD + '{' + NBOLD)
                    inner = render_object_body(val, indent+4)
                    lines.extend(inner)
                    lines.append(' '*(indent+2) + '}' + tail)
            elif isinstance(val, list):
                extra = f'   {GRAY}(table view){RESET}' if is_table_array(val) else ''
                lines.append(prefix + BOLD + '[...]' + (tail if tail else '') + NBOLD + extra)
            else:
                lines.append(prefix + color_scalar(val) + tail)
        lines.append(sp + '}' + c)
    elif isinstance(v, list):
        lines.append(sp + (REV+'['+NREV if root and not selected_line[0] else '['))
        selected_line[0] = True
        for i,item in enumerate(v):
            tail = ',' if i != len(v)-1 else ''
            if isinstance(item, (dict, list)):
                if isinstance(item, dict):
                    lines.append(' '*(indent+2) + BOLD + '{...}' + NBOLD + tail)
                else:
                    lines.append(' '*(indent+2) + BOLD + '[...]' + NBOLD + tail)
            else:
                lines.append(' '*(indent+2) + color_scalar(item) + tail)
        lines.append(sp + ']' + c)
    else:
        s = color_scalar(v)
        if root:
            s = REV + s + NREV
        lines.append(sp + s + c)
    return lines


def render_object_body(d, indent):
    lines=[]
    keys=sorted(d.keys())
    for i,k in enumerate(keys):
        val=d[k]; last=i==len(keys)-1; tail=',' if not last else ''
        prefix=' '*indent + f'{BLUE}{json.dumps(str(k), ensure_ascii=False)}{RESET}: '
        if isinstance(val, dict):
            if val:
                lines.append(prefix+BOLD+'{'+NBOLD)
                lines.extend(render_object_body(val, indent+2))
                lines.append(' '*indent+'}'+tail)
            else:
                lines.append(prefix+BOLD+'{'+NBOLD)
                lines.append(' '*indent+'}'+tail)
        elif isinstance(val, list):
            extra=f'   {GRAY}(table view){RESET}' if is_table_array(val) else ''
            lines.append(prefix+BOLD+'[...]'+(tail if tail else '')+NBOLD+extra)
        else:
            lines.append(prefix+color_scalar(val)+tail)
    return lines


def color_scalar(v):
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False)
    if isinstance(v, (int,float)) and not isinstance(v, bool):
        return CYAN + json.dumps(v) + RESET
    if v is True: return 'true'
    if v is False: return 'false'
    if v is None: return 'null'
    return str(v)


def parse_error_text(e, text):
    # nlohmann/json style, close enough for common invalid-input tests.
    if e.pos == 0 and text:
        shown = text[:2].replace('\n', '\\n').replace('\r', '\\r')
        return f"[json.exception.parse_error.101] parse error at line 1, column {min(2, len(text))}: syntax error while parsing value - invalid literal; last read: '{shown}'"
    idx = max(0, min(len(text), e.pos))
    last = text[max(0, idx-2):idx+1] or text[:1]
    last = last.replace('\n', '\\n').replace('\r', '\\r')
    msg = e.msg
    if 'Expecting value' in msg:
        detail = 'syntax error while parsing value - invalid literal'
    elif 'property name' in msg:
        detail = 'syntax error while parsing object key - invalid literal'
    elif 'delimiter' in msg:
        detail = 'syntax error while parsing object - unexpected token'
    else:
        detail = 'syntax error while parsing value - invalid literal'
    return f"[json.exception.parse_error.101] parse error at line {e.lineno}, column {e.colno}: {detail}; last read: '{last}'"


def read_one_key_if_tty():
    if not sys.stdin.isatty():
        return
    try:
        import termios, tty, select
        fd=sys.stdin.fileno(); old=termios.tcgetattr(fd)
        try:
            tty.setcbreak(fd)
            while True:
                r,_,_=select.select([fd],[],[],0.05)
                if not r: break
                ch=os.read(fd,1)
                if ch in (b'q', b'\x1b', b'\r', b'\n'):
                    break
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    except Exception:
        pass


def display(data, fullscreen=False):
    out=[]
    if fullscreen:
        out.append('\x1b[?1049h')
    out.append('\x1bP$q q\x1b\\\x1b[?7l\x1b[?1000h\x1b[?1003h\x1b[?1015h\x1b[?1006h\x00\r\x1b[2K')
    lines=render_value(data, root=True, selected_line=[False])
    out.append('\r\r\n'.join(lines))
    out.append('\x1b[?25l\x00')
    out.append('\x1b[?1006l\x1b[?1015l\x1b[?1003l\x1b[?1000l\x1b[?7h\x1b[?25h\x1b[1 q\x00\r\r\n')
    if fullscreen:
        out.append('\x1b[?1049l')
    sys.stdout.write(''.join(out))
    sys.stdout.flush()


def main(argv):
    mode, fullscreen, files = parse_args(argv)
    if mode == 'help':
        sys.stdout.write(HELP); return 0
    if mode == 'version':
        print(VERSION); return 0
    if mode == 'keys':
        sys.stdout.write(KEY_TABLE); return 0
    if mode == 'invalid':
        print('Invalid arguments'); return 1

    if files:
        try:
            with open(files[0], 'r', encoding='utf-8') as f:
                text=f.read()
        except OSError:
            print(f'Could not open file {files[0]}')
            return 1
    else:
        print('Reading from stdin...')
        text=sys.stdin.read()
    try:
        data=json.loads(text)
    except json.JSONDecodeError as e:
        print(parse_error_text(e, text))
        return 1
    display(data, fullscreen)
    read_one_key_if_tty()
    return 0

if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
