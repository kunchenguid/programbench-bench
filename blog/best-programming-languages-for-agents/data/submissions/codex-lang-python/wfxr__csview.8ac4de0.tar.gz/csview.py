#!/usr/bin/env python3
import csv
import io
import os
import sys
import unicodedata


VERSION = "csview 1.3.4"
STYLES = {"none", "ascii", "ascii2", "sharp", "rounded", "reinforced", "markdown", "grid"}
ALIGNS = {"left", "center", "right"}

HELP = """A high performance csv viewer with cjk/emoji support.

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          File to view

Options:
  -H, --no-headers
          Specify that the input has no header row
  -n, --number
          Prepend a column of line numbers to the table
  -t, --tsv
          Use '\\t' as delimiter for tsv
  -d, --delimiter <DELIMITER>
          Specify the field delimiter [default: ,]
  -s, --style <STYLE>
          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
          rounded, reinforced, markdown, grid]
  -p, --padding <PADDING>
          Specify padding for table cell [default: 1]
  -i, --indent <INDENT>
          Specify global indent for table [default: 0]
      --sniff <LIMIT>
          Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
          [default: 1000]
      --header-align <HEADER_ALIGN>
          Specify the alignment of the table header [default: center] [possible values: left,
          center, right]
      --body-align <BODY_ALIGN>
          Specify the alignment of the table body [default: left] [possible values: left, center,
          right]
  -P, --disable-pager
          Disable pager
  -h, --help
          Print help
  -V, --version
          Print version
"""


def char_width(ch):
    if ch == "\n" or ch == "\r":
        return 0
    cat = unicodedata.category(ch)
    if cat.startswith("M") or cat == "Cf":
        return 0
    if unicodedata.east_asian_width(ch) in ("W", "F"):
        return 2
    o = ord(ch)
    if (0x1F000 <= o <= 0x1FAFF) or (0x2600 <= o <= 0x27BF):
        return 2
    return 1


def disp_width(s):
    return sum(char_width(c) for c in s)


def truncate_width(s, limit):
    if limit <= 0:
        return ""
    out = []
    used = 0
    for ch in s:
        w = char_width(ch)
        if used + w > limit:
            break
        out.append(ch)
        used += w
    return "".join(out)


def pad_to(s, width, align):
    s = truncate_width(s, width)
    missing = max(0, width - disp_width(s))
    if align == "right":
        return " " * missing + s
    if align == "center":
        left = missing // 2
        return " " * left + s + " " * (missing - left)
    return s + " " * missing


def cell(s, width, align, padding):
    return " " * padding + pad_to(s, width, align) + " " * padding


def parse_u64(name, val):
    try:
        if val.startswith("-"):
            raise ValueError("invalid digit found in string")
        return int(val, 10)
    except ValueError:
        err = "invalid digit found in string"
        print(f"error: invalid value '{val}' for '{name}': {err}\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        sys.exit(2)


def invalid_choice(opt, val, choices):
    print(f"error: invalid value '{val}' for '{opt}'", file=sys.stderr)
    print(f"  [possible values: {', '.join(choices)}]\n", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def parse_args(argv):
    opts = {
        "headers": True,
        "number": False,
        "delimiter": ",",
        "style": "sharp",
        "padding": 1,
        "indent": 0,
        "sniff": 1000,
        "header_align": "center",
        "body_align": "left",
        "file": None,
    }
    i = 0
    used_tsv = False
    used_delim = False
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a in ("-H", "--no-headers"):
            opts["headers"] = False
        elif a in ("-n", "--number"):
            opts["number"] = True
        elif a in ("-P", "--disable-pager"):
            pass
        elif a in ("-t", "--tsv"):
            used_tsv = True
            opts["delimiter"] = "\t"
        elif a in ("-d", "--delimiter"):
            if i + 1 >= len(argv):
                print("error: a value is required for '--delimiter <DELIMITER>'", file=sys.stderr)
                sys.exit(2)
            i += 1
            used_delim = True
            val = argv[i]
            if val == "":
                print("error: invalid value '' for '--delimiter <DELIMITER>': cannot parse char from empty string\n", file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                sys.exit(2)
            if len(val) != 1:
                print(f"error: invalid value '{val}' for '--delimiter <DELIMITER>': too many characters in string\n", file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                sys.exit(2)
            opts["delimiter"] = val
        elif a in ("-s", "--style"):
            i += 1
            if i >= len(argv):
                print("error: a value is required for '--style <STYLE>'", file=sys.stderr)
                sys.exit(2)
            if argv[i] not in STYLES:
                invalid_choice("--style <STYLE>", argv[i], ["none", "ascii", "ascii2", "sharp", "rounded", "reinforced", "markdown", "grid"])
            opts["style"] = argv[i]
        elif a in ("-p", "--padding"):
            i += 1
            opts["padding"] = parse_u64("--padding <PADDING>", argv[i])
        elif a in ("-i", "--indent"):
            i += 1
            opts["indent"] = parse_u64("--indent <INDENT>", argv[i])
        elif a == "--sniff":
            i += 1
            opts["sniff"] = parse_u64("--sniff <LIMIT>", argv[i])
        elif a == "--header-align":
            i += 1
            if argv[i] not in ALIGNS:
                invalid_choice("--header-align <HEADER_ALIGN>", argv[i], ["left", "center", "right"])
            opts["header_align"] = argv[i]
        elif a == "--body-align":
            i += 1
            if argv[i] not in ALIGNS:
                invalid_choice("--body-align <BODY_ALIGN>", argv[i], ["left", "center", "right"])
            opts["body_align"] = argv[i]
        elif a.startswith("-"):
            print(f"error: unexpected argument '{a}' found\n", file=sys.stderr)
            print("Usage: executable [OPTIONS] [FILE]\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        else:
            if opts["file"] is not None:
                print(f"error: unexpected argument '{a}' found\n", file=sys.stderr)
                print("Usage: executable [OPTIONS] [FILE]\n", file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                sys.exit(2)
            opts["file"] = a
        i += 1
    if used_tsv and used_delim:
        print("error: the argument '--tsv' cannot be used with '--delimiter <DELIMITER>'\n", file=sys.stderr)
        print("Usage: executable --disable-pager --tsv [FILE]\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    return opts


def read_rows(opts):
    try:
        if opts["file"]:
            with open(opts["file"], newline="", encoding="utf-8") as f:
                text = f.read()
        else:
            text = sys.stdin.read()
        line_starts = []
        off = 0
        for line in text.splitlines(True):
            line_starts.append(off)
            off += len(line.encode("utf-8"))
        rows = []
        reader = csv.reader(io.StringIO(text, newline=""), delimiter=opts["delimiter"])
        expected = None
        for n, row in enumerate(reader, start=1):
            if not row:
                continue
            if expected is None:
                expected = len(row)
            elif len(row) != expected:
                line = reader.line_num
                byte = line_starts[line - 1] if 0 < line <= len(line_starts) else 0
                raise ValueError(f"record {n-1} (line: {line}, byte: {byte}): found record with {len(row)} fields, but the previous record has {expected} fields")
            rows.append(row)
        return rows
    except FileNotFoundError as e:
        print(f"csview: {e.strerror} (os error {e.errno})", file=sys.stderr)
        sys.exit(1)
    except csv.Error as e:
        print(f"csview: CSV error: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"csview: CSV error: {e}", file=sys.stderr)
        sys.exit(1)


STYLE_CHARS = {
    "ascii": dict(tl="+", tr="+", bl="+", br="+", tm="+", mm="+", bm="+", ml="+", mr="+", v="|", h="-"),
    "sharp": dict(tl="┌", tr="┐", bl="└", br="┘", tm="┬", mm="┼", bm="┴", ml="├", mr="┤", v="│", h="─"),
    "rounded": dict(tl="╭", tr="╮", bl="╰", br="╯", tm="┬", mm="┼", bm="┴", ml="├", mr="┤", v="│", h="─"),
    "reinforced": dict(tl="┏", tr="┓", bl="┗", br="┛", tm="┬", mm="┼", bm="┴", ml="├", mr="┤", v="│", h="─"),
    "grid": dict(tl="┌", tr="┐", bl="└", br="┘", tm="┬", mm="┼", bm="┴", ml="├", mr="┤", v="│", h="─"),
}


def border(widths, padding, chars, kind):
    total = [chars["h"] * (w + 2 * padding) for w in widths]
    if not widths:
        if kind == "top":
            return chars["tl"] + chars["tr"]
        if kind == "bottom":
            return chars["bl"] + chars["br"]
        return chars["ml"] + chars["mr"]
    if kind == "top":
        return chars["tl"] + chars["tm"].join(total) + chars["tr"]
    if kind == "bottom":
        return chars["bl"] + chars["bm"].join(total) + chars["br"]
    return chars["ml"] + chars["mm"].join(total) + chars["mr"]


def render_line(row, widths, align, padding, style):
    if not widths:
        return "││" if style in STYLE_CHARS or style == "grid" else ""
    parts = [cell(row[i] if i < len(row) else "", widths[i], align, padding) for i in range(len(widths))]
    if style == "none":
        return "".join(parts)
    if style == "ascii2":
        return "|".join(parts)
    if style == "markdown":
        return "|" + "|".join(parts) + "|"
    ch = STYLE_CHARS[style]
    return ch["v"] + ch["v"].join(parts) + ch["v"]


def render(rows, opts):
    header = None
    body = rows
    if opts["headers"] and rows:
        header = rows[0]
        body = rows[1:]
    if opts["number"]:
        if header is not None:
            header = ["#"] + header
            body = [[str(i)] + r for i, r in enumerate(body, start=1)]
        else:
            body = [[str(i)] + r for i, r in enumerate(body, start=1)]
    probe = []
    if header is not None:
        probe.append(header)
    limit = opts["sniff"]
    probe.extend(body if limit == 0 else body[:limit])
    cols = max((len(r) for r in probe), default=(0 if rows else 0))
    if not rows:
        cols = 0
    widths = [0] * cols
    for r in probe:
        for i in range(cols):
            widths[i] = max(widths[i], disp_width(r[i] if i < len(r) else ""))

    style = opts["style"]
    pad = opts["padding"]
    lines = []
    if style in STYLE_CHARS:
        ch = STYLE_CHARS[style]
        lines.append(border(widths, pad, ch, "top"))
        if header is not None:
            lines.append(render_line(header, widths, opts["header_align"], pad, style))
            if body:
                lines.append(border(widths, pad, ch, "mid"))
            elif opts["headers"] and rows:
                pass
        elif not rows:
            lines.append(render_line([], widths, opts["body_align"], pad, style))
        for idx, r in enumerate(body):
            lines.append(render_line(r, widths, opts["body_align"], pad, style))
            if style == "grid" and idx != len(body) - 1:
                lines.append(border(widths, pad, ch, "mid"))
        lines.append(border(widths, pad, ch, "bottom"))
    elif style == "markdown":
        if header is not None:
            lines.append(render_line(header, widths, opts["header_align"], pad, style))
            hy = ["-" * (w + 2 * pad) for w in widths]
            lines.append("|" + "|".join(hy) + "|")
        for r in body:
            lines.append(render_line(r, widths, opts["body_align"], pad, style))
    elif style == "ascii2":
        if header is not None:
            lines.append(render_line(header, widths, opts["header_align"], pad, style))
            hy = ["-" * (w + 2 * pad) for w in widths]
            lines.append("+".join(hy))
        for r in body:
            lines.append(render_line(r, widths, opts["body_align"], pad, style))
        lines = [" " + l + " " for l in lines]
    else:
        if header is not None:
            lines.append(render_line(header, widths, opts["header_align"], pad, style))
        for r in body:
            lines.append(render_line(r, widths, opts["body_align"], pad, style))

    indent = " " * opts["indent"]
    return "\n".join(indent + line for line in lines) + ("\n" if lines else "")


def main():
    opts = parse_args(sys.argv[1:])
    rows = read_rows(opts)
    sys.stdout.write(render(rows, opts))


if __name__ == "__main__":
    main()
