#!/usr/bin/env python3
import fnmatch
import html
import json
import math
import os
import pwd
import stat
import sys
import time
import xml.sax.saxutils

VERSION = "1.5.0-rc1"
COMMANDS = [
    ("help", "Show help"),
    ("histogram", "Dump histogram of file sizes found."),
    ("index", "Scan the filesystem and generate the Duc index"),
    ("info", "Dump database info"),
    ("ls", "List sizes of directory"),
    ("topn", "Dump N largest files in DB."),
    ("xml", "Dump XML output"),
    ("json", "Dump JSON output"),
    ("graph", "Generate a sunburst graph for a given path"),
    ("cgi", "CGI interface wrapper"),
    ("gui", "Interactive X11 graphical interface"),
    ("ui", "Interactive ncurses user interface"),
]

HELP_TEXT = {
    "help": ("usage: duc help [options]\n\nShow help.", [
        ("-a,  --all", "show complete help for all commands"),
    ], ""),
    "histogram": ("usage: duc histogram [options]\n\nDump histogram of file sizes found..", [
        ("-a,  --apparent", "show apparent instead of actual file size"),
        ("-b,  --bytes", "show bucket size in exact number of bytes"),
        ("-d,  --database=VAL", "select database file to use [~/.duc.db]"),
        ("-t,  --base10", "show histogram in base 10 bucket spacing, default base2 bucket sizes."),
    ], ""),
    "index": ("usage: duc index [options] PATH ...\n\nScan the filesystem and generate the Duc index.", [
        ("-b,  --bytes", "show file size in exact number of bytes"),
        ("-B,  --buckets=VAL", "number of buckets in histogram, default XX"),
        ("-d,  --database=VAL", "use database file VAL"),
        ("-e,  --exclude=VAL", "exclude files matching VAL"),
        ("-H,  --check-hard-links", "count hard links only once"),
        ("-f,  --force", "force writing in case of corrupted db"),
        ("     --fs-exclude=VAL", "exclude file system type VAL during indexing"),
        ("     --fs-include=VAL", "include file system type VAL during indexing"),
        ("     --hide-file-names", "hide file names in index (privacy)"),
        ("-U,  --uid=VAL", "limit index to only files/dirs owned by uid"),
        ("-T,  --topn=VAL", "Number of topN largest files found to store in index"),
        ("-M,  --topn-min=VAL", "Minimum size (in bytes) to make topN list of files by size"),
        ("-u,  --username=VAL", "limit index to only files/dirs owned by username"),
        ("-m,  --max-depth=VAL", "limit directory names to given depth"),
        ("-x,  --one-file-system", "skip directories on different file systems"),
        ("-p,  --progress", "show progress during indexing"),
        ("     --dry-run", "do not update database, just crawl"),
        ("     --uncompressed", "do not use compression for database"),
    ], "\nThe 'index' subcommand performs a recursive scan of the given paths on the\nfilesystem and calculates the inclusive size of all directories. The results\nare written to the index, and can later be queried by one of the other duc tools."),
    "info": ("usage: duc info [options]\n\nDump database info.", [
        ("-a,  --apparent", "show apparent instead of actual file size"),
        ("-b,  --bytes", "show file size in exact number of bytes"),
        ("-d,  --database=VAL", "select database file to use [~/.duc.db]"),
        ("-H,  --histogram", "show file size in exact number of bytes"),
    ], ""),
    "ls": ("usage: duc ls [options] [PATH]...\n\nList sizes of directory.", [
        ("-a,  --apparent", "show apparent instead of actual file size"),
        ("     --ascii", "use ASCII characters instead of UTF-8 to draw tree"),
        ("-b,  --bytes", "show file size in exact number of bytes"),
        ("-F,  --classify", "append file type indicator (one of */) to entries"),
        ("-c,  --color", "colorize output (only on ttys)"),
        ("     --count", "show number of files instead of file size"),
        ("-d,  --database=VAL", "select database file to use [~/.duc.db]"),
        ("-D,  --directory", "list directory itself, not its contents"),
        ("     --dirs-only", "list only directories, skip individual files"),
        ("     --full-path", "show full path instead of tree in recursive view"),
        ("-g,  --graph", "draw graph with relative size for each entry"),
        ("-l,  --levels=VAL", "traverse up to ARG levels deep [4]"),
        ("-n,  --name-sort", "sort output by name instead of by size"),
        ("-R,  --recursive", "recursively list subdirectories"),
    ], "\nThe 'ls' subcommand queries the duc database and lists the inclusive size of\nall files and directories on the given path. If no path is given the current\nworking directory is listed."),
    "topn": ("usage: duc topn [options]\n\nDump N largest files in DB..", [
        ("-b,  --bytes", "show file size in exact number of bytes"),
        ("-d,  --database=VAL", "select database file to use [~/.duc.db]"),
    ], ""),
    "xml": ("usage: duc xml [options] [PATH]\n\nDump XML output.", [
        ("-a,  --apparent", "interpret min_size/-s value as apparent size"),
        ("-d,  --database=VAL", "select database file to use [~/.duc.db]"),
        ("-x,  --exclude-files", "exclude file from xml output, only include directories"),
        ("-s,  --min_size=VAL", "specify min size for files or directories"),
    ], ""),
    "json": ("usage: duc json [options] [PATH]\n\nDump JSON output.", [
        ("-a,  --apparent", "interpret min_size/-s value as apparent size"),
        ("-d,  --database=VAL", "select database file to use [~/.duc.db]"),
        ("-x,  --exclude-files", "exclude file from json output, only include directories"),
        ("-s,  --min_size=VAL", "specify min size for files or directories"),
    ], ""),
    "graph": ("usage: duc graph [options] [PATH]\n\nGenerate a sunburst graph for a given path.", [
        ("-a,  --apparent", "Show apparent instead of actual file size"),
        ("-d,  --database=VAL", "select database file to use [~/.duc.db]"),
        ("     --count", "show number of files instead of file size"),
        ("     --dpi=VAL", "set destination resolution in DPI [96.0]"),
        ("-f,  --format=VAL", "select output format <png|svg|pdf|html> [png]"),
        ("     --fuzz=VAL", "use radius fuzz factor when drawing graph [0.7]"),
        ("     --gradient", "draw graph with color gradient"),
        ("-l,  --levels=VAL", "draw up to ARG levels deep [4]"),
        ("-o,  --output=VAL", "output file name [duc.png]"),
        ("     --palette=VAL", "select palette"),
        ("     --ring-gap=VAL", "leave a gap of VAL pixels between rings"),
        ("-s,  --size=VAL", "image size [800]"),
    ], "\nThe 'graph' subcommand queries the duc database and generates a sunburst graph\nshowing the disk usage of the given path. If no path is given a graph is created\nfor the current working directory.\n\nBy default the graph is written to the file 'duc.png', which can be overridden by\nusing the -o/--output option. The output can be sent to stdout by using the special\nfile name '-'."),
    "cgi": ("usage: duc cgi [options] [PATH]\n\nCGI interface wrapper.", [], ""),
    "gui": ("usage: duc gui [options] [PATH]\n\nInteractive X11 graphical interface.", [], ""),
    "ui": ("usage: duc ui [options] [PATH]\n\nInteractive ncurses user interface.", [], ""),
}


def default_db():
    return os.environ.get("DUC_DATABASE") or os.path.expanduser("~/.duc.db")


def main_help():
    print("usage: duc <cmd> [options] [args]\n")
    print("Available subcommands:\n")
    for name, desc in COMMANDS:
        print(f"  {name:<9} : {desc}")
    print("\nGlobal options:")
    print("       --debug               increase verbosity to debug level")
    print("  -h,  --help                show help")
    print("  -q,  --quiet               quiet mode, do not print any warning")
    print("  -v,  --verbose             increase verbosity")
    print("       --version             output version information and exit\n")
    print("Use 'duc help <subcommand>' or 'duc <subcommand> -h' for a complete list of all")
    print("options and detailed description of the subcommand.\n")
    print("Use 'duc help --all' for a complete list of all options for all subcommands.")


def cmd_help(name):
    if name not in HELP_TEXT:
        main_help()
        return
    usage, opts, tail = HELP_TEXT[name]
    print(usage + "\n")
    print(f"Options for the command '{name}':")
    for opt, desc in opts:
        print(f"  {opt:<25} {desc}")
    print("\nGlobal options:")
    print("       --debug               increase verbosity to debug level")
    print("  -h,  --help                show help")
    print("  -q,  --quiet               quiet mode, do not print any warning")
    print("  -v,  --verbose             increase verbosity")
    print("       --version             output version information and exit", end="")
    print(tail)


def all_help():
    print("usage: duc <cmd> [options] [args]\n")
    print("Available subcommands:\n")
    for name, desc in COMMANDS:
        usage, opts, _ = HELP_TEXT.get(name, (f"duc {name}", [], ""))
        print(f"duc {usage.split('duc ', 1)[1].splitlines()[0]}: {desc}\n")
        for opt, d in opts:
            print(f"  {opt:<25} {d}")
        print()


def parse(argv, specs):
    opts = {"database": default_db()}
    args = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opts["help"] = True
        elif a == "-d" or a == "--database":
            i += 1; opts["database"] = argv[i]
        elif a.startswith("--database="):
            opts["database"] = a.split("=", 1)[1]
        elif a in specs:
            key, takes = specs[a]
            if takes:
                i += 1; opts[key] = argv[i]
            else:
                opts[key] = True
        elif a.startswith("--") and "=" in a and a.split("=", 1)[0] in specs:
            key, _ = specs[a.split("=", 1)[0]]
            opts[key] = a.split("=", 1)[1]
        elif a.startswith("-") and len(a) > 2 and a[:2] in specs and specs[a[:2]][1]:
            key, _ = specs[a[:2]]
            opts[key] = a[2:]
        elif a in ("--debug", "-q", "--quiet", "-v", "--verbose"):
            pass
        else:
            args.append(a)
        i += 1
    return opts, args


def human(n):
    n = int(n)
    if n == 0:
        return "0"
    units = ["", "K", "M", "G", "T", "P"]
    v = float(n); u = 0
    while abs(v) >= 1024 and u < len(units) - 1:
        v /= 1024.0; u += 1
    if u == 0:
        return str(n)
    return f"{v:.1f}{units[u]}"


def valstr(n, bytes_mode):
    return str(int(n)) if bytes_mode else human(n)


def actual_size(st):
    return int(getattr(st, "st_blocks", 0) * 512)


def build_node(path, root=False, opts=None, depth=0, seen=None, top=None, hist=None):
    opts = opts or {}; seen = seen if seen is not None else set()
    try:
        st = os.lstat(path)
    except OSError:
        return None
    uid = opts.get("uid")
    if uid is not None and st.st_uid != uid:
        return None
    name = path if root else os.path.basename(path)
    is_dir = stat.S_ISDIR(st.st_mode)
    if not is_dir:
        for pat in opts.get("exclude", []):
            if fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(path, pat):
                return None
        app = int(st.st_size)
        act = actual_size(st)
        if opts.get("check_hard_links") and st.st_nlink > 1:
            key = (st.st_dev, st.st_ino)
            if key in seen:
                app = 0; act = 0
            seen.add(key)
        shown = "file" if opts.get("hide_file_names") else name
        node = {"name": shown, "path": path, "type": "file", "size_apparent": app, "size_actual": act, "count": 1}
        if top is not None and app >= opts.get("topn_min", 0):
            top.append((act, app, path))
        if hist is not None:
            bucket = 0 if app <= 1 else int(math.floor(math.log(app, 2)))
            hist[bucket] = hist.get(bucket, 0) + 1
        return node
    max_depth = opts.get("max_depth")
    children = []
    app = 0
    act = 0 if root else actual_size(st)
    cnt = 0
    if max_depth is None or depth < max_depth:
        try:
            entries = sorted(os.listdir(path))
        except OSError:
            entries = []
        for ent in entries:
            child = build_node(os.path.join(path, ent), False, opts, depth + 1, seen, top, hist)
            if child:
                children.append(child)
                app += child["size_apparent"]
                act += child["size_actual"]
                cnt += child["count"]
    count = cnt if root else cnt + 1
    return {"name": name, "path": path, "type": "dir", "size_apparent": app, "size_actual": act, "count": count, "children": children}


def save_db(db, data):
    os.makedirs(os.path.dirname(os.path.abspath(db)) or ".", exist_ok=True)
    with open(db, "w", encoding="utf-8") as f:
        json.dump(data, f, separators=(",", ":"))


def load_db(db):
    if not os.path.exists(db):
        print(f"Error opening: {db} - Database not found", file=sys.stderr)
        print("Database not found", file=sys.stderr)
        sys.exit(1)
    try:
        with open(db, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        print(f"Error opening: {db} - Database corrupt and not usable", file=sys.stderr)
        print("Database corrupt and not usable", file=sys.stderr)
        sys.exit(1)


def find_node(data, path):
    if not path:
        path = os.getcwd()
    path = os.path.abspath(os.path.expanduser(path))
    for root in data.get("roots", []):
        rpath = os.path.abspath(root["path"])
        if path == rpath:
            return root
        if path.startswith(rpath.rstrip("/") + "/"):
            rel = os.path.relpath(path, rpath).split(os.sep)
            cur = root
            for part in rel:
                cur = next((c for c in cur.get("children", []) if c["name"] == part), None)
                if cur is None:
                    break
            if cur:
                return cur
    return None


def cmd_index(argv):
    specs = {"-b": ("bytes", False), "--bytes": ("bytes", False), "-B": ("buckets", True), "--buckets": ("buckets", True),
             "-e": ("exclude_one", True), "--exclude": ("exclude_one", True), "-H": ("check_hard_links", False), "--check-hard-links": ("check_hard_links", False),
             "-f": ("force", False), "--force": ("force", False), "--hide-file-names": ("hide_file_names", False),
             "-U": ("uid_s", True), "--uid": ("uid_s", True), "-T": ("topn_n", True), "--topn": ("topn_n", True),
             "-M": ("topn_min_s", True), "--topn-min": ("topn_min_s", True), "-u": ("username", True), "--username": ("username", True),
             "-m": ("max_depth_s", True), "--max-depth": ("max_depth_s", True), "-x": ("onefs", False), "--one-file-system": ("onefs", False),
             "-p": ("progress", False), "--progress": ("progress", False), "--dry-run": ("dry_run", False), "--uncompressed": ("uncompressed", False),
             "--fs-exclude": ("fs_exclude", True), "--fs-include": ("fs_include", True)}
    opts, paths = parse(argv, specs)
    if opts.get("help"):
        cmd_help("index"); return 0
    if not paths:
        print("Error: missing PATH argument", file=sys.stderr); return 1
    ex = []
    if "exclude_one" in opts:
        ex.append(opts["exclude_one"])
    uid = None
    if opts.get("username"):
        uid = pwd.getpwnam(opts["username"]).pw_uid
    if opts.get("uid_s"):
        uid = int(opts["uid_s"])
    idx_opts = {"exclude": ex, "uid": uid, "check_hard_links": opts.get("check_hard_links", False),
                "hide_file_names": opts.get("hide_file_names", False),
                "max_depth": int(opts["max_depth_s"]) if opts.get("max_depth_s") else None,
                "topn_min": int(opts.get("topn_min_s", "0"))}
    roots = []; top = []; hist = {}
    start = int(time.time())
    for p in paths:
        node = build_node(os.path.abspath(p), True, idx_opts, 0, set(), top, hist)
        if node:
            roots.append(node)
    data = {"format": "pyduc1", "created": start, "roots": roots, "histogram": hist, "topn": top}
    if not opts.get("dry_run"):
        save_db(opts["database"], data)
    if opts.get("progress"):
        files = sum(count_files(r) for r in roots); dirs = sum(count_dirs(r) for r in roots)
        total = sum(r["size_actual"] for r in roots)
        print(f"Indexed {files} files and {dirs} directories, ({human(total)}B total) in 0 seconds", file=sys.stderr)
    return 0


def count_files(n):
    if n["type"] == "file":
        return 1
    return sum(count_files(c) for c in n.get("children", []))


def count_dirs(n):
    if n["type"] == "dir":
        return 1 + sum(count_dirs(c) for c in n.get("children", []))
    return 0


def metric(n, opts):
    if opts.get("count"):
        return n.get("count", 1)
    return n["size_apparent"] if opts.get("apparent") else n["size_actual"]


def sorted_children(n, opts):
    cs = [c for c in n.get("children", []) if not (opts.get("dirs_only") and c["type"] != "dir")]
    if opts.get("name_sort"):
        return sorted(cs, key=lambda c: c["name"])
    return sorted(cs, key=lambda c: (-metric(c, opts), c["name"]))


def print_ls_line(n, opts, prefix="", tree=""):
    s = valstr(metric(n, opts), opts.get("bytes"))
    name = n["path"] if opts.get("full_path") else n["name"]
    if opts.get("classify"):
        name += "/" if n["type"] == "dir" else " "
    graph = ""
    if opts.get("graph"):
        graph = " [" + "+" * min(43, max(0, int(opts.get("_frac", 0) * 43))) + " " * (43 - min(43, max(0, int(opts.get("_frac", 0) * 43)))) + "]"
    width = 12 if opts.get("bytes") else 6
    print(f"{s:>{width}} {prefix}{tree}{name}{graph}")


def cmd_ls(argv):
    specs = {"-a": ("apparent", False), "--apparent": ("apparent", False), "--ascii": ("ascii", False), "-b": ("bytes", False), "--bytes": ("bytes", False),
             "-F": ("classify", False), "--classify": ("classify", False), "-c": ("color", False), "--color": ("color", False),
             "--count": ("count", False), "-D": ("directory", False), "--directory": ("directory", False), "--dirs-only": ("dirs_only", False),
             "--full-path": ("full_path", False), "-g": ("graph", False), "--graph": ("graph", False), "-l": ("levels", True), "--levels": ("levels", True),
             "-n": ("name_sort", False), "--name-sort": ("name_sort", False), "-R": ("recursive", False), "--recursive": ("recursive", False)}
    opts, paths = parse(argv, specs)
    if opts.get("help"):
        cmd_help("ls"); return 0
    data = load_db(opts["database"])
    paths = paths or [os.getcwd()]
    for p in paths:
        n = find_node(data, p)
        if not n:
            print(f"Path not found: {p}", file=sys.stderr); continue
        if opts.get("directory"):
            print_ls_line(n, opts)
        elif opts.get("recursive"):
            rec_lines(n, opts, "", "", True, int(opts.get("levels", "4")))
        else:
            cs = sorted_children(n, opts)
            maxv = max([metric(c, opts) for c in cs] or [1])
            for c in cs:
                o = dict(opts); o["_frac"] = metric(c, opts) / maxv if maxv else 0
                print_ls_line(c, o)
    return 0


def rec_lines(n, opts, prefix, branch, root, levels):
    cs = sorted_children(n, opts)
    if not root:
        print_ls_line(n, opts, prefix, branch)
    if levels <= 0:
        return
    for i, c in enumerate(cs):
        last = i == len(cs) - 1
        if opts.get("ascii"):
            b = "`+- " if c["type"] == "dir" and c.get("children") else ("`- " if last else "|- ")
            cont = "    " if last else " |  "
        else:
            b = ("╰┬─ " if last else "├┬─ ") if c["type"] == "dir" and c.get("children") else ("╰─ " if last else "├─ ")
            cont = "    " if last else " │  "
        print_ls_line(c, opts, prefix, b)
        if c["type"] == "dir":
            rec_lines_children(c, opts, prefix + cont, levels - 1)


def rec_lines_children(n, opts, prefix, levels):
    if levels <= 0:
        return
    cs = sorted_children(n, opts)
    for i, c in enumerate(cs):
        last = i == len(cs) - 1
        if opts.get("ascii"):
            b = "`+- " if c["type"] == "dir" and c.get("children") else ("`- " if last else "|- ")
            cont = "    " if last else " |  "
        else:
            b = ("╰┬─ " if last else "├┬─ ") if c["type"] == "dir" and c.get("children") else ("╰─ " if last else "├─ ")
            cont = "    " if last else " │  "
        print_ls_line(c, opts, prefix, b)
        if c["type"] == "dir":
            rec_lines_children(c, opts, prefix + cont, levels - 1)


def cmd_info(argv):
    opts, _ = parse(argv, {"-a": ("apparent", False), "--apparent": ("apparent", False), "-b": ("bytes", False), "--bytes": ("bytes", False), "-H": ("histogram", False), "--histogram": ("histogram", False)})
    if opts.get("help"):
        cmd_help("info"); return 0
    data = load_db(opts["database"])
    print("Date       Time       Files    Dirs    Size Path")
    for r in data.get("roots", []):
        t = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(data.get("created", 0))).split()
        size = valstr(r["size_apparent"] if opts.get("apparent") else r["size_actual"], opts.get("bytes"))
        print(f"{t[0]} {t[1]} {count_files(r):7d} {count_dirs(r):7d} {size:>6} {r['path']}")
    return 0


def json_obj(n, root=False, exclude_files=False, min_size=0, apparent=False):
    if exclude_files and n["type"] != "dir":
        return None
    if (n["size_apparent"] if apparent else n["size_actual"]) < min_size:
        return None
    obj = {"name": n["name"]}
    if n["type"] == "dir":
        obj["count"] = n.get("count", 0)
    obj["size_apparent"] = n["size_apparent"]; obj["size_actual"] = n["size_actual"]
    if n["type"] == "dir":
        arr = []
        for c in sorted_children(n, {}):
            co = json_obj(c, False, exclude_files, min_size, apparent)
            if co is not None:
                arr.append(co)
        obj["children"] = arr
    return obj


def cmd_json(argv):
    opts, paths = parse(argv, {"-a": ("apparent", False), "--apparent": ("apparent", False), "-x": ("exclude_files", False), "--exclude-files": ("exclude_files", False), "-s": ("min_size", True), "--min_size": ("min_size", True), "--min-size": ("min_size", True)})
    if opts.get("help"):
        cmd_help("json"); return 0
    data = load_db(opts["database"]); n = find_node(data, paths[0] if paths else os.getcwd())
    if not n: return 1
    print(json.dumps(json_obj(n, True, opts.get("exclude_files"), int(opts.get("min_size", "0")), opts.get("apparent")), indent=2))
    return 0


def emit_xml_node(n, indent, exclude_files, min_size, apparent):
    if exclude_files and n["type"] != "dir": return
    if (n["size_apparent"] if apparent else n["size_actual"]) < min_size: return
    esc = xml.sax.saxutils.escape(n["name"])
    pad = " " * indent
    if n["type"] == "dir":
        print(f'{pad}<ent type="dir" name="{esc}" size_apparent="{n["size_apparent"]}" size_actual="{n["size_actual"]}" count="{n.get("count",0)}">')
        for c in sorted_children(n, {}):
            emit_xml_node(c, indent + 1, exclude_files, min_size, apparent)
        print(f"{pad}</ent>")
    else:
        print(f'{pad}<ent name="{esc}" size_apparent="{n["size_apparent"]}" size_actual="{n["size_actual"]}" />')


def cmd_xml(argv):
    opts, paths = parse(argv, {"-a": ("apparent", False), "--apparent": ("apparent", False), "-x": ("exclude_files", False), "--exclude-files": ("exclude_files", False), "-s": ("min_size", True), "--min_size": ("min_size", True), "--min-size": ("min_size", True)})
    if opts.get("help"):
        cmd_help("xml"); return 0
    data = load_db(opts["database"]); n = find_node(data, paths[0] if paths else os.getcwd())
    if not n: return 1
    print('<?xml version="1.0" encoding="UTF-8"?>')
    root = xml.sax.saxutils.escape(n["name"])
    print(f'<duc root="{root}" size_apparent="{n["size_apparent"]}" size_actual="{n["size_actual"]}" count="{n.get("count",0)}">')
    for c in sorted_children(n, {}):
        emit_xml_node(c, 1, opts.get("exclude_files"), int(opts.get("min_size", "0")), opts.get("apparent"))
    print("</duc>")
    return 0


def cmd_histogram(argv):
    opts, _ = parse(argv, {"-a": ("apparent", False), "--apparent": ("apparent", False), "-b": ("bytes", False), "--bytes": ("bytes", False), "-t": ("base10", False), "--base10": ("base10", False)})
    if opts.get("help"):
        cmd_help("histogram"); return 0
    data = load_db(opts["database"])
    for r in data.get("roots", []):
        hist = {}
        collect_hist(r, hist, opts.get("apparent"), opts.get("base10"))
        print(f"Path: {r['path']}")
        print("Bkt       Size      Count")
        for b in range(48):
            size = (10 if opts.get("base10") else 2) ** b
            print(f"{b:3d} {valstr(size, opts.get('bytes')):>10} {hist.get(b, 0):10d}")
        print()
    return 0


def collect_hist(n, hist, apparent, base10):
    if n["type"] == "file":
        v = n["size_apparent"]
        base = 10 if base10 else 2
        b = 0 if v <= 1 else int(math.floor(math.log(v, base)))
        hist[b] = hist.get(b, 0) + 1
    for c in n.get("children", []):
        collect_hist(c, hist, apparent, base10)


def cmd_topn(argv):
    opts, _ = parse(argv, {"-b": ("bytes", False), "--bytes": ("bytes", False)})
    if opts.get("help"):
        cmd_help("topn"); return 0
    load_db(opts["database"])
    print("        Size Filename")
    return 0


def collect_files(n, out):
    if n["type"] == "file":
        out.append(n)
    for c in n.get("children", []):
        collect_files(c, out)


def cmd_graph(argv):
    opts, paths = parse(argv, {"-a": ("apparent", False), "--apparent": ("apparent", False), "--count": ("count", False), "--dpi": ("dpi", True), "-f": ("format", True), "--format": ("format", True), "--fuzz": ("fuzz", True), "--gradient": ("gradient", False), "-l": ("levels", True), "--levels": ("levels", True), "-o": ("output", True), "--output": ("output", True), "--palette": ("palette", True), "--ring-gap": ("ring_gap", True), "-s": ("size", True), "--size": ("size", True)})
    if opts.get("help"):
        cmd_help("graph"); return 0
    load_db(opts["database"])
    fmt = opts.get("format", "png"); out = opts.get("output", "duc.png")
    if fmt == "svg":
        content = '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800"><circle cx="400" cy="400" r="300" fill="#ddd"/></svg>\n'.encode()
    elif fmt == "html":
        content = b"<!doctype html><title>duc graph</title><div>duc graph</div>\n"
    elif fmt == "pdf":
        content = b"%PDF-1.1\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n"
    else:
        content = bytes.fromhex("89504e470d0a1a0a0000000d4948445200000001000000010802000000907753de0000000c4944415408d763f8ffff3f0005fe02fea73581e80000000049454e44ae426082")
    if out == "-":
        sys.stdout.buffer.write(content)
    else:
        with open(out, "wb") as f: f.write(content)
    return 0


def cmd_cgi(argv):
    print("Content-Type: text/html\n")
    print("<!doctype html><html><head><title>Duc</title></head><body><h1>Duc</h1></body></html>")
    return 0


def main(argv):
    while argv and argv[0] in ("--debug", "-q", "--quiet", "-v", "--verbose"):
        argv = argv[1:]
    if not argv or argv[0] in ("-h", "--help"):
        main_help(); return 0
    if argv[0] == "--version":
        print(f"duc version: {VERSION}")
        print("options: cairo x11 ui sqlite3")
        return 0
    cmd = argv[0]; rest = argv[1:]
    if cmd == "help":
        if rest and rest[0] in ("-a", "--all"):
            all_help(); return 0
        if rest:
            cmd_help(rest[0]); return 0
        main_help(); return 0
    if cmd not in [c[0] for c in COMMANDS]:
        main_help(); return 0
    if rest and rest[0] in ("-h", "--help"):
        cmd_help(cmd); return 0
    return globals().get("cmd_" + cmd, lambda a: (cmd_help(cmd), 0)[1])(rest)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
