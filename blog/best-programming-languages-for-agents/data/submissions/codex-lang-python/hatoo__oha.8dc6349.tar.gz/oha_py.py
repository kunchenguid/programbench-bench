#!/usr/bin/env python3
import argparse
import base64
import csv
import json
import math
import os
import random
import re
import socket
import ssl
import sys
import threading
import time
from dataclasses import dataclass
from http.client import HTTPConnection, HTTPSConnection
from queue import Queue, Empty
from urllib.parse import urlparse

VERSION = "oha 1.12.1"
DESC = "Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation."

HELP = """Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.

Usage: executable [OPTIONS] <URL>

Arguments:
  <URL>  Target URL or file with multiple URLs.

Options:
  -n <N_REQUESTS>
          Number of requests to run. Accepts plain numbers or suffixes: k = 1,000, m = 1,000,000 (e.g. 10k, 1m). [default: 200]
  -c <N_CONNECTIONS>
          Number of connections to run concurrently. You may should increase limit to number of open files for larger `-c`. [default: 50]
  -p <N_HTTP2_PARALLEL>
          Number of parallel requests to send on HTTP/2. `oha` will run c * p concurrent workers in total. [default: 1]
  -z <DURATION>
          Duration of application to send requests.
          On HTTP/1, When the duration is reached, ongoing requests are aborted and counted as "aborted due to deadline"
          You can change this behavior with `-w` option.
          Currently, on HTTP/2, When the duration is reached, ongoing requests are waited. `-w` option is ignored.
          Examples: -z 10s -z 3m.
  -w, --wait-ongoing-requests-after-deadline
          When the duration is reached, ongoing requests are waited
  -q <QUERY_PER_SECOND>
          Rate limit for all, in queries per second (QPS)
      --burst-delay <BURST_DURATION>
          Introduce delay between a predefined number of requests.
          Note: If qps is specified, burst will be ignored
      --burst-rate <BURST_REQUESTS>
          Rates of requests for burst. Default is 1
          Note: If qps is specified, burst will be ignored
      --rand-regex-url
          Generate URL by rand_regex crate but dot is disabled for each query e.g. http://127.0.0.1/[a-z][a-z][0-9]. Currently dynamic scheme, host and port with keep-alive do not work well. See https://docs.rs/rand_regex/latest/rand_regex/struct.Regex.html for details of syntax.
      --urls-from-file
          Read the URLs to query from a file
      --max-repeat <MAX_REPEAT>
          A parameter for the '--rand-regex-url'. The max_repeat parameter gives the maximum extra repeat counts the x*, x+ and x{n,} operators will become. [default: 4]
      --dump-urls <DUMP_URLS>
          Dump target Urls <DUMP_URLS> times to debug --rand-regex-url
      --latency-correction
          Correct latency to avoid coordinated omission problem. It's ignored if -q is not set.
      --no-tui
          No realtime tui
      --fps <FPS>
          Frame per second for tui. [default: 16]
  -m, --method <METHOD>
          HTTP method [default: GET]
  -H <HEADERS>
          Custom HTTP header. Examples: -H "foo: bar"
      --proxy-header <PROXY_HEADERS>
          Custom Proxy HTTP header. Examples: --proxy-header "foo: bar"
  -t <TIMEOUT>
          Timeout for each request. Default to infinite.
      --connect-timeout <CONNECT_TIMEOUT>
          Timeout for establishing a new connection. Default to 5s. [default: 5s]
  -A <ACCEPT_HEADER>
          HTTP Accept Header.
  -d <BODY_STRING>
          HTTP request body.
  -D <BODY_PATH>
          HTTP request body from file.
  -Z <BODY_PATH_LINES>
          HTTP request body from file line by line.
  -F, --form <FORM>
          Specify HTTP multipart POST data (curl compatible). Examples: -F 'name=value' -F 'file=@path/to/file'
  -T <CONTENT_TYPE>
          Content-Type.
  -a <BASIC_AUTH>
          Basic authentication (username:password), or AWS credentials (access_key:secret_key)
      --aws-session <AWS_SESSION>
          AWS session token
      --aws-sigv4 <AWS_SIGV4>
          AWS SigV4 signing params (format: aws:amz:region:service)
  -x <PROXY>
          HTTP proxy
      --proxy-http-version <PROXY_HTTP_VERSION>
          HTTP version to connect to proxy. Available values 0.9, 1.0, 1.1, 2.
      --proxy-http2
          Use HTTP/2 to connect to proxy. Shorthand for --proxy-http-version=2
      --http-version <HTTP_VERSION>
          HTTP version. Available values 0.9, 1.0, 1.1, 2, 3
      --http2
          Use HTTP/2. Shorthand for --http-version=2
      --host <HOST>
          HTTP Host header
      --disable-compression
          Disable compression.
  -r, --redirect <REDIRECT>
          Limit for number of Redirect. Set 0 for no redirection. Redirection isn't supported for HTTP/2. [default: 10]
      --disable-keepalive
          Disable keep-alive, prevents re-use of TCP connections between different HTTP requests. This isn't supported for HTTP/2.
      --no-pre-lookup
          *Not* perform a DNS lookup at beginning to cache it
      --ipv6
          Lookup only ipv6.
      --ipv4
          Lookup only ipv4.
      --cacert <CACERT>
          (TLS) Use the specified certificate file to verify the peer. Native certificate store is used even if this argument is specified.
      --cert <CERT>
          (TLS) Use the specified client certificate file. --key must be also specified
      --key <KEY>
          (TLS) Use the specified client key file. --cert must be also specified
      --insecure
          Accept invalid certs.
      --connect-to <CONNECT_TO>
          Override DNS resolution and default port numbers with strings like 'example.org:443:localhost:8443'
          Note: if used several times for the same host:port:target_host:target_port, a random choice is made
      --no-color
          Disable the color scheme. [env: NO_COLOR=]
      --unix-socket <UNIX_SOCKET>
          Connect to a unix socket instead of the domain in the URL. Only for non-HTTPS URLs.
      --stats-success-breakdown
          Include a response status code successful or not successful breakdown for the time histogram and distribution statistics
      --db-url <DB_URL>
          Write succeeded requests to sqlite database url E.G test.db
      --debug
          Perform a single request and dump the request and response
  -o, --output <OUTPUT>
          Output file to write the results to. If not specified, results are written to stdout.
      --output-format <OUTPUT_FORMAT>
          Output format [default: text] [possible values: text, json, csv, quiet]
  -u, --time-unit <TIME_UNIT>
          Time unit to be used. If not specified, the time unit is determined automatically. This option affects only text format. [possible values: ns, us, ms, s, m, h]
  -h, --help
          Print help
  -V, --version
          Print version
"""

def parse_count(s):
    s = str(s).strip().lower()
    mult = 1
    if s.endswith("k"):
        mult, s = 1000, s[:-1]
    elif s.endswith("m"):
        mult, s = 1000000, s[:-1]
    return int(float(s) * mult)

def parse_duration(s):
    if not s:
        return None
    m = re.fullmatch(r"([0-9]*\.?[0-9]+)\s*(ns|us|µs|ms|s|m|h)?", str(s))
    if not m:
        raise ValueError("invalid duration")
    v = float(m.group(1)); u = m.group(2) or "s"
    return v * {"ns":1e-9, "us":1e-6, "µs":1e-6, "ms":1e-3, "s":1, "m":60, "h":3600}[u]

def fmt_time(sec, unit=None):
    if unit is None:
        if sec < 1e-6: unit = "ns"
        elif sec < 1e-3: unit = "us"
        elif sec < 1: unit = "ms"
        elif sec < 60: unit = "s"
        elif sec < 3600: unit = "m"
        else: unit = "h"
    scale = {"ns":1e9, "us":1e6, "ms":1e3, "s":1, "m":1/60, "h":1/3600}[unit]
    return f"{sec*scale:.4f} {unit}"

def percentile(vals, p):
    if not vals: return 0.0
    vals = sorted(vals)
    idx = max(0, min(len(vals)-1, math.ceil(len(vals)*p/100.0)-1))
    return vals[idx]

@dataclass
class Result:
    start: float
    dns: float
    dial: float
    response_delay: float
    duration: float
    size: int
    status: int = 0
    error: str = ""

def make_parser():
    p = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    p.add_argument("-n", default="200"); p.add_argument("-c", default="50")
    p.add_argument("-p", default="1"); p.add_argument("-z")
    p.add_argument("-w", "--wait-ongoing-requests-after-deadline", action="store_true")
    p.add_argument("-q", type=float); p.add_argument("--burst-delay")
    p.add_argument("--burst-rate", default="1"); p.add_argument("--rand-regex-url", action="store_true")
    p.add_argument("--urls-from-file", action="store_true"); p.add_argument("--max-repeat", default="4")
    p.add_argument("--dump-urls"); p.add_argument("--latency-correction", action="store_true")
    p.add_argument("--no-tui", action="store_true"); p.add_argument("--fps", default="16")
    p.add_argument("-m", "--method", default="GET"); p.add_argument("-H", dest="headers", action="append", default=[])
    p.add_argument("--proxy-header", action="append", default=[]); p.add_argument("-t", "--timeout")
    p.add_argument("--connect-timeout", default="5s"); p.add_argument("-A", dest="accept")
    p.add_argument("-d", dest="body_string"); p.add_argument("-D", dest="body_path")
    p.add_argument("-Z", dest="body_path_lines"); p.add_argument("-F", "--form", action="append", default=[])
    p.add_argument("-T", dest="content_type"); p.add_argument("-a", dest="basic_auth")
    p.add_argument("--aws-session"); p.add_argument("--aws-sigv4")
    p.add_argument("-x", dest="proxy"); p.add_argument("--proxy-http-version"); p.add_argument("--proxy-http2", action="store_true")
    p.add_argument("--http-version"); p.add_argument("--http2", action="store_true"); p.add_argument("--host")
    p.add_argument("--disable-compression", action="store_true"); p.add_argument("-r", "--redirect", default="10")
    p.add_argument("--disable-keepalive", action="store_true"); p.add_argument("--no-pre-lookup", action="store_true")
    p.add_argument("--ipv6", action="store_true"); p.add_argument("--ipv4", action="store_true")
    p.add_argument("--cacert"); p.add_argument("--cert"); p.add_argument("--key"); p.add_argument("--insecure", action="store_true")
    p.add_argument("--connect-to", action="append", default=[]); p.add_argument("--no-color", action="store_true")
    p.add_argument("--unix-socket"); p.add_argument("--stats-success-breakdown", action="store_true")
    p.add_argument("--db-url"); p.add_argument("--debug", action="store_true")
    p.add_argument("-o", "--output"); p.add_argument("--output-format", default="text", choices=["text","json","csv","quiet"])
    p.add_argument("-u", "--time-unit", choices=["ns","us","ms","s","m","h"])
    p.add_argument("url", nargs="?")
    return p

def header_dict(args):
    h = {"Accept": args.accept or "*/*", "Accept-Encoding": "gzip, compress, deflate, br", "User-Agent": "oha/1.12.1"}
    for item in args.headers:
        if ":" in item:
            k, v = item.split(":", 1); h[k.strip()] = v.strip()
    if args.host: h["Host"] = args.host
    if args.content_type: h["Content-Type"] = args.content_type
    if args.basic_auth:
        h["Authorization"] = "Basic " + base64.b64encode(args.basic_auth.encode()).decode()
    if args.disable_keepalive:
        h["Connection"] = "close"
    return h

def body_for(args):
    if args.body_string is not None:
        return args.body_string.encode()
    if args.body_path:
        with open(args.body_path, "rb") as f: return f.read()
    if args.form:
        parts = []
        for f in args.form:
            if "=" in f:
                parts.append(f)
        return "&".join(parts).encode()
    return None

def gen_regex_url(pat, max_repeat=4):
    def repl_class(m):
        s = m.group(1)
        if s == "a-z": return chr(random.randint(97,122))
        if s == "0-9": return chr(random.randint(48,57))
        return random.choice(s.replace("-", ""))
    out = re.sub(r"\[([^\]]+)\]", repl_class, pat)
    out = re.sub(r"\\d", lambda m: str(random.randint(0,9)), out)
    return out

def get_urls(args):
    if not args.url:
        return []
    if args.urls_from_file:
        with open(args.url) as f:
            return [line.strip() for line in f if line.strip()]
    return [args.url]

def request_once(url, args, base, body, headers):
    start_abs = time.perf_counter()
    start = start_abs - base
    dns_t = dial_t = resp_delay = 0.0
    size = status = 0
    err = ""
    try:
        u = urlparse(url)
        if u.scheme not in ("http", "https"):
            raise ValueError("invalid URL")
        port = u.port or (443 if u.scheme == "https" else 80)
        host = u.hostname or ""
        t0 = time.perf_counter()
        socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM)
        dns_t = time.perf_counter() - t0
        timeout = parse_duration(args.timeout) if args.timeout else None
        path = (u.path or "/") + (("?" + u.query) if u.query else "")
        conn_cls = HTTPSConnection if u.scheme == "https" else HTTPConnection
        context = None
        redirects = max(0, parse_count(args.redirect))
        current = url
        for attempt in range(redirects + 1):
            u = urlparse(current)
            port = u.port or (443 if u.scheme == "https" else 80)
            host = u.hostname or ""
            path = (u.path or "/") + (("?" + u.query) if u.query else "")
            conn_cls = HTTPSConnection if u.scheme == "https" else HTTPConnection
            if u.scheme == "https":
                context = ssl._create_unverified_context() if args.insecure else None
            t1 = time.perf_counter()
            if context is not None:
                conn = conn_cls(host, port, timeout=timeout, context=context)
            else:
                conn = conn_cls(host, port, timeout=timeout)
            conn.connect()
            dial_t = time.perf_counter() - t1 + dns_t
            conn.putrequest(args.method.upper(), path, skip_accept_encoding=True, skip_host=bool(args.host))
            for k, v in headers.items():
                conn.putheader(k, v)
            if body is not None:
                conn.putheader("Content-Length", str(len(body)))
            conn.endheaders(body)
            t2 = time.perf_counter()
            resp = conn.getresponse()
            first = resp.read()
            resp_delay = time.perf_counter() - t2
            status = resp.status
            size = len(first)
            loc = resp.getheader("Location")
            conn.close()
            if status in (301, 302, 303, 307, 308) and loc and attempt < redirects:
                current = loc if "://" in loc else f"{u.scheme}://{u.netloc}{loc}"
                continue
            break
    except Exception as e:
        err = str(e) or e.__class__.__name__
    dur = time.perf_counter() - start_abs
    return Result(start, dns_t, dial_t, resp_delay, dur, size, status, err)

def debug(args):
    headers = header_dict(args); body = body_for(args)
    u = urlparse(args.url); path = (u.path or "/") + (("?" + u.query) if u.query else "")
    print("Request {")
    print(f"    method: {args.method.upper()},")
    print(f"    uri: {path},")
    print("    version: HTTP/1.1,")
    print("    headers: {")
    h2 = dict(headers); h2["host"] = args.host or u.netloc
    for k, v in h2.items():
        print(f'        "{k.lower()}": "{v}",')
    print("    },")
    if body:
        print("    body: Full {")
        print("        data: Some(")
        print(f'            b"{body.decode(errors="replace")}",')
        print("        ),")
        print("    },")
    else:
        print("    body: Empty,")
    print("}")
    res_body = b""; status = 0; rh = {}
    try:
        conn_cls = HTTPSConnection if u.scheme == "https" else HTTPConnection
        conn = conn_cls(u.hostname, u.port or (443 if u.scheme == "https" else 80), timeout=parse_duration(args.timeout) if args.timeout else None)
        conn.request(args.method.upper(), path, body=body, headers=headers)
        resp = conn.getresponse(); status = resp.status; rh = dict(resp.getheaders()); res_body = resp.read(); conn.close()
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr); return 1
    print("Response {")
    print(f"    status: {status},")
    print("    version: HTTP/1.1,")
    print("    headers: {")
    for k, v in rh.items():
        print(f'        "{k.lower()}": "{v}",')
    print("    },")
    try: btxt = res_body.decode()
    except Exception: btxt = repr(res_body)[2:-1]
    print(f'    body: b"{btxt}",')
    print("}")
    return 0

def run_load(args):
    urls = get_urls(args)
    if args.rand_regex_url and args.dump_urls:
        for _ in range(parse_count(args.dump_urls)):
            print(gen_regex_url(args.url, parse_count(args.max_repeat)))
        return []
    headers = header_dict(args); body = body_for(args)
    n = parse_count(args.n)
    conc = max(1, parse_count(args.c) * parse_count(args.p))
    duration = parse_duration(args.z) if args.z else None
    qps = args.q
    burst_delay = parse_duration(args.burst_delay) if args.burst_delay else None
    burst_rate = max(1, parse_count(args.burst_rate))
    q = Queue()
    start = time.perf_counter()
    if duration is None:
        for i in range(n): q.put(i)
    else:
        for i in range(max(n, 1000000)): q.put(i)
    results = []
    lock = threading.Lock()
    next_lock = threading.Lock()
    next_time = [start]
    counter = [0]
    def worker():
        while True:
            if duration is not None and time.perf_counter() - start >= duration:
                break
            try: q.get_nowait()
            except Empty: break
            with next_lock:
                now = time.perf_counter()
                delay = 0.0
                if qps:
                    delay = max(0.0, next_time[0] - now); next_time[0] = max(next_time[0], now) + 1.0 / qps
                elif burst_delay:
                    if counter[0] and counter[0] % burst_rate == 0:
                        next_time[0] = max(next_time[0], now) + burst_delay
                    delay = max(0.0, next_time[0] - now)
                counter[0] += 1
            if delay: time.sleep(delay)
            url = gen_regex_url(args.url, parse_count(args.max_repeat)) if args.rand_regex_url else random.choice(urls)
            r = request_once(url, args, start, body, headers)
            with lock: results.append(r)
            q.task_done()
    threads = [threading.Thread(target=worker, daemon=True) for _ in range(conc)]
    for t in threads: t.start()
    for t in threads: t.join()
    return results

def summarize(results, total_elapsed=None):
    durs = [r.duration for r in results]
    ok = [r for r in results if 200 <= r.status < 300 and not r.error]
    total = total_elapsed if total_elapsed is not None else ((max((r.start+r.duration for r in results), default=0.0)) or sum(durs))
    if total <= 0: total = sum(durs) or 0.0
    total_data = sum(r.size for r in results)
    avg = sum(durs)/len(durs) if durs else 0.0
    return {
        "successRate": len(ok)/len(results) if results else 0.0,
        "total": total,
        "slowest": max(durs) if durs else 0.0,
        "fastest": min(durs) if durs else 0.0,
        "average": avg,
        "requestsPerSec": len(results)/total if total else 0.0,
        "totalData": total_data,
        "sizePerRequest": int(total_data/len(results)) if results else 0,
        "sizePerSec": total_data/total if total else 0.0,
    }

def histogram(vals):
    if not vals: return {"0": 0}
    lo, hi = min(vals), max(vals)
    if lo == hi:
        step = max(lo * 1e-12, 1e-12)
        out = {}
        for i in range(11):
            out[str(lo + step * i)] = len(vals) if i == 0 else 0
        return out
    out = {}
    step = (hi-lo)/10
    for i in range(11):
        key = lo + step*i
        if i == 0:
            cnt = sum(1 for v in vals if v <= key)
        elif i == 10:
            cnt = sum(1 for v in vals if lo+step*(i-1) < v <= key)
        else:
            cnt = sum(1 for v in vals if lo+step*(i-1) < v <= key)
        out[str(key)] = cnt
    return out

def output_json(results, fp):
    summ = summarize(results)
    durs = [r.duration for r in results]
    statuses = {}
    errors = {}
    for r in results:
        if r.status: statuses[str(r.status)] = statuses.get(str(r.status), 0) + 1
        if r.error: errors[r.error] = errors.get(r.error, 0) + 1
    dnsd = [r.dial for r in results if r.dial]
    dnsl = [r.dns for r in results if r.dns]
    def det(v): return {"average": sum(v)/len(v) if v else 0.0, "fastest": min(v) if v else 0.0, "slowest": max(v) if v else 0.0}
    pcts = {"p10":10,"p25":25,"p50":50,"p75":75,"p90":90,"p95":95,"p99":99,"p99.9":99.9,"p99.99":99.99}
    rps_vals = [1/r.duration for r in results if r.duration > 0]
    mean = sum(rps_vals)/len(rps_vals) if rps_vals else 0.0
    std = (sum((x-mean)**2 for x in rps_vals)/len(rps_vals))**0.5 if rps_vals else 0.0
    obj = {"summary": summ, "responseTimeHistogram": histogram(durs),
           "latencyPercentiles": {k: percentile(durs,v) for k,v in pcts.items()},
           "rps": {"mean": mean, "stddev": std, "max": max(rps_vals) if rps_vals else 0.0, "min": min(rps_vals) if rps_vals else 0.0,
                   "percentiles": {k: percentile(rps_vals,v) for k,v in pcts.items()}},
           "details": {"DNSDialup": det(dnsd), "DNSLookup": det(dnsl)},
           "statusCodeDistribution": statuses, "errorDistribution": errors}
    json.dump(obj, fp, indent=2); fp.write("\n")

def output_csv(results, fp):
    w = csv.writer(fp, lineterminator="\n")
    w.writerow(["request-start","DNS","DNS+dialup","Response-delay","request-duration","bytes","status"])
    for r in results:
        w.writerow([f"{r.start:.9g}", f"{r.dns:.9g}", f"{r.dial:.9g}", f"{r.response_delay:.9g}", f"{r.duration:.9g}", r.size, r.status or r.error])

def output_text(results, fp, unit=None):
    s = summarize(results)
    print("Summary:", file=fp)
    print(f"  Success rate:\t{s['successRate']*100:.2f}%", file=fp)
    for label, key in [("Total","total"),("Slowest","slowest"),("Fastest","fastest"),("Average","average")]:
        print(f"  {label}:\t{fmt_time(s[key], unit)}", file=fp)
    print(f"  Requests/sec:\t{s['requestsPerSec']:.4f}", file=fp)
    print("", file=fp)
    print(f"  Total data:\t{s['totalData']} B", file=fp)
    print(f"  Size/request:\t{s['sizePerRequest']} B", file=fp)
    print(f"  Size/sec:\t{int(s['sizePerSec'])} B", file=fp)
    print("\nResponse time histogram:", file=fp)
    h = histogram([r.duration for r in results]); maxc = max(h.values()) if h else 0
    for k, c in h.items():
        bar = "■" * (32*c//maxc) if maxc else ""
        print(f"  {fmt_time(float(k), unit):>12} [{c}] |{bar}", file=fp)
    print("\nResponse time distribution:", file=fp)
    d = [r.duration for r in results]
    for p in [10,25,50,75,90,95,99,99.9,99.99]:
        print(f"  {p:.2f}% in {fmt_time(percentile(d,p), unit)}", file=fp)
    dnsd = [r.dial for r in results if r.dial]; dnsl = [r.dns for r in results if r.dns]
    def detail(name, vals):
        if vals:
            print(f"  {name}:\t{fmt_time(sum(vals)/len(vals), unit)}, {fmt_time(min(vals), unit)}, {fmt_time(max(vals), unit)}", file=fp)
    print("\n\nDetails (average, fastest, slowest):", file=fp)
    detail("DNS+dialup", dnsd); detail("DNS-lookup", dnsl)
    statuses = {}
    errors = {}
    for r in results:
        if r.status: statuses[r.status] = statuses.get(r.status,0)+1
        if r.error: errors[r.error] = errors.get(r.error,0)+1
    if statuses:
        print("\nStatus code distribution:", file=fp)
        for k in sorted(statuses): print(f"  [{k}] {statuses[k]} responses", file=fp)
    if errors:
        print("\nError distribution:", file=fp)
        for k,v in errors.items(): print(f"  [{v}] {k}", file=fp)

def main(argv):
    if any(a in ("-h","--help") for a in argv) or not argv:
        print(HELP, end=""); return 0
    if any(a in ("-V","--version") for a in argv):
        print(VERSION); return 0
    parser = make_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as e:
        return int(e.code)
    if not args.url:
        print(HELP, end=""); return 0
    if args.debug:
        return debug(args)
    t0 = time.perf_counter()
    results = run_load(args)
    elapsed = time.perf_counter() - t0
    if args.output_format == "quiet":
        return 0
    fp = open(args.output, "w", newline="") if args.output else sys.stdout
    try:
        if args.output_format == "json": output_json(results, fp)
        elif args.output_format == "csv": output_csv(results, fp)
        else: output_text(results, fp, args.time_unit)
    finally:
        if args.output: fp.close()
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
