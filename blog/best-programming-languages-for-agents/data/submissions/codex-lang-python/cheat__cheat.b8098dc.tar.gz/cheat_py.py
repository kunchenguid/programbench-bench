#!/usr/bin/env python3
import argparse
import fnmatch
import glob
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

VERSION = "5.1.0"


def eprint(*args):
    print(*args, file=sys.stderr)


def parse_list(value):
    value = value.strip()
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        if not inner:
            return []
        return [x.strip().strip("'\"") for x in inner.split(",") if x.strip()]
    return [value.strip().strip("'\"")] if value else []


def scalar(value):
    value = value.strip()
    if value in ("true", "True"):
        return True
    if value in ("false", "False"):
        return False
    if value in ("[]", ""):
        return [] if value == "[]" else ""
    if value.startswith("["):
        return parse_list(value)
    return os.path.expandvars(value.strip("'\""))


def parse_config(path):
    cfg = {"cheatpaths": []}
    current = None
    in_cheatpaths = False
    for raw in Path(path).read_text(errors="ignore").splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        stripped = line.strip()
        if stripped == "---":
            continue
        if not raw.startswith(" ") and ":" in stripped:
            key, val = stripped.split(":", 1)
            key = key.strip()
            if key == "cheatpaths":
                in_cheatpaths = True
                continue
            in_cheatpaths = False
            cfg[key] = scalar(val)
            continue
        if in_cheatpaths:
            s = stripped
            if s.startswith("- "):
                if current:
                    cfg["cheatpaths"].append(current)
                current = {}
                s = s[2:].strip()
                if s and ":" in s:
                    k, v = s.split(":", 1)
                    current[k.strip()] = scalar(v)
            elif current is not None and ":" in s:
                k, v = s.split(":", 1)
                current[k.strip()] = scalar(v)
    if current:
        cfg["cheatpaths"].append(current)
    return cfg


def config_candidates():
    if os.environ.get("CHEAT_CONFIG_PATH"):
        return [Path(os.environ["CHEAT_CONFIG_PATH"])]
    home = Path(os.environ.get("HOME", "~")).expanduser()
    xdg = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config")).expanduser()
    return [
        xdg / "cheat" / "conf.yml",
        home / ".config" / "cheat" / "conf.yml",
        home / ".cheat" / "conf.yml",
        Path("/etc/cheat/conf.yml"),
    ]


def find_config():
    for p in config_candidates():
        if p.exists():
            return p
    return None


def prompt_missing_config():
    sys.stderr.write("A config file was not found. Would you like to create one now? [Y/n]: ")
    sys.stderr.flush()
    try:
        ans = sys.stdin.readline()
    except Exception:
        ans = ""
    if not ans:
        eprint("failed to create config: failed to prompt: EOF")
        return 1
    return 1


def default_config():
    home = Path(os.environ.get("HOME", "~")).expanduser()
    return f"""---
# The editor to use with 'cheat -e <sheet>'. Overridden by $VISUAL or $EDITOR.
editor: EDITOR_PATH

# Should 'cheat' always colorize output?
colorize: false

# Which 'chroma' colorscheme should be applied to the output?
style: monokai

# Which 'chroma' "formatter" should be applied?
formatter: terminal256

# Through which pager should output be piped?
pager: /usr/bin/pager

cheatpaths:

  # Cheatsheets that are tagged "personal" are stored here by default:
  - name: personal
    path: {home}/.config/cheat/cheatsheets/personal
    tags: [ personal ]
    readonly: false

  # Cheatsheets that are tagged "work" are stored here by default:
  - name: work
    path: {home}/.config/cheat/cheatsheets/work
    tags: [ work ]
    readonly: false
"""


def load_config(required=True):
    path = find_config()
    if not path:
        if required:
            sys.exit(prompt_missing_config())
        return None, None
    cfg = parse_config(path)
    editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or cfg.get("editor")
    if not editor or editor == "EDITOR_PATH":
        eprint("failed to load config: no editor set")
        sys.exit(1)
    cfg["editor"] = editor
    return cfg, path


def expand_path(p):
    return Path(os.path.expandvars(os.path.expanduser(str(p))))


def dot_cheat_path():
    cur = Path.cwd().resolve()
    for p in [cur] + list(cur.parents):
        d = p / ".cheat"
        if d.is_dir():
            return {"name": "", "path": str(d), "tags": [], "readonly": False}
    return None


def configured_paths(cfg):
    paths = []
    for cp in cfg.get("cheatpaths", []):
        base = str(cp.get("path", ""))
        expanded = [Path(p) for p in sorted(glob.glob(os.path.expanduser(base), recursive=True))] if any(x in base for x in "*?[") else []
        if expanded:
            for p in expanded:
                item = dict(cp)
                item["path"] = str(p)
                paths.append(item)
        else:
            paths.append(cp)
    dot = dot_cheat_path()
    if dot:
        paths.append(dot)
    return paths


def frontmatter(text):
    tags = []
    syntax = None
    body = text
    if text.startswith("---\n"):
        end = text.find("\n---", 4)
        if end != -1:
            head = text[4:end].strip().splitlines()
            rest_start = end + 4
            if rest_start < len(text) and text[rest_start] == "\n":
                rest_start += 1
            body = text[rest_start:]
            for line in head:
                if ":" in line:
                    k, v = line.split(":", 1)
                    if k.strip() == "tags":
                        tags = parse_list(v)
                    elif k.strip() == "syntax":
                        syntax = v.strip()
    return tags, syntax, body


def is_sheet(path):
    name = path.name
    if name.startswith(".") or name.endswith(".md") or path.is_dir():
        return False
    return True


def rel_title(root, path):
    return str(path.relative_to(root)).replace(os.sep, "/")


def scan(cfg, path_filter=None, tag_filter=None, title_filter=None):
    sheets = []
    cps = configured_paths(cfg)
    names = [cp.get("name", "") for cp in cps]
    if path_filter and path_filter not in names:
        eprint(f"invalid option --path: cheatpath does not exist: {path_filter}")
        sys.exit(1)
    for cp in cps:
        if path_filter and cp.get("name", "") != path_filter:
            continue
        root = expand_path(cp.get("path", ""))
        if not root.is_dir():
            continue
        for path in sorted(root.rglob("*")):
            if not is_sheet(path):
                continue
            title = rel_title(root, path)
            text = path.read_text(errors="ignore")
            fm_tags, syntax, body = frontmatter(text)
            tags = sorted(set(parse_list(str(cp.get("tags", []))) if isinstance(cp.get("tags"), str) else cp.get("tags", [])).union(fm_tags))
            item = {
                "title": title,
                "file": str(path),
                "tags": tags,
                "body": body,
                "path_name": cp.get("name", ""),
                "readonly": bool(cp.get("readonly", False)),
                "root": root,
                "syntax": syntax,
            }
            if tag_filter and tag_filter not in tags:
                continue
            if title_filter and title_filter not in title:
                continue
            sheets.append(item)
    return sorted(sheets, key=lambda s: s["title"])


def table(rows, headers):
    if not rows:
        return
    widths = []
    allrows = [headers] + rows
    for i in range(len(headers)):
        widths.append(max(len(r[i]) for r in allrows))
    for r in allrows:
        print(" ".join(r[i].ljust(widths[i]) for i in range(len(r))).rstrip())


def list_sheets(cfg, brief=False, **kw):
    rows = []
    for s in scan(cfg, **kw):
        tagstr = ",".join(s["tags"])
        if brief:
            rows.append([s["title"], tagstr])
        else:
            rows.append([s["title"], s["file"], tagstr])
    if not rows:
        return 2 if kw.get("tag_filter") or kw.get("title_filter") else 0
    table(rows, ["title:", "tags:"] if brief else ["title:", "file:", "tags:"])
    return 0


def select_sheets(cfg, title, path_filter=None, tag_filter=None, all_paths=False):
    matches = [s for s in scan(cfg, path_filter, tag_filter) if s["title"] == title]
    if all_paths:
        return matches
    if matches:
        return [matches[-1]]
    return []


def view_sheet(cfg, title, args):
    matches = select_sheets(cfg, title, args.path, args.tag, args.all)
    if not matches:
        eprint(f"No cheatsheet found for '{title}'.")
        return 2
    if args.all:
        for i, s in enumerate(matches):
            if i:
                print()
            print(f"{s['title']} ({s['path_name']})")
            for line in s["body"].splitlines():
                print("\t" + line)
        return 0
    sys.stdout.write(matches[0]["body"])
    if matches[0]["body"] and not matches[0]["body"].endswith("\n"):
        print()
    return 0


def directories(cfg):
    cps = configured_paths(cfg)
    width = max([len(str(cp.get("name", ""))) for cp in cps] + [0])
    for cp in cps:
        name = str(cp.get("name", ""))
        print(f"{name}:{' ' * (width - len(name) + 1)}{expand_path(cp.get('path',''))}")
    return 0


def tags(cfg):
    alltags = sorted({t for s in scan(cfg) for t in s["tags"]})
    for t in alltags:
        print(t)
    return 0


def search(cfg, phrase, regex=False, color=False, **kw):
    try:
        rx = re.compile(phrase) if regex else None
    except re.error as ex:
        eprint(str(ex))
        return 1
    found = False
    for s in scan(cfg, kw.get("path_filter"), kw.get("tag_filter")):
        lines = s["body"].splitlines()
        matched = []
        for line in lines:
            ok = bool(rx.search(line)) if rx else phrase.lower() in line.lower()
            if ok:
                matched = lines
                break
        if matched:
            found = True
            print(f"{s['title']} ({s['path_name']})")
            for line in matched:
                print("\t" + line)
    return 0


def writable_path(cfg, name=None):
    cps = configured_paths(cfg)
    if name:
        cps = [cp for cp in cps if cp.get("name", "") == name]
    for cp in reversed(cps):
        if not bool(cp.get("readonly", False)):
            return expand_path(cp.get("path", ""))
    return None


def edit_sheet(cfg, title, path_name=None):
    existing = select_sheets(cfg, title, path_name, None, False)
    target = None
    if existing and not existing[0]["readonly"]:
        target = Path(existing[0]["file"])
    else:
        root = writable_path(cfg, path_name)
        if root is None:
            eprint("no writeable cheatpaths available")
            return 1
        target = root / title
        if existing and not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(existing[0]["file"], target)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.touch(exist_ok=True)
    return subprocess.call([cfg["editor"], str(target)])


def remove_sheet(cfg, title, path_name=None):
    matches = select_sheets(cfg, title, path_name, None, False)
    if not matches:
        eprint(f"No cheatsheet found for '{title}'.")
        return 2
    try:
        Path(matches[0]["file"]).unlink()
    except OSError as ex:
        eprint(str(ex))
        return 1
    return 0


def update(cfg, path_name=None):
    status = 0
    for cp in configured_paths(cfg):
        if path_name and cp.get("name", "") != path_name:
            continue
        root = expand_path(cp.get("path", ""))
        if (root / ".git").is_dir():
            status = subprocess.call(["git", "-C", str(root), "pull"]) or status
    return status


def completion(shell):
    if shell not in ("bash", "zsh", "fish", "powershell"):
        eprint(f"unsupported shell: {shell} (valid: bash, zsh, fish, powershell)")
        return 1
    if shell == "bash":
        print("# bash completion V2 for cheat                                -*- shell-script -*-")
        print("_cheat() { COMPREPLY=(); }")
        print("complete -F _cheat cheat")
    elif shell == "zsh":
        print("#compdef cheat\n_arguments '*: :->args'")
    elif shell == "fish":
        print("complete -c cheat -f")
    else:
        print("Register-ArgumentCompleter -CommandName cheat -ScriptBlock { }")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(
        prog="cheat",
        add_help=False,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="cheat allows you to create and view interactive cheatsheets on the\ncommand-line. It was designed to help remind *nix system administrators of\noptions for commands that they use frequently, but not frequently enough to\nremember.",
    )
    p.add_argument("cheatsheet", nargs="?")
    p.add_argument("-a", "--all", action="store_true")
    p.add_argument("-b", "--brief", action="store_true")
    p.add_argument("-c", "--colorize", action="store_true")
    p.add_argument("--completion")
    p.add_argument("--conf", action="store_true")
    p.add_argument("-d", "--directories", action="store_true")
    p.add_argument("-e", "--edit")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("--init", action="store_true")
    p.add_argument("-l", "--list", action="store_true")
    p.add_argument("-p", "--path")
    p.add_argument("-r", "--regex", action="store_true")
    p.add_argument("--rm")
    p.add_argument("-s", "--search")
    p.add_argument("-t", "--tag")
    p.add_argument("-T", "--tags", action="store_true")
    p.add_argument("-u", "--update", action="store_true")
    p.add_argument("-v", "--version", action="store_true")
    args, unknown = p.parse_known_args(argv)
    if unknown:
        eprint(f"unknown flag: {unknown[0]}")
        return 1
    if args.help:
        subprocess.run(["/bin/echo", HELP_TEXT.rstrip()])
        return 0
    if args.version:
        print(VERSION)
        return 0
    if args.init:
        print(default_config(), end="")
        return 0
    if args.completion:
        return completion(args.completion)
    if args.conf:
        path = find_config()
        if not path:
            return prompt_missing_config()
        print(path)
        return 0
    cfg, _ = load_config()
    title_filter = args.cheatsheet
    if args.directories:
        return directories(cfg)
    if args.tags:
        return tags(cfg)
    if args.list:
        return list_sheets(cfg, False, path_filter=args.path, tag_filter=args.tag, title_filter=title_filter)
    if args.brief:
        return list_sheets(cfg, True, path_filter=args.path, tag_filter=args.tag, title_filter=title_filter)
    if args.search is not None:
        return search(cfg, args.search, args.regex, args.colorize, path_filter=args.path, tag_filter=args.tag)
    if args.edit:
        return edit_sheet(cfg, args.edit, args.path)
    if args.rm:
        return remove_sheet(cfg, args.rm, args.path)
    if args.update:
        return update(cfg, args.path)
    if args.cheatsheet:
        return view_sheet(cfg, args.cheatsheet, args)
    return prompt_missing_config() if not find_config() else 0


HELP_TEXT = """cheat allows you to create and view interactive cheatsheets on the
command-line. It was designed to help remind *nix system administrators of
options for commands that they use frequently, but not frequently enough to
remember.

Usage:
  cheat [cheatsheet] [flags]

Flags:
  -a, --all                Search among all cheatpaths
  -b, --brief              List cheatsheets without file paths
  -c, --colorize           Colorize output
      --completion shell   Generate shell completion script (shell: bash, zsh, fish, powershell)
      --conf               Display the config file path
  -d, --directories        List cheatsheet directories
  -e, --edit cheatsheet    Edit cheatsheet
  -h, --help               help for cheat
      --init               Write a default config file to stdout
  -l, --list               List cheatsheets
  -p, --path name          Return only sheets found on cheatpath name
  -r, --regex              Treat search <phrase> as a regex
      --rm cheatsheet      Remove (delete) cheatsheet
  -s, --search phrase      Search cheatsheets for phrase
  -t, --tag tag            Return only sheets matching tag
  -T, --tags               List all tags in use
  -u, --update             Update git-backed cheatpaths
  -v, --version            Print the version number"""


if __name__ == "__main__":
    sys.exit(main())
