#!/usr/bin/env python3
import configparser
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path

VERSION = "handlr 0.6.4"


def eprint(s=""):
    print(s, file=sys.stderr)


def xdg_config_home():
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")


def xdg_data_home():
    return Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")


def xdg_data_dirs():
    val = os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share"
    return [Path(p) for p in val.split(":") if p]


def ensure_files():
    cfg = xdg_config_home()
    (cfg / "handlr").mkdir(parents=True, exist_ok=True)
    htoml = cfg / "handlr" / "handlr.toml"
    if not htoml.exists():
        htoml.write_text('enable_selector = false\nselector = "rofi -dmenu -i -p \'Open With: \'"\n')
    mimeapps = cfg / "mimeapps.list"
    if not mimeapps.exists():
        mimeapps.parent.mkdir(parents=True, exist_ok=True)
        mimeapps.write_text("")
    return mimeapps


def app_dirs():
    dirs = [xdg_data_home() / "applications"]
    dirs += [d / "applications" for d in xdg_data_dirs()]
    return dirs


def find_desktop(handler):
    name = handler
    if not name.endswith(".desktop"):
        name += ".desktop"
    for d in app_dirs():
        p = d / name
        if p.exists():
            return p, name
    return None, name


def parse_desktop(path):
    data = {}
    try:
        for line in Path(path).read_text(errors="replace").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                if k not in data:
                    data[k] = v
    except OSError:
        pass
    return data


def all_desktops():
    seen = set()
    for d in app_dirs():
        if not d.is_dir():
            continue
        for p in sorted(d.glob("*.desktop")):
            if p.name in seen:
                continue
            seen.add(p.name)
            yield p.name, p, parse_desktop(p)


def mime_from_ext(ext):
    ext = ext.lower()
    patterns = []
    for base in [xdg_data_home()] + xdg_data_dirs():
        for rel in ("mime/globs2", "mime/globs"):
            p = base / rel
            if not p.exists():
                continue
            try:
                patterns += p.read_text(errors="replace").splitlines()
            except OSError:
                pass
    for line in patterns:
        if not line or line.startswith("#"):
            continue
        parts = line.split(":")
        if len(parts) == 3:
            _, mt, glob = parts
        elif len(parts) == 2:
            mt, glob = parts
        else:
            continue
        if glob.lower() == "*" + ext:
            return mt
    return None


def read_mimeapps():
    path = ensure_files()
    sections = {}
    cur = None
    try:
        lines = path.read_text(errors="replace").splitlines()
    except OSError:
        lines = []
    for line in lines:
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            cur = s[1:-1]
            sections.setdefault(cur, {})
        elif cur and s and not s.startswith("#") and "=" in s:
            k, v = s.split("=", 1)
            sections.setdefault(cur, {})[k.strip()] = [x for x in v.split(";") if x]
    sections.setdefault("Added Associations", {})
    sections.setdefault("Default Applications", {})
    return sections


def write_mimeapps(sections):
    path = ensure_files()
    order = ["Added Associations", "Default Applications"]
    out = []
    for sec in order:
        out.append(f"[{sec}]")
        for k in sorted(sections.get(sec, {})):
            vals = sections[sec][k]
            if vals:
                out.append(f"{k}={';'.join(vals)};")
        out.append("")
    path.write_text("\n".join(out))


def mime_error(msg):
    eprint(f"error: Invalid value for '<mime>': {msg}")
    eprint()
    eprint("For more information try --help")
    return 2


def handler_error(handler):
    eprint(f"error: Invalid value for '<handler>': no handlers found for '{handler}'")
    eprint()
    eprint("For more information try --help")
    return 2


def malformed_handler_error(path):
    eprint(f"error: Invalid value for '<handler>': malformed desktop entry at {path}")
    eprint()
    eprint("For more information try --help")
    return 2


def missing_error(cmd, missing):
    eprint("error: The following required arguments were not provided:")
    for m in missing:
        eprint(f"    <{m}>")
    usage = {
        "set": "executable set <mime> <handler>",
        "add": "executable add <mime> <handler>",
        "unset": "executable unset <mime>",
        "get": "executable get [FLAGS] <mime>",
        "launch": "executable launch <mime> [args]...",
        "open": "executable open <paths>...",
    }[cmd]
    eprint()
    eprint("USAGE:")
    eprint(f"    {usage}")
    eprint()
    eprint("For more information try --help")
    return 2


def unexpected_error(arg, usage):
    eprint(f"error: Found argument '{arg}' which wasn't expected, or isn't valid in this context")
    eprint()
    eprint(f"If you tried to supply `{arg}` as a PATTERN use `-- {arg}`")
    eprint()
    eprint("USAGE:")
    eprint(f"    {usage}")
    eprint()
    eprint("For more information try --help")
    return 2


def normalize_mime(arg, allow_paths=False):
    a = arg.strip()
    if a.startswith("."):
        mt = mime_from_ext(a)
        if not mt:
            raise ValueError(f"could not figure out the mime type of '{a}'")
        return mt
    if allow_paths:
        if "://" in a:
            scheme = a.split(":", 1)[0]
            if scheme:
                return f"x-scheme-handler/{scheme}"
        suffix = Path(a).suffix
        if suffix:
            mt = mime_from_ext(suffix)
            if mt:
                return mt
    if "/" not in a:
        raise ValueError("mime parse error: a slash (/) was missing between the type and subtype")
    bad = None
    for i, ch in enumerate(a):
        ok = ch.isalnum() or ch in "!#$&^_.+-*/"
        if not ok:
            bad = (i, ch)
            break
    if bad:
        i, ch = bad
        raise ValueError(f"mime parse error: an invalid token was encountered, {ord(ch):02X} at position {i}")
    return a


def get_handlers(mime):
    sec = read_mimeapps().get("Default Applications", {})
    if mime in sec and sec[mime]:
        return sec[mime]
    if "/" in mime:
        wildcard = mime.split("/", 1)[0] + "/*"
        if wildcard in sec and sec[wildcard]:
            return sec[wildcard]
    return []


def table(rows):
    if not rows:
        return "┌──┐\n│  │\n└──┘"
    w1 = max(len(str(a)) for a, _ in rows)
    w2 = max(len(str(b)) for _, b in rows)
    lines = ["┌" + "─" * (w1 + 2) + "┬" + "─" * (w2 + 2) + "┐"]
    for a, b in rows:
        lines.append("│ " + str(a).ljust(w1) + " │ " + str(b).ljust(w2) + " │")
    lines.append("└" + "─" * (w1 + 2) + "┴" + "─" * (w2 + 2) + "┘")
    return "\n".join(lines)


def help_main():
    print("""handlr 0.6.4

USAGE:
    executable <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    list      List default apps and the associated handlers
    open      Open a path/URL with its default handler
    set       Set the default handler for mime/extension
    unset     Unset the default handler for mime/extension
    launch    Launch the handler for specified extension/mime with optional arguments
    get       Get handler for this mime/extension
    add       Add a handler for given mime/extension Note that the first handler is the default""")


def help_sub(cmd):
    desc = {
        "list": ("List default apps and the associated handlers", "executable list [FLAGS]", "", "    -a, --all        \n    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "open": ("Open a path/URL with its default handler", "executable open <paths>...", "ARGS:\n    <paths>...    \n", "    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "set": ("Set the default handler for mime/extension", "executable set <mime> <handler>", "ARGS:\n    <mime>       \n    <handler>    \n", "    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "unset": ("Unset the default handler for mime/extension", "executable unset <mime>", "ARGS:\n    <mime>    \n", "    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "launch": ("Launch the handler for specified extension/mime with optional arguments", "executable launch <mime> [args]...", "ARGS:\n    <mime>       \n    <args>...    \n", "    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "get": ("Get handler for this mime/extension", "executable get [FLAGS] <mime>", "ARGS:\n    <mime>    \n", "        --json       \n    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "add": ("Add a handler for given mime/extension Note that the first handler is the default", "executable add <mime> <handler>", "ARGS:\n    <mime>       \n    <handler>    \n", "    -h, --help       Prints help information\n    -V, --version    Prints version information"),
    }[cmd]
    d, usage, args, flags = desc
    print(f"executable-{cmd} \n{d}\n\nUSAGE:\n    {usage}\n")
    if args:
        print(args, end="\n")
    print("FLAGS:\n" + flags)


def cmd_set(mime_arg, handler, append=False):
    try:
        mime = normalize_mime(mime_arg)
    except ValueError as ex:
        return mime_error(str(ex))
    path, hname = find_desktop(handler)
    if not path:
        return handler_error(handler)
    d = parse_desktop(path)
    if not d.get("Name") or not d.get("Exec"):
        return malformed_handler_error(path)
    data = read_mimeapps()
    vals = data["Default Applications"].setdefault(mime, [])
    if append:
        vals.append(hname)
    else:
        data["Default Applications"][mime] = [hname]
    write_mimeapps(data)
    return 0


def cmd_unset(mime_arg):
    try:
        mime = normalize_mime(mime_arg)
    except ValueError as ex:
        return mime_error(str(ex))
    data = read_mimeapps()
    data["Default Applications"].pop(mime, None)
    write_mimeapps(data)
    return 0


def cmd_get(args):
    as_json = False
    rest = []
    for a in args:
        if a == "--json":
            as_json = True
        else:
            rest.append(a)
    if len(rest) < 1:
        return missing_error("get", ["mime"])
    if len(rest) > 1:
        return unexpected_error(rest[1], "executable get [FLAGS] <mime>")
    try:
        mime = normalize_mime(rest[0])
    except ValueError as ex:
        return mime_error(str(ex))
    hs = get_handlers(mime)
    if not hs:
        return 1
    h = hs[0]
    if as_json:
        p, _ = find_desktop(h)
        d = parse_desktop(p) if p else {}
        exec_cmd = strip_exec_codes(d.get("Exec", ""))
        print(json.dumps({"handler": h, "name": d.get("Name", h), "cmd": exec_cmd}, separators=(",", ":")))
    else:
        print(h)
    return 0


def strip_exec_codes(s):
    out = []
    i = 0
    while i < len(s):
        if s[i] == "%" and i + 1 < len(s):
            code = s[i + 1]
            if code == "%":
                out.append("%")
            elif code in "fFuUdDnNickvm":
                pass
            else:
                pass
            i += 2
        else:
            out.append(s[i])
            i += 1
    return "".join(out).replace('"', "")


def expand_exec(s, args):
    if not s:
        return []
    try:
        parts = shlex.split(s)
    except ValueError:
        parts = s.split()
    repl = []
    used = False
    for part in parts:
        if "%" in part:
            new = part.replace("%f", args[0] if args else "")
            new = new.replace("%u", args[0] if args else "")
            if "%F" in new or "%U" in new:
                used = True
                for a in args:
                    repl.append(new.replace("%F", a).replace("%U", a))
                continue
            if new != part:
                used = True
            for code in ["%d", "%D", "%n", "%N", "%i", "%c", "%k", "%v", "%m"]:
                new = new.replace(code, "")
            new = new.replace("%%", "%")
            if new:
                repl.append(new)
        else:
            repl.append(part)
    if args and not used:
        repl.extend(args)
    return repl


def launch_for_mime(mime, args):
    hs = get_handlers(mime)
    if not hs:
        return 1
    p, _ = find_desktop(hs[0])
    d = parse_desktop(p) if p else {}
    cmd = expand_exec(d.get("Exec", ""), args)
    if not cmd:
        return 1
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        return 1
    return 0


def cmd_launch(args):
    if not args:
        return missing_error("launch", ["mime"])
    mime_arg = args[0]
    rest = args[1:]
    if rest and rest[0] == "--":
        rest = rest[1:]
    try:
        mime = normalize_mime(mime_arg)
    except ValueError as ex:
        return mime_error(str(ex))
    return launch_for_mime(mime, rest)


def cmd_open(args):
    if not args:
        return missing_error("open", ["paths"])
    status = 0
    for a in args:
        try:
            mime = normalize_mime(a, allow_paths=True)
        except ValueError:
            status = 1
            continue
        if launch_for_mime(mime, [a]) != 0:
            status = 1
    return status


def cmd_list(args):
    show_all = "-a" in args or "--all" in args
    data = read_mimeapps()
    defaults = [(k, ", ".join(v)) for k, v in sorted(data.get("Default Applications", {}).items()) if v]
    if show_all:
        print("Default Apps")
    print(table(defaults))
    if show_all:
        sysapps = []
        for h, p, d in all_desktops():
            for m in [x for x in d.get("MimeType", "").split(";") if x]:
                sysapps.append((m, h))
        print("System Apps")
        print(table(sorted(sysapps)))
    return 0


def clap_missing():
    help_main()
    return 2


def main(argv):
    if not argv:
        return clap_missing()
    if argv[0] in ("-h", "--help"):
        help_main()
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    cmd, args = argv[0], argv[1:]
    if cmd not in {"list", "open", "set", "unset", "launch", "get", "add"}:
        return unexpected_error(cmd, "executable <SUBCOMMAND>")
    if "-h" in args or "--help" in args:
        help_sub(cmd)
        return 0
    if "-V" in args or "--version" in args:
        print(VERSION)
        return 0
    if cmd == "list":
        extras = [a for a in args if a not in ("-a", "--all")]
        if extras:
            return unexpected_error(extras[0], "executable list [FLAGS]")
        return cmd_list(args)
    if cmd == "set":
        if len(args) < 2:
            return missing_error("set", ["mime", "handler"][len(args):])
        if len(args) > 2:
            return unexpected_error(args[2], "executable set <mime> <handler>")
        return cmd_set(args[0], args[1], append=False)
    if cmd == "add":
        if len(args) < 2:
            return missing_error("add", ["mime", "handler"][len(args):])
        if len(args) > 2:
            return unexpected_error(args[2], "executable add <mime> <handler>")
        return cmd_set(args[0], args[1], append=True)
    if cmd == "unset":
        if len(args) < 1:
            return missing_error("unset", ["mime"])
        if len(args) > 1:
            return unexpected_error(args[1], "executable unset <mime>")
        return cmd_unset(args[0])
    if cmd == "get":
        return cmd_get(args)
    if cmd == "launch":
        return cmd_launch(args)
    if cmd == "open":
        return cmd_open(args)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
