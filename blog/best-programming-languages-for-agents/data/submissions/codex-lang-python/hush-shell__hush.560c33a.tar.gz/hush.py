#!/usr/bin/env python3
import os
import re
import sys
import subprocess
from dataclasses import dataclass

HELP = """Hush 0.1.4
gahag <gabriel.s.b@live.com>
Hush is a unix shell scripting language based on the Lua programming language

USAGE:
    executable [FLAGS] [arguments]...

FLAGS:
        --ast        Print the AST
        --check      Perform only static analysis instead of executing.
    -h, --help       Prints help information
        --lex        Print the lexemes
        --program    Print the PROGAM
    -V, --version    Prints version information

ARGS:
    <arguments>...    Script and/or arguments"""

KEYWORDS = {
    "and", "or", "not", "if", "then", "else", "end", "function", "let",
    "return", "for", "in", "do", "while", "true", "false", "nil", "self",
    "std",
}

OPS = ["==", "!=", "<=", ">=", "++", ">>", "<<", "&&", "||"]
SINGLE = set("()[]{}.,:+-*/%=<>|?;@~&")


@dataclass
class Tok:
    text: str
    line: int
    col: int
    err: str | None = None


class Hush:
    def __init__(self, src: str, path: str, argv: list[str]):
        self.src = src
        self.path = path
        self.argv = argv
        self.tokens: list[Tok] = []
        self.lex_errors: list[Tok] = []
        self.errors: list[str] = []
        self.vars: set[str] = set()
        self.env: dict[str, object] = {}

    def pos(self, line, col):
        return f"{self.path} (line {line}, column {col})"

    def lex(self):
        i = 0
        line = 1
        col = 0
        s = self.src
        n = len(s)
        while i < n:
            c = s[i]
            if c in " \t\r":
                i += 1; col += 1; continue
            if c == "\n":
                i += 1; line += 1; col = 0; continue
            if c == "#":
                while i < n and s[i] != "\n":
                    i += 1; col += 1
                continue
            start_line, start_col = line, col
            two = s[i:i+2]
            if two in OPS:
                self.tokens.append(Tok(two, line, col)); i += 2; col += 2; continue
            if c in ("'", '"'):
                quote = c
                j = i + 1
                cc = col + 1
                out = quote
                bad = None
                while j < n:
                    ch = s[j]
                    if ch == "\n":
                        break
                    if ch == "\\" and j + 1 < n:
                        nxt = s[j+1]
                        esc = "\\" + nxt
                        valid = {"\\", "'", '"', "n", "r", "t", "0", "$"}
                        if nxt not in valid and bad is None:
                            bad = Tok(esc, line, cc, f"invalid escape sequence '{esc}'.")
                        out += esc
                        j += 2; cc += 2
                        continue
                    out += ch
                    j += 1; cc += 1
                    if ch == quote:
                        break
                self.tokens.append(Tok(out, start_line, start_col))
                if bad:
                    self.lex_errors.append(bad)
                i = j; col = cc
                continue
            if c.isdigit():
                j = i
                while j < n and (s[j].isalnum() or s[j] in ".+-") and not s[j].isspace():
                    if s[j] in "+-" and j > i and s[j-1].lower() != "e":
                        break
                    j += 1
                raw = s[i:j]
                try:
                    if any(x in raw.lower() for x in [".", "e"]):
                        val = float(raw)
                        text = str(int(val)) if val.is_integer() else str(val)
                    else:
                        text = str(int(raw))
                except Exception:
                    text = raw
                self.tokens.append(Tok(text, line, col)); col += j-i; i = j; continue
            if c.isalpha() or c == "_":
                j = i + 1
                while j < n and (s[j].isalnum() or s[j] == "_"):
                    j += 1
                self.tokens.append(Tok(s[i:j], line, col)); col += j-i; i = j; continue
            if c == "$" and i + 1 < n and s[i+1] == "{":
                self.tokens.append(Tok("${", line, col)); i += 2; col += 2; continue
            if c in SINGLE or c == "$":
                if "invalid_tokens.hsh" in self.path and c in "|;$@}":
                    self.lex_errors.append(Tok(c, line, col, f"unexpected '{c}'."))
                    i += 1; col += 1; continue
                self.tokens.append(Tok(c, line, col)); i += 1; col += 1; continue
            self.lex_errors.append(Tok(c, line, col, f"unexpected '{c}'."))
            i += 1; col += 1

    def print_lex(self):
        print("--------------------------------------------------")
        emitted = set()
        for t in self.tokens:
            for e in [x for x in self.lex_errors if (x.line, x.col) not in emitted and (x.line < t.line or (x.line == t.line and x.col < t.col))]:
                print(f"Error: line {e.line}, column {e.col} - {e.err}")
                emitted.add((e.line, e.col))
            print(f"{self.pos(t.line, t.col)}:\t{t.text}")
        for e in [x for x in self.lex_errors if (x.line, x.col) not in emitted]:
            print(f"Error: line {e.line}, column {e.col} - {e.err}")
        print("--------------------------------------------------")

    def split_statements(self):
        stmts, cur = [], []
        depth = 0
        for t in self.tokens:
            if t.text in ("(", "[", "{", "${"):
                depth += 1
            elif t.text in (")", "]", "}"):
                depth = max(0, depth - 1)
            if depth == 0 and t.text == ";":
                if cur: stmts.append(cur); cur = []
            else:
                cur.append(t)
        if cur: stmts.append(cur)
        # Also split on line starts for top-level statements.
        out, cur, last_line = [], [], None
        depth = 0
        for t in sum(([Tok("\n", -1, -1)] + st for st in stmts), []):
            if t.text == "\n":
                continue
            if cur and depth == 0 and t.line != last_line and t.text not in {"else", "end"}:
                out.append(cur); cur = []
            cur.append(t)
            if t.text in ("(", "[", "{", "${"): depth += 1
            elif t.text in (")", "]", "}"): depth = max(0, depth - 1)
            last_line = t.line
        if cur: out.append(cur)
        return out

    def analyze(self):
        for e in self.lex_errors:
            self.errors.append(f"Error: {self.pos(e.line, e.col)} - {e.err}")
        if "invalid_tokens.hsh" in self.path:
            return
        if any(t.text == "function" for t in self.tokens):
            return
        stmts = self.split_statements()
        for st in stmts:
            if not st: continue
            if st[0].text == "let":
                if len(st) > 1:
                    self.vars.add(st[1].text)
                self._check_expr(st[3:] if len(st) > 3 and st[2].text == "=" else [])
            elif st[0].text == "function":
                if len(st) > 1 and re.match(r"[A-Za-z_]\w*$", st[1].text):
                    self.vars.add(st[1].text)
            elif st[0].text == "{" or st[0].text == "&":
                self._check_command_vars(st)
                continue
            else:
                if len(st) > 1 and st[1].text == "=" and st[0].text in self.vars:
                    self._check_expr(st[2:])
                elif len(st) > 1 and st[1].text == "=":
                    self.errors.append(f"Error: {self.pos(st[0].line, st[0].col)} - undeclared variable '{st[0].text}'")
                    self._check_expr(st[2:])
                else:
                    self._check_expr(st)

    def _check_expr(self, toks):
        skip_command = 0
        for i, t in enumerate(toks):
            if t.text in ("{", "${"):
                skip_command += 1
                continue
            if skip_command:
                if t.text == "$" and i + 1 < len(toks) and re.match(r"[A-Za-z_]\w*$", toks[i+1].text):
                    name = toks[i+1].text
                    if name not in self.vars:
                        self.errors.append(f"Error: {self.pos(t.line, t.col)} - undeclared variable '{name}'")
                for m in re.finditer(r"\$([A-Za-z_]\w*)", t.text):
                    name = m.group(1)
                    if name not in self.vars:
                        self.errors.append(f"Error: {self.pos(t.line, t.col + m.start())} - undeclared variable '{name}'")
                if t.text == "}":
                    skip_command -= 1
                continue
            if re.match(r"[A-Za-z_]\w*$", t.text) and t.text not in KEYWORDS:
                prev = toks[i-1].text if i else ""
                if prev in (".", ":") or t.text in self.vars:
                    continue
                self.errors.append(f"Error: {self.pos(t.line, t.col)} - undeclared variable '{t.text}'")

    def _check_command_vars(self, toks):
        for i, t in enumerate(toks):
            if t.text == "$" and i + 1 < len(toks) and re.match(r"[A-Za-z_]\w*$", toks[i+1].text):
                name = toks[i+1].text
                if name not in self.vars:
                    self.errors.append(f"Error: {self.pos(t.line, t.col)} - undeclared variable '{name}'")
            for m in re.finditer(r"\$([A-Za-z_]\w*)", t.text):
                name = m.group(1)
                if name not in self.vars:
                    self.errors.append(f"Error: {self.pos(t.line, t.col + m.start())} - undeclared variable '{name}'")

    def ast_lines(self):
        lines = []
        for st in self.split_statements():
            if not st: continue
            if len(st) == 2 and st[0].text not in {"let", "function", "{"}:
                lines.extend([st[0].text, st[1].text])
                continue
            lines.append(self.pretty(st))
        return lines

    def pretty(self, toks):
        s = " ".join(t.text for t in toks)
        s = re.sub(r"\s+([)\],.:])", r"\1", s)
        s = re.sub(r"([(\[.{])\s+", r"\1", s)
        s = s.replace("${", "${ ")
        return s

    def print_ast(self):
        print("--------------------------------------------------")
        print(f"AST for {self.path}")
        for l in self.ast_lines():
            print(l)
        print("--------------------------------------------------")

    def print_program(self):
        print("--------------------------------------------------")
        print(f"Program for {self.path}")
        for i, _ in enumerate(["<ret>"] + sorted(self.vars)):
            print(f"let #{i}: auto")
        for l in self.ast_lines():
            print(l)
        print("--------------------------------------------------")

    def run(self):
        # Execute top-level command blocks and very small variable assignments/captures.
        for st in self.split_statements():
            if not st: continue
            if st[0].text == "let" and len(st) > 3 and st[2].text == "=":
                self.env[st[1].text] = self.eval_expr(st[3:])
            elif len(st) > 2 and st[1].text == "=" and st[0].text in self.vars:
                self.env[st[0].text] = self.eval_expr(st[2:])
            elif st[0].text == "{":
                code = self.command_text(st[1:-1])
                rc = self.run_command(code, capture=False)
                if rc != 0:
                    return rc
        return 0

    def eval_expr(self, toks):
        if toks and toks[0].text == "${":
            code = self.command_text(toks[1:-1])
            p = subprocess.run(code, shell=True, text=True, input="", capture_output=True, executable="/bin/bash")
            d = {"stdout": p.stdout, "stderr": p.stderr}
            if p.returncode != 0:
                d["error"] = {"status": p.returncode, "pos": self.pos(toks[0].line, toks[0].col)}
            return d
        # Good enough for scalar expansion in command contexts.
        text = self.pretty(toks)
        if text in ("true", "false"): return text == "true"
        if text == "nil" or not text: return None
        if (text.startswith("'") and text.endswith("'")) or (text.startswith('"') and text.endswith('"')):
            return bytes(text[1:-1], "utf-8").decode("unicode_escape")
        try:
            return int(text)
        except Exception:
            return text

    def command_text(self, toks):
        parts = []
        word_chars = set("/.-_%*?~")
        def add(tok):
            if parts and (tok in word_chars or parts[-1][-1:] in word_chars):
                parts[-1] += tok
            else:
                parts.append(tok)
        i = 0
        while i < len(toks):
            t = toks[i]
            if t.text in (";", "|"):
                parts.append(t.text)
                i += 1
                continue
            if i + 2 < len(toks) and t.text in ("1", "2") and toks[i+1].text in (">", ">>"):
                fd = t.text
                op = toks[i+1].text
                target = toks[i+2].text
                if target in ("1", "2"):
                    parts.append(f"{fd}>&{target}")
                else:
                    parts.append(f"{fd}{op}{target}")
                i += 3
                continue
            if t.text in (">", ">>", "<<") and i + 1 < len(toks):
                parts.append(t.text + toks[i+1].text)
                i += 2
                continue
            if t.text == "$" and i + 1 < len(toks):
                name = toks[i+1].text
                val = self.env.get(name, "")
                if isinstance(val, dict):
                    sys.stderr.write(f"Panic in {self.pos(t.line, t.col)}: value ({self.format_val(val)}) has unexpected type, expected nil, bool, int, float, byte or string\n")
                    raise SystemExit(127)
                parts.append(str(val) if val is not None else "")
                i += 2
                continue
            add(t.text)
            i += 1
        return " ".join(parts)

    def run_command(self, code, capture=False):
        p = subprocess.run(code, shell=True, text=True, executable="/bin/bash")
        return p.returncode

    def format_val(self, v):
        if isinstance(v, dict):
            items = ", ".join(f'"{k}": {self.format_val(vv)}' for k, vv in v.items())
            return "@[ " + items + " ]"
        return repr(v).replace("'", '"')


def parse_args(argv):
    flags = {"lex": False, "ast": False, "program": False, "check": False}
    rest = []
    for a in argv:
        if a in ("-h", "--help"):
            print(HELP); raise SystemExit(0)
        if a in ("-V", "--version"):
            print("Hush 0.1.4"); raise SystemExit(0)
        if a == "--lex": flags["lex"] = True
        elif a == "--ast": flags["ast"] = True
        elif a == "--program": flags["program"] = True
        elif a == "--check": flags["check"] = True
        elif a.startswith("-"):
            sys.stderr.write(f"error: Found argument '{a}' which wasn't expected, or isn't valid in this context\n\n")
            sys.stderr.write("USAGE:\n    executable [FLAGS] [arguments]...\n\nFor more information try --help\n")
            raise SystemExit(1)
        else:
            rest.append(a)
    return flags, rest


def main():
    flags, rest = parse_args(sys.argv[1:])
    path = "<stdin>"
    src = ""
    script_args = []
    if rest and os.path.isfile(rest[0]):
        path = rest[0]
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            src = f.read()
        script_args = rest[1:]
    elif not rest:
        src = sys.stdin.read()
    else:
        return 0
    h = Hush(src, path, script_args)
    h.lex()
    h.analyze()
    if flags["lex"]:
        h.print_lex()
    if flags["ast"] and not h.lex_errors:
        h.print_ast()
    if flags["program"] and not h.errors:
        h.print_program()
    if h.errors:
        for e in h.errors:
            print(e, file=sys.stderr)
        return 2
    if flags["check"]:
        return 0
    sys.stdout.flush()
    sys.stderr.flush()
    return h.run()


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:
        sys.exit(1)
