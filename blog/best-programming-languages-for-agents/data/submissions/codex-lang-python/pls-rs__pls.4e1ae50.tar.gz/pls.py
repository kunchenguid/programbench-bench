#!/usr/bin/env python3
import fnmatch
import grp
import os
import pwd
import stat
import sys
from datetime import datetime

VERSION = "pls 0.0.1-beta.9"

DETAILS = {
    "dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid",
    "size", "blocks", "btime", "ctime", "mtime", "atime", "git", "none", "std", "all",
}
TYPES = {"dir", "symlink", "fifo", "socket", "block-device", "char-device", "file", "none", "all"}
SORTS = {
    "dev", "ino", "nlink", "typ", "cat", "user", "uid", "group", "gid", "size", "blocks",
    "btime", "ctime", "mtime", "atime", "name", "cname", "ext", "inode_", "nlinks_",
    "typ_", "cat_", "user_", "uid_", "group_", "gid_", "size_", "blocks_", "btime_",
    "ctime_", "mtime_", "atime_", "name_", "cname_", "ext_", "none",
}

HELP = """pls is a prettier and powerful ls(1) for the pros.

Read docs: https://pls.cli.rs/
Get source: https://github.com/pls-rs/pls/
Sponsor: https://github.com/sponsors/dhruvkb/

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          the paths to list, each of which may be a file or directory
          
          [default: .]

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Detail view:
  -d, --det <DETAILS>
          the data points to show about each node
          
          [default: none]
          [possible values: dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
          btime, ctime, mtime, atime, git, none, std, all]

  -H, --header <HEADER>
          show headers above columnar data
          
          [default: true]
          [possible values: true, false]

  -u, --unit <UNIT>
          the type of units to use for the node sizes
          
          [default: binary]
          [possible values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>
          display node names in multiple columns
          
          [default: false]
          [possible values: true, false]

  -D, --down <DOWN>
          display node names column-first
          
          [default: false]
          [possible values: true, false]

Presentation:
  -i, --icon <ICON>
          display icons next to node names
          
          [default: true]
          [possible values: true, false]

  -S, --suffix <SUFFIX>
          display node type suffixes after the node name
          
          [default: true]
          [possible values: true, false]

  -l, --sym <SYM>
          show symlink targets
          
          [default: true]
          [possible values: true, false]

  -c, --collapse <COLLAPSE>
          show dependent nodes as children of their principal nodes
          
          [default: true]
          [possible values: true, false]

  -a, --align <ALIGN>
          align items accounting for leading dots
          
          [default: true]
          [possible values: true, false]

Filtering:
  -t, --typ <TYPES>
          the set of node types to include in the output
          
          [default: all]
          [possible values: dir, symlink, fifo, socket, block-device, char-device, file, none, all]

  -I, --imp <IMP>
          the importance cutoff to dim or hide unimportant files
          
          [default: 0]

  -e, --exclude <EXCLUDE>
          the pattern of files to selectively hide from the output

  -o, --only <ONLY>
          the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>
          the set of fields to sort by, trailing `_` reverses the direction
          
          [default: cat cname]
          [possible values: dev, ino, nlink, typ, cat, user, uid, group, gid, size, blocks, btime,
          ctime, mtime, atime, name, cname, ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_,
          gid_, size_, blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]
"""


class UsageError(Exception):
    pass


def parse_bool(val, opt):
    if val == "true":
        return True
    if val == "false":
        return False
    raise UsageError(f"error: invalid value '{val}' for '{opt}'\n  [possible values: true, false]\n\nFor more information, try '--help'.")


def parse_args(argv):
    opts = {
        "det": ["none"], "header": True, "unit": "binary", "grid": False, "down": False,
        "icon": True, "suffix": True, "sym": True, "collapse": True, "align": True,
        "typ": ["all"], "imp": 0, "exclude": [], "only": [], "sort": ["cat", "cname"],
    }
    paths = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            paths.extend(argv[i + 1:])
            break
        if arg in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        takes = {
            "-d": ("det", DETAILS, "--det <DETAILS>"), "--det": ("det", DETAILS, "--det <DETAILS>"),
            "-H": ("header", None, "--header <HEADER>"), "--header": ("header", None, "--header <HEADER>"),
            "-u": ("unit", {"binary", "decimal", "none"}, "--unit <UNIT>"), "--unit": ("unit", {"binary", "decimal", "none"}, "--unit <UNIT>"),
            "-g": ("grid", None, "--grid <GRID>"), "--grid": ("grid", None, "--grid <GRID>"),
            "-D": ("down", None, "--down <DOWN>"), "--down": ("down", None, "--down <DOWN>"),
            "-i": ("icon", None, "--icon <ICON>"), "--icon": ("icon", None, "--icon <ICON>"),
            "-S": ("suffix", None, "--suffix <SUFFIX>"), "--suffix": ("suffix", None, "--suffix <SUFFIX>"),
            "-l": ("sym", None, "--sym <SYM>"), "--sym": ("sym", None, "--sym <SYM>"),
            "-c": ("collapse", None, "--collapse <COLLAPSE>"), "--collapse": ("collapse", None, "--collapse <COLLAPSE>"),
            "-a": ("align", None, "--align <ALIGN>"), "--align": ("align", None, "--align <ALIGN>"),
            "-t": ("typ", TYPES, "--typ <TYPES>"), "--typ": ("typ", TYPES, "--typ <TYPES>"),
            "-I": ("imp", None, "--imp <IMP>"), "--imp": ("imp", None, "--imp <IMP>"),
            "-e": ("exclude", None, "--exclude <EXCLUDE>"), "--exclude": ("exclude", None, "--exclude <EXCLUDE>"),
            "-o": ("only", None, "--only <ONLY>"), "--only": ("only", None, "--only <ONLY>"),
            "-s": ("sort", SORTS, "--sort <SORT_BASES>"), "--sort": ("sort", SORTS, "--sort <SORT_BASES>"),
        }
        if arg.startswith("--") and "=" in arg:
            name, value = arg.split("=", 1)
            if name not in takes:
                raise UsageError(f"error: unexpected argument '{name}' found\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.")
            key, allowed, disp = takes[name]
        elif arg in takes:
            key, allowed, disp = takes[arg]
            i += 1
            if i >= len(argv):
                raise UsageError(f"error: a value is required for '{arg} <{key.upper()}>' but none was supplied\n\nFor more information, try '--help'.")
            value = argv[i]
        elif arg.startswith("-"):
            raise UsageError(f"error: unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.")
        else:
            paths.append(arg)
            i += 1
            continue

        if key in {"header", "grid", "down", "icon", "suffix", "sym", "collapse", "align"}:
            opts[key] = parse_bool(value, disp)
        elif key == "imp":
            try:
                opts[key] = int(value)
            except ValueError:
                opts[key] = 0
        elif key in {"exclude", "only"}:
            opts[key].append(value)
        elif allowed is not None:
            if value not in allowed:
                vals = ", ".join(sorted(allowed))
                raise UsageError(f"error: invalid value '{value}' for '{disp}'\n  [possible values: {vals}]\n\nFor more information, try '--help'.")
            if key in {"det", "typ", "sort"}:
                opts[key].append(value)
            else:
                opts[key] = value
        i += 1
    if not paths:
        paths = ["."]
    if len(opts["det"]) > 1 and "none" in opts["det"]:
        opts["det"] = [x for x in opts["det"] if x != "none"]
    if len(opts["typ"]) > 1 and "all" in opts["typ"]:
        opts["typ"] = [x for x in opts["typ"] if x != "all"]
    if len(opts["sort"]) > 2 or opts["sort"] != ["cat", "cname"]:
        opts["sort"] = [x for x in opts["sort"] if x not in {"cat", "cname"}] or opts["sort"]
    return opts, paths


def kind_from_mode(mode):
    if stat.S_ISDIR(mode):
        return "dir", "d", 0
    if stat.S_ISLNK(mode):
        return "symlink", "l", 4
    if stat.S_ISFIFO(mode):
        return "fifo", "p", 2
    if stat.S_ISSOCK(mode):
        return "socket", "s", 2
    if stat.S_ISBLK(mode):
        return "block-device", "b", 2
    if stat.S_ISCHR(mode):
        return "char-device", "c", 2
    return "file", "f", 1


def icon_for(name, kind, mode):
    if kind == "dir":
        return "\uf07b"
    if kind == "symlink":
        return "\U000f0339"
    if kind == "fifo":
        return "\U000f07e5"
    if kind == "socket":
        return "\U000f06a7"
    if mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH):
        return "\uf489"
    ext = os.path.splitext(name)[1].lower()
    if ext in {".txt", ".md", ".rst", ".log"}:
        return "\ue612"
    if ext in {".rs", ".py", ".c", ".h", ".js", ".json", ".toml", ".yaml", ".yml"}:
        return " "
    return " "


def suffix_for(kind):
    return {"dir": "/", "symlink": "@", "fifo": "|", "socket": "="}.get(kind, "")


def perms(mode):
    chunks = []
    for shift in (6, 3, 0):
        bits = (mode >> shift) & 7
        chunks.append(("r" if bits & 4 else "-") + ("w" if bits & 2 else "-") + ("x" if bits & 1 else "-"))
    return " ".join(chunks)


def uname(uid):
    try:
        return pwd.getpwuid(uid).pw_name
    except KeyError:
        return str(uid)


def gname(gid):
    try:
        return grp.getgrgid(gid).gr_name
    except KeyError:
        return str(gid)


def fmt_size(size, unit):
    if unit == "none":
        return f"{size} B"
    base = 1000 if unit == "decimal" else 1024
    units = ["B", "K", "M", "G", "T"]
    val = float(size)
    idx = 0
    while val >= base and idx < len(units) - 1:
        val /= base
        idx += 1
    return f"{val:.1f}   {units[idx]}"


def fmt_time(ts):
    dt = datetime.fromtimestamp(ts)
    return dt.strftime("%Y-%b-%d %I:%M%p").replace("AM", "am").replace("PM", "pm")


class Entry:
    def __init__(self, path, display_path=None):
        self.path = path
        self.name = os.path.basename(path.rstrip(os.sep)) or path
        self.display_path = display_path if display_path is not None else self.name
        self.error = None
        try:
            self.st = os.lstat(path)
        except OSError as e:
            self.error = e
            self.st = None
            self.kind = "none"
            self.typ = "?"
            self.cat = 9
            return
        self.kind, self.typ, self.cat = kind_from_mode(self.st.st_mode)
        if self.name.startswith(".") and self.kind == "file":
            self.cat = 3

    def cname(self):
        return self.name.lstrip(".").lower()

    def ext(self):
        return os.path.splitext(self.name)[1].lower()


def sort_entries(entries, sort_keys):
    if "none" in sort_keys:
        return entries
    out = entries[:]
    for key in reversed(sort_keys):
        rev = key.endswith("_")
        base = key[:-1] if rev else key
        if base == "inode":
            base = "ino"
        if base == "nlinks":
            base = "nlink"
        def k(e):
            st = e.st
            if base == "cat":
                return e.cat
            if base == "name":
                return e.name
            if base == "cname":
                return e.cname()
            if base == "ext":
                return e.ext()
            if base == "typ":
                return e.typ
            if base == "user":
                return uname(st.st_uid) if st else ""
            if base == "group":
                return gname(st.st_gid) if st else ""
            attrs = {
                "dev": "st_dev", "ino": "st_ino", "nlink": "st_nlink", "uid": "st_uid",
                "gid": "st_gid", "size": "st_size", "blocks": "st_blocks",
                "ctime": "st_ctime", "mtime": "st_mtime", "atime": "st_atime",
                "btime": "st_ctime",
            }
            return getattr(st, attrs.get(base, "st_size"), 0) if st else 0
        out.sort(key=k, reverse=rev)
    return out


def list_dir(path, opts):
    try:
        names = os.listdir(path)
    except OSError as e:
        print(f"{path}:\n\terror: {e.strerror} (os error {getattr(e, 'errno', 1)})", file=sys.stderr)
        return []
    entries = [Entry(os.path.join(path, n), n) for n in names]
    return filter_entries(sort_entries(entries, opts["sort"]), opts)


def filter_entries(entries, opts):
    out = []
    typs = set(opts["typ"])
    for e in entries:
        if e.error:
            continue
        if "none" in typs:
            continue
        if "all" not in typs and e.kind not in typs:
            continue
        if opts["only"] and not any(fnmatch.fnmatch(e.name, pat) for pat in opts["only"]):
            continue
        if any(fnmatch.fnmatch(e.name, pat) for pat in opts["exclude"]):
            continue
        if opts["imp"] and e.name.endswith(("~", ".tmp", ".bak", ".swp")):
            continue
        out.append(e)
    return out


def detail_fields(opts):
    det = opts["det"]
    if "all" in det:
        return ["dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid", "size", "blocks", "btime", "ctime", "mtime", "atime", "git"]
    if "std" in det:
        return ["nlink", "typ", "perm", "user", "group", "size", "mtime"]
    return [d for d in det if d != "none"]


HEADERS = {
    "dev": "Device", "ino": "inode", "nlink": "Link#", "typ": "T", "perm": "Permissions",
    "oct": "SUGO", "user": "User", "uid": "UID", "group": "Group", "gid": "GID",
    "size": "Size", "blocks": "Blocks", "btime": "Created", "ctime": "Changed",
    "mtime": "Modified", "atime": "Accessed", "git": "Git",
}


def value(e, field, opts):
    st = e.st
    if field == "dev":
        return str(st.st_dev)
    if field == "ino":
        return str(st.st_ino)
    if field == "nlink":
        return str(st.st_nlink)
    if field == "typ":
        return e.typ
    if field == "perm":
        return perms(st.st_mode)
    if field == "oct":
        return f"{stat.S_IMODE(st.st_mode):03o}"
    if field == "user":
        return uname(st.st_uid)
    if field == "uid":
        return str(st.st_uid)
    if field == "group":
        return gname(st.st_gid)
    if field == "gid":
        return str(st.st_gid)
    if field == "size":
        return "" if e.kind == "dir" else fmt_size(st.st_size, opts["unit"])
    if field == "blocks":
        return "" if e.kind == "dir" else str(getattr(st, "st_blocks", 0))
    if field in {"btime", "ctime", "mtime", "atime"}:
        ts = {"btime": st.st_ctime, "ctime": st.st_ctime, "mtime": st.st_mtime, "atime": st.st_atime}[field]
        return fmt_time(ts)
    if field == "git":
        return ""
    return ""


def name_text(e, opts):
    name = e.display_path
    path_display = "/" in name
    if opts["suffix"]:
        name += suffix_for(e.kind)
    if opts["icon"]:
        pad = " " if name.startswith(".") or path_display else "  "
        text = icon_for(e.name, e.kind, e.st.st_mode) + pad + name
    else:
        text = (" " if not name.startswith(".") else "") + name
    if e.kind == "symlink" and opts["sym"] and not opts["grid"]:
        try:
            text += " \U000f0054 " + os.readlink(e.path)
        except OSError:
            pass
    return text


def print_entries(entries, opts):
    fields = detail_fields(opts)
    if not fields:
        for e in entries:
            print(name_text(e, opts))
        return
    rows = [[value(e, f, opts) for f in fields] + [name_text(e, opts)] for e in entries]
    heads = [HEADERS[f] for f in fields] + ["Name"]
    widths = []
    for col in range(len(heads)):
        basis = [len(r[col]) for r in rows] or [0]
        if opts["header"]:
            basis.append(len(heads[col]))
        widths.append(max(basis))
    if opts["header"]:
        hparts = []
        for i, head in enumerate(heads):
            if i == len(heads) - 1:
                hparts.append(head)
            elif i < len(fields) and fields[i] in {"typ", "perm", "user", "group", "btime", "ctime", "mtime", "atime", "git"}:
                hparts.append(head.ljust(widths[i]))
            else:
                hparts.append(head.rjust(widths[i]))
        print(" ".join(hparts).rstrip())
    for r in rows:
        parts = []
        for i, cell in enumerate(r):
            if i == len(r) - 1 or (i < len(fields) and fields[i] in {"typ", "perm", "user", "group", "btime", "ctime", "mtime", "atime", "git"}):
                parts.append(cell.ljust(widths[i]))
            else:
                parts.append(cell.rjust(widths[i]))
        print(" ".join(parts).rstrip())


def run(opts, paths):
    multi = len(paths) > 1
    first = True
    for p in paths:
        ent = Entry(p, p if not os.path.isdir(p) or os.path.islink(p) else os.path.basename(p.rstrip(os.sep)) or p)
        if ent.error:
            print(f"{p}:\n\terror: {ent.error.strerror} (os error {getattr(ent.error, 'errno', 1)})", file=sys.stderr)
            continue
        if stat.S_ISDIR(ent.st.st_mode) and not stat.S_ISLNK(ent.st.st_mode):
            if multi:
                if not first:
                    print()
                print(f"{p}:")
            print_entries(list_dir(p, opts), opts)
        else:
            entries = filter_entries([ent], opts)
            print_entries(entries, opts)
        first = False


def main(argv):
    try:
        opts, paths = parse_args(argv)
        run(opts, paths)
        return 0
    except UsageError as e:
        print(str(e), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
