#!/usr/bin/env python3
import argparse
import json
import os
import re
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from fnmatch import fnmatch

VERSION = "onefetch 2.25.0"

LANGUAGES = """ABNF
ABAP
Ada
Agda
Arduino C++
Assembly
ATS
AutoHotKey
BASH
C
CMake
C#
Ceylon
Clojure
CoffeeScript
ColdFusion
Coq
C++
Crystal
CSS
CUDA
D
Dart
Dockerfile
Emacs Lisp
Elixir
Elm
Emojicode
Erlang
F#
Fish
Forth
FORTRAN Legacy
FORTRAN Modern
GDScript
GLSL
Go
GraphQL
Groovy
Haskell
Haxe
HCL
HLSL
HolyC
HTML
Idris
Java
JavaScript
JSON
Jsonnet
JSX
Julia
Jupyter Notebooks
Kotlin
LLVM
Lean
Common Lisp
Lua
Makefile
Markdown
Modelica
Nim
Nix
OCaml
Objective-C
Odin
OpenSCAD
Org
Oz
Pascal
Perl
PHP
PowerShell
Processing
Prolog
Protocol Buffers
PureScript
Python
QML
R
Racket
Raku
Razor
Ren'Py
Ruby
Rust
Sass
Scala
Scheme
Shell
Solidity
SQL
Svelte
SVG
Swift
SystemVerilog
TCL
TeX
Plain Text
TOML
TSX
TypeScript
Typst
Vala
Verilog
VHDL
Vim Script
Visual Basic
Vue
WebAssembly
Wolfram
XSL
XAML
XML
YAML
Zig
Zsh""".splitlines()

DISABLED = ["project", "description", "head", "pending", "version", "created",
            "languages", "dependencies", "authors", "last-change", "contributors",
            "url", "commits", "churn", "lines-of-code", "size", "license"]

EXT_LANG = {
    ".py": ("Python", "programming"), ".rs": ("Rust", "programming"),
    ".go": ("Go", "programming"), ".js": ("JavaScript", "programming"),
    ".jsx": ("JSX", "programming"), ".ts": ("TypeScript", "programming"),
    ".tsx": ("TSX", "programming"), ".java": ("Java", "programming"),
    ".c": ("C", "programming"), ".h": ("C", "programming"),
    ".cpp": ("C++", "programming"), ".cc": ("C++", "programming"),
    ".cxx": ("C++", "programming"), ".hpp": ("C++", "programming"),
    ".cs": ("C#", "programming"), ".rb": ("Ruby", "programming"),
    ".php": ("PHP", "programming"), ".swift": ("Swift", "programming"),
    ".kt": ("Kotlin", "programming"), ".kts": ("Kotlin", "programming"),
    ".scala": ("Scala", "programming"), ".r": ("R", "programming"),
    ".R": ("R", "programming"), ".lua": ("Lua", "programming"),
    ".pl": ("Perl", "programming"), ".pm": ("Perl", "programming"),
    ".ex": ("Elixir", "programming"), ".exs": ("Elixir", "programming"),
    ".erl": ("Erlang", "programming"), ".hrl": ("Erlang", "programming"),
    ".hs": ("Haskell", "programming"), ".fs": ("F#", "programming"),
    ".fsx": ("F#", "programming"), ".dart": ("Dart", "programming"),
    ".zig": ("Zig", "programming"), ".nim": ("Nim", "programming"),
    ".m": ("Objective-C", "programming"), ".mm": ("Objective-C", "programming"),
    ".sh": ("Shell", "programming"), ".bash": ("BASH", "programming"),
    ".zsh": ("Zsh", "programming"), ".fish": ("Fish", "programming"),
    ".ps1": ("PowerShell", "programming"), ".sql": ("SQL", "programming"),
    ".html": ("HTML", "markup"), ".htm": ("HTML", "markup"),
    ".css": ("CSS", "markup"), ".scss": ("Sass", "markup"),
    ".sass": ("Sass", "markup"), ".vue": ("Vue", "markup"),
    ".svelte": ("Svelte", "markup"), ".xml": ("XML", "markup"),
    ".xaml": ("XAML", "markup"), ".svg": ("SVG", "markup"),
    ".md": ("Markdown", "prose"), ".markdown": ("Markdown", "prose"),
    ".rst": ("Plain Text", "prose"), ".txt": ("Plain Text", "prose"),
    ".tex": ("TeX", "prose"), ".org": ("Org", "prose"),
    ".json": ("JSON", "data"), ".yaml": ("YAML", "data"),
    ".yml": ("YAML", "data"), ".toml": ("TOML", "data"),
    ".lock": ("TOML", "data"), ".csv": ("Plain Text", "data"),
    ".proto": ("Protocol Buffers", "programming"), ".graphql": ("GraphQL", "data"),
}

SPECIAL_NAMES = {
    "Dockerfile": ("Dockerfile", "programming"),
    "Makefile": ("Makefile", "programming"),
    "CMakeLists.txt": ("CMake", "programming"),
}

def run(cmd, cwd, ok=False):
    p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode and not ok:
        raise RuntimeError(p.stderr.strip() or p.stdout.strip())
    return p.stdout

def git_root(path):
    p = subprocess.run(["git", "rev-parse", "--show-toplevel"], cwd=path, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode:
        print(f"Error: Could not find a git repository in '{path}' or in any of its parents", file=sys.stderr)
        sys.exit(1)
    return p.stdout.strip()

def rel_time(epoch, iso=False):
    if iso:
        s = datetime.fromtimestamp(epoch, timezone.utc).strftime("%Y-%m-%dT%H:%M:%S%z")
        return s[:-2] + ":" + s[-2:] if len(s) >= 5 else s
    now = datetime.now(timezone.utc).timestamp()
    diff = max(0, int(now - epoch))
    units = [("year", 365*24*3600), ("month", 30*24*3600), ("week", 7*24*3600),
             ("day", 24*3600), ("hour", 3600), ("minute", 60)]
    for name, sec in units:
        n = diff // sec
        if n:
            return f"{n} {name}{'' if n == 1 else 's'} ago"
    return "now"

def git_epoch(root, args):
    out = run(["git"] + args, root, ok=True).strip()
    try:
        return int(out.splitlines()[0])
    except Exception:
        return int(datetime.now(timezone.utc).timestamp())

def tracked_files(root, include_hidden=False, excludes=None):
    excludes = excludes or []
    out = run(["git", "ls-files", "--cached", "--others", "--exclude-standard"], root, ok=True)
    files = []
    for f in out.splitlines():
        if not f or f.startswith(".git/"):
            continue
        parts = f.split("/")
        if not include_hidden and any(part.startswith(".") for part in parts):
            continue
        if any(fnmatch(f, pat) or any(fnmatch(part, pat) for part in parts) for pat in excludes):
            continue
        full = os.path.join(root, f)
        if os.path.isfile(full):
            files.append(f)
    return files

def language_for(path):
    base = os.path.basename(path)
    if base in SPECIAL_NAMES:
        return SPECIAL_NAMES[base]
    ext = os.path.splitext(base)[1]
    return EXT_LANG.get(ext)

def count_code_lines(full, lang):
    try:
        data = open(full, "r", encoding="utf-8", errors="ignore").read().splitlines()
    except OSError:
        return 0
    n = 0
    in_block = False
    for line in data:
        s = line.strip()
        if not s:
            continue
        if lang in ("Python", "Shell", "Ruby", "Perl", "R") and s.startswith("#"):
            continue
        if lang in ("JavaScript", "TypeScript", "Rust", "Go", "Java", "C", "C++", "C#", "CSS"):
            if in_block:
                if "*/" in s:
                    in_block = False
                    s = s.split("*/", 1)[1].strip()
                else:
                    continue
            if s.startswith("/*"):
                if "*/" not in s[2:]:
                    in_block = True
                continue
            if s.startswith("//"):
                continue
        if lang in ("HTML", "XML", "SVG") and s.startswith("<!--"):
            continue
        n += 1
    return n

def fmt_size(n):
    units = ["B", "KiB", "MiB", "GiB"]
    val = float(n)
    for unit in units:
        if val < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(val)} B"
            s = f"{val:.2f}".rstrip("0").rstrip(".")
            return f"{s} {unit}"
        val /= 1024

def fmt_num(n, sep):
    if sep == "comma":
        return f"{n:,}"
    if sep == "space":
        return f"{n:,}".replace(",", " ")
    if sep == "underscore":
        return f"{n:,}".replace(",", "_")
    return str(n)

def repo_url(root, http_url=False, hide_token=False):
    url = run(["git", "config", "--get", "remote.origin.url"], root, ok=True).strip()
    if http_url and url.startswith("git@") and ":" in url:
        host = url.split("@", 1)[1].split(":", 1)[0]
        path = url.split(":", 1)[1]
        url = f"https://{host}/{path}"
    if hide_token:
        url = re.sub(r"(https?://)[^/@]+@", r"\1", url)
    return url

def license_name(root):
    for name in ["LICENSE", "LICENSE.md", "LICENSE.txt", "COPYING"]:
        p = os.path.join(root, name)
        if os.path.exists(p):
            txt = open(p, "r", encoding="utf-8", errors="ignore").read(2048)
            low = txt.lower()
            if "mit license" in low:
                return "MIT"
            if "apache license" in low:
                return "Apache-2.0"
            if "gnu general public license" in low:
                return "GPL"
            return os.path.splitext(name)[0]
    return ""

def package_deps(root):
    vals = []
    if os.path.exists(os.path.join(root, "Cargo.toml")):
        vals.append("Cargo")
    if os.path.exists(os.path.join(root, "package.json")):
        vals.append("Npm")
    return ", ".join(vals)

def version_value(root):
    for fname in ["Cargo.toml", "pyproject.toml", "package.json"]:
        p = os.path.join(root, fname)
        if not os.path.exists(p):
            continue
        txt = open(p, "r", encoding="utf-8", errors="ignore").read()
        m = re.search(r'"version"\s*:\s*"([^"]+)"', txt) or re.search(r'(?m)^\s*version\s*=\s*"([^"]+)"', txt)
        if m:
            return m.group(1)
    return ""

def pending(root):
    out = run(["git", "status", "--porcelain"], root, ok=True)
    added = deleted = modified = 0
    for line in out.splitlines():
        code = line[:2]
        if "A" in code or code == "??":
            added += 1
        if "D" in code:
            deleted += 1
        if "M" in code or "R" in code:
            modified += 1
    return added, deleted, modified

def authors(root, show_email=False, no_bots=None, no_merges=False):
    cmd = ["git", "log", "--format=%an%x00%ae"]
    if no_merges:
        cmd.insert(2, "--no-merges")
    out = run(cmd, root, ok=True)
    c = Counter()
    emails = {}
    pat = re.compile(no_bots or r"(?i)(\[bot\]|bot$)") if no_bots is not None else None
    for line in out.splitlines():
        if "\0" in line:
            name, email = line.split("\0", 1)
        else:
            name, email = line, ""
        if pat and (pat.search(name) or pat.search(email)):
            continue
        c[name] += 1
        emails.setdefault(name, email)
    total = sum(c.values()) or 1
    arr = []
    for name, n in c.most_common():
        arr.append({"name": name, "email": emails.get(name) if show_email else None,
                    "nbrOfCommits": n, "contribution": round(n * 100 / total)})
    return arr

def churn(root, limit, pool, no_merges=False):
    args = ["git", "log", "--name-only", "--format="]
    if no_merges:
        args.insert(2, "--no-merges")
    if pool:
        args.insert(2, f"-n{pool}")
    out = run(args, root, ok=True)
    c = Counter(f for f in out.splitlines() if f.strip())
    return [{"filePath": k, "nbrOfCommits": v} for k, v in c.most_common(limit)]

def build(root, ns):
    files = tracked_files(root, ns.include_hidden, ns.exclude)
    lang_bytes = Counter()
    lang_types = {}
    loc = 0
    size = 0
    for f in files:
        full = os.path.join(root, f)
        try:
            b = os.path.getsize(full)
        except OSError:
            b = 0
        size += b
        lf = language_for(f)
        if lf:
            lang, typ = lf
            lang_types[lang] = typ
            if typ in ns.type:
                lang_bytes[lang] += b
                loc += count_code_lines(full, lang)
    total_lang = sum(lang_bytes.values()) or 1
    langs = [{"language": lang, "percentage": round(val * 100 / total_lang, 1)}
             for lang, val in lang_bytes.most_common(ns.number_of_languages)]
    head = run(["git", "rev-parse", "--short=7", "HEAD"], root, ok=True).strip()
    branch = run(["git", "branch", "--show-current"], root, ok=True).strip()
    refs = [branch] if branch else []
    git_user = run(["git", "config", "user.name"], root, ok=True).strip() or os.environ.get("USER", "")
    git_ver = run(["git", "--version"], root, ok=True).strip()
    commits = run(["git", "rev-list", "--count", "HEAD"], root, ok=True).strip()
    try:
        commit_count = int(commits)
    except ValueError:
        commit_count = 0
    first = git_epoch(root, ["log", "--reverse", "--format=%ct", "-n1"])
    last = git_epoch(root, ["log", "-1", "--format=%ct"])
    add, dele, mod = pending(root)
    auths = authors(root, ns.email, ns.no_bots, ns.no_merges)[:ns.number_of_authors]
    total_auths = len(authors(root, False, ns.no_bots, ns.no_merges))
    branches = run(["git", "branch", "--format=%(refname:short)"], root, ok=True).splitlines()
    tags = run(["git", "tag"], root, ok=True).splitlines()
    shallow = os.path.exists(os.path.join(root, ".git", "shallow"))
    pool = ns.churn_pool_size or commit_count
    repo_name = os.path.basename(repo_url(root) or "")
    if repo_name.endswith(".git"):
        repo_name = repo_name[:-4]
    fields = []
    def add_field(key, obj):
        if key not in ns.disabled_fields:
            fields.append(obj)
    add_field("project", {"ProjectInfo": {"repoName": repo_name, "numberOfBranches": max(0, len(branches)-1), "numberOfTags": len(tags)}})
    add_field("description", {"DescriptionInfo": {"description": None}})
    add_field("head", {"HeadInfo": {"headRefs": {"shortCommitId": head, "refs": refs}}})
    add_field("pending", {"PendingInfo": {"added": add, "deleted": dele, "modified": mod}})
    add_field("version", {"VersionInfo": {"version": version_value(root)}})
    add_field("created", {"CreatedInfo": {"creationDate": rel_time(first, ns.iso_time)}})
    add_field("languages", {"LanguagesInfo": {"languagesWithPercentage": langs}})
    add_field("dependencies", {"DependenciesInfo": {"dependencies": package_deps(root)}})
    add_field("authors", {"AuthorsInfo": {"authors": auths}})
    add_field("last-change", {"LastChangeInfo": {"lastChange": rel_time(last, ns.iso_time)}})
    add_field("contributors", {"ContributorsInfo": {"totalNumberOfAuthors": total_auths}})
    add_field("url", {"UrlInfo": {"repoUrl": repo_url(root, ns.http_url, ns.hide_token)}})
    add_field("commits", {"CommitsInfo": {"numberOfCommits": commit_count, "isShallow": shallow}})
    add_field("churn", {"ChurnInfo": {"file_churns": churn(root, ns.number_of_file_churns, ns.churn_pool_size, ns.no_merges), "churn_pool_size": pool}})
    add_field("lines-of-code", {"LocInfo": {"linesOfCode": loc}})
    add_field("size", {"SizeInfo": {"repoSize": fmt_size(size), "fileCount": len(files)}})
    add_field("license", {"LicenseInfo": {"license": license_name(root)}})
    return {"title": {"gitUsername": git_user, "gitVersion": git_ver}, "infoFields": fields}

def yaml_scalar(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    if v == "":
        return "''"
    if re.match(r"^[A-Za-z0-9_./:() -]+$", str(v)):
        return str(v)
    return json.dumps(str(v))

def dump_yaml(obj, indent=0):
    lines = []
    sp = " " * indent
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, dict):
                lines.append(f"{sp}{k}:")
                lines.extend(dump_yaml(v, indent + 2))
            elif isinstance(v, list):
                lines.append(f"{sp}{k}:")
                lines.extend(dump_yaml(v, indent))
            else:
                lines.append(f"{sp}{k}: {yaml_scalar(v)}")
    elif isinstance(obj, list):
        for item in obj:
            if isinstance(item, dict):
                first = True
                for k, v in item.items():
                    if first:
                        if isinstance(v, (dict, list)):
                            lines.append(f"{sp}- {k}:")
                            lines.extend(dump_yaml(v, indent + 4))
                        else:
                            lines.append(f"{sp}- {k}: {yaml_scalar(v)}")
                        first = False
                    else:
                        if isinstance(v, (dict, list)):
                            lines.append(f"{sp}  {k}:")
                            lines.extend(dump_yaml(v, indent + 4))
                        else:
                            lines.append(f"{sp}  {k}: {yaml_scalar(v)}")
            else:
                lines.append(f"{sp}- {yaml_scalar(item)}")
    return lines

def text_output(data, ns):
    out = []
    title = data["title"]
    if not ns.no_title:
        out.append(f"{title['gitUsername']} ~ {title['gitVersion']}")
        out.append("-" * max(10, len(out[0])))
    labels = {
        "ProjectInfo": "Project", "DescriptionInfo": "Description", "HeadInfo": "HEAD",
        "PendingInfo": "Pending", "VersionInfo": "Version", "CreatedInfo": "Created",
        "LanguagesInfo": "Language", "DependenciesInfo": "Dependencies",
        "AuthorsInfo": "Author", "LastChangeInfo": "Last change",
        "ContributorsInfo": "Contributors", "UrlInfo": "URL", "CommitsInfo": "Commits",
        "ChurnInfo": "Churn", "LocInfo": "Lines of code", "SizeInfo": "Size",
        "LicenseInfo": "License"
    }
    for wrapper in data["infoFields"]:
        key, val = next(iter(wrapper.items()))
        lab = labels.get(key, key)
        if key == "LanguagesInfo":
            s = ", ".join(f"{x['language']} ({x['percentage']:.1f} %)" for x in val["languagesWithPercentage"])
        elif key == "AuthorsInfo":
            s = ", ".join(f"{a['contribution']}% {a['name']} {a['nbrOfCommits']}" for a in val["authors"])
        elif key == "HeadInfo":
            h = val["headRefs"]; s = f"{h['shortCommitId']} ({', '.join(h['refs'])})"
        elif key == "PendingInfo":
            s = f"{val['added']}+, {val['modified']}~, {val['deleted']}-"
        elif key == "CommitsInfo":
            s = fmt_num(val["numberOfCommits"], ns.number_separator)
        elif key == "ChurnInfo":
            lab = f"Churn ({val['churn_pool_size']})"
            s = ", ".join(f"{c['filePath']} {c['nbrOfCommits']}" for c in val["file_churns"])
        elif key == "LocInfo":
            s = fmt_num(val["linesOfCode"], ns.number_separator)
        elif key == "SizeInfo":
            s = f"{val['repoSize']} ({fmt_num(val['fileCount'], ns.number_separator)} files)"
        else:
            inner = next(iter(val.values())) if isinstance(val, dict) and len(val) == 1 else val
            s = "" if inner is None else str(inner)
        if s:
            out.append(f"{lab}: {s}")
    return "\n".join(out)

class Parser(argparse.ArgumentParser):
    def error(self, message):
        if "invalid choice" in message and "--disabled-fields" in message:
            bad = message.split("'")[1] if "'" in message else ""
            print(f"error: invalid value '{bad}' for '--disabled-fields <FIELD>...'", file=sys.stderr)
            print("  [possible values: " + ", ".join(DISABLED) + "]\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        super().error(message)

def make_parser():
    p = Parser(prog="executable", description="Command-line Git information tool",
               formatter_class=argparse.RawDescriptionHelpFormatter, add_help=False)
    p.add_argument("input", nargs="?", default=".")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("-l", "--languages", action="store_true")
    p.add_argument("-p", "--package-managers", action="store_true")
    p.add_argument("-o", "--output", choices=["json", "yaml"])
    p.add_argument("--generate", choices=["bash", "elvish", "fish", "powershell", "zsh"])
    p.add_argument("-d", "--disabled-fields", nargs="+", choices=DISABLED, default=[])
    p.add_argument("--no-title", action="store_true")
    p.add_argument("--number-of-authors", type=int, default=3)
    p.add_argument("--number-of-languages", type=int, default=6)
    p.add_argument("--number-of-file-churns", type=int, default=3)
    p.add_argument("--churn-pool-size", type=int)
    p.add_argument("-e", "--exclude", nargs="+", default=[])
    p.add_argument("--no-bots", nargs="?", const=r"(?i)(\[bot\]|bot$)")
    p.add_argument("--no-merges", action="store_true")
    p.add_argument("-E", "--email", action="store_true")
    p.add_argument("--http-url", action="store_true")
    p.add_argument("--hide-token", action="store_true")
    p.add_argument("--include-hidden", action="store_true")
    p.add_argument("-T", "--type", nargs="+", default=["programming", "markup"],
                   choices=["programming", "markup", "prose", "data"])
    p.add_argument("-z", "--iso-time", action="store_true")
    p.add_argument("--number-separator", default="plain", choices=["plain", "comma", "space", "underscore"])
    p.add_argument("--no-bold", action="store_true")
    p.add_argument("--ascii-input")
    p.add_argument("-c", "--ascii-colors", nargs="+")
    p.add_argument("-t", "--text-colors", nargs="+")
    p.add_argument("-a", "--ascii-language")
    p.add_argument("--true-color", choices=["auto", "never", "always"], default="auto")
    p.add_argument("-i", "--image")
    p.add_argument("--image-protocol", choices=["kitty", "sixel", "iterm"])
    p.add_argument("--color-resolution", choices=["16", "32", "64", "128", "256"], default="64")
    p.add_argument("--no-color-palette", action="store_true")
    p.add_argument("--no-art", action="store_true")
    p.add_argument("--nerd-fonts", action="store_true")
    return p

HELP = """Command-line Git information tool

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Run as if onefetch was started in <input> instead of the current working directory

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

INFO:
  -d, --disabled-fields <FIELD>...   Allows you to disable FIELD(s) from appearing in the output
      --no-title                     Hides the title
      --number-of-authors <NUM>      Maximum NUM of authors to be shown [default: 3]
      --number-of-languages <NUM>    Maximum NUM of languages to be shown [default: 6]
      --number-of-file-churns <NUM>  Maximum NUM of file churns to be shown [default: 3]
      --churn-pool-size <NUM>        Minimum NUM of commits from HEAD used to compute the churn summary
  -e, --exclude <EXCLUDE>...         Ignore all files & directories matching EXCLUDE
      --no-bots[=<REGEX>]            Exclude [bot] commits. Use <REGEX> to override the default pattern
      --no-merges                    Ignores merge commits
  -E, --email                        Show the email address of each author
      --http-url                     Display repository URL as HTTP
      --hide-token                   Hide token in repository URL
      --include-hidden               Count hidden files and directories
  -T, --type <TYPE>...               Filters output by language type [default: programming markup]
                                     [possible values: programming, markup, prose, data]

TEXT FORMATTING:
  -z, --iso-time                      Use ISO 8601 formatted timestamps
      --number-separator <SEPARATOR>  Which thousands SEPARATOR to use [default: plain] [possible values: plain, comma, space, underscore]
      --no-bold                       Turns off bold formatting

DEVELOPER:
  -o, --output <FORMAT>   Outputs Onefetch in a specific format [possible values: json, yaml]
      --generate <SHELL>  If provided, outputs the completion file for given SHELL [possible values: bash, elvish, fish, powershell, zsh]

OTHER:
  -l, --languages         Prints out supported languages
  -p, --package-managers  Prints out supported package managers"""

def main(argv):
    p = make_parser()
    ns = p.parse_args(argv)
    if ns.help:
        print(HELP)
        return 0
    if ns.version:
        print(VERSION)
        return 0
    if ns.languages:
        print("\n".join(LANGUAGES))
        return 0
    if ns.package_managers:
        print("Npm\nCargo")
        return 0
    if ns.generate:
        print(f"# completion for onefetch ({ns.generate})")
        return 0
    root = git_root(os.path.abspath(ns.input))
    data = build(root, ns)
    if ns.output == "json":
        print(json.dumps(data, indent=2))
    elif ns.output == "yaml":
        print("\n".join(dump_yaml(data)))
    else:
        print(text_output(data, ns))
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
