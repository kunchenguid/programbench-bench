#!/usr/bin/env python3
import fnmatch
import gzip
import lzma
import os
import re
import stat
import sys
import time


VERSION = """ag version 2.2.0

Features:
  +jit +lzma +zlib"""

HELP = r"""
Usage: ag [FILE-TYPE] [OPTIONS] PATTERN [PATH]

  Recursively search for PATTERN in PATH.
  Like grep or ack, but faster.

Example:
  ag -i foo /bar/

Output Options:
     --ackmate            Print results in AckMate-parseable format
  -A --after [LINES]      Print lines after match (Default: 2)
  -B --before [LINES]     Print lines before match (Default: 2)
     --[no]break          Print newlines between matches in different files
                          (Enabled by default)
  -c --count              Only print the number of matches in each file.
                          (This often differs from the number of matching lines)
     --[no]color          Print color codes in results (Enabled by default)
     --color-line-number  Color codes for line numbers (Default: 1;33)
     --color-match        Color codes for result match numbers (Default: 30;43)
     --color-path         Color codes for path names (Default: 1;32)
     --column             Print column numbers in results
     --[no]filename       Print file names (Enabled unless searching a single file)
  -H --[no]heading        Print file names before each file's matches
                          (Enabled by default)
  -C --context [LINES]    Print lines before and after matches (Default: 2)
     --[no]group          Same as --[no]break --[no]heading
  -g --filename-pattern PATTERN
                          Print filenames matching PATTERN
  -l --files-with-matches Only print filenames that contain matches
                          (don't print the matching lines)
  -L --files-without-matches
                          Only print filenames that don't contain matches
     --print-all-files    Print headings for all files searched, even those that
                          don't contain matches
     --[no]numbers        Print line numbers. Default is to omit line numbers
                          when searching streams
  -o --only-matching      Prints only the matching part of the lines
     --print-long-lines   Print matches on very long lines (Default: >2k characters)
     --passthrough        When searching a stream, print all lines even if they
                          don't match
     --silent             Suppress all log messages, including errors
     --stats              Print stats (files scanned, time taken, etc.)
     --stats-only         Print stats and nothing else.
                          (Same as --count when searching a single file)
     --vimgrep            Print results like vim's :vimgrep /pattern/g would
                          (it reports every match on the line)
  -0 --null --print0      Separate filenames with null (for 'xargs -0')

Search Options:
  -a --all-types          Search all files (doesn't include hidden files
                          or patterns from ignore files)
  -D --debug              Ridiculous debugging (probably not useful)
     --depth NUM          Search up to NUM directories deep (Default: 25)
  -f --follow             Follow symlinks
  -F --fixed-strings      Alias for --literal for compatibility with grep
  -G --file-search-regex  PATTERN Limit search to filenames matching PATTERN
     --hidden             Search hidden files (obeys .*ignore files)
  -i --ignore-case        Match case insensitively
     --ignore PATTERN     Ignore files/directories matching PATTERN
                          (literal file/directory names also allowed)
     --ignore-dir NAME    Alias for --ignore for compatibility with ack.
  -m --max-count NUM      Skip the rest of a file after NUM matches (Default: 10,000)
     --one-device         Don't follow links to other devices.
  -p --path-to-ignore STRING
                          Use .ignore file at STRING
  -Q --literal            Don't parse PATTERN as a regular expression
  -s --case-sensitive     Match case sensitively
  -S --smart-case         Match case insensitively unless PATTERN contains
                          uppercase characters (Enabled by default)
     --search-binary      Search binary files for matches
  -t --all-text           Search all text files (doesn't include hidden files)
  -u --unrestricted       Search all files (ignore .ignore, .gitignore, etc.;
                          searches binary and hidden files as well)
  -U --skip-vcs-ignores   Ignore VCS ignore files
                          (.gitignore, .hgignore; still obey .ignore)
  -v --invert-match
  -w --word-regexp        Only match whole words
  -W --width NUM          Truncate match lines after NUM characters
  -z --search-zip         Search contents of compressed (e.g., gzip) files

File Types:
The search can be restricted to certain types of files. Example:
  ag --html needle
  - Searches for 'needle' in files with suffix .htm, .html, .shtml or .xhtml.

For a list of supported file types run:
  ag --list-file-types

ag was originally created by Geoff Greer. More information (and the latest release)
can be found at http://geoff.greer.fm/ag
""".lstrip()

FILE_TYPES = {
    "actionscrit": [".as", ".mxml"],
    "actionscript": [".as", ".mxml"],
    "ada": [".ada", ".adb", ".ads"],
    "asciidoc": [".adoc", ".ad", ".asc", ".asciidoc"],
    "asm": [".asm", ".s"],
    "asp": [".asp", ".asa", ".aspx", ".asax", ".ashx", ".ascx", ".asmx"],
    "aspx": [".asp", ".asa", ".aspx", ".asax", ".ashx", ".ascx", ".asmx"],
    "batch": [".bat", ".cmd"],
    "bazel": [".bazel"],
    "cc": [".c", ".h", ".xs"],
    "c": [".c", ".h"],
    "cpp": [".cpp", ".cc", ".C", ".cxx", ".m", ".hpp", ".hh", ".h", ".H", ".hxx", ".tpp"],
    "csharp": [".cs"],
    "css": [".css"],
    "go": [".go"],
    "html": [".htm", ".html", ".shtml", ".xhtml"],
    "java": [".java", ".properties"],
    "js": [".js", ".jsx", ".vue"],
    "json": [".json"],
    "lua": [".lua"],
    "make": ["Makefile", "makefile", ".mk"],
    "markdown": [".md", ".markdown", ".mkd"],
    "md": [".md", ".markdown", ".mkd"],
    "objc": [".m", ".h"],
    "perl": [".pl", ".pm", ".pod", ".t"],
    "php": [".php", ".phpt", ".php3", ".php4", ".php5", ".phtml"],
    "python": [".py"],
    "py": [".py"],
    "ruby": [".rb", ".rhtml", ".rjs", ".rxml", ".erb", ".rake", "Rakefile", "Gemfile"],
    "rust": [".rs"],
    "scala": [".scala"],
    "shell": [".sh", ".bash", ".csh", ".tcsh", ".ksh", ".zsh", ".fish"],
    "sql": [".sql"],
    "swift": [".swift"],
    "txt": [".txt"],
    "xml": [".xml", ".dtd", ".xsl", ".xslt", ".ent"],
    "yaml": [".yaml", ".yml"],
}


class Opt:
    def __init__(self):
        self.after = 0
        self.before = 0
        self.breaks = False
        self.color = False
        self.column = False
        self.count = False
        self.filename = None
        self.heading = False
        self.group = True
        self.file_pattern = None
        self.name_pattern = None
        self.files_with_matches = False
        self.files_without_matches = False
        self.print_all_files = False
        self.numbers = None
        self.only_matching = False
        self.passthrough = False
        self.stats = False
        self.stats_only = False
        self.vimgrep = False
        self.ackmate = False
        self.null = False
        self.all_types = False
        self.hidden = False
        self.follow = False
        self.literal = False
        self.ignore_case = False
        self.case_sensitive = False
        self.smart_case = True
        self.search_binary = False
        self.unrestricted = False
        self.skip_vcs_ignores = False
        self.invert = False
        self.word = False
        self.width = None
        self.search_zip = False
        self.depth = 25
        self.max_count = 10000
        self.recurse = True
        self.silent = False
        self.ignores = []
        self.path_to_ignore = None
        self.type_exts = None
        self.debug = False


def want_value(argv, i, default=None):
    if i + 1 < len(argv) and argv[i + 1] != "--" and not argv[i + 1].startswith("-"):
        return argv[i + 1], i + 1
    return default, i


def parse_args(argv):
    opt = Opt()
    rest = []
    i = 0
    endopts = False
    while i < len(argv):
        a = argv[i]
        if endopts:
            rest.append(a); i += 1; continue
        if a == "--":
            endopts = True; i += 1; continue
        if a in ("--help", "-h"):
            print(HELP, end="")
            raise SystemExit(0)
        if a in ("--version", "-V"):
            print(VERSION)
            raise SystemExit(0)
        if a == "--list-file-types":
            print_file_types()
            raise SystemExit(0)
        if a.startswith("--") and a[2:] in FILE_TYPES:
            opt.type_exts = FILE_TYPES[a[2:]]
            i += 1; continue
        if not a.startswith("-") or a == "-":
            rest.append(a); i += 1; continue

        def need():
            nonlocal i
            if i + 1 >= len(argv):
                sys.stderr.write(f"ERR: option {a} requires an argument\n")
                raise SystemExit(1)
            i += 1
            return argv[i]

        if a.startswith("--after="): opt.after = int(a.split("=",1)[1])
        elif a in ("-A", "--after"):
            v, ni = want_value(argv, i, "2"); opt.after = int(v); i = ni
        elif a.startswith("-A") and len(a) > 2: opt.after = int(a[2:])
        elif a in ("-B", "--before"):
            v, ni = want_value(argv, i, "2"); opt.before = int(v); i = ni
        elif a.startswith("-B") and len(a) > 2: opt.before = int(a[2:])
        elif a in ("-C", "--context"):
            v, ni = want_value(argv, i, "2"); opt.before = opt.after = int(v); i = ni
        elif a.startswith("-C") and len(a) > 2: opt.before = opt.after = int(a[2:])
        elif a == "--break": opt.breaks = True
        elif a == "--nobreak": opt.breaks = False
        elif a in ("-c", "--count"): opt.count = True
        elif a == "--color": opt.color = True
        elif a == "--nocolor": opt.color = False
        elif a.startswith("--color-"):
            if "=" not in a:
                need()
        elif a == "--column": opt.column = True
        elif a == "--filename": opt.filename = True
        elif a == "--nofilename": opt.filename = False
        elif a in ("-H", "--heading"): opt.heading = True; opt.filename = True; opt.breaks = True
        elif a == "--noheading": opt.heading = False
        elif a == "--group": opt.group = True; opt.breaks = True; opt.heading = True
        elif a == "--nogroup": opt.group = False; opt.breaks = False; opt.heading = False
        elif a in ("-g", "--filename-pattern"): opt.name_pattern = need()
        elif a in ("-G", "--file-search-regex"): opt.file_pattern = need()
        elif a.startswith("-G") and len(a) > 2: opt.file_pattern = a[2:]
        elif a in ("-l", "--files-with-matches"): opt.files_with_matches = True
        elif a in ("-L", "--files-without-matches"): opt.files_without_matches = True
        elif a == "--print-all-files": opt.print_all_files = True
        elif a == "--numbers": opt.numbers = True
        elif a == "--nonumbers": opt.numbers = False
        elif a in ("-o", "--only-matching"): opt.only_matching = True
        elif a in ("--passthrough", "--passthru"): opt.passthrough = True
        elif a == "--silent": opt.silent = True
        elif a == "--stats": opt.stats = True
        elif a == "--stats-only": opt.stats_only = True
        elif a == "--vimgrep": opt.vimgrep = True; opt.heading = False; opt.filename = True
        elif a == "--ackmate": opt.ackmate = True
        elif a in ("-0", "--null", "--print0"): opt.null = True
        elif a in ("-a", "--all-types"): opt.all_types = True
        elif a in ("-D", "--debug"): opt.debug = True
        elif a == "--depth": opt.depth = int(need())
        elif a in ("-f", "--follow"): opt.follow = True
        elif a in ("-F", "--fixed-strings", "-Q", "--literal"): opt.literal = True
        elif a == "--hidden": opt.hidden = True
        elif a in ("--ignore", "--ignore-dir"): opt.ignores.append(need())
        elif a in ("-i", "--ignore-case"): opt.ignore_case = True; opt.case_sensitive = False
        elif a in ("-m", "--max-count"): opt.max_count = int(need())
        elif a == "--one-device": pass
        elif a in ("-p", "--path-to-ignore"): opt.path_to_ignore = need()
        elif a in ("-s", "--case-sensitive"): opt.case_sensitive = True; opt.ignore_case = False; opt.smart_case = False
        elif a in ("-S", "--smart-case"): opt.smart_case = True
        elif a == "--search-binary": opt.search_binary = True
        elif a in ("-t", "--all-text"): pass
        elif a in ("-u", "--unrestricted"): opt.unrestricted = True; opt.hidden = True; opt.search_binary = True
        elif a in ("-U", "--skip-vcs-ignores"): opt.skip_vcs_ignores = True
        elif a in ("-v", "--invert-match"): opt.invert = True
        elif a in ("-w", "--word-regexp"): opt.word = True
        elif a in ("-W", "--width"): opt.width = int(need())
        elif a in ("-z", "--search-zip"): opt.search_zip = True
        elif a in ("-n", "--norecurse"): opt.recurse = False
        elif a in ("-r", "--recurse"): opt.recurse = True
        elif a.startswith("--workers") or a.startswith("--pager") or a in ("--nopager", "--parallel", "--mmap", "--nommap", "--multiline", "--nomultiline", "--affinity", "--noaffinity", "--print-long-lines"):
            if a in ("--workers", "--pager"): need()
        else:
            # Combined short options used by grep users, e.g. -in.
            if len(a) > 2 and a.startswith("-"):
                for ch in a[1:]:
                    if ch == "i": opt.ignore_case = True
                    elif ch == "s": opt.case_sensitive = True; opt.smart_case = False
                    elif ch == "v": opt.invert = True
                    elif ch == "w": opt.word = True
                    elif ch == "l": opt.files_with_matches = True
                    elif ch == "c": opt.count = True
                    elif ch == "n": opt.recurse = False
                    elif ch == "o": opt.only_matching = True
                    else:
                        sys.stderr.write(f"ERR: unknown option {a}\n"); raise SystemExit(1)
            else:
                sys.stderr.write(f"ERR: unknown option {a}\n"); raise SystemExit(1)
        i += 1
    return opt, rest


def print_file_types():
    print("The following file types are supported:")
    for name in sorted(k for k in FILE_TYPES if k != "actionscrit"):
        vals = FILE_TYPES[name]
        print(f"  --{name}")
        print("      " + "  ".join(vals))
        print()


def load_ignore_file(path):
    pats = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                s = line.strip()
                if not s or s.startswith("#"):
                    continue
                if s.startswith("!"):
                    continue
                pats.append(s)
    except OSError:
        pass
    return pats


def is_hidden(path):
    return any(part.startswith(".") and part not in (".", "..") for part in path.split(os.sep))


def pat_match(pat, name, rel):
    p = pat.strip()
    if not p:
        return False
    p = p.rstrip("/")
    if fnmatch.fnmatch(name, p) or fnmatch.fnmatch(rel, p):
        return True
    if "/" not in p and name == p:
        return True
    return False


def is_binary_bytes(bs):
    if b"\0" in bs:
        return True
    sample = bs[:4096]
    if not sample:
        return False
    bad = sum(1 for b in sample if b < 7 or (13 < b < 32))
    return bad / len(sample) > 0.30


def iter_files(paths, opt):
    roots = paths or ["."]
    global_ignores = list(opt.ignores)
    if opt.path_to_ignore:
        global_ignores += load_ignore_file(opt.path_to_ignore)
    home = os.environ.get("HOME")
    if home and not opt.unrestricted:
        global_ignores += load_ignore_file(os.path.join(home, ".agignore"))
    for root in roots:
        if root == "-":
            yield "-"
            continue
        if os.path.isfile(root) or (os.path.islink(root) and not os.path.isdir(root)):
            yield root
            continue
        for dirpath, dirnames, filenames in os.walk(root, followlinks=opt.follow):
            rel_dir = os.path.relpath(dirpath, root)
            depth = 0 if rel_dir == "." else rel_dir.count(os.sep) + 1
            ignores = list(global_ignores)
            if not opt.unrestricted:
                ignores += load_ignore_file(os.path.join(dirpath, ".ignore"))
                if not opt.skip_vcs_ignores:
                    ignores += load_ignore_file(os.path.join(dirpath, ".gitignore"))
                    ignores += load_ignore_file(os.path.join(dirpath, ".hgignore"))
            keep_dirs = []
            for d in dirnames:
                full = os.path.join(dirpath, d)
                rel = os.path.relpath(full, root)
                if not opt.hidden and d.startswith("."):
                    continue
                if not opt.unrestricted and d in (".git", ".hg", ".svn"):
                    continue
                if opt.depth >= 0 and depth >= opt.depth:
                    continue
                if not opt.unrestricted and any(pat_match(p, d, rel) for p in ignores):
                    continue
                keep_dirs.append(d)
            dirnames[:] = sorted(keep_dirs)
            for fn in sorted(filenames):
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, root)
                disp = rel if root != "." else rel
                if not opt.hidden and is_hidden(rel):
                    continue
                if not opt.unrestricted and any(pat_match(p, fn, rel) for p in ignores):
                    continue
                if opt.file_pattern and not safe_search(opt.file_pattern, rel):
                    continue
                if opt.type_exts and not type_ok(fn, opt.type_exts):
                    continue
                yield disp if root == "." else full


def type_ok(fn, exts):
    base = os.path.basename(fn)
    return any(base == x or base.endswith(x) for x in exts)


def safe_search(pattern, text):
    try:
        return re.search(pattern, text) is not None
    except re.error:
        return pattern in text


def read_text(path, opt):
    try:
        if path == "-":
            data = sys.stdin.buffer.read()
        elif opt.search_zip and path.endswith(".gz"):
            data = gzip.open(path, "rb").read()
        elif opt.search_zip and (path.endswith(".xz") or path.endswith(".lzma")):
            data = lzma.open(path, "rb").read()
        else:
            with open(path, "rb") as f:
                data = f.read()
    except OSError as e:
        if not opt.silent:
            sys.stderr.write(f"ERR: Error opening {path}: {e}\n")
        return None
    if not opt.search_binary and path != "-" and is_binary_bytes(data):
        return None
    return data.decode("utf-8", errors="replace")


def compile_pattern(pat, opt):
    if opt.literal:
        pat = re.escape(pat)
    if opt.word:
        pat = r"\b(?:" + pat + r")\b"
    flags = re.MULTILINE
    if opt.ignore_case or (opt.smart_case and not opt.case_sensitive and not any(c.isupper() for c in pat)):
        flags |= re.IGNORECASE
    try:
        return re.compile(pat, flags)
    except re.error as e:
        sys.stderr.write(f"ERR: Error in regex: {e}\n")
        raise SystemExit(1)


def line_spans(text):
    pos = 0
    for idx, line in enumerate(text.splitlines(True), 1):
        raw = line[:-1] if line.endswith("\n") else line
        if raw.endswith("\r"):
            raw = raw[:-1]
        yield idx, raw, pos
        pos += len(line)
    if text == "":
        return


def matches_for_file(path, text, rx, opt):
    rows = []
    total = 0
    if opt.invert:
        for ln, line, start in line_spans(text):
            has = rx.search(line) is not None
            if not has:
                rows.append((ln, line, [(0, len(line))]))
                total += 1
                if opt.max_count and total >= opt.max_count:
                    break
        return rows, total
    for ln, line, start in line_spans(text):
        ms = list(rx.finditer(line))
        if not ms:
            continue
        spans = [(m.start(), m.end()) for m in ms if m.end() >= m.start()]
        if not spans:
            continue
        rows.append((ln, line, spans))
        total += len(spans)
        if opt.max_count and total >= opt.max_count:
            break
    return rows, total


def truncate(line, opt):
    if opt.width is not None and len(line) > opt.width:
        return line[:opt.width]
    return line


def colorize(line, spans, opt):
    if not opt.color:
        return line
    out = []
    last = 0
    for a, b in spans:
        out.append(line[last:a])
        out.append("\033[30;43m" + line[a:b] + "\033[0m")
        last = b
    out.append(line[last:])
    return "".join(out)


def emit_name(name, opt):
    end = "\0" if opt.null else "\n"
    sys.stdout.write(name + end)


def print_stats(files, matches, start):
    elapsed = time.time() - start
    print(f"{files} files contained matches")
    print(f"{matches} matches")
    print(f"{elapsed:.6f} seconds")


def search_stream(pattern, opt):
    rx = compile_pattern(pattern, opt)
    text = read_text("-", opt) or ""
    rows, total = matches_for_file("-", text, rx, opt)
    rowmap = {ln: (line, spans) for ln, line, spans in rows}
    anyhit = total > 0
    for ln, line, _ in line_spans(text):
        hit = ln in rowmap
        if not hit and not opt.passthrough:
            continue
        spans = rowmap.get(ln, (line, []))[1]
        if opt.only_matching and hit:
            for a, b in spans:
                print(line[a:b])
            continue
        prefix = ""
        if opt.numbers:
            prefix += f"{ln}:"
        elif opt.column and hit:
            prefix += f"{spans[0][0]+1}:"
        print(prefix + colorize(truncate(line, opt), spans, opt))
    return 0 if anyhit else 1


def rel_display(path):
    if path.startswith("./"):
        return path[2:]
    return path


def main(argv):
    opt, rest = parse_args(argv)
    if opt.name_pattern is not None:
        paths = rest or ["."]
        try:
            rx = re.compile(opt.name_pattern)
        except re.error:
            rx = re.compile(re.escape(opt.name_pattern))
        found = False
        for p in iter_files(paths, opt):
            name = rel_display(p)
            if rx.search(name):
                emit_name(name, opt); found = True
        return 0 if found else 1
    if not rest:
        print(HELP, end="")
        return 1
    pattern, paths = rest[0], rest[1:]
    st = os.fstat(0)
    stdin_has_data = (stat.S_ISFIFO(st.st_mode) or stat.S_ISSOCK(st.st_mode) or (stat.S_ISREG(st.st_mode) and st.st_size > 0))
    if not paths and not sys.stdin.isatty() and stdin_has_data:
        return search_stream(pattern, opt)
    if not paths:
        paths = ["."]
    single_file = len(paths) == 1 and os.path.isfile(paths[0])
    show_filename = opt.filename if opt.filename is not None else not single_file
    use_heading = opt.heading and opt.group and show_filename and not (opt.count or opt.files_with_matches or opt.files_without_matches or opt.vimgrep or opt.only_matching)
    rx = compile_pattern(pattern, opt)
    files = list(iter_files(paths, opt))
    found_any = False
    printed_file = False
    files_with = 0
    match_count = 0
    start = time.time()
    for path in files:
        text = read_text(path, opt)
        if text is None:
            continue
        rows, total = matches_for_file(path, text, rx, opt)
        has = total > 0
        if has:
            files_with += 1; match_count += total
            if not opt.files_without_matches:
                found_any = True
        name = rel_display(path)
        if opt.files_with_matches:
            if has:
                emit_name(name, opt)
            continue
        if opt.files_without_matches:
            if not has:
                emit_name(name, opt); found_any = True
            continue
        if opt.count or (opt.stats_only and single_file):
            if show_filename:
                print(f"{name}:{total}")
            else:
                print(total)
            continue
        if opt.stats_only:
            continue
        if not has and not opt.print_all_files:
            continue
        if use_heading:
            if printed_file and opt.breaks:
                print()
            print(name)
            printed_file = True
        row_by_ln = {ln: (line, spans) for ln, line, spans in rows}
        out_lines = []
        if opt.before or opt.after:
            all_lines = list(line_spans(text))
            wanted = {}
            for ln, _, _ in rows:
                for n in range(max(1, ln - opt.before), ln + opt.after + 1):
                    wanted[n] = True
            for ln, line, _ in all_lines:
                if ln not in wanted:
                    continue
                spans = row_by_ln.get(ln, (line, []))[1]
                out_lines.append((ln, line, spans, bool(spans)))
        else:
            out_lines = [(ln, line, spans, True) for ln, line, spans in rows]
        for ln, line, spans, is_match in out_lines:
            if opt.only_matching:
                for a, b in spans:
                    prefix = f"{name}:{ln}:" if show_filename else ""
                    print(prefix + line[a:b])
                continue
            if opt.vimgrep:
                for a, b in spans:
                    print(f"{name}:{ln}:{a+1}:{truncate(line, opt)}")
                continue
            sep = ":" if is_match else "-"
            pieces = []
            if not use_heading and show_filename:
                pieces.append(name)
            if opt.numbers is not False:
                pieces.append(str(ln))
            if opt.column and is_match:
                pieces.append(str(spans[0][0] + 1))
            prefix = (sep.join(pieces) + sep) if pieces else ""
            print(prefix + colorize(truncate(line, opt), spans if is_match else [], opt))
    if opt.stats or opt.stats_only:
        print_stats(files_with, match_count, start)
    return 0 if found_any else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
