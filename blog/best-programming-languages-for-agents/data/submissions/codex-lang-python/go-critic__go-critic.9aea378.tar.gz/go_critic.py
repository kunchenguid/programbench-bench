#!/usr/bin/env python3
import os
import re
import sys
from pathlib import Path

VERSION = "v0.0.0-SNAPSHOT"

CHECKERS = [
    ("appendAssign", "diagnostic"), ("appendCombine", "performance"),
    ("argOrder", "diagnostic"), ("assignOp", "style"), ("badCall", "diagnostic"),
    ("badCond", "diagnostic"), ("badLock", "diagnostic experimental"),
    ("badRegexp", "diagnostic experimental"), ("badSorting", "diagnostic experimental"),
    ("badSyncOnceFunc", "diagnostic experimental"), ("boolExprSimplify", "style experimental"),
    ("builtinShadow", "style opinionated"), ("builtinShadowDecl", "diagnostic experimental"),
    ("captLocal", "style"), ("caseOrder", "diagnostic"), ("codegenComment", "diagnostic"),
    ("commentFormatting", "style"), ("commentedOutCode", "diagnostic experimental"),
    ("commentedOutImport", "style experimental"), ("defaultCaseOrder", "style"),
    ("deferInLoop", "diagnostic experimental"), ("deferUnlambda", "style experimental"),
    ("deprecatedComment", "diagnostic"), ("docStub", "style experimental"),
    ("dupArg", "diagnostic"), ("dupBranchBody", "diagnostic"), ("dupCase", "diagnostic"),
    ("dupImport", "style experimental"), ("dupOption", "diagnostic experimental"),
    ("dupSubExpr", "diagnostic"), ("dynamicFmtString", "diagnostic experimental"),
    ("elseif", "style"), ("emptyDecl", "diagnostic experimental"),
    ("emptyFallthrough", "style experimental"), ("emptyStringTest", "style experimental"),
    ("equalFold", "performance experimental"), ("evalOrder", "diagnostic experimental"),
    ("exitAfterDefer", "diagnostic"), ("exposedSyncMutex", "style experimental"),
    ("externalErrorReassign", "diagnostic experimental"), ("filepathJoin", "diagnostic experimental"),
    ("flagDeref", "diagnostic"), ("flagName", "diagnostic"), ("hexLiteral", "style experimental"),
    ("httpNoBody", "style experimental"), ("hugeParam", "performance"),
    ("ifElseChain", "style"), ("importShadow", "style opinionated"),
    ("indexAlloc", "performance"), ("initClause", "style opinionated experimental"),
    ("mapKey", "diagnostic"), ("methodExprCall", "style experimental"),
    ("nestingReduce", "style opinionated experimental"), ("newDeref", "style"),
    ("nilValReturn", "diagnostic experimental"), ("octalLiteral", "style experimental opinionated"),
    ("offBy1", "diagnostic"), ("paramTypeCombine", "style opinionated"),
    ("preferDecodeRune", "performance experimental"), ("preferFilepathJoin", "style experimental"),
    ("preferFprint", "performance experimental"), ("preferStringWriter", "performance experimental"),
    ("preferWriteByte", "performance experimental opinionated"),
    ("ptrToRefParam", "style opinionated experimental"), ("rangeAppendAll", "diagnostic experimental"),
    ("rangeExprCopy", "performance"), ("rangeValCopy", "performance"),
    ("redundantSprint", "style experimental"), ("regexpMust", "style"),
    ("regexpPattern", "diagnostic experimental"), ("regexpSimplify", "style experimental opinionated"),
    ("returnAfterHttpError", "diagnostic experimental"), ("ruleguard", "style experimental"),
    ("singleCaseSwitch", "style"), ("sliceClear", "performance experimental"),
    ("sloppyLen", "diagnostic"), ("sloppyReassign", "diagnostic experimental"),
    ("sloppyTypeAssert", "diagnostic"), ("sortSlice", "diagnostic experimental"),
    ("sprintfQuotedString", "diagnostic experimental"), ("sqlQuery", "diagnostic experimental"),
    ("stringConcatSimplify", "style experimental"), ("stringXbytes", "performance"),
    ("stringsCompare", "style experimental"), ("switchTrue", "style"),
    ("syncMapLoadAndDelete", "diagnostic experimental"), ("timeExprSimplify", "style experimental"),
    ("todoCommentWithoutDetail", "style opinionated experimental"),
    ("tooManyResultsChecker", "style opinionated experimental"),
    ("truncateCmp", "diagnostic experimental"), ("typeAssertChain", "style experimental"),
    ("typeDefFirst", "style experimental"), ("typeSwitchVar", "style"),
    ("typeUnparen", "style opinionated"), ("uncheckedInlineErr", "diagnostic experimental"),
    ("underef", "style"), ("unlabelStmt", "style experimental"), ("unlambda", "style"),
    ("unnamedResult", "style opinionated experimental"),
    ("unnecessaryBlock", "style opinionated experimental"),
    ("unnecessaryDefer", "diagnostic experimental"), ("unslice", "style"),
    ("valSwap", "style"), ("weakCond", "diagnostic experimental"),
    ("whyNoLint", "style experimental"), ("wrapperFunc", "style"),
    ("yodaStyleExpr", "style experimental"), ("zeroByteRepeat", "performance"),
]

DEFAULT_ENABLED = "appendAssign,argOrder,assignOp,badCall,badCond,captLocal,caseOrder,codegenComment,commentFormatting,defaultCaseOrder,deprecatedComment,dupArg,dupBranchBody,dupCase,dupSubExpr,elseif,exitAfterDefer,flagDeref,flagName,ifElseChain,mapKey,newDeref,offBy1,regexpMust,singleCaseSwitch,sloppyLen,sloppyTypeAssert,switchTrue,typeSwitchVar,underef,unlambda,unslice,valSwap,wrapperFunc"

PARAM_HELP = """Usage of go-critic:
  -@captLocal.paramsOnly
    \twhether to restrict checker to params only (default true)
  -@commentedOutCode.minLength int
    \tmin length of the comment that triggers a warning (default 15)
  -@elseif.skipBalanced
    \twhether to skip balanced if-else pairs (default true)
  -@hugeParam.sizeThreshold int
    \tsize in bytes that makes the warning trigger (default 80)
  -@ifElseChain.minThreshold int
    \tmin number of if-else blocks that makes the warning trigger (default 2)
  -@rangeExprCopy.sizeThreshold int
    \tsize in bytes that makes the warning trigger (default 512)
  -@rangeExprCopy.skipTestFuncs
    \twhether to check test functions (default true)
  -@rangeValCopy.sizeThreshold int
    \tsize in bytes that makes the warning trigger (default 128)
  -@rangeValCopy.skipTestFuncs
    \twhether to check test functions (default true)
  -checkGenerated
    \twhether to check generated files
  -checkTests
    \twhether to check test files (default true)
  -concurrency int
    \thow many concurrent checkers to run (default is runtime.GOMAXPROCS(0))
  -cpuprofile string
    \twrite CPU profile to the specified file
  -disable string
    \tcomma-separated list of checkers to be disabled. Can include #tags
  -enable string
    \tcomma-separated list of enabled checkers. Can include #tags (default "%s")
  -enableAll
    \tidentical to -enable with all checkers listed. If true, -enable is ignored
  -exitCode int
    \texit code to be used when lint issues are found (default 1)
  -go string
    \tselect the Go version to target. Leave as string for the latest
  -memprofile string
    \twrite memory profile to the specified file
  -shorterErrLocation
    \twhether to replace error location prefix with $GOROOT and $GOPATH (default true)
  -v\twhether to print output useful during linter debugging""" % DEFAULT_ENABLED

DOCS = {
    "appendAssign": """appendAssign checker documentation
URL: https://github.com/go-critic/go-critic/checkers
Tags: [diagnostic]

Detects suspicious append result assignments.

Non-compliant code:
p.positives = append(p.negatives, x)
p.negatives = append(p.negatives, y)

Compliant code:
p.positives = append(p.positives, x)
p.negatives = append(p.negatives, y)""",
    "elseif": """elseif checker documentation
URL: https://github.com/go-critic/go-critic/checkers
Tags: [style]

Detects else with nested if statement that can be replaced with else-if.

Non-compliant code:
if cond1 {
} else {
\tif x := cond2; x {
\t}
}

Compliant code:
if cond1 {
} else if x := cond2; x {
}

Checker parameters:
  -@elseif.skipBalanced bool
    \twhether to skip balanced if-else pairs (default true)""",
    "rangeExprCopy": """rangeExprCopy checker documentation
URL: https://github.com/go-critic/go-critic/checkers
Tags: [performance]

Detects expensive copies of `for` loop range expressions.

Suggests to use pointer to array to avoid the copy using `&` on range expression.

Checker parameters:
  -@rangeExprCopy.sizeThreshold int
    \tsize in bytes that makes the warning trigger (default 512)
  -@rangeExprCopy.skipTestFuncs bool
    \twhether to check test functions (default true)""",
}


def usage():
    print(f"""Usage:

    go-critic <command> [arguments...]

The commands are:

    check             run linter over specified targets
    doc               get installed checkers documentation
    help              shows help message
    version           shows version of the application

Version: {VERSION}
""")


def checker_tags(name):
    for n, tags in CHECKERS:
        if n == name:
            return tags.split()
    return []


def expand_names(spec):
    out = set()
    if not spec:
        return out
    for item in spec.split(","):
        item = item.strip()
        if not item:
            continue
        if item.startswith("#"):
            tag = item[1:]
            out.update(n for n, tags in CHECKERS if tag in tags.split())
        else:
            out.add(item)
    return out


def collect_files(targets, check_tests=True, check_generated=False):
    if not targets:
        targets = ["."]
    files = []
    for target in targets:
        recursive = target.endswith("/...")
        base = target[:-4] if recursive else target
        p = Path(base)
        if recursive and p.is_dir():
            candidates = p.rglob("*.go")
        elif p.is_dir():
            candidates = p.glob("*.go")
        elif p.suffix == ".go":
            candidates = [p]
        else:
            continue
        for f in candidates:
            if not check_tests and f.name.endswith("_test.go"):
                continue
            try:
                text = f.read_text(errors="replace")
            except OSError:
                continue
            if not check_generated and re.search(r"Code generated .* DO NOT EDIT\.", text):
                continue
            files.append((f, text))
    return files


def line_col(text, offset):
    line = text.count("\n", 0, offset) + 1
    last = text.rfind("\n", 0, offset)
    return line, offset - last


def strip_strings(line):
    return re.sub(r'`[^`]*`|"([^"\\]|\\.)*"', '""', line)


def warn(path, line, col, checker, msg, warnings):
    warnings.append((str(path), line, col, checker, msg))


def run_checks(path, text, enabled):
    warnings = []
    lines = text.splitlines()
    for i, raw in enumerate(lines, 1):
        line = strip_strings(raw)
        code = line.split("//", 1)[0]

        if "appendAssign" in enabled:
            m = re.search(r"([\w.]+)\s*=\s*append\(([\w.]+)\s*,", code)
            if m and m.group(1) != m.group(2):
                warn(path, i, m.start(0)+1, "appendAssign", "append result not assigned to the same slice", warnings)

        if "assignOp" in enabled:
            m = re.search(r"\b([A-Za-z_]\w*(?:\[[^\]]+\])?)\s*=\s*\1\s*([+\-*/%&|^]|<<|>>)\s*([^=].*)", code)
            if m and "==" not in code:
                warn(path, i, m.start(0)+1, "assignOp", f"replace `{m.group(1)} = {m.group(1)} {m.group(2)} ...` with assignment operation", warnings)

        if "badCond" in enabled:
            m = re.search(r"\b([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)?)\s*(==|!=|<=|>=)\s*\1\b", code)
            if m:
                warn(path, i, m.start(0)+1, "badCond", "suspicious condition: identical expressions", warnings)

        if "dupSubExpr" in enabled:
            m = re.search(r"\b(.+?)\s*(&&|\|\|)\s*\1\b", code)
            if m:
                warn(path, i, m.start(0)+1, "dupSubExpr", "suspicious duplicated sub-expression", warnings)

        if "newDeref" in enabled:
            m = re.search(r"\*new\(([^)]+)\)", code)
            if m:
                warn(path, i, m.start(0)+1, "newDeref", "replace *new(T) with zero value", warnings)

        if "sloppyLen" in enabled:
            m = re.search(r"len\(([^)]+)\)\s*(==|<=)\s*0|0\s*(==|>=)\s*len\(([^)]+)\)", code)
            if m:
                warn(path, i, m.start(0)+1, "sloppyLen", "use len(x) == 0 or len(x) != 0 form consistently", warnings)

        if "switchTrue" in enabled and re.search(r"\bswitch\s+true\s*{", code):
            warn(path, i, code.find("switch")+1, "switchTrue", "omit true expression in switch statement", warnings)

        if "unslice" in enabled:
            m = re.search(r"\b([A-Za-z_]\w*)\[:\]", code)
            if m:
                warn(path, i, m.start(0)+1, "unslice", f"could simplify {m.group(0)} to {m.group(1)}", warnings)

        if "regexpMust" in enabled and "regexp.Compile(" in code:
            warn(path, i, code.find("regexp.Compile(")+1, "regexpMust", "use regexp.MustCompile for constant regexps", warnings)

        if "exitAfterDefer" in enabled and re.search(r"\b(os\.Exit|log\.Fatalf?|panic)\s*\(", code):
            prev = "\n".join(lines[max(0, i-8):i-1])
            if "defer " in prev:
                warn(path, i, code.find("(")+1, "exitAfterDefer", "defer will not run after this call", warnings)

        if "commentFormatting" in enabled:
            m = re.search(r"//[A-Za-z]", raw)
            if m:
                warn(path, i, m.start()+1, "commentFormatting", "put a space between `//` and comment text", warnings)

    if "elseif" in enabled:
        for m in re.finditer(r"}\s*else\s*{\s*\n\s*if\b", text):
            l, c = line_col(text, m.start())
            warn(path, l, c, "elseif", "can replace `else { if ... }` with `else if ...`", warnings)

    if "dupCase" in enabled or "caseOrder" in enabled:
        cases = {}
        for m in re.finditer(r"(?m)^\s*case\s+([^:\n]+):", text):
            vals = [v.strip() for v in m.group(1).split(",")]
            for v in vals:
                if v in cases and "dupCase" in enabled:
                    l, c = line_col(text, m.start())
                    warn(path, l, c, "dupCase", f"duplicate case {v}", warnings)
                cases[v] = m.start()

    if "singleCaseSwitch" in enabled:
        for m in re.finditer(r"switch[^{]*{([^{}]*)}", text, re.S):
            body = m.group(1)
            if len(re.findall(r"(?m)^\s*case\s+", body)) == 1 and "default:" not in body:
                l, c = line_col(text, m.start())
                warn(path, l, c, "singleCaseSwitch", "should use if statement instead of a single-case switch", warnings)

    if "valSwap" in enabled:
        pat = re.compile(r"(?m)^\s*(\w+)\s*,\s*(\w+)\s*=\s*\2\s*,\s*\1\s*$")
        for m in pat.finditer(text):
            l, c = line_col(text, m.start())
            warn(path, l, c, "valSwap", "use a dedicated swap operation form only when it improves clarity", warnings)

    return warnings


def parse_check(argv):
    enabled = expand_names(DEFAULT_ENABLED)
    exit_code = 1
    check_tests = True
    check_generated = False
    targets = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-help", "--help", "-h"):
            print(PARAM_HELP)
            print("parse args: flag: help requested")
            return None
        if not a.startswith("-"):
            targets.extend(argv[i:])
            break
        key, eq, val = a.partition("=")
        takes_value = key in ("-enable", "-disable", "-exitCode", "-concurrency", "-cpuprofile", "-memprofile", "-go")
        if takes_value and not eq:
            i += 1
            val = argv[i] if i < len(argv) else ""
        if key == "-enable":
            enabled = expand_names(val)
        elif key == "-disable":
            enabled -= expand_names(val)
        elif key == "-enableAll":
            enabled = {n for n, _ in CHECKERS}
        elif key == "-exitCode":
            try:
                exit_code = int(val)
            except ValueError:
                exit_code = 1
        elif key == "-checkTests":
            check_tests = False if val.lower() == "false" else True
        elif key == "-checkGenerated":
            check_generated = True
        elif key.startswith("-@") or key in ("-v", "-shorterErrLocation"):
            pass
        elif key in ("-concurrency", "-cpuprofile", "-memprofile", "-go"):
            pass
        else:
            print(f"flag provided but not defined: {key}")
            print(PARAM_HELP)
            print(f"parse args: flag provided but not defined: {key}")
            return None
        i += 1
    return enabled, exit_code, check_tests, check_generated, targets


def cmd_check(argv):
    parsed = parse_check(argv)
    if parsed is None:
        return 0
    enabled, exit_code, check_tests, check_generated, targets = parsed
    warnings = []
    for path, text in collect_files(targets, check_tests, check_generated):
        warnings.extend(run_checks(path, text, enabled))
    warnings.sort()
    for path, line, col, checker, msg in warnings:
        print(f"{path}:{line}:{col}: {checker}: {msg}")
    return exit_code if warnings else 0


def cmd_doc(argv):
    if argv and argv[0] in ("-help", "--help", "-h"):
        print("Usage of go-critic:")
        print("flag: help requested")
        return 0
    if len(argv) > 1:
        print("expected 0 or 1 positional arguments")
        return 0
    if not argv:
        for name, tags in CHECKERS:
            print(f"{name} [{tags}]")
        return 0
    name = argv[0]
    if name not in {n for n, _ in CHECKERS}:
        print(f'checker with name "{name}" not found')
        return 0
    if name in DOCS:
        print(DOCS[name])
    else:
        tags = " ".join(checker_tags(name))
        print(f"{name} checker documentation")
        print("URL: https://github.com/go-critic/go-critic/checkers")
        print(f"Tags: [{tags}]")
        print()
        print(f"Runs the {name} checker.")
    return 0


def main(argv):
    prog = "go-critic"
    if not argv:
        usage()
        return 0
    cmd = argv[0]
    if cmd == "help":
        usage()
        return 0
    if cmd == "version":
        print(f"{prog} version: {VERSION}")
        return 0
    if cmd == "doc":
        return cmd_doc(argv[1:])
    if cmd == "check":
        return cmd_check(argv[1:])
    if cmd.startswith("-"):
        print(f'"{cmd}" unknown command, did you mean "help"?')
        print(f'Run "{prog} help" for usage.')
        print()
        print(f'no such command "{cmd}"')
        return 0
    print(f'"{cmd}" unknown command')
    print(f'Run "{prog} help" for usage.')
    print()
    print(f'no such command "{cmd}"')
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
