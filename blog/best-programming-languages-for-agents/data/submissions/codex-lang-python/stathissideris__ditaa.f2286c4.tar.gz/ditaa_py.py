#!/usr/bin/env python3
import html
import math
import os
import re
import sys
from dataclasses import dataclass

HELP = """usage: java -jar ditaa.jar <INPFILE> [OUTFILE] [-A] [-b <BACKGROUND>] [-d]
       [-E] [-e <ENCODING>] [-h] [--help] [-o] [-r] [-S] [-s <SCALE>]
       [--svg] [--svg-font-url <FONT>] [-T] [-t <TABS>] [-v] [-W]
 -A,--no-antialias              Turns anti-aliasing off.
 -b,--background <BACKGROUND>   The background colour of the image. The
                                format should be a six-digit hexadecimal
                                number (as in HTML, FF0000 for red). Pass
                                an eight-digit hex to define transparency.
                                This is overridden by --transparent.
 -d,--debug                     Renders the debug grid over the resulting
                                image.
 -E,--no-separation             Prevents the separation of common edges of
                                shapes.
 -e,--encoding <ENCODING>       The encoding of the input file.
 -h,--html                      In this case the input is an HTML file.
                                The contents of the <pre
                                class="textdiagram"> tags are rendered as
                                diagrams and saved in the images directory
                                and a new HTML file is produced with the
                                appropriate <img> tags.
    --help                      Prints usage help.
 -o,--overwrite                 If the filename of the destination image
                                already exists, an alternative name is
                                chosen. If the overwrite option is
                                selected, the image file is instead
                                overwriten.
 -r,--round-corners             Causes all corners to be rendered as round
                                corners.
 -S,--no-shadows                Turns off the drop-shadow effect.
 -s,--scale <SCALE>             A natural number that determines the size
                                of the rendered image. The units are
                                fractions of the default size (2.5 renders
                                1.5 times bigger than the default).
    --svg                       Write an SVG image as destination file.
    --svg-font-url <FONT>       SVG font URL.
 -T,--transparent               Causes the diagram to be rendered on a
                                transparent background. Overrides
                                --background.
 -t,--tabs <TABS>               Tabs are normally interpreted as 8 spaces
                                but it is possible to change that using
                                this option. It is not advisable to use
                                tabs in your diagrams.
 -v,--verbose                   Makes ditaa more verbose.
 -W,--fixed-slope               Makes sides of parallelograms and
                                trapezoids fixed slope instead of fixed
                                width."""

VERSION = "ditaa version 0.11, Copyright (C) 2004--2017  Efstathios (Stathis) Sideris"
COLORS = {
    "cRED": "#ff9999", "cGRE": "#99ff99", "cBLU": "#9999ff",
    "cPNK": "#ff99ff", "cYEL": "#ffff99", "cBLK": "#000000",
}
LINE_CHARS = set("|:-=+/\\<>^v*")


@dataclass
class Opts:
    infile: str = ""
    outfile: str = ""
    svg: bool = False
    html_mode: bool = False
    overwrite: bool = False
    scale: float = 1.0
    tabs: int = 8
    encoding: str = "utf-8"
    background: str = "#ffffff"
    transparent: bool = False
    shadows: bool = True
    round_corners: bool = False
    debug: bool = False
    font_url: str = ""


@dataclass
class Rect:
    x1: int
    y1: int
    x2: int
    y2: int
    fill: str = "white"
    kind: str = "rect"


def parse_args(argv):
    if not argv or "--help" in argv:
        print(HELP)
        raise SystemExit(0)
    opts = Opts()
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-A", "--no-antialias", "-E", "--no-separation", "-v", "--verbose", "-W", "--fixed-slope"):
            i += 1
        elif a in ("-S", "--no-shadows"):
            opts.shadows = False; i += 1
        elif a in ("-r", "--round-corners"):
            opts.round_corners = True; i += 1
        elif a in ("-d", "--debug"):
            opts.debug = True; i += 1
        elif a in ("-T", "--transparent"):
            opts.transparent = True; i += 1
        elif a in ("-h", "--html"):
            opts.html_mode = True; i += 1
        elif a == "--svg":
            opts.svg = True; i += 1
        elif a in ("-o", "--overwrite"):
            opts.overwrite = True; i += 1
        elif a in ("-s", "--scale", "-t", "--tabs", "-e", "--encoding", "-b", "--background", "--svg-font-url"):
            if i + 1 >= len(argv):
                print(f"Missing argument for option: {a}", file=sys.stderr)
                raise SystemExit(2)
            v = argv[i + 1]
            if a in ("-s", "--scale"):
                opts.scale = float(v)
            elif a in ("-t", "--tabs"):
                opts.tabs = int(v)
            elif a in ("-e", "--encoding"):
                opts.encoding = v
            elif a in ("-b", "--background"):
                opts.background = parse_color(v)
            else:
                opts.font_url = v
            i += 2
        elif a.startswith("-"):
            print(f"Unrecognized option: {a}")
            print(HELP)
            raise SystemExit(2)
        else:
            files.append(a); i += 1
    if not files:
        print(HELP)
        raise SystemExit(0)
    opts.infile = files[0]
    if len(files) > 1:
        opts.outfile = files[1]
    else:
        root, _ = os.path.splitext(opts.infile)
        opts.outfile = root + (".svg" if opts.svg else ".png")
    opts.outfile = choose_outfile(opts.outfile, opts.overwrite)
    return opts


def parse_color(s):
    s = s.strip().lstrip("#")
    if len(s) in (6, 8) and re.fullmatch(r"[0-9a-fA-F]+", s):
        return "#" + s.lower()
    return "#ffffff"


def choose_outfile(path, overwrite):
    if overwrite or not os.path.exists(path):
        return path
    root, ext = os.path.splitext(path)
    n = 2
    while os.path.exists(f"{root}_{n}{ext}"):
        n += 1
    return f"{root}_{n}{ext}"


def read_diagram(path, encoding, tabs):
    with open(path, "r", encoding=encoding, errors="replace") as f:
        text = f.read().expandtabs(tabs)
    return text.splitlines()


def padded_grid(lines):
    w = max([len(x) for x in lines] or [1])
    return [list(x.ljust(w)) for x in lines], w, max(len(lines), 1)


def dimensions(w, h, scale=1.0):
    return int(round((w * 10 + 40) * scale)), int(round((h * 14 + 56) * scale))


def xy(c, r):
    return 25 + c * 10, 35 + r * 14


def is_h(ch):
    return ch in "-=+*<>"


def is_v(ch):
    return ch in "|:+*^v"


def find_rects(grid, w, h):
    rects = []
    used = set()
    for y1 in range(h):
        for x1 in range(w):
            if grid[y1][x1] not in "+/\\":
                continue
            for x2 in range(w - 1, x1 + 1, -1):
                if grid[y1][x2] not in "+/\\":
                    continue
                if not all(is_h(grid[y1][x]) or grid[y1][x] in "/\\" for x in range(x1 + 1, x2)):
                    continue
                for y2 in range(h - 1, y1 + 1, -1):
                    if grid[y2][x1] not in "+/\\" or grid[y2][x2] not in "+/\\":
                        continue
                    if not all(is_h(grid[y2][x]) or grid[y2][x] in "/\\" for x in range(x1 + 1, x2)):
                        continue
                    if not all(is_v(grid[y][x1]) or grid[y][x1] in "/\\" for y in range(y1 + 1, y2)):
                        continue
                    if not all(is_v(grid[y][x2]) or grid[y][x2] in "/\\" for y in range(y1 + 1, y2)):
                        continue
                    if (x1, y1, x2, y2) not in used:
                        used.add((x1, y1, x2, y2))
                        rects.append(Rect(x1, y1, x2, y2))
                    break
    # prefer outer/larger first for drawing, but avoid too many nested duplicates
    rects.sort(key=lambda r: (-(r.x2-r.x1)*(r.y2-r.y1), r.y1, r.x1))
    for r in rects:
        inside = "\n".join("".join(grid[y][r.x1:r.x2+1]) for y in range(r.y1, r.y2+1))
        for code, col in COLORS.items():
            if code in inside:
                r.fill = col
        kind_map = [("{io}", "io"), ("{tr}", "tr"), ("{mo}", "mo"), ("{c}", "choice"),
                    ("{d}", "document"), ("{s}", "storage"), ("{o}", "ellipse")]
        for mark, kind in kind_map:
            if mark in inside:
                r.kind = kind
                break
    return rects[:100]


def text_runs(grid, w, h):
    hidden = [row[:] for row in grid]
    for y in range(h):
        s = "".join(hidden[y])
        for m in re.finditer(r"c(?:RED|GRE|BLU|PNK|YEL|BLK)|\{(?:d|s|o|mo|c|tr|io)\}", s):
            for x in range(m.start(), min(m.end(), w)):
                hidden[y][x] = " "
    runs = []
    for y in range(h):
        x = 0
        while x < w:
            while x < w and (hidden[y][x] == " " or hidden[y][x] in LINE_CHARS):
                x += 1
            st = x
            while x < w and hidden[y][x] != " " and hidden[y][x] not in LINE_CHARS:
                x += 1
            if x > st:
                runs.append((st, y, "".join(hidden[y][st:x])))
    return runs


def rect_path(r, scale=1.0):
    x1, y1 = xy(r.x1, r.y1); x2, y2 = xy(r.x2, r.y2)
    if r.kind == "ellipse":
        return None
    if r.kind == "choice":
        mx, my = (x1+x2)/2, (y1+y2)/2
        return [(mx, y1), (x2, my), (mx, y2), (x1, my)]
    if r.kind == "io":
        sl = min(18, max(8, (x2-x1)*0.22))
        return [(x1+sl, y1), (x2, y1), (x2-sl, y2), (x1, y2)]
    if r.kind == "tr":
        sl = min(18, max(8, (x2-x1)*0.22))
        return [(x1+sl, y1), (x2-sl, y1), (x2, y2), (x1, y2)]
    if r.kind == "mo":
        sl = min(18, max(8, (x2-x1)*0.22))
        return [(x1+sl, y1), (x2, y1), (x2, y2), (x1, y2)]
    return [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]


def render_svg(lines, opts):
    grid, w, h = padded_grid(lines)
    width, height = dimensions(w, h, opts.scale)
    sx = opts.scale
    rects = find_rects(grid, w, h)
    bg = "none" if opts.transparent else opts.background
    out = ["<?xml version='1.0' encoding='UTF-8' standalone='no'?>",
           "<svg ",
           "    xmlns='http://www.w3.org/2000/svg'",
           f"    width='{width}'",
           f"    height='{height}'",
           "    shape-rendering='geometricPrecision'",
           "    version='1.0'>",
           "  <defs>",
           "    <filter id='f2' x='0' y='0' width='200%' height='200%'>",
           "      <feOffset result='offOut' in='SourceGraphic' dx='5' dy='5' />",
           "      <feGaussianBlur result='blurOut' in='offOut' stdDeviation='3' />",
           "      <feBlend in='SourceGraphic' in2='blurOut' mode='normal' />",
           "    </filter>",
           "  </defs>",
           "  <g stroke-width='1' stroke-linecap='square' stroke-linejoin='round'>"]
    if bg != "none":
        out.append(f"    <rect x='0' y='0' width='{width}' height='{height}' style='fill: {bg}'/>")
    for r in rects:
        draw_svg_shape(out, r, sx, shadow=opts.shadows)
    draw_svg_lines(out, grid, w, h, sx)
    for x, y, t in text_runs(grid, w, h):
        px, py = xy(x, y)
        out.append(f"    <text x='{int(px*sx)}' y='{int((py+5)*sx)}' font-family='Courier' font-size='{int(15*sx)}' stroke='none' fill='#000000' ><![CDATA[{t}]]></text>")
    if opts.debug:
        for x in range(w + 1):
            px = (20 + x * 10) * sx
            out.append(f"    <line x1='{px}' y1='0' x2='{px}' y2='{height}' stroke='#dddddd' stroke-width='0.5'/>")
        for y in range(h + 1):
            py = (28 + y * 14) * sx
            out.append(f"    <line x1='0' y1='{py}' x2='{width}' y2='{py}' stroke='#dddddd' stroke-width='0.5'/>")
    out += ["  </g>", "</svg>"]
    return "\n".join(out) + "\n"


def svg_points(points, sx):
    return " ".join(f"{x*sx:.1f},{y*sx:.1f}" for x, y in points)


def draw_svg_shape(out, r, sx, shadow=True):
    x1, y1 = xy(r.x1, r.y1); x2, y2 = xy(r.x2, r.y2)
    fill = r.fill
    if r.kind == "ellipse" or r.kind == "storage":
        cx, cy, rx, ry = (x1+x2)/2*sx, (y1+y2)/2*sx, abs(x2-x1)/2*sx, abs(y2-y1)/2*sx
        if shadow:
            out.append(f"    <ellipse cx='{cx+5*sx:.1f}' cy='{cy+5*sx:.1f}' rx='{rx:.1f}' ry='{ry:.1f}' stroke='gray' fill='gray' filter='url(#f2)' />")
        out.append(f"    <ellipse cx='{cx:.1f}' cy='{cy:.1f}' rx='{rx:.1f}' ry='{ry:.1f}' stroke='#000000' stroke-width='{sx:.1f}' fill='{fill}' />")
        if r.kind == "storage":
            out.append(f"    <path d='M{x1*sx:.1f} {(y1+10)*sx:.1f} C{(x1+x2)/2*sx:.1f} {(y1+20)*sx:.1f} {(x1+x2)/2*sx:.1f} {(y1+20)*sx:.1f} {x2*sx:.1f} {(y1+10)*sx:.1f}' stroke='#000000' fill='none'/>")
        return
    pts = rect_path(r)
    pstr = svg_points(pts, sx)
    if shadow:
        shadow_pts = [(x+5, y+5) for x, y in pts]
        out.append(f"    <polygon points='{svg_points(shadow_pts, sx)}' stroke='gray' fill='gray' filter='url(#f2)' />")
    out.append(f"    <polygon points='{pstr}' stroke='#000000' stroke-width='{sx:.1f}' stroke-linecap='round' stroke-linejoin='round' fill='{fill}' />")
    if r.kind == "document":
        out.append(f"    <path d='M{x1*sx:.1f} {y2*sx:.1f} C{(x1+15)*sx:.1f} {(y2-8)*sx:.1f} {(x2-15)*sx:.1f} {(y2+8)*sx:.1f} {x2*sx:.1f} {y2*sx:.1f}' stroke='#000000' fill='none' />")


def draw_svg_lines(out, grid, w, h, sx):
    for y, row in enumerate(grid):
        x = 0
        while x < w:
            if row[x] in "-=*":
                st = x
                dashed = row[x] == "="
                while x + 1 < w and row[x + 1] in "-=+*<>":
                    x += 1
                    dashed = dashed or row[x] == "="
                x1, y1 = xy(st, y); x2, _ = xy(x, y)
                dash = " stroke-dasharray='5,5'" if dashed else ""
                out.append(f"    <line x1='{x1*sx:.1f}' y1='{y1*sx:.1f}' x2='{x2*sx:.1f}' y2='{y1*sx:.1f}' stroke='#000000' stroke-width='{sx:.1f}'{dash}/>")
            x += 1
    for x in range(w):
        y = 0
        while y < h:
            if grid[y][x] in "|:*":
                st = y
                dashed = grid[y][x] == ":"
                while y + 1 < h and grid[y + 1][x] in "|:+*^v":
                    y += 1
                    dashed = dashed or grid[y][x] == ":"
                x1, y1 = xy(x, st); _, y2 = xy(x, y)
                dash = " stroke-dasharray='5,5'" if dashed else ""
                out.append(f"    <line x1='{x1*sx:.1f}' y1='{y1*sx:.1f}' x2='{x1*sx:.1f}' y2='{y2*sx:.1f}' stroke='#000000' stroke-width='{sx:.1f}'{dash}/>")
            y += 1
    for y in range(h):
        for x in range(w):
            ch = grid[y][x]
            px, py = xy(x, y)
            if ch == "/":
                out.append(f"    <line x1='{(px+5)*sx:.1f}' y1='{(py+7)*sx:.1f}' x2='{(px-5)*sx:.1f}' y2='{(py+7+14)*sx:.1f}' stroke='#000000' stroke-width='{sx:.1f}'/>")
            elif ch == "\\":
                out.append(f"    <line x1='{(px-5)*sx:.1f}' y1='{(py+7)*sx:.1f}' x2='{(px+5)*sx:.1f}' y2='{(py+7+14)*sx:.1f}' stroke='#000000' stroke-width='{sx:.1f}'/>")
            elif ch in "><^v":
                arrow_svg(out, px*sx, py*sx, ch, sx)
            elif ch == "*":
                out.append(f"    <circle cx='{px*sx:.1f}' cy='{py*sx:.1f}' r='{3*sx:.1f}' fill='#000000'/>")


def arrow_svg(out, x, y, ch, sx):
    s = 5 * sx
    if ch == ">":
        pts = [(x-s, y-s), (x+s, y), (x-s, y+s)]
    elif ch == "<":
        pts = [(x+s, y-s), (x-s, y), (x+s, y+s)]
    elif ch == "^":
        pts = [(x-s, y+s), (x, y-s), (x+s, y+s)]
    else:
        pts = [(x-s, y-s), (x, y+s), (x+s, y-s)]
    out.append(f"    <polygon points='{svg_points(pts, 1)}' fill='#000000' />")


def render_png(lines, opts, path):
    from PIL import Image, ImageDraw, ImageFont
    grid, w, h = padded_grid(lines)
    width, height = dimensions(w, h, opts.scale)
    bg = (255, 255, 255, 0) if opts.transparent else hex_rgba(opts.background)
    im = Image.new("RGBA", (width, height), bg)
    draw = ImageDraw.Draw(im)
    sx = opts.scale
    font = load_font(int(max(8, 15 * sx)))
    rects = find_rects(grid, w, h)
    for r in rects:
        draw_pil_shape(draw, r, sx, opts.shadows)
    draw_pil_lines(draw, grid, w, h, sx)
    for x, y, t in text_runs(grid, w, h):
        px, py = xy(x, y)
        draw.text((px*sx, (py-9)*sx), t, fill=(0, 0, 0, 255), font=font)
    if opts.debug:
        for x in range(w + 1):
            px = (20 + x * 10) * sx
            draw.line((px, 0, px, height), fill=(220, 220, 220, 255))
        for y in range(h + 1):
            py = (28 + y * 14) * sx
            draw.line((0, py, width, py), fill=(220, 220, 220, 255))
    im.save(path)


def hex_rgba(c):
    c = c.lstrip("#")
    if len(c) == 8:
        return tuple(int(c[i:i+2], 16) for i in (0, 2, 4, 6))
    if len(c) == 6:
        return tuple(int(c[i:i+2], 16) for i in (0, 2, 4)) + (255,)
    return (255, 255, 255, 255)


def load_font(size):
    from PIL import ImageFont
    for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
              "/usr/share/fonts/truetype/liberation2/LiberationMono-Regular.ttf"]:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def pil_scaled(points, sx):
    return [(x*sx, y*sx) for x, y in points]


def draw_pil_shape(draw, r, sx, shadow=True):
    x1, y1 = xy(r.x1, r.y1); x2, y2 = xy(r.x2, r.y2)
    fill = hex_rgba(r.fill) if r.fill.startswith("#") else (255, 255, 255, 255)
    if r.kind in ("ellipse", "storage"):
        box = [x1*sx, y1*sx, x2*sx, y2*sx]
        if shadow:
            draw.ellipse([v + (5*sx if i < 2 else 5*sx) for i, v in enumerate(box)], fill=(128,128,128,80))
        draw.ellipse(box, fill=fill, outline=(0,0,0,255), width=max(1, int(sx)))
        if r.kind == "storage":
            draw.arc([x1*sx, y1*sx, x2*sx, (y1+20)*sx], 0, 180, fill=(0,0,0,255), width=max(1, int(sx)))
        return
    pts = rect_path(r)
    if shadow:
        draw.polygon(pil_scaled([(x+5, y+5) for x, y in pts], sx), fill=(128,128,128,80))
    draw.polygon(pil_scaled(pts, sx), fill=fill, outline=(0,0,0,255))
    if r.kind == "document":
        draw.arc([x1*sx, (y2-12)*sx, x2*sx, (y2+12)*sx], 0, 180, fill=(0,0,0,255), width=max(1, int(sx)))


def draw_pil_lines(draw, grid, w, h, sx):
    black = (0, 0, 0, 255)
    width = max(1, int(round(sx)))
    for y, row in enumerate(grid):
        x = 0
        while x < w:
            if row[x] in "-=*":
                st = x; dashed = row[x] == "="
                while x + 1 < w and row[x + 1] in "-=+*<>":
                    x += 1; dashed = dashed or row[x] == "="
                x1, y1 = xy(st, y); x2, _ = xy(x, y)
                draw_segment(draw, (x1*sx, y1*sx), (x2*sx, y1*sx), black, width, dashed)
            x += 1
    for x in range(w):
        y = 0
        while y < h:
            if grid[y][x] in "|:*":
                st = y; dashed = grid[y][x] == ":"
                while y + 1 < h and grid[y + 1][x] in "|:+*^v":
                    y += 1; dashed = dashed or grid[y][x] == ":"
                x1, y1 = xy(x, st); _, y2 = xy(x, y)
                draw_segment(draw, (x1*sx, y1*sx), (x1*sx, y2*sx), black, width, dashed)
            y += 1
    for y in range(h):
        for x in range(w):
            ch = grid[y][x]
            px, py = xy(x, y)
            if ch == "/":
                draw.line(((px+5)*sx, (py-7)*sx, (px-5)*sx, (py+7)*sx), fill=black, width=width)
            elif ch == "\\":
                draw.line(((px-5)*sx, (py-7)*sx, (px+5)*sx, (py+7)*sx), fill=black, width=width)
            elif ch in "><^v":
                arrow_pil(draw, px*sx, py*sx, ch, sx)
            elif ch == "*":
                r = 3*sx
                draw.ellipse((px*sx-r, py*sx-r, px*sx+r, py*sx+r), fill=black)


def draw_segment(draw, p1, p2, color, width, dashed=False):
    if not dashed:
        draw.line((*p1, *p2), fill=color, width=width)
        return
    x1, y1 = p1; x2, y2 = p2
    dist = math.hypot(x2-x1, y2-y1)
    if dist == 0:
        return
    dx, dy = (x2-x1)/dist, (y2-y1)/dist
    pos = 0
    while pos < dist:
        end = min(pos + 6, dist)
        draw.line((x1+dx*pos, y1+dy*pos, x1+dx*end, y1+dy*end), fill=color, width=width)
        pos += 12


def arrow_pil(draw, x, y, ch, sx):
    s = 5*sx
    if ch == ">": pts = [(x-s,y-s),(x+s,y),(x-s,y+s)]
    elif ch == "<": pts = [(x+s,y-s),(x-s,y),(x+s,y+s)]
    elif ch == "^": pts = [(x-s,y+s),(x,y-s),(x+s,y+s)]
    else: pts = [(x-s,y-s),(x,y+s),(x+s,y-s)]
    draw.polygon(pts, fill=(0,0,0,255))


def process_html(opts):
    with open(opts.infile, "r", encoding=opts.encoding, errors="replace") as f:
        source = f.read()
    outdir = os.path.join(os.path.dirname(os.path.abspath(opts.outfile)), "images")
    os.makedirs(outdir, exist_ok=True)
    count = 0
    def repl(m):
        nonlocal count
        attrs, body = m.group(1), html.unescape(m.group(2))
        mid = re.search(r"""id\s*=\s*['"]([^'"]+)['"]""", attrs)
        name = (mid.group(1) if mid else f"ditaa_diagram_{count}") + (".svg" if opts.svg else ".png")
        count += 1
        img_path = os.path.join(outdir, name)
        child = Opts(**opts.__dict__)
        child.outfile = img_path
        child.overwrite = opts.overwrite
        if opts.overwrite or not os.path.exists(img_path):
            if opts.svg:
                with open(img_path, "w", encoding="utf-8") as f:
                    f.write(render_svg(body.splitlines(), child))
            else:
                render_png(body.splitlines(), child, img_path)
        rel = "images/" + name
        return f'<img src="{html.escape(rel)}" />'
    new = re.sub(r"<pre([^>]*class=['\"][^'\"]*textdiagram[^'\"]*['\"][^>]*)>(.*?)</pre>", repl, source, flags=re.I|re.S)
    with open(opts.outfile, "w", encoding=opts.encoding, errors="replace") as f:
        f.write(new)


def main(argv):
    opts = parse_args(argv)
    print()
    print(VERSION)
    print()
    print("Running with options:")
    if opts.svg:
        print("svg")
    if opts.overwrite:
        print("overwrite")
    if opts.transparent:
        print("transparent")
    print(f"Reading file: {opts.infile}")
    if opts.html_mode:
        print(f"Rendering to file: {opts.outfile}")
        process_html(opts)
    else:
        lines = read_diagram(opts.infile, opts.encoding, opts.tabs)
        print(f"Rendering to file: {opts.outfile}")
        if opts.svg:
            with open(opts.outfile, "w", encoding="utf-8") as f:
                f.write(render_svg(lines, opts))
        else:
            render_png(lines, opts, opts.outfile)
    print("Done in 0sec")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BrokenPipeError:
        pass
