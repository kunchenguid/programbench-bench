#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
from pathlib import Path

BLUE = "\033[0;34m"
RED = "\033[0;31m"
RESET = "\033[0m"


HELP = f"""{BLUE}________      _____ 
______(_)_______  /_
_____  /_  __ \\  __/
____  / / /_/ / /_  
___  /  \\____/\\__/  
/___/         ᵥ₀.₁.₂  
{RESET}         

usage: jt <command>

{BLUE}commands:{RESET}

create items
    {BLUE}vault{RESET}, {BLUE}vl{RESET}       create a vault or list vaults
    create items in current folder
        {BLUE}note{RESET}, {BLUE}nt{RESET}        create a note 
        {BLUE}folder{RESET}, {BLUE}fd{RESET}      create a folder

interact with items
    {BLUE}enter{RESET}, {BLUE}en{RESET}       enter a vault
    {BLUE}open{RESET}, {BLUE}op{RESET}        open a note from current folder
    {BLUE}opdir{RESET}, {BLUE}od{RESET}       open current folder in file explorer
    {BLUE}chdir{RESET}, {BLUE}cd{RESET}       change folder within current vault
    {BLUE}list{RESET}, {BLUE}ls{RESET}        list items in current folder

perform fs operations on items
    {BLUE}remove{RESET}, {BLUE}rm{RESET}      remove an item 
    {BLUE}rename{RESET}, {BLUE}rn{RESET}      rename an item 
    {BLUE}move{RESET}, {BLUE}mv{RESET}        move an item to a new location
    {BLUE}vmove{RESET}, {BLUE}vm{RESET}       move an item to a different vault

config
    {BLUE}config{RESET}, {BLUE}cf{RESET}      display, set or open config

get help 
    use {BLUE}help{RESET} or {BLUE}-h{RESET} and {BLUE}--help{RESET} flags along with a command to get corresponding help"""

CMD_HELP = {
    "vault": """executable-vault 
create a vault or list vaults

USAGE:
    jt vault
    jt vault -l
    jt vault <vault name> <vault location>

ARGS:
    <vault name>        name for new vault
    <vault location>    absolute path to location of new vault

OPTIONS:
    -l            show vaults' location
    -h, --help    Print help information""",
    "note": """executable-note 
create a note

USAGE:
    jt note
    jt note [note name]

ARGS:
    <note name>    name for new note (to be created in the current folder)

OPTIONS:
    -h, --help    Print help information""",
    "folder": """executable-folder 
create a folder

USAGE:
    jt folder
    jt folder [folder name]

ARGS:
    <folder name>    name for new folder (to be created in the current folder)

OPTIONS:
    -h, --help    Print help information""",
    "enter": """executable-enter 
enter a vault

USAGE:
    executable enter <vault name>

ARGS:
    <vault name>    name of the vault to enter

OPTIONS:
    -h, --help    Print help information""",
    "open": """executable-open 
open a note (from the current folder)

USAGE:
    executable open <note name>

ARGS:
    <note name>    name of note to be opened

OPTIONS:
    -h, --help    Print help information""",
    "opdir": """executable-opdir 
open current folder in file explorer

USAGE:
    executable opdir

OPTIONS:
    -h, --help    Print help information""",
    "chdir": """executable-chdir 
change folder within current vault

USAGE:
    executable chdir <folder path>

ARGS:
    <folder path>    path to folder to switch to (from current folder)

OPTIONS:
    -h, --help    Print help information""",
    "list": """executable-list 
list items in current folder

USAGE:
    executable list [item type]

ARGS:
    <item type>    

OPTIONS:
    -h, --help    Print help information""",
    "remove": """executable-remove 
remove an item

USAGE:
    executable remove <item type> <name>

ARGS:
    <item type>    remove a vault (or vl) | note (or nt) | folder (or fd)
    <name>         name of item to be removed

OPTIONS:
    -h, --help    Print help information""",
    "rename": """executable-rename 
rename an item

USAGE:
    executable rename <item type> <name> <new name>

ARGS:
    <item type>    rename a vault (or vl) | note (or nt) | folder (or fd)
    <name>         name of item to be renamed
    <new name>     new name of item

OPTIONS:
    -h, --help    Print help information""",
    "move": """executable-move 
move an item

USAGE:
    executable move <item type> <name> <new location>

ARGS:
    <item type>       move a vault (or vl) | note (or nt) | folder (or fd)
    <name>            name of item to be moved
    <new location>    path to new location of item (current folder as root in case of note or
                      folder)

OPTIONS:
    -h, --help    Print help information""",
    "vmove": """executable-vmove 
move notes and folders to a different vault

USAGE:
    executable vmove <item type> <name> <vault name>

ARGS:
    <item type>     move a note (or nt) | folder (or fd)
    <name>          name of item to be moved
    <vault name>    name of vault to move the item to

OPTIONS:
    -h, --help    Print help information""",
    "config": """executable-config 
display, set or open config

USAGE:
    jt config <config type>
    jt config <config type> [config value]

ARGS:
    <config type>     name of config item to display or set
    <config value>    pass a value if config needs to be updated

OPTIONS:
    -h, --help    Print help information""",
}

ALIASES = {
    "vl": "vault", "nt": "note", "fd": "folder", "en": "enter", "op": "open",
    "od": "opdir", "cd": "chdir", "ls": "list", "rm": "remove", "rn": "rename",
    "mv": "move", "vm": "vmove", "cf": "config",
}


def home() -> Path:
    return Path(os.environ.get("HOME", str(Path.home())))


def paths():
    h = home()
    return h / ".config" / "jot" / "config", h / ".local" / "share" / "jot" / "vaults"


def init():
    cfg, vaults = paths()
    cfg.parent.mkdir(parents=True, exist_ok=True)
    vaults.parent.mkdir(parents=True, exist_ok=True)
    (home() / ".cache" / "rosetta").mkdir(parents=True, exist_ok=True)
    if not cfg.exists():
        cfg.write_text("editor = 'nvim'\nconflict = true\n")
    if not vaults.exists():
        vaults.write_text("[vaults]\n")


def parse_file(p: Path):
    vals, section = {}, None
    if not p.exists():
        return vals
    for raw in p.read_text().splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            continue
        if "=" in line:
            k, v = [x.strip() for x in line.split("=", 1)]
            if v.startswith("'") and v.endswith("'"):
                v = v[1:-1]
            elif v == "true":
                v = True
            elif v == "false":
                v = False
            key = f"{section}.{k}" if section else k
            vals[key] = v
    return vals


def config():
    return parse_file(paths()[0])


def read_vaults():
    vals = parse_file(paths()[1])
    current = vals.get("current", "")
    vaults = {k.split(".", 1)[1]: v for k, v in vals.items() if k.startswith("vaults.")}
    return current, vaults


def write_vaults(current, vaults):
    lines = []
    if current:
        lines += [f"current = '{current}'", ""]
    lines.append("[vaults]")
    for name in sorted(vaults):
        lines.append(f"{name} = '{vaults[name]}'")
    paths()[1].write_text("\n".join(lines) + "\n")


def vault_dir(name, vaults=None) -> Path:
    if vaults is None:
        _, vaults = read_vaults()
    return Path(vaults[name]) / name


def read_data(name, vaults=None):
    p = vault_dir(name, vaults) / ".jot" / "data"
    return parse_file(p)


def write_data(name, location, folder=""):
    d = Path(location) / name / ".jot"
    d.mkdir(parents=True, exist_ok=True)
    (d / "data").write_text(f"name = '{name}'\nlocation = '{location}'\nfolder = '{folder}'\nhistory = []\n")


def err(msg):
    print(f"{RED}error{RESET}: {msg}")


def blue(s):
    return f"{BLUE}{s}{RESET}"


def need_current():
    current, vaults = read_vaults()
    if not current or current not in vaults:
        err("not inside a vault")
        return None
    data = read_data(current, vaults)
    root = vault_dir(current, vaults)
    folder = data.get("folder", "") or ""
    cur = (root / folder).resolve()
    return current, vaults, root, folder, cur


def resolve_in_vault(root: Path, folder: str, dest: str):
    base = root if dest.startswith("/") else root / folder
    rel = dest[1:] if dest.startswith("/") else dest
    target = (base / rel).resolve()
    try:
        target.relative_to(root.resolve())
    except ValueError:
        return None
    return target


def item_type(t):
    return {"vl": "vault", "vault": "vault", "nt": "note", "note": "note", "fd": "folder", "folder": "folder"}.get(t)


def note_path(cur: Path, name: str):
    return cur / (name if name.endswith(".md") else name + ".md")


def cmd_vault(args):
    current, vaults = read_vaults()
    if not args:
        for n in sorted(vaults):
            print(f"   {n}")
        return 0
    if args == ["-l"]:
        for n in sorted(vaults):
            print(f"   {n} \t {vaults[n]}")
        return 0
    if len(args) < 2:
        return usage_error("vault", "<vault name> <vault location>")
    name, loc = args[0], args[1]
    if not Path(loc).is_absolute():
        err("specified path isn't absolute")
    elif name in vaults:
        err(f"vault {name} already exists")
    else:
        (Path(loc) / name).mkdir(parents=True, exist_ok=True)
        write_data(name, loc, "")
        vaults[name] = loc
        write_vaults(current, vaults)
        print(f"vault {blue(name)} created")
    return 0


def cmd_enter(args):
    if not args:
        return usage_error("enter", "<vault name>")
    name = args[0]
    _, vaults = read_vaults()
    if name not in vaults:
        err(f"vault {name} doesn't exist")
    else:
        write_vaults(name, vaults)
        print(f"entered {blue(name)}")
    return 0


def cmd_note(args):
    if not args:
        return missing("note", "<note name>")
    st = need_current()
    if not st:
        return 0
    name = args[0]
    p = note_path(st[4], name)
    shown = p.stem
    if p.exists():
        err(f"a note named {shown} already exists in this location")
    else:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.touch()
        print(f"note {blue(shown)} created")
    return 0


def cmd_folder(args):
    if not args:
        return missing("folder", "<folder name>")
    st = need_current()
    if not st:
        return 0
    name = args[0]
    p = st[4] / name
    if p.exists():
        err(f"a folder named {name} already exists in this location")
    else:
        p.mkdir(parents=True)
        print(f"folder {blue(name)} created")
    return 0


def cmd_chdir(args):
    if not args:
        return usage_error("chdir", "<folder path>")
    st = need_current()
    if not st:
        return 0
    current, vaults, root, folder, _ = st
    target = resolve_in_vault(root, folder, args[0])
    if target is None:
        err("path crosses the bounds of vault")
    elif not target.is_dir():
        err("specified folder doesn't exist")
    else:
        rel = "" if target == root.resolve() else str(target.relative_to(root.resolve()))
        write_data(current, vaults[current], rel)
        print("folder changed")
    return 0


def visible_entries(path, filt):
    items = []
    for p in path.iterdir() if path.exists() else []:
        if filt != "folder" and p.name == ".jot":
            items.append((p.name, p, "hidden"))
            continue
        if p.is_file() and p.suffix == ".md" and filt in ("all", "note"):
            items.append((p.stem, p, "note"))
        elif p.is_dir() and filt in ("all", "folder"):
            items.append((p.name, p, "folder"))
    return items


def print_tree(path, prefix, filt):
    entries = visible_entries(path, filt)
    for i, (name, p, typ) in enumerate(entries):
        last = i == len(entries) - 1
        if typ == "hidden":
            continue
        connector = "└── " if last else "├── "
        print(prefix + connector + (blue(name) if typ == "note" else name))
        if typ == "folder":
            print_tree(p, prefix + ("    " if last else "│   "), filt)


def cmd_list(args):
    st = need_current()
    if not st:
        return 0
    current, _, root, folder, cur = st
    filt = "all"
    if args:
        typ = item_type(args[0])
        if typ in ("note", "folder"):
            filt = typ
    label = current if not folder else f"{current} > {folder}"
    print(label)
    print_tree(cur, "", filt)
    return 0


def cmd_open(args):
    if not args:
        return usage_error("open", "<note name>")
    st = need_current()
    if not st:
        return 0
    p = note_path(st[4], args[0])
    if not p.exists():
        err(f"note {args[0]} doesn't exist")
        return 0
    editor = str(config().get("editor", "nvim"))
    try:
        subprocess.run([editor, str(p)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
    except Exception:
        pass
    return 0


def cmd_opdir(args):
    st = need_current()
    if not st:
        return 0
    try:
        subprocess.run(["xdg-open", str(st[4])], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
    except Exception:
        pass
    return 0


def cmd_remove(args):
    if len(args) < 2:
        return usage_error("remove", "<item type> <name>")
    typ, name = item_type(args[0]), args[1]
    current, vaults = read_vaults()
    if typ == "vault":
        if name not in vaults:
            err(f"vault {name} doesn't exist")
        else:
            shutil.rmtree(vault_dir(name, vaults), ignore_errors=True)
            del vaults[name]
            write_vaults("" if current == name else current, vaults)
            print(f"vault {blue(name)} removed")
        return 0
    st = need_current()
    if not st:
        return 0
    p = note_path(st[4], name) if typ == "note" else st[4] / name
    if not p.exists():
        err(f"{typ or 'item'} {name} doesn't exist")
    else:
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink()
        print(f"{typ} {blue(name)} removed")
    return 0


def cmd_rename(args):
    if len(args) < 3:
        return usage_error("rename", "<item type> <name> <new name>")
    typ, name, new = item_type(args[0]), args[1], args[2]
    current, vaults = read_vaults()
    if typ == "vault":
        if name not in vaults:
            err(f"vault {name} doesn't exist")
        else:
            olddir = vault_dir(name, vaults)
            newdir = Path(vaults[name]) / new
            olddir.rename(newdir)
            loc = vaults.pop(name)
            vaults[new] = loc
            write_data(new, loc, read_data(name, vaults).get("folder", "") if False else "")
            write_vaults(new if current == name else current, vaults)
            print(f"vault {blue(name)} renamed to {blue(new)}")
        return 0
    st = need_current()
    if not st:
        return 0
    old = note_path(st[4], name) if typ == "note" else st[4] / name
    newp = note_path(st[4], new) if typ == "note" else st[4] / new
    if not old.exists():
        err(f"{typ} {name} doesn't exist")
    else:
        old.rename(newp)
        print(f"{typ} {blue(name)} renamed to {blue(new)}")
    return 0


def cmd_move(args):
    if len(args) < 3:
        return usage_error("move", "<item type> <name> <new location>")
    typ, name, dest = item_type(args[0]), args[1], args[2]
    if typ == "vault":
        current, vaults = read_vaults()
        if name not in vaults:
            err(f"vault {name} doesn't exist")
        elif not Path(dest).is_absolute():
            err("specified path isn't absolute")
        else:
            Path(dest).mkdir(parents=True, exist_ok=True)
            shutil.move(str(vault_dir(name, vaults)), str(Path(dest) / name))
            vaults[name] = dest
            write_data(name, dest, read_data(name, vaults).get("folder", "") if False else "")
            write_vaults(current, vaults)
            print(f"vault {blue(name)} moved")
        return 0
    st = need_current()
    if not st:
        return 0
    _, _, root, folder, cur = st
    src = note_path(cur, name) if typ == "note" else cur / name
    target_dir = resolve_in_vault(root, folder, dest)
    if target_dir is None:
        err("path crosses the bounds of vault")
    elif not target_dir.is_dir():
        err("specified folder doesn't exist")
    elif not src.exists():
        err(f"{typ} {name} doesn't exist")
    else:
        shutil.move(str(src), str(target_dir / src.name))
        print(f"{typ} {blue(name)} moved")
    return 0


def cmd_vmove(args):
    if len(args) < 3:
        return usage_error("vmove", "<item type> <name> <vault name>")
    typ, name, vname = item_type(args[0]), args[1], args[2]
    st = need_current()
    if not st:
        return 0
    _, vaults, _, _, cur = st
    if vname not in vaults:
        err(f"vault {vname} doesn't exist")
        return 0
    src = note_path(cur, name) if typ == "note" else cur / name
    if not src.exists():
        err(f"{typ} {name} doesn't exist")
    else:
        shutil.move(str(src), str(vault_dir(vname, vaults) / src.name))
        print(f"{typ} {blue(name)} moved")
    return 0


def cmd_config(args):
    cfg_path, _ = paths()
    vals = config()
    if not args:
        editor = str(vals.get("editor", "nvim"))
        try:
            subprocess.run([editor, str(cfg_path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
        except Exception:
            pass
        return 0
    key = args[0]
    if len(args) == 1:
        if key in vals:
            print(f"{key}: {blue(str(vals[key]).lower() if isinstance(vals[key], bool) else vals[key])}")
        else:
            err(f"config {key} doesn't exist")
    else:
        val = args[1]
        vals[key] = (val == "true") if val in ("true", "false") else val
        cfg_path.write_text(f"editor = '{vals.get('editor', 'nvim')}'\nconflict = {str(vals.get('conflict', True)).lower()}\n")
        print(f"set {blue(key)} to {blue(val)}")
    return 0


def usage_error(cmd, usage):
    print(f"error: The following required arguments were not provided:\n    {usage}\n\nUSAGE:\n    executable {cmd} {usage}\n\nFor more information try --help", file=sys.stderr)
    return 2


def missing(cmd, arg):
    usage = "jt note\n    jt note [note name]" if cmd == "note" else "jt folder\n    jt folder [folder name]"
    print(f"error: The following required arguments were not provided:\n    {arg}\n\nUSAGE:\n    {usage}\n\nFor more information try --help", file=sys.stderr)
    return 2


def main(argv):
    init()
    if not argv:
        print(HELP, file=sys.stderr)
        return 2
    if argv[0] in ("-h", "--help"):
        print(HELP)
        return 0
    if argv[0] == "help":
        if len(argv) > 1:
            cmd = ALIASES.get(argv[1], argv[1])
            if cmd in CMD_HELP:
                print(CMD_HELP[cmd])
                return 0
        print(HELP)
        return 0
    cmd = ALIASES.get(argv[0], argv[0])
    if len(argv) > 1 and argv[1] in ("-h", "--help") and cmd in CMD_HELP:
        print(CMD_HELP[cmd])
        return 0
    funcs = {
        "vault": cmd_vault, "note": cmd_note, "folder": cmd_folder, "enter": cmd_enter,
        "open": cmd_open, "opdir": cmd_opdir, "chdir": cmd_chdir, "list": cmd_list,
        "remove": cmd_remove, "rename": cmd_rename, "move": cmd_move, "vmove": cmd_vmove,
        "config": cmd_config,
    }
    if cmd not in funcs:
        print(f"error: Found argument '{argv[0]}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help", file=sys.stderr)
        return 2
    return funcs[cmd](argv[1:])


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
