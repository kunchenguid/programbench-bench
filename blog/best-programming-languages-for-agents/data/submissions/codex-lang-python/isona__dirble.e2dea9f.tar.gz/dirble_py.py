#!/usr/bin/env python3
import base64
import json
import os
import random
import re
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.sax.saxutils


VERSION = "Dirble 1.4.2 (commit d520c82, build 2026-04-17)"

HELP = """Fast directory scanning and scraping tool

Usage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>

Arguments:
  [uri]
          The URI of the host to scan, optionally supports basic auth with
          http://user:pass@host:port

Options:
  -u, --uri <uri>
          Additional hosts to scan [aliases: url]
  -U, --uri-file <uri-file>
          The filename of a file containing a list of URIs to scan - cookies and
          headers set will be applied to all URIs [aliases: url-file]
      --verb <http_verb>
          Specify which HTTP verb to use
           [default: get] [possible values: get, head, post]
  -w, --wordlist <wordlist>
          Sets which wordlist to use, defaults to dirble_wordlist.txt in the same
          folder as the executable
  -p, --prefixes <prefixes>...
          Provides comma separated prefixes to extend queries with
  -P, --prefix-file <prefix-file>
          The name of a file containing extensions to extend queries with, one
          per line
  -x, --extensions <extensions>...
          Provides comma separated extensions to extend queries with
  -X, --extension-file <extension-file>
          The name of a file containing extensions to extend queries with, one
          per line
      --ext-sub
          Indicates whether the string "%EXT%" in a wordlist file should be 
          substituted with the current extension
  -f, --force-extension
          Only scan with provided extensions
  -k, --ignore-cert
          Ignore the certificate validity for HTTPS
      --show-htaccess
          Enable display of items containing .ht when they return 403 responses
      --timeout <timeout>
          Maximum time to wait for a response before giving up, given in seconds
           [default: 5]
      --max-errors <max_errors>
          The number of consecutive errors a thread can have before it exits,
          set to 0 to disable [default: 5]
      --json-file <json_file>
          Sets a file to write JSON output to [aliases: oJ]
      --no-color
          Disable coloring of terminal output
  -o, --output-file <output_file>
          Sets the file to write the report to [aliases: oN]
      --xml-file <xml_file>
          Sets a file to write XML output to [aliases: oX]
      --hide-lengths <length_blacklist>...
          Specify length ranges to hide, e.g. --hide-lengths 348,500-700
      --output-all <output_all>
          Stores all output types respectively as .txt, .json and .xml [aliases: oA]
      --burp
          Sets the proxy to use the default burp proxy values
          (http://localhost:8080)
      --no-proxy
          Disables proxy use even if there is a system proxy
      --proxy <proxy>
          The proxy address to use, including type and port, can also include a
          username and password in the form 
          "http://username:password@proxy_url:proxy_port"
  -t, --max-threads <max-threads>
          Sets the maximum number of request threads that will be spawned [default: 10]
  -T, --wordlist-split <wordlist_split>
          The number of threads to run for each folder/extension combo [default: 3]
  -z, --throttle <milliseconds>
          Time each thread will wait between requests, given in milliseconds
      --username <username>
          Sets the username to authenticate with
      --password <password>
          Sets the password to authenticate with
  -l, --scan-listable
          Scan listable directories
      --max-recursion-depth <max_recursion_depth>
          Sets the maximum directory depth to recurse to, 0 will disable
          recursion
  -r, --disable-recursion
          Disable discovered subdirectory scanning
      --scrape-listable
          Enable scraping of listable directories for urls, often produces large
          amounts of output
  -a, --user-agent <user_agent>
          Set the user-agent provided with requests, by default it isn't set
  -c, --cookie <cookie>
          Provide a cookie in the form "name=value", can be used multiple times
  -H, --header <header>
          Provide an arbitrary header in the form "header:value" - headers with
          no value must end in a semicolon
  -S, --silent
          Don't output information during the scan, only output the report at
          the end.
  -v, --verbose...
          Increase the verbosity level. Use twice for full verbosity.
  -B, --code-blacklist <code_blacklist>...
          Provide a comma separated list of response codes to not show in output
      --disable-validator
          Disable automatic detection of not found codes
  -W, --code-whitelist <code_whitelist>...
          Provide a comma separated list of response codes to show in output,
          also disables detection of not found codes
      --scan-401
          Scan folders even if they return 401 - Unauthorized frequently
      --scan-403
          Scan folders if they return 403 - Forbidden frequently
  -h, --help
          Print help
  -V, --version
          Print version

OUTPUT FORMAT:
    + [url] - File
    D [url] - Directory
    L [url] - Listable Directory

EXAMPLE USE:
    - Run against a website using the default dirble_wordlist.txt from the
      current directory:
        dirble [address]

    - Run with a different wordlist and including .php and .html extensions:
        dirble [address] -w example_wordlist.txt -x .php,.html

    - With listable directory scraping enabled:
        dirble [address] --scrape-listable

    - Providing a list of extensions and a list of URIs:
        dirble [address] -X wordlists/web.lst -U uri-list.txt

    - Providing multiple hosts to scan via command line:
        dirble [address] -u [address] -u [address]
"""


TAKES_VALUE = {
    "-u": "uri", "--uri": "uri", "--url": "uri",
    "-U": "uri_file", "--uri-file": "uri_file", "--url-file": "uri_file",
    "--verb": "verb", "-w": "wordlist", "--wordlist": "wordlist",
    "-P": "prefix_file", "--prefix-file": "prefix_file",
    "-X": "extension_file", "--extension-file": "extension_file",
    "--timeout": "timeout", "--max-errors": "max_errors",
    "--json-file": "json_file", "--oJ": "json_file",
    "-o": "output_file", "--output-file": "output_file", "--oN": "output_file",
    "--xml-file": "xml_file", "--oX": "xml_file",
    "--output-all": "output_all", "--oA": "output_all",
    "--proxy": "proxy", "-t": "max_threads", "--max-threads": "max_threads",
    "-T": "wordlist_split", "--wordlist-split": "wordlist_split",
    "-z": "throttle", "--throttle": "throttle",
    "--username": "username", "--password": "password",
    "--max-recursion-depth": "max_recursion_depth",
    "-a": "user_agent", "--user-agent": "user_agent",
}

MULTI_VALUE = {
    "-p": "prefixes", "--prefixes": "prefixes",
    "-x": "extensions", "--extensions": "extensions",
    "--hide-lengths": "hide_lengths",
    "-B": "code_blacklist", "--code-blacklist": "code_blacklist",
    "-W": "code_whitelist", "--code-whitelist": "code_whitelist",
}

FLAGS = {
    "--ext-sub": "ext_sub", "-f": "force_extension", "--force-extension": "force_extension",
    "-k": "ignore_cert", "--ignore-cert": "ignore_cert", "--show-htaccess": "show_htaccess",
    "--no-color": "no_color", "--burp": "burp", "--no-proxy": "no_proxy",
    "-l": "scan_listable", "--scan-listable": "scan_listable",
    "-r": "disable_recursion", "--disable-recursion": "disable_recursion",
    "--scrape-listable": "scrape_listable", "-S": "silent", "--silent": "silent",
    "--disable-validator": "disable_validator", "--scan-401": "scan_401", "--scan-403": "scan_403",
}


def defaults():
    return {
        "uris": [], "uri_files": [], "wordlist": None, "verb": "get",
        "prefixes": [], "extensions": [], "prefix_file": None, "extension_file": None,
        "ext_sub": False, "force_extension": False, "ignore_cert": False,
        "show_htaccess": False, "timeout": 5.0, "max_errors": 5,
        "json_file": None, "output_file": None, "xml_file": None, "output_all": None,
        "hide_lengths": [], "proxy": None, "burp": False, "no_proxy": False,
        "throttle": 0, "username": None, "password": None,
        "max_recursion_depth": None, "disable_recursion": False, "scrape_listable": False,
        "scan_listable": False, "user_agent": None, "cookies": [], "headers": [],
        "silent": False, "verbose": 0, "code_blacklist": [], "code_whitelist": [],
        "disable_validator": False, "scan_401": False, "scan_403": False,
    }


def parse(argv):
    if any(a in ("-h", "--help") for a in argv):
        print(HELP, end="")
        raise SystemExit(0)
    if any(a in ("-V", "--version") for a in argv):
        print(VERSION)
        raise SystemExit(0)
    opt = defaults()
    i = 0
    positional = []
    while i < len(argv):
        a = argv[i]
        if a == "--":
            positional.extend(argv[i + 1:])
            break
        if a in ("-v", "--verbose"):
            opt["verbose"] += 1
            i += 1
        elif a in ("-c", "--cookie"):
            i += 1
            need_value(argv, i, a)
            opt["cookies"].append(argv[i])
            i += 1
        elif a in ("-H", "--header"):
            i += 1
            need_value(argv, i, a)
            opt["headers"].append(argv[i])
            i += 1
        elif a in FLAGS:
            opt[FLAGS[a]] = True
            i += 1
        elif a in TAKES_VALUE:
            key = TAKES_VALUE[a]
            i += 1
            need_value(argv, i, a)
            val = argv[i]
            if key == "uri":
                opt["uris"].append(val)
            elif key == "uri_file":
                opt["uri_files"].append(val)
            elif key in ("timeout",):
                opt[key] = float(val)
            elif key in ("max_errors", "throttle", "max_recursion_depth"):
                opt[key] = int(val)
            else:
                opt[key] = val
            i += 1
        elif a in MULTI_VALUE:
            key = MULTI_VALUE[a]
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                opt[key].extend(split_csv(argv[i]))
                i += 1
        elif a.startswith("-"):
            sys.stderr.write(f"error: unexpected argument '{a}' found\n\n")
            sys.stderr.write("For more information, try '--help'.\n")
            raise SystemExit(2)
        else:
            positional.append(a)
            i += 1
    if positional:
        opt["uris"].insert(0, positional[0])
    if len(positional) > 1:
        for extra in positional[1:]:
            sys.stderr.write(f"error: unexpected argument '{extra}' found\n\n")
        raise SystemExit(2)
    return opt


def need_value(argv, idx, flag):
    if idx >= len(argv):
        sys.stderr.write(f"error: a value is required for '{flag}' but none was supplied\n")
        raise SystemExit(2)


def split_csv(value):
    out = []
    for part in value.split(","):
        part = part.strip()
        if part:
            out.append(part)
    return out


def read_lines(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return [line.strip() for line in f.read().splitlines() if line.strip()]


def normalize_url(url):
    parsed = urllib.parse.urlsplit(url)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("relative URL without a base")
    path = parsed.path or "/"
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, path, parsed.query, ""))


def join_url(base, word):
    if base.endswith("/"):
        return base + urllib.parse.quote(word.lstrip("/"), safe="/.%")
    return base + "/" + urllib.parse.quote(word.lstrip("/"), safe="/.%")


def parse_ranges(items):
    ranges = []
    for item in items:
        for part in split_csv(item):
            if "-" in part:
                lo, hi = part.split("-", 1)
                ranges.append((int(lo), int(hi)))
            else:
                val = int(part)
                ranges.append((val, val))
    return ranges


def hidden_length(size, ranges):
    return any(lo <= size <= hi for lo, hi in ranges)


def parse_codes(items):
    out = set()
    for item in items:
        for part in split_csv(str(item)):
            try:
                out.add(int(part))
            except ValueError:
                pass
    return out


def load_inputs(opt):
    uris = list(opt["uris"])
    for path in opt["uri_files"]:
        try:
            uris.extend(read_lines(path))
        except OSError as e:
            sys.stderr.write(f"Unable to read URI file {path}: {e}\n")
    if not uris:
        sys.stderr.write("error: the following required arguments were not provided:\n")
        sys.stderr.write("  <uri|--uri-file <uri-file>|--uri <uri>>\n\n")
        sys.stderr.write("Usage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        raise SystemExit(2)

    good_uris = []
    for uri in uris:
        try:
            good_uris.append(normalize_url(uri))
        except ValueError as e:
            sys.stderr.write(f"Invalid URL: {uri}\n" if not str(e) else f"error: invalid value '{uri}' for '[uri]': {e}\n")
    if not good_uris:
        raise SystemExit(1)

    if opt["wordlist"] is None:
        default_wordlist = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "dirble_wordlist.txt")
        if not os.path.exists(default_wordlist):
            print("[ERROR] Unable to find default wordlist")
            raise SystemExit(1)
        opt["wordlist"] = default_wordlist
    words = read_lines(opt["wordlist"])

    prefixes = list(opt["prefixes"])
    if opt["prefix_file"]:
        prefixes.extend(read_lines(opt["prefix_file"]))
    extensions = list(opt["extensions"])
    if opt["extension_file"]:
        extensions.extend(read_lines(opt["extension_file"]))
    return good_uris, words, prefixes, extensions


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def make_opener(opt):
    handlers = []
    if opt["no_proxy"]:
        handlers.append(urllib.request.ProxyHandler({}))
    elif opt["proxy"] or opt["burp"]:
        proxy = opt["proxy"] or "http://localhost:8080"
        handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
    if opt["ignore_cert"]:
        ctx = ssl._create_unverified_context()
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    return urllib.request.build_opener(*handlers)


def request_url(opener, url, opt):
    headers = {}
    if opt["user_agent"]:
        headers["User-Agent"] = opt["user_agent"]
    if opt["cookies"]:
        headers["Cookie"] = "; ".join(opt["cookies"])
    for raw in opt["headers"]:
        if ":" in raw:
            k, v = raw.split(":", 1)
            headers[k.strip()] = v.strip()
        elif raw.endswith(";"):
            headers[raw[:-1].strip()] = ""
    username = opt["username"]
    password = opt["password"]
    parts = urllib.parse.urlsplit(url)
    if parts.username is not None:
        username = urllib.parse.unquote(parts.username)
        password = urllib.parse.unquote(parts.password or "")
        netloc = parts.hostname or ""
        if parts.port:
            netloc += f":{parts.port}"
        url = urllib.parse.urlunsplit((parts.scheme, netloc, parts.path, parts.query, parts.fragment))
    if username is not None and password is not None:
        token = base64.b64encode(f"{username}:{password}".encode()).decode()
        headers["Authorization"] = f"Basic {token}"
    method = opt["verb"].upper()
    data = b"" if method == "POST" else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with opener.open(req, timeout=opt["timeout"]) as resp:
            body = resp.read() if method != "HEAD" else b""
            return resp.geturl(), resp.status, body, dict(resp.headers), ""
    except urllib.error.HTTPError as e:
        body = e.read() if method != "HEAD" else b""
        return e.geturl(), e.code, body, dict(e.headers), ""
    except Exception as e:
        return url, 0, b"", {}, str(e)


def is_listable(body):
    sample = body[:4096].lower()
    return b"directory listing for" in sample or b"<title>index of" in sample or b"<h1>index of" in sample


def candidate_words(words, prefixes, extensions, opt):
    seen = set()
    prefixes = prefixes or [""]
    raw_exts = extensions
    for word in words:
        variants = []
        if raw_exts and opt["ext_sub"] and "%EXT%" in word:
            for ext in raw_exts:
                variants.append(word.replace("%EXT%", ext[1:] if ext.startswith(".") else ext))
        else:
            if not opt["force_extension"]:
                variants.append(word)
            if raw_exts:
                for ext in raw_exts:
                    variants.append(word + ext)
        for prefix in prefixes:
            for v in variants:
                item = prefix + v
                if item not in seen:
                    seen.add(item)
                    yield item


def should_show(result, blacklist, whitelist, hidden_ranges, not_found_codes, opt):
    code = result["code"]
    if code == 0:
        return False
    if whitelist and code not in whitelist:
        return False
    if code in blacklist:
        return False
    if not whitelist and code in not_found_codes:
        return False
    if hidden_length(result["size"], hidden_ranges):
        return False
    if ".ht" in urllib.parse.urlsplit(result["url"]).path and code == 403 and not opt["show_htaccess"]:
        return False
    return True


def line_for(r):
    kind = "L" if r["is_listable"] else ("D" if r["is_directory"] else "+")
    extra = f"|REDIRECT:{r['redirect_url']}" if r["redirect_url"] else ""
    return f"{kind} {r['url']} (CODE:{r['code']}|SIZE:{r['size']}{extra})"


def scan_base(base, words, prefixes, extensions, opt):
    opener = make_opener(opt)
    hidden_ranges = parse_ranges(opt["hide_lengths"])
    blacklist = parse_codes(opt["code_blacklist"])
    whitelist = parse_codes(opt["code_whitelist"])
    not_found = set()
    if not opt["disable_validator"] and not whitelist:
        probe = join_url(base, f"dirble-not-found-{random.randrange(10**12)}")
        _, code, _, _, _ = request_url(opener, probe, opt)
        if code:
            not_found.add(code)
            if not opt["silent"]:
                print(f"[INFO] Detected nonexistent paths for {base} are (CODE:{code})")

    results = []
    queue = [(base, 0)]
    visited_dirs = set()
    max_depth = opt["max_recursion_depth"]
    while queue:
        current, depth = queue.pop(0)
        if current in visited_dirs:
            continue
        visited_dirs.add(current)
        for word in candidate_words(words, prefixes, extensions, opt):
            if opt["throttle"]:
                time.sleep(opt["throttle"] / 1000.0)
            target = join_url(current, word)
            final_url, code, body, headers, err = request_url(opener, target, opt)
            if err:
                if opt["verbose"]:
                    print(f"[ERROR] {target}: {err}")
                continue
            path = urllib.parse.urlsplit(final_url).path
            directory = path.endswith("/")
            listable = directory and is_listable(body)
            # The reference follows common directory redirects and reports the
            # final URL as the item itself without annotating the redirect.
            redirect_url = ""
            r = {
                "url": final_url, "code": code, "size": len(body),
                "is_directory": directory, "is_listable": listable,
                "redirect_url": redirect_url, "found_from_listable": False,
            }
            if should_show(r, blacklist, whitelist, hidden_ranges, not_found, opt):
                results.append(r)
                if not opt["silent"]:
                    print(line_for(r))
            can_recurse = directory and not opt["disable_recursion"] and (max_depth is None or (max_depth > 0 and depth < max_depth))
            if can_recurse and code not in not_found and code in (200, 401, 403):
                if code == 401 and not opt["scan_401"]:
                    continue
                if code == 403 and not opt["scan_403"]:
                    continue
                queue.append(final_url)
    return results


def write_text(path, grouped):
    with open(path, "w", encoding="utf-8") as f:
        for base, results in grouped:
            f.write(f"Dirble Scan Report for {base}:\n")
            wrote = False
            for r in results:
                if r["is_directory"] and wrote:
                    f.write("\n")
                f.write(line_for(r) + "\n")
                wrote = True


def write_json(path, results):
    with open(path, "w", encoding="utf-8") as f:
        f.write("[")
        for i, r in enumerate(results):
            if i:
                f.write(",\n")
            f.write(json.dumps(r, separators=(",", ":")))
        f.write("]")


def write_xml(path, results):
    with open(path, "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<dirble_scan>\n')
        for r in results:
            f.write(
                '<path url="{url}" code="{code}" content_len="{size}" is_directory="{isd}" '
                'is_listable="{isl}" redirect_url="{redir}" found_from_listable="{ffl}"/>\n'.format(
                    url=xml.sax.saxutils.escape(r["url"], {'"': "&quot;"}),
                    code=r["code"], size=r["size"],
                    isd=str(r["is_directory"]).lower(),
                    isl=str(r["is_listable"]).lower(),
                    redir=xml.sax.saxutils.escape(r["redirect_url"], {'"': "&quot;"}),
                    ffl=str(r["found_from_listable"]).lower(),
                )
            )
        f.write("</dirble_scan>")


def main(argv):
    opt = parse(argv)
    try:
        uris, words, prefixes, extensions = load_inputs(opt)
    except FileNotFoundError as e:
        sys.stderr.write(f"No such file or directory: {e.filename}\n")
        return 101
    grouped = []
    all_results = []
    for base in uris:
        results = scan_base(base, words, prefixes, extensions, opt)
        grouped.append((base, results))
        all_results.extend(results)
    if opt["silent"] and not (opt["output_file"] or opt["json_file"] or opt["xml_file"] or opt["output_all"]):
        for r in all_results:
            print(line_for(r))
    if opt["output_all"]:
        opt["output_file"] = opt["output_all"] + ".txt"
        opt["json_file"] = opt["output_all"] + ".json"
        opt["xml_file"] = opt["output_all"] + ".xml"
    if opt["output_file"]:
        write_text(opt["output_file"], grouped)
    if opt["json_file"]:
        write_json(opt["json_file"], all_results)
    if opt["xml_file"]:
        write_xml(opt["xml_file"], all_results)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
