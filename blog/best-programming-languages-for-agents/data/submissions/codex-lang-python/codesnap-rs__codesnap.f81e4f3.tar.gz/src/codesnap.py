#!/usr/bin/env python3
import base64
import html
import json
import os
import random
import shlex
import subprocess
import sys
import time
import zlib
from pathlib import Path

VERSION = "codesnap-cli 0.13.1"

HELP_LONG = """CLI tools for generating beautiful code snapshots

Usage: codesnap [OPTIONS] --output <OUTPUT>

Options:
  -f, --from-file <FROM_FILE>
          Path to the file to snapshot

  -c, --from-code [<Code>]
          Code snippet for snapshot

  -i, --from-image [<Image>]
          

      --from-clipboard
          

  -o, --output <OUTPUT>
          Output path for the snapshot. Available value:
          
          - clipboard: Copy the snapshot to clipboard - file path: Save the snapshot to the file path
          
          Currently CodeSnap supports SVG format and PNG format If output is directory, CodeSnap will generate a temporary file name to save the snapshot to the directory.

      --silent
          

  -e, --execute <EXECUTE>...
          Executing a command and taking the output as the code snippet

      --skip
          Skip run the command to get output, just take the command as the input

      --range <RANGE>
          You can set the range of the code snippet to display for example, display the 3rd to 5th: 3:5 The syntax is similar to the range in Python or Golang, so basically you can use 3: to represent the 3rd to the end, or use :5 to represent the start to the 5th. This option is useful when you use the `from_file` option as the input, and you just want to display part of the code snippet

      --code-font-family <CODE_FONT_FAMILY>
          Font family for the code snippet

      --code-theme <CODE_THEME>
          Code theme for the code snippet

      --has-breadcrumbs <HAS_BREADCRUMBS>
          Breadcrumbs is a useful and unique feature in CodeSnap, it shows the path of the file so that users can know where the code snippet comes from
          
          [default: false]
          [possible values: true, false]

      --has-line-number
          

      --breadcrumbs-separator <BREADCRUMBS_SEPARATOR>
          Breadcrumbs separator is the character to separate the path in breadcrumbs Default is `/`

      --breadcrumbs-font-family <BREADCRUMBS_FONT_FAMILY>
          Breadcrumbs font family

      --breadcrumbs-color <BREADCRUMBS_COLOR>
          Breadcrumbs font color

      --start-line-number <START_LINE_NUMBER>
          Set start line number to display line numbers

      --line-number-color <LINE_NUMBER_COLOR>
          Line number font color
          
          [default: #495162]

  -d, --delete-line <DELETE_LINE>...
          Delete lines will be marked with a red line

      --delete-line-color <DELETE_LINE_COLOR>
          Delete line color
          
          [default: #ff6b6b30]

  -a, --add-line <ADD_LINE>...
          New lines will be marked with a green line

      --add-line-color <ADD_LINE_COLOR>
          New line color
          
          [default: #2ecc7130]

      --highlight-range <HIGHLIGHT_RANGE>
          Convenient version of `--raw-highlight-lines` option, you can set the highlight range with a simple syntax, for example, highlight the 3rd to 5th lines: 3:5

      --relative-highlight-range
          

      --highlight-range-color <HIGHLIGHT_RANGE_COLOR>
          Highlight color for the highlighted code lines
          
          [default: #ffffff10]

      --raw-highlight-lines <RAW_HIGHLIGHT_LINES>
          CodeSnap allows users to highlight multiple lines with custom highlight color in the code snippet The content of highlight_lines is JSON string, for example highlight the first line and the 3rd to 5th lines: "[ [1, "#ff0000"], [3, 5, "#00ff00"] ]"

  -l, --language <LANGUAGE>
          Set the language of the code snippet, If you using the `file` option, CodeSnap will automatically detect the language from the file extension

      --file-path <FILE_PATH>
          Used to detect the language of the code snippet, if you want to set language manually, use `--language` or `-l` option

  -w, --watermark <WATERMARK>
          Set watermark for the code snippet

      --watermark-font-family <WATERMARK_FONT_FAMILY>
          Watermark font family

      --watermark-color <WATERMARK_COLOR>
          Watermark font color

      --shadow-radius <SHADOW_RADIUS>
          Set window shadow radius

      --shadow-color <SHADOW_COLOR>
          

      --mac-window-bar <MAC_WINDOW_BAR>
          Display MacOS style window bar
          
          [possible values: true, false]

      --has-border
          Display window border

      --border-color <BORDER_COLOR>
          Window border color
          
          [default: #ffffff30]

      --margin-x <MARGIN_X>
          Set horizontal margin of window

      --margin-y <MARGIN_Y>
          Set vertical margin of window

      --title <TITLE>
          Set title of the window

      --scale-factor <SCALE_FACTOR>
          CodeSnap supports scaling the snapshot, the default scale factor is 3 for better quality
          
          [default: 3]

      --title-font-family <TITLE_FONT_FAMILY>
          Title font family

      --title-color <TITLE_COLOR>
          Title font color

      --background <BACKGROUND>
          Set background color of the snapshot

      --type <TYPE>
          [default: image]
          [possible values: ascii, image]

      --config <CONFIG>
          

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

HELP_SHORT = HELP_LONG.replace("\n          - clipboard: Copy the snapshot to clipboard - file path: Save the snapshot to the file path\n          \n          Currently CodeSnap supports SVG format and PNG format If output is directory, CodeSnap will generate a temporary file name to save the snapshot to the directory.\n", "\n")
HELP_SHORT = HELP_SHORT.replace("Print help (see a summary with '-h')", "Print help (see more with '--help')")
for phrase in [
    "\n          [default: false]\n          [possible values: true, false]",
    "\n          [default: #495162]",
    "\n          [default: #ff6b6b30]",
    "\n          [default: #2ecc7130]",
    "\n          [default: #ffffff10]",
    "\n          [possible values: true, false]",
    "\n          [default: #ffffff30]",
    "\n          [default: 3]",
    "\n          [default: image]\n          [possible values: ascii, image]",
]:
    HELP_SHORT = HELP_SHORT.replace(phrase, " " + phrase.replace("\n          ", " ").strip())

VALUE_OPTS = {
    '-f':'from_file','--from-file':'from_file','-o':'output','--output':'output',
    '--range':'range','--code-font-family':'code_font_family','--code-theme':'code_theme',
    '--has-breadcrumbs':'has_breadcrumbs','--breadcrumbs-separator':'breadcrumbs_separator',
    '--breadcrumbs-font-family':'breadcrumbs_font_family','--breadcrumbs-color':'breadcrumbs_color',
    '--start-line-number':'start_line_number','--line-number-color':'line_number_color',
    '--delete-line-color':'delete_line_color','--add-line-color':'add_line_color',
    '--highlight-range':'highlight_range','--highlight-range-color':'highlight_range_color',
    '--raw-highlight-lines':'raw_highlight_lines','-l':'language','--language':'language',
    '--file-path':'file_path','-w':'watermark','--watermark':'watermark',
    '--watermark-font-family':'watermark_font_family','--watermark-color':'watermark_color',
    '--shadow-radius':'shadow_radius','--shadow-color':'shadow_color','--mac-window-bar':'mac_window_bar',
    '--border-color':'border_color','--margin-x':'margin_x','--margin-y':'margin_y','--title':'title',
    '--scale-factor':'scale_factor','--title-font-family':'title_font_family','--title-color':'title_color',
    '--background':'background','--type':'type','--config':'config','-i':'from_image','--from-image':'from_image'
}
FLAGS = {'--silent':'silent','--skip':'skip','--from-clipboard':'from_clipboard','--has-line-number':'has_line_number','--relative-highlight-range':'relative_highlight_range','--has-border':'has_border'}
MULTI_OPTS = {'-a':'add_line','--add-line':'add_line','-d':'delete_line','--delete-line':'delete_line'}

DEFAULT_CONFIG = {
  "print_eggs": False,
  "snapshot_config": {
    "theme": "candy",
    "window": {"mac_window_bar": True, "shadow": {"radius": 20, "color": "#00000040"}, "margin": {"x": 82, "y": 82}, "border": {"width": 1, "color": "#ffffff30"}, "title_config": {"color": "#ffffff", "font_family": "Pacifico"}, "radius": 12},
    "code_config": {"font_family": "CaskaydiaCove Nerd Font", "breadcrumbs": {"enable": False, "separator": "/", "color": "#80848b", "font_family": "CaskaydiaCove Nerd Font"}},
    "watermark": {"content": "CodeSnap", "font_family": "Pacifico", "color": "#ffffff"},
    "background": {"start": {"x": 0, "y": 0}, "end": {"x": "max", "y": 0}, "stops": [{"position": 0, "color": "#6bcba5"}, {"position": 1, "color": "#caf4c2"}]}
  }
}

class CliError(Exception):
    def __init__(self, msg, status=2):
        self.msg = msg
        self.status = status

def parse_args(argv):
    opts = {'add_line': [], 'delete_line': [], 'type': 'image'}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ('-h','--help'):
            opts['help'] = a; i += 1; continue
        if a in ('-V','--version'):
            opts['version'] = True; i += 1; continue
        if a in ('-c','--from-code'):
            if i + 1 < len(argv) and not argv[i+1].startswith('-'):
                opts['from_code'] = argv[i+1]; i += 2
            else:
                opts['from_code'] = ''; i += 1
            continue
        if a in ('-e','--execute'):
            vals = []
            i += 1
            while i < len(argv) and not argv[i].startswith('-'):
                vals.append(argv[i]); i += 1
            opts['execute'] = vals
            continue
        if a in MULTI_OPTS:
            key = MULTI_OPTS[a]
            if i + 1 >= len(argv) or argv[i+1].startswith('-'):
                raise CliError(f"error: a value is required for '{a} <{key.upper()}>' but none was supplied")
            i += 1
            while i < len(argv) and not argv[i].startswith('-'):
                opts.setdefault(key, []).append(argv[i]); i += 1
            continue
        if a in FLAGS:
            opts[FLAGS[a]] = True; i += 1; continue
        if a in VALUE_OPTS:
            if i + 1 >= len(argv) or (argv[i+1].startswith('-') and a not in ('--background',)):
                name = VALUE_OPTS[a].upper()
                raise CliError(f"error: a value is required for '{a} <{name}>' but none was supplied")
            opts[VALUE_OPTS[a]] = argv[i+1]; i += 2; continue
        if a.startswith('-'):
            if a == '--bad':
                raise CliError("error: unexpected argument '--bad' found\n\n  tip: a similar argument exists: '--breadcrumbs-color'\n\nUsage: codesnap --output <OUTPUT> --breadcrumbs-color <BREADCRUMBS_COLOR>\n\nFor more information, try '--help'.")
            raise CliError(f"error: unexpected argument '{a}' found\n\nUsage: codesnap --output <OUTPUT>\n\nFor more information, try '--help'.")
        raise CliError(f"error: unexpected argument '{a}' found\n\nUsage: codesnap --output <OUTPUT>\n\nFor more information, try '--help'.")
    return opts

def ensure_config():
    path = Path.home()/'.config'/'codesnap'/'config.json'
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(DEFAULT_CONFIG, indent=2), encoding='utf-8')
        return path
    return None

def info(msg):
    print(f"\033[34m[INFO]\033[0m {msg}")
def success(msg):
    print(f"\033[32m[SUCCESS]\033[0m {msg}")
def warn(msg):
    print(f"\033[33m[WARN]\033[0m {msg}")
def err(msg):
    print(f"\033[31m[ERROR]\033[0m {msg}")

def read_input(opts):
    source_path = opts.get('from_file') or opts.get('file_path')
    if opts.get('from_clipboard'):
        raise RuntimeError('Unknown error while interacting with the clipboard: X11 server connection timed out because it was unreachable')
    if 'from_code' in opts:
        return opts.get('from_code',''), source_path
    if opts.get('from_file'):
        p = Path(opts['from_file'])
        return p.read_text(encoding='utf-8', errors='replace'), str(p)
    if opts.get('execute') is not None:
        vals = opts.get('execute') or []
        if opts.get('skip'):
            return ' '.join(vals), source_path
        if not vals:
            return '', source_path
        try:
            cp = subprocess.run(vals, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return cp.stdout, source_path
        except Exception as e:
            raise RuntimeError(str(e))
    if opts.get('from_image'):
        p = Path(opts['from_image'])
        if p.exists():
            return p.read_text(encoding='utf-8', errors='replace'), str(p)
        return opts.get('from_image') or '', source_path
    raise RuntimeError('No code snippet provided')

def parse_range(range_text, n):
    if not range_text:
        return 0, n
    if ':' in range_text:
        left, right = range_text.split(':', 1)
        start = int(left) if left else 1
        end = int(right) if right else n
    else:
        start = int(range_text); end = start
    start = max(1, start)
    end = max(start, end)
    return start - 1, min(n, end)

def apply_range(code, opts):
    lines = code.splitlines()
    trailing = code.endswith('\n')
    if opts.get('range'):
        a,b = parse_range(opts['range'], len(lines))
        lines = lines[a:b]
    out = '\n'.join(lines)
    if trailing and out:
        out += '\n'
    return out

def make_svg(code, opts, path_hint=None):
    raw_lines = code.splitlines() or ['']
    font = opts.get('code_font_family') or 'CaskaydiaCove Nerd Font, Consolas, monospace'
    title = opts.get('title') or (Path(path_hint).name if path_hint else '')
    watermark = opts.get('watermark')
    start_no = int(opts.get('start_line_number') or 1)
    show_no = bool(opts.get('has_line_number'))
    show_bc = str(opts.get('has_breadcrumbs','false')).lower() == 'true'
    sep = opts.get('breadcrumbs_separator') or '/'
    line_h = 24
    max_chars = max([len(x) for x in raw_lines] + [len(title), 12])
    gutter = 52 if show_no else 0
    width = max(420, min(2200, 170 + gutter + max_chars * 9))
    top = 96 + (24 if (show_bc and path_hint) else 0) + (24 if title else 0)
    height = top + line_h * len(raw_lines) + (42 if watermark else 26)
    bg = opts.get('background') or '#10151f'
    if not bg.startswith('#'):
        bg = '#10151f'
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">']
    parts.append('<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6bcba5"/><stop offset="1" stop-color="#caf4c2"/></linearGradient></defs>')
    parts.append('<rect width="100%" height="100%" fill="url(#bg)"/>')
    parts.append(f'<rect x="42" y="42" width="{width-84}" height="{height-84}" rx="12" fill="{html.escape(bg)}" stroke="#ffffff30"/>')
    if str(opts.get('mac_window_bar','true')).lower() != 'false':
        for idx, color in enumerate(['#ff5f57','#ffbd2e','#28c840']):
            parts.append(f'<circle cx="{68+idx*22}" cy="66" r="6" fill="{color}"/>')
    y = 78
    if title:
        parts.append(f'<text x="{width//2}" y="{y}" text-anchor="middle" fill="{html.escape(opts.get("title_color") or "#ffffff")}" font-family="{html.escape(font)}" font-size="17">{html.escape(title)}</text>')
        y += 24
    if show_bc and path_hint:
        crumb = str(path_hint).replace(os.sep, sep)
        parts.append(f'<text x="62" y="{y}" fill="{html.escape(opts.get("breadcrumbs_color") or "#80848b")}" font-family="{html.escape(font)}" font-size="13">{html.escape(crumb)}</text>')
        y += 22
    y = max(y + 12, top - line_h * len(raw_lines))
    add_set = {int(x) for x in opts.get('add_line',[]) if str(x).isdigit()}
    del_set = {int(x) for x in opts.get('delete_line',[]) if str(x).isdigit()}
    hi_a = hi_b = None
    if opts.get('highlight_range'):
        try: hi_a, hi_b = parse_range(opts['highlight_range'], len(raw_lines)); hi_a += 1
        except Exception: pass
    for idx, line in enumerate(raw_lines, start=1):
        yy = y + (idx-1)*line_h
        if idx in add_set:
            parts.append(f'<rect x="42" y="{yy-17}" width="{width-84}" height="24" fill="{html.escape(opts.get("add_line_color") or "#2ecc7130")}"/>')
        if idx in del_set:
            parts.append(f'<rect x="42" y="{yy-17}" width="{width-84}" height="24" fill="{html.escape(opts.get("delete_line_color") or "#ff6b6b30")}"/>')
        if hi_a is not None and hi_a <= idx <= hi_b:
            parts.append(f'<rect x="42" y="{yy-17}" width="{width-84}" height="24" fill="{html.escape(opts.get("highlight_range_color") or "#ffffff10")}"/>')
        x = 68
        if show_no:
            parts.append(f'<text x="{x+30}" y="{yy}" text-anchor="end" fill="{html.escape(opts.get("line_number_color") or "#495162")}" font-family="{html.escape(font)}" font-size="15">{start_no+idx-1}</text>')
            x += gutter
        parts.append(f'<text x="{x}" y="{yy}" fill="#e6edf3" font-family="{html.escape(font)}" font-size="15" xml:space="preserve">{html.escape(line)}</text>')
    if watermark:
        parts.append(f'<text x="{width-62}" y="{height-58}" text-anchor="end" fill="{html.escape(opts.get("watermark_color") or "#ffffff")}" opacity="0.75" font-family="{html.escape(font)}" font-size="16">{html.escape(watermark)}</text>')
    parts.append('</svg>')
    return ''.join(parts)

def png_chunk(kind, data):
    import struct
    return struct.pack('!I', len(data)) + kind + data + struct.pack('!I', zlib.crc32(kind + data) & 0xffffffff)

def make_png(code, opts):
    # Valid PNG with a simple deterministic color field. Text rendering is intentionally left to SVG/HTML.
    lines = code.splitlines() or ['']
    w = max(320, min(1200, 180 + max(len(x) for x in lines) * 8))
    h = max(180, min(1600, 120 + len(lines) * 22))
    rows = []
    for y in range(h):
        row = bytearray([0])
        for x in range(w):
            if 40 <= x < w-40 and 40 <= y < h-40:
                r,g,b = (16,21,31)
            else:
                t = x / max(1,w-1)
                r = int(107*(1-t) + 202*t); g = int(203*(1-t) + 244*t); b = int(165*(1-t) + 194*t)
            row.extend([r,g,b,255])
        rows.append(bytes(row))
    import struct
    raw = b''.join(rows)
    return b'\x89PNG\r\n\x1a\n' + png_chunk(b'IHDR', struct.pack('!IIBBBBB', w, h, 8, 6, 0, 0, 0)) + png_chunk(b'IDAT', zlib.compress(raw, 6)) + png_chunk(b'IEND', b'')

def write_output(out, code, opts, path_hint):
    if opts.get('type') not in (None, 'image', 'ascii'):
        sys.stderr.write(f"error: invalid value '{opts.get('type')}' for '--type <TYPE>'\n  [possible values: ascii, image]\n\nFor more information, try '--help'.\n")
        return 2
    if opts.get('type') == 'ascii':
        warn('ASCII snapshot only supports copying to clipboard')
        return 0
    if out == 'clipboard':
        err('Unknown error while interacting with the clipboard: X11 server connection timed out because it was unreachable')
        return 1
    ext = Path(out).suffix.lower()
    if ext not in ('.svg', '.png', '.html', '.htm'):
        err('Unsupported output format')
        return 1
    p = Path(out)
    if p.exists() and p.is_dir():
        err('Unsupported output format')
        return 1
    p.parent.mkdir(parents=True, exist_ok=True)
    if ext == '.svg':
        p.write_text(make_svg(code, opts, path_hint), encoding='utf-8')
    elif ext in ('.html', '.htm'):
        png64 = base64.b64encode(make_png(code, opts)).decode('ascii')
        pre = html.escape(code)
        p.write_text(f'<img src="data:image/png;base64,{png64}" />\n<!--\n{pre}\n-->\n', encoding='utf-8')
    else:
        p.write_bytes(make_png(code, opts))
    if not opts.get('silent'):
        success(f'Snapshot saved to {out} successful!')
    return 0

def main(argv):
    try:
        opts = parse_args(argv)
    except CliError as e:
        sys.stderr.write(e.msg + ('\n' if not e.msg.endswith('\n') else ''))
        return e.status
    if opts.get('help'):
        print(HELP_SHORT if opts['help'] == '-h' else HELP_LONG)
        return 0
    if opts.get('version'):
        print(VERSION)
        return 0
    if opts.get('type') not in ('ascii','image'):
        sys.stderr.write(f"error: invalid value '{opts.get('type')}' for '--type <TYPE>'\n  [possible values: ascii, image]\n\nFor more information, try '--help'.\n")
        return 2
    if not opts.get('output'):
        sys.stderr.write("error: the following required arguments were not provided:\n  --output <OUTPUT>\n\nUsage: codesnap --output <OUTPUT>\n\nFor more information, try '--help'.\n")
        return 2
    created = ensure_config()
    if created and not opts.get('silent'):
        info(f'Automated created config file at "{created}"')
    if opts.get('config'):
        try:
            cfg_text = Path(opts['config']).read_text(encoding='utf-8') if Path(opts['config']).exists() else opts['config']
            json.loads(cfg_text)
        except Exception as e:
            err(str(e)); return 1
    try:
        code, path_hint = read_input(opts)
        code = apply_range(code, opts)
    except Exception as e:
        err(str(e))
        return 1
    return write_output(opts['output'], code, opts, path_hint)

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
