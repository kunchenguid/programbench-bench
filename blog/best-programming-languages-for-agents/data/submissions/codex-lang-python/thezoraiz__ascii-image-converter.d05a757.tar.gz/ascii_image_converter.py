#!/usr/bin/env python3
import argparse
import io
import os
import shutil
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFont, ImageOps
except Exception as exc:  # pragma: no cover
    print(f"Error: failed to import Pillow: {exc}\n")
    sys.exit(0)


VERSION = "v1.13.1"
DEFAULT_MAP = " .:-=+*#%@"
COMPLEX_MAP = " .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$"
COLOR_ERROR = "Error: your terminal supports neither 24-bit nor 8-bit colors. Other coloring options aren't available\n"
HELP = """This tool converts images into ascii art and prints them on the terminal.
Further configuration can be managed with flags.

Usage:
  ascii-image-converter [image paths/urls or piped stdin] [flags]

Flags:
  -C, --color             Display ascii art with original colors
                          If 24-bit colors aren't supported, uses 8-bit
                          (Inverts with --negative flag)
                          (Overrides --grayscale and --font-color flags)
                          
      --color-bg          If some color flag is passed, use that color
                          on character background instead of foreground
                          (Inverts with --negative flag)
                          (Only applicable for terminal display)
                          
  -d, --dimensions ints   Set width and height for ascii art in CHARACTER length
                          e.g. -d 60,30 (defaults to terminal height)
                          (Overrides --width and --height flags)
                          
  -W, --width int         Set width for ascii art in CHARACTER length
                          Height is kept to aspect ratio
                          e.g. -W 60
                          
  -H, --height int        Set height for ascii art in CHARACTER length
                          Width is kept to aspect ratio
                          e.g. -H 60
                          
  -m, --map string        Give custom ascii characters to map against
                          Ordered from darkest to lightest
                          e.g. -m " .-+#@" (Quotation marks excluded from map)
                          (Overrides --complex flag)
                          
  -b, --braille           Use braille characters instead of ascii
                          Terminal must support braille patterns properly
                          (Overrides --complex and --map flags)
                          
      --threshold int     Threshold for braille art
                          Value between 0-255 is accepted
                          e.g. --threshold 170
                          (Defaults to 128)
                          
      --dither            Apply dithering on image for braille
                          art conversion
                          (Only applicable with --braille flag)
                          (Negates --threshold flag)
                          
  -g, --grayscale         Display grayscale ascii art
                          (Inverts with --negative flag)
                          (Overrides --font-color flag)
                          
  -c, --complex           Display ascii characters in a larger range
                          May result in higher quality
                          
  -f, --full              Use largest dimensions for ascii art
                          that fill the terminal width
                          (Overrides --dimensions, --width and --height flags)
                          
  -n, --negative          Display ascii art in negative colors
                          
  -x, --flipX             Flip ascii art horizontally
                          
  -y, --flipY             Flip ascii art vertically
                          
  -s, --save-img string   Save ascii art as a .png file
                          Format: <image-name>-ascii-art.png
                          Image will be saved in passed path
                          (pass . for current directory)
                          
      --save-txt string   Save ascii art as a .txt file
                          Format: <image-name>-ascii-art.txt
                          File will be saved in passed path
                          (pass . for current directory)
                          
      --save-gif string   If input is a gif, save it as a .gif file
                          Format: <gif-name>-ascii-art.gif
                          Gif will be saved in passed path
                          (pass . for current directory)
                          
      --save-bg ints      Set background color for --save-img
                          and --save-gif flags
                          Pass an RGBA value
                          e.g. --save-bg 255,255,255,100
                          (Defaults to 0,0,0,100)
                          
      --font string       Set font for --save-img and --save-gif flags
                          Pass file path to font .ttf file
                          e.g. --font ./RobotoMono-Regular.ttf
                          (Defaults to Hack-Regular for ascii and
                           DejaVuSans-Oblique for braille)
                          
      --font-color ints   Set font color for terminal as well as
                          --save-img and --save-gif flags
                          Pass an RGB value
                          e.g. --font-color 0,0,0
                          (Defaults to 255,255,255)
                          
      --only-save         Don't print ascii art on terminal
                          if some saving flag is passed
                          
      --formats           Display supported input formats
                          
  -h, --help              Help for ascii-image-converter
                          
  -v, --version           Version for ascii-image-converter

Copyright © 2021 Zoraiz Hassan <hzoraiz8@gmail.com>
Distributed under the Apache License Version 2.0 (Apache-2.0)
For further details, visit https://github.com/TheZoraiz/ascii-image-converter"""


class Parser(argparse.ArgumentParser):
    def error(self, message):
        flag = ""
        if "invalid int value" in message and "--dimensions" in " ".join(sys.argv):
            bad = message.split(":")[-1].strip().strip("'")
            message = f'invalid argument "{bad}" for "-d, --dimensions" flag: strconv.Atoi: parsing "{bad}": invalid syntax'
        print(f"Error: {message}")
        print(HELP)
        print()
        print(message)
        raise SystemExit(1)


def parse_csv_ints(value, count, name):
    parts = value.split(",")
    if len(parts) != count:
        raise ValueError(f"requires {count} {name}, got {len(parts)}")
    out = []
    for p in parts:
        try:
            out.append(int(p))
        except ValueError:
            raise ValueError(f'invalid argument "{p}" for "-d, --dimensions" flag: strconv.Atoi: parsing "{p}": invalid syntax')
    return tuple(out)


def output_error(msg):
    print(f"Error: {msg}\n")


def image_name(path):
    if path == "-":
        return "stdin"
    return Path(path).stem


STDIN_DATA = None


def load_image(path):
    try:
        if path == "-":
            data = STDIN_DATA if STDIN_DATA is not None else sys.stdin.buffer.read()
            try:
                return Image.open(io.BytesIO(data)).convert("RGBA")
            except Exception:
                output_error("can't decode piped input: image: unknown format")
                return None
        return Image.open(path).convert("RGBA")
    except FileNotFoundError:
        output_error(f"unable to open file: open {path}: no such file or directory")
    except Exception as exc:
        output_error(f"can't decode image: {exc}")
    return None


def target_size(img, args):
    w, h = img.size
    if args.full:
        tw = shutil.get_terminal_size((80, 24)).columns
        return max(1, tw), max(1, int(round(tw * h / w / 2)))
    if args.dimensions:
        return args.dimensions
    if args.width:
        return max(1, args.width), max(1, int(round(args.width * h / w / 2)))
    if args.height:
        return max(1, int(round(args.height * w / h * 2))), max(1, args.height)
    th = max(1, shutil.get_terminal_size((80, 24)).lines - 1)
    return max(1, int(round(th * w / h * 2))), th


def char_for(v, cmap):
    idx = int(v * (len(cmap) - 1) / 255)
    if idx < 0:
        idx = 0
    if idx >= len(cmap):
        idx = len(cmap) - 1
    return cmap[idx]


def resize_for_ascii(img, size):
    return img.resize(size, Image.Resampling.BICUBIC)


def ascii_lines(img, args):
    tw, th = target_size(img, args)
    img = resize_for_ascii(img, (tw, th))
    if args.flipX:
        img = ImageOps.mirror(img)
    if args.flipY:
        img = ImageOps.flip(img)
    gray = img.convert("L")
    if args.negative:
        gray = ImageOps.invert(gray)
    cmap = args.map or (COMPLEX_MAP if args.complex else DEFAULT_MAP)
    pix = gray.load()
    lines = []
    for y in range(th):
        lines.append("".join(char_for(pix[x, y], cmap) for x in range(tw)))
    return lines


BRAILLE_BITS = {
    (0, 0): 0x01, (0, 1): 0x02, (0, 2): 0x04, (0, 3): 0x40,
    (1, 0): 0x08, (1, 1): 0x10, (1, 2): 0x20, (1, 3): 0x80,
}


def braille_lines(img, args):
    tw, th = target_size(img, args)
    img = img.resize((tw * 2, th * 4), Image.Resampling.BICUBIC).convert("L")
    if args.flipX:
        img = ImageOps.mirror(img)
    if args.flipY:
        img = ImageOps.flip(img)
    if args.negative:
        img = ImageOps.invert(img)
    if args.dither:
        img = img.convert("1").convert("L")
    pix = img.load()
    threshold = args.threshold
    lines = []
    for cy in range(th):
        row = []
        for cx in range(tw):
            mask = 0
            for dy in range(4):
                for dx in range(2):
                    if pix[cx * 2 + dx, cy * 4 + dy] > threshold:
                        mask |= BRAILLE_BITS[(dx, dy)]
            row.append(chr(0x2800 + mask))
        lines.append("".join(row))
    return lines


def save_text(path, src, lines):
    os.makedirs(path, exist_ok=True)
    out = Path(path) / f"{image_name(src)}-ascii-art.txt"
    out.write_text("\n".join(lines), encoding="utf-8")


def save_image(path, src, lines, args):
    os.makedirs(path, exist_ok=True)
    font = None
    if args.font:
        try:
            font = ImageFont.truetype(args.font, 14)
        except Exception:
            font = None
    if font is None:
        for candidate in ("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
            if os.path.exists(candidate):
                font = ImageFont.truetype(candidate, 14)
                break
    if font is None:
        font = ImageFont.load_default()
    sample = "M"
    box = ImageDraw.Draw(Image.new("RGB", (1, 1))).textbbox((0, 0), sample, font=font)
    cw, ch = max(1, box[2] - box[0]), max(1, box[3] - box[1] + 2)
    width = max(1, max((len(line) for line in lines), default=1) * cw)
    height = max(1, len(lines) * ch)
    bg = tuple(args.save_bg or (0, 0, 0, 100))
    fg = tuple(args.font_color or (255, 255, 255))
    im = Image.new("RGBA", (width, height), bg)
    draw = ImageDraw.Draw(im)
    for i, line in enumerate(lines):
        draw.text((0, i * ch), line, font=font, fill=fg + (255,))
    im.save(Path(path) / f"{image_name(src)}-ascii-art.png")


def build_parser():
    p = Parser(add_help=False, prog="ascii-image-converter", allow_abbrev=False)
    p.add_argument("inputs", nargs="*")
    p.add_argument("-C", "--color", action="store_true")
    p.add_argument("--color-bg", action="store_true")
    p.add_argument("-d", "--dimensions")
    p.add_argument("-W", "--width", type=int)
    p.add_argument("-H", "--height", type=int)
    p.add_argument("-m", "--map")
    p.add_argument("-b", "--braille", action="store_true")
    p.add_argument("--threshold", type=int, default=128)
    p.add_argument("--dither", action="store_true")
    p.add_argument("-g", "--grayscale", action="store_true")
    p.add_argument("-c", "--complex", action="store_true")
    p.add_argument("-f", "--full", action="store_true")
    p.add_argument("-n", "--negative", action="store_true")
    p.add_argument("-x", "--flipX", action="store_true")
    p.add_argument("-y", "--flipY", action="store_true")
    p.add_argument("-s", "--save-img")
    p.add_argument("--save-txt")
    p.add_argument("--save-gif")
    p.add_argument("--save-bg")
    p.add_argument("--font")
    p.add_argument("--font-color")
    p.add_argument("--only-save", action="store_true")
    p.add_argument("--formats", action="store_true")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-v", "--version", action="store_true")
    return p


def main(argv=None):
    global STDIN_DATA
    args = build_parser().parse_args(argv)
    if args.help:
        print(HELP)
        return 0
    if args.version:
        print(VERSION)
        return 0
    if args.formats:
        print("Supported input formats:\n\nJPEG/JPG\nPNG\nWEBP\nBMP\nTIFF/TIF\nGIF")
        return 0
    if args.color or args.color_bg or args.grayscale or args.font_color:
        output_error(COLOR_ERROR[7:])
        return 0
    if args.dimensions:
        try:
            args.dimensions = parse_csv_ints(args.dimensions, 2, "dimensions")
        except ValueError as exc:
            output_error(str(exc))
            return 0
    if args.save_bg:
        try:
            args.save_bg = parse_csv_ints(args.save_bg, 4, "colors")
        except ValueError as exc:
            output_error(str(exc))
            return 0
    if args.font_color:
        try:
            args.font_color = parse_csv_ints(args.font_color, 3, "colors")
        except ValueError as exc:
            output_error(str(exc))
            return 0
    else:
        args.font_color = (255, 255, 255)
    if args.threshold < 0 or args.threshold > 255:
        output_error("threshold must be between 0 and 255")
        return 0
    if not args.inputs:
        data = b"" if sys.stdin.isatty() else sys.stdin.buffer.read()
        if not data:
            output_error("Need at least 1 input path/url or piped input\nUse the -h flag for more info")
            return 0
        STDIN_DATA = data
        args.inputs = ["-"]
    for src in args.inputs:
        img = load_image(src)
        if img is None:
            continue
        lines = braille_lines(img, args) if args.braille else ascii_lines(img, args)
        if args.flipX and args.braille:
            pass
        if args.save_txt:
            save_text(args.save_txt, src, lines)
        if args.save_img:
            save_image(args.save_img, src, lines, args)
        if args.save_gif:
            # Minimal support: save the first frame as a GIF.
            os.makedirs(args.save_gif, exist_ok=True)
            tmp = Path(args.save_gif) / f"{image_name(src)}-ascii-art.gif"
            frame = Image.new("RGBA", (1, 1), tuple(args.save_bg or (0, 0, 0, 100)))
            frame.save(tmp, save_all=True)
        if not (args.only_save and (args.save_txt or args.save_img or args.save_gif)):
            print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
