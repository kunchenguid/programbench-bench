#!/usr/bin/env python3
import fnmatch
import json
import os
import re
import sys
from dataclasses import dataclass


HELP = """wrapcheck: Checks that errors returned from external packages are wrapped

Usage: wrapcheck [-flag] [package]


Flags:
  -V\tprint version and exit
  -all
    \tno effect (deprecated)
  -c int
    \tdisplay offending line with this many lines of context (default -1)
  -cpuprofile string
    \twrite CPU profile to this file
  -debug string
    \tdebug flags, any subset of "fpstv"
  -diff
    \twith -fix, don't update the files, but print a unified diff
  -fix
    \tapply all suggested fixes
  -flags
    \tprint analyzer flags in JSON
  -json
    \temit JSON output
  -memprofile string
    \twrite memory profile to this file
  -source
    \tno effect (deprecated)
  -tags string
    \tno effect (deprecated)
  -test
    \tindicates whether test files should be analyzed, too (default true)
  -trace string
    \twrite trace log to this file
  -v\tno effect (deprecated)
"""

FLAGS_JSON = [
    {"Name": "V", "Bool": True, "Usage": "print version and exit"},
    {"Name": "all", "Bool": True, "Usage": "no effect (deprecated)"},
    {"Name": "c", "Bool": False, "Usage": "display offending line with this many lines of context"},
    {"Name": "diff", "Bool": True, "Usage": "with -fix, don't update the files, but print a unified diff"},
    {"Name": "flags", "Bool": True, "Usage": "print analyzer flags in JSON"},
    {"Name": "json", "Bool": True, "Usage": "emit JSON output"},
    {"Name": "source", "Bool": True, "Usage": "no effect (deprecated)"},
    {"Name": "tags", "Bool": False, "Usage": "no effect (deprecated)"},
    {"Name": "test", "Bool": True, "Usage": "indicates whether test files should be analyzed, too"},
    {"Name": "v", "Bool": True, "Usage": "no effect (deprecated)"},
]

DEFAULT_IGNORE_SIGS = [
    ".Errorf(",
    "errors.New(",
    "errors.Unwrap(",
    "errors.Join(",
    ".Wrap(",
    ".Wrapf(",
    ".WithMessage(",
    ".WithMessagef(",
    ".WithStack(",
]


@dataclass
class Config:
    ignore_sigs: list
    ignore_regexps: list
    ignore_pkg_globs: list
    report_internal: bool


@dataclass
class Diagnostic:
    file: str
    line: int
    col: int
    message: str
    pkg: str


def eprint(msg):
    print(msg, file=sys.stderr)


def parse_args(argv):
    opts = {"json": False, "test": True, "flags": False, "context": -1}
    packages = []
    takes_value = {"c", "cpuprofile", "debug", "memprofile", "tags", "trace"}
    bools = {"all", "diff", "fix", "flags", "json", "source", "test", "v"}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "-help", "--help"):
            print(HELP)
            raise SystemExit(0)
        if arg == "--":
            packages.extend(argv[i + 1 :])
            break
        if not arg.startswith("-") or arg == "-":
            packages.append(arg)
            i += 1
            continue
        nameval = arg[1:]
        if nameval.startswith("-"):
            nameval = nameval[1:]
        if "=" in nameval:
            name, val = nameval.split("=", 1)
        else:
            name, val = nameval, None
        if name == "V":
            if val == "full":
                eprint("wrapcheck: open /workspace/executable: permission denied")
                raise SystemExit(1)
            eprint(f"wrapcheck: unsupported flag value: -V={val or 'true'} (use -V=full)")
            raise SystemExit(1)
        if name in bools:
            if val is not None:
                opts[name] = val.lower() not in ("0", "false")
            else:
                opts[name] = True
            i += 1
            continue
        if name in takes_value:
            if val is None:
                i += 1
                if i >= len(argv):
                    eprint(f"flag needs an argument: -{name}")
                    print(HELP, file=sys.stderr)
                    raise SystemExit(2)
                val = argv[i]
            if name == "c":
                try:
                    opts["context"] = int(val)
                except ValueError:
                    eprint(f"invalid value \"{val}\" for flag -c: parse error")
                    raise SystemExit(2)
            i += 1
            continue
        eprint(f"flag provided but not defined: -{name}")
        print(HELP, file=sys.stderr)
        raise SystemExit(2)
    return opts, packages


def strip_comments_and_strings(line):
    out = []
    i = 0
    in_str = None
    while i < len(line):
        ch = line[i]
        nxt = line[i + 1] if i + 1 < len(line) else ""
        if in_str:
            out.append(" ")
            if ch == "\\" and in_str != "`":
                if i + 1 < len(line):
                    out.append(" ")
                    i += 2
                    continue
            if ch == in_str:
                in_str = None
            i += 1
            continue
        if ch in ("'", '"', "`"):
            in_str = ch
            out.append(" ")
            i += 1
            continue
        if ch == "/" and nxt == "/":
            break
        out.append(ch)
        i += 1
    return "".join(out)


def read_module_path(start):
    cur = os.path.abspath(start)
    while True:
        gomod = os.path.join(cur, "go.mod")
        if os.path.exists(gomod):
            try:
                for line in open(gomod, encoding="utf-8", errors="ignore"):
                    m = re.match(r"\s*module\s+(\S+)", line)
                    if m:
                        return m.group(1), cur
            except OSError:
                pass
            return "", cur
        parent = os.path.dirname(cur)
        if parent == cur:
            return "", os.path.abspath(start)
        cur = parent


def load_config(start):
    cfg = Config(DEFAULT_IGNORE_SIGS[:], [], [], False)
    paths = [os.path.join(start, ".wrapcheck.yaml"), os.path.join(os.path.expanduser("~"), ".wrapcheck.yaml")]
    for path in paths:
        if not os.path.exists(path):
            continue
        data = {}
        cur_key = None
        try:
            lines = open(path, encoding="utf-8", errors="ignore").read().splitlines()
        except OSError:
            continue
        for raw in lines:
            line = raw.split("#", 1)[0].rstrip()
            if not line.strip():
                continue
            m = re.match(r"^([A-Za-z][A-Za-z0-9]*):\s*(.*)$", line)
            if m:
                cur_key, val = m.group(1), m.group(2).strip()
                if val:
                    data[cur_key] = val.strip("'\"")
                else:
                    data[cur_key] = []
                continue
            m = re.match(r"^\s*-\s*(.*)$", line)
            if m and cur_key:
                data.setdefault(cur_key, []).append(m.group(1).strip().strip("'\""))
        if "ignoreSigs" in data and isinstance(data["ignoreSigs"], list):
            cfg.ignore_sigs = data["ignoreSigs"][:]
        if "extraIgnoreSigs" in data and isinstance(data["extraIgnoreSigs"], list):
            cfg.ignore_sigs.extend(data["extraIgnoreSigs"])
        if "ignoreSigRegexps" in data and isinstance(data["ignoreSigRegexps"], list):
            cfg.ignore_regexps.extend(data["ignoreSigRegexps"])
        if "ignorePackageGlobs" in data and isinstance(data["ignorePackageGlobs"], list):
            cfg.ignore_pkg_globs.extend(data["ignorePackageGlobs"])
        if str(data.get("reportInternalErrors", "")).lower() == "true":
            cfg.report_internal = True
    return cfg


def package_dirs(patterns):
    if not patterns:
        return []
    dirs = []
    for pat in patterns:
        if pat == "./...":
            root = os.getcwd()
            for cur, subdirs, files in os.walk(root):
                subdirs[:] = [d for d in subdirs if d not in (".git", "vendor", "testdata")]
                if any(f.endswith(".go") for f in files):
                    dirs.append(cur)
        elif pat.endswith("/..."):
            root = os.path.abspath(pat[:-4] or ".")
            for cur, subdirs, files in os.walk(root):
                subdirs[:] = [d for d in subdirs if d not in (".git", "vendor", "testdata")]
                if any(f.endswith(".go") for f in files):
                    dirs.append(cur)
        else:
            path = os.path.abspath(pat)
            if os.path.isdir(path):
                dirs.append(path)
            elif os.path.isfile(path):
                dirs.append(os.path.dirname(path))
    return sorted(set(dirs))


def parse_imports(text):
    imports = {}
    lines = text.splitlines()
    in_block = False
    for line in lines:
        s = line.strip()
        if s.startswith("import ("):
            in_block = True
            continue
        if in_block:
            if s.startswith(")"):
                in_block = False
                continue
            parse_import_line(s, imports)
        elif s.startswith("import "):
            parse_import_line(s[len("import ") :].strip(), imports)
    return imports


def parse_import_line(s, imports):
    m = re.match(r'(?:(\w+|\.)\s+)?\"([^\"]+)\"', s)
    if not m:
        return
    alias, path = m.group(1), m.group(2)
    if alias in (None, "."):
        alias = path.rstrip("/").split("/")[-1]
    if alias != "_":
        imports[alias] = path


def ignored_signature(sig, cfg):
    if any(part and part in sig for part in cfg.ignore_sigs):
        return True
    for rgx in cfg.ignore_regexps:
        try:
            if re.search(rgx, sig):
                return True
        except re.error:
            continue
    return False


def ignored_package(path, cfg):
    return any(fnmatch.fnmatch(path, glob) for glob in cfg.ignore_pkg_globs)


def signature_from_expr(expr, imports):
    expr = expr.strip()
    m = re.search(r"\b([A-Za-z_]\w*)\.([A-Za-z_]\w*)\s*\(", expr)
    if not m:
        return None, None
    alias, name = m.group(1), m.group(2)
    if alias not in imports:
        return None, None
    return f"{imports[alias]}.{name}(", imports[alias]


def call_is_external(expr, imports, cfg):
    sig, pkg = signature_from_expr(expr, imports)
    if not sig or ignored_signature(sig, cfg) or ignored_package(pkg, cfg):
        return None
    return sig


def analyze_file(path, pkg_name, pkg_path, cfg, include_tests):
    if path.endswith("_test.go") and not include_tests:
        return []
    try:
        text = open(path, encoding="utf-8", errors="ignore").read()
    except OSError:
        return []
    imports = parse_imports(text)
    if not imports:
        return []
    diagnostics = []
    err_sources = {}
    lines = text.splitlines()
    for idx, raw in enumerate(lines, 1):
        line = strip_comments_and_strings(raw)
        simple = line.strip()
        assign = re.search(r"(?P<lhs>[\w\s,]+)(?::=|=)\s*(?P<rhs>.+)", simple)
        if assign:
            lhs = [x.strip() for x in assign.group("lhs").split(",")]
            rhs = assign.group("rhs")
            sig = call_is_external(rhs, imports, cfg)
            if sig:
                for name in lhs:
                    if name == "err" or name.endswith("Err") or name.endswith("err"):
                        err_sources[name] = sig
        ret = re.search(r"\breturn\b(?P<expr>.*)", simple)
        if not ret:
            continue
        expr = ret.group("expr").strip()
        if not expr or expr == "nil":
            continue
        parts = [p.strip() for p in expr.split(",")]
        offending_sig = None
        for part in parts:
            if part in err_sources:
                offending_sig = err_sources[part]
                break
            sig = call_is_external(part, imports, cfg)
            if sig:
                offending_sig = sig
                break
            m = re.match(r"([A-Za-z_]\w*)\.[A-Za-z_]\w*$", part)
            if m and m.group(1) in imports and not ignored_package(imports[m.group(1)], cfg):
                offending_sig = imports[m.group(1)] + "." + part.split(".", 1)[1]
                break
        if offending_sig:
            col = raw.find("return") + 1
            msg = "error returned from external package is unwrapped"
            diagnostics.append(Diagnostic(path, idx, max(col, 1), msg, pkg_path or pkg_name))
    return diagnostics


def analyze_package_dir(path, cfg, include_tests=True):
    module, root = read_module_path(path)
    rel = os.path.relpath(path, root)
    pkg_path = module if rel == "." else (module + "/" + rel.replace(os.sep, "/") if module else rel)
    files = [f for f in os.listdir(path) if f.endswith(".go")]
    pkg_name = os.path.basename(path)
    diagnostics = []
    for f in sorted(files):
        full = os.path.join(path, f)
        try:
            content = open(full, encoding="utf-8", errors="ignore").read(2000)
            m = re.search(r"(?m)^\s*package\s+(\w+)", content)
            if m:
                pkg_name = m.group(1)
        except OSError:
            pass
        diagnostics.extend(analyze_file(full, pkg_name, pkg_path, cfg, include_tests))
    return diagnostics


def emit_plain(diags, context):
    for d in diags:
        print(f"{d.file}:{d.line}:{d.col}: {d.message}")
        if context >= 0:
            try:
                lines = open(d.file, encoding="utf-8", errors="ignore").read().splitlines()
            except OSError:
                continue
            start = max(1, d.line - context)
            end = min(len(lines), d.line + context)
            for no in range(start, end + 1):
                print(f"{no:5d}: {lines[no - 1]}")


def emit_json(diags):
    out = {}
    for d in diags:
        out.setdefault(d.pkg, {}).setdefault("wrapcheck", []).append(
            {"posn": f"{d.file}:{d.line}:{d.col}", "message": d.message}
        )
    print(json.dumps(out, indent=2, sort_keys=True))


def main(argv):
    opts, packages = parse_args(argv)
    if opts.get("flags"):
        print(json.dumps(FLAGS_JSON, indent="\t"))
        return 0
    if not packages:
        print(HELP)
        return 1
    cfg = load_config(os.getcwd())
    dirs = package_dirs(packages)
    diags = []
    for d in dirs:
        diags.extend(analyze_package_dir(d, cfg, bool(opts.get("test", True))))
    diags.sort(key=lambda x: (x.file, x.line, x.col))
    if opts.get("json"):
        emit_json(diags)
    else:
        emit_plain(diags, opts.get("context", -1))
    return 3 if diags else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
