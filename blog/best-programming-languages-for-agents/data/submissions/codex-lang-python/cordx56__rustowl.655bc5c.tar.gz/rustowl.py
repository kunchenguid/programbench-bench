#!/usr/bin/env python3
import json
import os
import random
import string
import sys
from datetime import datetime, timezone

VERSION = "RustOwl v1.0.0-rc.1"
URL = "https://static.rust-lang.org/dist/2025-06-20/rustc-nightly-x86_64-unknown-linux-gnu.tar.gz"


MAIN_HELP = """Usage: executable [OPTIONS] [COMMAND]

Commands:
  check        Check availability
  clean        Remove artifacts from the target directory
  toolchain    Install or uninstall the toolchain
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Options:
  -V, --version   Print version
  -q, --quiet...  Suppress output
      --stdio     Use stdio to communicate with the LSP server
  -h, --help      Print help
"""

CHECK_HELP = """Check availability

Usage: executable check [OPTIONS] [path]

Arguments:
  [path]  The path of a file or directory to check availability

Options:
      --all-targets   Run the check for all targets instead of current only
      --all-features  Run the check for all features instead of the current active ones only
  -h, --help          Print help
"""

CLEAN_HELP = """Remove artifacts from the target directory

Usage: executable clean

Options:
  -h, --help  Print help
"""

TOOLCHAIN_HELP = """Install or uninstall the toolchain

Usage: executable toolchain [COMMAND]

Commands:
  install    Install the toolchain
  uninstall  Uninstall the toolchain
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

INSTALL_HELP = """Install the toolchain

Usage: executable toolchain install [OPTIONS]

Options:
      --path <path>             Runtime directory path to install RustOwl toolchain
      --skip-rustowl-toolchain  Install Rust toolchain only
  -h, --help                    Print help
"""

UNINSTALL_HELP = """Uninstall the toolchain

Usage: executable toolchain uninstall

Options:
  -h, --help  Print help
"""

COMPLETIONS_HELP = """Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>
          The shell to generate completions for

          Possible values:
          - bash:       Bourne Again `SHell` (bash)
          - elvish:     Elvish shell
          - fish:       Friendly Interactive `SHell` (fish)
          - powershell: `PowerShell`
          - zsh:        Z `SHell` (zsh)
          - nushell:    Nushell

Options:
  -h, --help
          Print help (see a summary with '-h')
"""


def eprint(s=""):
    print(s, file=sys.stderr)


def ts():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:23] + "Z"


def log(level, target, message):
    eprint(f"{ts()} {level:<5} [{target}] {message}")


def random_tmp():
    return "/tmp/.tmp" + "".join(random.choice(string.ascii_letters + string.digits) for _ in range(6))


def network_error():
    return (
        f'reqwest::Error {{ kind: Request, url: "{URL}", source: '
        'hyper_util::client::legacy::Error(Connect, ConnectError("dns error", '
        'Custom { kind: Uncategorized, error: "failed to lookup address information: Temporary failure in name resolution" })) }'
    )


def install_toolchain(prefix=False):
    if prefix:
        log("INFO", "rustowl::toolchain", "sysroot not found; start setup toolchain")
    log("INFO", "rustowl::toolchain", "start installing Rust toolchain...")
    log("INFO", "rustowl::toolchain", f"temp dir is made: {random_tmp()}")
    log("INFO", "rustowl::toolchain", f"start downloading {URL}...")
    log("ERROR", "rustowl::toolchain", "failed to download tarball")
    log("ERROR", "rustowl::toolchain", network_error())
    return 1


def clap_error(msg, usage, tip=None):
    eprint(f"error: {msg}")
    if tip:
        eprint("")
        eprint(f"  tip: {tip}")
    eprint("")
    eprint(usage)
    eprint("")
    eprint("For more information, try '--help'.")
    return 2


def completion(shell):
    if shell == "bash":
        return """_rustowl() {
    local cur opts
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    opts="-V -q -h --version --quiet --stdio --help check clean toolchain completions help"
    COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
}
complete -F _rustowl -o bashdefault -o default rustowl
"""
    if shell == "fish":
        return """complete -c rustowl -s V -l version -d 'Print version'
complete -c rustowl -s q -l quiet -d 'Suppress output'
complete -c rustowl -l stdio -d 'Use stdio to communicate with the LSP server'
complete -c rustowl -s h -l help -d 'Print help'
complete -c rustowl -f -a "check" -d 'Check availability'
complete -c rustowl -f -a "clean" -d 'Remove artifacts from the target directory'
complete -c rustowl -f -a "toolchain" -d 'Install or uninstall the toolchain'
complete -c rustowl -f -a "completions" -d 'Generate shell completions'
"""
    if shell == "zsh":
        return """#compdef rustowl
_arguments '-V[Print version]' '--version[Print version]' '*-q[Suppress output]' '*--quiet[Suppress output]' '--stdio[Use stdio to communicate with the LSP server]' '-h[Print help]' '--help[Print help]' '1: :((check\\:Check\\ availability clean\\:Remove\\ artifacts\\ from\\ the\\ target\\ directory toolchain\\:Install\\ or\\ uninstall\\ the\\ toolchain completions\\:Generate\\ shell\\ completions help\\:Print\\ this\\ message\\ or\\ the\\ help\\ of\\ the\\ given\\ subcommand\\(s\\)))'
"""
    if shell == "elvish":
        return "use builtin;\nuse str;\n# completions for rustowl: check clean toolchain completions help\n"
    if shell == "powershell":
        return "Register-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock { param($wordToComplete, $commandAst, $cursorPosition) }\n"
    if shell == "nushell":
        return """module completions {
  export extern rustowl [
    --version(-V)             # Print version
    --quiet(-q)               # Suppress output
    --stdio                   # Use stdio to communicate with the LSP server
    --help(-h)                # Print help
  ]
  export extern "rustowl check" [ --all-targets --all-features path?: path ]
  export extern "rustowl toolchain install" [ --path: path --skip-rustowl-toolchain ]
}
"""
    return None


def send_lsp(obj):
    data = json.dumps(obj, separators=(",", ":")).encode()
    sys.stdout.buffer.write(b"Content-Length: " + str(len(data)).encode() + b"\r\n\r\n" + data)
    sys.stdout.buffer.flush()


def stdio_loop():
    eprint(VERSION)
    eprint("This is an LSP server. You can use --help flag to show help.")
    while True:
        headers = {}
        line = sys.stdin.buffer.readline()
        if not line:
            return 0
        while line not in (b"\r\n", b"\n", b""):
            if b":" in line:
                k, v = line.decode(errors="ignore").split(":", 1)
                headers[k.lower()] = v.strip()
            line = sys.stdin.buffer.readline()
        try:
            n = int(headers.get("content-length", "0"))
        except ValueError:
            n = 0
        if n <= 0:
            continue
        raw = sys.stdin.buffer.read(n)
        try:
            msg = json.loads(raw.decode())
        except Exception:
            continue
        mid = msg.get("id")
        method = msg.get("method")
        if method == "initialize" and mid is not None:
            send_lsp({"jsonrpc": "2.0", "id": mid, "result": {"capabilities": {"textDocumentSync": 1, "hoverProvider": True, "codeLensProvider": {"resolveProvider": False}}, "serverInfo": {"name": "RustOwl", "version": "1.0.0-rc.1"}}})
        elif method == "shutdown" and mid is not None:
            send_lsp({"jsonrpc": "2.0", "id": mid, "result": None})
        elif method == "textDocument/hover" and mid is not None:
            send_lsp({"jsonrpc": "2.0", "id": mid, "result": None})
        elif method == "exit":
            return 0
        elif mid is not None:
            send_lsp({"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": "Method not found"}})


def handle_check(args):
    path = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(CHECK_HELP, end="")
            return 0
        if a in ("--all-targets", "--all-features"):
            i += 1
            continue
        if a.startswith("-"):
            return clap_error(f"unexpected argument '{a}' found", "Usage: executable check [OPTIONS] [path]", f"to pass '{a}' as a value, use '-- {a}'")
        if path is not None:
            return clap_error(f"unexpected argument '{a}' found", "Usage: executable check [OPTIONS] [path]")
        path = a
        i += 1
    target = path or os.getcwd()
    if path and not os.path.exists(path):
        log("WARN", "rustowl::toolchain", "cargo not found; fallback")
        log("WARN", "rustowl::toolchain", "rustowlc not found; fallback")
        log("WARN", "rustowl::lsp::analyze", f"Invalid analysis target: {path}")
        log("ERROR", "rustowl", "Analyze failed")
        return 1
    rc = install_toolchain(prefix=True)
    log("ERROR", "rustowl::toolchain", "()")
    return rc


def handle_toolchain(args):
    if not args:
        return 0
    if args[0] in ("-h", "--help", "help"):
        if len(args) >= 2 and args[1] == "install":
            print(INSTALL_HELP, end="")
        elif len(args) >= 2 and args[1] == "uninstall":
            print(UNINSTALL_HELP, end="")
        else:
            print(TOOLCHAIN_HELP, end="")
        return 0
    if args[0] == "install":
        rest = args[1:]
        i = 0
        while i < len(rest):
            a = rest[i]
            if a in ("-h", "--help"):
                print(INSTALL_HELP, end="")
                return 0
            if a == "--skip-rustowl-toolchain":
                i += 1
                continue
            if a == "--path":
                if i + 1 >= len(rest):
                    eprint("error: a value is required for '--path <path>' but none was supplied\n")
                    eprint("For more information, try '--help'.")
                    return 2
                i += 2
                continue
            if a.startswith("--path="):
                i += 1
                continue
            return clap_error(f"unexpected argument '{a}' found", "Usage: executable toolchain install [OPTIONS]")
        return install_toolchain(False)
    if args[0] == "uninstall":
        if len(args) > 1 and args[1] in ("-h", "--help"):
            print(UNINSTALL_HELP, end="")
            return 0
        if len(args) > 1:
            return clap_error(f"unexpected argument '{args[1]}' found", "Usage: executable toolchain uninstall")
        log("INFO", "rustowl::toolchain", "remove sysroot: /home/agent/.rustowl/sysroot/nightly-2025-06-20-x86_64-unknown-linux-gnu")
        return 0
    return clap_error(f"unrecognized subcommand '{args[0]}'", "Usage: executable toolchain [COMMAND]")


def main(argv):
    quiet = 0
    args = list(argv)
    while args and args[0] in ("-q", "--quiet"):
        quiet += 1
        args.pop(0)
    if args and args[0].startswith("-q") and set(args[0]) == {"-", "q"}:
        quiet += len(args[0]) - 1
        args.pop(0)
    if not args:
        print(VERSION)
        print("This is an LSP server. You can use --help flag to show help.")
        return 0
    if args[0] in ("-h", "--help", "help"):
        if len(args) >= 2 and args[1] == "check":
            print(CHECK_HELP, end="")
        elif len(args) >= 2 and args[1] == "clean":
            print(CLEAN_HELP, end="")
        elif len(args) >= 2 and args[1] == "toolchain":
            return handle_toolchain(["help"] + args[2:])
        elif len(args) >= 2 and args[1] == "completions":
            print(COMPLETIONS_HELP, end="")
        else:
            print(MAIN_HELP, end="")
        return 0
    if args[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    if args[0] == "--stdio":
        return stdio_loop()
    if args[0].startswith("-"):
        return clap_error(f"unexpected argument '{args[0]}' found", "Usage: executable [OPTIONS] [COMMAND]")
    cmd, rest = args[0], args[1:]
    if cmd == "check":
        return handle_check(rest)
    if cmd == "clean":
        if rest and rest[0] in ("-h", "--help"):
            print(CLEAN_HELP, end="")
            return 0
        if rest:
            return clap_error(f"unexpected argument '{rest[0]}' found", "Usage: executable clean")
        return 0
    if cmd == "toolchain":
        return handle_toolchain(rest)
    if cmd == "completions":
        if rest and rest[0] in ("-h", "--help"):
            print(COMPLETIONS_HELP, end="")
            return 0
        if not rest:
            return clap_error("the following required arguments were not provided:\n  <SHELL>", "Usage: executable completions <SHELL>")
        out = completion(rest[0])
        if out is None:
            eprint(f"error: invalid value '{rest[0]}' for '<SHELL>'")
            eprint("  [possible values: bash, elvish, fish, powershell, zsh, nushell]\n")
            eprint("  tip: a similar value exists: 'bash'\n")
            eprint("For more information, try '--help'.")
            return 2
        print(out, end="")
        return 0
    return clap_error(f"unrecognized subcommand '{cmd}'", "Usage: executable [OPTIONS] [COMMAND]")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
