#!/usr/bin/env python3
import argparse
import fnmatch
import os
import re
import shutil
import stat
import sys
import tempfile
from pathlib import Path


VERSION = "ambr 0.6.0"
VCS_DIRS = {".git", ".hg", ".svn", ".bzr"}


def build_parser():
    p = argparse.ArgumentParser(
        prog="executable",
        usage="%(prog)s [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...",
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("--key-from-file", action="store_true")
    p.add_argument("--rep-from-file", action="store_true")
    p.add_argument("--verbose", action="store_true")
    p.add_argument("-r", "--regex", action="store_true")
    p.add_argument("--column", action="store_true")
    p.add_argument("--row", action="store_true")
    p.add_argument("--binary", action="store_true")
    p.add_argument("--statistics", action="store_true")
    p.add_argument("--skipped", action="store_true")
    p.add_argument("--preserve-time", action="store_true")
    p.add_argument("--no-interactive", action="store_true")
    p.add_argument("--no-recursive", action="store_true")
    p.add_argument("--no-symlink", action="store_true")
    p.add_argument("--no-color", action="store_true")
    p.add_argument("--no-file", action="store_true")
    p.add_argument("--no-skip-vcs", action="store_true")
    p.add_argument("--no-skip-gitignore", action="store_true")
    p.add_argument("--no-fixed-order", action="store_true")
    p.add_argument("--no-parent-ignore", action="store_true")
    p.add_argument("--tbm", action="store_true")
    p.add_argument("--sse", action="store_true")
    p.add_argument("--max-threads", default="4")
    p.add_argument("--size-per-thread", default="1048576")
    p.add_argument("--bin-check-bytes", default="256")
    p.add_argument("--mmap-bytes", default="1048576")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("keyword", nargs="?")
    p.add_argument("replacement", nargs="?")
    p.add_argument("paths", nargs="*")
    return p


HELP = """ambr 0.6.0

USAGE:
    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...

FLAGS:
        --key-from-file        Use file contents of KEYWORD as keyword for search
        --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement
        --verbose              Verbose message
    -r, --regex                Enable regular expression search
        --column               Enable column output
        --row                  Enable row output
        --binary               Enable binary file search
        --statistics           Enable statistics output
        --skipped              Enable skipped file output
        --preserve-time        Enable timestamp preserve
        --no-interactive       Disable interactive replace
        --no-recursive         Disable recursive directory search
        --no-symlink           Disable symbolic link follow
        --no-color             Disable colored output
        --no-file              Disable filename output
        --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip
        --no-skip-gitignore    Disable .gitignore skip
        --no-fixed-order       Disable output order guarantee
        --no-parent-ignore     Disable .*ignore file search at parent directories
        --tbm                  [Experimental] Enable TBM matcher
        --sse                  [Experimental] Enable SSE 4.2
    -h, --help                 Prints help information
    -V, --version              Prints version information

OPTIONS:
        --max-threads <NUM>          Number of max threads [default: 4]
        --size-per-thread <BYTES>    File size per one thread [default: 1048576]
        --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]
        --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]

ARGS:
    <KEYWORD>        Keyword for search
    <REPLACEMENT>    Keyword for replace
    <PATHS>...       Search paths
"""


def color(args, code, text):
    if args.no_color:
        return text
    return f"\033[{code}m{text}\033[37m"


def load_arg_from_file(value):
    with open(value, "r", encoding="utf-8", errors="surrogateescape") as f:
        return f.read()


def read_ignore_file(path):
    pats = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                pats.append(line)
    except OSError:
        pass
    return pats


def collect_parent_ignores(start):
    pats = []
    cur = Path(start).resolve()
    if cur.is_file():
        cur = cur.parent
    for parent in [cur, *cur.parents]:
        for name in (".gitignore", ".ignore", ".amberignore"):
            pats.extend(read_ignore_file(parent / name))
    return pats


def ignored(path, root, patterns):
    rel = os.path.relpath(path, root)
    base = os.path.basename(path)
    for pat in patterns:
        neg = pat.startswith("!")
        if neg:
            pat = pat[1:]
        pat = pat.strip("/")
        hit = fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(base, pat)
        if "/" not in pat:
            hit = hit or any(fnmatch.fnmatch(part, pat) for part in rel.split(os.sep))
        if hit:
            return not neg
    return False


def iter_files(paths, args):
    roots = paths or ["."]
    all_files = []
    global_ignores = [] if args.no_skip_gitignore or args.no_parent_ignore else collect_parent_ignores(os.getcwd())
    for entry in roots:
        if os.path.isfile(entry) or (os.path.islink(entry) and not os.path.isdir(entry)):
            all_files.append(entry)
            continue
        if not os.path.isdir(entry):
            if args.skipped or args.verbose:
                print(f"{entry}: No such file or directory", file=sys.stderr)
            continue
        local_patterns = [] if args.no_skip_gitignore else global_ignores + read_ignore_file(os.path.join(entry, ".gitignore"))
        if args.no_recursive:
            try:
                names = sorted(os.listdir(entry))
            except OSError as e:
                if args.skipped:
                    print(f"{entry}: {e.strerror}", file=sys.stderr)
                continue
            for name in names:
                p = os.path.join(entry, name)
                if os.path.isfile(p) and not ignored(p, entry, local_patterns):
                    all_files.append(p)
            continue
        for root, dirs, files in os.walk(entry, followlinks=not args.no_symlink):
            if not args.no_skip_vcs:
                dirs[:] = [d for d in dirs if d not in VCS_DIRS]
            if local_patterns:
                dirs[:] = [d for d in dirs if not ignored(os.path.join(root, d), entry, local_patterns)]
            for name in sorted(files):
                p = os.path.join(root, name)
                if local_patterns and ignored(p, entry, local_patterns):
                    continue
                all_files.append(p)
    return sorted(all_files) if not args.no_fixed_order else all_files


def is_binary(path, check_bytes):
    try:
        with open(path, "rb") as f:
            return b"\0" in f.read(check_bytes)
    except OSError:
        return False


def rust_replacement_to_python(rep):
    out = []
    i = 0
    while i < len(rep):
        c = rep[i]
        if c == "$":
            if i + 1 < len(rep) and rep[i + 1] == "$":
                out.append("$")
                i += 2
            elif i + 1 < len(rep) and rep[i + 1] == "{":
                j = rep.find("}", i + 2)
                if j != -1:
                    out.append(r"\g<" + rep[i + 2:j] + ">")
                    i = j + 1
                else:
                    out.append(c)
                    i += 1
            else:
                j = i + 1
                while j < len(rep) and (rep[j].isalnum() or rep[j] == "_"):
                    j += 1
                if j > i + 1:
                    out.append(r"\g<" + rep[i + 1:j] + ">")
                    i = j
                else:
                    out.append(c)
                    i += 1
        elif c == "\\":
            out.append(r"\\")
            i += 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


def line_col(text, pos):
    row = text.count("\n", 0, pos) + 1
    start = text.rfind("\n", 0, pos) + 1
    return row, pos - start + 1


def format_match(path, text, match, replacement, args):
    row, col = line_col(text, match.start())
    line_start = text.rfind("\n", 0, match.start()) + 1
    line_end = text.find("\n", match.end())
    if line_end == -1:
        line_end = len(text)
    line = text[line_start:line_end]
    replaced_line = line[: match.start() - line_start] + replacement + line[match.end() - line_start :]
    prefix = ""
    if not args.no_file:
        prefix += color(args, "32", path) + color(args, "36", ": ")
    if args.row:
        prefix += color(args, "36", f"{row}:")
    if args.column:
        prefix += color(args, "36", f"{col}:")
    return prefix + line + "\n" + color(args, "36", "    -> ") + replaced_line


def replace_file(path, args, pattern, replacement):
    try:
        st = os.stat(path)
        with open(path, "r", encoding="utf-8", errors="surrogateescape", newline="") as f:
            text = f.read()
    except (OSError, UnicodeError) as e:
        if args.skipped:
            print(f"{path}: {e}", file=sys.stderr)
        return 0, False

    if args.regex:
        matches = list(pattern.finditer(text))
        if not matches:
            return 0, False
        new_text = pattern.sub(replacement, text)
    else:
        if args.keyword == "":
            return 0, False
        starts = [m.start() for m in re.finditer(re.escape(args.keyword), text)]
        if not starts:
            return 0, False
        matches = [re.match(re.escape(args.keyword), text[s:]) for s in starts]
        # Rebuild match objects with absolute spans for display by using finditer.
        matches = list(re.finditer(re.escape(args.keyword), text))
        new_text = text.replace(args.keyword, replacement)

    do_replace = args.no_interactive or not sys.stdin.isatty()
    if not args.no_interactive and sys.stdin.isatty():
        for m in matches:
            rep_line = m.expand(replacement) if args.regex else replacement
            print(format_match(path, text, m, rep_line, args))
            ans = input(color(args, "36", "Replace keyword? [Y]es/[n]o/[a]ll/[q]uit: "))
            if ans in ("q", "Q", "Quit"):
                raise KeyboardInterrupt
            if ans in ("a", "A", "All"):
                do_replace = True
                break
            if ans in ("", "y", "Y", "Yes"):
                do_replace = True
                break
            return len(matches), False

    if do_replace and new_text != text:
        fd, tmp = tempfile.mkstemp(prefix=".ambr.", dir=os.path.dirname(path) or ".")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", errors="surrogateescape", newline="") as f:
                f.write(new_text)
            shutil.copymode(path, tmp)
            os.replace(tmp, path)
            if args.preserve_time:
                os.utime(path, (st.st_atime, st.st_mtime))
        finally:
            try:
                os.unlink(tmp)
            except OSError:
                pass
        return len(matches), True
    return len(matches), False


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.help:
        print(HELP, end="")
        return 0
    if args.version:
        print(VERSION)
        return 0
    if args.keyword is None or args.replacement is None:
        missing = []
        if args.keyword is None:
            missing.append("    <KEYWORD>")
        if args.replacement is None:
            missing.append("    <REPLACEMENT>")
        print("error: The following required arguments were not provided:", file=sys.stderr)
        print("\n".join(missing), file=sys.stderr)
        print("", file=sys.stderr)
        print("USAGE:", file=sys.stderr)
        print("    executable <KEYWORD> <REPLACEMENT> --bin-check-bytes <BYTES> --max-threads <NUM> --mmap-bytes <BYTES> --size-per-thread <BYTES>", file=sys.stderr)
        print("", file=sys.stderr)
        print("For more information try --help", file=sys.stderr)
        return 1

    if args.key_from_file:
        args.keyword = load_arg_from_file(args.keyword)
    if args.rep_from_file:
        args.replacement = load_arg_from_file(args.replacement)

    try:
        bin_check = int(args.bin_check_bytes)
    except ValueError:
        bin_check = 256

    if args.regex:
        try:
            regex_text = re.sub(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>", r"(?P<\1>", args.keyword)
            pattern = re.compile(regex_text)
        except re.error as e:
            print(f"regex parse error: {e}", file=sys.stderr)
            return 1
        replacement = rust_replacement_to_python(args.replacement)
    else:
        pattern = None
        replacement = args.replacement

    files = iter_files(args.paths, args)
    total_matches = 0
    changed_files = 0
    searched_files = 0
    for path in files:
        try:
            mode = os.stat(path).st_mode
            if not stat.S_ISREG(mode):
                continue
        except OSError:
            continue
        if not args.binary and is_binary(path, bin_check):
            if args.skipped:
                print(f"{path}: skipped binary file")
            continue
        searched_files += 1
        try:
            count, changed = replace_file(path, args, pattern, replacement)
        except KeyboardInterrupt:
            break
        total_matches += count
        changed_files += int(changed)

    if args.statistics:
        print(f"{searched_files} files searched")
        print(f"{changed_files} files changed")
        print(f"{total_matches} matches")
    return 0 if total_matches else 1


if __name__ == "__main__":
    raise SystemExit(main())
