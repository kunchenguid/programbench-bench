#!/usr/bin/env python3
import math, os, sys, re, subprocess

VERSION = "LuaJIT 2.1.1772570160"
HELP = """usage: ./executable [options]... [script [args]...].
Available options are:
  -e chunk  Execute string 'chunk'.
  -l name   Require library 'name'.
  -b ...    Save or list bytecode.
  -j cmd    Perform LuaJIT control command.
  -O[opt]   Control LuaJIT optimizations.
  -i        Enter interactive mode after executing 'script'.
  -v        Show version information.
  -E        Ignore environment variables.
  --        Stop handling options.
  -         Execute stdin and stop handling options."""

class LuaError(Exception): pass
class ReturnEx(Exception):
    def __init__(self, vals): self.vals = vals
class BreakEx(Exception): pass

class NilType:
    def __bool__(self): return False
    def __repr__(self): return "nil"
NIL = NilType()

def truthy(v): return not (v is NIL or v is False)
def lua_str(v):
    if v is NIL: return "nil"
    if v is True: return "true"
    if v is False: return "false"
    if isinstance(v, float):
        if math.isfinite(v) and v.is_integer(): return str(int(v))
        return ("%g" % v)
    if isinstance(v, LuaTable): return "table: 0x%x" % id(v)
    if isinstance(v, LuaFunction): return "function: 0x%x" % id(v)
    if callable(v): return "function: 0x%x" % id(v)
    return str(v)
def to_num(v):
    if isinstance(v, (int,float)) and not isinstance(v,bool): return v
    if isinstance(v, str):
        try:
            if re.match(r"^[+-]?\d+$", v): return int(v)
            return float(v)
        except Exception: pass
    raise LuaError("attempt to perform arithmetic on a non-number value")

class LuaTable:
    def __init__(self, init=None):
        self.d = {}
        self.n = 0
        if init:
            for v in init: self.append(v)
    def append(self, v):
        self.n += 1; self.d[self.n] = v
    def get(self, k):
        return self.d.get(k, NIL)
    def set(self, k, v):
        if v is NIL: self.d.pop(k, None)
        else: self.d[k] = v
        if isinstance(k, int) and k > self.n: self.n = k
    def length(self):
        i = 0
        while self.d.get(i+1, NIL) is not NIL: i += 1
        return i
    def items(self): return list(self.d.items())

class Env:
    def __init__(self, parent=None):
        self.parent=parent; self.vars={}
    def define(self,k,v=NIL): self.vars[k]=v
    def get(self,k):
        if k in self.vars: return self.vars[k]
        if self.parent: return self.parent.get(k)
        return NIL
    def set(self,k,v):
        if k in self.vars: self.vars[k]=v
        elif self.parent: self.parent.set(k,v)
        else: self.vars[k]=v

TOK_RE = re.compile(r"""
    (?P<ws>[ \t\r\n]+)|(?P<com>--\[\[.*?\]\]|--[^\n]*)|
    (?P<num>0x[0-9a-fA-F]+|\d+\.\d*(?:[eE][+-]?\d+)?|\d+(?:[eE][+-]?\d+)?)|
    (?P<str>'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*")|
    (?P<dots>\.\.\.)|(?P<op>\.\.|==|~=|<=|>=|[+\-*/%^#=<>;:,.()\[\]{}])|
    (?P<id>[A-Za-z_][A-Za-z0-9_]*)
""", re.S|re.X)
KEY=set("and break do else elseif end false for function if in local nil not or repeat return then true until while".split())

def lex(s):
    out=[]; pos=0
    while pos < len(s):
        m=TOK_RE.match(s,pos)
        if not m: raise LuaError("syntax error near '%s'" % s[pos:pos+10])
        pos=m.end(); typ=m.lastgroup; val=m.group(typ)
        if typ in ("ws","com"): continue
        if typ=="op": typ=val
        if typ=="id" and val in KEY: typ=val
        out.append((typ,val))
    out.append(("EOF","EOF")); return out

class Parser:
    def __init__(self,s): self.t=lex(s); self.i=0
    def peek(self): return self.t[self.i][0]
    def val(self): return self.t[self.i][1]
    def eat(self,k=None):
        if k is not None and self.peek()!=k: raise LuaError("syntax error near '%s'" % self.val())
        x=self.t[self.i]; self.i+=1; return x
    def block(self, stops=("EOF",)):
        a=[]
        while self.peek() not in stops:
            if self.peek()==";": self.eat(";"); continue
            a.append(self.stat())
        return ("block",a)
    def stat(self):
        p=self.peek()
        if p=="local":
            self.eat(); 
            if self.peek()=="function":
                self.eat(); name=self.eat("id")[1]; body=self.funcbody(); return ("local", [name], [("func",body)])
            names=[self.eat("id")[1]]
            while self.peek()==",": self.eat(","); names.append(self.eat("id")[1])
            ex=[]
            if self.peek()=="=": self.eat("="); ex=self.explist()
            return ("local",names,ex)
        if p=="function":
            self.eat(); target=self.prefix_name(); body=self.funcbody(); return ("assign",[target],[("func",body)])
        if p=="if":
            self.eat(); branches=[]
            branches.append((self.expr(), self._then_block()))
            while self.peek()=="elseif":
                self.eat(); branches.append((self.expr(), self._then_block()))
            els=None
            if self.peek()=="else": self.eat(); els=self.block(("end",))
            self.eat("end"); return ("if",branches,els)
        if p=="while":
            self.eat(); cond=self.expr(); self.eat("do"); b=self.block(("end",)); self.eat("end"); return ("while",cond,b)
        if p=="repeat":
            self.eat(); b=self.block(("until",)); self.eat("until"); cond=self.expr(); return ("repeat",b,cond)
        if p=="for":
            self.eat(); name=self.eat("id")[1]
            if self.peek()=="=":
                self.eat("="); start=self.expr(); self.eat(","); stop=self.expr(); step=("num",1)
                if self.peek()==",": self.eat(","); step=self.expr()
                self.eat("do"); b=self.block(("end",)); self.eat("end"); return ("fornum",name,start,stop,step,b)
            names=[name]
            while self.peek()==",": self.eat(","); names.append(self.eat("id")[1])
            self.eat("in"); ex=self.explist(); self.eat("do"); b=self.block(("end",)); self.eat("end")
            return ("forin",names,ex,b)
        if p=="return":
            self.eat(); ex=[] if self.peek() in ("end","EOF","else","elseif","until") else self.explist(); return ("return",ex)
        if p=="break": self.eat(); return ("break",)
        lhs=[self.prefix()]
        if self.peek() in ("=",","):
            while self.peek()==",": self.eat(","); lhs.append(self.prefix())
            self.eat("="); return ("assign",lhs,self.explist())
        return ("callstmt",lhs[0])
    def _then_block(self):
        self.eat("then"); return self.block(("elseif","else","end"))
    def prefix_name(self):
        node=("var",self.eat("id")[1])
        while self.peek() in (".",":"):
            sep=self.eat()[0]; nm=self.eat("id")[1]; node=("index",node,("str",nm))
        return node
    def funcbody(self):
        self.eat("("); params=[]; vararg=False
        if self.peek()!=")":
            while True:
                if self.peek()=="dots": self.eat(); vararg=True; break
                params.append(self.eat("id")[1])
                if self.peek()!=",": break
                self.eat(",")
        self.eat(")"); b=self.block(("end",)); self.eat("end"); return (params,vararg,b)
    def explist(self):
        a=[self.expr()]
        while self.peek()==",": self.eat(","); a.append(self.expr())
        return a
    BP={"or":1,"and":2,"==":3,"~=":3,"<":3,">":3,"<=":3,">=":3,"..":4,"+":5,"-":5,"*":6,"/":6,"%":6,"^":8}
    def expr(self, rbp=0):
        tok,val=self.eat(); left=self.nud(tok,val)
        while self.peek() in self.BP and self.BP[self.peek()]>rbp:
            op=self.eat()[0]; bp=self.BP[op]; right=self.expr(bp-1 if op in ("^","..") else bp)
            left=("bin",op,left,right)
        return left
    def nud(self,t,v):
        if t=="num": return ("num", int(v,16) if v.startswith(("0x","0X")) else (float(v) if any(c in v for c in ".eE") else int(v)))
        if t=="str": return ("str", bytes(v[1:-1],"utf-8").decode("unicode_escape"))
        if t=="nil": return ("nil",)
        if t=="true": return ("bool",True)
        if t=="false": return ("bool",False)
        if t in ("-","not","#"): return ("un",t,self.expr(7))
        if t=="function": return ("func",self.funcbody())
        if t=="{": return self.table()
        if t=="(": 
            e=self.expr(); self.eat(")"); return self.suffix(e)
        if t=="id": return self.suffix(("var",v))
        raise LuaError("syntax error near '%s'" % v)
    def table(self):
        fields=[]; idx=1
        while self.peek()!="}":
            if self.peek()=="[":
                self.eat("["); k=self.expr(); self.eat("]"); self.eat("="); v=self.expr(); fields.append((k,v))
            elif self.peek()=="id" and self.t[self.i+1][0]=="=":
                k=("str",self.eat("id")[1]); self.eat("="); fields.append((k,self.expr()))
            else:
                fields.append((("num",idx), self.expr())); idx+=1
            if self.peek() in (",",";"): self.eat()
            else: break
        self.eat("}"); return ("table",fields)
    def prefix(self):
        if self.peek()=="id": return self.suffix(("var",self.eat()[1]))
        self.eat("("); e=self.expr(); self.eat(")"); return self.suffix(e)
    def suffix(self,node):
        while self.peek() in (".","[","(","{","str",":"):
            if self.peek()==".": self.eat(); node=("index",node,("str",self.eat("id")[1]))
            elif self.peek()=="[": self.eat(); k=self.expr(); self.eat("]"); node=("index",node,k)
            elif self.peek()==":":
                self.eat(); name=self.eat("id")[1]; args=self.args(); node=("call",("index",node,("str",name)),[node]+args)
            else:
                args=self.args(); node=("call",node,args)
        return node
    def args(self):
        if self.peek()=="(":
            self.eat("("); a=[] if self.peek()==")" else self.explist(); self.eat(")"); return a
        if self.peek()=="{": return [self.nud(*self.eat())]
        if self.peek()=="str": return [("str",self.eat()[1][1:-1])]
        raise LuaError("function arguments expected")

class LuaFunction:
    def __init__(self, body, env): self.params,self.vararg,self.block=body; self.env=env
    def __call__(self,*args):
        e=Env(self.env)
        for i,p in enumerate(self.params): e.define(p, args[i] if i<len(args) else NIL)
        try: exec_block(self.block,e)
        except ReturnEx as r: return r.vals[0] if len(r.vals)==1 else (r.vals or [NIL])
        return NIL

def eval_expr(n,e):
    k=n[0]
    if k=="num" or k=="str" or k=="bool": return n[1]
    if k=="nil": return NIL
    if k=="var": return e.get(n[1])
    if k=="index":
        obj=eval_expr(n[1],e); key=eval_expr(n[2],e)
        if isinstance(obj,LuaTable): return obj.get(key)
        if isinstance(obj,dict): return obj.get(key,NIL)
        return NIL
    if k=="table":
        t=LuaTable()
        for kk,vv in n[1]: t.set(eval_expr(kk,e), eval_expr(vv,e))
        return t
    if k=="func": return LuaFunction(n[1],e)
    if k=="un":
        op=n[1]; v=eval_expr(n[2],e)
        if op=="-": return -to_num(v)
        if op=="not": return not truthy(v)
        if op=="#": return len(v) if isinstance(v,str) else (v.length() if isinstance(v,LuaTable) else 0)
    if k=="bin":
        op=n[1]
        if op=="and":
            a=eval_expr(n[2],e); return eval_expr(n[3],e) if truthy(a) else a
        if op=="or":
            a=eval_expr(n[2],e); return a if truthy(a) else eval_expr(n[3],e)
        a=eval_expr(n[2],e); b=eval_expr(n[3],e)
        if op=="+": return to_num(a)+to_num(b)
        if op=="-": return to_num(a)-to_num(b)
        if op=="*": return to_num(a)*to_num(b)
        if op=="/": return to_num(a)/to_num(b)
        if op=="%": return to_num(a)%to_num(b)
        if op=="^": return to_num(a)**to_num(b)
        if op=="..": return lua_str(a)+lua_str(b)
        if op=="==": return a is b or a==b
        if op=="~=": return not (a is b or a==b)
        if op=="<": return a<b
        if op==">": return a>b
        if op=="<=": return a<=b
        if op==">=": return a>=b
    if k=="call":
        fn=eval_expr(n[1],e); args=[eval_expr(x,e) for x in n[2]]
        if callable(fn): return fn(*args)
        raise LuaError("attempt to call a non-function value")
    raise LuaError("internal error")

def assign(lhs, vals, e):
    vs=[eval_expr(x,e) for x in vals]
    for i,l in enumerate(lhs):
        v=vs[i] if i<len(vs) else NIL
        if l[0]=="var": e.set(l[1],v)
        elif l[0]=="index":
            obj=eval_expr(l[1],e); key=eval_expr(l[2],e)
            if isinstance(obj,LuaTable): obj.set(key,v)
            elif isinstance(obj,dict): obj[key]=v

def exec_block(b,e):
    for s in b[1]:
        k=s[0]
        if k=="local":
            vals=[eval_expr(x,e) for x in s[2]]
            for i,nm in enumerate(s[1]): e.define(nm, vals[i] if i<len(vals) else NIL)
        elif k=="assign": assign(s[1],s[2],e)
        elif k=="callstmt": eval_expr(s[1],e)
        elif k=="return": raise ReturnEx([eval_expr(x,e) for x in s[1]])
        elif k=="break": raise BreakEx()
        elif k=="if":
            done=False
            for cond,blk in s[1]:
                if truthy(eval_expr(cond,e)): exec_block(blk,Env(e)); done=True; break
            if not done and s[2]: exec_block(s[2],Env(e))
        elif k=="while":
            try:
                while truthy(eval_expr(s[1],e)): exec_block(s[2],Env(e))
            except BreakEx: pass
        elif k=="repeat":
            try:
                while True:
                    exec_block(s[1],Env(e))
                    if truthy(eval_expr(s[2],e)): break
            except BreakEx: pass
        elif k=="fornum":
            start=int(to_num(eval_expr(s[2],e))); stop=int(to_num(eval_expr(s[3],e))); step=int(to_num(eval_expr(s[4],e)))
            i=start
            try:
                while (i<=stop if step>=0 else i>=stop):
                    le=Env(e); le.define(s[1],i); exec_block(s[5],le); i+=step
            except BreakEx: pass
        elif k=="forin":
            iterable=eval_expr(s[2][0],e)
            if callable(iterable): iterable=iterable()
            try:
                for row in iterable:
                    if not isinstance(row, tuple): row=(row,)
                    le=Env(e)
                    for i,nm in enumerate(s[1]): le.define(nm,row[i] if i<len(row) else NIL)
                    exec_block(s[3],le)
            except BreakEx: pass

def base_env(argv):
    e=Env()
    def l_print(*args): sys.stdout.write("\t".join(lua_str(a) for a in args)+"\n")
    def l_write(*args): sys.stdout.write("".join(lua_str(a) for a in args)); sys.stdout.flush()
    def l_type(x=NIL):
        if x is NIL: return "nil"
        if isinstance(x,bool): return "boolean"
        if isinstance(x,(int,float)) and not isinstance(x,bool): return "number"
        if isinstance(x,str): return "string"
        if isinstance(x,LuaTable): return "table"
        if callable(x): return "function"
        return "userdata"
    def pairs(t):
        if isinstance(t,LuaTable): return iter(t.items())
        if isinstance(t,dict): return iter(t.items())
        return iter(())
    def ipairs(t):
        def gen():
            i=1
            while isinstance(t,LuaTable) and t.get(i) is not NIL:
                yield (i,t.get(i)); i+=1
        return gen()
    def require(name): return e.get(name)
    def l_select(which,*args):
        if which == "#": return len(args)
        return args[int(which)-1] if 0 < int(which) <= len(args) else NIL
    def l_pcall(fn,*args):
        try: return (True, fn(*args))
        except Exception as ex: return (False, str(ex))
    def m_random(*a):
        import random
        if not a: return random.random()
        if len(a)==1: return random.randint(1,int(a[0]))
        return random.randint(int(a[0]),int(a[1]))
    def t_insert(t,*a):
        if not isinstance(t,LuaTable): return NIL
        if len(a)==1: t.append(a[0])
        elif len(a)>=2:
            pos=int(a[0]); val=a[1]
            for i in range(t.length()+1,pos,-1): t.set(i,t.get(i-1))
            t.set(pos,val)
        return NIL
    mathlib={k:getattr(math,k) for k in dir(math) if not k.startswith("_")}
    mathlib.update({"random":m_random, "randomseed":lambda s: __import__("random").seed(s), "floor":math.floor, "ceil":math.ceil, "abs":abs, "max":max, "min":min})
    stringlib={"len":len, "upper":lambda s: str(s).upper(), "lower":lambda s: str(s).lower(), "sub":lambda s,i,j=None: str(s)[int(i)-1:(None if j is None or j is NIL else int(j))],
               "format":lambda fmt,*a: fmt % tuple(a), "rep":lambda s,n: str(s)*int(n),
               "find":lambda s,p: (str(s).find(str(p))+1 or NIL), "gsub":lambda s,p,r: re.sub(str(p),str(r),str(s))}
    tablelib={"insert":t_insert, "concat":lambda t,sep="": str(sep).join(lua_str(t.get(i)) for i in range(1,t.length()+1))}
    iolib={"write":l_write, "read":lambda *a: sys.stdin.readline().rstrip("\n")}
    oslib={"exit":lambda code=0: sys.exit(int(code)), "getenv":lambda n: os.environ.get(str(n),NIL)}
    argt=LuaTable()
    for i,a in enumerate(argv): argt.set(i,a)
    for k,v in {"_VERSION":"Lua 5.1","jit":LuaTable(),"print":l_print,"io":iolib,"type":l_type,"tostring":lua_str,
                "tonumber":lambda x,base=10: int(str(x),int(base)) if base is not NIL and int(base)!=10 else to_num(x),
                "assert":lambda x,*m: x if truthy(x) else (_ for _ in ()).throw(LuaError(lua_str(m[0]) if m else "assertion failed!")),
                "error":lambda msg="": (_ for _ in ()).throw(LuaError(lua_str(msg))), "select":l_select, "pcall":l_pcall,
                "pairs":pairs,"ipairs":ipairs,"require":require,"math":mathlib,"string":stringlib,"table":tablelib,"os":oslib,"arg":argt}.items(): e.define(k,v)
    e.get("jit").set("version",VERSION); e.get("jit").set("version_num",20199); e.get("jit").set("os","Linux"); e.get("jit").set("arch","x64")
    return e

def run_code(code, env, name="(command line)"):
    try:
        exec_block(Parser(code).block(), env); return 0
    except LuaError as ex:
        print(f"./executable: {name}: {ex}", file=sys.stderr); return 1

def main(argv):
    chunks=[]; libs=[]; showv=False; stop=False; script=None; sargs=[]; i=0
    if len(argv)>1 and argv[1]=="--help": print(HELP); return 1
    while i < len(argv)-1 and not stop:
        a=argv[i+1]
        if a=="--": stop=True; i+=1; break
        if a=="-": script="-"; i+=1; break
        if not a.startswith("-") or a=="-": break
        if a=="-v": showv=True; i+=1; continue
        if a=="-E" or a.startswith("-O"): i+=1; continue
        if a.startswith("-j"):
            i+=1; continue
        if a=="-b" or a.startswith("-b"): print("./executable: unknown luaJIT command or jit.* modules not installed", file=sys.stderr); return 1
        if a=="-i": i+=1; continue
        if a=="-e":
            i+=1; 
            if i>=len(argv)-1: print("./executable: '-e' needs argument", file=sys.stderr); return 1
            chunks.append(argv[i+1]); i+=1; continue
        if a.startswith("-e") and len(a)>2: chunks.append(a[2:]); i+=1; continue
        if a=="-l":
            i+=1
            if i>=len(argv)-1: print("./executable: '-l' needs argument", file=sys.stderr); return 1
            libs.append(argv[i+1]); i+=1; continue
        if a.startswith("-l") and len(a)>2: libs.append(a[2:]); i+=1; continue
        print(f"./executable: unrecognized option '{a}'", file=sys.stderr); print(HELP, file=sys.stderr); return 1
    if showv: print(f"{VERSION} -- Copyright (C) 2005-2026 Mike Pall. https://luajit.org/")
    rest=argv[i+1:]
    if rest:
        script=rest[0]; sargs=rest[1:]
    env=base_env([script or "./executable"]+sargs)
    rc=0
    for lib in libs: env.get("require")(lib)
    for c in chunks:
        rc=run_code(c, env)
        if rc: return rc
    if script:
        if script=="-": code=sys.stdin.read()
        else:
            try: code=open(script).read()
            except OSError as ex: print(f"./executable: cannot open {script}: {ex.strerror}", file=sys.stderr); return 1
        rc=run_code(code, env, script)
    elif not chunks and not showv:
        for line in sys.stdin:
            if line.strip(): rc=run_code(line, env)
    return rc
if __name__=="__main__": sys.exit(main(sys.argv))
