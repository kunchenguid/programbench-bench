#!/usr/bin/env python3
import os
import select
import sys
import termios
import tty

VERSION = "0.4.3"

HELP = """./executable: A tiny UTF-8 terminal text editor

Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.
Specify file paths to edit as a command argument or run without argument to
start to write a new text.
Help can show up with key mapping Ctrl-?.

Usage:
    ./executable [options] [FILES...]

Mappings:
    Ctrl-Q                        : Quit
    Ctrl-S                        : Save to file
    Ctrl-O                        : Open text buffer
    Ctrl-X                        : Next text buffer
    Alt-X                         : Previous text buffer
    Ctrl-P or UP                  : Move cursor up
    Ctrl-N or DOWN                : Move cursor down
    Ctrl-F or RIGHT               : Move cursor right
    Ctrl-B or LEFT                : Move cursor left
    Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line
    Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line
    Ctrl-[ or Ctrl-V or PAGE DOWN : Next page
    Ctrl-] or Alt-V or PAGE UP    : Previous page
    Alt-F or Ctrl-RIGHT           : Move cursor to next word
    Alt-B or Ctrl-LEFT            : Move cursor to previous word
    Alt-N or Ctrl-DOWN            : Move cursor to next paragraph
    Alt-P or Ctrl-UP              : Move cursor to previous paragraph
    Alt-<                         : Move cursor to top of file
    Alt->                         : Move cursor to bottom of file
    Ctrl-H or BACKSPACE           : Delete character
    Ctrl-D or DELETE              : Delete next character
    Ctrl-W                        : Delete a word
    Ctrl-J                        : Delete until head of line
    Ctrl-K                        : Delete until end of line
    Ctrl-U                        : Undo last change
    Ctrl-R                        : Redo last undo change
    Ctrl-G                        : Search text
    Ctrl-M                        : New line
    Ctrl-L                        : Refresh screen
    Ctrl-?                        : Show this help

Options:
    -v, --version       Print version
    -h, --help          Print this help
"""


def parse_args(argv):
    files = []
    seen_v = False
    seen_h = False
    end = False
    for arg in argv:
        if end:
            files.append(arg)
            continue
        if arg == "--":
            end = True
            continue
        if arg == "--version":
            if seen_v:
                die("Option 'version' given more than once. Please see --help for more details")
            seen_v = True
            continue
        if arg.startswith("--version="):
            die("Option 'version' does not take an argument. Please see --help for more details")
        if arg == "--help":
            if seen_h:
                die("Option 'help' given more than once. Please see --help for more details")
            seen_h = True
            continue
        if arg.startswith("--help="):
            die("Option 'help' does not take an argument. Please see --help for more details")
        if arg.startswith("--") and len(arg) > 2:
            die(f"Unrecognized option: '{arg[2:]}'. Please see --help for more details")
        if arg.startswith("-") and len(arg) > 1:
            for ch in arg[1:]:
                if ch == "v":
                    if seen_v:
                        die("Option 'version' given more than once. Please see --help for more details")
                    seen_v = True
                elif ch == "h":
                    if seen_h:
                        die("Option 'help' given more than once. Please see --help for more details")
                    seen_h = True
                else:
                    die(f"Unrecognized option: '{ch}'. Please see --help for more details")
            continue
        files.append(arg)
    return seen_h, seen_v, files


def die(msg):
    print("Error: " + msg, file=sys.stderr)
    sys.exit(1)


class Buffer:
    def __init__(self, name=None):
        self.name = name
        self.lines = [""]
        self.cx = 0
        self.cy = 0
        self.rowoff = 0
        self.dirty = False
        self.message = "Ctrl-? for help"
        if name is not None and os.path.exists(name):
            try:
                data = open(name, "r", encoding="utf-8", errors="replace").read()
            except OSError as e:
                self.message = f"Error: {e}"
                return
            self.lines = data.splitlines()
            if data.endswith("\n"):
                pass
            if not self.lines:
                self.lines = [""]

    @property
    def display_name(self):
        return self.name if self.name else "[No Name]"

    def insert(self, text):
        line = self.lines[self.cy]
        self.lines[self.cy] = line[:self.cx] + text + line[self.cx:]
        self.cx += len(text)
        self.dirty = True

    def newline(self):
        line = self.lines[self.cy]
        self.lines[self.cy] = line[:self.cx]
        self.lines.insert(self.cy + 1, line[self.cx:])
        self.cy += 1
        self.cx = 0
        self.dirty = True

    def backspace(self):
        if self.cx == 0 and self.cy == 0:
            return
        if self.cx > 0:
            line = self.lines[self.cy]
            self.lines[self.cy] = line[:self.cx - 1] + line[self.cx:]
            self.cx -= 1
        else:
            prev_len = len(self.lines[self.cy - 1])
            self.lines[self.cy - 1] += self.lines.pop(self.cy)
            self.cy -= 1
            self.cx = prev_len
        self.dirty = True

    def delete(self):
        line = self.lines[self.cy]
        if self.cx < len(line):
            self.lines[self.cy] = line[:self.cx] + line[self.cx + 1:]
            self.dirty = True
        elif self.cy + 1 < len(self.lines):
            self.lines[self.cy] += self.lines.pop(self.cy + 1)
            self.dirty = True

    def save(self, name=None):
        if name:
            self.name = name
        if not self.name:
            return False
        data = "\n".join(self.lines) + "\n"
        with open(self.name, "w", encoding="utf-8") as f:
            f.write(data)
        self.dirty = False
        self.message = f"{len(data.encode('utf-8'))} bytes written to {self.name}"
        return True


class Editor:
    def __init__(self, files):
        self.rows, self.cols = self.get_window_size()
        self.screenrows = max(1, self.rows - 2)
        self.buffers = [Buffer(f) for f in files] or [Buffer()]
        self.current = 0
        self.quit_warnings = 0

    @property
    def buf(self):
        return self.buffers[self.current]

    def write(self, s):
        os.write(sys.stdout.fileno(), s.encode("utf-8", errors="replace"))

    def get_window_size(self):
        self.write("\x1b[9999C\x1b[9999B\x1b[6n")
        resp = b""
        while not resp.endswith(b"R"):
            r, _, _ = select.select([sys.stdin.fileno()], [], [], 5)
            if not r:
                return 24, 80
            ch = os.read(sys.stdin.fileno(), 1)
            if not ch:
                return 24, 80
            resp += ch
        try:
            body = resp.decode().split("[", 1)[1][:-1]
            row, col = body.split(";", 1)
            return max(1, int(row)), max(1, int(col))
        except Exception:
            return 24, 80

    def refresh(self):
        b = self.buf
        self.scroll()
        self.write("\x1b[?25l")
        for y in range(self.screenrows):
            filerow = y + b.rowoff
            self.write(f"\x1b[{y + 1}H")
            if filerow < len(b.lines):
                self.write("\x1b[39;0m" + b.lines[filerow][: self.cols])
            else:
                if not b.name and len(b.lines) == 1 and b.lines[0] == "" and y == self.screenrows // 3:
                    msg = f"Kiro editor -- version {VERSION}"
                    pad = max(0, (self.cols - len(msg)) // 2)
                    self.write("\x1b[37m~\x1b[39;0m" + " " * pad + msg[: self.cols - 1])
                else:
                    self.write("\x1b[37m~\x1b[39;0m")
            self.write("\x1b[K")
        self.status_bar()
        msg = b.message[: self.cols]
        self.write(f"\x1b[{self.rows}H{msg}\x1b[K")
        cy = b.cy - b.rowoff + 1
        cx = b.cx + 1
        self.write(f"\x1b[{max(1, cy)};{max(1, cx)}H\x1b[?25h")

    def status_bar(self):
        b = self.buf
        left = f'"{b.display_name}" - {self.current + 1}/{len(self.buffers)}'
        if b.dirty:
            left += " (modified)"
        right = f"plain {b.cy + 1}/{len(b.lines)}"
        width = self.cols
        if len(left) + len(right) < width:
            bar = left + " " * (width - len(left) - len(right)) + right
        else:
            bar = (left + " " + right)[:width]
        self.write(f"\x1b[{self.rows - 1}H\x1b[7m{bar}\x1b[39;0m")

    def scroll(self):
        b = self.buf
        if b.cy < b.rowoff:
            b.rowoff = b.cy
        if b.cy >= b.rowoff + self.screenrows:
            b.rowoff = b.cy - self.screenrows + 1

    def read_key(self):
        c = os.read(sys.stdin.fileno(), 1)
        if c == b"\x1b":
            r, _, _ = select.select([sys.stdin.fileno()], [], [], 0.03)
            if not r:
                return "ESC"
            seq = c + os.read(sys.stdin.fileno(), 1)
            while len(seq) < 8 and select.select([sys.stdin.fileno()], [], [], 0.005)[0]:
                seq += os.read(sys.stdin.fileno(), 1)
            return seq
        if c and c[0] >= 0xC0:
            need = 1
            if c[0] >= 0xF0:
                need = 3
            elif c[0] >= 0xE0:
                need = 2
            for _ in range(need):
                r, _, _ = select.select([sys.stdin.fileno()], [], [], 0.02)
                if not r:
                    break
                c += os.read(sys.stdin.fileno(), 1)
        return c

    def move(self, key):
        b = self.buf
        if key in (b"\x10", b"\x1b[A"):
            b.cy = max(0, b.cy - 1)
        elif key in (b"\x0e", b"\x1b[B"):
            b.cy = min(len(b.lines) - 1, b.cy + 1)
        elif key in (b"\x02", b"\x1b[D"):
            if b.cx > 0:
                b.cx -= 1
            elif b.cy > 0:
                b.cy -= 1
                b.cx = len(b.lines[b.cy])
        elif key in (b"\x06", b"\x1b[C"):
            if b.cx < len(b.lines[b.cy]):
                b.cx += 1
            elif b.cy + 1 < len(b.lines):
                b.cy += 1
                b.cx = 0
        elif key == b"\x01":
            b.cx = 0
        elif key == b"\x05":
            b.cx = len(b.lines[b.cy])
        b.cx = min(b.cx, len(b.lines[b.cy]))

    def prompt(self, prefix):
        text = ""
        while True:
            self.buf.message = f"{prefix}{text} (^G or ESC to cancel)"
            self.refresh()
            k = self.read_key()
            if k in (b"\r", b"\n", b"\x0d"):
                self.buf.message = ""
                return text
            if k in (b"\x07", "ESC"):
                self.buf.message = "Ctrl-? for help"
                return None
            if k in (b"\x7f", b"\x08"):
                text = text[:-1]
            elif isinstance(k, bytes):
                try:
                    s = k.decode("utf-8")
                except UnicodeDecodeError:
                    continue
                if s.isprintable():
                    text += s

    def show_help(self):
        old = self.buf.message
        lines = HELP.splitlines()
        for i, line in enumerate(lines[: self.screenrows]):
            self.write(f"\x1b[{i + 1}H{line[:self.cols]}\x1b[K")
        self.write(f"\x1b[{self.rows}HPress any key to continue\x1b[K")
        self.read_key()
        self.buf.message = old

    def process(self, k):
        b = self.buf
        if k == b"\x11":
            if any(x.dirty for x in self.buffers) and self.quit_warnings < 1:
                self.quit_warnings += 1
                b.message = "At least one file has unsaved changes! Press Ctrl-Q again to quit"
                return True
            return False
        self.quit_warnings = 0
        if k == b"\x13":
            if b.name:
                try:
                    b.save()
                except OSError as e:
                    b.message = f"Error: {e}"
            else:
                name = self.prompt("Save as: ")
                if name:
                    try:
                        b.save(name)
                    except OSError as e:
                        b.message = f"Error: {e}"
            return True
        if k == b"\x0f":
            name = self.prompt("Open: ")
            if name:
                self.buffers.append(Buffer(name))
                self.current = len(self.buffers) - 1
            return True
        if k == b"\x18":
            self.current = (self.current + 1) % len(self.buffers)
            return True
        if k == b"\x1bx":
            self.current = (self.current - 1) % len(self.buffers)
            return True
        if k in (b"\x10", b"\x0e", b"\x02", b"\x06", b"\x01", b"\x05", b"\x1b[A", b"\x1b[B", b"\x1b[C", b"\x1b[D"):
            self.move(k)
        elif k in (b"\x08", b"\x7f"):
            b.backspace()
        elif k in (b"\x04", b"\x1b[3"):
            b.delete()
        elif k in (b"\r", b"\n", b"\x0d"):
            b.newline()
        elif k == b"\x0b":
            b.lines[b.cy] = b.lines[b.cy][: b.cx]
            b.dirty = True
        elif k == b"\x0a":
            b.lines[b.cy] = b.lines[b.cy][b.cx :]
            b.cx = 0
            b.dirty = True
        elif k == b"\x1f":
            self.show_help()
        elif isinstance(k, bytes):
            try:
                s = k.decode("utf-8")
            except UnicodeDecodeError:
                return True
            if s.isprintable():
                b.insert(s)
        return True

    def run(self):
        self.write("\x1b[?1049h")
        try:
            self.refresh()
            while True:
                k = self.read_key()
                if not self.process(k):
                    break
                self.refresh()
        finally:
            self.write("\x1b[?1049l\x1b[H")


def main():
    show_help, show_version, files = parse_args(sys.argv[1:])
    if show_version:
        print(VERSION)
        return 0
    if show_help:
        sys.stdout.write(HELP)
        return 0
    if not os.isatty(sys.stdin.fileno()) or not os.isatty(sys.stdout.fileno()):
        print("Error: Inappropriate ioctl for device (os error 25)", file=sys.stderr)
        return 1
    old = termios.tcgetattr(sys.stdin.fileno())
    try:
        tty.setraw(sys.stdin.fileno())
        Editor(files).run()
    finally:
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSAFLUSH, old)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
