#!/usr/bin/env python3
import argparse
import io
import lzma
import os
import shutil
import stat
import sys
import zlib

VERSION = "xz (XZ Utils) 5.8.2\nliblzma 5.8.2"

SHORT_HELP = """Usage: {prog} [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files
  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -h, --help          display this short help and exit
  -H, --long-help     display the long help (lists also the advanced options)
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>"""

LONG_HELP = """Usage: {prog} [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

 Operation mode:

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files

 Operation modifiers:

  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
      --no-sync       don't synchronize the output file to the storage device
                      before removing the input file
      --single-stream decompress only the first stream, and silently ignore
                      possible remaining input data
      --no-sparse     do not create sparse files when decompressing
  -S, --suffix=.SUF   use the suffix '.SUF' on compressed files
      --files[=FILE]  read filenames to process from FILE; if FILE is omitted,
                      filenames are read from the standard input; filenames
                      must be terminated with the newline character
      --files0[=FILE] like --files but use the null character as terminator

 Basic file format and compression options:

  -F, --format=FORMAT file format to encode or decode; possible values are
                      'auto' (default), 'xz', 'lzma', 'lzip', and 'raw'
  -C, --check=NAME    integrity check type: 'none' (use with caution), 'crc32',
                      'crc64' (default), or 'sha256'
      --ignore-check  don't verify the integrity check when decompressing
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
      --block-size=SIZE
                      start a new .xz block after every SIZE bytes of input;
                      use this to set the block size for threaded compression
      --block-list=BLOCKS
                      start a new .xz block after the given comma-separated
                      intervals of uncompressed data; optionally, specify a
                      filter chain number (0-9) followed by a ':' before the
                      uncompressed data size
      --flush-timeout=NUM
                      when compressing, if more than NUM milliseconds has
                      passed since the previous flush and reading more input
                      would block, all pending data is flushed out
      --memlimit-compress=LIMIT
      --memlimit-decompress=LIMIT
      --memlimit-mt-decompress=LIMIT
  -M, --memlimit=LIMIT
                      set memory usage limit for compression, decompression,
                      threaded decompression, or all of these; LIMIT is in
                      bytes, % of RAM, or 0 for defaults
      --no-adjust     if compression settings exceed the memory usage limit,
                      give an error instead of adjusting the settings downwards

 Other options:

  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -Q, --no-warn       make warnings not affect the exit status
      --robot         use machine-parsable messages (useful for scripts)

      --info-memory   display the total amount of RAM and the currently active
                      memory usage limits, and exit
  -h, --help          display the short help (lists only the basic options)
  -H, --long-help     display this long help and exit
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>"""


class XZError(Exception):
    def __init__(self, message, partial=b""):
        super().__init__(message)
        self.partial = partial


class Parser(argparse.ArgumentParser):
    def error(self, message):
        if message.startswith("unrecognized arguments: "):
            arg = message.split(": ", 1)[1].split()[0]
            if arg.startswith("--"):
                eprint(f"{progname()}: unrecognized option '{arg}'")
            elif arg.startswith("-") and len(arg) > 1:
                eprint(f"{progname()}: invalid option -- '{arg[1]}'")
            else:
                eprint(f"{progname()}: {message}")
        elif "expected one argument" in message:
            opt = message.split(":", 1)[0]
            if opt.startswith("argument "):
                opt = opt.split()[1].split("/", 1)[0]
            if opt.startswith("-") and len(opt) == 2:
                eprint(f"{progname()}: option requires an argument -- '{opt[1]}'")
            else:
                eprint(f"{progname()}: {opt}: option requires an argument")
        else:
            eprint(f"{progname()}: {message}")
        eprint(f"{progname()}: Try '{progname()} --help' for more information.")
        raise SystemExit(1)


def eprint(msg, quiet=0):
    if quiet < 2:
        print(msg, file=sys.stderr)


def progname():
    return sys.argv[0] or "xz"


def parse(argv):
    p = Parser(add_help=False, allow_abbrev=False)
    p.add_argument("-z", "--compress", action="store_true")
    p.add_argument("-d", "--decompress", action="store_true")
    p.add_argument("-t", "--test", action="store_true")
    p.add_argument("-l", "--list", dest="list_", action="store_true")
    p.add_argument("-k", "--keep", action="store_true")
    p.add_argument("-f", "--force", action="store_true")
    p.add_argument("-c", "--stdout", action="store_true")
    p.add_argument("-e", "--extreme", action="store_true")
    p.add_argument("-q", "--quiet", action="count", default=0)
    p.add_argument("-v", "--verbose", action="count", default=0)
    p.add_argument("-Q", "--no-warn", action="store_true")
    p.add_argument("--robot", action="store_true")
    p.add_argument("--single-stream", action="store_true")
    p.add_argument("--no-sync", action="store_true")
    p.add_argument("--no-sparse", action="store_true")
    p.add_argument("--ignore-check", action="store_true")
    p.add_argument("--no-adjust", action="store_true")
    p.add_argument("--info-memory", action="store_true")
    p.add_argument("-T", "--threads")
    p.add_argument("-S", "--suffix", default=".xz")
    p.add_argument("-F", "--format", default="auto")
    p.add_argument("-C", "--check", default="crc64")
    p.add_argument("-M", "--memlimit")
    p.add_argument("--memlimit-compress")
    p.add_argument("--memlimit-decompress")
    p.add_argument("--memlimit-mt-decompress")
    p.add_argument("--block-size")
    p.add_argument("--block-list")
    p.add_argument("--flush-timeout")
    p.add_argument("--filters")
    p.add_argument("--filters-help", action="store_true")
    for i in range(1, 10):
        p.add_argument(f"--filters{i}")
    p.add_argument("--lzma1", nargs="?", const="")
    p.add_argument("--lzma2", nargs="?", const="")
    for name in ("x86", "arm", "armthumb", "arm64", "powerpc", "ia64", "sparc", "riscv", "delta"):
        p.add_argument("--" + name, nargs="?", const="")
    p.add_argument("--files", dest="files_from", nargs="?", const="-")
    p.add_argument("--files0", dest="files0_from", nargs="?", const="-")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-H", "--long-help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    for n in range(10):
        p.add_argument("-" + str(n), dest="preset", action="store_const", const=n)
    p.add_argument("files", nargs="*")
    try:
        ns = p.parse_args(argv)
    except SystemExit as exc:
        return None, exc.code
    if ns.format not in ("auto", "xz", "lzma", "alone", "lzip", "raw"):
        eprint(f"{progname()}: {ns.format}: Unknown file format type")
        return None, 1
    if ns.check not in ("none", "crc32", "crc64", "sha256"):
        eprint(f"{progname()}: {ns.check}: Unsupported integrity check type")
        return None, 1
    if ns.files_from is not None and ns.files0_from is not None:
        eprint(f"{progname()}: Only one of --files or --files0 can be specified")
        return None, 1
    return ns, 0


def add_files_from_option(ns):
    opt = ns.files_from if ns.files_from is not None else ns.files0_from
    if opt is None:
        return
    sep = b"\0" if ns.files0_from is not None else b"\n"
    data = sys.stdin.buffer.read() if opt == "-" else open(opt, "rb").read()
    names = [x.decode(errors="surrogateescape") for x in data.split(sep) if x]
    ns.files.extend(names)


def fmt_for(ns, input_name=None, compress=False):
    f = ns.format
    if f == "alone":
        f = "lzma"
    if f == "auto":
        if compress:
            return lzma.FORMAT_XZ
        if input_name and input_name.endswith(".lzma"):
            return lzma.FORMAT_ALONE
        return lzma.FORMAT_AUTO
    if f == "xz":
        return lzma.FORMAT_XZ
    if f == "lzma":
        return lzma.FORMAT_ALONE
    raise XZError(f"{f}: This file format is not supported")


def lzip_dict_size(code):
    if code < 12 or code > 29:
        return 1 << 23
    base = 1 << code
    return base - (base // 16) * ((code >> 5) & 7)


def decompress_lzip(data):
    out = []
    rest = data
    members = 0
    while rest:
        if len(rest) < 6 or not rest.startswith(b"LZIP"):
            raise XZError("File format not recognized", b"".join(out))
        if rest[4] != 1:
            raise XZError("Unsupported lzip version", b"".join(out))
        dict_size = lzip_dict_size(rest[5])
        payload = rest[6:]
        d = lzma.LZMADecompressor(
            format=lzma.FORMAT_RAW,
            filters=[{"id": lzma.FILTER_LZMA1, "dict_size": dict_size, "lc": 3, "lp": 0, "pb": 2}],
        )
        try:
            chunk = d.decompress(payload)
        except lzma.LZMAError:
            raise XZError("Unexpected end of input", b"".join(out))
        out.append(chunk)
        members += 1
        if not d.eof or len(d.unused_data) < 20:
            raise XZError("Unexpected end of input", b"".join(out))
        trailer = d.unused_data[:20]
        crc = int.from_bytes(trailer[:4], "little")
        usize = int.from_bytes(trailer[4:12], "little")
        msize = int.from_bytes(trailer[12:20], "little")
        if usize != len(chunk) or crc != (zlib.crc32(chunk) & 0xFFFFFFFF):
            raise XZError("Corrupt input data", b"".join(out))
        if msize <= 0 or msize > len(rest):
            raise XZError("Corrupt input data", b"".join(out))
        rest = rest[msize:]
    return b"".join(out), members


def check_id(name):
    return {"none": lzma.CHECK_NONE, "crc32": lzma.CHECK_CRC32,
            "crc64": lzma.CHECK_CRC64, "sha256": lzma.CHECK_SHA256}[name]


def default_output_name(name, ns, compress):
    if compress:
        suffix = ".lzma" if ns.format in ("lzma", "alone") and ns.suffix == ".xz" else ns.suffix
        if name.endswith(suffix):
            raise XZError(f"{name}: File already has '{suffix}' suffix, skipping")
        return name + suffix
    suffix = ns.suffix
    if suffix != ".xz" and name.endswith(suffix):
        return name[:-len(suffix)]
    if name.endswith(".txz"):
        return name[:-4] + ".tar"
    if name.endswith(".xz"):
        return name[:-3]
    if name.endswith(".lzma"):
        return name[:-5]
    raise XZError(f"{name}: Filename has an unknown suffix, skipping")


def read_input(name):
    if name == "-":
        return sys.stdin.buffer.read()
    with open(name, "rb") as f:
        return f.read()


def write_output(name, data, ns, src=None):
    if name == "-":
        sys.stdout.buffer.write(data)
        return
    if os.path.exists(name) and not ns.force:
        raise XZError(f"{name}: File exists")
    tmp = name
    with open(tmp, "wb") as f:
        f.write(data)
    if src and os.path.exists(src):
        try:
            st = os.stat(src)
            os.chmod(name, stat.S_IMODE(st.st_mode))
        except OSError:
            pass


def decompress_all(data, ns, info=False):
    if not data:
        raise XZError("File format not recognized")
    if ns.format == "lzip" or (ns.format == "auto" and data.startswith(b"LZIP")):
        out, streams = decompress_lzip(data)
        return (out, streams) if info else out
    if ns.single_stream:
        d = lzma.LZMADecompressor(format=fmt_for(ns))
        try:
            out = d.decompress(data)
            return (out, 1) if info else out
        except lzma.LZMAError as e:
            raise XZError(str(e) or "File format not recognized")
    out = []
    rest = data
    streams = 0
    while rest:
        d = lzma.LZMADecompressor(format=fmt_for(ns))
        try:
            part = d.decompress(rest)
        except lzma.LZMAError:
            raise XZError("Unexpected end of input", b"".join(out))
        out.append(part)
        streams += 1
        if not d.eof:
            raise XZError("Unexpected end of input", b"".join(out))
        rest = d.unused_data
        if rest and not rest.strip(b"\0"):
            break
    try:
        result = b"".join(out) if out else lzma.decompress(data, format=fmt_for(ns))
        return (result, streams or 1) if info else result
    except lzma.LZMAError as e:
        raise XZError(str(e) or "File format not recognized", b"".join(out))


def compress_one(name, ns):
    data = read_input(name)
    preset = getattr(ns, "preset", None)
    if preset is None:
        preset = 6
    if ns.extreme:
        preset |= lzma.PRESET_EXTREME
    fmt = fmt_for(ns, name, True)
    kwargs = {"format": fmt, "preset": preset}
    if fmt == lzma.FORMAT_XZ:
        kwargs["check"] = check_id(ns.check)
    out = lzma.compress(data, **kwargs)
    to_stdout = ns.stdout or name == "-"
    outname = "-" if to_stdout else default_output_name(name, ns, True)
    write_output(outname, out, ns, None if name == "-" else name)
    if not (ns.keep or to_stdout) and name != "-":
        os.unlink(name)


def decompress_one(name, ns, testing=False):
    data = read_input(name)
    try:
        out = decompress_all(data, ns)
    except XZError as e:
        if not testing and (ns.stdout or name == "-") and e.partial:
            sys.stdout.buffer.write(e.partial)
        if str(e) == "Input format not supported by decoder":
            raise XZError(f"{name if name != '-' else '(stdin)'}: File format not recognized")
        raise
    if testing:
        return len(out)
    to_stdout = ns.stdout or name == "-"
    outname = "-" if to_stdout else default_output_name(name, ns, False)
    write_output(outname, out, ns, None if name == "-" else name)
    if not (ns.keep or to_stdout) and name != "-":
        os.unlink(name)
    return len(out)


def ratio(comp, uncomp):
    if uncomp == 0:
        return "---"
    r = comp / uncomp
    return "---" if r > 9.999 else f"{r:.3f}"


def human(n):
    return f"{n} B"


def detect_check(data):
    if data.startswith(b"\xfd7zXZ\x00") and len(data) > 8:
        return {0: "None", 1: "CRC32", 4: "CRC64", 10: "SHA256"}.get(data[7] & 0x0F, "Unknown")
    return "None"


def list_one(name, ns):
    data = read_input(name)
    try:
        out, streams = decompress_all(data, ns, True)
    except XZError as e:
        raise XZError(f"{name if name != '-' else '(stdin)'}: {e}")
    comp, uncomp = len(data), len(out)
    chk = detect_check(data)
    if ns.robot:
        print(f"name\t{name if name != '-' else '(stdin)'}")
        print(f"file\t{streams}\t{streams}\t{comp}\t{uncomp}\t{ratio(comp, uncomp)}\t{chk}\t0")
    elif ns.verbose:
        fn = name if name != "-" else "(stdin)"
        print(f"{fn} (1/1)")
        print(f"  Streams:           {streams}")
        print(f"  Blocks:            {streams}")
        print(f"  Compressed size:   {human(comp)}")
        print(f"  Uncompressed size: {human(uncomp)}")
        print(f"  Ratio:             {ratio(comp, uncomp)}")
        print(f"  Check:             {chk}")
        print("  Stream Padding:    0 B")
    else:
        print(f"{streams:5d} {streams:7d} {human(comp):>12} {human(uncomp):>12} {ratio(comp, uncomp):>6}  {chk:<6}  {name if name != '-' else '(stdin)'}")
    return comp, uncomp, chk, streams


def main(argv):
    ns, code = parse(argv)
    if ns is None:
        return code
    if ns.help:
        print(SHORT_HELP.format(prog=progname()))
        return 0
    if ns.long_help:
        print(LONG_HELP.format(prog=progname()))
        return 0
    if ns.version:
        print(VERSION)
        return 0
    if ns.info_memory:
        print("Hardware information:")
        print("  Amount of physical memory (RAM):  Unknown")
        print(f"  Number of processor threads:      {os.cpu_count() or 1}")
        print()
        print("Memory usage limits:")
        print("  Compression:                      Disabled")
        print("  Decompression:                    Disabled")
        print("  Multi-threaded decompression:     Disabled")
        print("  Default for -T0:                  Disabled")
        return 0
    if getattr(ns, "filters_help", False):
        print("Filter chains are set using the --filters=FILTERS or --filters1=FILTERS ...")
        print("--filters9=FILTERS options. Each filter in the chain can be separated by")
        print("spaces or '--'. Alternatively a preset <0-9>[e] can be specified instead of")
        print("a filter chain.")
        print()
        print("The supported filters and their options are:")
        print("lzma2:preset=<0-9[e]>,dict=<4KiB-1536MiB>,lc=<0-4>,lp=<0-4>,pb=<0-4>,mode=<fast|normal>,nice=<2-273>,mf=<hc3|hc4|bt2|bt3|bt4>,depth=<0-4294967295>")
        print("x86:start=<0-4294967295>")
        print("arm:start=<0-4294967295>")
        print("armthumb:start=<0-4294967295>")
        print("arm64:start=<0-4294967295>")
        print("riscv:start=<0-4294967295>")
        print("powerpc:start=<0-4294967295>")
        print("ia64:start=<0-4294967295>")
        print("sparc:start=<0-4294967295>")
        print("delta:dist=<1-256>")
        return 0
    add_files_from_option(ns)
    if not ns.files:
        ns.files = ["-"]

    mode = "compress"
    if ns.decompress:
        mode = "decompress"
    if ns.test:
        mode = "test"
    if ns.list_:
        mode = "list"

    if ns.format == "lzip" and mode == "compress":
        eprint(f"{progname()}: Compression of lzip files (.lz) is not supported")
        return 1
    if ns.format == "raw":
        eprint(f"{progname()}: raw: This file format is not supported")
        return 1

    rc = 0
    totals = [0, 0]
    if mode == "list" and not ns.robot and not ns.verbose:
        print("Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename")
    for name in ns.files:
        try:
            if mode == "compress":
                compress_one(name, ns)
            elif mode == "decompress":
                decompress_one(name, ns)
            elif mode == "test":
                decompress_one(name, ns, True)
            elif mode == "list":
                c, u, _, s = list_one(name, ns)
                totals[0] += c
                totals[1] += u
                totals.append(s)
        except FileNotFoundError:
            eprint(f"{progname()}: {name}: No such file or directory", ns.quiet)
            rc = max(rc, 1)
        except PermissionError:
            eprint(f"{progname()}: {name}: Permission denied", ns.quiet)
            rc = max(rc, 1)
        except XZError as e:
            msg = str(e)
            if ": " not in msg:
                msg = f"{name if name != '-' else '(stdin)'}: {msg}"
            eprint(f"{progname()}: {msg}", ns.quiet)
            if "skipping" in msg:
                rc = max(rc, 2)
            else:
                rc = max(rc, 1)
    if mode == "list" and len(ns.files) > 1:
        if ns.robot:
            stream_total = sum(totals[2:]) if len(totals) > 2 else len(ns.files)
            print(f"totals\t{stream_total}\t{stream_total}\t{totals[0]}\t{totals[1]}\t{ratio(totals[0], totals[1])}\tCRC64\t0\t{len(ns.files)}")
        elif not ns.verbose:
            stream_total = sum(totals[2:]) if len(totals) > 2 else len(ns.files)
            print("-" * 79)
            print(f"{stream_total:5d} {stream_total:7d} {human(totals[0]):>12} {human(totals[1]):>12} {ratio(totals[0], totals[1]):>6}  CRC64   {len(ns.files)} files")
    if ns.no_warn and rc == 2:
        return 0
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
