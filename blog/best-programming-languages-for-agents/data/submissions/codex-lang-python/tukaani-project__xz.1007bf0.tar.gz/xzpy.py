#!/usr/bin/env python3
import argparse
import binascii
import hashlib
import os
import struct
import sys

VERSION = "xz (XZ Utils) 5.8.2\nliblzma 5.8.2"
MAGIC = b"\xfd7zXZ\x00"
FOOTER_MAGIC = b"YZ"


def crc32(data: bytes) -> int:
    return binascii.crc32(data) & 0xFFFFFFFF


_CRC64_TABLE = None


def crc64_xz(data: bytes) -> int:
    global _CRC64_TABLE
    if _CRC64_TABLE is None:
        poly = 0xC96C5795D7870F42
        table = []
        for i in range(256):
            r = i
            for _ in range(8):
                if r & 1:
                    r = (r >> 1) ^ poly
                else:
                    r >>= 1
            table.append(r & 0xFFFFFFFFFFFFFFFF)
        _CRC64_TABLE = table
    crc = 0xFFFFFFFFFFFFFFFF
    for b in data:
        crc = _CRC64_TABLE[(crc ^ b) & 0xFF] ^ (crc >> 8)
    return crc ^ 0xFFFFFFFFFFFFFFFF


def uleb128(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def read_uleb128(buf: bytes, pos: int):
    n = 0
    shift = 0
    for _ in range(9):
        if pos >= len(buf):
            raise ValueError("Truncated variable-length integer")
        b = buf[pos]
        pos += 1
        n |= (b & 0x7F) << shift
        if not (b & 0x80):
            return n, pos
        shift += 7
    raise ValueError("Variable-length integer is too long")


def make_block_header() -> bytes:
    # 12-byte total block header: 8 bytes of fields/padding plus CRC32.
    h = bytearray([2, 0x00, 0x21, 0x01, 22, 0, 0, 0])
    return bytes(h) + struct.pack("<I", crc32(h))


def lzma2_store(data: bytes) -> bytes:
    out = bytearray()
    pos = 0
    first = True
    if not data:
        return b"\x00"
    while pos < len(data):
        chunk = data[pos:pos + 65536]
        pos += len(chunk)
        out.append(0x01 if first else 0x02)
        first = False
        out += struct.pack(">H", len(chunk) - 1)
        out += chunk
    out.append(0)
    return bytes(out)


def build_xz(data: bytes, check="crc64") -> bytes:
    check_id = {"none": 0, "crc32": 1, "crc64": 4, "sha256": 10}.get(check, 4)
    flags = bytes([0, check_id])
    stream_header = MAGIC + flags + struct.pack("<I", crc32(flags))
    block_header = make_block_header()
    packed = lzma2_store(data)
    pad = b"\0" * ((4 - (len(packed) % 4)) % 4)
    if check_id == 0:
        check_bytes = b""
    elif check_id == 1:
        check_bytes = struct.pack("<I", crc32(data))
    else:
        if check_id == 10:
            check_bytes = hashlib.sha256(data).digest()
        else:
            check_bytes = struct.pack("<Q", crc64_xz(data))
    block = block_header + packed + pad + check_bytes
    unpadded = len(block_header) + len(packed) + len(check_bytes)
    index_body = bytearray([0])
    index_body += uleb128(1)
    index_body += uleb128(unpadded)
    index_body += uleb128(len(data))
    index_body += b"\0" * ((4 - (len(index_body) % 4)) % 4)
    index = bytes(index_body) + struct.pack("<I", crc32(index_body))
    backward = len(index) // 4 - 1
    footer_data = struct.pack("<I", backward) + flags
    footer = struct.pack("<I", crc32(footer_data)) + footer_data + FOOTER_MAGIC
    return stream_header + block + index + footer


class XZInfo:
    def __init__(self, compressed, uncompressed, check_name, blocks=1, streams=1):
        self.compressed = compressed
        self.uncompressed = uncompressed
        self.check_name = check_name
        self.blocks = blocks
        self.streams = streams


def check_name(check_id):
    return {0: "None", 1: "CRC32", 4: "CRC64", 10: "SHA-256"}.get(check_id, "Unknown")


def parse_xz(data: bytes, want_output=True, ignore_check=False):
    if len(data) < 32 or data[:6] != MAGIC:
        raise ValueError("File format not recognized")
    flags = data[6:8]
    if struct.unpack("<I", data[8:12])[0] != crc32(flags):
        raise ValueError("Corrupt input data")
    check_id = flags[1]
    if data[-2:] != FOOTER_MAGIC:
        raise ValueError("File format not recognized")
    footer_crc, backward, f0, f1 = struct.unpack("<IIBB", data[-12:-2])
    if footer_crc != crc32(data[-8:-2]) or bytes([f0, f1]) != flags:
        raise ValueError("Corrupt input data")
    index_size = (backward + 1) * 4
    index_start = len(data) - 12 - index_size
    if index_start < 12:
        raise ValueError("Corrupt input data")
    idx = data[index_start:index_start + index_size]
    if struct.unpack("<I", idx[-4:])[0] != crc32(idx[:-4]):
        raise ValueError("Corrupt input data")
    if not idx or idx[0] != 0:
        raise ValueError("Corrupt input data")
    pos = 1
    records, pos = read_uleb128(idx, pos)
    if records != 1:
        raise NotImplementedError("Only single-block .xz streams are supported")
    unpadded, pos = read_uleb128(idx, pos)
    unpacked, pos = read_uleb128(idx, pos)
    block_pos = 12
    bh_total = (data[block_pos] + 1) * 4
    bh_size = bh_total - 4
    bh = data[block_pos:block_pos + bh_size]
    if len(bh) != bh_size or block_pos + bh_total > len(data):
        raise ValueError("Corrupt input data")
    if struct.unpack("<I", data[block_pos + bh_size:block_pos + bh_size + 4])[0] != crc32(bh):
        raise ValueError("Corrupt input data")
    flags_b = bh[1]
    if flags_b & 0x3C:
        raise NotImplementedError("Unsupported block header")
    hpos = 2
    if flags_b & 0x40:
        _, hpos = read_uleb128(bh, hpos)
    if flags_b & 0x80:
        _, hpos = read_uleb128(bh, hpos)
    filters = (flags_b & 0x03) + 1
    if filters != 1:
        raise NotImplementedError("Only one-filter streams are supported")
    fid, hpos = read_uleb128(bh, hpos)
    plen, hpos = read_uleb128(bh, hpos)
    props = bh[hpos:hpos + plen]
    if fid != 0x21 or plen != 1:
        raise NotImplementedError("Only LZMA2 streams are supported")
    comp_start = block_pos + bh_total
    check_len = {0: 0, 1: 4, 4: 8, 10: 32}.get(check_id)
    if check_len is None:
        raise NotImplementedError("Unsupported integrity check")
    comp_len = unpadded - bh_total - check_len
    comp = data[comp_start:comp_start + comp_len]
    out = decode_lzma2_stored(comp) if want_output else b""
    if want_output and len(out) != unpacked:
        raise ValueError("Corrupt input data")
    check_start = comp_start + comp_len
    check_start += (4 - (comp_len % 4)) % 4
    got_check = data[check_start:check_start + check_len]
    if want_output and not ignore_check:
        if check_id == 1 and got_check != struct.pack("<I", crc32(out)):
            raise ValueError("Corrupt input data")
        if check_id == 4 and got_check != struct.pack("<Q", crc64_xz(out)):
            raise ValueError("Corrupt input data")
        if check_id == 10 and got_check != hashlib.sha256(out).digest():
            raise ValueError("Corrupt input data")
    return out, XZInfo(len(data), unpacked, check_name(check_id))


def decode_lzma2_stored(comp: bytes) -> bytes:
    pos = 0
    out = bytearray()
    while True:
        if pos >= len(comp):
            raise ValueError("Corrupt input data")
        control = comp[pos]
        pos += 1
        if control == 0:
            return bytes(out)
        if control not in (1, 2):
            raise NotImplementedError("Compressed LZMA2 chunks are not supported")
        if pos + 2 > len(comp):
            raise ValueError("Corrupt input data")
        size = struct.unpack(">H", comp[pos:pos + 2])[0] + 1
        pos += 2
        if pos + size > len(comp):
            raise ValueError("Corrupt input data")
        out += comp[pos:pos + size]
        pos += size


def suffix_out_name(path, suffix):
    return path + suffix


def decompress_name(path, suffix):
    if suffix and path.endswith(suffix):
        return path[:-len(suffix)]
    if path.endswith(".xz"):
        return path[:-3]
    if path.endswith(".txz"):
        return path[:-4] + ".tar"
    return None


def read_input(path):
    if path == "-":
        return sys.stdin.buffer.read(), "(stdin)"
    with open(path, "rb") as f:
        return f.read(), path


def write_output(path, data, force=False):
    if os.path.exists(path) and not force:
        raise FileExistsError(path)
    with open(path, "wb") as f:
        f.write(data)


def fmt_size(n):
    return f"{n} B"


SHORT_HELP = """Usage: ./executable [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files
  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -h, --help          display this short help and exit
  -H, --long-help     display the long help (lists also the advanced options)
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>"""


def make_parser():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("files", nargs="*")
    p.add_argument("-z", "--compress", action="store_true")
    p.add_argument("-d", "--decompress", action="store_true")
    p.add_argument("-t", "--test", action="store_true")
    p.add_argument("-l", "--list", action="store_true")
    p.add_argument("-k", "--keep", action="store_true")
    p.add_argument("-f", "--force", action="store_true")
    p.add_argument("-c", "--stdout", action="store_true")
    p.add_argument("-q", "--quiet", action="count", default=0)
    p.add_argument("-v", "--verbose", action="count", default=0)
    p.add_argument("-e", "--extreme", action="store_true")
    p.add_argument("-T", "--threads")
    p.add_argument("-M", "--memlimit")
    p.add_argument("-S", "--suffix", default=".xz")
    p.add_argument("-F", "--format", default="auto")
    p.add_argument("-C", "--check", default="crc64")
    p.add_argument("--files", dest="files_list", nargs="?", const="-")
    p.add_argument("--files0", dest="files0_list", nargs="?", const="-")
    p.add_argument("--robot", action="store_true")
    p.add_argument("--ignore-check", action="store_true")
    p.add_argument("--single-stream", action="store_true")
    p.add_argument("--no-sparse", action="store_true")
    p.add_argument("--no-sync", action="store_true")
    p.add_argument("--no-warn", action="store_true")
    p.add_argument("--info-memory", action="store_true")
    p.add_argument("--long-help", "-H", action="store_true")
    p.add_argument("--help", "-h", action="store_true")
    p.add_argument("--version", "-V", action="store_true")
    for n in range(10):
        p.add_argument(f"-{n}", dest="preset", action="store_const", const=str(n))
    return p


def err(msg, quiet=0):
    if quiet < 2:
        print(f"{sys.argv[0]}: {msg}", file=sys.stderr)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    # Expand grouped short options such as -dc and -k9.
    expanded = []
    for a in argv:
        if a.startswith("-") and not a.startswith("--") and len(a) > 2:
            if a[1:].isdigit():
                expanded.append(a)
            elif a[1] in "TSFCM":
                expanded.extend([a[:2], a[2:]])
            else:
                for ch in a[1:]:
                    expanded.append("-" + ch)
        else:
            expanded.append(a)
    args, unknown = make_parser().parse_known_args(expanded)
    if args.help:
        print(SHORT_HELP)
        return 0
    if args.long_help:
        print(SHORT_HELP)
        return 0
    if args.version:
        print(VERSION)
        return 0
    if args.info_memory:
        print("Total amount of physical memory (RAM):  1 GiB")
        print("Memory usage limit for compression:     1 GiB")
        print("Memory usage limit for decompression:   1 GiB")
        return 0
    mode = "compress"
    if args.decompress:
        mode = "decompress"
    if args.test:
        mode = "test"
    if args.list:
        mode = "list"
    files = list(args.files)
    for list_file, sep in ((args.files_list, "\n"), (args.files0_list, "\0")):
        if list_file is not None:
            if list_file == "-":
                content = sys.stdin.buffer.read()
            else:
                with open(list_file, "rb") as f:
                    content = f.read()
            names = content.decode(errors="surrogateescape").split(sep)
            files.extend([n for n in names if n])
    if not files:
        files = ["-"]
    status = 0
    infos = []
    for path in files:
        try:
            data, display = read_input(path)
            if mode == "compress":
                out = build_xz(data, args.check)
                if args.stdout or path == "-":
                    sys.stdout.buffer.write(out)
                else:
                    op = suffix_out_name(path, args.suffix)
                    write_output(op, out, args.force)
                    if not args.keep:
                        os.unlink(path)
            elif mode == "decompress":
                out, _ = parse_xz(data, True, args.ignore_check)
                if args.stdout or path == "-":
                    sys.stdout.buffer.write(out)
                else:
                    op = decompress_name(path, args.suffix)
                    if not op:
                        raise ValueError("Filename has an unknown suffix, skipping")
                    write_output(op, out, args.force)
                    if not args.keep:
                        os.unlink(path)
            elif mode == "test":
                try:
                    parse_xz(data, True, args.ignore_check)
                except NotImplementedError:
                    parse_xz(data, False, True)
            else:
                _, info = parse_xz(data, False, True)
                infos.append((path, info))
        except NotImplementedError as e:
            err(f"{path if path != '-' else '(stdin)'}: {e}", args.quiet)
            status = 1
        except FileExistsError as e:
            err(f"{e.args[0]}: File exists", args.quiet)
            status = 1
        except Exception as e:
            err(f"{path if path != '-' else '(stdin)'}: {e}", args.quiet)
            status = 1
    if mode == "list" and infos:
        if args.robot:
            for name, info in infos:
                print(f"name\t{name}")
                print(f"file\t{info.streams}\t{info.blocks}\t{info.compressed}\t{info.uncompressed}\t---\t{info.check_name}\t0")
            print(f"totals\t{len(infos)}\t{sum(i.blocks for _, i in infos)}\t{sum(i.compressed for _, i in infos)}\t{sum(i.uncompressed for _, i in infos)}\t---\tCRC64\t0\t{len(infos)}")
        else:
            print("Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename")
            for name, info in infos:
                print(f"{info.streams:5d}{info.blocks:8d}{fmt_size(info.compressed):>13}{fmt_size(info.uncompressed):>12}    ---  {info.check_name:<7} {name}")
    return status


if __name__ == "__main__":
    sys.exit(main())
