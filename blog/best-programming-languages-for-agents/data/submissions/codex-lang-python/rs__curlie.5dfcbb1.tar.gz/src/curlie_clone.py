#!/usr/bin/env python3
import json
import os
import subprocess
import sys


METHODS = {
    "GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS", "TRACE", "CONNECT"
}

OPTS_WITH_VALUE = {
    "-A", "--user-agent", "-b", "--cookie", "-c", "--cookie-jar", "-d", "--data", "--json",
    "--data-raw", "--data-binary", "--data-urlencode", "-e", "--referer", "-F",
    "--form", "--form-string", "-H", "--header", "-K", "--config", "-m",
    "--max-time", "-o", "--output", "-u", "--user", "-x", "--proxy",
    "-X", "--request", "--connect-timeout", "--cacert", "--capath", "-E",
    "--cert", "--cert-type", "--key", "--key-type", "--resolve", "--connect-to",
    "--interface", "--limit-rate", "--retry", "--retry-delay", "--url",
}


def is_request_item(s):
    return (":" in s and not s.startswith("http://") and not s.startswith("https://")
            and not s.startswith("file://")) or "=" in s


def normalize_for_stderr(url):
    if url.startswith("http://") or url.startswith("https://"):
        return url
    return "http://" + url


def curl_url(url):
    if url.startswith(":"):
        return "localhost" + url
    return url


def add_query(url, pairs):
    if not pairs:
        return url
    sep = "&" if "?" in url else "?"
    return url + sep + "&".join(f"{k}={v}" for k, v in pairs)


def parse_json_value(v):
    try:
        parsed = json.loads(v)
        if isinstance(parsed, float) and parsed.is_integer():
            return int(parsed)
        return parsed
    except Exception:
        return None


def shellish(args):
    out = []
    for a in args:
        if a in ('Content-Type: application/json', 'Accept: application/json, */*'):
            out.append('"' + a + '"')
        else:
            out.append(a)
    return " ".join(out)


def colorize_json_text(text):
    try:
        obj = json.loads(text)
    except Exception:
        return text
    pretty = json.dumps(obj, indent=4, ensure_ascii=False)
    res = []
    in_str = False
    esc = False
    token = ""
    expecting_key = False
    i = 0
    while i < len(pretty):
        ch = pretty[i]
        if in_str:
            token += ch
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
                j = i + 1
                while j < len(pretty) and pretty[j] in " \t":
                    j += 1
                color = "\033[34m" if j < len(pretty) and pretty[j] == ":" else "\033[32m"
                res.append(color + token + "\033[37m")
                token = ""
            i += 1
            continue
        if ch == '"':
            in_str = True
            token = ch
        elif ch in "{}[]":
            res.append("\033[37m" + ch)
        elif ch in ":,":
            res.append("\033[37m" + ch)
        elif ch.isdigit() or ch == "-":
            j = i + 1
            while j < len(pretty) and pretty[j] in "0123456789.eE+-":
                j += 1
            res.append("\033[36m" + pretty[i:j] + "\033[37m")
            i = j
            continue
        else:
            res.append(ch)
        i += 1
    return "\033[37m" + "".join(res) + "\n\033[0m"


def parse(argv):
    curl_debug = False
    pretty = False
    form = False
    tokens = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--curl":
            curl_debug = True
        elif a == "--pretty":
            pretty = True
        elif a == "--form":
            form = True
        else:
            tokens.append(a)
        i += 1

    curl_opts = []
    rest = []
    i = 0
    while i < len(tokens):
        a = tokens[i]
        if a == "--":
            i += 1
            continue
        if a.startswith("-") and a != "-":
            curl_opts.append(a)
            takes_value = a in OPTS_WITH_VALUE
            if not takes_value and len(a) > 2 and a.startswith("-") and not a.startswith("--"):
                # compact short flags are forwarded as-is
                takes_value = False
            if takes_value and i + 1 < len(tokens):
                curl_opts.append(tokens[i + 1])
                i += 2
                continue
            i += 1
            continue
        rest.append(a)
        i += 1

    method = None
    url = None
    items = []
    for a in rest:
        au = a.upper()
        if url is None and method is None and au in METHODS:
            method = au
        elif url is None:
            url = a
        else:
            items.append(a)
    return curl_debug, pretty, form, curl_opts, method, url, items


def build(argv):
    curl_debug, pretty, form, curl_opts, method, url, items = parse(argv)
    headers = []
    query = []
    data = {}
    form_items = []
    passthrough = []
    has_content_type = False
    has_accept = False

    for item in items:
        if ":=" in item:
            k, v = item.split(":=", 1)
            data[k] = parse_json_value(v)
        elif "==" in item:
            k, v = item.split("==", 1)
            query.append((k, v))
        elif "=" in item:
            k, v = item.split("=", 1)
            if form:
                form_items.extend(["-F", item])
            else:
                data[k] = v
        elif ":" in item:
            headers.extend(["-H", item])
            name = item.split(":", 1)[0].lower()
            if name == "content-type":
                has_content_type = True
            elif name == "accept":
                has_accept = True
        else:
            passthrough.append(item)

    cmd = ["curl"]
    cmd.extend(curl_opts)
    if method:
        cmd.extend(["-X", method])
    cmd.extend(headers)
    if form:
        cmd.extend(form_items)
    elif data:
        body = json.dumps(data, sort_keys=True, separators=(",", ":"))
        cmd.extend(["-d", body])
    cmd.extend(passthrough)
    if url is not None:
        url2 = add_query(curl_url(url), query)
        display_url = add_query(normalize_for_stderr(url), query)
        cmd.append(url2)
    else:
        display_url = None
    cmd.extend(["-s", "-S"])
    if pretty:
        cmd.append("-v")
    if not data:
        cmd.append("-d@-")
    if not form and not has_content_type:
        cmd.extend(["-H", "Content-Type: application/json"])
    if not has_accept:
        cmd.extend(["-H", "Accept: application/json, */*"])
    return curl_debug, pretty, display_url, cmd


def main(argv):
    if not argv:
        proc = subprocess.run(["curl", "--help", "all"], stdout=subprocess.PIPE, stderr=None, text=True)
        lines = proc.stdout.splitlines()
        if lines:
            lines[0] = "Usage: ./executable [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]"
        print("\n".join(lines))
        return proc.returncode
    if argv == ["--version"]:
        return subprocess.call(["curl", "--version"])
    if argv[0] == "--help":
        proc = subprocess.run(["curl", "--help"] + argv[1:] if len(argv) > 1 else ["curl", "--help", "--help"],
                              stdout=subprocess.PIPE, stderr=None, text=True)
        lines = proc.stdout.splitlines()
        if lines:
            lines[0] = "Usage: ./executable [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]"
        print("\n".join(lines))
        return proc.returncode

    curl_debug, pretty, display_url, cmd = build(argv)
    if curl_debug:
        if display_url:
            print(display_url, file=sys.stderr)
        print(shellish(cmd))
        return 0
    if display_url:
        print(display_url, file=sys.stderr)
    if pretty:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        sys.stdout.write(colorize_json_text(proc.stdout.decode("utf-8", "replace")))
        return proc.returncode
    return subprocess.call(cmd)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
