#!/usr/bin/env python3
import argparse
import html
import html.parser
import http.client
import json
import re
import socket
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request
from collections import OrderedDict, deque


VERSION = "2.11.1"


HELP = """Usage:
  executable [options] <url>

Application Options:
      --accepted-status-codes=<codes>       Accepted HTTP response status codes
                                            (e.g. '200..300,403') (default:
                                            200..300)
  -b, --buffer-size=<size>                  HTTP response buffer size in bytes
                                            (default: 4096)
  -c, --max-connections=<count>             Maximum number of HTTP connections
                                            (default: 512)
      --max-connections-per-host=<count>    Maximum number of HTTP connections
                                            per host (default: 512)
      --max-response-body-size=<size>       Maximum response body size to read
                                            (default: 10000000)
  -e, --exclude=<pattern>...                Exclude URLs matched with given
                                            regular expressions
  -i, --include=<pattern>...                Include URLs matched with given
                                            regular expressions
      --follow-robots-txt                   Follow robots.txt when scraping
                                            pages
      --follow-sitemap-xml                  Scrape only pages listed in
                                            sitemap.xml (deprecated)
      --header=<header>...                  Custom headers
  -f, --ignore-fragments                    Ignore URL fragments
      --max-retries=<count>                 Maximum retry count for network
                                            errors (default: 0)
      --dns-resolver=<address>              Custom DNS resolver
      --format=[text|json|junit]            Output format (default: text)
      --json                                Output results in JSON (deprecated)
      --experimental-verbose-json           Include successful results in JSON
                                            (deprecated)
      --junit                               Output results as JUnit XML file
                                            (deprecated)
  -r, --max-redirections=<count>            Maximum number of redirections
                                            (default: 64)
      --rate-limit=<rate>                   Max requests per second
  -t, --timeout=<seconds>                   Timeout for HTTP requests in
                                            seconds (default: 10)
  -v, --verbose                             Show successful results too
      --proxy=<host>                        HTTP proxy host
      --skip-tls-verification               Skip TLS certificate verification
      --one-page-only                       Only check links found in the given
                                            URL
      --color=[auto|always|never]           Color output (default: auto)
  -h, --help                                Show this help
      --version                             Show version"""


class LinkParser(html.parser.HTMLParser):
    LINK_ATTRS = {
        "a": ("href",),
        "area": ("href",),
        "img": ("src", "srcset"),
        "script": ("src",),
        "link": ("href",),
        "iframe": ("src",),
        "frame": ("src",),
        "source": ("src", "srcset"),
        "video": ("src", "poster"),
        "audio": ("src",),
        "embed": ("src",),
        "object": ("data",),
        "track": ("src",),
    }

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.ids = set()

    def handle_starttag(self, tag, attrs):
        d = {k.lower(): v for k, v in attrs if k}
        if "id" in d and d["id"] is not None:
            self.ids.add(d["id"])
        if tag == "a" and d.get("name"):
            self.ids.add(d["name"])
        for attr in self.LINK_ATTRS.get(tag, ()):
            val = d.get(attr)
            if not val:
                continue
            if attr == "srcset":
                for part in val.split(","):
                    u = part.strip().split()
                    if u:
                        self.links.append(u[0])
            else:
                self.links.append(val.strip())


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def go_error(exc, url):
    reason = exc
    if isinstance(exc, urllib.error.URLError):
        reason = exc.reason
    if isinstance(reason, ConnectionRefusedError):
        host = urllib.parse.urlsplit(url).netloc
        return f"error when dialing {host}: dial tcp {host}: connect: connection refused"
    if isinstance(reason, socket.gaierror):
        host = urllib.parse.urlsplit(url).hostname or ""
        return f"lookup {host}: no such host"
    if isinstance(reason, TimeoutError) or isinstance(reason, socket.timeout):
        return "request timeout"
    return str(reason)


def accepted_parser(spec):
    accepted = set()
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            if ".." in part:
                a, b = part.split("..", 1)
                a, b = int(a), int(b)
                for x in range(a, b):
                    accepted.add(x)
            else:
                accepted.add(int(part))
        except ValueError:
            raise ValueError(f"invalid status code range: {part}")
    return accepted


def normalize_url(base, link):
    link = html.unescape(link.strip())
    if not link:
        return None
    low = link.lower()
    if low.startswith(("mailto:", "javascript:", "tel:", "data:")):
        return None
    u = urllib.parse.urljoin(base, link)
    p = urllib.parse.urlsplit(u)
    if p.scheme not in ("http", "https"):
        return None
    path = p.path or "/"
    return urllib.parse.urlunsplit((p.scheme, p.netloc, path, p.query, p.fragment))


def defrag(u):
    p = urllib.parse.urlsplit(u)
    return urllib.parse.urlunsplit((p.scheme, p.netloc, p.path or "/", p.query, ""))


def same_site(a, b):
    pa, pb = urllib.parse.urlsplit(a), urllib.parse.urlsplit(b)
    return pa.scheme == pb.scheme and pa.netloc == pb.netloc


def should_check(url, includes, excludes):
    if includes and not any(r.search(url) for r in includes):
        return False
    if any(r.search(url) for r in excludes):
        return False
    return True


def fetch(url, opts, opener):
    p = urllib.parse.urlsplit(url)
    if p.scheme not in ("http", "https"):
        return None, None, f'unsupported protocol "{p.scheme}". http and https are supported', url
    headers = {"User-Agent": "muffet/2.11.1"}
    headers.update(opts.headers)
    current = url
    redirects = 0
    while True:
        req = urllib.request.Request(current, headers=headers, method="GET")
        try:
            with opener.open(req, timeout=opts.timeout) as resp:
                body = resp.read(opts.max_body + 1)
                ctype = resp.headers.get("Content-Type", "")
                return resp.status, (body[: opts.max_body], ctype, resp.geturl()), None, resp.geturl()
        except urllib.error.HTTPError as e:
            if e.code in (301, 302, 303, 307, 308) and e.headers.get("Location"):
                if redirects >= opts.max_redirections:
                    return None, None, "too many redirections", current
                current = urllib.parse.urljoin(current, e.headers.get("Location"))
                redirects += 1
                continue
            body = e.read(opts.max_body + 1)
            return e.code, (body[: opts.max_body], e.headers.get("Content-Type", ""), current), None, current
        except Exception as e:
            return None, None, go_error(e, current), current


def is_html(content_type, url):
    return "html" in (content_type or "").lower() or urllib.parse.urlsplit(url).path.lower().endswith((".html", ".htm", "/"))


def crawl(root, opts):
    ctx = ssl._create_unverified_context() if opts.skip_tls else None
    handlers = [NoRedirect()]
    if ctx:
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    opener = urllib.request.build_opener(*handlers)

    status, body, err, final = fetch(root, opts, opener)
    if err:
        print(f"failed to fetch root page: {err}", file=sys.stderr)
        return None, 1
    if status not in opts.accepted:
        print(f"failed to fetch root page: {status}", file=sys.stderr)
        return None, 1

    robots_disallow = []
    if opts.follow_robots:
        rp = urllib.parse.urlsplit(root)
        robots_url = urllib.parse.urlunsplit((rp.scheme, rp.netloc, "/robots.txt", "", ""))
        st, bd, er, _ = fetch(robots_url, opts, opener)
        if not er and st and 200 <= st < 300 and bd:
            active = False
            for line in bd[0].decode("utf-8", "replace").splitlines():
                line = line.split("#", 1)[0].strip()
                if not line or ":" not in line:
                    continue
                k, v = [x.strip() for x in line.split(":", 1)]
                if k.lower() == "user-agent":
                    active = v == "*"
                elif active and k.lower() == "disallow" and v:
                    robots_disallow.append(v)

    sitemap_urls = []
    if opts.follow_sitemap:
        rp = urllib.parse.urlsplit(root)
        sm_url = urllib.parse.urlunsplit((rp.scheme, rp.netloc, "/sitemap.xml", "", ""))
        st, bd, er, _ = fetch(sm_url, opts, opener)
        if not er and st and 200 <= st < 300 and bd:
            sitemap_urls = re.findall(r"<loc>\s*([^<]+?)\s*</loc>", bd[0].decode("utf-8", "replace"), re.I)

    pages = OrderedDict()
    fetched_pages = {}
    starts = sitemap_urls or [root]
    queue = deque(starts)
    enqueued = {defrag(u) for u in starts}

    # Seed root content from the already completed request.
    fetched_pages[defrag(root)] = (status, body, err, final)

    while queue:
        page = queue.popleft()
        key = defrag(page)
        if key in pages:
            continue
        status, body, err, final = fetched_pages.get(key, (None, None, None, None))
        if body is None:
            status, body, err, final = fetch(page, opts, opener)
        links_out = []
        ids = set()
        if not err and body and is_html(body[1], page):
            parser = LinkParser()
            try:
                parser.feed(body[0].decode("utf-8", "replace"))
            except Exception:
                pass
            ids = parser.ids
            for raw in parser.links:
                u = normalize_url(page, raw)
                if not u or opts.ignore_fragments and urllib.parse.urlsplit(u).fragment:
                    if u and opts.ignore_fragments:
                        u = defrag(u)
                    else:
                        continue
                if u and robots_disallow:
                    path = urllib.parse.urlsplit(u).path or "/"
                    if any(path.startswith(d) for d in robots_disallow):
                        continue
                if u and should_check(u, opts.includes, opts.excludes):
                    links_out.append(u)
        pages[page] = {"links": [], "ids": ids}
        seen_links = set()
        for link in links_out:
            if link in seen_links:
                continue
            seen_links.add(link)
            target = defrag(link) if opts.ignore_fragments else defrag(link)
            if target in fetched_pages:
                st, bd, er, fin = fetched_pages[target]
            else:
                st, bd, er, fin = fetch(target, opts, opener)
                fetched_pages[target] = (st, bd, er, fin)
            frag = urllib.parse.urlsplit(link).fragment
            error = er
            if not error and st not in opts.accepted:
                error = str(st)
            if not error and frag and not opts.ignore_fragments:
                text = ""
                ids = set()
                if bd and is_html(bd[1], target):
                    parser = LinkParser()
                    try:
                        parser.feed(bd[0].decode("utf-8", "replace"))
                        ids = parser.ids
                    except Exception:
                        pass
                if frag not in ids:
                    error = f"id #{frag} not found"
            pages[page]["links"].append({"url": link, "error": error})
            if (
                not opts.one_page
                and not error
                and same_site(root, target)
                and bd
                and is_html(bd[1], target)
                and target not in enqueued
            ):
                enqueued.add(target)
                queue.append(target)
    return pages, 0


def emit_text(pages, verbose):
    failed = False
    for page, info in pages.items():
        shown = [l for l in info["links"] if verbose or l["error"]]
        if verbose or shown:
            print(page)
            for l in shown:
                if l["error"]:
                    failed = True
                    print(f"\t{l['error']}\t{l['url']}")
                else:
                    print(f"\t200\t{l['url']}")
    return 1 if failed else 0


def emit_json(pages, verbose):
    arr = []
    failed = False
    for page, info in pages.items():
        links = []
        for l in info["links"]:
            if l["error"]:
                failed = True
                links.append({"url": l["url"], "error": l["error"]})
            elif verbose:
                links.append({"url": l["url"], "error": ""})
        if links:
            arr.append({"url": page, "links": links})
    print(json.dumps(arr, separators=(",", ":")))
    return 1 if failed else 0


def x(s):
    return html.escape(str(s), quote=True)


def emit_junit(pages):
    failed_any = False
    print('<?xml version="1.0" encoding="UTF-8"?>')
    print("<testsuites>")
    for page, info in pages.items():
        failures = sum(1 for l in info["links"] if l["error"])
        failed_any = failed_any or failures > 0
        if not info["links"]:
            print(f'  <testsuite name="{x(page)}" tests="0" failures="0" skipped="0"></testsuite>')
            continue
        print(f'  <testsuite name="{x(page)}" tests="{len(info["links"])}" failures="{failures}" skipped="0">')
        for l in info["links"]:
            print(f'    <testcase name="{x(l["url"])}" classname="{x(page)}">', end="")
            if l["error"]:
                print()
                print(f'      <failure message="{x(l["error"])}"></failure>')
                print("    </testcase>")
            else:
                print("</testcase>")
        print("  </testsuite>")
    print("</testsuites>")
    return 1 if failed_any else 0


def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP)
        raise SystemExit(0)
    if "--version" in argv:
        print(VERSION)
        raise SystemExit(0)
    fmt = "text"
    verbose = False
    json_verbose = False
    headers = {}
    includes, excludes = [], []
    accepted = "200..300"
    timeout = 10
    max_redirs = 64
    max_body = 10000000
    ignore_fragments = False
    one_page = False
    skip_tls = False
    follow_robots = False
    follow_sitemap = False
    positional = []
    i = 0
    while i < len(argv):
        a = argv[i]
        def val():
            nonlocal i
            if "=" in a:
                return a.split("=", 1)[1]
            i += 1
            if i >= len(argv):
                print(f"expected argument for flag `{a}'", file=sys.stderr)
                raise SystemExit(1)
            return argv[i]
        if a in ("-v", "--verbose"):
            verbose = True
        elif a in ("-f", "--ignore-fragments"):
            ignore_fragments = True
        elif a == "--one-page-only":
            one_page = True
        elif a == "--skip-tls-verification":
            skip_tls = True
        elif a == "--json":
            fmt = "json"
        elif a == "--junit":
            fmt = "junit"
        elif a == "--experimental-verbose-json":
            json_verbose = True
        elif a.startswith("--format"):
            fmt = val()
            if fmt not in ("text", "json", "junit"):
                print(f"Invalid value `{fmt}' for option `--format'. Allowed values are: text, json or junit", file=sys.stderr)
                raise SystemExit(1)
        elif a.startswith("--accepted-status-codes"):
            accepted = val()
        elif a in ("-e", "--exclude") or a.startswith("--exclude="):
            excludes.append(re.compile(val()))
        elif a in ("-i", "--include") or a.startswith("--include="):
            includes.append(re.compile(val()))
        elif a.startswith("--header"):
            hv = val()
            if ":" in hv:
                k, v = hv.split(":", 1)
                headers[k.strip()] = v.strip()
        elif a in ("-t", "--timeout") or a.startswith("--timeout="):
            try:
                timeout = int(val())
            except ValueError as e:
                print(f"invalid argument for flag `-t, --timeout' (expected int): strconv.ParseInt: parsing \"{argv[i] if i < len(argv) else ''}\": invalid syntax", file=sys.stderr)
                raise SystemExit(1)
        elif a in ("-r", "--max-redirections") or a.startswith("--max-redirections="):
            max_redirs = int(val())
        elif a.startswith("--max-response-body-size"):
            max_body = int(val())
        elif a in (
            "-b", "--buffer-size", "-c", "--max-connections",
            "--max-connections-per-host", "--max-retries", "--dns-resolver",
            "--rate-limit", "--proxy", "--color",
        ) or a.startswith(("--buffer-size=", "--max-connections=", "--max-connections-per-host=", "--max-retries=", "--dns-resolver=", "--rate-limit=", "--proxy=", "--color=")):
            if "=" not in a and a not in ("--follow-robots-txt", "--follow-sitemap-xml"):
                _ = val()
        elif a == "--follow-robots-txt":
            follow_robots = True
        elif a == "--follow-sitemap-xml":
            follow_sitemap = True
        elif a.startswith("-"):
            print(f"unknown flag `{a.lstrip('-')}'", file=sys.stderr)
            raise SystemExit(1)
        else:
            positional.append(a)
        i += 1
    if len(positional) != 1:
        print("invalid number of arguments", file=sys.stderr)
        raise SystemExit(1)
    try:
        accepted_set = accepted_parser(accepted)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        raise SystemExit(1)
    class O: pass
    o = O()
    o.format = fmt; o.verbose = verbose; o.json_verbose = json_verbose
    o.headers = headers; o.includes = includes; o.excludes = excludes
    o.accepted = accepted_set; o.timeout = timeout; o.max_redirections = max_redirs; o.max_body = max_body
    o.ignore_fragments = ignore_fragments; o.one_page = one_page; o.skip_tls = skip_tls
    o.follow_robots = follow_robots; o.follow_sitemap = follow_sitemap
    o.url = positional[0]
    return o


def main(argv):
    opts = parse_args(argv)
    pages, code = crawl(opts.url, opts)
    if pages is None:
        return code
    if opts.format == "json":
        return emit_json(pages, opts.verbose or opts.json_verbose)
    if opts.format == "junit":
        return emit_junit(pages)
    return emit_text(pages, opts.verbose)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
