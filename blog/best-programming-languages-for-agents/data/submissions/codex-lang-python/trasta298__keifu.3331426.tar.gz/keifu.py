#!/usr/bin/env python3
import curses
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime


VERSION = "keifu 0.2.3"
ABOUT = "A TUI tool to visualize Git commit graphs with branch genealogy"


@dataclass
class Commit:
    sha: str
    parents: list[str]
    author: str
    email: str
    date: str
    message: str
    refs: list[str]
    graph: str = ""


def eprint(text: str) -> None:
    sys.stderr.write(text + "\n")


def usage() -> str:
    return (
        f"{ABOUT}\n\n"
        "Usage: executable\n\n"
        "Options:\n"
        "  -h, --help     Print help\n"
        "  -V, --version  Print version"
    )


def parse_args(argv: list[str]) -> int | None:
    if len(argv) == 1:
        return None
    arg = argv[1]
    if arg in ("-h", "--help"):
        print(usage())
        return 0
    if arg in ("-V", "--version"):
        print(VERSION)
        return 0
    eprint(f"error: unexpected argument '{arg}' found\n")
    eprint("Usage: executable\n")
    eprint("For more information, try '--help'.")
    return 2


def run_git(args: list[str], cwd: str | None = None, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", *args],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=check,
    )


def repo_root() -> str:
    p = run_git(["rev-parse", "--show-toplevel"], check=False)
    if p.returncode != 0:
        eprint("Error: Git repository not found. Please run inside a Git repository.\n")
        eprint("Caused by:")
        eprint("    could not find repository at '.'; class=Repository (6); code=NotFound (-3)")
        sys.exit(1)
    return p.stdout.strip() or os.getcwd()


def terminal_available() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


def git_lines(args: list[str]) -> list[str]:
    p = run_git(args, check=False)
    if p.returncode != 0:
        return []
    return p.stdout.splitlines()


def load_refs() -> dict[str, list[str]]:
    refs: dict[str, list[str]] = {}
    for line in git_lines(["for-each-ref", "--format=%(objectname)%09%(refname:short)", "refs/heads", "refs/remotes", "refs/tags"]):
        if "\t" not in line:
            continue
        sha, name = line.split("\t", 1)
        refs.setdefault(sha, []).append(name)
    head = run_git(["rev-parse", "--abbrev-ref", "HEAD"], check=False)
    if head.returncode == 0:
        name = head.stdout.strip()
        hsha = run_git(["rev-parse", "HEAD"], check=False)
        if hsha.returncode == 0 and name and name != "HEAD":
            cur = refs.setdefault(hsha.stdout.strip(), [])
            if name not in cur:
                cur.insert(0, name)
    return refs


def load_commits(limit: int = 300) -> list[Commit]:
    refs = load_refs()
    fmt = "%H%x1f%P%x1f%an%x1f%ae%x1f%ad%x1f%s"
    lines = git_lines(["log", "--all", f"-n{limit}", "--date=format:%Y-%m-%d %H:%M:%S", f"--pretty=format:{fmt}"])
    commits: list[Commit] = []
    for line in lines:
        parts = line.split("\x1f")
        if len(parts) < 6:
            continue
        sha, parents, author, email, date, msg = parts[:6]
        commits.append(Commit(sha, parents.split() if parents else [], author, email, date, msg, refs.get(sha, [])))
    graph = git_lines(["log", "--all", "--graph", "--date=short", "--pretty=format:%H%x1f%s", f"-n{limit}"])
    by_sha = {c.sha: c for c in commits}
    for line in graph:
        m = re.search(r"([0-9a-f]{40})\x1f", line)
        if m and m.group(1) in by_sha:
            by_sha[m.group(1)].graph = line[: m.start(1)].rstrip() or "●"
    return commits


def current_branch() -> str:
    p = run_git(["branch", "--show-current"], check=False)
    return p.stdout.strip() if p.returncode == 0 else ""


def repo_name(root: str) -> str:
    p = run_git(["rev-parse", "--show-toplevel"], check=False)
    return os.path.basename((p.stdout.strip() if p.returncode == 0 else root) or root)


def changed_files(commit: Commit) -> tuple[str, list[tuple[str, str, str, str]]]:
    if commit.parents:
        status_args = ["diff", "--name-status", commit.parents[0], commit.sha]
        stat_args = ["diff", "--numstat", commit.parents[0], commit.sha]
    else:
        status_args = ["show", "--format=", "--name-status", commit.sha]
        stat_args = ["show", "--format=", "--numstat", commit.sha]
    rows: list[tuple[str, str, str, str]] = []
    total_add = total_del = 0
    status_by_name: dict[str, str] = {}
    for line in git_lines(status_args):
        parts = line.split("\t")
        if len(parts) >= 2 and re.fullmatch(r"[A-Z][0-9]*", parts[0]):
            status_by_name[parts[-1]] = parts[0][0]
    for line in git_lines(stat_args):
        parts = line.split("\t")
        if len(parts) < 3:
            continue
        a, d, name = parts[0], parts[1], parts[2]
        ai = int(a) if a.isdigit() else 0
        di = int(d) if d.isdigit() else 0
        total_add += ai
        total_del += di
        rows.append((status_by_name.get(name, "M"), name, f"+{ai}", f"-{di}"))
    summary = f"{len(rows)} files changed  +{total_add} -{total_del}"
    return summary, rows


def trim(s: str, width: int) -> str:
    if width <= 0:
        return ""
    return s if len(s) <= width else s[: max(0, width - 1)] + "…"


def draw_box(stdscr, y: int, x: int, h: int, w: int, title: str) -> None:
    if h < 2 or w < 2:
        return
    title_text = f" {title} "
    top = "┌" + trim(title_text + "─" * max(0, w - 2 - len(title_text)), w - 2) + "┐"
    mid = "│" + " " * (w - 2) + "│"
    bot = "└" + "─" * (w - 2) + "┘"
    try:
        stdscr.addstr(y, x, top[:w])
        for yy in range(y + 1, y + h - 1):
            stdscr.addstr(yy, x, mid[:w])
        stdscr.addstr(y + h - 1, x, bot[:w])
    except curses.error:
        pass


def put(stdscr, y: int, x: int, text: str, attr: int = 0) -> None:
    maxy, maxx = stdscr.getmaxyx()
    if 0 <= y < maxy and 0 <= x < maxx:
        try:
            stdscr.addstr(y, x, trim(text, maxx - x), attr)
        except curses.error:
            pass


def tui(stdscr, root: str) -> None:
    curses.curs_set(0)
    curses.use_default_colors()
    for i, fg in enumerate([curses.COLOR_WHITE, curses.COLOR_BLUE, curses.COLOR_GREEN, curses.COLOR_CYAN, curses.COLOR_YELLOW, curses.COLOR_MAGENTA, curses.COLOR_RED], 1):
        curses.init_pair(i, fg, -1)
    selected = 0
    offset = 0
    commits = load_commits()
    detail_cache: dict[str, tuple[str, list[tuple[str, str, str, str]]]] = {}
    while True:
        if not commits:
            commits = load_commits()
        h, w = stdscr.getmaxyx()
        stdscr.erase()
        top_h = max(5, h - 8)
        draw_box(stdscr, 0, 0, top_h, w, "Commits")
        visible = max(1, top_h - 2)
        if selected < offset:
            offset = selected
        if selected >= offset + visible:
            offset = selected - visible + 1
        for idx, c in enumerate(commits[offset : offset + visible], offset):
            y = 1 + idx - offset
            refs = " ".join(f"[{r}]" for r in c.refs if not r.startswith("origin/"))
            graph = c.graph.replace("*", "●") or "●"
            date = c.date[:10]
            text = f"{graph:<5} {refs} {c.message}"
            right = f"{date}  {c.author[:8]}"
            line = trim(text, max(10, w - len(right) - 4)).ljust(max(1, w - len(right) - 3)) + right
            attr = curses.A_REVERSE if idx == selected else 0
            put(stdscr, y, 1, line, attr)
        detail_y = top_h
        detail_h = max(4, h - top_h - 1)
        left_w = max(20, w // 2)
        draw_box(stdscr, detail_y, 0, detail_h, left_w, "Commit Detail")
        draw_box(stdscr, detail_y, left_w, detail_h, w - left_w, "Changed Files")
        if commits:
            c = commits[selected]
            summary, rows = detail_cache.setdefault(c.sha, changed_files(c))
            put(stdscr, detail_y + 1, 2, "Commit:", curses.A_BOLD)
            put(stdscr, detail_y + 2, 2, c.sha, curses.color_pair(5))
            put(stdscr, detail_y + 3, 2, f"Author: {c.author} <{c.email}>", curses.color_pair(4))
            put(stdscr, detail_y + 4, 2, f"Date:   {c.date}", curses.color_pair(1))
            put(stdscr, detail_y + 5, 2, "")
            put(stdscr, detail_y + 6, 2, c.message, curses.A_BOLD)
            put(stdscr, detail_y + 1, left_w + 2, summary, curses.A_BOLD)
            for n, (st, name, add, dele) in enumerate(rows[: max(0, detail_h - 3)]):
                put(stdscr, detail_y + 2 + n, left_w + 2, f"{st:>2} {name}")
                put(stdscr, detail_y + 2 + n, max(left_w + 2, w - 12), f"{add:>4} {dele:>4}", curses.color_pair(3))
        status = f" {repo_name(root)}  {current_branch()}  j/k move  Enter checkout  b branch  f fetch  ? help  q quit "
        put(stdscr, h - 1, 0, trim(status, w), curses.A_REVERSE)
        stdscr.refresh()
        ch = stdscr.getch()
        if ch in (ord("q"), 27):
            return
        if ch in (ord("j"), curses.KEY_DOWN) and selected < len(commits) - 1:
            selected += 1
        elif ch in (ord("k"), curses.KEY_UP) and selected > 0:
            selected -= 1
        elif ch in (ord("g"), curses.KEY_HOME):
            selected = 0
        elif ch in (ord("G"), curses.KEY_END):
            selected = max(0, len(commits) - 1)
        elif ch in (ord("R"), ord("r")):
            commits = load_commits()
            selected = min(selected, max(0, len(commits) - 1))
            detail_cache.clear()
        elif ch == ord("f"):
            run_git(["fetch", "origin"], check=False)
            commits = load_commits()
            detail_cache.clear()
        elif ch in (10, 13) and commits:
            target = commits[selected].refs[0] if commits[selected].refs else commits[selected].sha
            run_git(["checkout", target], check=False)
            commits = load_commits()
        elif ch == ord("?"):
            put(stdscr, max(0, h // 2 - 1), max(0, w // 2 - 18), "j/k move  Enter checkout  q quit", curses.A_REVERSE)
            stdscr.refresh()
            stdscr.getch()


def main() -> int:
    parsed = parse_args(sys.argv)
    if parsed is not None:
        return parsed
    root = repo_root()
    if not terminal_available():
        eprint("Error: No such device or address (os error 6)")
        return 1
    os.chdir(root)
    try:
        curses.wrapper(tui, root)
    except curses.error as exc:
        eprint(f"Error: {exc}")
        return 1
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
