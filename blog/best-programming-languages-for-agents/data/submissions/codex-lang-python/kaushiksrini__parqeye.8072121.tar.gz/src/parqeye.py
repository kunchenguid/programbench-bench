#!/usr/bin/env python3
import os
import sys
import time
import tty
import termios
import select
import shutil
from collections import Counter

VERSION = "parqeye 0.0.2"
HELP = """Command line tool to visualize parquet files

Usage: executable <PATH>

Arguments:
  <PATH>  Path to the parquet file

Options:
  -h, --help     Print help
  -V, --version  Print version
"""


def eprint(text):
    sys.stderr.write(text)
    sys.stderr.flush()


def usage_error(msg):
    eprint(f"error: {msg}\n\nUsage: executable <PATH>\n\nFor more information, try '--help'.\n")
    return 2


def parse_args(argv):
    if len(argv) == 2 and argv[1] in ("-h", "--help"):
        print(HELP, end="")
        return None, 0
    if len(argv) == 2 and argv[1] in ("-V", "--version"):
        print(VERSION)
        return None, 0
    if len(argv) < 2:
        return None, usage_error("the following required arguments were not provided:\n  <PATH>")
    if len(argv) > 2:
        return None, usage_error(f"unexpected argument '{argv[2]}' found")
    return argv[1], None


def load_parquet(path):
    try:
        import pyarrow.parquet as pq
        import pyarrow as pa
    except Exception as exc:
        raise RuntimeError(f"failed to import pyarrow: {exc}") from exc
    pf = pq.ParquetFile(path)
    table = None
    rows = []
    try:
        table = pf.read()
        data = table.to_pylist()
        rows = data[:500]
    except Exception:
        rows = []
    return pq, pa, pf, table, rows


def physical_type(col):
    try:
        return col.physical_type
    except Exception:
        return ""


def encodings(col):
    vals = []
    for i in range(col.num_statistics if False else 0):
        pass
    try:
        vals = list(col.encodings)
    except Exception:
        vals = []
    return ", ".join(str(v) for v in vals)


def fmt_bytes(n):
    if n is None:
        return ""
    try:
        n = int(n)
    except Exception:
        return str(n)
    units = ["B", "KB", "MB", "GB", "TB"]
    f = float(n)
    for unit in units:
        if f < 1024 or unit == units[-1]:
            return f"{int(f)} {unit}" if unit == "B" else f"{f:.1f} {unit}"
        f /= 1024


def fmt_value(v):
    if v is None:
        return "NULL"
    if isinstance(v, bytes):
        body = v.decode("utf-8", "backslashreplace")
        body = body.replace("\\", "\\\\").replace('"', '\\"')
        return f'b"{body}"'
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float):
        return repr(v)
    return str(v)


class Screen:
    def __init__(self):
        size = shutil.get_terminal_size((100, 30))
        self.w = max(40, size.columns)
        self.h = max(12, size.lines)
        self.buf = [[" " for _ in range(self.w)] for _ in range(self.h)]

    def put(self, y, x, text):
        if y < 0 or y >= self.h or x >= self.w:
            return
        if x < 0:
            text = text[-x:]
            x = 0
        for i, ch in enumerate(text):
            xx = x + i
            if xx >= self.w:
                break
            self.buf[y][xx] = ch

    def box(self, y, x, h, w, title=""):
        h = max(2, min(h, self.h - y))
        w = max(2, min(w, self.w - x))
        self.put(y, x, "╭" + "─" * (w - 2) + "╮")
        for yy in range(y + 1, y + h - 1):
            self.put(yy, x, "│")
            self.put(yy, x + w - 1, "│")
        self.put(y + h - 1, x, "╰" + "─" * (w - 2) + "╯")
        if title:
            self.put(y, x + 2, f" {title} ")

    def render(self):
        return "\x1b[H" + "\n".join("".join(row).rstrip() for row in self.buf)


class App:
    tabs = ["Visualize", "Metadata", "Schema", "Row Groups"]

    def __init__(self, path, pf, table, rows):
        self.path = path
        self.pf = pf
        self.table = table
        self.rows = rows
        self.tab = 0
        self.row = 0
        self.col = 0
        self.columns = list(table.column_names) if table is not None else self._columns_from_schema()

    def _columns_from_schema(self):
        try:
            return [self.pf.schema.column(i).name for i in range(len(self.pf.schema))]
        except Exception:
            return []

    def draw_header(self, s):
        s.box(0, 0, 3, s.w)
        x = 2
        for i, tab in enumerate(self.tabs):
            label = f"[{tab}]" if i == self.tab else tab
            s.put(1, x, label)
            x += len(tab) + 4
        p = self.path
        s.put(1, max(1, s.w - len(p) - 2), p[: max(0, s.w - 4)])

    def draw_footer(self, s):
        footer = "parqeye"
        if self.tab == 0:
            help_text = "↑/↓: Row | →/←: Column | u/d: Page - [Tab] Next Tab, [Q]uit"
        else:
            help_text = "[Tab] Next Tab, [Q]uit"
        s.put(s.h - 1, 0, footer)
        s.put(s.h - 1, max(9, s.w - len(help_text) - 1), help_text)

    def draw_visualize(self, s):
        start_y = 4
        rowno_w = 6
        visible_cols = self.columns[self.col:]
        widths = []
        for name in visible_cols:
            vals = [fmt_value(r.get(name)) for r in self.rows[:30] if isinstance(r, dict)]
            widths.append(min(24, max(8, len(name), *(len(v) for v in vals)) + 2))
        x = rowno_w + 3
        for name, width in zip(visible_cols, widths):
            if x >= s.w:
                break
            s.put(start_y, x, name[: width - 1])
            x += width
        s.put(start_y + 1, 0, "─" * min(s.w, rowno_w) + "┬" + "─" * max(0, s.w - rowno_w - 1))
        max_rows = max(0, s.h - start_y - 3)
        for screen_i in range(max_rows):
            idx = self.row + screen_i
            y = start_y + 2 + screen_i
            if idx >= max(1, len(self.rows)):
                s.put(y, rowno_w, "│")
                continue
            s.put(y, 0, str(idx + 1))
            s.put(y, rowno_w, "│")
            row = self.rows[idx] if idx < len(self.rows) else {}
            x = rowno_w + 3
            for name, width in zip(visible_cols, widths):
                if x >= s.w:
                    break
                val = fmt_value(row.get(name)) if isinstance(row, dict) else ""
                s.put(y, x, val[: width - 1])
                x += width

    def draw_metadata(self, s):
        md = self.pf.metadata
        raw = sum(getattr(md.row_group(i), "total_byte_size", 0) for i in range(md.num_row_groups))
        comp = 0
        codecs = Counter()
        encs = set()
        for rg_i in range(md.num_row_groups):
            rg = md.row_group(rg_i)
            for c_i in range(rg.num_columns):
                c = rg.column(c_i)
                comp += c.total_compressed_size or 0
                codecs[str(c.compression)] += 1
                try:
                    encs.update(str(e) for e in c.encodings)
                except Exception:
                    pass
        ratio = (raw / comp) if comp else 0
        items = [
            ("Format version", getattr(md, "format_version", "")),
            ("Created by", md.created_by or ""),
            ("Rows", md.num_rows),
            ("Columns", md.num_columns),
            ("Row groups", md.num_row_groups),
            ("Size (raw)", fmt_bytes(raw)),
            ("Size (compressed)", fmt_bytes(comp)),
            ("Compression ratio", f"{ratio:.2f}x" if ratio else ""),
            ("Codecs (cols)", ", ".join(f"{k}({v})" for k, v in codecs.items())),
            ("Encodings", ", ".join(sorted(encs))),
            ("Avg row size", fmt_bytes(raw // md.num_rows if md.num_rows else 0)),
        ]
        bw = min(s.w - 4, 104)
        x = max(0, (s.w - bw) // 2)
        y = max(4, (s.h - len(items) - 4) // 2)
        s.box(y, x, len(items) + 2, bw, "File Metadata")
        for i, (k, v) in enumerate(items):
            s.put(y + 1 + i, x + 3, f"{k:>18}  {v}"[: bw - 6])

    def draw_schema(self, s):
        left_w = min(34, max(24, s.w // 3))
        s.box(4, 0, s.h - 5, left_w, "Schema Tree")
        s.box(4, left_w, s.h - 5, s.w - left_w, "Column Statistics")
        s.put(5, 2, "└─ root")
        for i, name in enumerate(self.columns[: s.h - 8]):
            branch = "└─" if i == len(self.columns) - 1 else "├─"
            s.put(6 + i, 5, f"{branch} {name}"[: left_w - 7])
        headers = "Repetition   Physical     Compressed  Uncompressed  Ratio   Encodings          Compression"
        s.put(5, left_w + 2, headers[: s.w - left_w - 4])
        md = self.pf.metadata
        for i in range(min(md.num_columns, s.h - 8)):
            col = md.row_group(0).column(i) if md.num_row_groups else None
            rep = "OPTIONAL"
            phys = physical_type(self.pf.schema.column(i)) if i < len(self.pf.schema) else ""
            comp = fmt_bytes(col.total_compressed_size) if col else ""
            uncomp = fmt_bytes(col.total_uncompressed_size) if col else ""
            ratio = f"{(col.total_uncompressed_size / col.total_compressed_size):.2f}x" if col and col.total_compressed_size else ""
            enc = encodings(col) if col else ""
            codec = str(col.compression) if col else ""
            line = f"{rep:<12} {phys:<11} {comp:<11} {uncomp:<13} {ratio:<7} {enc:<18} {codec}"
            s.put(6 + i, left_w + 2, line[: s.w - left_w - 4])

    def draw_row_groups(self, s):
        md = self.pf.metadata
        s.box(4, 0, s.h - 5, s.w, "Row Groups")
        s.put(5, 2, "Group  Rows      Columns  Total Byte Size  Compressed Size")
        for i in range(min(md.num_row_groups, s.h - 8)):
            rg = md.row_group(i)
            comp = sum(rg.column(c).total_compressed_size or 0 for c in range(rg.num_columns))
            line = f"{i:<6} {rg.num_rows:<9} {rg.num_columns:<8} {fmt_bytes(rg.total_byte_size):<16} {fmt_bytes(comp)}"
            s.put(6 + i, 2, line[: s.w - 4])
        if md.num_row_groups:
            y = 8 + min(md.num_row_groups, s.h - 12)
            s.put(y, 2, "Columns in row group 0")
            for j in range(min(md.row_group(0).num_columns, s.h - y - 3)):
                c = md.row_group(0).column(j)
                line = f"{j:<4} {c.path_in_schema:<28} {c.num_values:<8} {c.compression:<14} {fmt_bytes(c.total_compressed_size)}"
                s.put(y + 1 + j, 2, line[: s.w - 4])

    def draw(self):
        s = Screen()
        self.draw_header(s)
        if self.tab == 0:
            self.draw_visualize(s)
        elif self.tab == 1:
            self.draw_metadata(s)
        elif self.tab == 2:
            self.draw_schema(s)
        else:
            self.draw_row_groups(s)
        self.draw_footer(s)
        return s.render()

    def handle_key(self, key):
        if key in (b"q", b"Q", b"\x03"):
            return False
        if key == b"\t":
            self.tab = (self.tab + 1) % len(self.tabs)
        elif key == b"\x1b[Z":
            self.tab = (self.tab - 1) % len(self.tabs)
        elif key in (b"\x1b[B", b"j"):
            self.row = min(max(0, len(self.rows) - 1), self.row + 1)
        elif key in (b"\x1b[A", b"k"):
            self.row = max(0, self.row - 1)
        elif key in (b"\x1b[C", b"l"):
            self.col = min(max(0, len(self.columns) - 1), self.col + 1)
        elif key in (b"\x1b[D", b"h"):
            self.col = max(0, self.col - 1)
        elif key == b"d":
            self.row = min(max(0, len(self.rows) - 1), self.row + 20)
        elif key == b"u":
            self.row = max(0, self.row - 20)
        return True

    def run_tui(self):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        sys.stdout.write("\x1b[?1049h\x1b[?25l")
        sys.stdout.flush()
        try:
            tty.setraw(fd)
            running = True
            while running:
                sys.stdout.write(self.draw())
                sys.stdout.flush()
                r, _, _ = select.select([fd], [], [], 0.25)
                if not r:
                    continue
                ch = os.read(fd, 1)
                if ch == b"\x1b":
                    time.sleep(0.01)
                    while select.select([fd], [], [], 0)[0]:
                        ch += os.read(fd, 1)
                        if len(ch) > 8:
                            break
                running = self.handle_key(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.write("\x1b[?1049l\x1b[?25h")
            sys.stdout.flush()

    def print_plain(self):
        print(f"parqeye {self.path}")
        print(f"Rows: {self.pf.metadata.num_rows}  Columns: {self.pf.metadata.num_columns}  Row groups: {self.pf.metadata.num_row_groups}")
        print("\t".join(self.columns))
        for row in self.rows[:20]:
            print("\t".join(fmt_value(row.get(c)) for c in self.columns))


def main(argv):
    path, code = parse_args(argv)
    if code is not None:
        return code
    if not os.path.exists(path):
        sys.stdout.write("\x1b[?1049h")
        sys.stdout.flush()
        eprint('Error: Custom { kind: Other, error: "No such file or directory (os error 2)" }\n')
        return 1
    try:
        _, _, pf, table, rows = load_parquet(path)
    except Exception as exc:
        sys.stdout.write("\x1b[?1049h")
        sys.stdout.flush()
        eprint(f"Error: Custom {{ kind: Other, error: \"{exc}\" }}\n")
        return 1
    app = App(path, pf, table, rows)
    if sys.stdin.isatty() and sys.stdout.isatty():
        app.run_tui()
    else:
        app.print_plain()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
