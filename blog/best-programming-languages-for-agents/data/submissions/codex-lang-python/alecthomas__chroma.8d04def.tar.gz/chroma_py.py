#!/usr/bin/env python3
import sys, os, json, fnmatch
from html import escape

try:
    from pygments import lex
    from pygments.token import Text as PygText
    from pygments.lexers import get_lexer_by_name, get_lexer_for_filename, guess_lexer, get_all_lexers
    from pygments.util import ClassNotFound
    from pygments.formatters import TerminalFormatter, Terminal256Formatter, HtmlFormatter, SvgFormatter
    from pygments.styles import get_all_styles
except Exception as e:
    sys.stderr.write(f"executable: error: {e}\n")
    sys.exit(1)

HELP = '''Usage: executable [<files> ...] [flags]

Chroma is a general purpose syntax highlighting library and corresponding
command, for Go.

Arguments:
  [<files> ...]    Files to highlight.

Flags:
  -h, --help               Show context-sensitive help.
      --version            Show version.
      --list               List lexers, styles and formatters.
      --unbuffered         Do not buffer output.
      --trace              Trace lexer states as they are traversed.
      --check              Do not format, check for tokenisation errors instead.
      --filename=STRING    Filename to use for selecting a lexer when reading
                           from stdin.
      --fail               Exit silently with status 1 if no specific lexer was
                           found.

Select lexer and style:
  -l, --lexer="autodetect"    Lexer to use when formatting or path to an XML
                              file to load.
  -s, --style="swapoff"       Style to use for formatting or path to an XML file
                              to load.

Output format:
  -f, --formatter="terminal"    Formatter to use.
      --json                    Convenience flag to use JSON formatter.
      --html                    Convenience flag to use HTML formatter.
      --svg                     Convenience flag to use SVG formatter.

HTML formatter options:
  --html-prefix=PREFIX             HTML CSS class prefix.
  --html-styles                    Output HTML CSS styles.
  --html-all-styles                Output all HTML CSS styles, including
                                   redundant ones.
  --html-only                      Output HTML fragment.
  --html-inline-styles             Output HTML with inline styles (no classes).
  --html-tab-width=8               Set the HTML tab width.
  --html-lines                     Include line numbers in output.
  --html-lines-table               Split line numbers and code in a HTML table
  --html-lines-style=STRING        Style for line numbers.
  --html-highlight=N[:M][,...]     Highlight these lines.
  --html-highlight-style=STRING    Style used for highlighting lines.
  --html-base-line=1               Base line number.
  --html-prevent-surrounding-pre
                                   Prevent the surrounding pre tag.
  --html-linkable-lines            Make the line numbers linkable and be a link
                                   to themselves.
'''

FORMATTERS = ["html","json","noop","svg","terminal","terminal16","terminal16m","terminal256","terminal8","tokens"]
ALIASES = {
    'golang':'go', 'py':'python', 'js':'javascript', 'ts':'typescript',
    'shell':'bash', 'sh':'bash', 'zsh':'bash', 'c++':'cpp', 'c#':'csharp',
    'md':'markdown', 'yml':'yaml', 'make':'makefile', 'plain':'text', 'plaintext':'text',
}
STYLE_ALIASES = {'monokailight':'monokai', 'github-dark':'monokai', 'github':'default', 'swapoff':'swapoff'}

def die(msg, code=1):
    sys.stderr.write(f"executable: error: {msg}\n")
    sys.exit(code)

def parse(argv):
    opts = {'files':[], 'lexer':'autodetect', 'style':'swapoff', 'formatter':'terminal',
            'filename':None, 'fail':False, 'list':False, 'version':False, 'help':False,
            'check':False, 'trace':False, 'unbuffered':False,
            'html':{'prefix':'','styles':False,'all_styles':False,'only':False,'inline':False,
                    'tab_width':8,'lines':False,'lines_table':False,'lines_style':None,
                    'highlight':None,'highlight_style':None,'base_line':1,
                    'prevent_pre':False,'linkable_lines':False}}
    takes = {'--lexer':'lexer','-l':'lexer','--style':'style','-s':'style','--formatter':'formatter','-f':'formatter','--filename':'filename'}
    html_takes = {'--html-prefix':'prefix','--html-tab-width':'tab_width','--html-lines-style':'lines_style','--html-highlight':'highlight','--html-highlight-style':'highlight_style','--html-base-line':'base_line'}
    i=0
    while i < len(argv):
        a=argv[i]
        if a in ('-h','--help'): opts['help']=True
        elif a == '--version': opts['version']=True
        elif a == '--list': opts['list']=True
        elif a == '--json': opts['formatter']='json'
        elif a == '--html': opts['formatter']='html'
        elif a == '--svg': opts['formatter']='svg'
        elif a == '--fail': opts['fail']=True
        elif a == '--check': opts['check']=True
        elif a == '--trace': opts['trace']=True
        elif a == '--unbuffered': opts['unbuffered']=True
        elif a == '--html-styles': opts['html']['styles']=True
        elif a == '--html-all-styles': opts['html']['all_styles']=True
        elif a == '--html-only': opts['html']['only']=True
        elif a == '--html-inline-styles': opts['html']['inline']=True
        elif a == '--html-lines': opts['html']['lines']=True
        elif a == '--html-lines-table': opts['html']['lines_table']=True
        elif a == '--html-prevent-surrounding-pre': opts['html']['prevent_pre']=True
        elif a == '--html-linkable-lines': opts['html']['linkable_lines']=True
        elif any(a.startswith(k+'=') for k in takes):
            k=a.split('=',1)[0]; opts[takes[k]]=a.split('=',1)[1]
        elif a in takes:
            i+=1
            if i>=len(argv): die(f"expected value after {a}",80)
            opts[takes[a]]=argv[i]
        elif any(a.startswith(k+'=') for k in html_takes):
            k=a.split('=',1)[0]; v=a.split('=',1)[1]; opts['html'][html_takes[k]]=v
        elif a in html_takes:
            i+=1
            if i>=len(argv): die(f"expected value after {a}",80)
            opts['html'][html_takes[a]]=argv[i]
        elif a.startswith('-'):
            die(f"unknown flag {a}",80)
        else:
            opts['files'].append(a)
        i+=1
    if opts['formatter'] not in FORMATTERS:
        die('--formatter must be one of "html","json","noop","svg","terminal","terminal16","terminal16m","terminal256","terminal8","tokens" but got "'+opts['formatter']+'"',80)
    for k in ('tab_width','base_line'):
        try: opts['html'][k]=int(opts['html'][k])
        except Exception: die(f"invalid integer for --html-{k.replace('_','-')}",80)
    return opts

def list_all():
    print('lexers:')
    rows=[]
    for name, aliases, filenames, mimetypes in get_all_lexers():
        rows.append((name, aliases, filenames, mimetypes))
    for name, aliases, filenames, mimetypes in sorted(rows, key=lambda r: r[0].lower()):
        print(f'  {name}')
        if aliases: print('    aliases: ' + ' '.join(aliases))
        if filenames: print('    filenames: ' + ' '.join(filenames))
        if mimetypes: print('    mimetypes: ' + ' '.join(mimetypes))
    styles = sorted(set(get_all_styles()) | {'swapoff','monokailight','github-dark','catppuccin-mocha','tokyonight-night'})
    print('\nstyles: ' + ' '.join(styles))
    print('formatters: ' + ' '.join(FORMATTERS))

def lexer_for(opts, filename, text):
    name = opts['lexer']
    if name and name != 'autodetect':
        try: return get_lexer_by_name(ALIASES.get(name.lower(), name))
        except ClassNotFound:
            if opts['fail']: return None
            return get_lexer_by_name('text')
    fn = filename or opts.get('filename')
    if fn:
        try: return get_lexer_for_filename(fn, text)
        except ClassNotFound:
            pass
    if opts['fail']: return None
    try: return guess_lexer(text)
    except ClassNotFound: return get_lexer_by_name('text')

def chroma_token_name(ttype):
    if ttype in PygText:
        return 'Text'
    s = str(ttype)
    if s.startswith('Token.'):
        s = s[6:]
    if s == 'Token': s = 'Text'
    parts = [p for p in s.split('.') if p]
    return ''.join(parts) if parts else 'Text'

def get_style(name):
    if name == 'swapoff':
        die('open swapoff: no such file or directory',1)
    return STYLE_ALIASES.get(name, name)

def output_json(tokens):
    arr=[{'type':chroma_token_name(t),'value':v} for t,v in tokens if v!='']
    sys.stdout.write('[\n')
    for i, obj in enumerate(arr):
        comma = ',' if i + 1 < len(arr) else ''
        typ = json.dumps(obj['type'])
        val = json.dumps(obj['value'])
        sys.stdout.write(f'  {{"type":{typ},"value":{val}}}{comma}\n')
    sys.stdout.write(']\n')

def output_tokens(tokens):
    for t,v in tokens:
        vv=v.replace('\\','\\\\').replace('\n','\\n').replace('\t','\\t').replace('"','\\"')
        sys.stdout.write(f'&Token{{{chroma_token_name(t)}, "{vv}"}}\n')

def parse_hl(spec):
    if not spec: return []
    out=[]
    for part in spec.split(','):
        if ':' in part:
            a,b=part.split(':',1); a=int(a or 1); b=int(b or a); out.extend(range(a,b+1))
        else: out.append(int(part))
    return out

def format_text(text, lexer, opts):
    fmt=opts['formatter']
    tokens=list(lex(text, lexer))
    if opts['check']:
        return 0
    if fmt == 'noop':
        sys.stdout.write(text); return 0
    if fmt == 'json':
        output_json(tokens); return 0
    if fmt == 'tokens':
        output_tokens(tokens); return 0
    style=get_style(opts['style'])
    if fmt.startswith('terminal'):
        if fmt in ('terminal256','terminal16m'):
            formatter=Terminal256Formatter(style=style)
        else:
            formatter=TerminalFormatter(bg='dark', style=style)
        from pygments import highlight
        sys.stdout.write(highlight(text, lexer, formatter)); return 0
    if fmt == 'html':
        from pygments import highlight
        h=opts['html']
        if h['styles'] or h['all_styles']:
            formatter=HtmlFormatter(style=style, classprefix=h['prefix'])
            sys.stdout.write(formatter.get_style_defs('.'+(h['prefix']+'chroma' if h['prefix'] else 'chroma'))+'\n')
            return 0
        formatter=HtmlFormatter(style=style, classprefix=h['prefix'], noclasses=h['inline'],
            linenos=('table' if h['lines_table'] else ('inline' if h['lines'] else False)),
            linenostart=h['base_line'], hl_lines=parse_hl(h['highlight']), tabsize=h['tab_width'], nowrap=h['prevent_pre'])
        sys.stdout.write(highlight(text, lexer, formatter)); return 0
    if fmt == 'svg':
        from pygments import highlight
        sys.stdout.write(highlight(text, lexer, SvgFormatter(style=style)))
        return 0
    return 0

def main(argv):
    opts=parse(argv)
    if opts['help']:
        sys.stdout.write(HELP); return 0
    if opts['version']:
        print('?-?-?'); return 0
    if opts['list']:
        list_all(); return 0
    # Preserve the reference build's broken default style for actual formatting.
    if opts['style'] == 'swapoff' and opts['formatter'] not in ('json','noop','tokens') and not opts['check']:
        die('open swapoff: no such file or directory',1)
    files=opts['files'] or [None]
    status=0
    for path in files:
        if path is None or path == '-':
            data=sys.stdin.read(); fn=opts.get('filename')
        else:
            try:
                with open(path, 'r', encoding='utf-8', errors='replace') as f: data=f.read()
            except OSError as e:
                die(str(e),1)
            fn=path
        lx=lexer_for(opts, fn, data)
        if lx is None:
            return 1
        status=max(status, format_text(data, lx, opts))
    return status

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
