#!/usr/bin/env python3
import argparse
import csv
import html
import io
import json
import os
import shlex
import sqlite3
import subprocess
import sys
import time


VERSION = "3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)"

HELP = """Usage: ./executable [OPTIONS] [FILENAME [SQL...]]
FILENAME is the name of an SQLite database. A new database is created
if the file does not previously exist. Defaults to :memory:.
OPTIONS include:
   --                   treat no subsequent arguments as options
   -A ARGS...           run ".archive ARGS" and exit
   -append              append the database to the end of the file
   -ascii               set output mode to 'ascii'
   -bail                stop after hitting an error
   -batch               force batch I/O
   -box                 set output mode to 'box'
   -cmd COMMAND         run "COMMAND" before reading stdin
   -column              set output mode to 'column'
   -csv                 set output mode to 'csv'
   -deserialize         open the database using sqlite3_deserialize()
   -echo                print inputs before execution
   -escape T            ctrl-char escape; T is one of: symbol, ascii, off
   -init FILENAME       read/process named file
   -[no]header          turn headers on or off
   -help                show this message
   -html                set output mode to HTML
   -ifexists            only open if database already exists
   -interactive         force interactive I/O
   -json                set output mode to 'json'
   -line                set output mode to 'line'
   -list                set output mode to 'list'
   -lookaside SIZE N    use N entries of SZ bytes for lookaside memory
   -markdown            set output mode to 'markdown'
   -maxsize N           maximum size for a --deserialize database
   -memtrace            trace all memory allocations and deallocations
   -mmap N              default mmap size set to N
   -newline SEP         set output row separator. Default: '\\n'
   -nofollow            refuse to open symbolic links to database files
   -noinit              Do not read the ~/.sqliterc file at startup
   -nonce STRING        set the safe-mode escape nonce
   -no-rowid-in-view    Disable rowid-in-view using sqlite3_config()
   -nullvalue TEXT      set text string for NULL values. Default ''
   -pagecache SIZE N    use N slots of SZ bytes each for page cache memory
   -pcachetrace         trace all page cache operations
   -quote               set output mode to 'quote'
   -readonly            open the database read-only
   -safe                enable safe-mode
   -screenwidth N       use N as the default screenwidth 
   -separator SEP       set output column separator. Default: '|'
   -stats               print memory stats before each finalize
   -table               set output mode to 'table'
   -tabs                set output mode to 'tabs'
   -unsafe-testing      allow unsafe commands and modes for testing
   -version             show SQLite version
   -vfs NAME            use NAME as the default VFS
   -vfstrace            enable tracing of all VFS calls
   -zip                 open the file as a ZIP Archive"""


DOT_HELP = """.archive ...             Manage SQL archives
.backup ?DB? FILE        Backup DB (default "main") to FILE
.bail on|off             Stop after hitting an error.  Default OFF
.cd DIRECTORY            Change the working directory to DIRECTORY
.changes on|off          Show number of rows changed by SQL
.databases               List names and files of attached databases
.dump ?OBJECTS?          Render database content as SQL
.echo on|off             Turn command echo on or off
.exit ?CODE?             Exit this program with return-code CODE
.headers on|off          Turn display of headers on or off
.help ?-all? ?PATTERN?   Show help text for PATTERN
.import FILE TABLE       Import data from FILE into TABLE
.indexes ?PATTERN?       Show names of indexes matching PATTERN
.mode ?MODE? ?OPTIONS?   Set output mode
.nullvalue STRING        Use STRING in place of NULL values
.once ?OPTIONS? ?FILE?   Output for the next SQL command only to FILE
.open ?OPTIONS? ?FILE?   Close existing database and reopen FILE
.output ?FILE?           Send output to FILE or stdout if FILE is omitted
.print STRING...         Print literal STRING
.quit                    Stop interpreting input stream, exit if primary.
.read FILE               Read input from FILE or command output
.schema ?PATTERN?        Show the CREATE statements matching PATTERN
.separator COL ?ROW?     Change the column and row separators
.show                    Show the current values for various settings
.tables ?TABLE?          List names of tables matching LIKE pattern TABLE
.timeout MS              Try opening locked tables for MS milliseconds
.timer on|off|once       Turn SQL timer on or off.
.version                 Show source, library and compiler versions"""


class Shell:
    def __init__(self, filename=":memory:", readonly=False):
        self.filename = filename or ":memory:"
        self.mode = "list"
        self.headers = False
        self.nullvalue = ""
        self.colsep = "|"
        self.rowsep = "\n"
        self.echo = False
        self.bail = False
        self.timer = False
        self.changes = False
        self.output = sys.stdout
        self.output_name = "stdout"
        self.once_name = None
        self.import_skip = 0
        self.params = {}
        self.open_db(self.filename, readonly=readonly)

    def open_db(self, filename, readonly=False):
        self.filename = filename or ":memory:"
        if readonly and self.filename != ":memory:":
            uri = "file:" + self.filename + "?mode=ro"
            self.conn = sqlite3.connect(uri, uri=True)
        else:
            self.conn = sqlite3.connect(self.filename)
        self.conn.row_factory = sqlite3.Row

    def close_output(self):
        if self.output is not sys.stdout:
            self.output.close()
        self.output = sys.stdout
        self.output_name = "stdout"

    def set_output(self, name):
        self.close_output()
        if name:
            self.output = open(name, "w", newline="")
            self.output_name = name

    def write(self, text=""):
        self.output.write(text)
        self.output.flush()

    def eprint(self, text):
        print(text, file=sys.stderr)

    def onoff(self, value):
        return str(value).lower() in ("on", "yes", "true", "1")

    def cell(self, value):
        return self.nullvalue if value is None else str(value)

    def quote_sql(self, value):
        if value is None:
            return "NULL"
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return str(value)
        if isinstance(value, bytes):
            return "X'" + value.hex().upper() + "'"
        return "'" + str(value).replace("'", "''") + "'"

    def run_sql(self, sql, line_no=None):
        sql = sql.strip()
        if not sql:
            return True
        if self.echo:
            self.write(sql + "\n")
        started = time.perf_counter()
        try:
            cur = self.conn.cursor()
            cur.execute(sql, self.params)
            if cur.description:
                rows = cur.fetchall()
                cols = [d[0] for d in cur.description]
                self.render(cols, rows)
            else:
                self.conn.commit()
            if self.changes:
                self.write(f"changes: {self.conn.total_changes}   total_changes: {self.conn.total_changes}\n")
            if self.timer:
                elapsed = time.perf_counter() - started
                self.write(f"Run Time: real {elapsed:.3f} user 0.000000 sys 0.000000\n")
            return True
        except sqlite3.Error as e:
            prefix = f"Parse error near line {line_no}: " if line_no else "Error: "
            self.eprint(prefix + str(e))
            return False

    def split_sql(self, sql):
        parts = []
        start = 0
        quote = None
        i = 0
        while i < len(sql):
            ch = sql[i]
            if quote:
                if ch == quote:
                    if i + 1 < len(sql) and sql[i + 1] == quote:
                        i += 1
                    else:
                        quote = None
            else:
                if ch in ("'", '"', "`"):
                    quote = ch
                elif ch == "-" and i + 1 < len(sql) and sql[i + 1] == "-":
                    j = sql.find("\n", i)
                    if j < 0:
                        break
                    i = j
                elif ch == "/" and i + 1 < len(sql) and sql[i + 1] == "*":
                    j = sql.find("*/", i + 2)
                    i = len(sql) if j < 0 else j + 1
                elif ch == ";":
                    parts.append(sql[start:i + 1])
                    start = i + 1
            i += 1
        tail = sql[start:].strip()
        if tail:
            parts.append(sql[start:])
        return parts

    def render(self, cols, rows):
        mode = self.mode
        if mode in ("list", "tabs", "ascii"):
            sep = "\t" if mode == "tabs" else ("\x1f" if mode == "ascii" else self.colsep)
            rsep = "\x1e" if mode == "ascii" else self.rowsep
            if self.headers:
                self.write(sep.join(cols) + rsep)
            for row in rows:
                self.write(sep.join(self.cell(row[c]) for c in cols) + rsep)
            return
        if mode == "csv":
            out = io.StringIO()
            writer = csv.writer(out, lineterminator="\r\n")
            if self.headers:
                writer.writerow(cols)
            for row in rows:
                writer.writerow(["" if row[c] is None else row[c] for c in cols])
            self.write(out.getvalue())
            return
        if mode == "json":
            data = [{c: row[c] for c in cols} for row in rows]
            self.write(json.dumps(data, separators=(",", ":")) + "\n")
            return
        if mode == "line":
            for ri, row in enumerate(rows):
                if ri:
                    self.write("\n")
                for c in cols:
                    self.write(f"{c}: {self.cell(row[c])}\n")
            return
        if mode == "quote":
            if self.headers:
                self.write(",".join(self.quote_sql(c) for c in cols) + "\n")
            for row in rows:
                self.write(",".join(self.quote_sql(row[c]) for c in cols) + "\n")
            return
        if mode == "insert":
            table = getattr(self, "insert_table", "table")
            for row in rows:
                self.write(f"INSERT INTO {table} VALUES(" + ",".join(self.quote_sql(row[c]) for c in cols) + ");\n")
            return
        if mode == "html":
            if self.headers or True:
                self.write("<TR>\n" + "".join(f"<TH>{html.escape(c)}\n" for c in cols) + "</TR>\n")
            for row in rows:
                self.write("<TR>\n")
                for c in cols:
                    v = "null" if row[c] is None else html.escape(str(row[c]))
                    self.write(f"<TD>{v}\n")
                self.write("</TR>\n")
            return
        if mode in ("column", "table", "markdown", "box"):
            vals = [[self.cell(row[c]) for c in cols] for row in rows]
            header = cols if (self.headers or mode in ("table", "markdown", "box", "column")) else []
            widths = [len(c) for c in cols]
            for row in vals:
                for i, v in enumerate(row):
                    widths[i] = max(widths[i], len(v))
            if mode == "column":
                if header:
                    self.write("  ".join(cols[i].center(widths[i]) for i in range(len(cols))).rstrip() + "\n")
                    self.write("  ".join("-" * widths[i] for i in range(len(cols))).rstrip() + "\n")
                for row in vals:
                    self.write("  ".join(row[i].ljust(widths[i]) for i in range(len(cols))).rstrip() + "\n")
            elif mode == "markdown":
                self.write("| " + " | ".join(cols[i].center(widths[i]) for i in range(len(cols))) + " |\n")
                self.write("|" + "|".join("-" * (widths[i] + 2) for i in range(len(cols))) + "|\n")
                for row in vals:
                    self.write("| " + " | ".join(row[i].ljust(widths[i]) for i in range(len(cols))) + " |\n")
            elif mode == "table":
                bar = "+" + "+".join("-" * (w + 2) for w in widths) + "+\n"
                self.write(bar)
                self.write("| " + " | ".join(cols[i].center(widths[i]) for i in range(len(cols))) + " |\n")
                self.write(bar)
                for row in vals:
                    self.write("| " + " | ".join(row[i].ljust(widths[i]) for i in range(len(cols))) + " |\n")
                self.write(bar)
            else:
                top = "╭" + "┬".join("─" * (w + 2) for w in widths) + "╮\n"
                mid = "╞" + "╪".join("═" * (w + 2) for w in widths) + "╡\n"
                bot = "╰" + "┴".join("─" * (w + 2) for w in widths) + "╯\n"
                self.write(top)
                self.write("│ " + " │ ".join(cols[i].center(widths[i]) for i in range(len(cols))) + " │\n")
                self.write(mid)
                for row in vals:
                    self.write("│ " + " │ ".join(row[i].ljust(widths[i]) for i in range(len(cols))) + " │\n")
                self.write(bot)

    def tables(self, pattern=None):
        sql = "SELECT name FROM sqlite_schema WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%'"
        params = []
        if pattern:
            sql += " AND name LIKE ?"
            params.append(pattern.replace("*", "%"))
        sql += " ORDER BY 1"
        names = [r[0] for r in self.conn.execute(sql, params)]
        if names:
            self.write(" ".join(names) + "\n")

    def schema(self, pattern=None):
        sql = "SELECT sql FROM sqlite_schema WHERE sql NOT NULL"
        params = []
        if pattern:
            sql += " AND name LIKE ?"
            params.append(pattern.replace("*", "%"))
        sql += " ORDER BY type='table' DESC, name"
        for (s,) in self.conn.execute(sql, params):
            self.write(s.rstrip(";") + ";\n")

    def dump(self):
        self.write("PRAGMA foreign_keys=OFF;\n")
        for line in self.conn.iterdump():
            self.write(line + "\n")

    def import_file(self, file, table):
        with open(file, newline="") as f:
            reader = csv.reader(f, delimiter="\t" if self.mode == "tabs" else self.colsep)
            rows = list(reader)
        if self.import_skip:
            rows = rows[self.import_skip:]
        if not rows:
            return
        n = len(rows[0])
        placeholders = ",".join("?" for _ in range(n))
        self.conn.executemany(f'INSERT INTO "{table}" VALUES({placeholders})', rows)
        self.conn.commit()

    def dot(self, line):
        try:
            parts = shlex.split(line)
        except ValueError as e:
            self.eprint(f"Error: {e}")
            return False
        if not parts:
            return True
        cmd = parts[0][1:]
        args = parts[1:]
        if cmd in ("quit", "exit"):
            raise SystemExit(int(args[0]) if args and args[0].isdigit() else 0)
        if cmd == "help":
            pat = args[-1].lower() if args and not args[-1].startswith("-") else ""
            for l in DOT_HELP.splitlines():
                if not pat or pat in l.lower():
                    self.write(l + "\n")
            return True
        if cmd == "version":
            self.write("SQLite " + VERSION + "\n")
            self.write("zlib version 1.2.11\n")
            return True
        if cmd == "show":
            self.write(f"        echo: {'on' if self.echo else 'off'}\n")
            self.write("         eqp: off\n     explain: auto\n")
            self.write(f"     headers: {'on' if self.headers else 'off'}\n")
            self.write(f"        mode: {self.mode}\n")
            self.write(f"   nullvalue: \"{self.nullvalue}\"\n")
            self.write(f"      output: {self.output_name}\n")
            self.write(f"colseparator: \"{self.colsep}\"\nrowseparator: \"{self.rowsep}\"\n")
            self.write("       stats: off\n       width: \n")
            self.write(f"    filename: {self.filename}\n")
            return True
        if cmd in ("headers", "header"):
            if args:
                self.headers = self.onoff(args[0])
            return True
        if cmd == "mode":
            if not args:
                extra = ' --tablename "{}"'.format(getattr(self, "insert_table", "table")) if self.mode == "insert" else ""
                self.write(f".mode {self.mode}{extra}\n")
            else:
                m = args[0].lower()
                aliases = {"tabs": "tabs", "tcl": "list"}
                self.mode = aliases.get(m, m)
                if self.mode == "tabs":
                    self.colsep = "\t"
                if self.mode == "ascii":
                    self.colsep = "\x1f"; self.rowsep = "\x1e"
                if self.mode == "csv":
                    self.colsep = ","
                if self.mode == "insert" and len(args) > 1:
                    self.insert_table = args[1]
            return True
        if cmd == "separator":
            if args:
                self.colsep = bytes(args[0], "utf-8").decode("unicode_escape")
            if len(args) > 1:
                self.rowsep = bytes(args[1], "utf-8").decode("unicode_escape")
            return True
        if cmd == "nullvalue":
            self.nullvalue = args[0] if args else ""
            return True
        if cmd == "echo":
            self.echo = bool(args and self.onoff(args[0])); return True
        if cmd == "bail":
            self.bail = bool(args and self.onoff(args[0])); return True
        if cmd == "timer":
            self.timer = bool(args and self.onoff(args[0])); return True
        if cmd == "changes":
            self.changes = bool(args and self.onoff(args[0])); return True
        if cmd == "print":
            self.write(" ".join(args) + "\n"); return True
        if cmd == "cd":
            os.chdir(args[0] if args else os.path.expanduser("~")); return True
        if cmd == "read" and args:
            with open(args[0]) as f:
                return self.process(f.read().splitlines())
        if cmd == "output":
            self.set_output(args[0] if args else None); return True
        if cmd == "once":
            self.once_name = args[-1] if args else None; return True
        if cmd == "tables":
            self.tables(args[0] if args else None); return True
        if cmd == "schema":
            self.schema(args[0] if args else None); return True
        if cmd == "dump":
            self.dump(); return True
        if cmd in ("system", "shell") and args:
            return subprocess.call(args) == 0
        if cmd == "databases":
            for seq, name, file in self.conn.execute("PRAGMA database_list"):
                self.write(f"{seq}: {name}: {file or ''}\n")
            return True
        if cmd == "indexes":
            pattern = args[0] if args else "%"
            for (name,) in self.conn.execute("SELECT name FROM sqlite_schema WHERE type='index' AND name LIKE ? ORDER BY 1", (pattern.replace("*", "%"),)):
                self.write(name + "\n")
            return True
        if cmd == "import" and len(args) >= 2:
            self.import_file(args[0], args[1]); return True
        if cmd in ("parameter", "param"):
            sub = args[0] if args else "list"
            if sub == "clear":
                self.params.clear()
            elif sub == "init":
                pass
            elif sub == "list":
                for k in sorted(self.params):
                    self.write(f":{k} {self.quote_sql(self.params[k])}\n")
            elif sub in ("set", "unset") and len(args) >= 2:
                key = args[1].lstrip(":@$")
                if sub == "unset":
                    self.params.pop(key, None)
                else:
                    val = " ".join(args[2:]) if len(args) > 2 else "NULL"
                    try:
                        self.params[key] = self.conn.execute("SELECT " + val).fetchone()[0]
                    except sqlite3.Error:
                        self.params[key] = val
            else:
                self.eprint("Usage: .parameter CMD ...")
                return False
            return True
        if cmd == "open":
            self.conn.close()
            self.open_db(args[-1] if args else ":memory:")
            return True
        if cmd in ("backup", "save") and args:
            dest = args[-1]
            target = sqlite3.connect(dest)
            self.conn.backup(target)
            target.close()
            return True
        if cmd == "restore" and args:
            src = sqlite3.connect(args[-1])
            src.backup(self.conn)
            src.close()
            return True
        if cmd == "timeout" and args:
            self.conn.execute(f"PRAGMA busy_timeout={int(args[0])}")
            return True
        self.eprint(f"Error: unknown command or invalid arguments:  \"{line}\". Enter \".help\" for help")
        return False

    def process(self, lines):
        buf = ""
        start_line = 1
        ok_all = True
        for idx, raw in enumerate(lines, 1):
            line = raw.rstrip("\n")
            if not buf and line.lstrip().startswith("."):
                ok = self.dot(line.strip())
                ok_all = ok_all and ok
                if self.bail and not ok:
                    return False
                continue
            if not buf and line.lstrip().startswith("--"):
                continue
            if not buf:
                start_line = idx
            buf += line + "\n"
            if sqlite3.complete_statement(buf):
                old = None
                if self.once_name:
                    old = (self.output, self.output_name)
                    self.output = open(self.once_name, "w", newline="")
                    self.output_name = self.once_name
                    self.once_name = None
                ok = True
                for stmt in self.split_sql(buf):
                    ok = self.run_sql(stmt, start_line) and ok
                    if self.bail and not ok:
                        break
                if old:
                    self.output.close()
                    self.output, self.output_name = old
                ok_all = ok_all and ok
                buf = ""
                if self.bail and not ok:
                    return False
        if buf.strip():
            ok_all = self.run_sql(buf, start_line) and ok_all
        return ok_all


def parse(argv):
    opts = {"cmds": [], "filename": None, "sql": [], "readonly": False, "actions": []}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            i += 1
            break
        if a in ("-help", "--help"):
            print(HELP)
            raise SystemExit(0)
        if a in ("-version", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a == "-cmd":
            i += 1; opts["cmds"].append(argv[i])
        elif a in ("-init", "-vfs", "-nonce", "-escape", "-newline", "-separator", "-nullvalue", "-mmap", "-maxsize", "-screenwidth"):
            key = a[1:]; i += 1; opts[key] = argv[i]
        elif a in ("-lookaside", "-pagecache"):
            i += 2
        elif a in ("-readonly",):
            opts["readonly"] = True
        elif a.startswith("-") and a[1:] in ("list","line","column","csv","html","json","quote","tabs","ascii","table","box","markdown"):
            opts["actions"].append(("mode", a[1:]))
        elif a in ("-header", "--header"):
            opts["actions"].append(("headers", True))
        elif a in ("-noheader", "--noheader"):
            opts["actions"].append(("headers", False))
        elif a in ("-echo",):
            opts["actions"].append(("echo", True))
        elif a in ("-bail",):
            opts["actions"].append(("bail", True))
        elif a in ("-batch","-interactive","-noinit","-safe","-unsafe-testing","-append","-deserialize","-ifexists","-nofollow","-no-rowid-in-view","-stats","-memtrace","-pcachetrace","-vfstrace","-zip"):
            pass
        else:
            break
        i += 1
    rest = argv[i:]
    if rest:
        opts["filename"] = rest[0]
        opts["sql"] = rest[1:]
    return opts


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    try:
        opts = parse(argv)
        sh = Shell(opts.get("filename") or ":memory:", readonly=opts.get("readonly", False))
        for k, v in opts["actions"]:
            if k == "mode":
                sh.mode = v
                sh.headers = False
                if v == "tabs":
                    sh.colsep = "\t"
                elif v == "csv":
                    sh.colsep = ","
                elif v == "ascii":
                    sh.colsep = "\x1f"; sh.rowsep = "\x1e"
            elif k == "headers": sh.headers = v
            elif k == "echo": sh.echo = v
            elif k == "bail": sh.bail = v
        for k in ("nullvalue", "separator", "newline"):
            if k in opts:
                if k == "nullvalue": sh.nullvalue = opts[k]
                elif k == "separator": sh.colsep = opts[k]
                elif k == "newline": sh.rowsep = opts[k]
        ok = True
        for cmd in opts["cmds"]:
            if cmd.startswith("."):
                ok = sh.dot(cmd) and ok
            else:
                ok = sh.process([cmd]) and ok
        if opts["sql"]:
            ok = sh.process([" ".join(opts["sql"])]) and ok
        else:
            ok = sh.process(sys.stdin.read().splitlines()) and ok
        return 0 if ok else 1
    except SystemExit as e:
        return int(e.code or 0)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
