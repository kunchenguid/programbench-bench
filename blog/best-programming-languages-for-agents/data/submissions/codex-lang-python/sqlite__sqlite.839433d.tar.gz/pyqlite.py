#!/usr/bin/env python3
import csv
import fnmatch
import html
import json
import os
import re
import shlex
import sys
from copy import deepcopy

VERSION = "3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)"
MAGIC = "__pyqlite_db_v1__"


def err(msg):
    print(msg, file=sys.stderr)


def split_sql(text):
    out, buf, quote, linecom, block = [], [], None, False, False
    i = 0
    while i < len(text):
        c = text[i]
        n = text[i + 1] if i + 1 < len(text) else ""
        if linecom:
            if c == "\n":
                linecom = False
                buf.append(c)
            i += 1
            continue
        if block:
            if c == "*" and n == "/":
                block = False
                i += 2
            else:
                i += 1
            continue
        if quote:
            buf.append(c)
            if c == quote:
                if n == quote:
                    buf.append(n)
                    i += 2
                    continue
                quote = None
            i += 1
            continue
        if c in ("'", '"', "`"):
            quote = c
            buf.append(c)
        elif c == "-" and n == "-":
            linecom = True
            i += 1
        elif c == "/" and n == "*":
            block = True
            i += 1
        elif c == ";":
            s = "".join(buf).strip()
            if s:
                out.append(s)
            buf = []
        else:
            buf.append(c)
        i += 1
    s = "".join(buf).strip()
    if s:
        out.append(s)
    return out


def split_top(s, sep=","):
    parts, buf, quote, depth = [], [], None, 0
    i = 0
    while i < len(s):
        c = s[i]
        n = s[i + 1] if i + 1 < len(s) else ""
        if quote:
            buf.append(c)
            if c == quote:
                if n == quote:
                    buf.append(n); i += 2; continue
                quote = None
            i += 1; continue
        if c in ("'", '"', "`"):
            quote = c; buf.append(c)
        elif c == "(":
            depth += 1; buf.append(c)
        elif c == ")":
            depth -= 1; buf.append(c)
        elif c == sep and depth == 0:
            parts.append("".join(buf).strip()); buf = []
        else:
            buf.append(c)
        i += 1
    parts.append("".join(buf).strip())
    return parts


def unquote_ident(x):
    x = x.strip()
    if len(x) >= 2 and x[0] in '"`[' and x[-1] in '"`]':
        return x[1:-1].replace(x[0] * 2, x[0])
    return x


def sql_unquote(x):
    x = x.strip()
    if len(x) >= 2 and x[0] == "'" and x[-1] == "'":
        return x[1:-1].replace("''", "'")
    if len(x) >= 2 and x[0] == '"' and x[-1] == '"':
        return x[1:-1].replace('""', '"')
    return x


def like_to_fnmatch(pat):
    s = ""
    for c in pat:
        s += "*" if c == "%" else "?" if c == "_" else c
    return s


def normalize_schema_sql(s):
    s = s.strip().rstrip(";")
    s = re.sub(r"(?i)^create\s+table\b", "CREATE TABLE", s)
    s = re.sub(r"(?i)^create\s+unique\s+index\b", "CREATE UNIQUE INDEX", s)
    s = re.sub(r"(?i)^create\s+index\b", "CREATE INDEX", s)
    s = re.sub(r"(?i)^create\s+view\b", "CREATE VIEW", s)
    s = re.sub(r"(?i)^create\s+trigger\b", "CREATE TRIGGER", s)
    return s + ";"


class DB:
    def __init__(self, path):
        self.path = None if path in (None, ":memory:") else path
        self.tables = {}
        self.indexes = {}
        self.meta_sql = []
        if self.path:
            self.load()

    def load(self):
        if not os.path.exists(self.path) or os.path.getsize(self.path) == 0:
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("magic") == MAGIC:
                self.tables = data.get("tables", {})
                self.indexes = data.get("indexes", {})
                self.meta_sql = data.get("meta_sql", [])
        except Exception:
            # A real SQLite file or arbitrary input is treated as an empty db.
            pass

    def save(self):
        if not self.path:
            return
        data = {"magic": MAGIC, "tables": self.tables, "indexes": self.indexes, "meta_sql": self.meta_sql}
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, separators=(",", ":"))

    def table_names(self):
        return sorted(k for k, v in self.tables.items() if not v.get("hidden"))

    def get_table(self, name):
        key = self.resolve_table(name)
        if key is None:
            raise Exception(f"no such table: {name}")
        return key, self.tables[key]

    def resolve_table(self, name):
        n = unquote_ident(name).split(".")[-1]
        if n in self.tables:
            return n
        lo = n.lower()
        for k in self.tables:
            if k.lower() == lo:
                return k
        return None

    def execute(self, sql):
        s = sql.strip().rstrip(";").strip()
        if not s:
            return None
        low = s.lower()
        if low in ("begin", "begin transaction", "commit", "end", "rollback"):
            return None
        if low.startswith("pragma "):
            return self.pragma(s)
        if low.startswith("create table"):
            return self.create_table(s)
        if low.startswith("create "):
            return self.create_other(s)
        if low.startswith("drop table"):
            return self.drop_table(s)
        if low.startswith("drop index"):
            return self.drop_index(s)
        if low.startswith("insert "):
            return self.insert(s)
        if low.startswith("delete "):
            return self.delete(s)
        if low.startswith("update "):
            return self.update(s)
        if low.startswith("alter table"):
            return self.alter(s)
        if low.startswith("select ") or low.startswith("with ") or low.startswith("values "):
            return self.select(s)
        raise Exception(f"near \"{s.split()[0]}\": syntax error")

    def pragma(self, s):
        m = re.match(r"pragma\s+([\w.]+)(?:\s*=\s*(.*)|\((.*)\))?$", s, re.I | re.S)
        if not m:
            return None
        name = m.group(1).split(".")[-1].lower()
        arg = m.group(2) if m.group(2) is not None else m.group(3)
        if name == "table_info" and arg:
            tname = sql_unquote(arg.strip())
            _, t = self.get_table(tname)
            rows = []
            for i, col in enumerate(t["columns"]):
                rows.append([i, col["name"], col.get("type", ""), int(col.get("notnull", False)), col.get("dflt_value"), int(col.get("pk", False))])
            return (["cid", "name", "type", "notnull", "dflt_value", "pk"], rows)
        if name == "database_list":
            return (["seq", "name", "file"], [[0, "main", self.path or ""]])
        if name == "foreign_keys":
            return (["foreign_keys"], [[0]])
        if name in ("integrity_check", "quick_check"):
            return ([name], [["ok"]])
        if name == "schema_version":
            return (["schema_version"], [[len(self.meta_sql)]])
        return None

    def create_table(self, s):
        m = re.match(r"create\s+(temp(?:orary)?\s+)?table\s+(if\s+not\s+exists\s+)?([^\s(]+)\s*\((.*)\)\s*$", s, re.I | re.S)
        if not m:
            raise Exception("near \"table\": syntax error")
        name = unquote_ident(m.group(3).split(".")[-1])
        if name in self.tables and not m.group(2):
            raise Exception(f"table {name} already exists")
        cols = []
        for i, part in enumerate(split_top(m.group(4))):
            if not part:
                continue
            first = part.split(None, 1)[0].lower()
            if first in ("primary", "foreign", "unique", "check", "constraint"):
                continue
            toks = part.split()
            cname = unquote_ident(toks[0])
            ctype = ""
            rest = ""
            if len(toks) > 1:
                rest = " ".join(toks[1:])
                ctype_tokens = []
                for tok in toks[1:]:
                    if tok.lower() in ("primary", "not", "null", "default", "unique", "check", "references", "collate", "generated", "as"):
                        break
                    ctype_tokens.append(tok)
                ctype = " ".join(ctype_tokens)
            cols.append({"name": cname, "type": ctype, "pk": bool(re.search(r"\bprimary\s+key\b", rest, re.I)),
                         "notnull": bool(re.search(r"\bnot\s+null\b", rest, re.I)),
                         "dflt_value": None})
        self.tables[name] = {"columns": cols, "rows": [], "sql": normalize_schema_sql(s)}
        if self.tables[name]["sql"] not in self.meta_sql:
            self.meta_sql.append(self.tables[name]["sql"])
        self.save()
        return None

    def create_other(self, s):
        m = re.match(r"create\s+(?:unique\s+)?index\s+(if\s+not\s+exists\s+)?([^\s]+)\s+on\s+([^\s(]+)", s, re.I | re.S)
        if m:
            name = unquote_ident(m.group(2).split(".")[-1])
            self.indexes[name] = {"table": unquote_ident(m.group(3).split(".")[-1]), "sql": normalize_schema_sql(s)}
            if self.indexes[name]["sql"] not in self.meta_sql:
                self.meta_sql.append(self.indexes[name]["sql"])
            self.save()
            return None
        if re.match(r"create\s+(view|trigger)", s, re.I):
            self.meta_sql.append(normalize_schema_sql(s))
            self.save()
            return None
        raise Exception("syntax error")

    def drop_table(self, s):
        m = re.match(r"drop\s+table\s+(if\s+exists\s+)?([^\s;]+)", s, re.I)
        if not m:
            raise Exception("syntax error")
        name = self.resolve_table(m.group(2))
        if name:
            del self.tables[name]
        elif not m.group(1):
            raise Exception(f"no such table: {m.group(2)}")
        self.save()

    def drop_index(self, s):
        m = re.match(r"drop\s+index\s+(if\s+exists\s+)?([^\s;]+)", s, re.I)
        name = unquote_ident(m.group(2)) if m else ""
        if name in self.indexes:
            del self.indexes[name]
        self.save()

    def parse_value(self, expr, row=None):
        expr = expr.strip()
        if not expr:
            return None
        if re.match(r"(?i)^null$", expr):
            return None
        if re.match(r"(?i)^true$", expr):
            return 1
        if re.match(r"(?i)^false$", expr):
            return 0
        if len(expr) >= 2 and expr[0] in ("'", '"') and expr[-1] == expr[0]:
            return sql_unquote(expr)
        if row is not None:
            key = unquote_ident(expr.split(".")[-1])
            if key in row:
                return row[key]
            lo = key.lower()
            for k, v in row.items():
                if k.lower() == lo:
                    return v
        if re.match(r"^-?\d+$", expr):
            try: return int(expr)
            except Exception: pass
        if re.match(r"^-?(\d+\.\d*|\d*\.\d+)([eE][+-]?\d+)?$", expr) or re.match(r"^-?\d+[eE][+-]?\d+$", expr):
            try: return float(expr)
            except Exception: pass
        if expr.startswith("(") and expr.endswith(")"):
            return self.parse_value(expr[1:-1], row)
        for op in ("||", "+", "-", "*", "/"):
            pos = self.find_op(expr, op)
            if pos > 0:
                a = self.parse_value(expr[:pos], row)
                b = self.parse_value(expr[pos + len(op):], row)
                if op == "||":
                    return ("" if a is None else str(a)) + ("" if b is None else str(b))
                if a is None or b is None:
                    return None
                if op == "+": return a + b
                if op == "-": return a - b
                if op == "*": return a * b
                if op == "/": return a / b if b != 0 else None
        m = re.match(r"(?i)(length|lower|upper|abs|round|typeof)\s*\((.*)\)$", expr, re.S)
        if m:
            val = self.parse_value(m.group(2), row)
            fn = m.group(1).lower()
            if fn == "length": return None if val is None else len(str(val))
            if fn == "lower": return None if val is None else str(val).lower()
            if fn == "upper": return None if val is None else str(val).upper()
            if fn == "abs": return None if val is None else abs(val)
            if fn == "round": return None if val is None else round(float(val))
            if fn == "typeof":
                return "null" if val is None else "integer" if isinstance(val, int) and not isinstance(val, bool) else "real" if isinstance(val, float) else "text"
        raise Exception(f"no such column: {expr}")

    def find_op(self, expr, op):
        quote = None; depth = 0
        rng = range(len(expr) - len(op), -1, -1) if op in ("+", "-") else range(len(expr))
        for i in rng:
            c = expr[i]
            if quote:
                if c == quote:
                    quote = None
                continue
            if c in ("'", '"', "`"):
                quote = c
            elif c == ")":
                depth += 1
            elif c == "(":
                depth -= 1
            elif depth == 0 and expr.startswith(op, i):
                if op == "-" and i == 0:
                    continue
                return i
        return -1

    def insert(self, s):
        m = re.match(r"insert\s+(?:or\s+\w+\s+)?into\s+([^\s(]+)\s*(\([^)]*\))?\s*(.*)$", s, re.I | re.S)
        if not m:
            raise Exception("near \"insert\": syntax error")
        name, t = self.get_table(m.group(1))
        cols = [c["name"] for c in t["columns"]]
        if m.group(2):
            cols = [unquote_ident(x) for x in split_top(m.group(2)[1:-1])]
        rest = m.group(3).strip()
        if rest.lower().startswith("values"):
            vals = rest[6:].strip()
            groups = []
            while vals:
                vals = vals.strip()
                if not vals.startswith("("):
                    break
                depth = 0; quote = None
                for i, ch in enumerate(vals):
                    if quote:
                        if ch == quote and (i + 1 >= len(vals) or vals[i + 1] != quote):
                            quote = None
                        elif ch == quote:
                            continue
                    elif ch in ("'", '"'):
                        quote = ch
                    elif ch == "(":
                        depth += 1
                    elif ch == ")":
                        depth -= 1
                        if depth == 0:
                            groups.append(vals[1:i])
                            vals = vals[i + 1:].lstrip()
                            if vals.startswith(","):
                                vals = vals[1:]
                            break
                else:
                    break
            for g in groups:
                vals2 = [self.parse_value(x) for x in split_top(g)]
                row = {c["name"]: None for c in t["columns"]}
                for c, v in zip(cols, vals2):
                    row[c] = v
                t["rows"].append(row)
        elif rest.lower().startswith("select"):
            headers, rows = self.select(rest)
            for vals2 in rows:
                row = {c["name"]: None for c in t["columns"]}
                for c, v in zip(cols, vals2):
                    row[c] = v
                t["rows"].append(row)
        else:
            raise Exception("near \"insert\": syntax error")
        self.save()

    def where_match(self, cond, row):
        cond = cond.strip()
        if not cond:
            return True
        parts = re.split(r"(?i)\s+and\s+", cond)
        for p in parts:
            p = p.strip()
            m = re.match(r"(.+?)\s+(is\s+not|is)\s+(null)\s*$", p, re.I)
            if m:
                v = self.parse_value(m.group(1), row)
                ok = (v is not None) if m.group(2).lower() == "is not" else (v is None)
            else:
                m = re.match(r"(.+?)\s*(=|==|<>|!=|<=|>=|<|>|like)\s*(.+)$", p, re.I | re.S)
                if not m:
                    ok = bool(self.parse_value(p, row))
                else:
                    a = self.parse_value(m.group(1), row); b = self.parse_value(m.group(3), row); op = m.group(2).lower()
                    if op in ("=", "=="): ok = a == b
                    elif op in ("<>", "!="): ok = a != b
                    elif op == "<": ok = a < b
                    elif op == ">": ok = a > b
                    elif op == "<=": ok = a <= b
                    elif op == ">=": ok = a >= b
                    else: ok = fnmatch.fnmatchcase("" if a is None else str(a), like_to_fnmatch("" if b is None else str(b)))
            if not ok:
                return False
        return True

    def delete(self, s):
        m = re.match(r"delete\s+from\s+([^\s]+)(?:\s+where\s+(.+))?$", s, re.I | re.S)
        if not m: raise Exception("syntax error")
        _, t = self.get_table(m.group(1))
        cond = m.group(2) or ""
        t["rows"] = [r for r in t["rows"] if not self.where_match(cond, r)]
        self.save()

    def update(self, s):
        m = re.match(r"update\s+([^\s]+)\s+set\s+(.+?)(?:\s+where\s+(.+))?$", s, re.I | re.S)
        if not m: raise Exception("syntax error")
        _, t = self.get_table(m.group(1))
        assigns = []
        for a in split_top(m.group(2)):
            k, v = a.split("=", 1)
            assigns.append((unquote_ident(k), v))
        for row in t["rows"]:
            if self.where_match(m.group(3) or "", row):
                for k, v in assigns:
                    row[k] = self.parse_value(v, row)
        self.save()

    def alter(self, s):
        m = re.match(r"alter\s+table\s+([^\s]+)\s+add\s+(?:column\s+)?(.+)$", s, re.I | re.S)
        if not m: raise Exception("syntax error")
        _, t = self.get_table(m.group(1))
        toks = m.group(2).split()
        cname = unquote_ident(toks[0])
        ctype = toks[1] if len(toks) > 1 else ""
        t["columns"].append({"name": cname, "type": ctype, "pk": False, "notnull": False, "dflt_value": None})
        for r in t["rows"]: r[cname] = None
        self.save()

    def select(self, s):
        if s.lower().startswith("values"):
            vals = s[6:].strip()
            rows = []
            for g in re.findall(r"\((.*?)\)", vals, re.S):
                rows.append([self.parse_value(x) for x in split_top(g)])
            headers = [f"column{i+1}" for i in range(len(rows[0]) if rows else 0)]
            return headers, rows
        if s.lower().startswith("with "):
            idx = s.lower().rfind("select ")
            if idx >= 0:
                s = s[idx:]
        m = re.match(r"select\s+(.*?)\s+from\s+([^\s]+)(.*)$", s, re.I | re.S)
        if not m:
            exprs = split_top(re.match(r"select\s+(.*)$", s, re.I | re.S).group(1))
            headers, row = [], []
            for e in exprs:
                expr, alias = self.expr_alias(e)
                headers.append(alias or expr)
                row.append(self.parse_value(expr, {}))
            return headers, [row]
        expr_part, table_name, tail = m.group(1), m.group(2), m.group(3) or ""
        if table_name.split(".")[-1].lower() in ("sqlite_master", "sqlite_schema"):
            rows = self.schema_rows()
            t = {"columns": [{"name": c} for c in ["type", "name", "tbl_name", "rootpage", "sql"]], "rows": rows}
        else:
            name, t = self.get_table(table_name)
            rows = []
            for idx, r in enumerate(t["rows"], 1):
                rr = dict(r)
                rr.setdefault("rowid", idx)
                rr.setdefault("_rowid_", idx)
                rr.setdefault("oid", idx)
                rows.append(rr)
        wm = re.search(r"(?i)\s+where\s+(.+?)(?=\s+order\s+by|\s+limit|$)", tail, re.S)
        if wm:
            rows = [r for r in rows if self.where_match(wm.group(1), r)]
        om = re.search(r"(?i)\s+order\s+by\s+(.+?)(?=\s+limit|$)", tail, re.S)
        if om:
            orders = split_top(om.group(1))
            for order in reversed(orders):
                desc = bool(re.search(r"(?i)\s+desc\s*$", order))
                keyexpr = re.sub(r"(?i)\s+(asc|desc)\s*$", "", order).strip()
                if keyexpr.isdigit():
                    # Positional ORDER BY is applied after projection below.
                    continue
                rows.sort(key=lambda r: (self.parse_value(keyexpr, r) is None, self.parse_value(keyexpr, r)), reverse=desc)
        lm = re.search(r"(?i)\s+limit\s+(\d+)(?:\s+offset\s+(\d+))?", tail)
        expr_part = expr_part.strip()
        distinct = False
        if expr_part.lower().startswith("distinct "):
            distinct = True
            expr_part = expr_part[9:].strip()
        if expr_part == "*":
            headers = [c["name"] for c in t["columns"]]
            out = [[r.get(h) for h in headers] for r in rows]
            out = self.finish_select(headers, out, tail, distinct, lm)
            return headers, out
        agg = self.aggregate(expr_part, rows)
        if agg is not None:
            return agg
        exprs = split_top(expr_part)
        headers = []
        parsed = []
        for e in exprs:
            expr, alias = self.expr_alias(e)
            headers.append(alias or expr.split(".")[-1])
            parsed.append(expr)
        out = [[self.parse_value(e, r) for e in parsed] for r in rows]
        out = self.finish_select(headers, out, tail, distinct, lm)
        return headers, out

    def finish_select(self, headers, out, tail, distinct, lm):
        om = re.search(r"(?i)\s+order\s+by\s+(.+?)(?=\s+limit|$)", tail, re.S)
        if om:
            for order in reversed(split_top(om.group(1))):
                desc = bool(re.search(r"(?i)\s+desc\s*$", order))
                keyexpr = re.sub(r"(?i)\s+(asc|desc)\s*$", "", order).strip()
                if keyexpr.isdigit():
                    idx = int(keyexpr) - 1
                    if 0 <= idx < len(headers):
                        out.sort(key=lambda r: (r[idx] is None, r[idx]), reverse=desc)
        if distinct:
            seen, uniq = set(), []
            for r in out:
                k = tuple(r)
                if k not in seen:
                    seen.add(k); uniq.append(r)
            out = uniq
        if lm:
            limit = int(lm.group(1)); offset = int(lm.group(2) or 0)
            out = out[offset:offset + limit]
        return out

    def aggregate(self, expr_part, rows):
        exprs = split_top(expr_part)
        headers, vals = [], []
        for e in exprs:
            expr, alias = self.expr_alias(e)
            m = re.match(r"(?i)^(count|sum|avg|min|max)\s*\(\s*(\*|.*?)\s*\)$", expr.strip(), re.S)
            if not m:
                return None
            fn, inner = m.group(1).lower(), m.group(2).strip()
            headers.append(alias or expr.strip())
            if fn == "count" and inner == "*":
                vals.append(len(rows)); continue
            seq = [self.parse_value(inner, r) for r in rows]
            nonnull = [x for x in seq if x is not None]
            if fn == "count": vals.append(len(nonnull))
            elif fn == "sum": vals.append(sum(nonnull) if nonnull else None)
            elif fn == "avg": vals.append((sum(nonnull) / len(nonnull)) if nonnull else None)
            elif fn == "min": vals.append(min(nonnull) if nonnull else None)
            elif fn == "max": vals.append(max(nonnull) if nonnull else None)
        return headers, [vals]

    def schema_rows(self):
        rows = []
        for t in self.table_names():
            rows.append({"type": "table", "name": t, "tbl_name": t, "rootpage": 0, "sql": self.tables[t]["sql"].rstrip(";")})
        for n in sorted(self.indexes):
            rows.append({"type": "index", "name": n, "tbl_name": self.indexes[n].get("table", ""), "rootpage": 0, "sql": self.indexes[n]["sql"].rstrip(";")})
        return rows

    def expr_alias(self, e):
        m = re.match(r"(.+?)\s+as\s+(.+)$", e, re.I | re.S)
        if m:
            return m.group(1).strip(), unquote_ident(m.group(2).strip())
        m = re.match(r"(.+?)\s+([A-Za-z_]\w*)$", e, re.S)
        if m and not re.search(r"[+\-*/|()'\"]", m.group(2)):
            left = m.group(1).strip()
            if not left.lower().endswith((" collate", " desc", " asc")):
                return left, m.group(2)
        return e.strip(), None


class Shell:
    def __init__(self):
        self.mode = "list"; self.headers = False; self.separator = "|"; self.newline = "\n"
        self.nullvalue = ""; self.echo = False; self.bail = False; self.db = None
        self.output = sys.stdout; self.once = None; self.filename = ":memory:"; self.insert_table = "table"

    def open_db(self, fn):
        self.filename = fn or ":memory:"; self.db = DB(self.filename)

    def out(self, s=""):
        print(s, file=self.output)

    def format_val(self, v):
        return self.nullvalue if v is None else str(v)

    def emit(self, headers, rows):
        if self.once:
            self.output = open(self.once, "w", encoding="utf-8", newline="")
            self.once = None
        try:
            getattr(self, "emit_" + self.mode, self.emit_list)(headers, rows)
        finally:
            if self.output is not sys.stdout:
                self.output.close()
                self.output = sys.stdout

    def emit_list(self, headers, rows):
        if self.headers:
            self.out(self.separator.join(headers))
        for r in rows:
            self.out(self.separator.join(self.format_val(v) for v in r))

    def emit_tabs(self, headers, rows):
        old = self.separator; self.separator = "\t"; self.emit_list(headers, rows); self.separator = old

    def emit_csv(self, headers, rows):
        w = csv.writer(self.output, lineterminator="\r\n")
        if self.headers: w.writerow(headers)
        for r in rows: w.writerow(["" if v is None else v for v in r])

    def emit_quote(self, headers, rows):
        if self.headers:
            self.out(",".join(sql_quote(h) for h in headers))
        for r in rows:
            self.out(",".join(sql_quote(v) for v in r))

    def emit_json(self, headers, rows):
        arr = [{headers[i]: r[i] for i in range(len(headers))} for r in rows]
        self.out(json.dumps(arr, separators=(",", ":")))

    def emit_insert(self, headers, rows):
        for r in rows:
            self.out(f"INSERT INTO {quote_ident(self.insert_table)} VALUES(" + ",".join(sql_quote(v) for v in r) + ");")

    def widths(self, headers, rows):
        vals = [[self.format_val(v) for v in r] for r in rows]
        widths = []
        for i, h in enumerate(headers):
            widths.append(max([len(h)] + [len(r[i]) for r in vals] if vals else [len(h)]))
        return widths, vals

    def emit_column(self, headers, rows):
        widths, vals = self.widths(headers, rows)
        if self.headers:
            self.out("  ".join(headers[i].ljust(widths[i]) for i in range(len(headers))).rstrip())
            self.out("  ".join("-" * widths[i] for i in range(len(headers))).rstrip())
        for r in vals:
            parts = []
            for i, v in enumerate(r):
                parts.append(v.rjust(widths[i]) if is_num(v) else v.ljust(widths[i]))
            self.out("  ".join(parts).rstrip())

    def emit_table(self, headers, rows):
        widths, vals = self.widths(headers, rows)
        border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
        self.out(border)
        if self.headers:
            self.out("|" + "|".join(" " + headers[i].center(widths[i]) + " " for i in range(len(headers))) + "|")
            self.out(border)
        for r in vals:
            self.out("|" + "|".join(" " + (r[i].rjust(widths[i]) if is_num(r[i]) else r[i].ljust(widths[i])) + " " for i in range(len(headers))) + "|")
        self.out(border)

    def emit_markdown(self, headers, rows):
        widths, vals = self.widths(headers, rows)
        if self.headers:
            self.out("| " + " | ".join(headers[i].center(widths[i]) for i in range(len(headers))) + " |")
            self.out("|" + "|".join("-" * (w + 2) for w in widths) + "|")
        for r in vals:
            self.out("| " + " | ".join((r[i].rjust(widths[i]) if is_num(r[i]) else r[i].ljust(widths[i])) for i in range(len(headers))) + " |")

    def emit_box(self, headers, rows):
        widths, vals = self.widths(headers, rows)
        self.out("╭" + "┬".join("─" * (w + 2) for w in widths) + "╮")
        if self.headers:
            self.out("│" + "│".join(" " + headers[i].center(widths[i]) + " " for i in range(len(headers))) + "│")
            self.out("╞" + "╪".join("═" * (w + 2) for w in widths) + "╡")
        for r in vals:
            self.out("│" + "│".join(" " + (r[i].rjust(widths[i]) if is_num(r[i]) else r[i].ljust(widths[i])) + " " for i in range(len(headers))) + "│")
        self.out("╰" + "┴".join("─" * (w + 2) for w in widths) + "╯")

    def emit_html(self, headers, rows):
        if self.headers:
            self.out("<TR>"); [self.out("<TH>" + html.escape(h)) for h in headers]; self.out("</TR>")
        for r in rows:
            self.out("<TR>")
            for v in r: self.out("<TD>" + ("null" if v is None else html.escape(str(v))))
            self.out("</TR>")

    def emit_line(self, headers, rows):
        width = max([len(h) for h in headers] + [0])
        for ri, r in enumerate(rows):
            if ri: self.out("")
            for h, v in zip(headers, r):
                self.out(f"{h.rjust(width)} = {self.format_val(v)}" if False else f"{h}: {self.format_val(v)}")

    def emit_ascii(self, headers, rows):
        s1 = "\x1f"; s2 = "\x1e"
        chunks = []
        if self.headers: chunks.append(s1.join(headers))
        chunks += [s1.join(self.format_val(v) for v in r) for r in rows]
        self.output.write(s2.join(chunks) + (s2 if chunks else ""))

    def do_dot(self, line):
        try:
            args = shlex.split(line)
        except ValueError:
            args = line.split()
        if not args: return True
        cmd = args[0][1:].lower()
        if cmd in ("quit", "exit"):
            raise SystemExit(int(args[1]) if len(args) > 1 and args[1].isdigit() else 0)
        if cmd in ("help",):
            print_help(); return True
        if cmd == "version":
            self.out("SQLite 3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b")
            self.out("zlib version 1.2.11"); self.out("gcc-11.4.0 (64-bit)"); return True
        if cmd in ("headers", "header"):
            if len(args) > 1: self.headers = onoff(args[1])
            else: self.headers = not self.headers
            return True
        if cmd == "mode":
            if len(args) > 1:
                self.set_mode(args[1])
                if self.mode == "insert" and len(args) > 2:
                    self.insert_table = args[2]
            return True
        if cmd == "separator":
            if len(args) > 1: self.separator = decode_sep(args[1])
            if len(args) > 2: self.newline = decode_sep(args[2])
            return True
        if cmd == "nullvalue":
            self.nullvalue = args[1] if len(args) > 1 else ""; return True
        if cmd == "bail":
            self.bail = onoff(args[1]) if len(args) > 1 else not self.bail; return True
        if cmd == "echo":
            self.echo = onoff(args[1]) if len(args) > 1 else not self.echo; return True
        if cmd == "print":
            self.out(" ".join(args[1:])); return True
        if cmd == "open":
            fn = args[-1] if len(args) > 1 else ":memory:"; self.open_db(fn); return True
        if cmd == "databases":
            mode = self.mode; head = self.headers; self.mode = "list"; self.headers = False
            path = os.path.abspath(self.filename) if self.filename != ":memory:" else ""
            self.out(f"main: {path} r/w"); self.mode = mode; self.headers = head; return True
        if cmd == "tables":
            names = self.db.table_names()
            if len(args) > 1: names = [n for n in names if fnmatch.fnmatchcase(n, like_to_fnmatch(args[1]))]
            self.out(" ".join(names)); return True
        if cmd == "indexes":
            names = sorted(self.db.indexes)
            if len(args) > 1:
                pat = like_to_fnmatch(args[1])
                names = [n for n in names if fnmatch.fnmatchcase(n, pat) or fnmatch.fnmatchcase(self.db.indexes[n].get("table",""), pat)]
            for n in names: self.out(n)
            return True
        if cmd == "schema" or cmd == "fullschema":
            pat = args[1] if len(args) > 1 else None
            for t in self.db.table_names():
                if not pat or fnmatch.fnmatchcase(t, like_to_fnmatch(pat)):
                    self.out(self.db.tables[t]["sql"])
            for n in sorted(self.db.indexes):
                if not pat or fnmatch.fnmatchcase(n, like_to_fnmatch(pat)) or fnmatch.fnmatchcase(self.db.indexes[n]["table"], like_to_fnmatch(pat)):
                    self.out(self.db.indexes[n]["sql"])
            return True
        if cmd == "dump":
            self.dump(args[1:] if len(args) > 1 else []); return True
        if cmd == "read":
            with open(args[1], encoding="utf-8") as f: self.run_script(f.read())
            return True
        if cmd in ("save", "backup"):
            dest = args[-1] if len(args) > 1 else None
            if not dest: raise Exception(f"Usage: .{cmd} FILE")
            old = self.db.path
            self.db.path = dest
            self.db.save()
            self.db.path = old
            return True
        if cmd == "restore":
            src = args[-1] if len(args) > 1 else None
            if not src: raise Exception("Usage: .restore FILE")
            self.open_db(src)
            return True
        if cmd == "output":
            if self.output is not sys.stdout: self.output.close()
            self.output = open(args[1], "w", encoding="utf-8") if len(args) > 1 else sys.stdout
            return True
        if cmd == "once":
            if len(args) > 1: self.once = args[-1]
            return True
        if cmd == "import":
            self.import_file(args); return True
        if cmd == "cd":
            os.chdir(args[1]); return True
        if cmd == "shell" or cmd == "system":
            os.system(" ".join(shlex.quote(a) for a in args[1:])); return True
        if cmd == "changes":
            return True
        err(f"Error: unknown command or invalid arguments:  \"{line}\". Enter \".help\" for help")
        return False

    def set_mode(self, m):
        m = m.lower()
        aliases = {"tabs": "tabs", "tab": "tabs", "lines": "line", "insert": "insert"}
        self.mode = aliases.get(m, m)
        if self.mode == "tabs": self.separator = "\t"
        if self.mode == "csv": self.separator = ","
        if self.mode == "ascii": self.separator = "\x1f"

    def dump(self, pats):
        self.out("PRAGMA foreign_keys=OFF;"); self.out("BEGIN TRANSACTION;")
        for t in self.db.table_names():
            if pats and not any(fnmatch.fnmatchcase(t, like_to_fnmatch(p)) for p in pats): continue
            tab = self.db.tables[t]
            self.out(tab["sql"])
            cols = [c["name"] for c in tab["columns"]]
            for r in tab["rows"]:
                self.out(f"INSERT INTO {quote_ident(t)} VALUES(" + ",".join(sql_quote(r.get(c)) for c in cols) + ");")
        for n in sorted(self.db.indexes): self.out(self.db.indexes[n]["sql"])
        self.out("COMMIT;")

    def import_file(self, args):
        if len(args) < 3: raise Exception("Usage: .import FILE TABLE")
        fn, table = args[-2], args[-1]
        delim = "," if self.mode == "csv" else self.separator
        with open(fn, newline="", encoding="utf-8") as f:
            rows = list(csv.reader(f, delimiter=delim if len(delim)==1 else ","))
        if self.db.resolve_table(table) is None:
            if not rows: return True
            self.db.tables[table] = {"columns": [{"name": c, "type": "", "pk": False, "notnull": False, "dflt_value": None} for c in rows[0]], "rows": [], "sql": f"CREATE TABLE {quote_ident(table)}(" + ",".join(quote_ident(c) + " TEXT" for c in rows[0]) + ");"}
            rows = rows[1:]
        _, t = self.db.get_table(table)
        cols = [c["name"] for c in t["columns"]]
        for vals in rows:
            t["rows"].append({c: (vals[i] if i < len(vals) else None) for i, c in enumerate(cols)})
        self.db.save(); return True

    def run_sql(self, sql):
        res = self.db.execute(sql)
        if res: self.emit(*res)

    def run_script(self, text):
        buf = []
        for line in text.splitlines():
            if self.echo: self.out(line)
            if line.lstrip().startswith("."):
                if buf:
                    for st in split_sql("\n".join(buf)):
                        self.run_sql(st)
                    buf = []
                self.do_dot(line.strip())
            else:
                buf.append(line)
                joined = "\n".join(buf)
                stmts = split_sql(joined)
                complete = joined.rstrip().endswith(";")
                if complete:
                    for st in stmts:
                        self.run_sql(st)
                    buf = []
        if buf:
            for st in split_sql("\n".join(buf)):
                self.run_sql(st)


def is_num(s):
    return bool(re.match(r"^-?\d+(\.\d+)?$", s or ""))


def sql_quote(v):
    if v is None: return "NULL"
    if isinstance(v, (int, float)) and not isinstance(v, bool): return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def quote_ident(v):
    return v if re.match(r"^[A-Za-z_]\w*$", v) else '"' + v.replace('"', '""') + '"'


def onoff(x):
    return str(x).lower() in ("1", "on", "yes", "true")


def decode_sep(x):
    return x.encode("utf-8").decode("unicode_escape")


def print_usage():
    print("""Usage: ./executable [OPTIONS] [FILENAME [SQL...]]
FILENAME is the name of an SQLite database. A new database is created
if the file does not previously exist. Defaults to :memory:.
OPTIONS include:
   --                   treat no subsequent arguments as options
   -A ARGS...           run ".archive ARGS" and exit
   -append              append the database to the end of the file
   -ascii               set output mode to 'ascii'
   -bail                stop after hitting an error
   -batch               force batch I/O
   -box                 set output mode to 'box'
   -cmd COMMAND         run "COMMAND" before reading stdin
   -column              set output mode to 'column'
   -csv                 set output mode to 'csv'
   -echo                print inputs before execution
   -escape T            ctrl-char escape; T is one of: symbol, ascii, off
   -init FILENAME       read/process named file
   -[no]header          turn headers on or off
   -help                show this message
   -html                set output mode to HTML
   -ifexists            only open if database already exists
   -interactive         force interactive I/O
   -json                set output mode to 'json'
   -line                set output mode to 'line'
   -list                set output mode to 'list'
   -lookaside SIZE N    use N entries of SZ bytes for lookaside memory
   -markdown            set output mode to 'markdown'
   -maxsize N           maximum size for a --deserialize database
   -memtrace            trace all memory allocations and deallocations
   -mmap N              default mmap size set to N
   -newline SEP         set output row separator. Default: '\\n'
   -nofollow            refuse to open symbolic links to database files
   -noinit              Do not read the ~/.sqliterc file at startup
   -nonce STRING        set the safe-mode escape nonce
   -no-rowid-in-view    Disable rowid-in-view using sqlite3_config()
   -nullvalue TEXT      set text string for NULL values. Default ''
   -pagecache SIZE N    use N slots of SZ bytes each for page cache memory
   -pcachetrace         trace all page cache operations
   -quote               set output mode to 'quote'
   -readonly            open the database read-only
   -safe                enable safe-mode
   -screenwidth N       use N as the default screenwidth 
   -separator SEP       set output column separator. Default: '|'
   -stats               print memory stats before each finalize
   -table               set output mode to 'table'
   -tabs                set output mode to 'tabs'
   -unsafe-testing      allow unsafe commands and modes for testing
   -version             show SQLite version
   -vfs NAME            use NAME as the default VFS
   -vfstrace            enable tracing of all VFS calls
   -zip                 open the file as a ZIP Archive""")


def print_help():
    print(""".archive ...             Manage SQL archives
.backup ?DB? FILE        Backup DB (default "main") to FILE
.bail on|off             Stop after hitting an error.  Default OFF
.cd DIRECTORY            Change the working directory to DIRECTORY
.changes on|off          Show number of rows changed by SQL
.databases               List names and files of attached databases
.dump ?OBJECTS?          Render database content as SQL
.echo on|off             Turn command echo on or off
.exit ?CODE?             Exit this program with return-code CODE
.headers on|off          Turn display of headers on or off
.help ?-all? ?PATTERN?   Show help text for PATTERN
.import FILE TABLE       Import data from FILE into TABLE
.indexes ?PATTERN?       Show names of indexes matching PATTERN
.mode ?MODE? ?OPTIONS?   Set output mode
.nullvalue STRING        Use STRING in place of NULL values
.once ?OPTIONS? ?FILE?   Output for the next SQL command only to FILE
.open ?OPTIONS? ?FILE?   Close existing database and reopen FILE
.output ?FILE?           Send output to FILE or stdout if FILE is omitted
.print STRING...         Print literal STRING
.quit                    Stop interpreting input stream, exit if primary.
.read FILE               Read input from FILE
.schema ?PATTERN?        Show the CREATE statements matching PATTERN
.separator COL ?ROW?     Change the column and row separators
.shell CMD ARGS...       Run CMD ARGS... in a system shell
.system CMD ARGS...      Run CMD ARGS... in a system shell
.tables ?TABLE?          List names of tables matching LIKE pattern TABLE
.version                 Show source, library and compiler versions""")


def main(argv):
    sh = Shell()
    filename = None; sqls = []; cmds = []
    i = 1
    while i < len(argv):
        a = argv[i]
        if a == "--":
            i += 1; break
        if a in ("-help", "--help"):
            print_usage(); return 0
        if a == "-version":
            print(VERSION); return 0
        if a == "-cmd":
            i += 1; cmds.append(argv[i])
        elif a in ("-header", "--header"):
            sh.headers = True
        elif a in ("-noheader", "--noheader"):
            sh.headers = False
        elif a in ("-bail",):
            sh.bail = True
        elif a in ("-echo",):
            sh.echo = True
        elif a in ("-nullvalue", "-separator", "-newline"):
            i += 1
            if a == "-nullvalue": sh.nullvalue = argv[i]
            elif a == "-separator": sh.separator = decode_sep(argv[i])
            else: sh.newline = decode_sep(argv[i])
        elif a.startswith("-") and a[1:] in ("list","csv","tabs","ascii","quote","column","table","box","markdown","html","json","line"):
            sh.set_mode(a[1:])
        elif a.startswith("-") and a in ("-batch","-interactive","-noinit","-readonly","-safe","-unsafe-testing","-nofollow","-zip","-append","-deserialize"):
            pass
        elif a.startswith("-") and a in ("-init","-vfs","-mmap","-maxsize","-lookaside","-pagecache","-screenwidth","-escape","-nonce"):
            i += 1
            if a in ("-lookaside","-pagecache") and i + 1 < len(argv): i += 1
        elif filename is None:
            filename = a
        else:
            sqls.append(a)
        i += 1
    rest = argv[i:]
    if filename is None and rest:
        filename = rest[0]; sqls += rest[1:]
    sh.open_db(filename or ":memory:")
    try:
        for c in cmds:
            sh.do_dot(c) if c.lstrip().startswith(".") else sh.run_script(c if c.endswith(";") else c + ";")
        if sqls:
            text = " ".join(sqls)
            if text.lstrip().startswith("."):
                sh.do_dot(text.strip())
            else:
                for st in split_sql(text):
                    sh.run_sql(st)
        elif not sys.stdin.isatty():
            sh.run_script(sys.stdin.read())
    except SystemExit as e:
        return int(e.code)
    except Exception as e:
        err("Error: " + str(e))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
