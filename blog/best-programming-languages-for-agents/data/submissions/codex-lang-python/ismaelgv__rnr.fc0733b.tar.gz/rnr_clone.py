#!/usr/bin/env python3
import argparse
import json
import os
import re
import shutil
import sys
import unicodedata
from datetime import datetime


VERSION = "rnr 0.5.1"


ASCII_OVERRIDES = {
    "ß": "ss",
    "æ": "ae",
    "Æ": "AE",
    "œ": "oe",
    "Œ": "OE",
    "ø": "o",
    "Ø": "O",
    "ð": "d",
    "Ð": "D",
    "þ": "th",
    "Þ": "Th",
    "ł": "l",
    "Ł": "L",
    "ı": "i",
    "Đ": "D",
    "đ": "d",
    "世": "Shi",
    "界": "Jie",
    "中": "Zhong",
    "国": "Guo",
    "日": "Ri",
    "本": "Ben",
    "語": "Yu",
    "汉": "Han",
    "漢": "Han",
    "字": "Zi",
}


class RnrError(Exception):
    pass


def to_ascii_text(text):
    out = []
    for ch in text:
        if ord(ch) < 128:
            out.append(ch)
        elif ch in ASCII_OVERRIDES:
            out.append(ASCII_OVERRIDES[ch])
        else:
            decomposed = unicodedata.normalize("NFKD", ch)
            ascii_part = decomposed.encode("ascii", "ignore").decode("ascii")
            out.append(ascii_part)
    return "".join(out)


def replacement_to_python(rep):
    # Rust's regex crate accepts $1 and ${1}; Python wants \g<1>.
    def braced(match):
        return r"\g<%s>" % match.group(1)

    rep = re.sub(r"\$\{(\d+)\}", braced, rep)
    rep = re.sub(r"\$(\d+)", braced, rep)
    return rep


def is_hidden_path(path):
    for part in path.split(os.sep):
        if part not in ("", ".", "..") and part.startswith("."):
            return True
    return False


def display_path(path):
    return path


def iter_targets(paths, recursive=False, max_depth=None, hidden=False, include_dirs=False):
    targets = []
    for raw in paths:
        if os.path.isdir(raw):
            if not recursive:
                if include_dirs and (hidden or not is_hidden_path(os.path.basename(raw))):
                    targets.append(raw)
                continue
            root = raw

            def visit(cur, depth):
                try:
                    names = sorted(os.listdir(cur))
                except OSError:
                    return
                dirs = [n for n in names if os.path.isdir(os.path.join(cur, n))]
                files = [n for n in names if not os.path.isdir(os.path.join(cur, n))]
                if not hidden:
                    dirs = [d for d in dirs if not d.startswith(".")]
                    files = [f for f in files if not f.startswith(".")]
                descend = max_depth is None or depth < max_depth
                if descend:
                    for d in dirs:
                        full = os.path.join(cur, d)
                        visit(full, depth + 1)
                        if include_dirs:
                            targets.append(full)
                for f in files:
                    targets.append(os.path.join(cur, f))

            visit(root, 0)
        else:
            base = os.path.basename(raw)
            if hidden or not base.startswith("."):
                targets.append(raw)
    return targets


def make_dump_name(prefix):
    return f"{prefix}{datetime.now().strftime('%Y-%m-%d_%H%M%S')}.json"


def write_dump(operations, prefix):
    name = make_dump_name(prefix)
    data = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "operations": [{"source": s, "target": t} for s, t in operations],
    }
    with open(name, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
    return name


def build_ops_regex(args):
    try:
        pattern = re.compile(args.expression)
    except re.error as exc:
        raise RnrError(str(exc))
    repl = replacement_to_python(args.replacement)
    count = args.replace_limit if args.replace_limit is not None else 0
    ops = []
    for path in iter_targets(args.paths, args.recursive, args.max_depth, args.hidden, args.include_dirs):
        name = os.path.basename(path)
        try:
            new_name = pattern.sub(repl, name, count=count)
        except re.error as exc:
            raise RnrError(str(exc))
        if args.replace_transform == "upper":
            new_name = new_name.upper()
        elif args.replace_transform == "lower":
            new_name = new_name.lower()
        elif args.replace_transform == "ascii":
            new_name = to_ascii_text(new_name)
        if new_name != name:
            ops.append((path, os.path.join(os.path.dirname(path), new_name)))
    return ops


def build_ops_ascii(args):
    ops = []
    for path in iter_targets(args.paths, args.recursive, args.max_depth, args.hidden, args.include_dirs):
        name = os.path.basename(path)
        new_name = to_ascii_text(name)
        if new_name != name:
            ops.append((path, os.path.join(os.path.dirname(path), new_name)))
    return ops


def print_ops(ops, dry_run, silent):
    if silent:
        return
    if dry_run:
        print("This is a DRY-RUN")
    for source, target in ops:
        print(f"{display_path(source)} -> {display_path(target)}")


def validate_ops(ops):
    sources = {os.path.abspath(s) for s, _ in ops}
    targets = {}
    for source, target in ops:
        abss = os.path.abspath(source)
        abst = os.path.abspath(target)
        if abst in targets:
            raise RnrError(f"Conflict with existing path {source} -> {target}")
        targets[abst] = source
        if os.path.exists(target) and abst not in sources:
            raise RnrError(f"Conflict with existing path {source} -> {target}")
        if not os.path.exists(source):
            raise RnrError(f"Cannot rename {source} -> {target}\nNo such file or directory (os error 2)")


def apply_ops(ops, backup=False, silent=False):
    validate_ops(ops)
    for source, target in ops:
        if backup:
            backup_path = source + ".bk"
            shutil.copy2(source, backup_path) if os.path.isfile(source) else shutil.copytree(source, backup_path)
            if not silent:
                print(f"Info:  Backup created - {source} -> {backup_path}")
        try:
            os.rename(source, target)
        except OSError as exc:
            raise RnrError(f"Cannot rename {source} -> {target}\n{exc.strerror} (os error {exc.errno})")
        if not silent:
            print(f"{source} -> {target}")


def maybe_dump(ops, args, dry_run):
    if args.no_dump:
        return
    if args.dump or (not dry_run and ops):
        write_dump(ops, args.dump_prefix)


def run_common(ops, args):
    dry_run = not args.force
    if dry_run:
        print_ops(ops, True, args.silent)
    else:
        apply_ops(ops, args.backup, args.silent)
    maybe_dump(ops, args, dry_run)


def cmd_regex(args):
    run_common(build_ops_regex(args), args)


def cmd_ascii(args):
    run_common(build_ops_ascii(args), args)


def cmd_from_file(args):
    try:
        with open(args.dumpfile, encoding="utf-8") as fh:
            data = json.load(fh)
    except OSError as exc:
        raise RnrError(str(exc))
    ops = [(op["source"], op["target"]) for op in data.get("operations", [])]
    if args.undo:
        ops = [(target, source) for source, target in reversed(ops)]
    run_common(ops, args)


def add_common_flags(parser):
    parser.add_argument("-n", "--dry-run", action="store_true", help="Only show what would be done (default mode)")
    parser.add_argument("-f", "--force", action="store_true", help="Make actual changes to files")
    parser.add_argument("-b", "--backup", action="store_true", help="Generate file backups before renaming")
    parser.add_argument("-s", "--silent", action="store_true", help="Do not print any information")
    parser.add_argument("--color", choices=["always", "never", "auto"], default="auto", help="Set color output mode")
    parser.add_argument("--dump", action="store_true", help="Force dumping operations into a file even in dry-run mode")
    parser.add_argument("--dump-prefix", default="rnr-", help="Set the dump file prefix")
    parser.add_argument("--no-dump", action="store_true", help="Do not dump operations into a file")


def main(argv=None):
    parser = argparse.ArgumentParser(prog="executable", description="RnR is a command-line tool to rename multiple files and directories that supports regular expressions")
    parser.add_argument("-V", "--version", action="store_true", help="Print version")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("regex", description="Rename files and directories using a regular expression")
    add_common_flags(p)
    p.add_argument("-l", "--replace-limit", type=int, metavar="LIMIT")
    p.add_argument("-t", "--replace-transform", choices=["upper", "lower", "ascii"])
    p.add_argument("-D", "--include-dirs", action="store_true")
    p.add_argument("-r", "--recursive", action="store_true")
    p.add_argument("-d", "--max-depth", type=int, metavar="LEVEL")
    p.add_argument("-x", "--hidden", action="store_true")
    p.add_argument("expression")
    p.add_argument("replacement")
    p.add_argument("paths", nargs="+")
    p.set_defaults(func=cmd_regex)

    p = sub.add_parser("from-file", description="Read operations from a dump file")
    add_common_flags(p)
    p.add_argument("-u", "--undo", action="store_true")
    p.add_argument("dumpfile")
    p.set_defaults(func=cmd_from_file)

    p = sub.add_parser("to-ascii", description="Replace file name UTF-8 chars with ASCII chars representation")
    add_common_flags(p)
    p.add_argument("-D", "--include-dirs", action="store_true")
    p.add_argument("-r", "--recursive", action="store_true")
    p.add_argument("-d", "--max-depth", type=int, metavar="LEVEL")
    p.add_argument("-x", "--hidden", action="store_true")
    p.add_argument("paths", nargs="+")
    p.set_defaults(func=cmd_ascii)

    args = parser.parse_args(argv)
    if args.version:
        print(VERSION)
        return 0
    if not hasattr(args, "func"):
        parser.print_help()
        return 0
    try:
        args.func(args)
        return 0
    except RnrError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
