#!/usr/bin/env python3
import html
import json
import os
import re
import socketserver
import sys
from http.server import SimpleHTTPRequestHandler
from pathlib import Path

VERSION = "oranda 0.6.5"

ROOT_HELP_LONG = """🎁 generate beautiful landing pages for your projects

Usage: executable [OPTIONS] <COMMAND>

Commands:
  build     Build an oranda site
  dev       Start a local development server that recompiles your oranda site if a file changes
  serve     Start a file server to access your oranda site in a browser
  generate  Generate infrastructure files for oranda sites
  help      Print this message or the help of the given subcommand(s)

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output"""

ROOT_HELP_SHORT = """🎁 generate beautiful landing pages for your projects

Usage: executable [OPTIONS] <COMMAND>

Commands:
  build     Build an oranda site
  dev       Start a local development server that recompiles your oranda site if a file changes
  serve     Start a file server to access your oranda site in a browser
  generate  Generate infrastructure files for oranda sites
  help      Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]"""

BUILD_HELP = """Build an oranda site

Usage: executable build [OPTIONS]

Options:
      --json-only
          Only build the artifacts JSON file (if applicable) and other files that may be used to
          support it, such as installer source files

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output"""

DEV_HELP = """Start a local development server that recompiles your oranda site if a file changes

Usage: executable dev [OPTIONS]

Options:
      --port <PORT>
          The port for the file server to be launched on

      --no-first-build
          Skip the first build before starting to watch for changes

  -i, --include-paths <INCLUDE_PATHS>
          List of extra paths to watch

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output"""

SERVE_HELP = """Start a file server to access your oranda site in a browser

Usage: executable serve [OPTIONS]

Options:
      --port <PORT>
          [default: 7979]

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output"""

GENERATE_HELP = """Generate infrastructure files for oranda sites

Usage: executable generate [OPTIONS] <COMMAND>

Commands:
  ci    Generates a CI file that can be used to deploy your site
  help  Print this message or the help of the given subcommand(s)

Options:
  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output"""

GENERATE_CI_HELP = """Generates a CI file that can be used to deploy your site

Usage: executable generate ci [OPTIONS]

Options:
      --ci <CI>
          What CI to generate a file for
          
          [default: github]

          Possible values:
          - github: Deploy to GitHub Pages using GitHub Actions

  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output"""


def print_err(msg):
    print(msg, file=sys.stderr)


def clap_error(message, usage):
    print_err(f"error: {message}\n\n{usage}\n\nFor more information, try '--help'.")
    return 2


def parse_globals(argv):
    output = "human"
    verbose = False
    rest = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "-v" or arg == "--verbose":
            verbose = True
        elif arg == "--output-format":
            if i + 1 >= len(argv):
                return None, None, None, clap_error("a value is required for '--output-format <OUTPUT_FORMAT>'", "Usage: executable [OPTIONS] <COMMAND>")
            output = argv[i + 1]
            i += 1
            if output not in ("human", "json"):
                print_err(f"error: invalid value '{output}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]\n\nFor more information, try '--help'.")
                return None, None, None, 2
        else:
            rest.extend(argv[i:])
            break
        i += 1
    return output, verbose, rest, None


def strip_late_globals(args, output, verbose):
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-v", "--verbose"):
            verbose = True
        elif a == "--output-format":
            i += 1
            if i >= len(args):
                return None, None, None, clap_error("a value is required for '--output-format <OUTPUT_FORMAT>'", "Usage: executable [OPTIONS] <COMMAND>")
            output = args[i]
            if output not in ("human", "json"):
                print_err(f"error: invalid value '{output}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]\n\nFor more information, try '--help'.")
                return None, None, None, 2
        else:
            rest.append(a)
        i += 1
    return output, verbose, rest, None


def info(msg):
    print(f"↪ >o_o< INFO: {msg}")


def load_config():
    for name in ("oranda.json", "oranda.json5"):
        p = Path(name)
        if p.exists():
            try:
                text = p.read_text()
                if name.endswith(".json"):
                    return json.loads(text)
            except Exception:
                return {}
    return {}


def read_project_metadata():
    cfg = load_config()
    name = cfg.get("project", {}).get("name") if isinstance(cfg.get("project"), dict) else cfg.get("name")
    desc = cfg.get("project", {}).get("description") if isinstance(cfg.get("project"), dict) else cfg.get("description")
    version = None
    cargo = Path("Cargo.toml")
    if cargo.exists():
        in_package = False
        for line in cargo.read_text(errors="ignore").splitlines():
            stripped = line.strip()
            if stripped == "[package]":
                in_package = True
                continue
            if stripped.startswith("[") and stripped != "[package]":
                in_package = False
            if in_package and "=" in stripped:
                k, v = stripped.split("=", 1)
                val = v.strip().strip('"').strip("'")
                if k.strip() == "name" and not name:
                    name = val
                elif k.strip() == "description" and not desc:
                    desc = val
                elif k.strip() == "version":
                    version = val
    pkg = Path("package.json")
    if pkg.exists():
        try:
            data = json.loads(pkg.read_text())
            name = name or data.get("name")
            desc = desc or data.get("description")
            version = version or data.get("version")
        except Exception:
            pass
    readme = None
    for candidate in ("README.md", "Readme.md", "readme.md"):
        if Path(candidate).exists():
            readme = Path(candidate).read_text(errors="ignore")
            break
    if not name and readme:
        m = re.search(r"^#\s+(.+?)\s*$", readme, re.M)
        if m:
            name = re.sub(r"[#`*_]", "", m.group(1)).strip()
    return name or Path.cwd().name, desc or "Generated by oranda", version, readme or ""


def md_to_html(text):
    out = []
    in_code = False
    para = []

    def flush_para():
        if para:
            out.append("<p>" + inline_md(" ".join(para)) + "</p>")
            para.clear()

    for raw in text.splitlines():
        line = raw.rstrip()
        if line.startswith("```"):
            flush_para()
            if in_code:
                out.append("</code></pre>")
            else:
                out.append("<pre><code>")
            in_code = not in_code
            continue
        if in_code:
            out.append(html.escape(line) + "\n")
            continue
        if not line.strip():
            flush_para()
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            flush_para()
            level = len(m.group(1))
            out.append(f"<h{level}>{inline_md(m.group(2))}</h{level}>")
        elif re.match(r"^\s*[-*]\s+", line):
            flush_para()
            item = re.sub(r"^\s*[-*]\s+", "", line)
            out.append(f"<ul><li>{inline_md(item)}</li></ul>")
        else:
            para.append(line.strip())
    flush_para()
    if in_code:
        out.append("</code></pre>")
    return "\n".join(out)


def inline_md(s):
    s = html.escape(s)
    s = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"`(.+?)`", r"<code>\1</code>", s)
    s = re.sub(r"\[(.+?)\]\((.+?)\)", r'<a href="\2">\1</a>', s)
    return s


def build(json_only=False, output_format="human", verbose=False):
    if verbose:
        print("↪ >o_o< DEBUG: No config found, using default values")
    name, desc, version, readme = read_project_metadata()
    public = Path("public")
    public.mkdir(exist_ok=True)
    artifacts = {
        "schema_version": "0.1.0",
        "project": {"name": name, "version": version, "description": desc},
        "artifacts": [],
    }
    (public / "artifacts.json").write_text(json.dumps(artifacts, indent=2) + "\n")
    if not json_only:
        body = md_to_html(readme) if readme else f"<h1>{html.escape(name)}</h1>\n<p>{html.escape(desc)}</p>"
        page = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(name)}</title>
  <meta name="description" content="{html.escape(desc)}">
  <style>body{{font-family:system-ui,-apple-system,Segoe UI,sans-serif;max-width:920px;margin:3rem auto;padding:0 1.25rem;line-height:1.6;color:#222}}pre{{background:#f5f5f5;padding:1rem;overflow:auto}}a{{color:#0969da}}</style>
</head>
<body>
{body}
</body>
</html>
"""
        (public / "index.html").write_text(page)
        fav = public / "favicon.ico"
        if not fav.exists():
            fav.write_bytes(b"\0")
    if output_format == "json":
        print(json.dumps({"success": True, "output_dir": "public"}))
    else:
        info("site build complete")
    return 0


def ci_text(site_path="."):
    site_arg = "" if site_path in ("", ".") else f" --site-path {site_path}"
    return f"""name: Deploy oranda site to GitHub Pages

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: false

jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{{{ steps.deployment.outputs.page_url }}}}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Install oranda
        run: curl --proto '=https' --tlsv1.2 -LsSf https://github.com/axodotdev/oranda/releases/latest/download/oranda-installer.sh | sh
      - name: Build
        run: oranda build{site_arg}
      - name: Setup Pages
        uses: actions/configure-pages@v5
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: public
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
"""


def generate_ci(args, output_format):
    output_path = None
    site_path = "."
    ci = "github"
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(GENERATE_CI_HELP)
            return 0
        if a in ("-o", "--output-path"):
            i += 1
            if i >= len(args):
                return clap_error("a value is required for '--output-path <OUTPUT_PATH>'", "Usage: executable generate ci [OPTIONS]")
            output_path = args[i]
        elif a in ("-s", "--site-path"):
            i += 1
            if i >= len(args):
                return clap_error("a value is required for '--site-path <SITE_PATH>'", "Usage: executable generate ci [OPTIONS]")
            site_path = args[i]
        elif a == "--ci":
            i += 1
            if i >= len(args):
                return clap_error("a value is required for '--ci <CI>'", "Usage: executable generate ci [OPTIONS]")
            ci = args[i]
        else:
            return clap_error(f"unexpected argument '{a}' found", "Usage: executable generate ci [OPTIONS]")
        i += 1
    if ci != "github":
        print_err(f"error: invalid value '{ci}' for '--ci <CI>'\n  [possible values: github]\n\nFor more information, try '--help'.")
        return 2
    info("Generating a CI deploy workflow for your site...")
    path = Path(output_path) if output_path else Path(".github/workflows/web.yml")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(ci_text(site_path))
    if output_format == "json":
        print(json.dumps({"success": True, "path": str(path)}))
    else:
        info(f"wrote {path}")
    return 0


def serve(args, do_build=False):
    port = 7979
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(DEV_HELP if do_build else SERVE_HELP)
            return 0
        if a == "--port":
            i += 1
            if i >= len(args):
                return clap_error("a value is required for '--port <PORT>'", f"Usage: executable {'dev' if do_build else 'serve'} [OPTIONS]")
            port = int(args[i])
        elif do_build and a == "--no-first-build":
            do_build = False
        elif do_build and a in ("-i", "--include-paths"):
            i += 1
        else:
            return clap_error(f"unexpected argument '{a}' found", f"Usage: executable {'dev' if do_build else 'serve'} [OPTIONS]")
        i += 1
    if do_build:
        build()
    root = Path("public") if Path("public").is_dir() else Path(".")
    os.chdir(root)
    info(f"Serving {root} at http://127.0.0.1:{port}")
    with socketserver.TCPServer(("", port), SimpleHTTPRequestHandler) as httpd:
        httpd.serve_forever()
    return 0


def main(argv):
    output, verbose, rest, err = parse_globals(argv)
    if err is not None:
        return err
    if not rest:
        print(ROOT_HELP_SHORT)
        return 2
    cmd = rest[0]
    args = rest[1:]
    if cmd in ("-h", "--help"):
        print(ROOT_HELP_LONG if cmd == "--help" else ROOT_HELP_SHORT)
        return 0
    if cmd in ("-V", "--version"):
        print(VERSION)
        return 0
    if cmd == "help":
        if not args:
            print(ROOT_HELP_LONG)
            return 0
        if args == ["build"]:
            print(BUILD_HELP)
            return 0
        if args == ["dev"]:
            print(DEV_HELP)
            return 0
        if args == ["serve"]:
            print(SERVE_HELP)
            return 0
        if args == ["generate"]:
            print(GENERATE_HELP)
            return 0
        if args == ["generate", "ci"]:
            print(GENERATE_CI_HELP)
            return 0
        return clap_error(f"unrecognized subcommand '{args[0]}'", "Usage: executable [OPTIONS] <COMMAND>")
    if cmd == "build":
        output, verbose, args, err = strip_late_globals(args, output, verbose)
        if err is not None:
            return err
        if any(a in ("-h", "--help") for a in args):
            print(BUILD_HELP)
            return 0
        json_only = False
        for a in args:
            if a == "--json-only":
                json_only = True
            else:
                return clap_error(f"unexpected argument '{a}' found", "Usage: executable build [OPTIONS]")
        return build(json_only, output, verbose)
    if cmd == "dev":
        output, verbose, args, err = strip_late_globals(args, output, verbose)
        if err is not None:
            return err
        return serve(args, True)
    if cmd == "serve":
        output, verbose, args, err = strip_late_globals(args, output, verbose)
        if err is not None:
            return err
        return serve(args, False)
    if cmd == "generate":
        output, verbose, args, err = strip_late_globals(args, output, verbose)
        if err is not None:
            return err
        if not args or args[0] in ("-h", "--help"):
            print(GENERATE_HELP)
            return 0 if args else 2
        if args[0] == "help":
            if len(args) == 1:
                print(GENERATE_HELP)
                return 0
            if args[1] == "ci":
                print(GENERATE_CI_HELP)
                return 0
        # Accept parent options either before or after the subcommand.
        parent = []
        sub_index = None
        for idx, a in enumerate(args):
            if a == "ci":
                sub_index = idx
                break
            parent.append(a)
        if sub_index is None:
            return clap_error(f"unrecognized subcommand '{args[0]}'", "Usage: executable generate [OPTIONS] <COMMAND>")
        return generate_ci(parent + args[sub_index + 1:], output)
    return clap_error(f"unrecognized subcommand '{cmd}'", "Usage: executable [OPTIONS] <COMMAND>")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
