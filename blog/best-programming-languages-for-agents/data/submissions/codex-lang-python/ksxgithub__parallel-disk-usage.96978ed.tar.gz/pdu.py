#!/usr/bin/env python3
import json
import math
import os
import stat
import sys

VERSION = "0.21.1"


class UsageError(Exception):
    pass


def print_help(long=False):
    if long:
        text = """Summarize disk usage of the set of files, recursively for directories.

Copyright: Apache-2.0 (C) 2021 Hoang Van Khai <https://github.com/KSXGitHub/>
Sponsor: https://github.com/sponsors/KSXGitHub

Usage: executable [OPTIONS] [FILES]...

Arguments:
  [FILES]...
          List of files and/or directories

Options:
      --json-input
          Read JSON data from stdin

      --json-output
          Print JSON data instead of an ASCII chart

  -b, --bytes-format <BYTES_FORMAT>
          How to display the numbers of bytes

          Possible values:
          - plain:  Display plain number of bytes without units
          - metric: Use metric scale, i.e. 1K = 1000B, 1M = 1000K, and so on
          - binary: Use binary scale, i.e. 1K = 1024B, 1M = 1024K, and so on

          [default: metric]

  -H, --deduplicate-hardlinks
          Detect and subtract the sizes of hardlinks from their parent directory totals

      --top-down
          Print the tree top-down instead of bottom-up

      --align-right
          Set the root of the bars to the right

  -q, --quantity <QUANTITY>
          Aspect of the files/directories to be measured

          Possible values:
          - apparent-size: Measure apparent sizes
          - block-size:    Measure block sizes (block-count * 512B)
          - block-count:   Count numbers of blocks

          [default: block-size]

  -d, --max-depth <MAX_DEPTH>
          Maximum depth to display the data. Could be either "inf" or a positive integer

          [default: 10]

  -w, --total-width <TOTAL_WIDTH>
          Width of the visualization

      --column-width <TREE_WIDTH> <BAR_WIDTH>
          Maximum widths of the tree column and width of the bar column

  -m, --min-ratio <MIN_RATIO>
          Minimal size proportion required to appear

          [default: 0.01]

      --no-sort
          Do not sort the branches in the tree

  -s, --silent-errors
          Prevent filesystem error messages from appearing in stderr

  -p, --progress
          Report progress being made at the expense of performance

      --threads <THREADS>
          Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer

          [default: auto]

      --omit-json-shared-details
          Do not output `.shared.details` in the JSON output

      --omit-json-shared-summary
          Do not output `.shared.summary` in the JSON output

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""
    else:
        text = """Summarize disk usage of the set of files, recursively for directories.

Usage: executable [OPTIONS] [FILES]...

Arguments:
  [FILES]...  List of files and/or directories

Options:
      --json-input
          Read JSON data from stdin
      --json-output
          Print JSON data instead of an ASCII chart
  -b, --bytes-format <BYTES_FORMAT>
          How to display the numbers of bytes [default: metric] [possible values: plain, metric, binary]
  -H, --deduplicate-hardlinks
          Detect and subtract the sizes of hardlinks from their parent directory totals [aliases: --detect-links, --dedupe-links]
      --top-down
          Print the tree top-down instead of bottom-up
      --align-right
          Set the root of the bars to the right
  -q, --quantity <QUANTITY>
          Aspect of the files/directories to be measured [default: block-size] [possible values: apparent-size, block-size, block-count]
  -d, --max-depth <MAX_DEPTH>
          Maximum depth to display the data. Could be either "inf" or a positive integer [default: 10] [aliases: --depth]
  -w, --total-width <TOTAL_WIDTH>
          Width of the visualization [aliases: --width]
      --column-width <TREE_WIDTH> <BAR_WIDTH>
          Maximum widths of the tree column and width of the bar column
  -m, --min-ratio <MIN_RATIO>
          Minimal size proportion required to appear [default: 0.01]
      --no-sort
          Do not sort the branches in the tree
  -s, --silent-errors
          Prevent filesystem error messages from appearing in stderr [aliases: --no-errors]
  -p, --progress
          Report progress being made at the expense of performance
      --threads <THREADS>
          Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer [default: auto]
      --omit-json-shared-details
          Do not output `.shared.details` in the JSON output
      --omit-json-shared-summary
          Do not output `.shared.summary` in the JSON output
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""
    print(text.rstrip())


def default_opts():
    return {
        "json_input": False,
        "json_output": False,
        "bytes_format": "metric",
        "dedupe": False,
        "top_down": False,
        "align_right": False,
        "quantity": "block-size",
        "max_depth": 10,
        "total_width": None,
        "column_width": None,
        "min_ratio": 0.01,
        "sort": True,
        "silent_errors": False,
        "omit_details": False,
        "omit_summary": False,
        "files": [],
    }


def need_value(args, i, opt):
    if i + 1 >= len(args):
        raise UsageError(f"error: a value is required for '{opt} <{opt_name(opt)}>' but none was supplied")
    return args[i + 1]


def opt_name(opt):
    return opt.strip("-").replace("-", "_").upper()


def parse_positive_int(value, opt):
    try:
        n = int(value)
    except Exception:
        raise UsageError(f"error: invalid value '{value}' for '{opt}': invalid digit found in string")
    if n <= 0:
        what = "MAX_DEPTH" if "depth" in opt else "THREADS"
        raise UsageError(f"error: invalid value '{value}' for '{opt} <{what}>': Value is neither \"inf\" nor a positive integer: number would be zero for non-zero type")
    return n


def parse_args(argv):
    opts = default_opts()
    i = 0
    end = False
    while i < len(argv):
        a = argv[i]
        if end or not a.startswith("-") or a == "-":
            opts["files"].append(a)
            i += 1
            continue
        if a == "--":
            end = True
            i += 1
            continue
        if a in ("-h", "--help"):
            print_help(long=(a == "--help"))
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(f"pdu {VERSION}")
            raise SystemExit(0)
        if "=" in a and a.startswith("--"):
            a, val = a.split("=", 1)
            has_inline = True
        else:
            val = None
            has_inline = False
        if a == "--json-input":
            opts["json_input"] = True
        elif a == "--json-output":
            opts["json_output"] = True
        elif a in ("-H", "--deduplicate-hardlinks", "--detect-links", "--dedupe-links"):
            opts["dedupe"] = True
        elif a == "--top-down":
            opts["top_down"] = True
        elif a == "--align-right":
            opts["align_right"] = True
        elif a in ("--no-sort",):
            opts["sort"] = False
        elif a in ("-s", "--silent-errors", "--no-errors"):
            opts["silent_errors"] = True
        elif a in ("-p", "--progress"):
            pass
        elif a in ("--omit-json-shared-details",):
            opts["omit_details"] = True
        elif a in ("--omit-json-shared-summary",):
            opts["omit_summary"] = True
        elif a in ("-b", "--bytes-format"):
            if not has_inline:
                val = need_value(argv, i, a)
                i += 1
            if val not in ("plain", "metric", "binary"):
                raise UsageError(f"error: invalid value '{val}' for '--bytes-format <BYTES_FORMAT>'")
            opts["bytes_format"] = val
        elif a in ("-q", "--quantity"):
            if not has_inline:
                val = need_value(argv, i, a)
                i += 1
            if val not in ("apparent-size", "block-size", "block-count"):
                raise UsageError(f"error: invalid value '{val}' for '--quantity <QUANTITY>'")
            opts["quantity"] = val
        elif a in ("-d", "--max-depth", "--depth"):
            if not has_inline:
                val = need_value(argv, i, a)
                i += 1
            opts["max_depth"] = math.inf if val == "inf" else parse_positive_int(val, "--max-depth")
        elif a in ("-w", "--total-width", "--width"):
            if not has_inline:
                val = need_value(argv, i, a)
                i += 1
            opts["total_width"] = parse_positive_int(val, "--total-width")
        elif a == "--column-width":
            if has_inline:
                first = val
            else:
                first = need_value(argv, i, a)
                i += 1
            second = need_value(argv, i, a)
            i += 1
            opts["column_width"] = (parse_positive_int(first, "--column-width"), parse_positive_int(second, "--column-width"))
        elif a in ("-m", "--min-ratio"):
            if not has_inline:
                val = need_value(argv, i, a)
                i += 1
            try:
                opts["min_ratio"] = float(val)
            except Exception:
                raise UsageError(f"error: invalid value '{val}' for '--min-ratio <MIN_RATIO>': invalid float literal")
        elif a == "--threads":
            if not has_inline:
                val = need_value(argv, i, a)
                i += 1
            if val not in ("auto", "max"):
                parse_positive_int(val, "--threads")
        else:
            raise UsageError(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'")
        i += 1
    if not opts["files"]:
        opts["files"] = ["."]
    return opts


class Node:
    __slots__ = ("name", "size", "children", "dev", "ino", "nlink", "is_file", "path")

    def __init__(self, name, size=0, children=None, dev=None, ino=None, nlink=1, is_file=False, path=None):
        self.name = name
        self.size = size
        self.children = children if children is not None else []
        self.dev = dev
        self.ino = ino
        self.nlink = nlink
        self.is_file = is_file
        self.path = path if path is not None else name

    def to_json(self):
        return {"name": self.name, "size": self.size, "children": [c.to_json() for c in self.children]}

    @staticmethod
    def from_json(obj):
        return Node(obj.get("name", ""), int(obj.get("size", 0)), [Node.from_json(x) for x in obj.get("children", [])])


def measure(st, quantity):
    if quantity == "apparent-size":
        return int(st.st_size)
    if quantity == "block-count":
        return int(getattr(st, "st_blocks", 0))
    return int(getattr(st, "st_blocks", 0)) * 512


def err_path(path):
    return json.dumps(path, ensure_ascii=False)


def scan(path, opts, seen_links):
    try:
        st = os.lstat(path)
    except OSError as e:
        if not opts["silent_errors"]:
            print(f'[error] metadata {err_path(path)}: {e.strerror} (os error {e.errno})', file=sys.stderr)
        return None
    name = path.rstrip("/") or path
    base_size = measure(st, opts["quantity"])
    is_dir = stat.S_ISDIR(st.st_mode)
    is_file = stat.S_ISREG(st.st_mode)
    node = Node(os.path.basename(name) if os.path.dirname(name) else name, base_size, [], st.st_dev, st.st_ino, st.st_nlink, is_file, path)
    if is_dir:
        try:
            entries = list(os.scandir(path))
        except OSError as e:
            if not opts["silent_errors"]:
                print(f'[error] read_dir {err_path(path)}: {e.strerror} (os error {e.errno})', file=sys.stderr)
            node.size = 0
            return node
        total = base_size
        for ent in entries:
            child_path = os.path.join(path, ent.name)
            child = scan(child_path, opts, seen_links)
            if child is not None:
                node.children.append(child)
                total += child.size
        node.size = total
    if opts["dedupe"] and node.nlink > 1 and not is_dir:
        key = (node.dev, node.ino)
        seen_links.setdefault(key, []).append(node)
    return node


def recompute_sizes(node):
    if node.children:
        node.size = node.size + sum(recompute_sizes(c) for c in node.children)
    return node.size


def walk_nodes(node):
    yield node
    for c in node.children:
        yield from walk_nodes(c)


def sort_tree(node, enabled=True):
    for c in node.children:
        sort_tree(c, enabled)
    if enabled:
        node.children.sort(key=lambda n: n.size, reverse=True)


def make_tree(files, opts):
    seen = {}
    nodes = []
    for p in files:
        n = scan(p, opts, seen)
        if n is not None:
            if len(files) > 1:
                n.name = p.rstrip("/") or p
            nodes.append(n)
    if len(nodes) == 1:
        root = nodes[0]
    else:
        root = Node("(total)", sum(n.size for n in nodes), nodes)
    if opts["dedupe"]:
        apply_hardlink_dedupe(root, set())
    sort_tree(root, opts["sort"])
    shared = build_shared(seen, opts) if opts["dedupe"] else None
    return root, shared


def apply_hardlink_dedupe(node, seen):
    subtract = 0
    for c in node.children:
        subtract += apply_hardlink_dedupe(c, seen)
    if node.nlink > 1 and node.ino is not None and not node.children:
        key = (node.dev, node.ino)
        if key in seen:
            subtract += node.size
        else:
            seen.add(key)
    if node.children:
        node.size -= subtract
    return subtract


def build_shared(seen, opts):
    details = []
    for (_dev, ino), nodes in seen.items():
        if len(nodes) >= 2:
            paths = [path_of_node(n) for n in nodes]
            # First seen keeps its size; duplicates have already been zeroed.
            size = max([n.size for n in nodes] + [0])
            if size == 0:
                size = 0
            details.append({"ino": ino, "size": size, "links": len(nodes), "paths": paths})
    summary = {
        "inodes": len(details),
        "exclusive_inodes": len(details),
        "all_links": sum(d["links"] for d in details),
        "detected_links": sum(d["links"] for d in details),
        "exclusive_links": sum(d["links"] for d in details),
        "shared_size": sum(d["size"] for d in details),
        "exclusive_shared_size": sum(d["size"] for d in details),
    }
    out = {}
    if not opts["omit_details"]:
        out["details"] = details
    if not opts["omit_summary"]:
        out["summary"] = summary
    return out if out else None


def path_of_node(n):
    return n.path


def json_output(root, shared, opts):
    unit = "blocks" if opts["quantity"] == "block-count" else "bytes"
    obj = {"schema-version": "2024-11-02", "pdu": VERSION, "unit": unit, "tree": root.to_json()}
    if shared:
        obj["shared"] = shared
    print(json.dumps(obj, separators=(",", ":")))


def human(n, fmt):
    if fmt == "plain":
        return str(int(n))
    base = 1024 if fmt == "binary" else 1000
    units = ["", "K", "M", "G", "T", "P", "E"]
    x = float(n)
    u = 0
    while abs(x) >= base and u < len(units) - 1:
        x /= base
        u += 1
    if u == 0:
        return str(int(n))
    return f"{x:.1f}{units[u]}"


def filtered_children(node, root_size, opts, depth):
    out = []
    if depth >= opts["max_depth"]:
        return out
    for c in node.children:
        ratio = c.size / root_size if root_size else 0
        if opts["min_ratio"] <= 0 or ratio >= opts["min_ratio"] or c.size == 0 and opts["min_ratio"] <= 0:
            out.append(c)
    return out


def collect_lines(node, root_size, opts, depth=0, prefix="", is_last=True, lines=None):
    if lines is None:
        lines = []
    children = filtered_children(node, root_size, opts, depth)
    if opts["top_down"]:
        connector = "└─" if is_last else "├─"
        branch = connector + ("┬" if children else "─")
        lines.append((node, prefix + branch + node.name, depth))
        next_prefix = prefix + ("  " if is_last else "│ ")
        for i, c in enumerate(children):
            collect_lines(c, root_size, opts, depth + 1, next_prefix, i == len(children) - 1, lines)
    else:
        next_prefix = prefix + ("  " if is_last else "│ ")
        for i, c in enumerate(reversed(children)):
            collect_lines(c, root_size, opts, depth + 1, next_prefix, i == 0, lines)
        connector = "┌─" if is_last else "├─"
        branch = connector + ("┴" if children else "─")
        lines.append((node, prefix + branch + node.name, depth))
    return lines


def render_chart(root, opts):
    root_size = root.size
    lines = collect_lines(root, root_size, opts)
    vals = [human(n.size, opts["bytes_format"]) for n, _t, _d in lines]
    valw = max([len(v) for v in vals] + [1])
    treew = max([len(t) for _n, t, _d in lines] + [1])
    barw = 80
    if opts["column_width"]:
        treew = min(treew, opts["column_width"][0])
        barw = opts["column_width"][1]
    elif opts["total_width"]:
        barw = max(1, opts["total_width"] - valw - treew - 10)
    else:
        barw = max(20, 127 - valw - treew - 7)
    for (node, tree, _depth), val in zip(lines, vals):
        ratio = node.size / root_size if root_size else 0
        fill = int(round(ratio * barw))
        bar = "█" * max(0, min(barw, fill))
        bar += " " * (barw - len(bar))
        pct = int(round(ratio * 100))
        print(f"{val:>{valw}} {tree:<{treew}}│{bar}│{pct:>3}%")


def main(argv):
    try:
        opts = parse_args(argv)
    except UsageError as e:
        print(str(e), file=sys.stderr)
        print("\nUsage: executable [OPTIONS] [FILES]...\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    if opts["json_input"]:
        try:
            data = json.load(sys.stdin)
            root = Node.from_json(data["tree"] if "tree" in data else data)
        except Exception as e:
            print(f"error: failed to parse JSON input: {e}", file=sys.stderr)
            return 1
        render_chart(root, opts)
        return 0
    root, shared = make_tree(opts["files"], opts)
    if opts["json_output"]:
        json_output(root, shared, opts)
    else:
        render_chart(root, opts)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
