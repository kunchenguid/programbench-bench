#!/usr/bin/env python3
import os
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path


VERSION = "gittype 0.8.0"

SUPPORTED = {
    "rust", "rs", "typescript", "ts", "javascript", "js", "python", "py",
    "ruby", "rb", "go", "swift", "kotlin", "kt", "java", "php", "csharp",
    "cs", "c#", "c", "cpp", "c++", "haskell", "hs", "dart", "scala", "sc",
    "zig", "clojure", "clj", "cljs",
}

COMMANDS = {"history", "stats", "export", "cache", "repo", "trending", "help"}


LONG_HELP = """GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. 

Examples:
  gittype                           # Use current directory
  gittype /path/to/repo             # Use specific repository
  gittype --repo owner/repo         # Clone and use GitHub repository
  gittype --langs rust,python       # Filter by languages

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]
          Repository path to extract code from

Options:
      --repo <REPO>
          GitHub repository URL or path to clone and play with. Supports formats:
            - owner/repo
            - https://github.com/owner/repo
            - git@github.com:owner/repo.git

      --langs <LANGS>
          Filter by programming languages (comma-separated). Supported languages:
            rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig
            Example: --langs rust,python,typescript

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version"""

SHORT_HELP = """A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]  Repository path to extract code from

Options:
      --repo <REPO>    GitHub repository URL or path to clone and play with
      --langs <LANGS>  Filter by programming languages (comma-separated)
  -h, --help           Print help (see more with '--help')
  -V, --version        Print version"""

CACHE_HELP = """Manage challenge cache

Usage: executable cache <COMMAND>

Commands:
  stats  Show cache statistics
  clear  Clear all cached challenges
  list   List cached repository keys
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help"""

REPO_HELP = """Manage repositories

Usage: executable repo <COMMAND>

Commands:
  list   List all cached repositories
  clear  Clear all cached repositories
  play   Play a cached repository interactively
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help"""

TRENDING_HELP = """Select and practice with trending repositories from GitHub

Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]

Arguments:
  [LANGUAGE]
          Programming language to filter trending repositories.
          Supported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig

  [REPO_NAME]
          Specific repository name to select from trending list

Options:
      --period <PERIOD>
          Time period for trending (daily, weekly, monthly)
          
          [default: daily]

  -h, --help
          Print help (see a summary with '-h')"""

EXPORT_HELP = """Export session data

Usage: executable export [OPTIONS]

Options:
      --format <FORMAT>  Export format [default: json]
      --output <OUTPUT>  Output file path
  -h, --help             Print help"""

HELP_TEXTS = {
    "history": "Show session history\n\nUsage: executable history\n\nOptions:\n  -h, --help  Print help",
    "stats": "Show analytics\n\nUsage: executable stats\n\nOptions:\n  -h, --help  Print help",
    "export": EXPORT_HELP,
    "cache": CACHE_HELP,
    "repo": REPO_HELP,
    "trending": TRENDING_HELP,
    "cache stats": "Show cache statistics\n\nUsage: executable cache stats\n\nOptions:\n  -h, --help  Print help",
    "cache clear": "Clear all cached challenges\n\nUsage: executable cache clear\n\nOptions:\n  -h, --help  Print help",
    "cache list": "List cached repository keys\n\nUsage: executable cache list\n\nOptions:\n  -h, --help  Print help",
    "repo list": "List all cached repositories\n\nUsage: executable repo list\n\nOptions:\n  -h, --help  Print help",
    "repo clear": "Clear all cached repositories\n\nUsage: executable repo clear [OPTIONS]\n\nOptions:\n      --force  Force clear without confirmation\n  -h, --help   Print help",
    "repo play": "Play a cached repository interactively\n\nUsage: executable repo play\n\nOptions:\n  -h, --help  Print help",
}


def eprint(text=""):
    print(text, file=sys.stderr)


def home() -> Path:
    return Path.home()


def challenge_cache_dirs():
    return [
        home() / ".cache" / "gittype" / "challenges",
        home() / ".gittype" / "cache",
        home() / ".gittype" / "challenge-cache",
    ]


def repo_cache_dirs():
    return [
        home() / ".cache" / "gittype" / "repositories",
        home() / ".gittype" / "repositories",
        home() / ".gittype" / "repos",
    ]


def total_size(path: Path) -> int:
    if not path.exists():
        return 0
    if path.is_file():
        return path.stat().st_size
    return sum(p.stat().st_size for p in path.rglob("*") if p.is_file())


def log_terminal_error(message="Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)"):
    now = datetime.now(timezone.utc)
    stamp = now.strftime("%Y%m%d_%H%M%S")
    name = f"gittype_error_{stamp}.log"
    args = [sys.argv[0], *sys.argv[1:]]
    body = (
        f"ERROR OCCURRED AT: {now.strftime('%Y-%m-%d %H:%M:%S UTC')}\n"
        'ERROR TYPE: "gittype::domain::error::GitTypeError"\n'
        f"ERROR MESSAGE: {message}\n"
        f'EXECUTABLE: "{Path(sys.argv[0]).resolve()}"\n'
        f'WORKING_DIR: "{Path.cwd()}"\n'
        f"COMMAND_ARGS: {args!r}\n"
        "OS: linux\n"
        "ARCH: x86_64\n\n"
    )
    try:
        with open(name, "a", encoding="utf-8") as f:
            f.write(body)
        logs = home() / ".gittype" / "logs"
        logs.mkdir(parents=True, exist_ok=True)
        with open(logs / f"gittype_{stamp}.log", "a", encoding="utf-8") as f:
            f.write(body)
    except OSError:
        pass
    print(f"💾 Error details written to: {name}")
    print(f"Error: {message}")
    return 1


def unsupported_langs(value: str):
    bad = []
    for item in value.split(","):
        lang = item.strip().lower()
        if lang and lang not in SUPPORTED:
            bad.append(item.strip())
    return bad


def unsupported_lang_message(bad):
    print(f"❌ Unsupported language(s): {', '.join(bad)}")
    print("💡 Supported languages:")
    print("   rust, rs, typescript, ts, javascript, js")
    print("   python, py, ruby, rb, go, swift")
    print("   kotlin, kt, java, php, csharp, cs")
    print("   c#, c, cpp, c++, haskell, hs")
    print("   dart, scala, sc, zig, clojure, clj")
    print("   cljs")
    return 1


def option_value(args, idx, opt, usage=None):
    if idx + 1 >= len(args):
        eprint(f"error: a value is required for '{opt} <{opt.lstrip('-').upper()}>' but none was supplied")
        eprint()
        eprint("For more information, try '--help'.")
        raise SystemExit(2)
    return args[idx + 1]


def main_help(args):
    if "--help" in args:
        print(LONG_HELP)
        return 0
    if "-h" in args:
        print(SHORT_HELP)
        return 0
    return None


def cmd_history(args):
    if args in (["--help"], ["-h"]):
        print(HELP_TEXTS["history"])
        return 0
    if args:
        return unexpected(args[0], "history")
    print("❌ History command is not yet implemented")
    print("💡 This feature is planned for a future release")
    return 1


def cmd_stats(args):
    if args in (["--help"], ["-h"]):
        print(HELP_TEXTS["stats"])
        return 0
    if args:
        return unexpected(args[0], "stats")
    print("❌ Stats command is not yet implemented")
    print("💡 This feature is planned for a future release")
    return 1


def cmd_export(args):
    if args in (["--help"], ["-h"]):
        print(EXPORT_HELP)
        return 0
    fmt = "json"
    out = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--format":
            if i + 1 >= len(args):
                eprint("error: a value is required for '--format <FORMAT>' but none was supplied")
                eprint()
                eprint("For more information, try '--help'.")
                return 2
            fmt = args[i + 1]
            i += 2
        elif a == "--output":
            if i + 1 >= len(args):
                eprint("error: a value is required for '--output <OUTPUT>' but none was supplied")
                eprint()
                eprint("For more information, try '--help'.")
                return 2
            out = args[i + 1]
            i += 2
        elif a.startswith("-"):
            return unexpected(a, "export")
        else:
            return unexpected(a, "export")
    print("❌ Export command is not yet implemented")
    print(f"💡 Requested format: {fmt}")
    if out:
        print(f"💡 Requested output: {out}")
    print("💡 This feature is planned for a future release")
    return 1


def cmd_cache(args):
    if not args or args in (["--help"], ["-h"]):
        print(CACHE_HELP)
        return 0 if args else 2
    sub = args[0]
    rest = args[1:]
    key = f"cache {sub}"
    if sub == "help":
        if rest:
            target = "cache " + " ".join(rest)
            print(HELP_TEXTS.get(target, CACHE_HELP))
        else:
            print(CACHE_HELP)
        return 0
    if key in HELP_TEXTS and rest in (["--help"], ["-h"]):
        print(HELP_TEXTS[key])
        return 0
    if sub not in {"stats", "clear", "list"}:
        eprint(f"error: unrecognized subcommand '{sub}'")
        eprint()
        eprint("Usage: executable cache <COMMAND>")
        eprint()
        eprint("For more information, try '--help'.")
        return 2
    if rest:
        return unexpected(rest[0], f"cache {sub}")
    if sub == "stats":
        existing = [p for p in challenge_cache_dirs() if p.exists()]
        count = sum(1 for p in existing for c in (p.iterdir() if p.is_dir() else []))
        size = sum(total_size(p) for p in existing)
        print("Challenge Cache Statistics:")
        print(f"  Cached repositories: {count}")
        print(f"  Total size: {size} bytes")
        return 0
    if sub == "list":
        keys = []
        for d in challenge_cache_dirs():
            if d.is_dir():
                keys += sorted(p.name for p in d.iterdir())
        if not keys:
            print("No cached challenges found.")
        else:
            for k in keys:
                print(k)
        return 0
    for d in challenge_cache_dirs():
        if d.exists():
            shutil.rmtree(d, ignore_errors=True)
    print("Challenge cache cleared successfully.")
    return 0


def cmd_repo(args):
    if not args or args in (["--help"], ["-h"]):
        print(REPO_HELP)
        return 0 if args else 2
    sub = args[0]
    rest = args[1:]
    if sub == "help":
        if rest:
            target = "repo " + " ".join(rest)
            print(HELP_TEXTS.get(target, REPO_HELP))
        else:
            print(REPO_HELP)
        return 0
    key = f"repo {sub}"
    if key in HELP_TEXTS and rest in (["--help"], ["-h"]):
        print(HELP_TEXTS[key])
        return 0
    if sub not in {"list", "clear", "play"}:
        eprint(f"error: unrecognized subcommand '{sub}'")
        eprint()
        eprint("Usage: executable repo <COMMAND>")
        eprint()
        eprint("For more information, try '--help'.")
        return 2
    if sub == "clear":
        force_rest = [a for a in rest if a != "--force"]
        if force_rest:
            return unexpected(force_rest[0], "repo clear")
        found = [d for d in repo_cache_dirs() if d.exists()]
        if not found:
            print("No cached repositories directory found.")
        else:
            for d in found:
                shutil.rmtree(d, ignore_errors=True)
            print("Cached repositories cleared successfully.")
        return 0
    if rest:
        return unexpected(rest[0], f"repo {sub}")
    return log_terminal_error()


def cmd_trending(args):
    if args in (["--help"], ["-h"]):
        print(TRENDING_HELP)
        return 0
    pos = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--period":
            if i + 1 >= len(args):
                eprint("error: a value is required for '--period <PERIOD>' but none was supplied")
                eprint()
                eprint("For more information, try '--help'.")
                return 2
            i += 2
        elif a.startswith("-"):
            return unexpected(a, "trending")
        else:
            pos.append(a)
            i += 1
    if len(pos) >= 2 and not re.match(r"^[^/\s]+/[^/\s]+$", pos[1]):
        print("⚠️ Repository name must be in format 'owner/repo'")
        return 0
    return log_terminal_error()


def unexpected(arg, usage):
    if usage == "main":
        eprint(f"error: unexpected argument '{arg}' found")
        eprint()
        eprint(f"  tip: to pass '{arg}' as a value, use '-- {arg}'")
        eprint()
        eprint("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]")
    else:
        eprint(f"error: unexpected argument '{arg}' found")
        eprint()
        eprint(f"Usage: executable {usage} [OPTIONS]" if usage == "export" else f"Usage: executable {usage}")
    eprint()
    eprint("For more information, try '--help'.")
    return 2


def dispatch_help(args):
    if not args:
        print(LONG_HELP)
        return 0
    if args[0].startswith("-"):
        eprint(f"error: unrecognized subcommand '{args[0]}'")
        eprint()
        eprint("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]")
        eprint()
        eprint("For more information, try '--help'.")
        return 2
    target = " ".join(args)
    print(HELP_TEXTS.get(target, LONG_HELP))
    return 0


def parse_global(args):
    if args and args[0] in COMMANDS:
        return {
            "history": cmd_history,
            "stats": cmd_stats,
            "export": cmd_export,
            "cache": cmd_cache,
            "repo": cmd_repo,
            "trending": cmd_trending,
            "help": dispatch_help,
        }[args[0]](args[1:])

    if "-V" in args or "--version" in args:
        print(VERSION)
        return 0

    cleaned = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--repo":
            if i + 1 >= len(args):
                eprint("error: a value is required for '--repo <REPO>' but none was supplied")
                eprint()
                eprint("For more information, try '--help'.")
                return 2
            i += 2
        elif a == "--langs":
            if i + 1 >= len(args):
                eprint("error: a value is required for '--langs <LANGS>' but none was supplied")
                eprint()
                eprint("For more information, try '--help'.")
                return 2
            bad = unsupported_langs(args[i + 1])
            if bad:
                return unsupported_lang_message(bad)
            i += 2
        elif a.startswith("-"):
            cleaned.append(a)
            i += 1
        else:
            cleaned.append(a)
            i += 1

    if not cleaned or not any(c in COMMANDS for c in cleaned):
        help_result = main_help(cleaned)
        if help_result is not None:
            return help_result
        for a in cleaned:
            if a.startswith("-"):
                return unexpected(a, "main")
        return log_terminal_error()

    cmd_index = next(i for i, c in enumerate(cleaned) if c in COMMANDS)
    for a in cleaned[:cmd_index]:
        if a.startswith("-"):
            help_result = main_help([a])
            if help_result is not None:
                return help_result
            return unexpected(a, "main")
    cmd, rest = cleaned[cmd_index], cleaned[cmd_index + 1:]

    return {
        "history": cmd_history,
        "stats": cmd_stats,
        "export": cmd_export,
        "cache": cmd_cache,
        "repo": cmd_repo,
        "trending": cmd_trending,
        "help": dispatch_help,
    }[cmd](rest)


if __name__ == "__main__":
    try:
        raise SystemExit(parse_global(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
