#!/usr/bin/env python3
import argparse
import html
import http.server
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import quote

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib

VERSION = "mdbook v0.5.0-alpha.1"

ROOT_HELP = """Creates a book from markdown files

Usage: executable [COMMAND]

Commands:
  init         Creates the boilerplate structure and files for a new book
  build        Builds a book from its markdown files
  test         Tests that a book's Rust code samples compile
  clean        Deletes a built book
  completions  Generate shell completions for your shell to stdout
  watch        Watches a book's files and rebuilds it on changes
  serve        Serves a book at http://localhost:3000, and rebuilds it on changes
  help         Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version

For more information about a specific command, try `mdbook <command> --help`
The source code for mdBook is available at: https://github.com/rust-lang/mdBook
"""

HELP = {
    "init": """Creates the boilerplate structure and files for a new book

Usage: executable init [OPTIONS] [dir]

Arguments:
  [dir]  Directory to create the book in
         (Defaults to the current directory when omitted)

Options:
      --theme            Copies the default theme into your source folder
      --force            Skips confirmation prompts
      --title <title>    Sets the book title
      --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]
  -h, --help             Print help
  -V, --version          Print version
""",
    "build": """Builds a book from its markdown files

Usage: executable build [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -o, --open                 Opens the compiled book in a web browser
  -h, --help                 Print help
  -V, --version              Print version
""",
    "test": """Tests that a book's Rust code samples compile

Usage: executable test [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -c, --chapter <chapter>    
  -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path
                             when building tests
  -h, --help                 Print help
  -V, --version              Print version
""",
    "clean": """Deletes a built book

Usage: executable clean [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -h, --help                 Print help
  -V, --version              Print version
""",
    "completions": """Generate shell completions for your shell to stdout

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,
           zsh]

Options:
  -h, --help     Print help
  -V, --version  Print version
""",
    "watch": """Watches a book's files and rebuilds it on changes

Usage: executable watch [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version
""",
    "serve": """Serves a book at http://localhost:3000, and rebuilds it on changes

Usage: executable serve [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]
  -p, --port <port>          Port to use for HTTP connections [default: 3000]
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version
""",
}


@dataclass
class Chapter:
    title: str
    path: str = ""
    level: int = 0
    numbered: bool = True
    number: str = ""
    html_path: str = ""
    children: list = field(default_factory=list)


def log(level, module, msg):
    print(f"{time.strftime('%Y-%m-%d %H:%M:%S')} [{level}] ({module}): {msg}", file=sys.stderr)


def load_config(root):
    cfg_path = root / "book.toml"
    if not cfg_path.exists():
        return {}
    with cfg_path.open("rb") as f:
        return tomllib.load(f)


def src_dir(root, cfg):
    return root / cfg.get("book", {}).get("src", "src")


def dest_dir(root, cfg, dest):
    if dest:
        p = Path(dest)
        return p if p.is_absolute() else root / p
    build = cfg.get("build", {}).get("build-dir", "book")
    p = Path(build)
    return p if p.is_absolute() else root / p


def md_to_html_path(path):
    p = Path(path)
    parts = list(p.parts)
    if not parts:
        return ""
    name = parts[-1]
    if name.lower() == "readme.md":
        parts[-1] = "index.html"
    elif name.lower().endswith(".md"):
        parts[-1] = name[:-3] + ".html"
    return "/".join(parts).lstrip("./")


def parse_summary(src):
    path = src / "SUMMARY.md"
    if not path.exists():
        raise FileNotFoundError(f'Couldn\'t open SUMMARY.md in "{src}" directory')
    chapters = []
    stack = []
    counters = []
    seen_numbered = False
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.rstrip()
        stripped = line.strip()
        if not stripped or stripped.lower().startswith("# summary"):
            continue
        if re.fullmatch(r"-{3,}", stripped):
            chapters.append(Chapter("", numbered=False, path="---"))
            stack = []
            continue
        if stripped.startswith("# "):
            chapters.append(Chapter(stripped[2:].strip(), numbered=False, path="#part"))
            stack = []
            seen_numbered = True
            continue
        m = re.match(r"^(\s*)(?:[-*]\s*)?\[([^\]]+)\]\(([^)]*)\)", line)
        if not m:
            continue
        indent, title, target = m.groups()
        bullet = stripped.startswith(("- ", "* "))
        level = len(indent.replace("\t", "    ")) // 4
        numbered = bullet or seen_numbered
        if numbered:
            seen_numbered = True
            while len(counters) <= level:
                counters.append(0)
            counters = counters[: level + 1]
            counters[level] += 1
            for i in range(level + 1, len(counters)):
                counters[i] = 0
            number = ".".join(str(n) for n in counters[: level + 1] if n) + "."
        else:
            number = ""
        ch = Chapter(title.strip(), target.strip(), level, numbered, number)
        ch.html_path = md_to_html_path(ch.path) if ch.path else ""
        if ch.path:
            ch.path = ch.path.lstrip("./")
        if level and stack:
            while stack and stack[-1].level >= level:
                stack.pop()
            (stack[-1].children if stack else chapters).append(ch)
        else:
            chapters.append(ch)
            stack = []
        stack.append(ch)
    return chapters


def flatten(chapters):
    out = []
    for ch in chapters:
        if ch.path not in ("#part", "---"):
            out.append(ch)
        out.extend(flatten(ch.children))
    return out


def slugify(text):
    text = re.sub(r"<[^>]+>", "", text.lower())
    text = re.sub(r"[^\w\s-]", "", text)
    return re.sub(r"[-\s]+", "-", text).strip("-")


def rel_root(html_path):
    depth = len(Path(html_path).parts) - 1
    return "../" * depth


def rewrite_href(href):
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", href) or href.startswith("#"):
        return href
    anchor = ""
    if "#" in href:
        href, anchor = href.split("#", 1)
        anchor = "#" + anchor
    if href.lower().endswith(".md"):
        href = md_to_html_path(href)
    return href + anchor


def inline_md(s):
    s = html.escape(s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", lambda m: f'<img src="{html.escape(m.group(2))}" alt="{m.group(1)}">', s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lambda m: f'<a href="{html.escape(rewrite_href(html.unescape(m.group(2))))}">{m.group(1)}</a>', s)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", s)
    return s


def preprocess_includes(text, base):
    def repl(m):
        spec = m.group(1).strip()
        parts = spec.split(None, 1)
        cmd = parts[0]
        arg = parts[1] if len(parts) > 1 else ""
        if cmd not in ("#include", "#rustdoc_include", "#playground"):
            return m.group(0)
        file_spec = arg.split()[0] if arg else ""
        file_path = file_spec.split(":", 1)[0]
        try:
            data = (base / file_path).read_text(encoding="utf-8", errors="replace")
            if cmd == "#playground":
                return "```rust\n" + data + "\n```"
            return data
        except Exception as e:
            log("ERROR", "mdbook_driver::builtin_preprocessors::links", f'Error updating "{m.group(0)}", Could not read file for link {m.group(0)} ({base / file_path})')
            log("WARN", "mdbook_driver::builtin_preprocessors::links", f"Caused By: {e}")
            return ""
    rendered = []
    in_fence = False
    for line in text.splitlines(True):
        stripped = line.strip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            in_fence = not in_fence
            rendered.append(line)
        elif in_fence:
            rendered.append(line)
        else:
            rendered.append(re.sub(r"\{\{(#[^{}]+)\}\}", repl, line))
    return "".join(rendered)


def render_markdown(text):
    lines = text.splitlines()
    out, para, in_ul, in_ol = [], [], False, False
    i = 0
    def flush_para():
        nonlocal para
        if para:
            out.append("<p>" + inline_md(" ".join(para).strip()) + "</p>")
            para = []
    def close_lists():
        nonlocal in_ul, in_ol
        if in_ul:
            out.append("</ul>"); in_ul = False
        if in_ol:
            out.append("</ol>"); in_ol = False
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        fence = re.match(r"^```([^`]*)$", stripped) or re.match(r"^~~~([^~]*)$", stripped)
        if fence:
            flush_para(); close_lists()
            lang = fence.group(1).split(",")[0].strip()
            end = "```" if stripped.startswith("```") else "~~~"
            code = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith(end):
                code.append(lines[i]); i += 1
            cls = f' class="language-{html.escape(lang)}"' if lang else ""
            out.append(f"<pre><code{cls}>" + html.escape("\n".join(code)) + "</code></pre>")
        elif not stripped:
            flush_para(); close_lists()
        elif re.match(r"^#{1,6}\s+", stripped):
            flush_para(); close_lists()
            n = len(stripped) - len(stripped.lstrip("#"))
            title = stripped[n:].strip()
            sid = slugify(title)
            out.append(f'<h{n} id="{sid}"><a class="header" href="#{sid}">{inline_md(title)}</a></h{n}>')
        elif re.match(r"^[-*]\s+", stripped):
            flush_para()
            if not in_ul:
                close_lists(); out.append("<ul>"); in_ul = True
            out.append("<li>" + inline_md(re.sub(r"^[-*]\s+", "", stripped)) + "</li>")
        elif re.match(r"^\d+[.)]\s+", stripped):
            flush_para()
            if not in_ol:
                close_lists(); out.append("<ol>"); in_ol = True
            out.append("<li>" + inline_md(re.sub(r"^\d+[.)]\s+", "", stripped)) + "</li>")
        elif stripped.startswith(">"):
            flush_para(); close_lists()
            out.append("<blockquote><p>" + inline_md(stripped.lstrip("> ").strip()) + "</p></blockquote>")
        elif re.fullmatch(r"-{3,}|\*{3,}", stripped):
            flush_para(); close_lists(); out.append("<hr>")
        else:
            para.append(stripped)
        i += 1
    flush_para(); close_lists()
    return "\n".join(out)


def page_template(title, book_title, content, toc, root_prefix, prev_href="", next_href="", desc="", lang="en", direction="ltr"):
    nav_prev = f'<a rel="prev" href="{prev_href}" class="nav-chapters previous">‹</a>' if prev_href else ""
    nav_next = f'<a rel="next" href="{next_href}" class="nav-chapters next">›</a>' if next_href else ""
    return f"""<!DOCTYPE HTML>
<html lang="{html.escape(lang)}" class="light sidebar-visible" dir="{html.escape(direction)}">
<head>
<meta charset="UTF-8">
<title>{html.escape(title + (" - " + book_title if book_title else ""))}</title>
<meta name="description" content="{html.escape(desc)}">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="{root_prefix}css/general.css">
</head>
<body>
<nav id="sidebar" class="sidebar" aria-label="Table of contents">{toc}</nav>
<div id="page-wrapper" class="page-wrapper">
<div id="menu-bar" class="menu-bar"><a href="{root_prefix}index.html" class="menu-title">{html.escape(book_title)}</a></div>
<main id="content" class="content">
{content}
</main>
<nav class="nav-wrapper" aria-label="Page navigation">{nav_prev}{nav_next}</nav>
</div>
</body>
</html>
"""


def render_toc(chapters, current=""):
    def rec(items):
        s = ['<ol class="chapter">']
        for ch in items:
            if ch.path == "---":
                s.append('<li class="spacer"></li>')
            elif ch.path == "#part":
                s.append(f'<li class="part-title">{html.escape(ch.title)}</li>')
            else:
                active = " active" if ch.html_path == current else ""
                if ch.html_path:
                    num = f'<strong aria-hidden="true">{html.escape(ch.number)}</strong> ' if ch.number else ""
                    s.append(f'<li class="chapter-item expanded{active}"><a href="{html.escape(ch.html_path)}">{num}{html.escape(ch.title)}</a>')
                else:
                    s.append(f'<li class="chapter-item expanded"><div>{html.escape(ch.title)}</div>')
                if ch.children:
                    s.append(rec(ch.children))
                s.append("</li>")
        s.append("</ol>")
        return "".join(s)
    return rec(chapters)


def copy_assets(src, dest):
    for p in src.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(src)
        if rel.name == "SUMMARY.md" or p.suffix.lower() == ".md":
            continue
        out = dest / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, out)


def write_theme(dest):
    (dest / "css").mkdir(parents=True, exist_ok=True)
    (dest / "css" / "general.css").write_text("""body{margin:0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:#222;background:#fff}.sidebar{position:fixed;inset:0 auto 0 0;width:280px;overflow:auto;background:#f6f6f6;border-right:1px solid #ddd;padding:1rem}.page-wrapper{margin-left:312px;max-width:900px;padding:2rem}.menu-bar{font-weight:700;margin-bottom:1.5rem}.chapter,.section{list-style:none;padding-left:1rem}.chapter-item{margin:.35rem 0}.part-title{font-weight:700;margin-top:1rem}.spacer{border-top:1px solid #ccc;margin:1rem 0}a{color:#0969da;text-decoration:none}a:hover{text-decoration:underline}pre{background:#f4f4f4;padding:1rem;overflow:auto;border-radius:4px}code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.nav-wrapper{display:flex;justify-content:space-between;font-size:2rem}.content img{max-width:100%}@media(max-width:900px){.sidebar{position:static;width:auto}.page-wrapper{margin-left:0;padding:1rem}}""", encoding="utf-8")
    (dest / ".nojekyll").write_text("", encoding="utf-8")


def build_book(root, dest_arg=None, quiet=False):
    root = Path(root).resolve()
    cfg = load_config(root)
    src = src_dir(root, cfg)
    dest = dest_dir(root, cfg, dest_arg)
    try:
        chapters = parse_summary(src)
    except FileNotFoundError:
        log("ERROR", "mdbook_core::utils", f'Error: Couldn\'t open SUMMARY.md in "{src}" directory')
        log("ERROR", "mdbook_core::utils", "\tCaused By: No such file or directory (os error 2)")
        return 101
    if not quiet:
        log("INFO", "mdbook_driver::mdbook", "Book building has started")
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)
    create_missing = cfg.get("build", {}).get("create-missing", True)
    flat = [c for c in flatten(chapters) if c.path and c.path != "---"]
    for ch in flat:
        src_file = src / ch.path
        if not src_file.exists():
            if create_missing:
                src_file.parent.mkdir(parents=True, exist_ok=True)
                src_file.write_text(f"# {ch.title}\n", encoding="utf-8")
            else:
                log("ERROR", "mdbook_core::utils", f"File not found: {src_file}")
                return 101
    copy_assets(src, dest)
    write_theme(dest)
    book = cfg.get("book", {})
    book_title = book.get("title", "mdBook")
    desc = book.get("description", "")
    lang = book.get("language", "en")
    direction = book.get("text-direction", "ltr")
    all_html = []
    for idx, ch in enumerate(flat):
        src_file = src / ch.path
        text = preprocess_includes(src_file.read_text(encoding="utf-8", errors="replace"), src_file.parent)
        content = render_markdown(text)
        out = dest / ch.html_path
        out.parent.mkdir(parents=True, exist_ok=True)
        prev_href = flat[idx - 1].html_path if idx else ""
        next_href = flat[idx + 1].html_path if idx + 1 < len(flat) else ""
        page = page_template(ch.title, book_title, content, render_toc(chapters, ch.html_path), rel_root(ch.html_path), prev_href, next_href, desc, lang, direction)
        out.write_text(page, encoding="utf-8")
        all_html.append(f"<h1>{html.escape(ch.title)}</h1>\n{content}")
    if flat and not (dest / "index.html").exists():
        first = dest / flat[0].html_path
        if first.exists():
            shutil.copy2(first, dest / "index.html")
    (dest / "toc.html").write_text(page_template("Table of Contents", book_title, render_toc(chapters), render_toc(chapters), "", desc=desc, lang=lang, direction=direction), encoding="utf-8")
    (dest / "toc.js").write_text("document.addEventListener('DOMContentLoaded',function(){var e=document.querySelector('mdbook-sidebar-scrollbox'); if(e) e.innerHTML = " + repr(render_toc(chapters)) + ";});", encoding="utf-8")
    (dest / "print.html").write_text(page_template("Print", book_title, "\n".join(all_html), render_toc(chapters), "", desc=desc, lang=lang, direction=direction), encoding="utf-8")
    (dest / "searchindex.js").write_text("window.search = window.search || {}; window.search.doc_urls=[]; window.search.doc_titles=[];", encoding="utf-8")
    redirects = cfg.get("output", {}).get("html", {}).get("redirect", {})
    for src_url, target in redirects.items():
        out = dest / src_url.lstrip("/")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(f'<!doctype html><meta http-equiv="refresh" content="0; url={html.escape(target)}"><a href="{html.escape(target)}">{html.escape(target)}</a>', encoding="utf-8")
    if not quiet:
        log("INFO", "mdbook_driver::mdbook", "Running the html backend")
        log("INFO", "mdbook_html::html_handlebars::hbs_renderer", f"HTML book written to `{dest}`")
    return 0


def cmd_init(args):
    root = Path(args.dir or ".").resolve()
    title = args.title or root.name or "My Book"
    root.mkdir(parents=True, exist_ok=True)
    src = root / "src"
    src.mkdir(parents=True, exist_ok=True)
    if args.ignore is None and not args.force:
        try:
            ans = input("\nDo you want a .gitignore to be created? (y/n)\n")
        except EOFError:
            ans = "n"
        ignore = "git" if ans.lower().startswith("y") else "none"
    else:
        ignore = args.ignore or "none"
    log("INFO", "mdbook_driver::init", "Creating a new book with stub content")
    (root / "book.toml").write_text(f'[book]\nauthors = []\nlanguage = "en"\nsrc = "src"\ntitle = "{title}"\n', encoding="utf-8")
    (src / "SUMMARY.md").write_text("# Summary\n\n- [Chapter 1](./chapter_1.md)\n", encoding="utf-8")
    (src / "chapter_1.md").write_text("# Chapter 1\n", encoding="utf-8")
    if ignore == "git":
        (root / ".gitignore").write_text("book\n", encoding="utf-8")
    if args.theme:
        theme = src / "theme"
        theme.mkdir(exist_ok=True)
        (theme / "index.hbs").write_text("{{ content }}\n", encoding="utf-8")
    print("\nAll done, no errors...")
    return 0


def cmd_clean(args):
    root = Path(args.dir or ".").resolve()
    dest = dest_dir(root, load_config(root), args.dest_dir)
    if dest.exists():
        shutil.rmtree(dest)
    return 0


def collect_rust_blocks(root, chapter=None):
    cfg = load_config(root)
    src = src_dir(root, cfg)
    blocks = []
    for md in src.rglob("*.md"):
        if md.name == "SUMMARY.md":
            continue
        if chapter and chapter not in str(md) and chapter not in md.read_text(encoding="utf-8", errors="replace"):
            continue
        text = md.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(r"```([^`\n]*)\n(.*?)\n```", text, flags=re.S):
            attrs = m.group(1)
            if "rust" in attrs and "ignore" not in attrs and "no_run" not in attrs:
                blocks.append((md, m.group(2)))
    return blocks


def cmd_test(args):
    root = Path(args.dir or ".").resolve()
    rc = build_book(root, args.dest_dir, quiet=True)
    if rc:
        return rc
    blocks = collect_rust_blocks(root, args.chapter)
    if not blocks:
        return 0
    with tempfile.TemporaryDirectory() as td:
        for i, (path, code) in enumerate(blocks):
            src = Path(td) / f"test_{i}.rs"
            body = code if "fn main" in code else "fn main() {\n" + code + "\n}\n"
            src.write_text(body, encoding="utf-8")
            cmd = ["rustc", "--edition", "2018", str(src), "-o", str(Path(td) / f"test_{i}")]
            for lp in args.library_path or []:
                for one in lp.split(","):
                    if one:
                        cmd.extend(["-L", one])
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if res.returncode:
                sys.stderr.write(res.stderr)
                return res.returncode
    return 0


def completions(shell):
    cmds = "init build test clean completions watch serve help"
    if shell == "bash":
        return f"_mdbook() {{ COMPREPLY=( $(compgen -W '{cmds}' -- \"${{COMP_WORDS[COMP_CWORD]}}\") ); }}\ncomplete -F _mdbook executable\n"
    if shell == "zsh":
        return f"#compdef executable\n_arguments '1: :({cmds})'\n"
    if shell == "fish":
        return "\n".join(f"complete -c executable -f -a {c}" for c in cmds) + "\n"
    if shell == "powershell":
        return f"Register-ArgumentCompleter -Native -CommandName executable -ScriptBlock {{ param($wordToComplete) '{cmds}'.Split(' ') | ? {{ $_ -like \"$wordToComplete*\" }} }}\n"
    return "\n".join(cmds.split()) + "\n"


def make_parser():
    p = argparse.ArgumentParser(add_help=False)
    sub = p.add_subparsers(dest="cmd")
    q = sub.add_parser("init", add_help=False)
    q.add_argument("--theme", action="store_true"); q.add_argument("--force", action="store_true")
    q.add_argument("--title"); q.add_argument("--ignore", choices=["none", "git"]); q.add_argument("dir", nargs="?")
    for name in ("build", "clean"):
        q = sub.add_parser(name, add_help=False)
        q.add_argument("-d", "--dest-dir"); q.add_argument("dir", nargs="?")
        if name == "build":
            q.add_argument("-o", "--open", action="store_true")
    q = sub.add_parser("test", add_help=False)
    q.add_argument("-d", "--dest-dir"); q.add_argument("-c", "--chapter"); q.add_argument("-L", "--library-path", action="append"); q.add_argument("dir", nargs="?")
    q = sub.add_parser("completions", add_help=False); q.add_argument("shell", nargs="?")
    for name in ("watch", "serve"):
        q = sub.add_parser(name, add_help=False)
        q.add_argument("-d", "--dest-dir"); q.add_argument("-o", "--open", action="store_true"); q.add_argument("--watcher", choices=["poll", "native"], default="poll"); q.add_argument("dir", nargs="?")
        if name == "serve":
            q.add_argument("-n", "--hostname", default="localhost"); q.add_argument("-p", "--port", type=int, default=3000)
    return p


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        print(ROOT_HELP)
        return 2
    if argv[0] in ("-h", "--help", "help"):
        if len(argv) > 1 and argv[1] in HELP:
            print(HELP[argv[1]])
        else:
            print(ROOT_HELP)
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION); return 0
    if argv[0] in HELP and any(a in ("-h", "--help") for a in argv[1:]):
        print(HELP[argv[0]]); return 0
    if argv[0] in HELP and any(a in ("-V", "--version") for a in argv[1:]):
        print(VERSION); return 0
    if argv[0] not in HELP:
        print(f"error: unrecognized subcommand '{argv[0]}'\n\nUsage: executable [COMMAND]\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    try:
        args = make_parser().parse_args(argv)
    except SystemExit:
        return 2
    if args.cmd == "init":
        return cmd_init(args)
    if args.cmd == "build":
        return build_book(args.dir or ".", args.dest_dir)
    if args.cmd == "clean":
        return cmd_clean(args)
    if args.cmd == "test":
        return cmd_test(args)
    if args.cmd == "completions":
        shells = ["bash", "elvish", "fish", "powershell", "zsh"]
        if not args.shell:
            print(HELP["completions"], file=sys.stderr); return 2
        if args.shell not in shells:
            print(f"error: invalid value '{args.shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.", file=sys.stderr)
            return 2
        print(completions(args.shell), end=""); return 0
    if args.cmd == "watch":
        rc = build_book(args.dir or ".", args.dest_dir)
        if rc: return rc
        print("Listening for changes...")
        while True:
            time.sleep(3600)
    if args.cmd == "serve":
        root = Path(args.dir or ".").resolve()
        rc = build_book(root, args.dest_dir)
        if rc: return rc
        dest = dest_dir(root, load_config(root), args.dest_dir)
        os.chdir(dest)
        print(f"Serving HTTP on {args.hostname} port {args.port} (http://{args.hostname}:{args.port}/) ...")
        http.server.ThreadingHTTPServer((args.hostname, args.port), http.server.SimpleHTTPRequestHandler).serve_forever()
    return 0


if __name__ == "__main__":
    sys.exit(main())
