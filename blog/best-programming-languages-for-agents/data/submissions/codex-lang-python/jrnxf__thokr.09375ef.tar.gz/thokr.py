#!/usr/bin/env python3
import os
import random
import select
import sys
import termios
import time
import tty
from pathlib import Path


VERSION = "thokr 0.4.1"
ABOUT = "sleek typing tui with visualized results and historical logging"
LANGUAGES = {"english", "english1k", "english10k"}

WORDS = [
    "the", "be", "to", "of", "and", "a", "in", "that", "have", "i", "it",
    "for", "not", "on", "with", "he", "as", "you", "do", "at", "this",
    "but", "his", "by", "from", "they", "we", "say", "her", "she", "or",
    "an", "will", "my", "one", "all", "would", "there", "their", "what",
    "so", "up", "out", "if", "about", "who", "get", "which", "go", "me",
    "when", "make", "can", "like", "time", "no", "just", "him", "know",
    "take", "people", "into", "year", "your", "good", "some", "could",
    "them", "see", "other", "than", "then", "now", "look", "only", "come",
    "its", "over", "think", "also", "back", "after", "use", "two", "how",
    "our", "work", "first", "well", "way", "even", "new", "want",
    "because", "any", "these", "give", "day", "most", "us",
]

SENTENCES = [
    "The quick brown fox jumps over the lazy dog.",
    "Typing practice is better when the words are simple.",
    "Small steady tests can make a fast typist calmer.",
    "Every prompt ends with a full stop.",
    "Clean habits improve speed and accuracy.",
    "A short sentence is easy to read.",
]


def help_text(prog: str) -> str:
    return f"""{VERSION}
{ABOUT}

USAGE:
    {prog} [OPTIONS]

OPTIONS:
    -f, --full-sentences <NUMBER_OF_SENTENCES>
            number of sentences to use in test

    -h, --help
            Print help information

    -l, --supported-language <SUPPORTED_LANGUAGE>
            language to pull words from [default: english] [possible values: english, english1k,
            english10k]

    -p, --prompt <PROMPT>
            custom prompt to use

    -s, --number-of-secs <NUMBER_OF_SECS>
            number of seconds to run test

    -V, --version
            Print version information

    -w, --number-of-words <NUMBER_OF_WORDS>
            number of words to use in test [default: 15]
"""


def err(msg: str, usage: str | None = None) -> int:
    sys.stderr.write(f"error: {msg}\n\n")
    if usage:
        sys.stderr.write(f"USAGE:\n    {usage}\n\n")
    sys.stderr.write("For more information try --help\n")
    return 2


def parse_uint(value: str, opt: str) -> int | None:
    if not value.isdigit():
        raise ValueError(f'Invalid value "{value}" for \'{opt}\': invalid digit found in string')
    return int(value)


def take_value(argv: list[str], i: int, opt: str, possible: bool = False) -> tuple[str | None, int | None]:
    if i + 1 >= len(argv):
        extra = "\n\t[possible values: english, english1k, english10k]" if possible else ""
        return None, err(f"The argument '{opt}' requires a value but none was supplied{extra}", "executable [OPTIONS]")
    if argv[i + 1].startswith("-"):
        a = argv[i + 1]
        msg = f"Found argument '{a}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `{a}` as a value rather than a flag, use `-- {a}`"
        return None, err(msg, "executable [OPTIONS]")
    return argv[i + 1], i + 2


def parse(argv: list[str]) -> tuple[int, dict | None]:
    opts = {"words": 15, "lang": "english", "prompt": None, "secs": None, "sentences": None}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(help_text("executable"), end="")
            return 0, None
        if a in ("-V", "--version"):
            print(VERSION)
            return 0, None
        if a in ("-w", "--number-of-words"):
            val, ni = take_value(argv, i, "--number-of-words <NUMBER_OF_WORDS>")
            if val is None:
                return ni, None
            try:
                opts["words"] = parse_uint(val, "--number-of-words <NUMBER_OF_WORDS>")
            except ValueError as e:
                return err(str(e)), None
            i = ni
            continue
        if a.startswith("--number-of-words="):
            val = a.split("=", 1)[1]
            try:
                opts["words"] = parse_uint(val, "--number-of-words <NUMBER_OF_WORDS>")
            except ValueError as e:
                return err(str(e)), None
            i += 1
            continue
        if a.startswith("-w") and a != "-w":
            val = a[2:]
            try:
                opts["words"] = parse_uint(val, "--number-of-words <NUMBER_OF_WORDS>")
            except ValueError as e:
                return err(str(e)), None
            i += 1
            continue
        if a in ("-s", "--number-of-secs"):
            val, ni = take_value(argv, i, "--number-of-secs <NUMBER_OF_SECS>")
            if val is None:
                return ni, None
            try:
                opts["secs"] = parse_uint(val, "--number-of-secs <NUMBER_OF_SECS>")
            except ValueError as e:
                return err(str(e)), None
            i = ni
            continue
        if a.startswith("--number-of-secs="):
            val = a.split("=", 1)[1]
            try:
                opts["secs"] = parse_uint(val, "--number-of-secs <NUMBER_OF_SECS>")
            except ValueError as e:
                return err(str(e)), None
            i += 1
            continue
        if a in ("-f", "--full-sentences"):
            val, ni = take_value(argv, i, "--full-sentences <NUMBER_OF_SENTENCES>")
            if val is None:
                return ni, None
            try:
                opts["sentences"] = parse_uint(val, "--full-sentences <NUMBER_OF_SENTENCES>")
            except ValueError as e:
                return err(str(e)), None
            i = ni
            continue
        if a.startswith("--full-sentences="):
            val = a.split("=", 1)[1]
            try:
                opts["sentences"] = parse_uint(val, "--full-sentences <NUMBER_OF_SENTENCES>")
            except ValueError as e:
                return err(str(e)), None
            i += 1
            continue
        if a in ("-l", "--supported-language"):
            val, ni = take_value(argv, i, "--supported-language <SUPPORTED_LANGUAGE>", True)
            if val is None:
                return ni, None
            if val not in LANGUAGES:
                return err(f'"{val}" isn\'t a valid value for \'--supported-language <SUPPORTED_LANGUAGE>\'\n\t[possible values: english, english1k, english10k]', "executable --supported-language <SUPPORTED_LANGUAGE>"), None
            opts["lang"] = val
            i = ni
            continue
        if a.startswith("--supported-language="):
            val = a.split("=", 1)[1]
            if val not in LANGUAGES:
                return err(f'"{val}" isn\'t a valid value for \'--supported-language <SUPPORTED_LANGUAGE>\'\n\t[possible values: english, english1k, english10k]', "executable --supported-language <SUPPORTED_LANGUAGE>"), None
            opts["lang"] = val
            i += 1
            continue
        if a in ("-p", "--prompt"):
            val, ni = take_value(argv, i, "--prompt <PROMPT>")
            if val is None:
                return ni, None
            opts["prompt"] = val
            i = ni
            continue
        if a.startswith("--prompt="):
            opts["prompt"] = a.split("=", 1)[1]
            i += 1
            continue
        if a.startswith("-"):
            if a.startswith("--"):
                msg = f"Found argument '{a}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `{a}` as a value rather than a flag, use `-- {a}`"
            else:
                msg = f"Found argument '{a}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `{a}` as a value rather than a flag, use `-- {a}`"
            return err(msg, "executable [OPTIONS]"), None
        return err(f"Found argument '{a}' which wasn't expected, or isn't valid in this context", "executable [OPTIONS]"), None
    return 0, opts


def make_prompt(opts: dict) -> str:
    if opts["prompt"] is not None:
        return opts["prompt"]
    if opts["sentences"] is not None:
        count = opts["sentences"]
        return " ".join(SENTENCES[i % len(SENTENCES)] for i in range(count))
    count = opts["words"]
    return " ".join(random.choice(WORDS) for _ in range(count))


def log_result(prompt: str, typed: str, elapsed: float) -> None:
    try:
        base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
        path = Path(base) / "thokr"
        path.mkdir(parents=True, exist_ok=True)
        log = path / "log.csv"
        correct = sum(1 for a, b in zip(prompt, typed) if a == b)
        accuracy = 100.0 if not typed else correct / max(len(typed), 1) * 100.0
        wpm = 0.0 if elapsed <= 0 else (len(typed) / 5.0) / (elapsed / 60.0)
        new = not log.exists()
        with log.open("a", encoding="utf-8") as f:
            if new:
                f.write("timestamp,wpm,accuracy,seconds,prompt\n")
            safe_prompt = prompt.replace('"', '""')
            f.write(f'{int(time.time())},{wpm:.2f},{accuracy:.2f},{elapsed:.2f},"{safe_prompt}"\n')
    except OSError:
        pass


def run_tty(opts: dict) -> int:
    prompt = make_prompt(opts)
    old = termios.tcgetattr(sys.stdin.fileno())
    typed = []
    start = time.monotonic()
    deadline = start + opts["secs"] if opts["secs"] is not None else None
    try:
        tty.setcbreak(sys.stdin.fileno())
        sys.stdout.write("\x1b[?1049h\x1b[?25l\x1b[2J\x1b[H")
        while True:
            elapsed = time.monotonic() - start
            sys.stdout.write("\x1b[H\x1b[2Kthokr\n\n")
            sys.stdout.write(prompt + "\n\n")
            sys.stdout.write("".join(typed) + "\n\n")
            sys.stdout.write(f"{elapsed:.1f}s")
            sys.stdout.flush()
            if "".join(typed) == prompt:
                break
            if deadline is not None and time.monotonic() >= deadline:
                break
            timeout = 0.05
            if deadline is not None:
                timeout = max(0.0, min(timeout, deadline - time.monotonic()))
            r, _, _ = select.select([sys.stdin], [], [], timeout)
            if not r:
                continue
            ch = os.read(sys.stdin.fileno(), 8).decode("utf-8", "ignore")
            if ch in ("\x03", "\x04"):
                return 1
            if ch in ("\x7f", "\b"):
                typed = typed[:-1]
            elif ch in ("\r", "\n"):
                if "".join(typed) == prompt:
                    break
            elif ch == "\x1b[D":
                typed = []
            elif ch == "\x1b[C" and opts["prompt"] is None:
                prompt = make_prompt(opts)
                typed = []
                start = time.monotonic()
                deadline = start + opts["secs"] if opts["secs"] is not None else None
            elif ch and ch.isprintable():
                typed.append(ch)
        elapsed = time.monotonic() - start
        log_result(prompt, "".join(typed), elapsed)
        sys.stdout.write("\n\n")
        sys.stdout.write(f"wpm: {((len(typed) / 5.0) / max(elapsed / 60.0, 1e-9)):.2f}  ")
        sys.stdout.write(f"accuracy: {(sum(1 for a,b in zip(prompt, typed) if a == b) / max(len(typed), 1) * 100.0):.2f}%\n")
        sys.stdout.flush()
        time.sleep(0.2)
        return 0
    finally:
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
        sys.stdout.write("\x1b[?25h\x1b[?1049l")
        sys.stdout.flush()


def main() -> int:
    code, opts = parse(sys.argv[1:])
    if opts is None:
        return code
    if not sys.stdin.isatty():
        return err("stdin must be a tty", "thokr [OPTIONS]")
    return run_tty(opts)


if __name__ == "__main__":
    raise SystemExit(main())
