#!/usr/bin/env python3
import argparse
import binascii
import hashlib
import hmac
import itertools
import os
import struct
import sys
import time
import zipfile
import zlib

VERSION = "zip-password-finder 0.10.3"

def make_crc_table():
    table = []
    for i in range(256):
        c = i
        for _ in range(8):
            if c & 1:
                c = 0xedb88320 ^ (c >> 1)
            else:
                c >>= 1
        table.append(c & 0xffffffff)
    return table

CRC_TABLE = make_crc_table()

CHARSETS = {
    "l": "abcdefghijklmnopqrstuvwxyz",
    "u": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "d": "0123456789",
    "h": "0123456789abcdef",
    "H": "0123456789ABCDEF",
    "s": " !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~",
}

HELP_TEXT = """Find the password of protected ZIP files

Usage: executable [OPTIONS] --inputFile <inputFile>

Options:
  -i, --inputFile <inputFile>                    path to zip input file
  -w, --workers <workers>                        number of workers
  -p, --passwordDictionary <passwordDictionary>  path to a password dictionary file
  -c, --charset <charset>                        charset to use to generate password [default: lud]
      --charsetFile <charsetFile>                path to a charset file
      --minPasswordLen <minPasswordLen>          minimum password length [default: 1]
      --maxPasswordLen <maxPasswordLen>          maximum password length [default: 10]
      --fileNumber <fileNumber>                  file number in the zip archive [default: 0]
  -s, --startingPassword <startingPassword>      password to start from
  -h, --help                                     Print help
  -V, --version                                  Print version
"""

class Parser(argparse.ArgumentParser):
    def error(self, message):
        sys.stderr.write(f"error: {message}\n\nFor more information, try '--help'.\n")
        raise SystemExit(2)


def parse_args(argv):
    if any(a in ("-h", "--help") for a in argv):
        print(HELP_TEXT)
        raise SystemExit(0)
    if any(a in ("-V", "--version") for a in argv):
        print(VERSION)
        raise SystemExit(0)
    p = Parser(add_help=False, prog="executable", allow_abbrev=False)
    p.add_argument("-i", "--inputFile", dest="inputFile")
    p.add_argument("-w", "--workers", dest="workers", type=int)
    p.add_argument("-p", "--passwordDictionary", dest="passwordDictionary")
    p.add_argument("-c", "--charset", dest="charset", default="lud")
    p.add_argument("--charsetFile", dest="charsetFile")
    p.add_argument("--minPasswordLen", dest="minPasswordLen", type=int, default=1)
    p.add_argument("--maxPasswordLen", dest="maxPasswordLen", type=int, default=10)
    p.add_argument("--fileNumber", dest="fileNumber", type=int, default=0)
    p.add_argument("-s", "--startingPassword", dest="startingPassword")
    ns = p.parse_args(argv)
    if not ns.inputFile:
        sys.stderr.write("error: the following required arguments were not provided:\n  --inputFile <inputFile>\n\nUsage: executable --inputFile <inputFile>\n\nFor more information, try '--help'.\n")
        raise SystemExit(2)
    return ns


def cli_arg_error(msg):
    print(f"CLI argument error - {msg!r}")
    return 1



class ZipCrypto:
    def __init__(self, password):
        self.keys = [305419896, 591751049, 878082192]
        for b in password.encode("utf-8"):
            self.update_keys(b)

    def crc32_byte(self, old, b):
        return ((old >> 8) ^ CRC_TABLE[(old ^ b) & 0xff]) & 0xffffffff

    def update_keys(self, b):
        self.keys[0] = self.crc32_byte(self.keys[0], b)
        self.keys[1] = (self.keys[1] + (self.keys[0] & 0xff)) & 0xffffffff
        self.keys[1] = (self.keys[1] * 134775813 + 1) & 0xffffffff
        self.keys[2] = self.crc32_byte(self.keys[2], (self.keys[1] >> 24) & 0xff)

    def decrypt_byte(self):
        temp = (self.keys[2] | 2) & 0xffffffff
        return ((temp * (temp ^ 1)) >> 8) & 0xff

    def decrypt(self, data):
        out = bytearray()
        for c in data:
            p = c ^ self.decrypt_byte()
            self.update_keys(p)
            out.append(p)
        return bytes(out)

def parse_extra(extra):
    pos = 0
    while pos + 4 <= len(extra):
        tag, size = struct.unpack_from("<HH", extra, pos)
        pos += 4
        body = extra[pos:pos+size]
        pos += size
        if tag == 0x9901 and len(body) >= 7:
            strength = body[4]
            actual = struct.unpack_from("<H", body, 5)[0]
            return strength, actual
    return None


def local_data(zip_path, info):
    with open(zip_path, "rb") as f:
        f.seek(info.header_offset)
        hdr = f.read(30)
        if len(hdr) != 30 or hdr[:4] != b"PK\x03\x04":
            raise zipfile.BadZipFile("bad local header")
        fields = struct.unpack("<IHHHHHIIIHH", hdr)
        name_len, extra_len = fields[9], fields[10]
        f.seek(name_len + extra_len, os.SEEK_CUR)
        return f.read(info.compress_size)


def aes_password_ok(zip_path, info, password):
    aes = parse_extra(info.extra)
    if not aes:
        return False
    strength, _actual = aes
    key_len = {1: 16, 2: 24, 3: 32}.get(strength)
    salt_len = {1: 8, 2: 12, 3: 16}.get(strength)
    if not key_len or not salt_len:
        return False
    blob = local_data(zip_path, info)
    if len(blob) < salt_len + 12:
        return False
    salt = blob[:salt_len]
    verifier = blob[salt_len:salt_len+2]
    encrypted = blob[salt_len+2:-10]
    auth = blob[-10:]
    pwd = password.encode("utf-8")
    material = hashlib.pbkdf2_hmac("sha1", pwd, salt, 1000, 2 * key_len + 2)
    enc_key = material[:key_len]
    auth_key = material[key_len:2*key_len]
    pwd_verify = material[2*key_len:]
    if pwd_verify != verifier:
        return False
    digest = hmac.new(auth_key, encrypted, hashlib.sha1).digest()[:10]
    return hmac.compare_digest(digest, auth)


def zipcrypto_password_ok(zip_path, zf, info, password):
    try:
        blob = local_data(zip_path, info)
        if len(blob) < 12:
            return False
        header = ZipCrypto(password).decrypt(blob[:12])
        check = (info._raw_time >> 8) & 0xff if (info.flag_bits & 0x8) else (info.CRC >> 24) & 0xff
        if header[-1] != check:
            return False
        # The header has a 1/256 false-positive rate. Confirm by asking zipfile
        # to read and validate CRC for candidates that pass the quick check.
        with zf.open(info, "r", pwd=password.encode("utf-8")) as fh:
            while fh.read(65536):
                pass
        return True
    except (RuntimeError, zipfile.BadZipFile, binascii.Error, zlib.error):
        return False
    except Exception:
        return False


def password_ok(zip_path, zf, info, password):
    if info.compress_type == 99:
        return aes_password_ok(zip_path, info, password)
    return zipcrypto_password_ok(zip_path, zf, info, password)


def dictionary_candidates(path, starting=None):
    started = starting is None
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            word = line.rstrip("\r\n")
            if not started:
                if word == starting:
                    started = True
                else:
                    continue
            yield word


def build_charset(spec, charset_file):
    if charset_file:
        with open(charset_file, "r", encoding="utf-8", errors="ignore") as f:
            return f.read().rstrip("\r\n")
    chars = []
    seen = set()
    for ch in spec:
        if ch not in CHARSETS:
            raise ValueError(f"Unknown charset option '{ch}'")
        for c in CHARSETS[ch]:
            if c not in seen:
                seen.add(c)
                chars.append(c)
    return "".join(chars)


def brute_candidates(chars, min_len, max_len, starting=None):
    started = starting is None
    for n in range(min_len, max_len + 1):
        for tup in itertools.product(chars, repeat=n):
            word = "".join(tup)
            if not started:
                if word == starting:
                    started = True
                else:
                    continue
            yield word


def fmt_elapsed(ns):
    ms, rem = divmod(ns, 1_000_000)
    us, ns2 = divmod(rem, 1_000)
    return f"{ms}ms {us}us {ns2}ns"


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    try:
        args = parse_args(argv)
    except SystemExit as e:
        return int(e.code)

    if not os.path.exists(args.inputFile):
        return cli_arg_error("'inputFile' does not exist")
    if args.passwordDictionary and not os.path.exists(args.passwordDictionary):
        return cli_arg_error("'passwordDictionary' does not exist")
    if args.charsetFile and not os.path.exists(args.charsetFile):
        return cli_arg_error("'charsetFile' does not exist")

    try:
        zf = zipfile.ZipFile(args.inputFile)
    except Exception as e:
        print(f"Invalid zip file error - {e}")
        return 1
    infos = zf.infolist()
    if args.fileNumber < 0 or args.fileNumber >= len(infos):
        print(f"File number not found within archive error - '{args.fileNumber}'")
        return 1
    info = infos[args.fileNumber]
    if not (info.flag_bits & 0x1):
        print(f"Invalid zip file error - the selected file in the archive is not encrypted (file_number:{args.fileNumber} file_name:{info.filename})")
        return 1

    try:
        if args.passwordDictionary:
            candidates = dictionary_candidates(args.passwordDictionary, args.startingPassword)
        else:
            chars = build_charset(args.charset, args.charsetFile)
            candidates = brute_candidates(chars, args.minPasswordLen, args.maxPasswordLen, args.startingPassword)
    except ValueError as e:
        return cli_arg_error(str(e))
    except OSError as e:
        print(f"CLI argument error - {str(e)!r}")
        return 1

    start = time.monotonic_ns()
    found = None
    for candidate in candidates:
        if password_ok(args.inputFile, zf, info, candidate):
            found = candidate
            break
    elapsed = time.monotonic_ns() - start
    print(f"Time elapsed: {fmt_elapsed(elapsed)}")
    if found is None:
        print("Password not found")
    else:
        print(f"Password found:{found}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
