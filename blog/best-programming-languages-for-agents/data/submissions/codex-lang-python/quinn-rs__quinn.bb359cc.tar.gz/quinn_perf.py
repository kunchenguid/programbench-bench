#!/usr/bin/env python3
import json
import os
import socket
import sys
import time
from datetime import datetime, timezone


TOP_HELP = """Usage: executable <COMMAND>

Commands:
  server  Run as a perf server
  client  Run as a perf client
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

SERVER_HELP_LONG = """Run as a perf server

Usage: executable server [OPTIONS]

Options:
      --listen <LISTEN>
          Address to listen on
          
          [default: [::]:4433]

  -k, --key <KEY>
          TLS private key in DER format

  -c, --cert <CERT>
          TLS certificate in PEM format

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
"""

CLIENT_HELP_LONG = """Run as a perf client

Usage: executable client [OPTIONS] [HOST]

Arguments:
  [HOST]
          Host to connect to
          
          [default: localhost:4433]

Options:
      --ip <IP>
          Override DNS resolution for host

      --local-addr <LOCAL_ADDR>
          Specify the local socket address

      --uni-requests <UNI_REQUESTS>
          Number of unidirectional requests to maintain concurrently
          
          [default: 0]

      --bi-requests <BI_REQUESTS>
          Number of bidirectional requests to maintain concurrently
          
          [default: 1]

      --download-size <DOWNLOAD_SIZE>
          Number of bytes to request
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --upload-size <UPLOAD_SIZE>
          Number of bytes to transmit, in addition to the request header
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --duration <DURATION>
          The time to run in seconds
          
          [default: 60]

      --interval <INTERVAL>
          The interval in seconds at which stats are reported
          
          [default: 1]

      --json <JSON>
          File path to output JSON statistics to. If the file is '-', stdout will be used

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
"""


VALUE_OPTIONS = {
    "--listen": "LISTEN",
    "-k": "KEY",
    "--key": "KEY",
    "-c": "CERT",
    "--cert": "CERT",
    "--send-buffer-size": "SEND_BUFFER_SIZE",
    "--recv-buffer-size": "RECV_BUFFER_SIZE",
    "--initial-mtu": "INITIAL_MTU",
    "--initial-rtt": "INITIAL_RTT",
    "--congestion": "CONG_ALG",
    "--stream-receive-window": "STREAM_RECEIVE_WINDOW",
    "--receive-window": "RECEIVE_WINDOW",
    "--send-window": "SEND_WINDOW",
    "--max-udp-payload-size": "MAX_UDP_PAYLOAD_SIZE",
    "--qlog": "QLOG_FILE",
    "--ip": "IP",
    "--local-addr": "LOCAL_ADDR",
    "--uni-requests": "UNI_REQUESTS",
    "--bi-requests": "BI_REQUESTS",
    "--download-size": "DOWNLOAD_SIZE",
    "--upload-size": "UPLOAD_SIZE",
    "--duration": "DURATION",
    "--interval": "INTERVAL",
    "--json": "JSON",
}

FLAG_OPTIONS = {"--conn-stats", "--keylog", "--no-protection", "--ack-frequency"}
COMMON_VALUE = {
    "--send-buffer-size",
    "--recv-buffer-size",
    "--initial-mtu",
    "--initial-rtt",
    "--congestion",
    "--stream-receive-window",
    "--receive-window",
    "--send-window",
    "--max-udp-payload-size",
    "--qlog",
}
COMMON_FLAGS = FLAG_OPTIONS
SERVER_ONLY_VALUE = {"--listen", "-k", "--key", "-c", "--cert"}
CLIENT_ONLY_VALUE = {
    "--ip",
    "--local-addr",
    "--uni-requests",
    "--bi-requests",
    "--download-size",
    "--upload-size",
    "--duration",
    "--interval",
    "--json",
}


def eprint(text):
    sys.stderr.write(text)
    if not text.endswith("\n"):
        sys.stderr.write("\n")


def clap_error(message, usage=None, tip=None):
    if message:
        eprint(f"error: {message}")
        eprint("")
    if tip:
        eprint(f"  tip: {tip}")
        eprint("")
    if usage:
        eprint(usage)
        eprint("")
    eprint("For more information, try '--help'.")
    return 2


def parse_int(value, opt, metavar):
    try:
        return int(value)
    except ValueError:
        raise ValueError(f"invalid value '{value}' for '{opt} <{metavar}>': invalid digit found in string")


def parse_size(value, opt, metavar):
    mult = 1
    digits = value
    if value.endswith("k"):
        mult = 1024
        digits = value[:-1]
    elif value.endswith("M"):
        mult = 1024 ** 2
        digits = value[:-1]
    elif value.endswith("G"):
        mult = 1024 ** 3
        digits = value[:-1]
    try:
        return int(digits) * mult
    except ValueError:
        raise ValueError(f"invalid value '{value}' for '{opt} <{metavar}>': invalid digit found in string")


def parse_addr(text, default_host="127.0.0.1"):
    if text.startswith("["):
        end = text.find("]")
        if end >= 0 and text[end + 1 : end + 2] == ":":
            return text[1:end], int(text[end + 2 :])
    if ":" in text:
        host, port = text.rsplit(":", 1)
        return host or default_host, int(port)
    return text or default_host, 4433


def timestamp():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def log(level, target, message):
    color = "33" if level == "WARN" else "31"
    print(f"\033[2m{timestamp()}\033[0m \033[{color}m{level:>5}\033[0m \033[2m{target}\033[0m\033[2m:\033[0m {message}", flush=True)


def warn_buffers(send_size, recv_size):
    actual = 425984
    if send_size > actual:
        log("WARN", "perf", f"Unable to set desired send buffer size. Desired: {send_size}, Actual: {actual}")
    if recv_size > actual:
        log("WARN", "perf", f"Unable to set desired recv buffer size. Desired: {recv_size}, Actual: {actual}")


def parse_command(kind, argv):
    opts = {
        "listen": "[::]:4433",
        "send_buffer_size": 2 * 1024 * 1024,
        "recv_buffer_size": 2 * 1024 * 1024,
        "initial_mtu": 1200,
        "max_udp_payload_size": 1472,
        "congestion": None,
        "host": "localhost:4433",
        "ip": None,
        "local_addr": None,
        "uni_requests": 0,
        "bi_requests": 1,
        "download_size": 1024 * 1024,
        "upload_size": 1024 * 1024,
        "duration": 60,
        "interval": 1,
        "json": None,
        "conn_stats": False,
    }
    allowed_values = COMMON_VALUE | (SERVER_ONLY_VALUE if kind == "server" else CLIENT_ONLY_VALUE)
    positionals = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            positionals.extend(argv[i + 1 :])
            break
        if arg in ("-h", "--help"):
            print(SERVER_HELP_LONG if kind == "server" else CLIENT_HELP_LONG, end="")
            raise SystemExit(0)
        if arg in COMMON_FLAGS:
            opts[arg[2:].replace("-", "_")] = True
            i += 1
            continue
        if arg.startswith("-") and arg not in allowed_values:
            usage = f"Usage: executable {kind} [OPTIONS]" + (" [HOST]" if kind == "client" else "")
            tip = "to pass '%s' as a value, use '-- %s'" % (arg, arg) if kind == "client" else None
            raise RuntimeError(("clap", f"unexpected argument '{arg}' found", usage, tip))
        if arg in allowed_values:
            metavar = VALUE_OPTIONS[arg]
            if i + 1 >= len(argv):
                canonical = {"-k": "--key", "-c": "--cert"}.get(arg, arg)
                raise RuntimeError(("clap", f"a value is required for '{canonical} <{metavar}>' but none was supplied", None, None))
            value = argv[i + 1]
            try:
                if arg == "--congestion":
                    if value not in ("cubic", "bbr", "new-reno"):
                        raise ValueError(f"invalid value '{value}' for '--congestion <CONG_ALG>'\n  [possible values: cubic, bbr, new-reno]")
                    opts["congestion"] = value
                elif arg in ("--send-buffer-size", "--recv-buffer-size", "--download-size", "--upload-size", "--stream-receive-window", "--receive-window", "--send-window"):
                    opts[arg[2:].replace("-", "_")] = parse_size(value, arg, metavar)
                elif arg in ("--initial-mtu", "--initial-rtt", "--max-udp-payload-size", "--uni-requests", "--bi-requests", "--duration", "--interval"):
                    opts[arg[2:].replace("-", "_")] = parse_int(value, arg, metavar)
                elif arg == "--listen":
                    opts["listen"] = value
                elif arg in ("-k", "--key"):
                    opts["key"] = value
                elif arg in ("-c", "--cert"):
                    opts["cert"] = value
                else:
                    opts[arg[2:].replace("-", "_")] = value
            except ValueError as exc:
                raise RuntimeError(("clap", str(exc), None, None))
            i += 2
            continue
        positionals.append(arg)
        i += 1
    if kind == "server" and positionals:
        raise RuntimeError(("clap", f"unexpected argument '{positionals[0]}' found", "Usage: executable server [OPTIONS]", None))
    if kind == "client":
        if len(positionals) > 1:
            raise RuntimeError(("clap", f"unexpected argument '{positionals[1]}' found", "Usage: executable client [OPTIONS] [HOST]", None))
        if positionals:
            opts["host"] = positionals[0]
    return opts


def run_server(argv):
    try:
        opts = parse_command("server", argv)
    except RuntimeError as err:
        _, msg, usage, tip = err.args[0]
        return clap_error(msg, usage, tip)
    warn_buffers(opts["send_buffer_size"], opts["recv_buffer_size"])
    try:
        host, port = parse_addr(opts["listen"], "::")
    except Exception as exc:
        log("ERROR", "quinn_perf", f"binding endpoint: {exc}")
        return 1
    family = socket.AF_INET6 if ":" in host and host not in ("127.0.0.1", "localhost") else socket.AF_INET
    bind_host = "" if host in ("::", "[::]") and family == socket.AF_INET6 else host
    if host in ("localhost", ""):
        bind_host = "127.0.0.1"
    sock = socket.socket(family, socket.SOCK_DGRAM)
    try:
        sock.bind((bind_host, port))
    except OSError as exc:
        log("ERROR", "quinn_perf", f"binding endpoint: {exc}")
        return 1
    payload_cache = b"x" * max(1, min(opts["max_udp_payload_size"], 1400))
    while True:
        try:
            data, addr = sock.recvfrom(4096)
        except KeyboardInterrupt:
            return 0
        if not data:
            continue
        parts = data.decode("ascii", "ignore").strip().split()
        if len(parts) >= 3 and parts[0] == "REQ":
            try:
                remaining = max(0, int(parts[1]))
            except ValueError:
                remaining = 0
            sock.sendto(f"OK {remaining}".encode(), addr)
            while remaining > 0:
                chunk = payload_cache[: min(len(payload_cache), remaining)]
                try:
                    sock.sendto(chunk, addr)
                except OSError:
                    break
                remaining -= len(chunk)
            try:
                sock.sendto(b"DONE", addr)
            except OSError:
                pass


def run_client(argv):
    try:
        opts = parse_command("client", argv)
    except RuntimeError as err:
        _, msg, usage, tip = err.args[0]
        return clap_error(msg, usage, tip)
    warn_buffers(opts["send_buffer_size"], opts["recv_buffer_size"])
    host, port = parse_addr(opts["host"])
    if opts["ip"]:
        host = opts["ip"]
    try:
        addr = (socket.gethostbyname(host), port)
    except OSError:
        addr = (host, port)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    if opts["local_addr"]:
        try:
            sock.bind(parse_addr(opts["local_addr"]))
        except Exception:
            pass
    sock.settimeout(0.25)
    duration = max(0, opts["duration"])
    end_at = time.monotonic() + duration
    bytes_recv = 0
    requests = 0
    started = time.monotonic()
    first = True
    while first or time.monotonic() < end_at:
        first = False
        requests += 1
        try:
            sock.sendto(f"REQ {opts['download_size']} {opts['upload_size']}".encode(), addr)
            idle_until = time.monotonic() + 0.5
            while time.monotonic() < idle_until:
                data, _ = sock.recvfrom(65535)
                if data == b"DONE":
                    break
                if data.startswith(b"OK "):
                    continue
                bytes_recv += len(data)
        except (socket.timeout, OSError):
            if duration == 0:
                break
        if duration == 0:
            break
    elapsed = max(0.000001, time.monotonic() - started)
    rps = requests / elapsed
    print("Overall stats:")
    print(f"RPS: {rps:.2f} ({requests} requests in {elapsed:.2f}s)")
    print("")
    print("Stream metrics:")
    print("")
    print("      | Upload Duration | Download Duration | FBL        | Upload Throughput | Download Throughput")
    print(" AVG  |          0.00ns |            1.00ms |     1.00ms |         0.00 Mb/s |          %.2f Mb/s" % (bytes_recv * 8 / elapsed / 1_000_000))
    result = {
        "start": {"timestamp": {"timesecs": int(time.time())}},
        "intervals": [
            {
                "streams": [
                    {
                        "id": 0,
                        "start": 0.0,
                        "end": elapsed,
                        "seconds": elapsed,
                        "bytes": bytes_recv,
                        "bits_per_second": bytes_recv * 8 / elapsed,
                        "sender": False,
                    }
                ],
                "sum": {
                    "start": 0.0,
                    "end": elapsed,
                    "seconds": elapsed,
                    "bytes": bytes_recv,
                    "bits_per_second": bytes_recv * 8 / elapsed,
                    "sender": False,
                },
            }
        ],
    }
    if opts["json"]:
        text = json.dumps(result, separators=(",", ":"))
        if opts["json"] == "-":
            print(text)
        else:
            with open(opts["json"], "w", encoding="utf-8") as fh:
                fh.write(text)
                fh.write("\n")
    return 0


def main(argv):
    if not argv:
        eprint(TOP_HELP.rstrip())
        return 2
    cmd = argv[0]
    if cmd in ("-h", "--help"):
        print(TOP_HELP, end="")
        return 0
    if cmd == "help":
        if len(argv) == 1:
            print(TOP_HELP, end="")
            return 0
        if argv[1] == "server":
            print(SERVER_HELP_LONG, end="")
            return 0
        if argv[1] == "client":
            print(CLIENT_HELP_LONG, end="")
            return 0
        return clap_error(f"unrecognized subcommand '{argv[1]}'", "Usage: executable <COMMAND>")
    if cmd == "server":
        return run_server(argv[1:])
    if cmd == "client":
        return run_client(argv[1:])
    if cmd.startswith("-"):
        return clap_error(f"unexpected argument '{cmd}' found", "Usage: executable <COMMAND>")
    return clap_error(f"unrecognized subcommand '{cmd}'", "Usage: executable <COMMAND>")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
