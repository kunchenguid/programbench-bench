#!/usr/bin/env python3
import datetime as _dt
import json
import os
import sys

HEADERS = ["MODULE", "VERSION", "NEW VERSION", "DIRECT", "VALID TIMESTAMPS"]


def usage(prog):
    return (f"Usage of {prog}:\n"
            "  -ci\n"
            "    \tNon-zero exit code when at least one outdated dependency was found\n"
            "  -direct\n"
            "    \tList only direct modules\n"
            "  -style string\n"
            "    \tOutput style, pass 'markdown' for a Markdown table (default \"default\")\n"
            "  -update\n"
            "    \tList only modules with updates\n")


def parse_args(argv):
    opts = {"ci": False, "direct": False, "update": False, "style": "default"}
    i = 1
    prog = os.environ.get("GMO_ARGV0") or (argv[0] if argv else "./executable")
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "-help", "--help"):
            sys.stdout.write(usage(prog))
            raise SystemExit(0)
        if a in ("-ci", "--ci"):
            opts["ci"] = True
        elif a in ("-ci=true", "--ci=true"):
            opts["ci"] = True
        elif a in ("-ci=false", "--ci=false"):
            opts["ci"] = False
        elif a in ("-direct", "--direct"):
            opts["direct"] = True
        elif a in ("-direct=true", "--direct=true"):
            opts["direct"] = True
        elif a in ("-direct=false", "--direct=false"):
            opts["direct"] = False
        elif a in ("-update", "--update"):
            opts["update"] = True
        elif a in ("-update=true", "--update=true"):
            opts["update"] = True
        elif a in ("-update=false", "--update=false"):
            opts["update"] = False
        elif a in ("-style", "--style"):
            if i + 1 >= len(argv):
                sys.stderr.write("flag needs an argument: -style\n")
                sys.stderr.write(usage(prog))
                raise SystemExit(2)
            opts["style"] = argv[i + 1]
            i += 1
        elif a.startswith("-style=") or a.startswith("--style="):
            opts["style"] = a.split("=", 1)[1]
        elif a.startswith("-"):
            sys.stderr.write(f"flag provided but not defined: {a}\n")
            sys.stderr.write(usage(prog))
            raise SystemExit(2)
        i += 1
    return opts


def log_error(msg):
    now = _dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    sys.stderr.write(f"{now} {msg}\n")


def load_objects(text):
    dec = json.JSONDecoder()
    pos = 0
    n = len(text)
    objs = []
    while True:
        while pos < n and text[pos].isspace():
            pos += 1
        if pos >= n:
            return objs, None
        try:
            obj, end = dec.raw_decode(text, pos)
        except json.JSONDecodeError as e:
            if pos < n and text[pos] == "{":
                return objs, "unexpected EOF"
            return objs, e.msg
        objs.append(obj)
        pos = end


def parse_go_time(s):
    if not s:
        return None
    try:
        if s.endswith("Z"):
            return _dt.datetime.fromisoformat(s[:-1] + "+00:00")
        return _dt.datetime.fromisoformat(s)
    except Exception:
        return "ERR"


def time_error(s):
    token = s[:4] if len(s) >= 4 else s
    return f'parsing time "{s}" as "2006-01-02T15:04:05Z07:00": cannot parse "{token}" as "2006"'


def make_row(obj):
    path = str(obj.get("Path", ""))
    ver = str(obj.get("Version", ""))
    upd = obj.get("Update") or {}
    newver = str(upd.get("Version", "")) if isinstance(upd, dict) else ""
    direct = not bool(obj.get("Indirect", False))

    valid = True
    if newver:
        cur_time = str(obj.get("Time", "")) if obj.get("Time", "") is not None else ""
        upd_time = str(upd.get("Time", "")) if isinstance(upd, dict) and upd.get("Time", "") is not None else ""
        ct = parse_go_time(cur_time)
        ut = parse_go_time(upd_time)
        if ct == "ERR":
            return None, time_error(cur_time)
        if ut == "ERR":
            return None, time_error(upd_time)
        if ct is not None and ut is not None:
            valid = ut > ct
    return [path, ver, newver, "true" if direct else "false", "true" if valid else "false"], None


def border(widths, markdown=False):
    sep = "|" if markdown else "+"
    return sep + sep.join("-" * (w + 2) for w in widths) + sep


def center_header(text, width):
    pad = width - len(text)
    left = pad // 2
    right = pad - left
    return " " * left + text + " " * right


def render(rows, style):
    if not rows:
        return ""
    widths = [len(h) for h in HEADERS]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))

    lines = []
    markdown = style == "markdown"
    if not markdown:
        lines.append(border(widths, False))
    header_cells = [" " + center_header(HEADERS[i], widths[i]) + " " for i in range(len(HEADERS))]
    lines.append("|" + "|".join(header_cells) + "|")
    lines.append(border(widths, markdown))
    for row in rows:
        cells = [" " + row[i].ljust(widths[i]) + " " for i in range(len(row))]
        lines.append("|" + "|".join(cells) + "|")
    if not markdown:
        lines.append(border(widths, False))
    return "\n".join(lines) + "\n"


def main(argv):
    opts = parse_args(argv)
    text = sys.stdin.read()
    objs, err = load_objects(text)
    if err:
        log_error(err)
        return 0

    rows = []
    any_update_displayed = False
    for obj in objs:
        if not isinstance(obj, dict):
            continue
        row, terr = make_row(obj)
        if terr:
            log_error(terr)
            return 0
        has_update = bool(row[2])
        is_direct = row[3] == "true"
        if opts["direct"] and not is_direct:
            continue
        if opts["update"] and not has_update:
            continue
        rows.append(row)
        if has_update:
            any_update_displayed = True

    out = render(rows, opts["style"])
    if out:
        sys.stdout.write(out)
    return 1 if opts["ci"] and any_update_displayed else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
