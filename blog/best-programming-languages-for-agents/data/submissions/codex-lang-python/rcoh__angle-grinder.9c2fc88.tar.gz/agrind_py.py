#!/usr/bin/env python3
import argparse
import csv
import fnmatch
import json
import math
import os
import re
import shlex
import sys
from collections import OrderedDict, defaultdict, deque
from datetime import datetime, timezone, timedelta


VERSION = "ag 0.19.6"


def split_pipeline(q):
    parts, cur, quote, esc = [], [], None, False
    for ch in q:
        if esc:
            cur.append(ch); esc = False; continue
        if ch == "\\":
            cur.append(ch); esc = True; continue
        if quote:
            cur.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in "'\"":
            quote = ch; cur.append(ch); continue
        if ch == "|":
            parts.append("".join(cur).strip()); cur = []
        else:
            cur.append(ch)
    parts.append("".join(cur).strip())
    return [p for p in parts if p]


def split_top(s, sep=","):
    out, cur, quote, depth, esc = [], [], None, 0, False
    for ch in s:
        if esc:
            cur.append(ch); esc = False; continue
        if ch == "\\":
            cur.append(ch); esc = True; continue
        if quote:
            cur.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in "'\"":
            quote = ch; cur.append(ch); continue
        if ch in "([": depth += 1
        elif ch in ")]": depth -= 1
        if ch == sep and depth == 0:
            out.append("".join(cur).strip()); cur = []
        else:
            cur.append(ch)
    if cur or s.endswith(sep):
        out.append("".join(cur).strip())
    return out


def unquote(s):
    s = s.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "'\"":
        return bytes(s[1:-1], "utf-8").decode("unicode_escape")
    return s


def convert(v):
    if isinstance(v, (int, float, bool)) or v is None:
        return v
    if isinstance(v, (list, dict)):
        return v
    s = str(v)
    if s.lower() == "true": return True
    if s.lower() == "false": return False
    if s.lower() in ("null", "none"): return None
    if re.fullmatch(r"[-+]?\d+", s):
        try: return int(s)
        except Exception: pass
    if re.fullmatch(r"[-+]?(?:\d+\.\d*|\.\d+|\d+e[-+]?\d+|\d+\.\d*e[-+]?\d+)", s, re.I):
        try: return float(s)
        except Exception: pass
    return s


def value_to_str(v):
    if v is None: return "null"
    if v is True: return "true"
    if v is False: return "false"
    if isinstance(v, float):
        if math.isfinite(v) and v.is_integer():
            return str(int(v))
        return f"{v:.2f}" if abs(v) >= 1 and not v.is_integer() else str(v)
    if isinstance(v, list):
        return "[" + ", ".join(value_to_str(x) for x in v) + "]"
    if isinstance(v, dict):
        return json.dumps(v, separators=(",", ":"))
    if isinstance(v, datetime):
        return v.isoformat()
    return str(v)


def get_field(row, path):
    path = path.strip()
    if path.startswith('["') and path.endswith('"]'):
        path = path[2:-2]
    if not path:
        return None
    cur = row
    for name, idx in re.findall(r"([A-Za-z_][\w.-]*|\[[^\]]+\])(?:\[(-?\d+)\])?", path):
        if name.startswith("["):
            key = name[1:-1].strip("'\"")
        else:
            key = name
        if isinstance(cur, dict):
            cur = cur.get(key)
        else:
            return None
        if idx != "":
            try:
                cur = cur[int(idx)]
            except Exception:
                return None
    return cur


def set_field(row, key, val):
    row[key.strip()] = val


class Expr:
    def __init__(self, text):
        self.text = text.strip()

    def eval(self, row):
        return eval_expr(self.text, row)


def transform_if(expr):
    # Python keyword workaround for if(cond,a,b) expressions.
    return re.sub(r"\bif\s*\(", "iif(", expr)


def eval_expr(expr, row):
    expr = expr.strip()
    if not expr:
        return None
    if re.fullmatch(r"[A-Za-z_][\w.\[\]\"-]*", expr) and not expr in ("true", "false", "null"):
        return get_field(row, expr)
    env = {
        "abs": abs, "acos": math.acos, "asin": math.asin, "atan": math.atan,
        "atan2": math.atan2, "cbrt": lambda x: math.copysign(abs(float(x)) ** (1/3), float(x)),
        "ceil": math.ceil, "cos": math.cos, "cosh": math.cosh, "exp": math.exp,
        "expm1": math.expm1, "floor": math.floor, "hypot": math.hypot,
        "log": math.log, "log10": math.log10, "log1p": math.log1p, "round": round,
        "sin": math.sin, "sinh": math.sinh, "sqrt": math.sqrt, "tan": math.tan,
        "tanh": math.tanh, "toDegrees": math.degrees, "toRadians": math.radians,
        "concat": lambda *a: "".join(value_to_str(x) for x in a),
        "contains": lambda h, n: str(n) in str(h),
        "length": lambda s: len(s) if s is not None else 0,
        "now": lambda: datetime.now(timezone.utc),
        "num": lambda v: float(v) if v is not None and str(v) != "" else None,
        "parseHex": lambda s: int(str(s), 16),
        "substring": lambda s, a, b=None: str(s)[int(a): None if b is None else int(b)],
        "toLowerCase": lambda s: str(s).lower(),
        "toUpperCase": lambda s: str(s).upper(),
        "isNull": lambda v: v is None,
        "isEmpty": lambda v: v is None or v == "",
        "isBlank": lambda v: v is None or str(v).strip() == "",
        "isNumeric": lambda s: isinstance(convert(s), (int, float)) and not isinstance(convert(s), bool),
        "iif": lambda c, a, b: a if c else b,
        "true": True, "false": False, "null": None,
        "True": True, "False": False, "None": None,
    }
    def repl(m):
        name = m.group(0)
        if name in env or name in ("and", "or", "not") or re.fullmatch(r"\d+", name):
            return name
        return f"__field({name!r})"
    py = transform_if(expr).replace("&&", " and ").replace("||", " or ")
    py = re.sub(r"(?<![=!<>])!(?!=)", " not ", py)
    py = re.sub(r"\btrue\b", "True", py, flags=re.I)
    py = re.sub(r"\bfalse\b", "False", py, flags=re.I)
    py = re.sub(r"\bnull\b", "None", py, flags=re.I)
    # Keep strings intact while replacing identifiers outside them.
    toks, out, pos = [], [], 0
    for m in re.finditer(r"'(?:\\.|[^'])*'|\"(?:\\.|[^\"])*\"", py):
        out.append(re.sub(r"\b[A-Za-z_][\w.\[\]\"-]*\b", repl, py[pos:m.start()]))
        out.append(m.group(0)); pos = m.end()
    out.append(re.sub(r"\b[A-Za-z_][\w.\[\]\"-]*\b", repl, py[pos:]))
    py = "".join(out)
    env["__field"] = lambda n: get_field(row, n)
    try:
        return eval(py, {"__builtins__": {}}, env)
    except Exception:
        # Fallback: literal or field
        if (expr.startswith('"') and expr.endswith('"')) or (expr.startswith("'") and expr.endswith("'")):
            return unquote(expr)
        return get_field(row, expr)


def parse_logfmt(s):
    try:
        toks = shlex.split(s, posix=True)
    except Exception:
        return None
    out = OrderedDict()
    for tok in toks:
        if "=" not in tok:
            return None
        k, v = tok.split("=", 1)
        if not k:
            return None
        out[k] = convert(v)
    return out


def flatten_json(obj, prefix="", out=None):
    if out is None: out = OrderedDict()
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            if isinstance(v, dict):
                out[key] = v
                flatten_json(v, key, out)
            else:
                out[key] = v
    else:
        out["_raw"] = obj
    return out


def wildcard_regex(pattern):
    star_count = pattern.count("*")
    seen = 0
    res = []
    for ch in pattern:
        if ch == "*":
            seen += 1
            res.append("(.*)" if seen == star_count else "(.*?)")
        else: res.append(re.escape(ch))
    return "".join(res)


def op_parse(rows, op):
    m = re.match(r'parse\s+regex\s+(".*?"|\'.*?\')\s*(.*)$', op, re.S)
    if m:
        rgx, rest = unquote(m.group(1)), m.group(2)
        fm = re.search(r"\bfrom\s+([^\s]+)", rest)
        nodrop = "nodrop" in rest
        cre = re.compile(rgx)
        out = []
        for row in rows:
            text = value_to_str(get_field(row, fm.group(1)) if fm else row.get("_raw", ""))
            mm = cre.search(text)
            if mm:
                nr = OrderedDict(row); nr.update({k: convert(v) for k, v in mm.groupdict().items()}); out.append(nr)
            elif nodrop:
                out.append(row)
        return out
    m = re.match(r'parse\s+(".*?"|\'.*?\')\s*(.*)$', op, re.S)
    if not m: return rows
    pat, rest = unquote(m.group(1)), m.group(2)
    fm = re.search(r"\bfrom\s+([^\s]+)", rest)
    am = re.search(r"\bas\s+(.+?)(?:\s+nodrop|\s+noconvert|$)", rest)
    names = [x.strip() for x in split_top(am.group(1))] if am else []
    nodrop = "nodrop" in rest
    noconv = "noconvert" in rest
    rgx = wildcard_regex(pat).replace(r"\ ", r"\s+")
    cre = re.compile(rgx, re.S)
    out = []
    for row in rows:
        text = value_to_str(get_field(row, fm.group(1)) if fm else row.get("_raw", ""))
        mm = cre.search(text)
        if mm:
            nr = OrderedDict(row)
            for name, val in zip(names, mm.groups()):
                nr[name] = val if noconv else convert(val)
            out.append(nr)
        elif nodrop:
            out.append(row)
    return out


def op_split(rows, op):
    m = re.match(r"split(?:\(([^)]+)\))?(?:\s+on\s+((?:\".*?\")|(?:'.*?')|[^\s]+))?(?:\s+as\s+([^\s]+))?", op)
    src = m.group(1) if m else None
    sep = unquote(m.group(2)) if m and m.group(2) else ","
    dst = m.group(3) if m and m.group(3) else (src if src else "_split")
    out = []
    for row in rows:
        text = value_to_str(get_field(row, src) if src else row.get("_raw", ""))
        nr = OrderedDict(row)
        if sep == "":
            nr[dst] = list(text)
        elif sep == " ":
            try:
                nr[dst] = next(csv.reader([text], delimiter=" ", skipinitialspace=True))
            except Exception:
                nr[dst] = text.split()
        else:
            nr[dst] = text.split(sep)
        out.append(nr)
    return out


def op_fields(rows, op):
    rest = op[len("fields"):].strip()
    mode = "except"
    if rest.startswith(("only ", "+ ")):
        mode = "only"; rest = re.sub(r"^(only|\+)\s+", "", rest)
    elif rest.startswith(("except ", "- ")):
        mode = "except"; rest = re.sub(r"^(except|-)\s+", "", rest)
    fields = [x.strip() for x in split_top(rest) if x.strip()]
    out = []
    for row in rows:
        nr = OrderedDict()
        if mode == "only":
            for f in fields:
                if f in row: nr[f] = row[f]
        else:
            for k, v in row.items():
                if k not in fields and k != "_raw": nr[k] = v
        out.append(nr)
    return out


def aggregate(rows, op):
    by = []
    if re.search(r"\s+by\s+", op):
        left, bys = re.split(r"\s+by\s+", op, 1)
        by = [b.strip() for b in split_top(bys) if b.strip()]
    else:
        left = op
    specs = [s.strip() for s in split_top(left) if s.strip()]
    groups = OrderedDict()
    for row in rows:
        key = tuple(eval_expr(b, row) for b in by)
        groups.setdefault(key, []).append(row)
    if not groups:
        groups[tuple()] = []
    out = []
    for key, grows in groups.items():
        nr = OrderedDict()
        for b, val in zip(by, key):
            nr[b] = val
        for spec in specs:
            alias = None
            if re.search(r"\s+as\s+", spec):
                spec, alias = re.split(r"\s+as\s+", spec, 1)
                alias = alias.strip()
            name = spec.strip()
            lm = name.lower()
            col = None
            fun = lm
            mm = re.match(r"([A-Za-z_]\w*|p\d+|pct\d+)\((.*)\)$", name)
            if mm:
                fun = mm.group(1).lower(); col = mm.group(2).strip()
            elif lm.startswith("count "):
                fun = "count"; col = name[6:].strip()
            vals = [eval_expr(col, r) for r in grows] if col else []
            nums = [float(v) for v in vals if isinstance(convert(v), (int, float)) and not isinstance(convert(v), bool)]
            if fun == "count":
                if col:
                    val = sum(1 for r in grows if bool(eval_expr(col, r)))
                else:
                    val = len(grows)
                outname = alias or "_count"
            elif fun == "sum":
                val = sum(nums); outname = alias or "_sum"
            elif fun in ("average", "avg"):
                val = (sum(nums) / len(nums)) if nums else None; outname = alias or "_average"
            elif fun == "min":
                val = min(nums) if nums else None; outname = alias or "_min"
            elif fun == "max":
                val = max(nums) if nums else None; outname = alias or "_max"
            elif fun.startswith("p") or fun.startswith("pct"):
                pct = int(re.sub(r"\D", "", fun) or "50")
                nums.sort()
                if nums:
                    idx = int(math.ceil((pct / 100.0) * len(nums))) - 1
                    idx = max(0, min(idx, len(nums)-1))
                    val = nums[idx]
                else:
                    val = None
                outname = alias or f"_{fun}"
            elif fun == "count_distinct":
                val = len(set(value_to_str(v) for v in vals)); outname = alias or "_count_distinct"
            else:
                continue
            nr[outname] = int(val) if isinstance(val, float) and val.is_integer() else val
        out.append(nr)
    if by:
        out.sort(key=lambda r: tuple(value_to_str(r.get(b)) for b in by))
    return out


def sort_rows(rows, op):
    m = re.match(r"sort\s+by\s+(.+?)(?:\s+(asc|desc))?$", op, re.I)
    if not m: return rows
    exprs = [x.strip() for x in split_top(m.group(1))]
    rev = (m.group(2) or "asc").lower() == "desc"
    return sorted(rows, key=lambda r: tuple(eval_expr(e, r) for e in exprs), reverse=rev)


def apply_filter(lines, filt):
    filt = filt.strip()
    if not filt or filt == "*":
        return lines
    def match_line(line):
        expr = filt
        # Simple support for AND/OR/NOT and parentheses.
        tokens = re.findall(r'"[^"]*"|\(|\)|\bAND\b|\bOR\b|\bNOT\b|[^\s()]+', expr, re.I)
        py = []
        vals = []
        for t in tokens:
            u = t.upper()
            if u in ("AND", "OR", "NOT"):
                py.append(u.lower())
            elif t in ("(", ")"):
                py.append(t)
            else:
                idx = len(vals); vals.append(t)
                py.append(f"m({idx})")
        def m(i):
            pat = vals[i]
            if len(pat) >= 2 and pat[0] == pat[-1] == '"':
                return pat[1:-1] in line
            return fnmatch.fnmatch(line.lower(), pat.lower())
        try:
            return bool(eval(" ".join(py), {"__builtins__": {}}, {"m": m}))
        except Exception:
            return m(0) if vals else True
    return [ln for ln in lines if match_line(ln)]


def run_query(lines, query):
    parts = split_pipeline(query or "*")
    filt = parts[0] if parts else "*"
    lines = apply_filter(lines, filt)
    rows = [OrderedDict([("_raw", ln.rstrip("\n"))]) for ln in lines]
    for op in parts[1:]:
        low = op.lower().strip()
        if low.startswith("json"):
            fm = re.search(r"\bfrom\s+([^\s]+)", op)
            out = []
            for row in rows:
                text = value_to_str(get_field(row, fm.group(1)) if fm else row.get("_raw", ""))
                try:
                    obj = json.loads(text)
                except Exception:
                    continue
                nr = OrderedDict((k, v) for k, v in row.items() if k != "_raw")
                nr.update(flatten_json(obj))
                out.append(nr)
            rows = out
        elif low.startswith("logfmt"):
            fm = re.search(r"\bfrom\s+([^\s]+)", op)
            out = []
            for row in rows:
                text = value_to_str(get_field(row, fm.group(1)) if fm else row.get("_raw", ""))
                parsed = parse_logfmt(text)
                if parsed is None: continue
                nr = OrderedDict((k, v) for k, v in row.items() if k != "_raw")
                nr.update(parsed); out.append(nr)
            rows = out
        elif low.startswith("parse "):
            rows = op_parse(rows, op)
        elif low.startswith("split"):
            rows = op_split(rows, op)
        elif low.startswith("fields"):
            rows = op_fields(rows, op)
        elif low.startswith("where "):
            expr = op[6:].strip()
            rows = [r for r in rows if bool(eval_expr(expr, r))]
        elif low.startswith("limit"):
            n = int(op.split()[1])
            rows = rows[:n] if n >= 0 else rows[n:]
        elif low.startswith("sort by"):
            rows = sort_rows(rows, op)
        elif re.match(r"^(count|sum|average|avg|min|max|p\d+|pct\d+|count_distinct|total)\b", low):
            rows = aggregate(rows, op)
        elif re.search(r"\s+as\s+", op):
            expr, name = re.split(r"\s+as\s+", op, 1)
            for r in rows:
                r[name.strip()] = eval_expr(expr, r)
        elif low.startswith("timeslice"):
            # Minimal support: pass through computed value under _timeslice.
            m = re.match(r"timeslice\((.*?)\)\s+(\d+)([a-z]+)(?:\s+as\s+(\S+))?", op)
            if m:
                expr, amount, unit, dst = m.groups(); dst = dst or "_timeslice"
                for r in rows: r[dst] = eval_expr(expr, r)
        elif low.startswith("total"):
            m = re.match(r"total\((.*?)\)(?:\s+as\s+(\S+))?", op)
            if m:
                expr, dst = m.groups(); dst = dst or "_total"; acc = 0
                for r in rows:
                    v = convert(eval_expr(expr, r))
                    if isinstance(v, (int, float)): acc += v
                    r[dst] = acc
    return rows


def discover_alias_dirs(start, explicit=None):
    if explicit:
        return [explicit]
    dirs = []
    cur = os.path.abspath(start)
    while True:
        cand = os.path.join(cur, ".agrind-aliases")
        if os.path.isdir(cand):
            dirs.append(cand)
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return dirs


def load_aliases(start=".", explicit=None):
    aliases = {}
    for d in discover_alias_dirs(start, explicit):
        for name in sorted(os.listdir(d)):
            path = os.path.join(d, name)
            if not os.path.isfile(path):
                continue
            try:
                txt = open(path, "r", encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            km = re.search(r'keyword\s*=\s*("([^"]+)"|\'([^\']+)\')', txt)
            tm = re.search(r'template\s*=\s*"""(.*?)"""', txt, re.S)
            if not tm:
                tm = re.search(r"template\s*=\s*'''(.*?)'''", txt, re.S)
            if not tm:
                tm = re.search(r'template\s*=\s*("([^"]*)"|\'([^\']*)\')', txt, re.S)
            if km and tm:
                key = km.group(2) or km.group(3)
                val = tm.group(1)
                if val.startswith(("'", '"')) and len(tm.groups()) > 1:
                    val = tm.group(2) or tm.group(3) or val
                aliases[key.strip()] = val.strip()
    return aliases


def expand_aliases(query, aliases):
    if not aliases:
        return query
    parts = split_pipeline(query or "*")
    expanded = []
    for i, part in enumerate(parts):
        key = part.strip()
        if i > 0 and key in aliases:
            expanded.extend(split_pipeline(aliases[key]))
        else:
            expanded.append(part)
    return " | ".join(expanded)


def render_legacy(rows, aggregate_mode=False):
    if not rows:
        return ""
    if aggregate_mode:
        cols = list(rows[0].keys())
        widths = {c: max(len(c), *(len(value_to_str(r.get(c))) for r in rows)) for c in cols}
        line = "        ".join(c.ljust(widths[c]) for c in cols).rstrip()
        sep = "-" * max(27, len(line))
        body = ["        ".join(value_to_str(r.get(c)).ljust(widths[c]) for c in cols).rstrip() for r in rows]
        return "\n".join([line, sep] + body) + "\n"
    out = []
    for r in rows:
        items = [(k, v) for k, v in sorted(r.items()) if k != "_raw"]
        if not items and "_raw" in r:
            out.append(r["_raw"])
        else:
            out.append("        ".join(f"[{k}={value_to_str(v)}]" for k, v in items))
    return "\n".join(out) + ("\n" if out else "")


def render(rows, mode, fmt=None, aggregate_mode=False):
    if mode == "json":
        return "".join(json.dumps({k: v for k, v in r.items() if k != "_raw"}, default=value_to_str, separators=(",", ":")) + "\n" for r in rows)
    if mode == "logfmt":
        lines = []
        for r in rows:
            parts = []
            for k, v in sorted(r.items()):
                if k == "_raw": continue
                s = value_to_str(v)
                if re.search(r"\s", s): s = json.dumps(s)
                parts.append(f"{k}={s}")
            lines.append(" ".join(parts))
        return "\n".join(lines) + ("\n" if lines else "")
    if mode == "format":
        lines = []
        for r in rows:
            def repl(m): return value_to_str(get_field(r, m.group(1)))
            lines.append(re.sub(r"\{([^{}]+)\}", repl, fmt or ""))
        return "\n".join(lines) + ("\n" if lines else "")
    return render_legacy(rows, aggregate_mode)


def main(argv=None):
    parser = argparse.ArgumentParser(add_help=False, usage="executable [OPTIONS] [QUERY]")
    parser.add_argument("-f", "--file")
    parser.add_argument("-m", "--format")
    parser.add_argument("-o", "--output", default="legacy")
    parser.add_argument("-a", "--alias-dir")
    parser.add_argument("--no-alias", action="store_true")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("query", nargs="?")
    args = parser.parse_args(argv)
    if args.help:
        print("Usage: executable [OPTIONS] [QUERY]\n\nArguments:\n  [QUERY]  The query\n\nOptions:\n  -f, --file <FILE>            Optionally reads from a file instead of Stdin\n  -m, --format <FORMAT>        DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output\n  -o, --output <OUTPUT>        Set output format. One of (json|legacy|format=<rust fmt str>|logfmt)\n  -a, --alias-dir <ALIAS_DIR>  Specifies an alternative directory to use for aliases. Defaults to `.agrind-aliases` in all parent directories.\n      --no-alias               Disables aliases\n  -h, --help                   Print help (see more with '--help')\n  -V, --version                Print version\n\nFor more details + docs, see https://github.com/rcoh/angle-grinder")
        return 0
    if args.version:
        print(VERSION); return 0
    if args.file:
        with open(args.file, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    else:
        lines = sys.stdin.readlines()
    query = args.query or "*"
    if not args.no_alias:
        query = expand_aliases(query, load_aliases(os.getcwd(), args.alias_dir))
    rows = run_query(lines, query)
    outopt = args.output
    mode, fmt = "legacy", None
    if args.format:
        mode, fmt = "format", args.format
    elif outopt == "json":
        mode = "json"
    elif outopt == "logfmt":
        mode = "logfmt"
    elif outopt.startswith("format="):
        mode, fmt = "format", outopt[len("format="):]
    aggregate_mode = any(re.match(r"^(count|sum|average|avg|min|max|p\d+|pct\d+|count_distinct)\b", p.strip().lower()) for p in split_pipeline(query)[1:])
    sys.stdout.write(render(rows, mode, fmt, aggregate_mode))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
