#!/usr/bin/env python3
import os
import select
import signal
import stat
import subprocess
import sys
import termios
import time


RELEASE = "5.7"
USAGE = "usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames"


def prog():
    return os.path.basename(sys.argv[0]) or "entr"


def print_usage_hint():
    print(f"release: {RELEASE}", file=sys.stderr)
    print(USAGE, file=sys.stderr)
    print("hint: use -h to display option summary", file=sys.stderr)


def print_help():
    print(f"release: {RELEASE}", file=sys.stderr)
    print(USAGE, file=sys.stderr)
    print("summary:", file=sys.stderr)
    print("    -a  Do not consolidate events", file=sys.stderr)
    print("    -c  Clear screen before execution", file=sys.stderr)
    print("    -d  Track files added or removed from directories", file=sys.stderr)
    print("    -n  Non-interactive mode", file=sys.stderr)
    print("    -p  Wait for first event", file=sys.stderr)
    print("    -r  Run as a background process, use signal to restart", file=sys.stderr)
    print("    -s  Evaluate using a shell", file=sys.stderr)
    print("    -x  Format exit status", file=sys.stderr)
    print("    -z  Exit after the utility completes", file=sys.stderr)
    print("docs:", file=sys.stderr)
    print("    man entr", file=sys.stderr)


def parse_args(argv):
    opts = {
        "a": 0, "c": 0, "d": 0, "n": 0, "p": 0,
        "r": 0, "s": 0, "x": 0, "z": 0,
    }
    i = 0
    while i < len(argv) and argv[i].startswith("-") and argv[i] != "-":
        arg = argv[i]
        if arg == "--":
            print(f"{sys.argv[0]}: invalid option -- '-'", file=sys.stderr)
            print_usage_hint()
            sys.exit(1)
        if arg == "-h":
            print_help()
            sys.exit(1)
        for ch in arg[1:]:
            if ch in opts:
                opts[ch] += 1
            elif ch == "h" and len(arg) > 2:
                opts.setdefault("h", 0)
                print_help()
                sys.exit(1)
            else:
                print(f"{sys.argv[0]}: invalid option -- '{ch}'", file=sys.stderr)
                print_usage_hint()
                sys.exit(1)
        i += 1
    cmd = argv[i:]
    if not cmd:
        print_usage_hint()
        sys.exit(1)
    if opts["s"] and len(cmd) != 1:
        print(f"{prog()}: -s requires commands to be formatted as a single argument", file=sys.stderr)
        sys.exit(1)
    return opts, cmd


def read_watch_list():
    files = []
    for line in sys.stdin:
        name = line.rstrip("\n")
        if name:
            files.append(name)
    return files


def valid_file(path):
    try:
        st = os.stat(path) if os.environ.get("ENTR_FOLLOW_SYMLINK") else os.lstat(path)
    except OSError:
        print(f"{prog()}: unable to stat '{path}'", file=sys.stderr)
        return False
    return stat.S_ISREG(st.st_mode) or stat.S_ISDIR(st.st_mode)


def build_watch(files, d_count):
    watched = []
    dirs = set()
    for path in files:
        if valid_file(path):
            watched.append(path)
            try:
                st = os.stat(path)
                if stat.S_ISREG(st.st_mode) and d_count:
                    parent = os.path.dirname(path) or "."
                    dirs.add(parent)
                elif stat.S_ISDIR(st.st_mode):
                    dirs.add(path)
            except OSError:
                pass
    if not watched:
        print(f"{prog()}: No regular files to watch", file=sys.stderr)
        sys.exit(1)
    return watched, sorted(dirs)


def file_state(path):
    try:
        st = os.stat(path)
        return (st.st_mtime_ns, st.st_size, st.st_ino)
    except OSError:
        return None


def dir_state(path, include_hidden):
    try:
        entries = []
        with os.scandir(path) as it:
            for ent in it:
                if not include_hidden and ent.name.startswith("."):
                    continue
                try:
                    st = ent.stat(follow_symlinks=True)
                    entries.append((ent.name, st.st_mtime_ns, st.st_size, st.st_ino))
                except OSError:
                    entries.append((ent.name, None, None, None))
        return tuple(sorted(entries))
    except OSError:
        return None


def snapshot(files, dirs, include_hidden):
    return {
        "files": {p: file_state(p) for p in files},
        "dirs": {p: dir_state(p, include_hidden) for p in dirs},
    }


def diff_snapshot(old, new):
    for p, st in new["files"].items():
        if old["files"].get(p) != st:
            return p, False
    for p, st in new["dirs"].items():
        if old["dirs"].get(p) != st:
            return p, True
    return None, False


def clear_screen(count):
    if count >= 2:
        sys.stdout.write("\033[2J\033[3J\033[H")
    elif count == 1:
        sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


def restart_signal():
    name = os.environ.get("ENTR_RESTART_SIGNAL", "TERM").upper()
    if name.startswith("SIG"):
        name = name[3:]
    return {
        "HUP": signal.SIGHUP,
        "INT": signal.SIGINT,
        "QUIT": signal.SIGQUIT,
        "TERM": signal.SIGTERM,
        "USR1": signal.SIGUSR1,
        "USR2": signal.SIGUSR2,
    }.get(name, signal.SIGTERM)


def make_command(cmd, opts, trigger):
    if opts["s"]:
        shell = os.environ.get("SHELL", "/bin/sh")
        return [shell, "-c", cmd[0], trigger]
    out = list(cmd)
    try:
        idx = out.index("/_")
        out[idx] = trigger
    except ValueError:
        pass
    return out


def run_once(cmd, opts, trigger):
    clear_screen(opts["c"])
    env = os.environ.copy()
    env.setdefault("PAGER", "/bin/cat")
    argv = make_command(cmd, opts, trigger)
    try:
        p = subprocess.Popen(argv, env=env)
        return p.wait()
    except FileNotFoundError:
        print(f"{prog()}: exec {argv[0]}: No such file or directory", file=sys.stderr)
        return 1
    except PermissionError:
        print(f"{prog()}: exec {argv[0]}: Permission denied", file=sys.stderr)
        return 1


def start_persistent(cmd, opts, trigger):
    clear_screen(opts["c"])
    env = os.environ.copy()
    env.setdefault("PAGER", "/bin/cat")
    argv = make_command(cmd, opts, trigger)
    try:
        return subprocess.Popen(argv, env=env, start_new_session=True)
    except FileNotFoundError:
        print(f"{prog()}: exec {argv[0]}: No such file or directory", file=sys.stderr)
        return None
    except PermissionError:
        print(f"{prog()}: exec {argv[0]}: Permission denied", file=sys.stderr)
        return None


def stop_child(child):
    if child is None or child.poll() is not None:
        return None
    sig = restart_signal()
    try:
        os.killpg(child.pid, sig)
    except OSError:
        try:
            child.terminate()
        except OSError:
            pass
    try:
        child.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except OSError:
            pass
        child.wait()
    return child.returncode


def tty_available(opts):
    if opts["n"]:
        return True
    try:
        fd = os.open("/dev/tty", os.O_RDONLY | os.O_NONBLOCK)
        termios.tcgetattr(fd)
        os.close(fd)
        return True
    except OSError:
        print(f"{prog()}: unable to get terminal attributes, use '-n' to run non-interactively", file=sys.stderr)
        return False


def stdin_key_ready(opts):
    if opts["n"]:
        return None
    try:
        r, _, _ = select.select([sys.stdin], [], [], 0)
        if r:
            return sys.stdin.read(1)
    except Exception:
        return None
    return None


def main():
    opts, cmd = parse_args(sys.argv[1:])
    files = read_watch_list()
    watched, dirs = build_watch(files, opts["d"])
    if not tty_available(opts):
        sys.exit(1)

    default_trigger = watched[0]
    include_hidden = opts["d"] >= 2

    if not opts["p"]:
        if opts["r"]:
            child = start_persistent(cmd, opts, default_trigger)
            if child is None:
                sys.exit(1)
            if opts["z"]:
                rc = child.wait()
                sys.exit(rc if rc >= 0 else 128 - rc)
        else:
            rc = run_once(cmd, opts, default_trigger)
            if opts["z"]:
                sys.exit(rc if rc >= 0 else 128 - rc)
            child = None
    else:
        child = None

    prev = snapshot(watched, dirs, include_hidden)
    pending = None
    try:
        while True:
            key = stdin_key_ready(opts)
            event_path = None
            dir_event = False
            if key == "q":
                stop_child(child)
                sys.exit(0)
            if key == " ":
                event_path = default_trigger

            cur = snapshot(watched, dirs, include_hidden)
            changed, dir_changed = diff_snapshot(prev, cur)
            if changed:
                event_path = changed
                dir_event = dir_changed
                prev = cur
            if dir_event and opts["d"]:
                stop_child(child)
                sys.exit(2)

            if event_path:
                pending = event_path
                if opts["r"]:
                    stop_child(child)
                    child = start_persistent(cmd, opts, pending)
                    if child is None:
                        sys.exit(1)
                    if opts["z"]:
                        rc = child.wait()
                        sys.exit(rc if rc >= 0 else 128 - rc)
                    pending = None
                elif child is None:
                    rc = run_once(cmd, opts, pending)
                    pending = None
                    if opts["z"]:
                        sys.exit(rc if rc >= 0 else 128 - rc)

            if child is not None and child.poll() is not None:
                child = None
                if pending and opts["a"]:
                    rc = run_once(cmd, opts, pending)
                    pending = None
                    if opts["z"]:
                        sys.exit(rc if rc >= 0 else 128 - rc)
            time.sleep(0.1)
    except KeyboardInterrupt:
        stop_child(child)
        sys.exit(0)


if __name__ == "__main__":
    main()
