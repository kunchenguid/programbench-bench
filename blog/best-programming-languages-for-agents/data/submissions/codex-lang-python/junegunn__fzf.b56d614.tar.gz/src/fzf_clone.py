#!/usr/bin/env python3
import os
import re
import shlex
import subprocess
import sys
import unicodedata
from dataclasses import dataclass


VERSION = "0.68.0 (5676da4a)"

HELP = """fzf is an interactive filter program for any kind of list.

It implements a "fuzzy" matching algorithm, so you can quickly type in patterns
with omitted characters and still get the results you want.

Project URL: https://github.com/junegunn/fzf
Author: Junegunn Choi <junegunn.c@gmail.com>

* See man page for more information: fzf --man

Usage: fzf [options]

  SEARCH
    -e, --exact              Enable exact-match
    +x, --no-extended        Disable extended-search mode
    -i, --ignore-case        Case-insensitive match
    +i, --no-ignore-case     Case-sensitive match
        --smart-case         Smart-case match (default)
    --scheme=SCHEME          Scoring scheme [default|path|history]
    -n, --nth=N[,..]         Comma-separated list of field index expressions
    --with-nth=N[,..]        Transform the presentation of each line
    --accept-nth=N[,..]      Define which fields to print on accept
    -d, --delimiter=STR      Field delimiter regex (default: AWK-style)
    +s, --no-sort            Do not sort the result
    --literal                Do not normalize latin script letters
    --tail=NUM               Maximum number of items to keep in memory
    --disabled               Do not perform search

  INPUT/OUTPUT
    --read0                  Read input delimited by ASCII NUL characters
    --print0                 Print output delimited by ASCII NUL characters
    --ansi                   Enable processing of ANSI color codes
    --sync                   Synchronous search for multi-staged filtering

  SCRIPTING
    -q, --query=STR          Start the finder with the given query
    -1, --select-1           Automatically select the only match
    -0, --exit-0             Exit immediately when there's no match
    -f, --filter=STR         Print matches for the initial query and exit
    --print-query            Print query as the first line
    --expect=KEYS            Comma-separated list of keys to complete fzf

  HELP
    --version                Display version information and exit
    --help                   Show this message
    --man                    Show man page

  ENVIRONMENT VARIABLES
    FZF_DEFAULT_COMMAND      Default command to use when input is tty
    FZF_DEFAULT_OPTS         Default options
    FZF_DEFAULT_OPTS_FILE    Location of the file to read default options from
    FZF_API_KEY              X-API-Key header for HTTP server (--listen)
"""


@dataclass
class Options:
    filter_query: str | None = None
    query: str = ""
    print_query: bool = False
    read0: bool = False
    print0: bool = False
    ignore_case: str = "smart"
    exact: bool = False
    extended: bool = True
    sort: bool = True
    delimiter: str | None = None
    nth: str | None = None
    with_nth: str | None = None
    accept_nth: str | None = None
    header_lines: int = 0
    tac: bool = False
    tail: int | None = None
    ansi: bool = False
    disabled: bool = False
    scheme: str = "default"
    tiebreak: str = "length"
    select_1: bool = False
    exit_0: bool = False


KNOWN_VALUE = {
    "-f", "--filter", "-q", "--query", "-n", "--nth", "--with-nth", "--accept-nth",
    "-d", "--delimiter", "--scheme", "--tiebreak", "--height", "--min-height",
    "--tmux", "--layout", "--margin", "--padding", "--border", "--border-label",
    "--border-label-pos", "--multi", "-m", "--preview", "--preview-window",
    "--preview-border", "--preview-label", "--preview-label-pos", "--header",
    "--header-lines", "--footer", "--footer-border", "--footer-label",
    "--footer-label-pos", "--bind", "--color", "--style", "--prompt", "--info",
    "--info-command", "--separator", "--ghost", "--input-border", "--input-label",
    "--input-label-pos", "--header-border", "--header-lines-border",
    "--header-label", "--header-label-pos", "--list-border", "--list-label",
    "--list-label-pos", "--gap", "--gap-line", "--freeze-left", "--freeze-right",
    "--scroll-off", "--hscroll-off", "--jump-labels", "--gutter", "--gutter-raw",
    "--pointer", "--marker", "--marker-multi-line", "--ellipsis", "--tabstop",
    "--scrollbar", "--with-shell", "--listen", "--walker", "--walker-root",
    "--walker-skip", "--history", "--history-size", "--expect", "--algo",
    "--tty-default",
}

KNOWN_FLAG = {
    "--help", "--version", "--man", "-e", "--exact", "-x", "--extended", "+x",
    "--no-extended", "-i", "--ignore-case", "+i", "--no-ignore-case",
    "--smart-case", "+s", "--no-sort", "--read0", "--print0", "--ansi", "--sync",
    "--literal", "--disabled", "--no-color", "--no-bold", "--highlight-line",
    "--cycle", "--wrap", "--no-multi-line", "--raw", "--track", "--tac",
    "--keep-right", "--no-hscroll", "--no-scrollbar", "--no-input",
    "--no-separator", "--filepath-word", "--header-first", "-1", "--select-1",
    "-0", "--exit-0", "--bash", "--zsh", "--fish", "--no-tty-default",
}

OPTIONAL_VALUE = {
    "--border", "--multi", "-m", "--gap", "--gap-line", "--scrollbar",
    "--list-border", "--input-border", "--header-border",
    "--header-lines-border", "--footer-border", "--preview-border",
    "--tmux", "--listen", "--color",
}


def eprint(msg: str) -> int:
    sys.stderr.write(msg + "\n")
    return 2


def shell_words(s: str) -> list[str]:
    try:
        return shlex.split(s)
    except ValueError:
        return s.split()


def expand_args(argv: list[str]) -> list[str]:
    out: list[str] = []
    file_name = os.environ.get("FZF_DEFAULT_OPTS_FILE")
    if file_name:
        try:
            with open(file_name, "r", encoding="utf-8") as f:
                out += shell_words(f.read())
        except OSError:
            pass
    if os.environ.get("FZF_DEFAULT_OPTS"):
        out += shell_words(os.environ["FZF_DEFAULT_OPTS"])
    out += argv
    return out


def parse(argv: list[str]) -> tuple[Options | None, int | None]:
    opt = Options()
    argv = expand_args(argv)
    i = 0
    while i < len(argv):
        a = argv[i]
        name, val = a, None
        if a.startswith("--") and "=" in a:
            name, val = a.split("=", 1)
        elif a.startswith("-") and len(a) > 2 and a[:2] in ("-f", "-q", "-n", "-d"):
            name, val = a[:2], a[2:]

        if name in ("--help",):
            sys.stdout.write(HELP)
            return None, 0
        if name == "--version":
            print(VERSION)
            return None, 0
        if name == "--man":
            man = "/workspace/man/man1/fzf.1"
            try:
                with open(man, "r", encoding="utf-8", errors="replace") as f:
                    sys.stdout.write(f.read())
            except OSError:
                sys.stdout.write(HELP)
            return None, 0
        if name in ("--bash", "--zsh", "--fish"):
            print("### key-bindings.%s ###" % name[2:])
            print("# fzf shell integration")
            return None, 0

        def need() -> str:
            nonlocal i, val
            if val is not None:
                return val
            i += 1
            if i >= len(argv):
                raise ValueError(f"{name}: option requires an argument")
            return argv[i]

        try:
            if name in ("-f", "--filter"):
                opt.filter_query = need()
            elif name in ("-q", "--query"):
                opt.query = need()
            elif name in ("-n", "--nth"):
                opt.nth = need()
            elif name == "--with-nth":
                opt.with_nth = need()
            elif name == "--accept-nth":
                opt.accept_nth = need()
            elif name in ("-d", "--delimiter"):
                opt.delimiter = need()
            elif name == "--scheme":
                opt.scheme = need()
                if opt.scheme not in ("default", "path", "history"):
                    return None, eprint(f"invalid scoring scheme: {opt.scheme} (expected: default|path|history)")
            elif name == "--tiebreak":
                opt.tiebreak = need()
            elif name == "--header-lines":
                opt.header_lines = int(need())
            elif name == "--tail":
                opt.tail = int(need())
            elif name in ("-e", "--exact"):
                opt.exact = True
            elif name in ("-x", "--extended"):
                opt.extended = True
            elif name in ("+x", "--no-extended"):
                opt.extended = False
            elif name in ("-i", "--ignore-case"):
                opt.ignore_case = "always"
            elif name in ("+i", "--no-ignore-case"):
                opt.ignore_case = "never"
            elif name == "--smart-case":
                opt.ignore_case = "smart"
            elif name in ("+s", "--no-sort"):
                opt.sort = False
            elif name == "--read0":
                opt.read0 = True
            elif name == "--print0":
                opt.print0 = True
            elif name == "--ansi":
                opt.ansi = True
            elif name == "--disabled":
                opt.disabled = True
            elif name == "--tac":
                opt.tac = True
            elif name == "--print-query":
                opt.print_query = True
            elif name in ("-1", "--select-1"):
                opt.select_1 = True
            elif name in ("-0", "--exit-0"):
                opt.exit_0 = True
            elif name in KNOWN_FLAG:
                pass
            elif name in OPTIONAL_VALUE:
                if val is None and i + 1 < len(argv) and not argv[i + 1].startswith(("-", "+")):
                    i += 1
            elif name in KNOWN_VALUE:
                need()
            elif a.startswith("-") or a.startswith("+"):
                return None, eprint(f"unknown option: {a}")
        except ValueError as ex:
            return None, eprint(str(ex))
        i += 1

    for expr in (opt.nth, opt.with_nth, opt.accept_nth):
        if expr and "{" not in expr:
            for part in expr.split(","):
                if part.strip() == "0":
                    return None, eprint("invalid format: 0")
    return opt, None


ansi_re = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def normalize(s: str, literal: bool = False) -> str:
    if literal:
        return s
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def split_items(data: bytes, read0: bool) -> list[str]:
    sep = b"\0" if read0 else b"\n"
    parts = data.split(sep)
    if parts and parts[-1] == b"":
        parts.pop()
    return [p.decode("utf-8", errors="surrogateescape") for p in parts]


def fields(s: str, delim: str | None) -> tuple[list[str], list[str]]:
    if delim is None:
        return re.findall(r"\S+", s), [" "] * max(0, len(re.findall(r"\S+", s)) - 1)
    fs = re.split(delim, s)
    ds = re.findall(delim, s)
    return fs, ds


def idx_to_pos(n: int, count: int) -> int:
    return n - 1 if n > 0 else count + n


def eval_one_expr(expr: str, fs: list[str], ds: list[str], strip: bool = False) -> str:
    expr = expr.strip()
    if expr == "":
        return ""
    count = len(fs)
    if ".." in expr:
        a, b = expr.split("..", 1)
        start = 0 if a == "" else idx_to_pos(int(a), count)
        end = count - 1 if b == "" else idx_to_pos(int(b), count)
        start, end = max(0, start), min(count - 1, end)
        if end < start or start >= count:
            return ""
        pieces = []
        for j in range(start, end + 1):
            pieces.append(fs[j])
            if j < end and j < len(ds):
                pieces.append(ds[j])
            elif j < end:
                pieces.append(" ")
        return "".join(pieces)
    pos = idx_to_pos(int(expr), count)
    if pos < 0 or pos >= count:
        return ""
    return fs[pos].strip() if strip else fs[pos]


def transform(s: str, spec: str | None, delim: str | None, n: int = 0) -> str:
    if not spec:
        return s
    fs, ds = fields(s, delim)
    if "{" in spec:
        def repl(m: re.Match[str]) -> str:
            body = m.group(1)
            if body == "n":
                return str(n)
            return eval_one_expr(body, fs, ds, strip=True)
        return re.sub(r"\{([^{}]+)\}", repl, spec)
    return " ".join(eval_one_expr(p, fs, ds, strip=True) for p in spec.split(",") if p.strip())


def split_query(q: str) -> list[list[str]]:
    groups: list[list[str]] = [[]]
    buf = ""
    esc = False
    for c in q:
        if esc:
            buf += c
            esc = False
        elif c == "\\":
            esc = True
        elif c.isspace():
            if buf:
                groups[-1].append(buf)
                buf = ""
        elif c == "|":
            if buf:
                groups[-1].append(buf)
                buf = ""
            if groups[-1]:
                groups.append([])
        else:
            buf += c
    if buf:
        groups[-1].append(buf)
    return [g for g in groups if g]


def fuzzy_positions(needle: str, hay: str) -> list[int] | None:
    pos = []
    start = 0
    for ch in needle:
        k = hay.find(ch, start)
        if k < 0:
            return None
        pos.append(k)
        start = k + 1
    return pos


def term_match(term: str, text: str, opt: Options) -> tuple[bool, tuple[int, int, int]]:
    inv = term.startswith("!")
    if inv:
        term = term[1:]
    exact = opt.exact or inv or term.startswith("'")
    boundary = len(term) >= 2 and term.startswith("'") and term.endswith("'")
    if term.startswith("'"):
        term = term[1:]
    if boundary:
        term = term[:-1]
    prefix = term.startswith("^")
    suffix = term.endswith("$") and len(term) > 0
    if prefix:
        term = term[1:]
        exact = True
    if suffix:
        term = term[:-1]
        exact = True
    if term == "":
        ok, score = True, (0, 0, len(text))
    elif exact:
        if prefix:
            ok = text.startswith(term)
            at = 0 if ok else 10**9
        elif suffix:
            ok = text.endswith(term)
            at = len(text) - len(term) if ok else 10**9
        elif boundary:
            ok = False
            at = 10**9
            penalty = 0
            for m in re.finditer(re.escape(term), text):
                b = m.start() == 0 or not text[m.start() - 1].isalnum()
                e = m.end() == len(text) or not text[m.end()].isalnum()
                if b and e:
                    ok = True
                    at = m.start()
                    penalty = (1 if m.start() > 0 and text[m.start() - 1] == "_" else 0) + (1 if m.end() < len(text) and text[m.end()] == "_" else 0)
                    break
            at += penalty * 10000
        else:
            at = text.find(term)
            ok = at >= 0
        score = (at, len(term), len(text))
    else:
        pos = fuzzy_positions(term, text)
        ok = pos is not None
        if ok:
            span = pos[-1] - pos[0] + 1
            score = (span, pos[0], len(text))
        else:
            score = (10**9, 10**9, len(text))
    if inv:
        return (not ok), score
    return ok, score


def match_item(query: str, text: str, opt: Options) -> tuple[bool, tuple]:
    plain = ansi_re.sub("", text) if opt.ansi else text
    literal = "--literal" in sys.argv
    plain = normalize(plain, literal)
    q = normalize(query, literal)
    case_sensitive = opt.ignore_case == "never" or (opt.ignore_case == "smart" and any(c.isupper() for c in q))
    if not case_sensitive:
        plain = plain.lower()
        q = q.lower()
    if opt.disabled:
        return True, (0, len(plain), 0)
    if q == "":
        return True, (0, len(plain), 0)
    if not opt.extended:
        pos = fuzzy_positions(q, plain) if not opt.exact else None
        if opt.exact:
            at = plain.find(q)
            return at >= 0, (at if at >= 0 else 10**9, len(q), len(plain))
        return pos is not None, ((pos[-1] - pos[0] + 1), pos[0], len(plain)) if pos else (10**9, 10**9, len(plain))
    best = None
    for group in split_query(q):
        scores = []
        ok = True
        for t in group:
            m, sc = term_match(t, plain, opt)
            if not m:
                ok = False
                break
            scores.append(sc)
        if ok:
            cand = tuple(min(s[i] for s in scores) for i in range(3)) + (len(group),)
            if best is None or cand < best:
                best = cand
    return best is not None, best or (10**9, 10**9, len(plain), 0)


def read_input(opt: Options) -> list[str]:
    if not sys.stdin.isatty():
        data = sys.stdin.buffer.read()
        items = split_items(data, opt.read0)
    else:
        cmd = os.environ.get("FZF_DEFAULT_COMMAND")
        if cmd:
            p = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE)
            items = split_items(p.stdout, opt.read0)
        else:
            items = []
            for root, dirs, files in os.walk("."):
                dirs[:] = [d for d in dirs if d not in (".git", "node_modules")]
                for f in files:
                    items.append(os.path.relpath(os.path.join(root, f), "."))
    if opt.tail is not None and opt.tail >= 0:
        items = items[-opt.tail:]
    if opt.tac:
        items.reverse()
    return items


def collect_matches(opt: Options, query: str):
    items = read_input(opt)
    body = items[opt.header_lines:] if opt.header_lines > 0 else items
    rows = []
    for idx, original in enumerate(body):
        view = transform(original, opt.with_nth, opt.delimiter, idx) if opt.with_nth else original
        scope = transform(view if opt.with_nth else original, opt.nth, opt.delimiter, idx) if opt.nth else view
        ok, score = match_item(query, scope, opt)
        if ok:
            rows.append((score, idx, original))
    if opt.sort:
        rows.sort(key=lambda r: (r[0], len(r[2]), r[1]))
    return query, rows


def run_filter(opt: Options) -> int:
    query, rows = collect_matches(opt, opt.filter_query if opt.filter_query is not None else opt.query)
    out: list[str] = []
    if opt.print_query:
        out.append(query)
    for _, idx, original in rows:
        out.append(transform(original, opt.accept_nth, opt.delimiter, idx) if opt.accept_nth else original)
    sep = "\0" if opt.print0 else "\n"
    if out:
        sys.stdout.write(sep.join(out) + sep)
    return 0 if rows else 1


def run_auto_select(opt: Options) -> int:
    query, rows = collect_matches(opt, opt.query)
    if opt.select_1 and len(rows) == 1:
        _, idx, original = rows[0]
        sys.stdout.write(transform(original, opt.accept_nth, opt.delimiter, idx) if opt.accept_nth else original)
        sys.stdout.write("\0" if opt.print0 else "\n")
        return 0
    if opt.exit_0 and len(rows) == 0:
        return 1
    sys.stderr.write("inappropriate ioctl for device\n")
    return 2


def main() -> int:
    opt, early = parse(sys.argv[1:])
    if early is not None:
        return early
    assert opt is not None
    if opt.filter_query is not None:
        return run_filter(opt)
    if opt.select_1 or opt.exit_0:
        return run_auto_select(opt)
    sys.stderr.write("inappropriate ioctl for device\n")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
