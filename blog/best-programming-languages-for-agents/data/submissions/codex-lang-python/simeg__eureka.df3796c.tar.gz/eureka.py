#!/usr/bin/env python3
import json
import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path


VERSION = "eureka 2.0.0"

HELP = """Input and store your ideas without leaving the terminal

Usage: executable [OPTIONS]

Options:
      --clear-config  Clear your stored configuration
  -v, --view          View ideas with your $PAGER env variable. If unset use less
  -h, --help          Print help
  -V, --version       Print version"""

SETUP = """\033[0m\033[33m############################################################
####                  First Time Setup                  ####
############################################################

This tool requires you to have a repository with a README.md
in the root folder. The markdown file is where your ideas
will be stored.

Once first time setup has completed, simply run Eureka again
to begin writing down ideas.
        
\033[0m"""

PROMPT_REPO = "\033[0m\033[1m\033[32mAbsolute path to your idea repo\n\033[0m> "
PROMPT_SUMMARY = "\033[0m\033[1m\033[32m>> Idea summary\n\033[0m> "


def config_dir() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME")
    if base:
        return Path(base) / "eureka"
    return Path.home() / ".config" / "eureka"


def config_path() -> Path:
    return config_dir() / "config.json"


def ensure_rosetta_cache() -> None:
    try:
        (Path.home() / ".cache" / "rosetta").mkdir(parents=True, exist_ok=True)
    except Exception:
        pass


def error(message: str) -> int:
    print(f" ERROR eureka > {message}", file=sys.stderr)
    return 0


def read_line(prompt: str) -> str:
    sys.stdout.write(prompt)
    sys.stdout.flush()
    line = sys.stdin.readline()
    if line == "":
        return ""
    return line.rstrip("\n")


def load_config():
    p = config_path()
    if not p.exists():
        return None
    try:
        with p.open("r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        if e.pos == 1:
            return error("key must be a string at line 1 column 2")
        return error(str(e))
    except OSError as e:
        return error(str(e))


def first_setup() -> int:
    ensure_rosetta_cache()
    config_dir().mkdir(parents=True, exist_ok=True)
    sys.stdout.write(SETUP)
    repo = read_line(PROMPT_REPO)
    with config_path().open("w", encoding="utf-8") as f:
        json.dump({"repo": repo}, f, separators=(",", ":"))
    print("First time setup complete. Happy ideation!")
    return 0


def clear_config() -> int:
    ensure_rosetta_cache()
    config_dir().mkdir(parents=True, exist_ok=True)
    try:
        config_path().unlink()
    except FileNotFoundError:
        pass
    except OSError as e:
        return error(str(e))
    return 0


def get_repo():
    cfg = load_config()
    if cfg is None:
        return None
    if isinstance(cfg, int):
        return cfg
    try:
        return cfg["repo"]
    except Exception:
        return error("missing field `repo`")


def run_cmd(args, cwd=None, capture=True):
    return subprocess.run(
        args,
        cwd=cwd,
        stdin=subprocess.DEVNULL if capture else None,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
        text=True,
    )


def view() -> int:
    repo = get_repo()
    if repo is None:
        return error("No such file or directory (os error 2)")
    if isinstance(repo, int):
        return repo
    pager = os.environ.get("PAGER") or "less"
    if "/" not in pager:
        return error("No such file or directory (os error 2)")
    readme = str(Path(repo) / "README.md")
    if not Path(readme).exists():
        return error("No such file or directory (os error 2)")
    try:
        return subprocess.call([pager, readme])
    except FileNotFoundError as e:
        return error(str(e))
    except OSError as e:
        return error(str(e))


def git_error(cp) -> int:
    msg = (cp.stderr or cp.stdout or "").strip()
    if not msg:
        msg = "git command failed"
    # libgit2 and git format errors differently; keeping the core message is
    # more useful than exposing Python tracebacks.
    return error(msg.splitlines()[-1])


def capture() -> int:
    repo = get_repo()
    if repo is None:
        return first_setup()
    if isinstance(repo, int):
        return repo

    summary = read_line(PROMPT_SUMMARY)
    repo_path = Path(repo)
    try:
        repo_path.resolve(strict=True)
    except OSError:
        return error(f"failed to resolve path '{repo}': No such file or directory; class=Os (2); code=NotFound (-3)")

    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL")
    if editor:
        try:
            subprocess.call(shlex.split(editor), cwd=str(repo_path))
        except FileNotFoundError as e:
            return error(str(e))
        except OSError as e:
            return error(str(e))

    print("Adding and committing your new idea to main..")
    if not (repo_path / ".git").exists():
        cp = run_cmd(["git", "init", "-b", "main"], cwd=str(repo_path))
        if cp.returncode != 0:
            return git_error(cp)
    else:
        cp = run_cmd(["git", "checkout", "-B", "main"], cwd=str(repo_path))
        if cp.returncode != 0:
            cp = run_cmd(["git", "checkout", "-b", "main"], cwd=str(repo_path))
            if cp.returncode != 0:
                return git_error(cp)

    cp = run_cmd(["git", "add", "README.md"], cwd=str(repo_path))
    if cp.returncode != 0:
        return git_error(cp)
    cp = run_cmd(["git", "commit", "--allow-empty", "-m", summary], cwd=str(repo_path))
    if cp.returncode != 0:
        return git_error(cp)
    print("Added and committed!")
    print("Pushing your new idea..")
    cp = run_cmd(["git", "push", "origin", "main"], cwd=str(repo_path))
    if cp.returncode != 0:
        if "No such remote" in (cp.stderr or "") or "does not appear to be a git repository" in (cp.stderr or ""):
            return error("remote 'origin' does not exist; class=Config (7); code=NotFound (-3)")
        return git_error(cp)
    print("Pushed!")
    return 0


def unexpected_arg(arg: str) -> int:
    print(f"error: unexpected argument '{arg}' found\n", file=sys.stderr)
    print("Usage: executable [OPTIONS]\n", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def unexpected_value(opt: str, value: str) -> int:
    print(f"error: unexpected value '{value}' for '{opt}' found; no more were expected\n", file=sys.stderr)
    print(f"Usage: executable {opt}\n", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def main(argv) -> int:
    ensure_rosetta_cache()
    for arg in argv:
        if arg.startswith("--help="):
            return unexpected_value("--help", arg.split("=", 1)[1])
        if arg.startswith("--version="):
            return unexpected_value("--version", arg.split("=", 1)[1])
    for arg in argv:
        if arg not in ("--clear-config", "-v", "--view", "-h", "--help", "-V", "--version") and not (
            arg.startswith("-") and set(arg[1:]) <= set("vhV") and len(arg) > 2
        ):
            return unexpected_arg(arg)

    expanded = []
    for arg in argv:
        if arg.startswith("-") and not arg.startswith("--") and len(arg) > 2:
            expanded.extend("-" + c for c in arg[1:])
        else:
            expanded.append(arg)

    if "-h" in expanded or "--help" in expanded:
        print(HELP)
        return 0
    if "-V" in expanded or "--version" in expanded:
        print(VERSION)
        return 0
    if "-v" in expanded or "--view" in expanded:
        return view()
    if "--clear-config" in expanded:
        return clear_config()
    return capture()


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
