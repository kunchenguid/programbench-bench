#!/usr/bin/env python3
import fnmatch
import grp
import os
import pwd
import re
import shlex
import stat
import subprocess
import sys
import time
from datetime import datetime


VERSION = "fd 10.3.0"


HELP = """A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]    the search pattern
  [path]...    The directory where the filesystem search is rooted (optional)

Options:
  -H, --hidden                 Include hidden directories and files
  -I, --no-ignore              Do not respect ignore files
  -u, --unrestricted           Alias for --hidden --no-ignore
  -s, --case-sensitive         Case-sensitive search
  -i, --ignore-case            Case-insensitive search
  -g, --glob                   Glob-based search
      --regex                  Regular-expression based search
  -F, --fixed-strings          Treat pattern as a literal string
      --and <pattern>          Add an additional required pattern
  -a, --absolute-path          Show absolute paths
  -l, --list-details           Use a detailed listing format like ls -l
  -L, --follow                 Follow symbolic links
  -p, --full-path              Match against full path
  -0, --print0                 Separate results by NUL
  -d, --max-depth <depth>      Limit traversal depth
      --min-depth <depth>      Only show results starting at this depth
      --exact-depth <depth>    Only show results at this depth
  -E, --exclude <pattern>      Exclude matching paths
      --prune                  Do not descend into matching directories
  -t, --type <filetype>        Filter by type
  -e, --extension <ext>        Filter by extension
  -S, --size <size>            Filter by file size
      --changed-within <dur>   Filter by modification time
      --changed-before <dur>   Filter by modification time
  -o, --owner <user:group>     Filter by owning user and/or group
      --format <fmt>           Print results according to template
  -x, --exec <cmd>...          Execute command for each search result
  -X, --exec-batch <cmd>...    Execute command with all results
      --batch-size <size>      Maximum batch size for -X
  -c, --color <when>           When to use color: never, auto, always
  -j, --threads <num>          Set number of threads
      --max-results <count>    Limit number of results
  -1                           Alias for --max-results=1
  -q, --quiet                  Return 0 if at least one result, else 1
  -C, --base-directory <path>  Change current working directory
      --search-path <path>     Add a search path
      --path-separator <sep>   Set output path separator
  -h, --help                   Print help
  -V, --version                Print version
"""


VALUE_OPTS = {
    "--max-depth", "-d", "--min-depth", "--exact-depth", "--exclude", "-E",
    "--type", "-t", "--extension", "-e", "--size", "-S", "--changed-within",
    "--change-newer-than", "--newer", "--changed-after", "--changed-before",
    "--change-older-than", "--older", "--owner", "-o", "--format",
    "--batch-size", "--ignore-file", "--color", "-c", "--threads", "-j",
    "--max-results", "--base-directory", "-C", "--path-separator",
    "--search-path", "--ignore-contain", "--strip-cwd-prefix", "--hyperlink",
}

FLAG_OPTS = {
    "--hidden", "-H", "--no-hidden", "--no-ignore", "-I", "--ignore",
    "--no-ignore-vcs", "--ignore-vcs", "--no-require-git", "--require-git",
    "--no-ignore-parent", "--unrestricted", "-u", "--case-sensitive", "-s",
    "--ignore-case", "-i", "--glob", "-g", "--regex", "--fixed-strings",
    "-F", "--absolute-path", "-a", "--relative-path", "--list-details", "-l",
    "--follow", "-L", "--no-follow", "--full-path", "-p", "--print0", "-0",
    "--prune", "--quiet", "-q", "--has-results", "--show-errors",
    "--one-file-system", "--mount", "--xdev", "--help", "-h", "--version",
    "-V", "-1", "--no-ignore-parent",
}


class Options:
    def __init__(self):
        self.hidden = False
        self.no_ignore = False
        self.no_ignore_vcs = False
        self.require_git = True
        self.case = "smart"
        self.mode = "regex"
        self.absolute = False
        self.list_details = False
        self.follow = False
        self.full_path = False
        self.print0 = False
        self.max_depth = None
        self.min_depth = 1
        self.excludes = []
        self.prune = False
        self.types = []
        self.exts = []
        self.size_filters = []
        self.newer = []
        self.older = []
        self.owner_filters = []
        self.fmt = None
        self.execs = []
        self.batch_execs = []
        self.batch_size = 0
        self.ignore_files = []
        self.ignore_contain = []
        self.max_results = None
        self.quiet = False
        self.base_dir = None
        self.path_separator = os.sep
        self.search_paths = []
        self.and_patterns = []
        self.strip_cwd_prefix = "auto"
        self.color = "auto"
        self.arg_absolute = False


def die(msg, code=2):
    print(msg, file=sys.stderr)
    raise SystemExit(code)


def split_long_arg(arg):
    if arg.startswith("--") and "=" in arg:
        k, v = arg.split("=", 1)
        return k, v
    return arg, None


def parse(argv):
    opt = Options()
    pos = []
    i = 0
    literal = False
    while i < len(argv):
        arg = argv[i]
        if literal:
            pos.append(arg)
            i += 1
            continue
        if arg == "--":
            literal = True
            i += 1
            continue
        key, inline = split_long_arg(arg)
        if key in ("-x", "--exec", "-X", "--exec-batch"):
            batch = key in ("-X", "--exec-batch")
            cmd = []
            if inline is not None:
                cmd.append(inline)
            i += 1
            while i < len(argv) and argv[i] != ";":
                cmd.append(argv[i])
                i += 1
            if i < len(argv) and argv[i] == ";":
                i += 1
            if not cmd:
                die(f"error: a value is required for '{key} <cmd>...' but none was supplied")
            (opt.batch_execs if batch else opt.execs).append(cmd)
            continue
        if key in ("--strip-cwd-prefix", "--hyperlink") and inline is None:
            if key == "--strip-cwd-prefix":
                opt.strip_cwd_prefix = "always"
            i += 1
            continue
        if key == "--and":
            val, i = take_value(argv, i, inline, key)
            opt.and_patterns.append(val)
            continue
        if key in VALUE_OPTS:
            val, i = take_value(argv, i, inline, key)
            set_value(opt, key, val)
            continue
        if key in FLAG_OPTS:
            set_flag(opt, key)
            i += 1
            continue
        if arg.startswith("-") and arg != "-" and not looks_negative_pattern(arg):
            consumed = parse_short_group(opt, argv, i)
            if consumed is None:
                die(f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] [pattern] [path]...")
            i = consumed
            continue
        pos.append(arg)
        i += 1
    pattern = None
    paths = []
    if opt.search_paths:
        paths = opt.search_paths
        if pos:
            pattern = pos[0]
            paths += pos[1:]
    else:
        if pos:
            pattern = pos[0]
            paths = pos[1:]
    if not paths:
        paths = ["."]
    return opt, pattern, paths


def looks_negative_pattern(arg):
    return len(arg) > 1 and arg[1].isdigit()


def take_value(argv, i, inline, key):
    if inline is not None:
        return inline, i + 1
    if i + 1 >= len(argv):
        die(f"error: a value is required for '{key}' but none was supplied")
    return argv[i + 1], i + 2


def parse_short_group(opt, argv, i):
    arg = argv[i]
    j = 1
    while j < len(arg):
        ch = arg[j]
        key = "-" + ch
        if key in ("-d", "-t", "-e", "-E", "-S", "-o", "-c", "-j", "-C"):
            if j + 1 < len(arg):
                val = arg[j + 1:]
                set_value(opt, key, val)
                return i + 1
            if i + 1 >= len(argv):
                return None
            set_value(opt, key, argv[i + 1])
            return i + 2
        if key in FLAG_OPTS:
            set_flag(opt, key)
            j += 1
            continue
        return None
    return i + 1


def set_flag(opt, key):
    if key in ("--help", "-h"):
        print(HELP, end="")
        raise SystemExit(0)
    if key in ("--version", "-V"):
        print(VERSION)
        raise SystemExit(0)
    if key in ("--hidden", "-H"):
        opt.hidden = True
    elif key == "--no-hidden":
        opt.hidden = False
    elif key in ("--no-ignore", "-I"):
        opt.no_ignore = True
    elif key == "--ignore":
        opt.no_ignore = False
    elif key == "--no-ignore-vcs":
        opt.no_ignore_vcs = True
    elif key == "--ignore-vcs":
        opt.no_ignore_vcs = False
    elif key == "--no-require-git":
        opt.require_git = False
    elif key == "--require-git":
        opt.require_git = True
    elif key in ("--unrestricted", "-u"):
        opt.hidden = True
        opt.no_ignore = True
    elif key in ("--case-sensitive", "-s"):
        opt.case = "sensitive"
    elif key in ("--ignore-case", "-i"):
        opt.case = "insensitive"
    elif key in ("--glob", "-g"):
        opt.mode = "glob"
    elif key == "--regex":
        opt.mode = "regex"
    elif key in ("--fixed-strings", "-F"):
        opt.mode = "fixed"
    elif key in ("--absolute-path", "-a"):
        opt.absolute = True
    elif key == "--relative-path":
        opt.absolute = False
    elif key in ("--list-details", "-l"):
        opt.list_details = True
    elif key in ("--follow", "-L"):
        opt.follow = True
    elif key == "--no-follow":
        opt.follow = False
    elif key in ("--full-path", "-p"):
        opt.full_path = True
    elif key in ("--print0", "-0"):
        opt.print0 = True
    elif key == "--prune":
        opt.prune = True
    elif key in ("--quiet", "-q", "--has-results"):
        opt.quiet = True
        opt.max_results = 1
    elif key == "-1":
        opt.max_results = 1


def set_value(opt, key, val):
    if key in ("--max-depth", "-d"):
        opt.max_depth = int(val)
    elif key == "--min-depth":
        opt.min_depth = int(val)
    elif key == "--exact-depth":
        opt.min_depth = int(val)
        opt.max_depth = int(val)
    elif key in ("--exclude", "-E"):
        opt.excludes.append(val)
    elif key in ("--type", "-t"):
        opt.types.append(val)
    elif key in ("--extension", "-e"):
        opt.exts.append(val.lower().lstrip("."))
    elif key in ("--size", "-S"):
        opt.size_filters.append(parse_size(val))
    elif key in ("--changed-within", "--change-newer-than", "--newer", "--changed-after"):
        opt.newer.append(parse_time_arg(val))
    elif key in ("--changed-before", "--change-older-than", "--older"):
        opt.older.append(parse_time_arg(val))
    elif key in ("--owner", "-o"):
        opt.owner_filters.append(parse_owner(val))
    elif key == "--format":
        opt.fmt = val
    elif key == "--batch-size":
        opt.batch_size = int(val)
    elif key == "--ignore-file":
        opt.ignore_files.append(val)
    elif key in ("--color", "-c"):
        opt.color = val
    elif key in ("--threads", "-j"):
        pass
    elif key == "--max-results":
        opt.max_results = int(val)
    elif key in ("--base-directory", "-C"):
        opt.base_dir = val
    elif key == "--path-separator":
        opt.path_separator = val
    elif key == "--search-path":
        opt.search_paths.append(val)
    elif key == "--ignore-contain":
        opt.ignore_contain.append(val)
    elif key == "--strip-cwd-prefix":
        opt.strip_cwd_prefix = val
    elif key == "--hyperlink":
        pass


def parse_size(s):
    m = re.fullmatch(r"([+-]?)(\d+)([A-Za-z]*)", s)
    if not m:
        die(f"error: invalid value '{s}' for '--size <size>'")
    sign, num, unit = m.groups()
    mults = {"": 1, "b": 1, "k": 1000, "m": 1000**2, "g": 1000**3, "t": 1000**4,
             "ki": 1024, "mi": 1024**2, "gi": 1024**3, "ti": 1024**4}
    mult = mults.get(unit.lower())
    if mult is None:
        die(f"error: invalid size unit '{unit}'")
    return sign or "=", int(num) * mult


def parse_time_arg(s):
    if s.startswith("@") and s[1:].isdigit():
        return float(s[1:])
    m = re.fullmatch(r"(\d+)\s*([A-Za-z]+)", s)
    if m:
        n = int(m.group(1))
        unit = m.group(2).lower()
        seconds = {
            "s": 1, "sec": 1, "secs": 1, "second": 1, "seconds": 1,
            "m": 60, "min": 60, "mins": 60, "minute": 60, "minutes": 60,
            "h": 3600, "hr": 3600, "hour": 3600, "hours": 3600,
            "d": 86400, "day": 86400, "days": 86400,
            "w": 604800, "week": 604800, "weeks": 604800,
            "month": 2592000, "months": 2592000, "year": 31536000, "years": 31536000,
        }.get(unit)
        if seconds:
            return time.time() - n * seconds
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt).timestamp()
        except ValueError:
            pass
    die(f"error: invalid date or duration '{s}'")


def parse_owner(s):
    if ":" in s:
        u, g = s.split(":", 1)
    else:
        u, g = s, ""
    return parse_owner_part(u, True), parse_owner_part(g, False)


def parse_owner_part(part, user):
    if part == "":
        return None
    neg = part.startswith("!")
    if neg:
        part = part[1:]
    try:
        val = int(part)
    except ValueError:
        try:
            val = pwd.getpwnam(part).pw_uid if user else grp.getgrnam(part).gr_gid
        except KeyError:
            val = -99999999
    return neg, val


class Matcher:
    def __init__(self, opt, pattern):
        self.opt = opt
        self.patterns = []
        if pattern is not None:
            self.patterns.append(pattern)
        self.patterns.extend(opt.and_patterns)
        self.compiled = []
        for p in self.patterns:
            flags = 0 if self.case_sensitive(p) else re.IGNORECASE
            if opt.mode == "regex":
                try:
                    self.compiled.append(re.compile(p, flags))
                except re.error as e:
                    print("[fd error]: regex parse error:", file=sys.stderr)
                    print(f"    {p}", file=sys.stderr)
                    print(f"error: {e}", file=sys.stderr)
                    print("\nNote: You can use the '--fixed-strings' option to search for a literal string instead of a regular expression. Alternatively, you can also use the '--glob' option to match on a glob pattern.", file=sys.stderr)
                    raise SystemExit(1)
            elif opt.mode == "glob":
                self.compiled.append((p, flags == re.IGNORECASE))
            else:
                self.compiled.append((p, flags == re.IGNORECASE))

    def case_sensitive(self, pattern):
        if self.opt.case == "sensitive":
            return True
        if self.opt.case == "insensitive":
            return False
        return any(c.isupper() for c in pattern)

    def matches(self, name, rel, abs_path):
        if not self.patterns:
            return True
        target = abs_path if self.opt.full_path else name
        if self.opt.full_path and not self.opt.absolute:
            target = rel
        for cp in self.compiled:
            if self.opt.mode == "regex":
                if not cp.search(target):
                    return False
            elif self.opt.mode == "glob":
                pat, icase = cp
                t = target.lower() if icase else target
                p = pat.lower() if icase else pat
                if "/" not in p and self.opt.full_path:
                    ok = fnmatch.fnmatch(os.path.basename(t.rstrip(os.sep)), p)
                else:
                    ok = fnmatch.fnmatch(t, p)
                if not ok:
                    return False
            else:
                pat, icase = cp
                t = target.lower() if icase else target
                p = pat.lower() if icase else pat
                if p not in t:
                    return False
        return True


def is_git_repo(path):
    cur = os.path.abspath(path)
    while True:
        if os.path.isdir(os.path.join(cur, ".git")):
            return True
        parent = os.path.dirname(cur)
        if parent == cur:
            return False
        cur = parent


def load_ignore_file(path):
    pats = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.rstrip("\n")
                if not line or line.lstrip().startswith("#"):
                    continue
                neg = line.startswith("!")
                if neg:
                    line = line[1:]
                pats.append((line, neg))
    except OSError:
        pass
    return pats


def ignore_match(rel, name, is_dir, patterns):
    ignored = False
    rel_no = rel.rstrip("/")
    for pat, neg in patterns:
        p = pat.strip()
        dir_only = p.endswith("/")
        if dir_only:
            p = p.rstrip("/")
        if not p:
            continue
        anchored = p.startswith("/")
        p = p.lstrip("/")
        candidates = [rel_no] if "/" in p or anchored else [name, rel_no]
        ok = any(fnmatch.fnmatch(c, p) or c == p or c.startswith(p.rstrip("/") + "/") for c in candidates)
        if ok and (not dir_only or is_dir):
            ignored = not neg
    return ignored


def should_exclude(opt, rel, name, is_dir):
    for pat in opt.excludes:
        if fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(rel.rstrip("/"), pat) or rel.rstrip("/") == pat:
            return True
    return False


def display_path(path, start, opt, for_exec=False):
    if opt.absolute or opt.arg_absolute:
        s = os.path.abspath(path)
    else:
        s = os.path.relpath(path, os.getcwd())
        if s == ".":
            s = os.path.basename(os.path.abspath(path))
    if os.path.isdir(path) and not os.path.islink(path):
        s = s.rstrip(os.sep) + os.sep
    if for_exec and not opt.absolute and not s.startswith("."):
        if opt.strip_cwd_prefix != "always":
            s = "." + os.sep + s
    if opt.path_separator != os.sep:
        s = s.replace(os.sep, opt.path_separator)
    return s


def type_ok(path, st, opt):
    if not opt.types:
        return True
    normalized = set()
    special_empty = False
    special_exec = False
    for t in opt.types:
        tt = t.lower()
        if tt in ("f", "file"):
            normalized.add("file")
        elif tt in ("d", "dir", "directory"):
            normalized.add("dir")
        elif tt in ("l", "symlink"):
            normalized.add("symlink")
        elif tt in ("s", "socket"):
            normalized.add("socket")
        elif tt in ("p", "pipe"):
            normalized.add("pipe")
        elif tt in ("b", "block-device"):
            normalized.add("block")
        elif tt in ("c", "char-device"):
            normalized.add("char")
        elif tt in ("x", "executable"):
            special_exec = True
            normalized.add("file")
        elif tt in ("e", "empty"):
            special_empty = True
        else:
            die(f"error: invalid value '{t}' for '--type <filetype>'")
    mode = st.st_mode
    kinds = []
    if stat.S_ISREG(mode):
        kinds.append("file")
    if stat.S_ISDIR(mode):
        kinds.append("dir")
    if stat.S_ISLNK(mode):
        kinds.append("symlink")
    if stat.S_ISSOCK(mode):
        kinds.append("socket")
    if stat.S_ISFIFO(mode):
        kinds.append("pipe")
    if stat.S_ISBLK(mode):
        kinds.append("block")
    if stat.S_ISCHR(mode):
        kinds.append("char")
    if normalized and not any(k in normalized for k in kinds):
        return False
    if special_exec and not os.access(path, os.X_OK):
        return False
    if special_empty and not is_empty(path, st):
        return False
    return True


def is_empty(path, st):
    if stat.S_ISDIR(st.st_mode):
        try:
            return next(os.scandir(path), None) is None
        except OSError:
            return False
    return stat.S_ISREG(st.st_mode) and st.st_size == 0


def filters_ok(path, st, opt):
    if opt.size_filters and not stat.S_ISREG(st.st_mode):
        return False
    if opt.exts:
        base = os.path.basename(path)
        ext = os.path.splitext(base)[1].lstrip(".").lower()
        if ext not in opt.exts:
            return False
    for sign, size in opt.size_filters:
        if sign == "+" and st.st_size < size:
            return False
        if sign == "-" and st.st_size > size:
            return False
        if sign == "=" and st.st_size != size:
            return False
    for ts in opt.newer:
        if st.st_mtime <= ts:
            return False
    for ts in opt.older:
        if st.st_mtime >= ts:
            return False
    for user_part, group_part in opt.owner_filters:
        if user_part is not None:
            neg, val = user_part
            if (st.st_uid == val) == neg:
                return False
        if group_part is not None:
            neg, val = group_part
            if (st.st_gid == val) == neg:
                return False
    return type_ok(path, st, opt)


def walk(paths, opt, matcher):
    results = []
    ignore_global = []
    for f in opt.ignore_files:
        ignore_global.extend(load_ignore_file(f))
    for root_arg in paths:
        root = os.path.abspath(root_arg)
        root_is_git = is_git_repo(root)
        if os.path.isfile(root) or os.path.islink(root):
            scan_one(root, root, opt, matcher, results, 1, ignore_global)
            continue
        traverse(root, root, opt, matcher, results, 0, ignore_global, root_is_git)
        if opt.max_results and len(results) >= opt.max_results:
            break
    return results[:opt.max_results] if opt.max_results else results


def traverse(root, cur, opt, matcher, results, depth, inherited_ignores, root_is_git):
    local_ignores = list(inherited_ignores)
    if not opt.no_ignore:
        local_ignores += load_ignore_file(os.path.join(cur, ".ignore"))
        local_ignores += load_ignore_file(os.path.join(cur, ".fdignore"))
        if not opt.no_ignore_vcs and (root_is_git or not opt.require_git):
            local_ignores += load_ignore_file(os.path.join(cur, ".gitignore"))
    try:
        entries = list(os.scandir(cur))
    except OSError as e:
        return
    entries.sort(key=lambda e: e.name)
    for ent in entries:
        path = ent.path
        name = ent.name
        child_depth = depth + 1
        try:
            st = ent.stat(follow_symlinks=opt.follow)
            lst = ent.stat(follow_symlinks=False)
        except OSError:
            continue
        is_dir = stat.S_ISDIR(st.st_mode) if opt.follow else ent.is_dir(follow_symlinks=False)
        rel = os.path.relpath(path, root)
        rel_dir = rel + "/" if is_dir else rel
        hidden = name.startswith(".")
        if hidden and not opt.hidden:
            continue
        if any(os.path.exists(os.path.join(path, marker)) for marker in opt.ignore_contain) if is_dir else False:
            continue
        if not opt.no_ignore and ignore_match(rel_dir, name, is_dir, local_ignores):
            continue
        if should_exclude(opt, rel_dir, name, is_dir):
            continue
        matched = scan_one(path, root, opt, matcher, results, child_depth, local_ignores, st=(st if opt.follow else lst))
        if opt.max_results and len(results) >= opt.max_results:
            return
        if is_dir and (opt.max_depth is None or child_depth < opt.max_depth):
            if opt.prune and matched:
                continue
            if not ent.is_symlink() or opt.follow:
                traverse(root, path, opt, matcher, results, child_depth, local_ignores, root_is_git)
                if opt.max_results and len(results) >= opt.max_results:
                    return


def scan_one(path, root, opt, matcher, results, depth, ignores, st=None):
    try:
        if st is None:
            st = os.lstat(path)
    except OSError:
        return False
    name = os.path.basename(path.rstrip(os.sep))
    rel = os.path.relpath(path, root)
    abs_path = os.path.abspath(path)
    if depth < opt.min_depth:
        return False
    if opt.max_depth is not None and depth > opt.max_depth:
        return False
    isdir = os.path.isdir(path) and not os.path.islink(path)
    rel_for_match = rel + "/" if isdir else rel
    if not matcher.matches(name, rel_for_match, abs_path):
        return False
    if not filters_ok(path, st, opt):
        return False
    results.append(path)
    return True


def replace_placeholders(arg, path):
    parent = os.path.dirname(path)
    base = os.path.basename(path.rstrip(os.sep))
    noext = os.path.splitext(path)[0]
    base_noext = os.path.splitext(base)[0]
    out = arg.replace("{{", "\0L").replace("}}", "\0R")
    out = out.replace("{//}", parent if parent else ".")
    out = out.replace("{/.}", base_noext)
    out = out.replace("{/}", base)
    out = out.replace("{.}", noext)
    out = out.replace("{}", path)
    return out.replace("\0L", "{").replace("\0R", "}")


def has_placeholder(cmd):
    return any(("{}" in a or "{/}" in a or "{//}" in a or "{.}" in a or "{/.}" in a) for a in cmd)


def print_results(results, opt):
    if opt.quiet:
        return
    if opt.list_details:
        if results:
            subprocess.run(["ls", "-ld", "--"] + [display_path(p, None, opt) for p in results])
        return
    if opt.fmt is not None:
        for p in results:
            d = display_path(p, None, opt).rstrip("/")
            print(replace_placeholders(opt.fmt, d))
        return
    sep = "\0" if opt.print0 else "\n"
    for p in results:
        sys.stdout.write(display_path(p, None, opt, for_exec=opt.print0))
        sys.stdout.write(sep)


def run_execs(results, opt):
    code = 0
    for cmd in opt.execs:
        implicit = not has_placeholder(cmd)
        for p in results:
            d = display_path(p, None, opt, for_exec=True).rstrip("/")
            args = [replace_placeholders(a, d) for a in cmd]
            if implicit:
                args.append(d)
            r = subprocess.run(args)
            code = code or r.returncode
            if opt.print0:
                sys.stdout.write("\0")
    for cmd in opt.batch_execs:
        implicit = not has_placeholder(cmd)
        ds = [display_path(p, None, opt, for_exec=True).rstrip("/") for p in results]
        if not ds and implicit:
            continue
        batches = [ds]
        if opt.batch_size > 0:
            batches = [ds[i:i + opt.batch_size] for i in range(0, len(ds), opt.batch_size)]
        for batch in batches:
            if implicit:
                args = list(cmd) + batch
            else:
                args = []
                for a in cmd:
                    if any(ph in a for ph in ("{}", "{/}", "{//}", "{.}", "{/.}")):
                        args.extend(replace_placeholders(a, d) for d in batch)
                    else:
                        args.append(a)
            if args:
                r = subprocess.run(args)
                code = code or r.returncode
    return code


def main(argv):
    opt, pattern, paths = parse(argv)
    if opt.base_dir:
        os.chdir(opt.base_dir)
    opt.arg_absolute = any(os.path.isabs(p) for p in paths)
    matcher = Matcher(opt, pattern)
    results = walk(paths, opt, matcher)
    if opt.execs or opt.batch_execs:
        return run_execs(results, opt)
    print_results(results, opt)
    if opt.quiet:
        return 0 if results else 1
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(1)
