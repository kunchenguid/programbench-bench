#!/usr/bin/env python3
import base64
import concurrent.futures
import json
import os
import re
import ssl
import sys
import time
import urllib.parse
import http.client

VERSION = "0.1.0"
HELP = """bat is a Go implemented CLI cURL-like tool for humans.

Usage:

	bat [flags] [METHOD] URL [ITEM [ITEM]]

flags:
  -a, -auth=USER[:PASS]       Pass a username:password pair as the argument
  -b, -bench=false            Sends bench requests to URL
  -b.N=1000                   Number of requests to run
  -b.C=100                    Number of requests to run concurrently
  -body=""                    Send RAW data as body
  -f, -form=false             Submitting the data as a form
  -j, -json=true              Send the data in a JSON object
  -p, -pretty=true            Print Json Pretty Format
  -i, -insecure=false         Allow connections to SSL sites without certs
  -proxy=PROXY_URL            Proxy with host and port
  -print="A"                  String specifying what the output should contain, default will print all information
         "H" request headers
         "B" request body
         "h" response headers
         "b" response body
  -v, -version=true           Show Version Number

METHOD:
  bat defaults to either GET (if there is no request data) or POST (with request data).

URL:
  The only information needed to perform a request is a URL. The default scheme is http://,
  which can be omitted from the argument; example.org works just fine.

ITEM:
  Can be any of:
    Query string   key=value
    Header         key:value
    Post data      key=value
    File upload    key@/path/file

Example:

	bat beego.me

more help information please refer to https://github.com/astaxie/bat
"""
METHODS = {"GET","POST","PUT","DELETE","PATCH","HEAD","OPTIONS"}

class Options:
    def __init__(self):
        self.auth = ""
        self.bench = False
        self.bench_n = 1000
        self.bench_c = 100
        self.body = ""
        self.form = False
        self.json = True
        self.pretty = True
        self.insecure = False
        self.proxy = ""
        self.print = "A"
        self.version = False
        self.download = False

def parse_bool(s):
    if s is None:
        return True
    return str(s).lower() in ("1", "t", "true", "y", "yes")

def parse_args(argv):
    opts = Options(); rest=[]; i=0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            rest.extend(argv[i+1:]); break
        if a.startswith("-") and a != "-":
            nameval = a[2:] if a.startswith("--") else a[1:]
            if "=" in nameval:
                name, val = nameval.split("=",1)
            else:
                name, val = nameval, None
            def need_value():
                nonlocal i, val
                if val is None:
                    i += 1
                    if i >= len(argv): val = ""
                    else: val = argv[i]
                return val
            if name in ("h", "help"):
                print(HELP, end=""); sys.exit(0)
            elif name in ("v", "version"):
                opts.version = parse_bool(val)
            elif name in ("a", "auth"):
                opts.auth = need_value()
            elif name in ("b", "bench"):
                opts.bench = parse_bool(val)
            elif name == "b.N":
                try: opts.bench_n = int(need_value())
                except Exception: opts.bench_n = 1000
            elif name == "b.C":
                try: opts.bench_c = int(need_value())
                except Exception: opts.bench_c = 100
            elif name == "body":
                opts.body = need_value()
            elif name in ("f", "form"):
                opts.form = parse_bool(val)
            elif name in ("j", "json"):
                opts.json = parse_bool(val)
            elif name in ("p", "pretty"):
                opts.pretty = parse_bool(val)
            elif name in ("i", "insecure"):
                opts.insecure = parse_bool(val)
            elif name == "proxy":
                opts.proxy = need_value()
            elif name == "print":
                opts.print = need_value()
            elif name == "download":
                opts.download = parse_bool(val)
            else:
                sys.stderr.write(f"flag provided but not defined: -{name}\n")
                print(HELP, end="", file=sys.stderr)
                sys.exit(2)
        else:
            rest.append(a)
        i += 1
    return opts, rest

def parse_url(u):
    if "://" not in u:
        u = "http://" + u
    p = urllib.parse.urlsplit(u)
    path = p.path or "/"
    if p.query: path += "?" + p.query
    return u, p, path

def build_request(opts, args):
    if not args:
        logerr('filter.go:35: Miss the URL')
        sys.exit(0)
    method = None
    if args[0].upper() in METHODS:
        method = args[0].upper(); args = args[1:]
    if not args:
        logerr('filter.go:35: Miss the URL')
        sys.exit(0)
    url = args[0]; items = args[1:]
    headers = {"Accept":"application/json", "Accept-Encoding":"gzip, deflate", "User-Agent":"bat/0.1.0"}
    data = []
    files = []
    for it in items:
        if ":" in it and ("=" not in it.split(":",1)[0]):
            k,v = it.split(":",1); headers[k]=v
        elif "@" in it and "=" not in it:
            k,v = it.split("@",1); files.append((k,v))
        elif "=" in it:
            k,v = it.split("=",1); data.append((k,v))
    if method is None:
        method = "POST" if data or opts.body else "GET"
    body = None
    if opts.body:
        body = opts.body.encode()
    elif method == "GET":
        if data:
            sep = "&" if "?" in url else "?"
            url += sep + urllib.parse.urlencode(data)
    elif opts.form:
        body = urllib.parse.urlencode(data).encode()
        if data: headers["Content-Type"] = "application/x-www-form-urlencoded"
    elif data:
        # Go's encoding/json on map[string]string produces compact JSON plus newline.
        obj = {k:v for k,v in data}
        body = json.dumps(obj, separators=(",", ":"), sort_keys=True).encode() + b"\n"
        headers["Content-Type"] = "application/json"
    elif files:
        body = b""
    if body is not None:
        headers["Content-Length"] = str(len(body))
    if opts.auth:
        auth_value = opts.auth if ":" in opts.auth else opts.auth + ":"
        token = base64.b64encode(auth_value.encode()).decode()
        headers["Authorization"] = "Basic " + token
    return method, url, headers, body

def logerr(msg):
    now = time.strftime("%Y/%m/%d %H:%M:%S")
    sys.stderr.write(f"{now}.000000 {msg}\n")

def perform(opts, method, url, headers, body):
    full, p, path = parse_url(url)
    timeout = 30
    context = None
    if p.scheme == "https":
        context = ssl._create_unverified_context() if opts.insecure else None
    host = p.hostname or ""
    port = p.port or (443 if p.scheme == "https" else 80)
    try:
        if opts.proxy:
            proxy_url = opts.proxy if "://" in opts.proxy else "http://" + opts.proxy
            pp = urllib.parse.urlsplit(proxy_url)
            conn = http.client.HTTPConnection(pp.hostname, pp.port or 80, timeout=timeout)
            request_path = full
        elif p.scheme == "https":
            conn = http.client.HTTPSConnection(host, port, timeout=timeout, context=context)
            request_path = path
        else:
            conn = http.client.HTTPConnection(host, port, timeout=timeout)
            request_path = path
        conn.request(method, request_path, body=body, headers=headers)
        resp = conn.getresponse()
        data = resp.read()
        info = (resp.status, resp.reason, resp.getheaders(), data)
        conn.close()
        return info
    except Exception as e:
        # Match the recognizable part of Go net/http errors.
        logerr(f'bat.go:215: can\'t get the url {method.title()} "{full}": {e}')
        return None

def print_response(opts, resp):
    if resp is None: return
    status, reason, hs, data = resp
    if opts.download:
        for k,v in hs:
            print(f"\x1b[90m{k}\x1b[0m : \x1b[96m{v}\x1b[0m")
        name = "index.html"
        cd = dict((k.lower(), v) for k,v in hs).get("content-disposition", "")
        m = re.search(r'filename="?([^";]+)', cd)
        if m: name = m.group(1)
        else:
            name = os.path.basename(urllib.parse.urlsplit("/").path) or "index.html"
        with open(name, "wb") as f: f.write(data)
        print(f'\nDownloading to "{name}"')
        print(f"\r{len(data)} B / {len(data)} B [==============================] 100.00 % 0s", end="")
        return
    sys.stdout.write("\n")
    ctype = ""
    for k,v in hs:
        if k.lower() == "content-type": ctype = v
    if opts.pretty and "json" in ctype.lower():
        try:
            obj = json.loads(data.decode())
            sys.stdout.write(json.dumps(obj, indent=2, sort_keys=True))
            return
        except Exception as e:
            logerr("http.go:122: Response Json Indent: " + str(e))
            return
    try:
        sys.stdout.write(data.decode())
    except UnicodeDecodeError:
        sys.stdout.buffer.write(data)

def bench(opts, method, url, headers, body):
    n=max(0, opts.bench_n); c=max(1, opts.bench_c)
    times=[]; sizes=[]; statuses=[]
    start=time.time()
    def one(_):
        t=time.time(); r=perform(opts, method, url, headers, body); dt=time.time()-t
        if r is None: return dt,0,0
        return dt, len(r[3]), r[0]
    with concurrent.futures.ThreadPoolExecutor(max_workers=c) as ex:
        for dt, sz, st in ex.map(one, range(n)):
            times.append(dt); sizes.append(sz); statuses.append(st)
    total=time.time()-start
    slow=max(times) if times else 0; fast=min(times) if times else 0; avg=sum(times)/len(times) if times else 0
    print("\nSummary:")
    print(f"  Total:\t{total:.4f} secs.")
    print(f"  Slowest:\t{slow:.4f} secs.")
    print(f"  Fastest:\t{fast:.4f} secs.")
    print(f"  Average:\t{avg:.4f} secs.")
    print(f"  Requests/sec:\t{(n/total if total else 0):.4f}")
    print(f"  Total Data Received:\t{sum(sizes)} bytes.")
    print(f"  Response Size per Request:\t{(int(sum(sizes)/n) if n else 0)} bytes.")
    print("\nStatus code distribution:")
    for st in sorted(set(statuses)):
        print(f"  [{st}]\t{statuses.count(st)} responses")
    print("\nResponse time histogram:")
    if times:
        for i in range(10):
            val=fast+(slow-fast)*i/9 if slow>fast else fast
            count=sum(1 for x in times if (x<=val if i==0 else True)) if i==0 else 0
            bar="∎"*min(40, max(0, count*20//max(1,n)))
            print(f"  {val:.3f} [{count}]\t|{bar}")
    print("\nLatency distribution:")
    stimes=sorted(times)
    for pct in (10,25,50,75,90,95,99):
        if stimes:
            idx=min(len(stimes)-1, int(len(stimes)*pct/100))
            print(f"  {pct}% in {stimes[idx]:.4f} secs.")

def main(argv):
    opts,args=parse_args(argv)
    if opts.version:
        print("Version: " + VERSION); return
    if not args:
        print(HELP, end=""); return
    method,url,headers,body=build_request(opts,args)
    if opts.bench:
        bench(opts, method, url, headers, body); return
    print_response(opts, perform(opts, method, url, headers, body))

if __name__ == "__main__":
    main(sys.argv[1:])
