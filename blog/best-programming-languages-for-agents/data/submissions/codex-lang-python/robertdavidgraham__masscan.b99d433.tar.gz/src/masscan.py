#!/usr/bin/env python3
import os
import random
import sys


LONG_HELP = """usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]
MASSCAN is a fast port scanner. The primary input parameters are the
IP addresses/ranges you want to scan, and the port numbers. An example
is the following, which scans the 10.x.x.x network for web servers:

    masscan 10.0.0.0/8 -p80

The program auto-detects network interface/adapter settings. If this
fails, you'll have to set these manually. The following is an
example of all the parameters that are needed:

    --adapter-ip 192.168.10.123
    --adapter-mac 00-11-22-33-44-55
    --router-mac 66-55-44-33-22-11

Parameters can be set either via the command-line or config-file. The
names are the same for both. Thus, the above adapter settings would
appear as follows in a configuration file:

    adapter-ip = 192.168.10.123
    adapter-mac = 00-11-22-33-44-55
    router-mac = 66-55-44-33-22-11

All single-dash parameters have a spelled out double-dash equivalent,
so '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).
To use the config file, type:

    masscan -c <filename>

To generate a config-file from the current settings, use the --echo
option. This stops the program from actually running, and just echoes
the current configuration instead. This is a useful way to generate
your first config file, or see a list of parameters you didn't know
about. I suggest you try it now:

    masscan -p1234 --echo
"""

SHORT_HELP = """usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]

examples:
    masscan -p80,8000-8100 10.0.0.0/8 --rate=10000
        scan some web ports on 10.x.x.x at 10kpps

    masscan --nmap
        list those options that are compatible with nmap

    masscan -p80 10.0.0.0/8 --banners -oB <filename>
        save results of scan in binary format to <filename>

    masscan --open --banners --readscan <filename> -oX <savefile>
        read binary scan results in <filename> and save them as xml in <savefile>
"""

NMAP_HELP = """Masscan (https://github.com/robertdavidgraham/masscan)
Usage: masscan [Options] -p{Target-Ports} {Target-IP-Ranges}
TARGET SPECIFICATION:
  Can pass only IPv4/IPv6 address, CIDR networks, or ranges (non-nmap style)
  Ex: 10.0.0.0/8, 192.168.0.1, 10.0.0.1-10.0.0.254
  -iL <inputfilename>: Input from list of hosts/networks
  --exclude <host1[,host2][,host3],...>: Exclude hosts/networks
  --excludefile <exclude_file>: Exclude list from file
  --randomize-hosts: Randomize order of hosts (default)
HOST DISCOVERY:
  -Pn: Treat all hosts as online (default)
  -n: Never do DNS resolution (default)
SCAN TECHNIQUES:
  -sS: TCP SYN (always on, default)
SERVICE/VERSION DETECTION:
  --banners: get the banners of the listening service if available. The
    default timeout for waiting to receive data is 30 seconds.
PORT SPECIFICATION AND SCAN ORDER:
  -p <port ranges>: Only scan specified ports
    Ex: -p22; -p1-65535; -p 111,137,80,139,8080
TIMING AND PERFORMANCE:
  --max-rate <number>: Send packets no faster than <number> per second
  --connection-timeout <number>: time in seconds a TCP connection will
    timeout while waiting for banner data from a port.
FIREWALL/IDS EVASION AND SPOOFING:
  -S/--source-ip <IP_Address>: Spoof source address
  -e <iface>: Use specified interface
  -g/--source-port <portnum>: Use given port number
  --ttl <val>: Set IP time-to-live field
  --spoof-mac <mac address/prefix/vendor name>: Spoof your MAC address
OUTPUT:
  --output-format <format>: Sets output to binary/list/unicornscan/json/ndjson/grepable/xml
  --output-file <file>: Write scan results to file. If --output-format is
     not given default is xml
  -oL/-oJ/-oD/-oG/-oB/-oX/-oU <file>: Output scan in List/JSON/nDjson/Grepable/Binary/XML/Unicornscan format,
     respectively, to the given filename. Shortcut for
     --output-format <format> --output-file <file>
  -v: Increase verbosity level (use -vv or more for greater effect)
  -d: Increase debugging level (use -dd or more for greater effect)
  --open: Only show open (or possibly open) ports
  --packet-trace: Show all packets sent and received
  --iflist: Print host interfaces and routes (for debugging)
  --append-output: Append to rather than clobber specified output files
  --resume <filename>: Resume an aborted scan
MISC:
  --send-eth: Send using raw ethernet frames (default)
  -V: Print version number
  -h: Print this help summary page.
EXAMPLES:
  masscan -v -sS 192.168.0.0/16 10.0.0.0/8 -p 80
  masscan 23.0.0.0/0 -p80 --banners -output-format binary --output-filename internet.scan
  masscan --open --banners --readscan internet.scan -oG internet_scan.grepable
SEE (https://github.com/robertdavidgraham/masscan) FOR MORE HELP
"""

VERSION = """
Masscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )
Compiled on: Apr 17 2026 19:59:25
Compiler: gcc 11.4.0
OS: Linux
CPU: x86 (64 bits)
GIT version: unknown
"""

PCAP_FAIL = """[-] FAIL: failed to load libpcap shared library
    [hint]: you must install libpcap or WinPcap"""

TOP_PORTS = {
    "1": "21-25,80,111,135,139,443,445,465,587,990,992,2525,5800,5900-5901,8080",
    "2": "80,443",
    "5": "21,80,443,990,8080",
    "10": "21-25,80,443,990,992,8080",
    "20": "21-25,80,111,135,139,443,445,465,587,990,992,2525,5800,5900-5901,8080",
    "100": "1,3-4,6-7,9,13,17,19-26,30,32-33,37,42-43,49,53,70,79-85,88-90,99-100,106,109-111,113,119,125,135,139,143-144,146,161,163,179,199,211-212,222,254-256,259,264,280,301,306,311,340,366,389,406-407,416-417,425,443,445,465,548,554,587,636,990,992,1098-1099,1433,2083,2096,2525,3389,5060-5061,5800,5900-5901,6000-6001,8080,8140,9050,11211",
}

OUT_FORMATS = {
    "-oL": "list", "-oJ": "json", "-oD": "ndjson", "-oG": "grepable",
    "-oB": "binary", "-oX": "xml", "-oU": "unicornscan",
}


class Conf:
    def __init__(self):
        self.rate = "100"
        self.shard = "1/1"
        self.ports = ""
        self.ranges = []
        self.outfile = None
        self.outfmt = None
        self.echo = False
        self.banners = False
        self.open = False
        self.readscan = None
        self.iflist = False
        self.selftest = False
        self.adapter_ip = None
        self.adapter_mac = None
        self.router_mac = None
        self.adapter_port = None
        self.extra = {}
        self.errors = []
        self.show_short_help = False


def norm_mac(s):
    return s.replace(":", "-").lower()


def needs_value(args, i, name):
    if i + 1 >= len(args) or (args[i + 1].startswith("-") and args[i + 1] != "-"):
        return None
    return args[i + 1]


def set_key(conf, key, val):
    k = key.strip().lstrip("-").replace("_", "-")
    if k in ("p", "ports"):
        conf.ports = val.strip()
    elif k in ("range", "ranges", "include"):
        if val.strip():
            conf.ranges.append(val.strip())
    elif k in ("rate", "max-rate"):
        if not val or not val.replace(".", "", 1).isdigit():
            conf.errors.append(f"CONF: non-digit in rate spec: rate={val}")
        else:
            conf.rate = val
    elif k == "shard":
        conf.shard = val
    elif k in ("output-filename", "output-file"):
        conf.outfile = val
        if conf.outfmt is None:
            conf.outfmt = "xml"
    elif k == "output-format":
        conf.outfmt = val
    elif k in ("adapter-ip", "source-ip", "source-address", "S"):
        conf.adapter_ip = val
    elif k in ("adapter-mac", "spoof-mac"):
        conf.adapter_mac = norm_mac(val)
    elif k in ("router-mac", "router-mac-ipv4", "router-mac-ipv6"):
        conf.router_mac = norm_mac(val)
    elif k in ("adapter-port", "source-port", "g"):
        conf.adapter_port = val
    elif k == "banners":
        conf.banners = val.lower() not in ("0", "false", "no")
    elif k == "open":
        conf.open = val.lower() not in ("0", "false", "no")
    elif k in ("excludefile", "exclude-file", "include-file", "iL"):
        if not os.path.exists(val):
            print("[-] FAIL: parsing IP addresses")
            print(f"[-] {val}: No such file or directory")
            sys.exit(0)
        conf.extra[k] = val
    else:
        conf.extra[k] = val


def parse_config(conf, filename):
    try:
        lines = open(filename, "r", encoding="utf-8", errors="ignore").read().splitlines()
    except OSError as e:
        print(f"[-] FAIL: {filename}: {e.strerror}")
        sys.exit(0)
    for line in lines:
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        if "=" in line:
            k, v = line.split("=", 1)
            set_key(conf, k, v.strip())
        else:
            parts = line.split(None, 1)
            if len(parts) == 2:
                set_key(conf, parts[0], parts[1])
            else:
                conf.errors.append(f"{parts[0]}: empty parameter")


def parse_args(argv):
    conf = Conf()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            conf.ranges.extend(argv[i + 1:])
            break
        if a in ("--help",):
            print(LONG_HELP, end="")
            sys.exit(0)
        if a in ("-h", "-?"):
            print(SHORT_HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION, end="")
            sys.exit(0)
        if a == "--nmap":
            print(NMAP_HELP, end="")
            sys.exit(0)
        if a in ("--selftest", "--regress"):
            conf.selftest = True
        elif a == "--iflist":
            conf.iflist = True
        elif a == "--echo":
            conf.echo = True
        elif a in ("--banners", "--open", "--append-output", "--packet-trace", "-sS", "-Pn", "-n", "--send-eth", "--randomize-hosts"):
            if a == "--banners":
                conf.banners = True
            elif a == "--open":
                conf.open = True
        elif a.startswith("-p") and a != "-p":
            conf.ports = a[2:]
        elif a == "-p":
            v = needs_value(argv, i, "(null)")
            if v is None:
                conf.errors.append("(null): empty parameter")
            else:
                conf.ports = v
                i += 1
        elif a in ("--ports", "--rate", "--max-rate", "--shard", "--adapter-ip", "--adapter-mac",
                   "--router-mac", "--source-ip", "-S", "--source-port", "-g", "--ttl", "--wait",
                   "--connection-timeout", "--exclude", "--excludefile", "--exclude-file",
                   "--include-file", "-iL", "--resume", "--readscan", "--top-ports", "-c",
                   "--output-format", "--output-filename", "--output-file", "-e", "--interface"):
            name = a.lstrip("-")
            v = needs_value(argv, i, name)
            if v is None:
                conf.errors.append(f"{name}: empty parameter")
            else:
                if a == "-c":
                    parse_config(conf, v)
                elif a == "--readscan":
                    conf.readscan = v
                elif a == "--top-ports":
                    conf.ports = TOP_PORTS.get(v, TOP_PORTS["100"])
                elif a in ("--excludefile", "--exclude-file", "--include-file", "-iL"):
                    set_key(conf, name, v)
                elif a in ("--output-filename", "--output-file"):
                    set_key(conf, "output-filename", v)
                elif a == "--output-format":
                    set_key(conf, "output-format", v)
                elif a in ("--interface", "-e"):
                    conf.extra["adapter"] = v
                else:
                    set_key(conf, name, v)
                i += 1
        elif a in OUT_FORMATS:
            v = needs_value(argv, i, a)
            if v is None:
                conf.errors.append(f"{a}: empty parameter")
            else:
                conf.outfmt = OUT_FORMATS[a]
                conf.outfile = v
                i += 1
        elif a.startswith("--") and "=" in a:
            k, v = a[2:].split("=", 1)
            set_key(conf, k, v)
        elif a.startswith("--"):
            conf.errors.append(f"{a[2:]}: empty parameter")
        elif a.startswith("-") and len(a) > 2 and a[1] in "vd":
            pass
        else:
            conf.ranges.append(a)
        i += 1
    return conf


def echo(conf):
    print(PCAP_FAIL)
    print(f"seed = {random.getrandbits(64)}")
    print(f"rate = {conf.rate:<10}")
    print(f"shard = {conf.shard}")
    if conf.banners:
        print("banners = true")
    print("nocapture = servername")
    print("nocapture = servername")
    print()
    if conf.outfile:
        print(f"output-filename = {conf.outfile}")
    if conf.outfmt:
        print(f"output-format = {conf.outfmt}")
        print()
    if conf.adapter_ip:
        print(f"adapter-ip = {conf.adapter_ip}")
    if conf.adapter_port:
        print(f"adapter-port = {conf.adapter_port}")
    if conf.adapter_mac:
        print(f"adapter-mac = {conf.adapter_mac}")
    if conf.router_mac:
        print(f"router-mac-ipv4 = {conf.router_mac}")
        print(f"router-mac-ipv6 = {conf.router_mac}")
    print("# TARGET SELECTION (IP, PORTS, EXCLUDES)")
    print(f"ports = {conf.ports}")
    for r in conf.ranges:
        print(f"range = {r}")


def handle_readscan(conf):
    print(PCAP_FAIL)
    if not conf.readscan:
        return False
    if not os.path.exists(conf.readscan):
        print("[-] FAIL: --readscan")
        print(f"[-] {conf.readscan}: No such file or directory")
        return True
    print(f"[+] --readscan {conf.readscan}")
    try:
        with open(conf.readscan, "rb") as f:
            hdr = f.read(16)
    except OSError as e:
        print(f"[-] {conf.readscan}: {e.strerror}")
        return True
    if not hdr.startswith(b"masscan/1.1"):
        print(f"[-] {conf.readscan}: unknown file format (expeced \"masscan/1.1\")")
        return True
    if conf.outfile and conf.outfile != "-":
        mode = "ab" if conf.outfmt == "binary" else "a"
        with open(conf.outfile, mode) as f:
            if "b" not in mode:
                f.write("")
    return True


def main(argv):
    conf = parse_args(argv)
    if conf.selftest:
        print(PCAP_FAIL)
        print("regression test: success!")
        return 0
    if conf.errors:
        for e in conf.errors:
            print(e)
        print(PCAP_FAIL)
        print(SHORT_HELP, end="")
        return 0
    if conf.iflist:
        print(PCAP_FAIL)
        print("libpcap not loaded")
        return 0
    if conf.echo:
        echo(conf)
        return 0
    if conf.readscan:
        handle_readscan(conf)
        return 0
    print(PCAP_FAIL)
    if not conf.ranges and conf.ports:
        print("FAIL: target IP address list empty")
        print(' [hint] try something like "--range 10.0.0.0/8"')
        print(' [hint] try something like "--range 192.168.0.100-192.168.0.200"')
    elif not conf.ranges and not conf.ports:
        print(SHORT_HELP, end="")
    elif not conf.ports:
        print("FAIL: no ports were specified")
        print(' [hint] try something like "-p80,8000-9000"')
    else:
        print("[-] FAIL: could not determine default interface")
        print('    [hint] try "--interface ethX"')
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
