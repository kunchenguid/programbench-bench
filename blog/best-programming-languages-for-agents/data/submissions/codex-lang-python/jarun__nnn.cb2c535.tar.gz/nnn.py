#!/usr/bin/env python3
import curses
import os
import select
import stat
import sys
import time
from dataclasses import dataclass


VERSION = "5.2"

USAGE = """usage: nnn [OPTIONS] [PATH]

The unorthodox terminal file manager.

positional args:
  PATH   start dir/file [default: .]

optional args:
 -a      auto NNN_FIFO
 -A      no dir auto-enter during filter
 -b key  open bookmark key (trumps -s/S)
 -B      use bsdtar for archives
 -c      cli-only NNN_OPENER (trumps -e)
 -C      8-color scheme
 -d      detail mode
 -D      dirs in context color
 -e      text in $VISUAL/$EDITOR/vi
 -E      internal edits in EDITOR
 -f      use history file
 -F val  fifo mode [0:preview 1:explore]
 -g      regex filters
 -H      show hidden files
 -i      show current file info
 -J      no auto-advance on selection
 -K      detect key collision and exit
 -l val  set scroll lines
 -n      type-to-nav mode
 -N      use native prompt
 -o      open files only on Enter
 -p file selection file [-:stdout]
 -P key  run plugin key
 -Q      no quit confirmation
 -r      use advcpmv patched cp, mv
 -R      no rollover at edges
 -s name load session by name
 -S      persistent session
 -t secs timeout to lock
 -T key  sort order [a/d/e/r/s/t/v]
 -u      use selection (no prompt)
 -U      show user and group
 -V      show version
 -x      notis, selection sync, xterm title
 -z      in order fuzzy filters
 -0      null separator in picker mode
 -h      show help

v5.2
BSD 2-Clause
https://github.com/jarun/nnn
"""


NOARG_OPTS = set("aABcCdDeEfgHiJKnNoQrRSuUVxz0")
ARG_OPTS = set("bFlpPstT")
VALID_SORTS = set("aderstv")


@dataclass
class Options:
    detail: bool = False
    show_hidden: bool = False
    picker: str | None = None
    null_sep: bool = False
    sort_key: str = "v"
    reverse: bool = False
    path: str = "."


def print_usage() -> None:
    sys.stdout.write(USAGE)


def option_error(message: str) -> int:
    prog = os.environ.get("NNN_ARGV0", sys.argv[0])
    sys.stderr.write(f"{prog}: {message}\n")
    print_usage()
    return 1


def parse_args(argv: list[str]) -> tuple[int | None, Options]:
    opts = Options()
    paths: list[str] = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            paths.extend(argv[i + 1 :])
            break
        if arg.startswith("--") and arg != "--":
            return option_error("invalid option -- '-'"), opts
        if len(arg) > 1 and arg.startswith("-"):
            j = 1
            while j < len(arg):
                ch = arg[j]
                if ch not in NOARG_OPTS and ch not in ARG_OPTS and ch != "h":
                    return option_error(f"invalid option -- '{ch}'"), opts
                if ch == "h":
                    print_usage()
                    return 0, opts
                if ch == "V":
                    sys.stdout.write(VERSION + "\n")
                    return 0, opts
                if ch in ARG_OPTS:
                    if j + 1 < len(arg):
                        val = arg[j + 1 :]
                    else:
                        i += 1
                        if i >= len(argv):
                            return option_error(f"option requires an argument -- '{ch}'"), opts
                        val = argv[i]
                    apply_arg_opt(opts, ch, val)
                    break
                apply_flag(opts, ch)
                j += 1
        else:
            paths.append(arg)
        i += 1

    if paths:
        opts.path = paths[0]
    return None, opts


def apply_flag(opts: Options, ch: str) -> None:
    if ch == "d":
        opts.detail = True
    elif ch == "H":
        opts.show_hidden = True
    elif ch == "r":
        opts.reverse = True
    elif ch == "0":
        opts.null_sep = True


def apply_arg_opt(opts: Options, ch: str, val: str) -> None:
    if ch == "p":
        opts.picker = val
    elif ch == "T" and val:
        opts.sort_key = val[0] if val[0] in VALID_SORTS else "v"
    elif ch in ("F", "l", "t"):
        # The real nnn mostly accepts numeric-looking option payloads leniently.
        pass


def natural_key(name: str):
    parts: list[object] = []
    buf = ""
    numeric = False
    for c in name:
        is_digit = c.isdigit()
        if buf and is_digit != numeric:
            parts.append(int(buf) if numeric else buf.casefold())
            buf = c
        else:
            buf += c
        numeric = is_digit
    if buf:
        parts.append(int(buf) if numeric else buf.casefold())
    return parts


def entry_sort_key(path: str, entry: os.DirEntry, key: str):
    try:
        st = entry.stat(follow_symlinks=False)
    except OSError:
        st = None
    name = entry.name
    if key == "s" and st is not None:
        return (not entry.is_dir(follow_symlinks=False), st.st_size, natural_key(name))
    if key == "t" and st is not None:
        return (not entry.is_dir(follow_symlinks=False), -st.st_mtime, natural_key(name))
    if key == "a" and st is not None:
        return (not entry.is_dir(follow_symlinks=False), -st.st_atime, natural_key(name))
    if key == "e":
        return (not entry.is_dir(follow_symlinks=False), os.path.splitext(name)[1].casefold(), natural_key(name))
    return (not entry.is_dir(follow_symlinks=False), natural_key(name))


def read_entries(path: str, opts: Options):
    try:
        entries = [e for e in os.scandir(path) if opts.show_hidden or not e.name.startswith(".")]
    except OSError:
        return []
    entries.sort(key=lambda e: entry_sort_key(path, e, opts.sort_key), reverse=opts.reverse)
    return entries


def format_entry(entry: os.DirEntry, detail: bool) -> str:
    name = entry.name
    try:
        st = entry.stat(follow_symlinks=False)
        is_dir = stat.S_ISDIR(st.st_mode)
        is_link = stat.S_ISLNK(st.st_mode)
    except OSError:
        st = None
        is_dir = False
        is_link = False
    suffix = "/" if is_dir else "@" if is_link else ""
    if not detail or st is None:
        return name + suffix
    mode = stat.filemode(st.st_mode)
    size = st.st_size
    mtime = time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime))
    return f"{mode} {size:>9} {mtime} {name}{suffix}"


def choose_path(path: str) -> str:
    if os.path.isdir(path):
        return os.path.abspath(path)
    if os.path.exists(path):
        return os.path.abspath(os.path.dirname(path) or ".")
    if path.endswith(os.sep):
        parent = path
    else:
        parent = os.path.dirname(path) or "."
    return os.path.abspath(parent if os.path.isdir(parent) else ".")


def write_selection(opts: Options, selected: str) -> None:
    sep = "\0" if opts.null_sep else "\n"
    if opts.picker == "-":
        sys.stdout.write(selected + sep)
        sys.stdout.flush()
    elif opts.picker:
        with open(opts.picker, "a", encoding="utf-8") as f:
            f.write(selected + sep)


def noninteractive(path: str, opts: Options) -> int:
    entries = read_entries(path, opts)
    sys.stderr.write(f"{len(entries)} entries\n")
    sys.stderr.flush()
    if opts.picker:
        return 1
    # The original program waits for terminal input; keep that behavior for
    # pipes so timeout-based probes see the same shape, but wake if stdin has data.
    while True:
        ready, _, _ = select.select([sys.stdin], [], [], 3600)
        if ready and sys.stdin.read(1) in ("q", "\x03", "\x04"):
            return 0


def curses_main(stdscr, start_path: str, opts: Options) -> int:
    curses.curs_set(0)
    stdscr.keypad(True)
    path = start_path
    cursor = 0
    top = 0
    while True:
        entries = read_entries(path, opts)
        if cursor >= len(entries):
            cursor = max(0, len(entries) - 1)
        height, width = stdscr.getmaxyx()
        stdscr.erase()
        title = path
        try:
            stdscr.addnstr(0, 0, title, width - 1, curses.A_REVERSE)
        except curses.error:
            pass
        visible = max(1, height - 2)
        if cursor < top:
            top = cursor
        if cursor >= top + visible:
            top = cursor - visible + 1
        for row, entry in enumerate(entries[top : top + visible], start=1):
            line = format_entry(entry, opts.detail)
            attr = curses.A_REVERSE if (top + row - 1) == cursor else curses.A_NORMAL
            try:
                stdscr.addnstr(row, 0, line, width - 1, attr)
            except curses.error:
                pass
        status = f"{len(entries)} entries"
        try:
            stdscr.addnstr(height - 1, 0, status, width - 1, curses.A_REVERSE)
        except curses.error:
            pass
        stdscr.refresh()
        key = stdscr.getch()
        if key in (ord("q"), 27):
            return 0
        if key in (curses.KEY_DOWN, ord("j")) and entries:
            cursor = min(cursor + 1, len(entries) - 1)
        elif key in (curses.KEY_UP, ord("k")) and entries:
            cursor = max(cursor - 1, 0)
        elif key in (curses.KEY_NPAGE, ord(" ")):
            cursor = min(cursor + visible, max(0, len(entries) - 1))
        elif key == curses.KEY_PPAGE:
            cursor = max(cursor - visible, 0)
        elif key in (10, 13, curses.KEY_ENTER) and entries:
            selected = os.path.join(path, entries[cursor].name)
            if os.path.isdir(selected):
                path = os.path.abspath(selected)
                cursor = top = 0
            else:
                write_selection(opts, selected)
                if opts.picker:
                    return 0
        elif key in (curses.KEY_BACKSPACE, 127, ord("h")):
            parent = os.path.dirname(path)
            if parent and parent != path:
                path = parent
                cursor = top = 0


def main(argv: list[str]) -> int:
    code, opts = parse_args(argv)
    if code is not None:
        return code
    start_path = choose_path(opts.path)
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return noninteractive(start_path, opts)
    try:
        return curses.wrapper(curses_main, start_path, opts)
    except curses.error:
        return noninteractive(start_path, opts)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
