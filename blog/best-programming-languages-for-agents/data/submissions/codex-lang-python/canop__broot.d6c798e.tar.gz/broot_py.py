#!/usr/bin/env python3
import os
import shutil
import stat
import sys
import time
from pathlib import Path

VERSION = "1.54.0"

FLAGS_WITH_VALUE = {
    "--conf",
    "--max-depth",
    "--outcmd",
    "--verb-output",
    "--cmd",
    "-c",
    "--color",
    "--height",
    "--set-install-state",
    "--print-shell-function",
    "--listen",
    "--write-default-conf",
    "--send",
}

KNOWN_FLAGS = {
    "--help",
    "--version",
    "--dates",
    "-d",
    "--no-dates",
    "-D",
    "--only-folders",
    "-f",
    "--no-only-folders",
    "-F",
    "--show-root-fs",
    "--show-git-info",
    "-g",
    "--no-show-git-info",
    "-G",
    "--git-status",
    "--hidden",
    "-h",
    "--no-hidden",
    "-H",
    "--git-ignored",
    "-i",
    "--no-git-ignored",
    "-I",
    "--permissions",
    "-p",
    "--no-permissions",
    "-P",
    "--sizes",
    "-s",
    "--no-sizes",
    "-S",
    "--sort-by-count",
    "--sort-by-date",
    "--sort-by-size",
    "--sort-by-type",
    "--sort-by-type-dirs-first",
    "--sort-by-type-dirs-last",
    "--no-sort",
    "--no-tree",
    "--tree",
    "--whale-spotting",
    "-w",
    "--no-whale-spotting",
    "-W",
    "--trim-root",
    "-t",
    "--no-trim-root",
    "-T",
    "--install",
    "--listen-auto",
    "--get-root",
} | FLAGS_WITH_VALUE


def eprint(*args):
    print(*args, file=sys.stderr)


def usage_line(prog: str) -> str:
    return f"Usage: {prog} [OPTIONS] [ROOT]"


def error(msg: str, prog: str = "executable", tip_arg: str | None = None) -> int:
    eprint(f"error: {msg}")
    if tip_arg:
        eprint()
        eprint(f"  tip: to pass '{tip_arg}' as a value, use '-- {tip_arg}'")
    eprint()
    eprint(usage_line(prog))
    return 2


def help_text(color: bool = False) -> str:
    return f"""broot {VERSION}

broot lets you explore file hierarchies with a tree-like view, manipulate and preview files,
launch actions, and define your own shortcuts.

broot is best launched as br: this shell function gives you access to more commands,
especially cd. The br shell function is interactively installed on first broot launch.

Flags and options can be classically passed on launch but also written in the configuration
file. Each flag has a counter-flag so that you can cancel at command line a flag which has
been set in the configuration file.

Complete documentation and tips at https://dystroy.org/broot

Usage: broot [options] [ROOT]

ROOT : Root Directory

Options:
      --help                         Print help information
      --version                      print the version
      --conf <paths>                 Semicolon separated paths to specific config files
  -d, --dates                        Show the last modified date of files and directories
  -D, --no-dates                     Don't show the last modified date
  -f, --only-folders                 Only show folders
  -F, --no-only-folders              Show folders and files alike
      --show-root-fs                 Show filesystem info on top
      --max-depth <MAX_DEPTH>        Only show trees up to a certain depth
  -g, --show-git-info                Show git statuses on files and stats on repo
  -G, --no-show-git-info             Don't show git statuses on files and stats on repo
      --git-status                   Only show files having an interesting git status, including hidden ones
  -h, --hidden                       Show hidden files
  -H, --no-hidden                    Don't show hidden files
  -i, --git-ignored                  Show git ignored files
  -I, --no-git-ignored               Don't show git ignored files
  -p, --permissions                  Show permissions
  -P, --no-permissions               Don't show permissions
  -s, --sizes                        Show the size of files and directories
  -S, --no-sizes                     Don't show sizes
      --sort-by-count                Sort by count (only show one level of the tree)
      --sort-by-date                 Sort by date (only show one level of the tree)
      --sort-by-size                 Sort by size (only show one level of the tree)
      --sort-by-type                 Same as sort-by-type-dirs-first
      --sort-by-type-dirs-first      Sort by type, directories first
      --sort-by-type-dirs-last       Sort by type, directories last
      --no-sort                      Don't sort
      --no-tree                      Do not show the tree
      --tree                         Show the tree, when allowed by sorting mode
  -w, --whale-spotting               Sort by size, show ignored and hidden files
  -W, --no-whale-spotting            No sort, no show hidden, no show git ignored
  -t, --trim-root                    Trim the root too and don't show a scrollbar
  -T, --no-trim-root                 Don't trim the root level, show a scrollbar
      --outcmd <path>                Where to write the produced cmd (if any)
      --verb-output <verb-output>    Optional path for verbs using :write_output
  -c, --cmd <cmd>                    Semicolon separated commands to execute
      --color <color>                Whether to have styles and colors [auto, yes, no]
      --height <height>              Height
      --install                      Install or reinstall the br shell function
      --set-install-state <state>    Manually set installation state [undefined, refused, installed]
      --print-shell-function <shell> Print to stdout the br function for a given shell
      --listen <socket>              A socket to listen to for commands
      --listen-auto                  create a random socket to listen to for commands
      --get-root                     Ask for the current root of the remote broot
      --write-default-conf <path>    Write default conf files in given directory
      --send <socket>                A socket to send commands to
"""


BASH_FUNC = """
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `cd`,
# have no useful effect if executed in a subshell.
function br {
    local cmd cmd_file code
    cmd_file=$(mktemp)
    if broot --outcmd "$cmd_file" "$@"; then
        cmd=$(<"$cmd_file")
        command rm -f "$cmd_file"
        eval "$cmd"
    else
        code=$?
        command rm -f "$cmd_file"
        return "$code"
    fi
}
"""

FISH_FUNC = """
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `cd`,
# have no useful effect if executed in a subshell.
function br --wraps=broot
    set -l cmd_file (mktemp)
    if broot --outcmd $cmd_file $argv
        source $cmd_file
        rm -f $cmd_file
    else
        set -l code $status
        rm -f $cmd_file
        return $code
    end
end
"""

POWERSHELL_FUNC = """function br {
    $cmd_file = New-TemporaryFile
    broot --outcmd $cmd_file $args
    if ($LASTEXITCODE -eq 0) {
        $cmd = Get-Content $cmd_file
        Remove-Item $cmd_file
        if ($cmd) { Invoke-Expression $cmd }
    } else {
        $code = $LASTEXITCODE
        Remove-Item $cmd_file
        exit $code
    }
}
"""

NUSHELL_FUNC = """# Launch broot
export def --env br [
    --cmd(-c): string
    --color: string = "auto"
    --help
    --version
    file?: path
] {
    let cmd_file = ($nu.temp-path | path join $"broot-(random chars).tmp")
    touch $cmd_file
    ^broot --outcmd $cmd_file
    let cmd = (open $cmd_file)
    rm -p -f $cmd_file
    if (not ($cmd | lines | is-empty)) {
        cd ($cmd | parse -r `^cd\\s+(?<quote>"|'|)(?<path>.+)\\k<quote>[\\s\\r\\n]*$` | get path | to text)
    }
}

export extern broot [
    --cmd(-c): string
    --color: string = "auto"
    --help
    --version
    file?: path
]
"""


def print_shell_function(shell: str) -> int:
    s = shell.lower()
    if s in ("bash", "zsh"):
        print(BASH_FUNC)
    elif s == "fish":
        print(FISH_FUNC)
    elif s in ("powershell", "pwsh"):
        print(POWERSHELL_FUNC)
    elif s in ("nushell", "nu"):
        print(NUSHELL_FUNC)
    else:
        eprint(f"Unknown shell: {shell}")
        return 1
    return 0


def parse_args(argv: list[str]):
    opts: dict[str, str | bool | list[str]] = {"positionals": []}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            opts["positionals"].extend(argv[i + 1 :])
            break
        if arg.startswith("--") and "=" in arg:
            key, val = arg.split("=", 1)
            if key not in KNOWN_FLAGS:
                raise ValueError(f"unexpected argument '{key}' found|{key}")
            if key not in FLAGS_WITH_VALUE:
                raise ValueError(f"unexpected value for '{key}'")
            opts[key] = val
        elif arg in FLAGS_WITH_VALUE:
            if i + 1 >= len(argv):
                raise ValueError(f"a value is required for '{arg} <value>' but none was supplied")
            opts[arg] = argv[i + 1]
            i += 1
        elif arg in KNOWN_FLAGS:
            opts[arg] = True
        elif arg.startswith("-"):
            raise ValueError(f"unexpected argument '{arg}' found|{arg}")
        else:
            opts["positionals"].append(arg)
        i += 1
    return opts


def resources_dir() -> Path:
    here = Path(__file__).resolve().parent
    return here / "resources" / "default-conf"


def write_default_conf(dest: str) -> int:
    src = resources_dir()
    d = Path(dest).expanduser()
    d.mkdir(parents=True, exist_ok=True)
    if src.is_dir():
        for child in src.iterdir():
            target = d / child.name
            if child.is_dir():
                shutil.copytree(child, target, dirs_exist_ok=True)
            else:
                shutil.copy2(child, target)
    else:
        (d / "conf.hjson").write_text("# broot configuration\n", encoding="utf-8")
        (d / "verbs.hjson").write_text("verbs: []\n", encoding="utf-8")
    return 0


def mode_string(st: os.stat_result) -> str:
    return stat.filemode(st.st_mode)


def size_string(n: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    v = float(n)
    for u in units:
        if v < 1000 or u == units[-1]:
            if u == "B":
                return f"{int(v)} B"
            return f"{v:.1f} {u}".replace(".0 ", " ")
        v /= 1000
    return f"{n} B"


def list_entries(root: Path, opts: dict) -> list[Path]:
    show_hidden = bool(opts.get("--hidden") or opts.get("-h") or opts.get("--whale-spotting") or opts.get("-w") or opts.get("--git-status"))
    only_dirs = bool(opts.get("--only-folders") or opts.get("-f"))
    try:
        entries = list(root.iterdir())
    except OSError:
        return []
    filtered = []
    for p in entries:
        if not show_hidden and p.name.startswith("."):
            continue
        if only_dirs and not p.is_dir():
            continue
        filtered.append(p)
    if opts.get("--no-sort"):
        return filtered
    if opts.get("--sort-by-size") or opts.get("--whale-spotting") or opts.get("-w"):
        return sorted(filtered, key=lambda p: safe_stat(p).st_size if safe_stat(p) else 0, reverse=True)
    if opts.get("--sort-by-date"):
        return sorted(filtered, key=lambda p: safe_stat(p).st_mtime if safe_stat(p) else 0, reverse=True)
    if opts.get("--sort-by-type-dirs-last"):
        return sorted(filtered, key=lambda p: (p.is_dir(), p.name.lower()))
    return sorted(filtered, key=lambda p: (not p.is_dir(), p.name.lower()))


def safe_stat(p: Path):
    try:
        return p.stat()
    except OSError:
        return None


def tree(root: Path, opts: dict, depth: int = 0, prefix: str = "") -> list[str]:
    max_depth = int(opts.get("--max-depth") or 3)
    if depth >= max_depth:
        return []
    lines = []
    entries = list_entries(root, opts)
    for idx, p in enumerate(entries):
        last = idx == len(entries) - 1
        branch = "└── " if last else "├── "
        st = safe_stat(p)
        cols = []
        if opts.get("--permissions") or opts.get("-p"):
            cols.append(mode_string(st) if st else "??????????")
        if opts.get("--sizes") or opts.get("-s"):
            cols.append(size_string(st.st_size) if st else "? B")
        if opts.get("--dates") or opts.get("-d"):
            cols.append(time.strftime("%Y/%m/%d %H:%M", time.localtime(st.st_mtime)) if st else "????/??/?? ??:??")
        name = p.name + ("/" if p.is_dir() else "")
        meta = (" ".join(cols) + " ") if cols else ""
        lines.append(f"{prefix}{branch}{meta}{name}")
        if p.is_dir() and not opts.get("--sort-by-count") and not opts.get("--sort-by-date") and not opts.get("--sort-by-size") and not opts.get("--sort-by-type") and not opts.get("--sort-by-type-dirs-first") and not opts.get("--sort-by-type-dirs-last"):
            lines.extend(tree(p, opts, depth + 1, prefix + ("    " if last else "│   ")))
    return lines


def run_tree(root_arg: str | None, opts: dict) -> int:
    root = Path(root_arg or ".").expanduser()
    if not root.exists():
        eprint(f"Cannot read {root}: No such file or directory")
        return 1
    if root.is_file():
        print(str(root))
        return 0
    if not opts.get("--trim-root") and not opts.get("-t"):
        print(str(root.resolve() if root_arg else root))
    if not opts.get("--no-tree"):
        for line in tree(root, opts):
            print(line)
    return 0


def handle_cmd(cmd: str, root: str | None, opts: dict) -> int:
    code = 0
    for raw in cmd.split(";"):
        c = raw.strip()
        if not c:
            continue
        if c in (":q", ":quit", "q", "quit"):
            continue
        if c in (":print_tree", ":pt", ":tree"):
            code = run_tree(root, opts)
        elif c in (":pwd", ":print_path", ":get_root"):
            print(str(Path(root or ".").resolve()))
        elif c.startswith(":focus "):
            root = c.split(" ", 1)[1]
        else:
            # Treat a bare token like broot's search input: show matching names.
            opts2 = dict(opts)
            matches_root = Path(root or ".")
            needle = c.lstrip(":").lower()
            for p in list_entries(matches_root, opts2):
                if needle in p.name.lower():
                    print(p.name)
    return code


def main(argv: list[str]) -> int:
    prog = Path(sys.argv[0]).name or "executable"
    try:
        opts = parse_args(argv)
    except ValueError as ex:
        msg = str(ex)
        tip = None
        if "|" in msg:
            msg, tip = msg.split("|", 1)
        return error(msg, prog, tip)

    color = opts.get("--color")
    if color and color not in ("auto", "yes", "no"):
        eprint(f"error: invalid value '{color}' for '--color <color>'")
        eprint("  [possible values: auto, yes, no]")
        return 2
    state = opts.get("--set-install-state")
    if state and state not in ("undefined", "refused", "installed"):
        eprint(f"error: invalid value '{state}' for '--set-install-state <state>'")
        eprint("  [possible values: undefined, refused, installed]")
        return 2

    if opts.get("--help"):
        print(help_text(color != "no"))
        return 0
    if opts.get("--version"):
        print(f"broot {VERSION}")
        return 0
    if opts.get("--print-shell-function"):
        return print_shell_function(str(opts["--print-shell-function"]))
    if opts.get("--write-default-conf"):
        return write_default_conf(str(opts["--write-default-conf"]))
    if opts.get("--get-root"):
        print(str(Path(".").resolve()))
        return 0

    outcmd = opts.get("--outcmd")
    if outcmd:
        Path(str(outcmd)).write_text("", encoding="utf-8")

    positionals = opts.get("positionals", [])
    root = positionals[0] if positionals else None
    if len(positionals) > 1:
        return error(f"unexpected argument '{positionals[1]}' found", prog, positionals[1])

    cmd = opts.get("--cmd") or opts.get("-c")
    if cmd:
        return handle_cmd(str(cmd), root, opts)
    return run_tree(root, opts)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
