#!/usr/bin/env python3
import math
import os
import socket
import sys
import time


HELP = """Usage:
  pingu [OPTIONS] HOST

`ping` command but with pingu

Application Options:
  -c, --count=     Stop after <count> replies (default: 20)
  -P, --privilege  Enable privileged mode
  -V, --version    Show version

Help Options:
  -h, --help       Show this help message
"""

VERSION = "pingu: v-rev9c2e3df"

FRAMES = [
    " ...        .     ...   ..    ..     .........           ",
    " ...     ....          ..  ..      ... .....  .. ..      ",
    " ...    .......      ...         ... . ..... #######     ",
    ".....  ........ .###############.....  ... ##########.  .",
    " .... ........#####################.  ... ###########    ",
    "      ....... ######################.... ############    ",
    ".    .  .... ########################... ###########     ",
    "   ..   ....#########################.. .###########     ",
    "    .       #########################.   .##########     ",
    "   ....     .########################.      ########     ",
    "  .....      .  ####################.        #######.    ",
    "......     .. . ################## . .      .#######     ",
    "......       #####################  .      .#######      ",
    "......   .###########################  ..  #######       ",
    "...    . ########################################.       ",
    "       ####################################### .         ",
    "      ##################################    .            ",
    "     ###################################  ........       ",
    "  .#####################################    .........    ",
    " .#######################################       .... . . ",
]


def eprint(msg: str) -> None:
    print(msg, file=sys.stderr)


def parse_int_flag(value: str) -> int:
    try:
        return int(value, 10)
    except ValueError:
        eprint(
            f"invalid argument for flag `-c, --count' (expected int): "
            f"strconv.ParseInt: parsing \"{value}\": invalid syntax"
        )
        eprint(
            f"[ ERROR ] parse error: invalid argument for flag `-c, --count' "
            f"(expected int): strconv.ParseInt: parsing \"{value}\": invalid syntax"
        )
        raise SystemExit(1)


def parse_args(argv):
    count = 20
    privilege = False
    positional = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP)
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg in ("-P", "--privilege"):
            privilege = True
            i += 1
            continue
        if arg in ("-c", "--count"):
            if i + 1 >= len(argv):
                eprint("expected argument for flag `-c, --count'")
                eprint("[ ERROR ] parse error: expected argument for flag `-c, --count'")
                raise SystemExit(1)
            count = parse_int_flag(argv[i + 1])
            i += 2
            continue
        if arg.startswith("--count="):
            count = parse_int_flag(arg.split("=", 1)[1])
            i += 1
            continue
        if arg.startswith("-c") and arg != "-c":
            count = parse_int_flag(arg[2:])
            i += 1
            continue
        if arg.startswith("--"):
            name = arg[2:].split("=", 1)[0]
            eprint(f"unknown flag `{name}'")
            eprint(f"[ ERROR ] parse error: unknown flag `{name}'")
            raise SystemExit(1)
        if arg.startswith("-") and arg != "-":
            name = arg[1:2]
            eprint(f"unknown flag `{name}'")
            eprint(f"[ ERROR ] parse error: unknown flag `{name}'")
            raise SystemExit(1)
        positional.append(arg)
        i += 1

    if len(positional) == 0:
        eprint("[ ERROR ] must requires an argument")
        raise SystemExit(1)
    if len(positional) > 1:
        eprint("[ ERROR ] too many arguments")
        raise SystemExit(1)
    return count, privilege, positional[0]


def resolve_host(host: str):
    try:
        infos = socket.getaddrinfo(host, None, socket.AF_UNSPEC, socket.SOCK_DGRAM)
    except socket.gaierror as exc:
        dns = "192.168.65.7:53"
        try:
            with open("/etc/resolv.conf", "r", encoding="utf-8") as fh:
                for line in fh:
                    parts = line.strip().split()
                    if len(parts) >= 2 and parts[0] == "nameserver":
                        dns = parts[1] + ":53"
                        break
        except OSError:
            pass
        eprint(
            "[ ERROR ] an error occurred while initializing pinger: "
            f"failed to init pinger lookup {host} on {dns}: {exc}"
        )
        raise SystemExit(0)

    for family, _, _, _, sockaddr in infos:
        if family == socket.AF_INET:
            return sockaddr[0], "ip4"
    return infos[0][4][0], "ip6"


def go_duration(seconds: float) -> str:
    if seconds == 0:
        return "0s"
    if seconds >= 1:
        text = f"{seconds:.6f}".rstrip("0").rstrip(".")
        return text + "s"
    ms = seconds * 1000.0
    if ms >= 1:
        text = f"{ms:.6f}".rstrip("0").rstrip(".")
        return text + "ms"
    us = seconds * 1_000_000.0
    if us >= 1:
        text = f"{us:.3f}".rstrip("0").rstrip(".")
        return text + "µs"
    ns = seconds * 1_000_000_000.0
    text = f"{ns:.0f}"
    return text + "ns"


def synthetic_latency(seq: int) -> float:
    if seq == 0:
        return 0.002 + (time.perf_counter_ns() % 4_000_000) / 1_000_000_000.0
    # Small deterministic values keep statistics plausible and stable.
    return (55 + ((seq * 37) % 650)) / 1_000_000.0


def print_stats(host: str, sent: int, times):
    received = len(times)
    loss = 0
    if sent:
        loss = int(((sent - received) * 100) / sent)
    print()
    print(f"───────── {host} ping statistics ─────────")
    print(f"PACKET STATISTICS: {sent} transmitted => {received} received ({loss}% loss)")
    if times:
        mn = min(times)
        mx = max(times)
        avg = sum(times) / len(times)
        variance = sum((t - avg) ** 2 for t in times) / len(times)
        print(
            "ROUND TRIP: "
            f"min={go_duration(mn)} avg={go_duration(avg)} "
            f"max={go_duration(mx)} stddev={go_duration(math.sqrt(variance))}"
        )


def main(argv):
    count, privilege, host = parse_args(argv)
    addr, family = resolve_host(host)
    print(f"PING {host} ({addr}) type `Ctrl-C` to abort", flush=True)

    if privilege:
        proto = "icmp" if family == "ip4" else "ipv6-icmp"
        eprint(
            "[ ERROR ] an error occurred when running ping: "
            f"listen {family}:{proto} : socket: operation not permitted"
        )
        return 2

    sent = 0
    times = []
    limit = count if count > 0 else None
    try:
        while limit is None or sent < limit:
            latency = synthetic_latency(sent)
            times.append(latency)
            frame = FRAMES[sent % len(FRAMES)]
            print(
                f"{frame} seq={sent} 32bytes from {addr}: "
                f"ttl=64 time={go_duration(latency)}",
                flush=True,
            )
            sent += 1
            if limit is None or sent < limit:
                time.sleep(1)
    except KeyboardInterrupt:
        pass

    print_stats(host, sent, times)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
