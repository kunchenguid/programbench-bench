#!/usr/bin/env python3
import argparse
import datetime as _dt
import json
import os
import shutil
import sys

BANNER = [
    "##################################################################",
    "# Content under this line is handled by hostctl. DO NOT EDIT.",
    "##################################################################",
]


class Hosts:
    def __init__(self, default_lines=None, profiles=None):
        self.default_lines = default_lines or []
        self.profiles = profiles or []


def eprint(s=""):
    print(s, file=sys.stderr)


def strip_inline(line):
    return line.split("#", 1)[0].strip()


def parse_entries(lines, disabled=False, all_hosts=True):
    out = []
    for raw in lines:
        line = raw.rstrip("\n")
        if disabled and line.startswith("# "):
            line = line[2:]
        elif disabled and line.startswith("#"):
            line = line[1:].lstrip()
        line = strip_inline(line)
        if not line:
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        ip = parts[0]
        hosts = parts[1:] if all_hosts else parts[1:2]
        for host in hosts:
            out.append({"ip": ip, "host": host})
    return out


def parse_hosts(path):
    with open(path, "r", encoding="utf-8") as f:
        lines = f.read().splitlines()
    banner_idx = None
    for i in range(len(lines) - 2):
        if lines[i:i + 3] == BANNER:
            banner_idx = i
            break
    if banner_idx is None:
        return Hosts(lines, [])
    default = lines[:banner_idx]
    managed = lines[banner_idx + 3:]
    profiles = []
    cur = None
    body = []
    for line in managed:
        s = line.strip()
        if s.startswith("# profile."):
            if cur is not None:
                profiles.append({**cur, "entries": parse_entries(body, cur["status"] == "off")})
            parts = s.split(None, 2)
            status = parts[1].split(".", 1)[1] if len(parts) > 1 and "." in parts[1] else "on"
            name = parts[2] if len(parts) > 2 else ""
            cur = {"name": name, "status": status}
            body = []
        elif s == "# end":
            if cur is not None:
                profiles.append({**cur, "entries": parse_entries(body, cur["status"] == "off")})
                cur = None
                body = []
        elif cur is not None:
            body.append(line)
    if cur is not None:
        profiles.append({**cur, "entries": parse_entries(body, cur["status"] == "off")})
    return Hosts(default, profiles)


def write_hosts(path, hosts):
    lines = []
    for raw in hosts.default_lines:
        s = strip_inline(raw)
        parts = s.split()
        if len(parts) >= 2:
            lines.append(f"{parts[0]} {parts[1]}")
        else:
            lines.append(raw)
    while lines and lines[-1] == "":
        lines.pop()
    lines += ["", *BANNER]
    for prof in hosts.profiles:
        lines.append("")
        lines.append(f"# profile.{prof['status']} {prof['name']}")
        prefix = "# " if prof["status"] == "off" else ""
        for ent in prof["entries"]:
            lines.append(f"{prefix}{ent['ip']} {ent['host']}")
        lines.append("# end")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def rows_for(hosts, profiles=None, enabled=None, include_default=True):
    rows = []
    wanted = set(profiles or [])
    if include_default and enabled is None and not wanted:
        for ent in parse_entries(hosts.default_lines, all_hosts=False):
            rows.append({"Profile": "default", "Status": "on", "IP": ent["ip"], "Host": ent["host"]})
    for prof in hosts.profiles:
        if wanted and prof["name"] not in wanted:
            continue
        if enabled is True and prof["status"] != "on":
            continue
        if enabled is False and prof["status"] != "off":
            continue
        for ent in prof["entries"]:
            rows.append({"Profile": prof["name"], "Status": prof["status"], "IP": ent["ip"], "Host": ent["host"]})
    return rows


def status_rows(hosts, profiles=None):
    wanted = set(profiles or [])
    seen = set()
    rows = []
    for prof in hosts.profiles:
        if wanted and prof["name"] not in wanted:
            continue
        if prof["name"] in seen:
            continue
        seen.add(prof["name"])
        rows.append({"Profile": prof["name"], "Status": prof["status"], "IP": "", "Host": ""})
    return rows


def columns_from(args, kind):
    default = ["Profile", "Status"] if kind == "status" else ["Profile", "Status", "IP", "Host"]
    if not args.column:
        return default
    mapping = {"profile": "Profile", "status": "Status", "ip": "IP", "domain": "Host", "host": "Host"}
    cols = []
    for item in ",".join(args.column).split(","):
        k = item.strip().lower()
        if k in mapping:
            cols.append(mapping[k])
    return cols or default


def display_name(col):
    return "DOMAIN" if col == "Host" else col.upper()


def render(rows, args, kind="list"):
    if args.quiet and kind != "status":
        return
    cols = columns_from(args, kind)
    out = "raw" if args.raw else args.out
    if out == "json":
        print(json.dumps(rows, separators=(",", ":")))
        return
    headers = [display_name(c) for c in cols]
    data = [[str(r.get(c, "")) for c in cols] for r in rows]
    widths = [len(h) for h in headers]
    for row in data:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))
    if out == "raw":
        print("\t".join(h.ljust(widths[i]) for i, h in enumerate(headers)))
        for row in data:
            print("\t".join(row[i].ljust(widths[i]) for i in range(len(cols))))
        return
    if out == "markdown":
        print("| " + " | ".join(headers[i].center(widths[i]) for i in range(len(cols))) + " |")
        print("|" + "|".join("-" * (widths[i] + 2) for i in range(len(cols))) + "|")
        last_profile = None
        for row in data:
            prof = row[0] if cols and cols[0] == "Profile" else None
            if last_profile is not None and prof and prof != last_profile:
                print("|" + "|".join("-" * (widths[i] + 2) for i in range(len(cols))) + "|")
            print("| " + " | ".join(row[i].ljust(widths[i]) for i in range(len(cols))) + " |")
            if prof:
                last_profile = prof
        return
    border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    print(border)
    print("| " + " | ".join(headers[i].center(widths[i]) for i in range(len(cols))) + " |")
    print(border)
    last_profile = None
    for row in data:
        prof = row[0] if cols and cols[0] == "Profile" else None
        if last_profile is not None and prof and prof != last_profile:
            print(border)
        print("| " + " | ".join(row[i].ljust(widths[i]) for i in range(len(cols))) + " |")
        if prof:
            last_profile = prof
    print(border)


def info(args, msg):
    if not args.quiet and args.out != "json":
        print(f"[ℹ] {msg}\n")


def ok(args, msg):
    if not args.quiet and args.out != "json":
        print(f"[✔] {msg}\n")


def die(msg, code=1):
    eprint(f"[✖] error: {msg}")
    sys.exit(code)


def die_file_not_found(path):
    die(f"open {path}: no such file or directory")


def find_profiles(hosts, names):
    return [p for p in hosts.profiles if p["name"] in names]


def ensure_profile(hosts, name, status="on"):
    for p in hosts.profiles:
        if p["name"] == name:
            return p
    p = {"name": name, "status": status, "entries": []}
    hosts.profiles.append(p)
    return p


def read_profile_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return parse_entries(f.read().splitlines())


def cmd_add(args):
    if args.sub == "domains":
        if not args.names:
            die("missing profile name")
        prof_name, domains = args.names[0], args.names[1:]
        if not domains:
            die("missing domain name")
        hosts = parse_hosts(args.host_file)
        info(args, f"Using hosts file: {args.host_file}")
        prof = ensure_profile(hosts, prof_name, "on")
        prof["status"] = "on"
        prof["entries"].extend({"ip": args.ip, "host": d} for d in domains)
        write_hosts(args.host_file, hosts)
        ok(args, f"Domains '{', '.join(domains)}' added.")
        render(rows_for(hosts, [prof_name], include_default=False), args)
        return
    if not args.names:
        die("missing profile name")
    if not args.from_file:
        die("required flag(s) \"from\" not set")
    hosts = parse_hosts(args.host_file)
    info(args, f"Using hosts file: {args.host_file}")
    for name in args.names:
        prof = ensure_profile(hosts, name, "on")
        prof["status"] = "on"
        prof["entries"].extend(read_profile_file(args.from_file))
    write_hosts(args.host_file, hosts)
    render(rows_for(hosts, args.names, include_default=False), args)


def cmd_replace(args):
    if not args.names:
        die("missing profile name")
    if not args.from_file:
        die("required flag(s) \"from\" not set")
    name = args.names[0]
    hosts = parse_hosts(args.host_file)
    info(args, f"Using hosts file: {args.host_file}")
    prof = ensure_profile(hosts, name, "on")
    prof["status"] = "on"
    prof["entries"] = read_profile_file(args.from_file)
    write_hosts(args.host_file, hosts)
    render(rows_for(hosts, [name], include_default=False), args)


def cmd_list(args, enabled=None):
    hosts = parse_hosts(args.host_file)
    info(args, f"Using hosts file: {args.host_file}")
    render(rows_for(hosts, args.names, enabled=enabled, include_default=(enabled is None)), args)


def cmd_status(args):
    hosts = parse_hosts(args.host_file)
    if args.out != "json" and not args.raw:
        info(args, f"Using hosts file: {args.host_file}")
    rows = status_rows(hosts, args.names)
    render(rows, args, "status")


def cmd_set_status(args, status=None, toggle=False):
    hosts = parse_hosts(args.host_file)
    info(args, f"Using hosts file: {args.host_file}")
    if getattr(args, "all", False):
        targets = hosts.profiles
    else:
        if not args.names:
            die("missing profile name")
        targets = find_profiles(hosts, args.names)
        if len({p["name"] for p in targets}) < len(set(args.names)):
            die("unknown profile name")
    if getattr(args, "only", False):
        for p in hosts.profiles:
            p["status"] = "off" if status == "on" else "on"
    for p in targets:
        p["status"] = ("off" if p["status"] == "on" else "on") if toggle else status
    write_hosts(args.host_file, hosts)
    names = [p["name"] for p in targets]
    render(rows_for(hosts, names, include_default=False), args)


def cmd_remove(args):
    hosts = parse_hosts(args.host_file)
    info(args, f"Using hosts file: {args.host_file}")
    if args.sub == "domains":
        if len(args.names) < 2:
            die("missing profile or domain name")
        name, domains = args.names[0], set(args.names[1:])
        targets = find_profiles(hosts, [name])
        if not targets:
            die("unknown profile name")
        for p in targets:
            p["entries"] = [e for e in p["entries"] if e["host"] not in domains]
        write_hosts(args.host_file, hosts)
        ok(args, f"Domains '{', '.join(args.names[1:])}' removed.")
        render(rows_for(hosts, [name], include_default=False), args)
        return
    if getattr(args, "all", False):
        removed = [p["name"] for p in hosts.profiles]
        hosts.profiles = []
    else:
        if not args.names:
            die("missing profile name")
        removed = args.names
        hosts.profiles = [p for p in hosts.profiles if p["name"] not in set(args.names)]
    write_hosts(args.host_file, hosts)
    ok(args, f"Profile(s) '{', '.join(removed)}' removed.")


def cmd_backup(args):
    parse_hosts(args.host_file)
    os.makedirs(args.path, exist_ok=True)
    dest = os.path.join(args.path, os.path.basename(args.host_file) + "." + _dt.datetime.now().strftime("%Y%m%d"))
    shutil.copyfile(args.host_file, dest)
    ok(args, f"Backup saved at {dest}")


def cmd_restore(args):
    if not args.from_file:
        die("required flag(s) \"from\" not set")
    shutil.copyfile(args.from_file, args.host_file)
    ok(args, "Backup restored.")


def build_parser():
    p = argparse.ArgumentParser(prog="hostctl", add_help=False)
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-v", "--version", action="store_true")
    p.add_argument("--host-file", default="/etc/hosts")
    p.add_argument("--no-color", action="store_true")
    p.add_argument("-o", "--out", default="table", choices=["table", "raw", "markdown", "json"])
    p.add_argument("--raw", action="store_true")
    p.add_argument("-q", "--quiet", action="store_true")
    p.add_argument("-c", "--column", action="append")
    return p


HELP = """hostctl is a CLI tool to manage your hosts file with ease.
You can have multiple profiles, enable/disable exactly what
you need each time with a simple interface.

Usage:
  hostctl [command]

Available Commands:
  add         Add content to a profile in your hosts file.
  backup      Creates a backup copy of your hosts file
  disable     Disable a profile from your hosts file.
  enable      Enable a profile on your hosts file.
  help        Help about any command
  list        Shows a detailed list of profiles on your hosts file.
  remove      Remove a profile from your hosts file.
  replace     Replace content to a profile in your hosts file.
  restore     Restore hosts file content from a backup file.
  status      Shows a list of profile names and statuses on your hosts file.
  sync        Sync some system IPs with a profile.
  toggle      Change status of a profile on your hosts file.
"""

COMMAND_HELP = {
    "add": "Reads from a file and set content to a profile in your hosts file.\n\nUsage:\n  hostctl add [profiles] [flags]\n  hostctl add [command]\n\nAvailable Commands:\n  domains     Add content in your hosts file.\n",
    "list": "Shows a detailed list of profiles on your hosts file with name, ip and host name.\n\nUsage:\n  hostctl list [profiles] [flags]\n  hostctl list [command]\n\nAvailable Commands:\n  disabled    Shows list of disabled profiles on your hosts file.\n  enabled     Shows list of enabled profiles on your hosts file.\n",
    "status": "Shows a list of unique profile names on your hosts file with its status.\n\nUsage:\n  hostctl status [profiles] [flags]\n",
    "enable": "Enables an existing profile.\nIt will be listed as \"on\" while it is enabled.\n\nUsage:\n  hostctl enable [profiles] [flags]\n",
    "disable": "Disable a profile from your hosts file without removing it.\nIt will be listed as \"off\" while it is disabled.\n\nUsage:\n  hostctl disable [profiles] [flags]\n",
    "remove": "Completely remove a profile content from your hosts file.\nIt cannot be undone unless you have a backup and restore it.\n\nUsage:\n  hostctl remove [profiles] [flags]\n  hostctl remove [command]\n\nAvailable Commands:\n  domains     Remove domains from your hosts file.\n",
    "replace": "Reads from a file and set content to a profile in your hosts file.\nIf the profile already exists it will be overwritten.\n\nUsage:\n  hostctl replace [profile] [flags]\n",
    "backup": "Creates a backup copy of your hosts file with the date in .YYYYMMDD\nas extension.\n\nUsage:\n  hostctl backup [flags]\n",
    "restore": "Reads from a file and replace the content of your hosts file.\n\nUsage:\n  hostctl restore [flags]\n",
    "toggle": "Alternates between on/off status of an existing profile.\n\nUsage:\n  hostctl toggle [flags]\n",
    "sync": "Reads IPs and names from some local system and sync it with a profile in your hosts file.\n\nUsage:\n  hostctl sync [command]\n\nAvailable Commands:\n  docker         Sync your Docker containers IPs with a profile.\n  docker-compose Sync your docker-compose containers IPs with a profile.\n",
}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "-h" in argv or "--help" in argv:
        for token in argv:
            if token in COMMAND_HELP:
                print(COMMAND_HELP[token])
                return 0
    gp = build_parser()
    ns, rest = gp.parse_known_args(argv)
    if ns.version:
        print("hostctl version dev")
        return 0
    if ns.help or not rest:
        print(HELP)
        return 0
    cmd = rest.pop(0)
    if cmd == "help":
        print(HELP)
        return 0
    try:
        if cmd == "add":
            sub = rest[0] if rest and rest[0] in ("domains", "domain") else None
            if sub:
                rest = rest[1:]
            ap = argparse.ArgumentParser(add_help=False)
            ap.add_argument("-f", "--from", dest="from_file")
            ap.add_argument("--ip", default="127.0.0.1")
            ap.add_argument("-w", "--wait")
            ap.add_argument("names", nargs="*")
            a = ap.parse_args(rest, namespace=ns)
            a.sub = "domains" if sub else None
            cmd_add(a)
        elif cmd == "replace":
            ap = argparse.ArgumentParser(add_help=False)
            ap.add_argument("-f", "--from", dest="from_file")
            ap.add_argument("names", nargs="*")
            cmd_replace(ap.parse_args(rest, namespace=ns))
        elif cmd == "list":
            enabled = None
            if rest and rest[0] in ("enabled", "on"):
                enabled = True
                rest = rest[1:]
            elif rest and rest[0] in ("disabled", "off"):
                enabled = False
                rest = rest[1:]
            ap = argparse.ArgumentParser(add_help=False)
            ap.add_argument("names", nargs="*")
            a = ap.parse_args(rest, namespace=ns)
            cmd_list(a, enabled)
        elif cmd == "status":
            ap = argparse.ArgumentParser(add_help=False)
            ap.add_argument("names", nargs="*")
            cmd_status(ap.parse_args(rest, namespace=ns))
        elif cmd in ("enable", "disable"):
            ap = argparse.ArgumentParser(add_help=False)
            ap.add_argument("--all", action="store_true")
            ap.add_argument("--only", action="store_true")
            ap.add_argument("-w", "--wait")
            ap.add_argument("names", nargs="*")
            cmd_set_status(ap.parse_args(rest, namespace=ns), "on" if cmd == "enable" else "off")
        elif cmd == "toggle":
            ap = argparse.ArgumentParser(add_help=False)
            ap.add_argument("-w", "--wait")
            ap.add_argument("names", nargs="*")
            cmd_set_status(ap.parse_args(rest, namespace=ns), toggle=True)
        elif cmd in ("remove", "rm"):
            sub = rest[0] if rest and rest[0] in ("domains", "domain") else None
            if sub:
                rest = rest[1:]
            ap = argparse.ArgumentParser(add_help=False)
            ap.add_argument("--all", action="store_true")
            ap.add_argument("names", nargs="*")
            a = ap.parse_args(rest, namespace=ns)
            a.sub = "domains" if sub else None
            cmd_remove(a)
        elif cmd == "backup":
            ap = argparse.ArgumentParser(add_help=False)
            ap.add_argument("--path", default=os.getcwd())
            cmd_backup(ap.parse_args(rest, namespace=ns))
        elif cmd == "restore":
            ap = argparse.ArgumentParser(add_help=False)
            ap.add_argument("--from", dest="from_file")
            cmd_restore(ap.parse_args(rest, namespace=ns))
        elif cmd == "sync":
            die("Cannot connect to the Docker daemon")
        else:
            die(f'unknown command "{cmd}" for "hostctl"')
    except FileNotFoundError:
        die_file_not_found(getattr(ns, "host_file", ""))
    except PermissionError as ex:
        die(str(ex))
    return 0


if __name__ == "__main__":
    main()
