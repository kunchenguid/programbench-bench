#!/usr/bin/env python3
import argparse
import os
import re
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path


VERSION = "git-graph 0.7.0"
MODELS = ["none", "simple", "git-flow"]

LONG_HELP = """Structured Git graphs for your branching model.
    https://github.com/mlange-42/git-graph

EXAMPES:
    git-graph                   -> Show graph
    git-graph --style round     -> Show graph in a different style
    git-graph --model <model>   -> Show graph using a certain <model>
    git-graph model --list      -> List available branching models
    git-graph model             -> Show repo's current branching models
    git-graph model <model>     -> Permanently set model <model> for this repo

Usage: executable [OPTIONS] [COMMAND]

Commands:
  model  Prints or permanently sets the branching model for a repository.
  help   Print this message or the help of the given subcommand(s)

Options:
  -p, --path <path>
          Open repository from this path or above. Default '.'

      --skip-repo-owner-validation
          Skip owner validation for the repository.
          This will turn off libgit2's owner validation, which may increase security risks.
          Please do not disable this validation for repositories you do not trust.

  -m, --model <model>
          Branching model. Available presets are [simple|git-flow|none].
          Default: git-flow. 
          Permanently set the model for a repository with
          > git-graph model <model>

  -n, --max-count <n>
          Maximum number of commits

      --color <color>
          Specify when colors should be used. One of [auto|always|never].
          Default: auto.

      --no-color
          Print without colors. Missing color support should be detected
          automatically (e.g. when piping to a file).
          Overrides option '--color'

  -w, --wrap [<wrap>...]
          Line wrapping for formatted commit text. Default: 'auto 0 8'
          Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
          Examples:
              git-graph --wrap auto
              git-graph --wrap auto 0 8
              git-graph --wrap none
              git-graph --wrap 80
              git-graph --wrap 80 0 8
          'auto' uses the terminal's width if on a terminal.

  -f, --format <format>
          Commit format. One of [oneline|short|medium|full|"<string>"].
            (First character can be used as abbreviation, e.g. '-f m')
          Formatting placeholders for "<string>":
              %n    newline
              %H    commit hash
              %h    abbreviated commit hash
              %P    parent commit hashes
              %p    abbreviated parent commit hashes
              %d    refs (branches, tags)
              %s    commit summary
              %b    commit message body
              %B    raw body (subject and body)
              %an   author name
              %ae   author email
              %ad   author date
              %as   author date in short format 'YYYY-MM-DD'
              %cn   committer name
              %ce   committer email
              %cd   committer date
              %cs   committer date in short format 'YYYY-MM-DD'

  -r, --reverse
          Reverse the order of commits.

  -l, --local
          Show only local branches, no remotes.

      --svg
          Render graph as SVG instead of text-based.

  -d, --debug
          Additional debug output and graphics.

  -S, --sparse
          Print a less compact graph: merge lines point to target lines
          rather than merge commits.

  -s, --style <style>
          Output style. One of [normal/thin|round|bold|double|ascii].
            (First character can be used as abbreviation, e.g. '-s r')

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

SHORT_HELP = """Structured Git graphs for your branching model.
    https://github.com/mlange-42/git-graph

EXAMPES:
    git-graph                   -> Show graph
    git-graph --style round     -> Show graph in a different style
    git-graph --model <model>   -> Show graph using a certain <model>
    git-graph model --list      -> List available branching models
    git-graph model             -> Show repo's current branching models
    git-graph model <model>     -> Permanently set model <model> for this repo

Usage: executable [OPTIONS] [COMMAND]

Commands:
  model  Prints or permanently sets the branching model for a repository.
  help   Print this message or the help of the given subcommand(s)

Options:
  -p, --path <path>                 Open repository from this path or above. Default '.'
      --skip-repo-owner-validation  Skip owner validation for the repository.
                                    This will turn off libgit2's owner validation, which may increase security risks.
                                    Please do not disable this validation for repositories you do not trust.
  -m, --model <model>               Branching model. Available presets are [simple|git-flow|none].
                                    Default: git-flow. 
                                    Permanently set the model for a repository with
                                    > git-graph model <model>
  -n, --max-count <n>               Maximum number of commits
      --color <color>               Specify when colors should be used. One of [auto|always|never].
                                    Default: auto.
      --no-color                    Print without colors. Missing color support should be detected
                                    automatically (e.g. when piping to a file).
                                    Overrides option '--color'
  -w, --wrap [<wrap>...]            Line wrapping for formatted commit text. Default: 'auto 0 8'
                                    Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
                                    For examples, consult 'git-graph --help'
  -f, --format <format>             Commit format. One of [oneline|short|medium|full|"<string>"].
                                      (First character can be used as abbreviation, e.g. '-f m')
                                    Default: oneline.
                                    For placeholders supported in "<string>", consult 'git-graph --help'
  -r, --reverse                     Reverse the order of commits.
  -l, --local                       Show only local branches, no remotes.
      --svg                         Render graph as SVG instead of text-based.
  -d, --debug                       Additional debug output and graphics.
  -S, --sparse                      Print a less compact graph: merge lines point to target lines
                                    rather than merge commits.
  -s, --style <style>               Output style. One of [normal/thin|round|bold|double|ascii].
                                      (First character can be used as abbreviation, e.g. '-s r')
  -h, --help                        Print help (see more with '--help')
  -V, --version                     Print version
"""

MODEL_HELP = """Prints or permanently sets the branching model for a repository.

Usage: executable model [OPTIONS] [model]

Arguments:
  [model]  The branching model to be used. Available presets are [simple|git-flow|none].
           When not given, prints the currently set model.

Options:
  -l, --list  List all available branching models.
  -h, --help  Print help
"""


def run(cmd, cwd=None, check=True):
    p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode:
        raise subprocess.CalledProcessError(p.returncode, cmd, p.stdout, p.stderr)
    return p


def error(msg, status=1):
    print(msg, file=sys.stderr)
    sys.exit(status)


def repo_root(path):
    p = Path(path)
    try:
        resolved = p.resolve()
    except FileNotFoundError:
        error(f"ERROR: failed to resolve path '{path}': No such file or directory\n       Navigate into a repository before running git-graph, or use option --path")
    r = run(["git", "-C", str(resolved), "rev-parse", "--show-toplevel"], check=False)
    if r.returncode:
        error(f"ERROR: could not find repository at '{path}'\n       Navigate into a repository before running git-graph, or use option --path")
    return Path(r.stdout.strip())


def git_dir(root):
    return Path(run(["git", "-C", str(root), "rev-parse", "--git-dir"]).stdout.strip())


def graph_config(root):
    gd = git_dir(root)
    if not gd.is_absolute():
        gd = root / gd
    return gd / "git-graph.toml"


def current_model(root):
    cfg = graph_config(root)
    if cfg.exists():
        m = re.search(r'model\s*=\s*"([^"]+)"', cfg.read_text(errors="ignore"))
        if m:
            return m.group(1)
    return None


def available_models():
    names = list(MODELS)
    cfg = Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "git-graph" / "models"
    if cfg.exists():
        for f in sorted(cfg.glob("*.toml")):
            if f.stem not in names:
                names.append(f.stem)
    return names


def validate_model(model):
    if model not in available_models():
        error(f"ERROR: No branching model named '{model}' found in /home/agent/.config/git-graph/models\n       Available models are: none, simple, git-flow")


def handle_model(args, path="."):
    if args and args[0] in ("-h", "--help"):
        print(MODEL_HELP, end="")
        return 0
    if args and args[0] in ("-l", "--list"):
        print("\n".join(available_models()))
        return 0
    root = repo_root(path)
    if not args:
        m = current_model(root)
        if m:
            print(m, end="")
        else:
            print("No branching model set", end="")
        return 0
    model = args[0]
    validate_model(model)
    graph_config(root).write_text(f'model = "{model}"\n')
    print(f"Branching model set to '{model}'", end="")
    return 0


def style_chars(style):
    s = (style or "normal").lower()
    if s.startswith("a"):
        return {"commit": "*", "merge": "o", "vert": "|", "tee": "|-", "corner": ".-", "join": "|-'", "left": "<"}
    if s.startswith("b"):
        return {"commit": "●", "merge": "○", "vert": "┃", "tee": "┣", "corner": "┓", "join": "┣━┛", "left": "<"}
    if s.startswith("d"):
        return {"commit": "●", "merge": "○", "vert": "║", "tee": "╠", "corner": "╗", "join": "╠═╝", "left": "<"}
    if s.startswith("r"):
        return {"commit": "●", "merge": "○", "vert": "│", "tee": "├", "corner": "╮", "join": "├─╯", "left": "<"}
    return {"commit": "●", "merge": "○", "vert": "│", "tee": "├", "corner": "┐", "join": "├─┘", "left": "<"}


def pretty_format(fmt):
    aliases = {"o": "oneline", "s": "short", "m": "medium", "f": "full"}
    fmt = aliases.get(fmt, fmt)
    if fmt == "oneline":
        return "%h%d %s"
    if fmt == "short":
        return "commit %H%d%nAuthor: %an <%ae>%n%n    %s%n"
    if fmt == "medium":
        return "commit %H%d%n%PARENTS%Author: %an <%ae>%nDate:   %ad%n%n    %s%n%n%b"
    if fmt == "full":
        return "commit %H%d%n%PARENTS%Author: %an <%ae>%nCommit: %cn <%ce>%nDate:   %ad%n%n    %s%n%n%b"
    return fmt


def git_pretty(fmt):
    return pretty_format(fmt).replace("%PARENTS%", "")


def commit_rows(root, args):
    fmt = args.fmt or "oneline"
    custom = pretty_format(fmt)
    field_sep = "\x1f"
    rec_sep = "\x1e"
    base_format = custom
    need_parents_line = "%PARENTS%" in custom
    base_format = base_format.replace("%PARENTS%", "")
    cmd = ["git", "-C", str(root), "log", "--topo-order", "--date=default", f"--format={base_format}%x1f%H%x1f%P%x1e"]
    if args.max_count is not None:
        cmd.extend(["-n", str(args.max_count)])
    if args.reverse:
        cmd.append("--reverse")
    if args.local:
        cmd.append("--branches")
        cmd.append("--tags")
    else:
        cmd.append("--all")
    out = run(cmd, check=False)
    if out.returncode:
        return []
    rows = []
    for rec in out.stdout.split(rec_sep):
        rec = rec.strip("\n")
        if not rec:
            continue
        chunks = rec.rsplit(field_sep, 2)
        if len(chunks) != 3:
            continue
        text, h, parents = chunks[0].lstrip("\n"), chunks[1].strip(), chunks[2].strip()
        if need_parents_line and len(parents.split()) > 1:
            short = " ".join(p[:7] for p in parents.split())
            text = text.replace("Author:", f"Merge: {short}\nAuthor:", 1)
        rows.append((h, parents.split(), text.rstrip("\n")))
    return rows


def text_graph(rows, style, color):
    ch = style_chars(style)
    lines = []
    active_second = False
    use_color = color == "always"
    for idx, (h, parents, text) in enumerate(rows):
        is_merge = len(parents) > 1
        if is_merge and not active_second:
            prefix = f" {ch['merge']}{ch['left']}{ch['corner']}  "
            active_second = True
        elif active_second and idx + 1 < len(rows) and rows[idx + 1][0] in parents:
            prefix = f" {ch['tee']}─┘  " if style != "ascii" else " |-'  "
            active_second = False
        elif active_second:
            prefix = f" {ch['vert']} {ch['commit']}  " if len(parents) <= 1 else f" {ch['vert']} {ch['merge']}  "
        else:
            prefix = f" {ch['commit']}  "
        tlines = text.splitlines() or [""]
        first = tlines[0]
        if use_color:
            first = colorize_summary(first)
            cprefix = re.sub(r"([●○*o])", r"\033[38;5;12m\1\033[0m", prefix, count=1)
        else:
            cprefix = prefix
        lines.append(cprefix + first)
        cont = (" " + (ch["vert"] if active_second else " ") + "  ")
        cont = cont.ljust(len(prefix))
        for extra in tlines[1:]:
            lines.append(cont + extra)
    return "\n".join(lines) + ("\n" if lines else "")


def colorize_summary(s):
    s = re.sub(r"^([0-9a-f]{7,40})", r"\033[38;5;11m\1\033[0m", s)
    s = re.sub(r"\((HEAD -> )?([^)]*)\)", lambda m: "(" + (("\033[38;5;14mHEAD ->\033[0m ") if m.group(1) else "") + "\033[38;5;12m" + m.group(2) + "\033[0m)", s, count=1)
    return s


def svg_graph(rows):
    h = max(45, len(rows) * 30 + 15)
    parts = [f'<svg height="{h}" viewBox="0 0 30 {h}" width="30" xmlns="http://www.w3.org/2000/svg">']
    for i, (sha, parents, _) in enumerate(rows):
        y = 15 + i * 30
        if i + 1 < len(rows):
            parts.append(f'<line stroke="blue" stroke-width="1" x1="15" x2="15" y1="{y}" y2="{y+30}"/>')
        fill = "white" if len(parents) > 1 else "blue"
        parts.append(f'<circle cx="15" cy="{y}" fill="{fill}" r="4" stroke="blue" stroke-width="1"/>')
    parts.append("</svg>")
    return "\n".join(parts) + "\n"


def parse_main(argv):
    if not argv:
        argv = []
    if argv[0:1] == ["help"]:
        print(LONG_HELP, end="")
        return 0
    if "model" in argv:
        idx = argv.index("model")
        path = "."
        before = argv[:idx]
        i = 0
        while i < len(before):
            if before[i] in ("-p", "--path") and i + 1 < len(before):
                path = before[i + 1]
                i += 2
            else:
                i += 1
        return handle_model(argv[idx + 1:], path)
    if any(a == "--help" for a in argv):
        print(LONG_HELP, end="")
        return 0
    if any(a == "-h" for a in argv):
        print(SHORT_HELP, end="")
        return 0
    if any(a in ("-V", "--version") for a in argv):
        print(VERSION)
        return 0

    p = argparse.ArgumentParser(add_help=False, prog="executable")
    p.add_argument("-p", "--path", default=".")
    p.add_argument("--skip-repo-owner-validation", action="store_true")
    p.add_argument("-m", "--model", default=None)
    p.add_argument("-n", "--max-count", type=int, default=None)
    p.add_argument("--color", choices=["auto", "always", "never"], default="auto")
    p.add_argument("--no-color", action="store_true")
    p.add_argument("-w", "--wrap", nargs="*")
    p.add_argument("-f", "--format", dest="fmt", default="oneline")
    p.add_argument("-r", "--reverse", action="store_true")
    p.add_argument("-l", "--local", action="store_true")
    p.add_argument("--svg", action="store_true")
    p.add_argument("-d", "--debug", action="store_true")
    p.add_argument("-S", "--sparse", action="store_true")
    p.add_argument("-s", "--style", default="normal")
    p.add_argument("--all", action="store_true")
    ns, extra = p.parse_known_args(argv)
    if extra:
        error(f"error: unexpected argument '{extra[0]}' found\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.", 2)
    if ns.model:
        validate_model(ns.model)
    if ns.no_color:
        ns.color = "never"
    root = repo_root(ns.path)
    rows = commit_rows(root, ns)
    if ns.svg:
        sys.stdout.write(svg_graph(rows))
    else:
        sys.stdout.write(text_graph(rows, ns.style, ns.color))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(parse_main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
