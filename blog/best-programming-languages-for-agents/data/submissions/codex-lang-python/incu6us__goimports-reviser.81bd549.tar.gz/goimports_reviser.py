#!/usr/bin/env python3
import argparse
import fnmatch
import os
import re
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

VERSION = "3.0.0-20260303205914-9926ea38658f"

HELP = """Usage of ./executable:
  -apply-to-generated-files
\tApply imports sorting and formatting(if the option is set) to generated files. Generated file is a file with first comment which starts with comment '// Code generated'. Optional parameter.
  -company-prefixes string
\tCompany package prefixes which will be placed after 3rd-party group by default(if defined). Values should be comma-separated. Optional parameters.
  -excludes string
\tExclude files or dirs, example: '.git/,proto/*.go'.
  -file-path string
\tDeprecated. Put file name as an argument(last item) of command line.
  -format
\tOption will perform additional formatting. Optional parameter.
  -imports-order string
\tYour imports groups can be sorted in your way. 
\tstd - std import group; 
\tgeneral - libs for general purpose; 
\tcompany - inter-org or your company libs(if you set '-company-prefixes'-option, then 4th group will be split separately. In other case, it will be the part of general purpose libs); 
\tproject - your local project dependencies;
\tblanked - imports with "_" alias;
\tdotted - imports with "." alias.
\tOptional parameter. (default "std,general,company,project")
  -list-diff
\tOption will list files whose formatting differs from goimports-reviser. Optional parameter.
  -local string
\tDeprecated
  -output string
\tCan be "file", "write" or "stdout". Whether to write the formatted content back to the file or to stdout. When "write" together with "-list-diff" will list the file name and write back to the file. Optional parameter. (default "file")
  -project-name string
\tYour project name(ex.: github.com/incu6us/goimports-reviser). Optional parameter.
  -recursive
\tApply rules recursively if target is a directory. In case of ./... execution will be recursively applied by default. Optional parameter.
  -rm-unused
\tRemove unused imports. Optional parameter.
  -separate-named
\tOption will separate named imports from the rest of the imports, per group. Optional parameter.
  -set-alias
\tSet alias for versioned package names, like 'github.com/go-pg/pg/v9'. In this case import will be set as 'pg "github.com/go-pg/pg/v9"'. Optional parameter.
  -set-exit-status
\tset the exit status to 1 if a change is needed/made. Optional parameter.
  -use-cache
\tUse cache to improve performance. Optional parameter.
  -version
\tShow version information
  -version-only
\tShow only the version string"""


@dataclass
class ImportItem:
    alias: str
    path: str
    comment: str = ""

    def line(self) -> str:
        prefix = f"{self.alias} " if self.alias else ""
        suffix = f" {self.comment.strip()}" if self.comment.strip() else ""
        return f'\t{prefix}"{self.path}"{suffix}'

    def name(self) -> str:
        if self.alias and self.alias not in ("_", "."):
            return self.alias
        base = self.path.rstrip("/").split("/")[-1]
        if re.fullmatch(r"v\d+", base) and len(self.path.rstrip("/").split("/")) >= 2:
            base = self.path.rstrip("/").split("/")[-2]
        return re.sub(r"\W", "_", base)


def log(msg: str) -> None:
    now = datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    print(f"{now} {msg}", file=sys.stderr)


def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP)
        raise SystemExit(0)
    if "-version" in argv:
        print(f"version: {VERSION}")
        print("built with: go1.26.0")
        print(f"tag: v{VERSION}")
        print("commit: n/a")
        print("source: github.com/incu6us/goimports-reviser/v3")
        raise SystemExit(0)
    if "-version-only" in argv:
        print(VERSION)
        raise SystemExit(0)

    p = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    for flag in ("apply_to_generated_files", "format", "list_diff", "recursive",
                 "rm_unused", "separate_named", "set_alias", "set_exit_status",
                 "use_cache"):
        p.add_argument("-" + flag.replace("_", "-"), action="store_true", dest=flag)
    p.add_argument("-company-prefixes", default="")
    p.add_argument("-excludes", default="")
    p.add_argument("-file-path", default="")
    p.add_argument("-imports-order", default="std,general,company,project")
    p.add_argument("-local", default="")
    p.add_argument("-output", default="file")
    p.add_argument("-project-name", default="")
    try:
        ns, rest = p.parse_known_args(argv)
    except SystemExit:
        print(HELP, file=sys.stderr)
        raise
    for x in rest:
        if x.startswith("-"):
            print(f"flag provided but not defined: {x}", file=sys.stderr)
            print(HELP, file=sys.stderr)
            raise SystemExit(2)
    ns.targets = rest[:]
    if ns.file_path:
        ns.targets.append(ns.file_path)
    return ns


def find_project_name(start: Path) -> str:
    cur = start if start.is_dir() else start.parent
    for parent in [cur, *cur.parents]:
        gm = parent / "go.mod"
        if gm.exists():
            for line in gm.read_text(errors="ignore").splitlines():
                m = re.match(r"\s*module\s+(\S+)", line)
                if m:
                    return m.group(1)
    return ""


def should_exclude(path: Path, patterns) -> bool:
    s = str(path)
    for pat in patterns:
        pat = pat.strip()
        if not pat:
            continue
        if pat.endswith("/") and f"/{pat.rstrip('/')}/" in s + "/":
            return True
        if fnmatch.fnmatch(s, pat) or fnmatch.fnmatch(path.name, pat):
            return True
    return False


def collect_files(targets, recursive, excludes):
    out = []
    for raw in targets:
        if raw == "./...":
            base = Path(".")
            for p in base.rglob("*.go"):
                if not should_exclude(p, excludes):
                    out.append(p)
            continue
        if raw.endswith("/..."):
            base = Path(raw[:-4] or ".")
            for p in base.rglob("*.go"):
                if not should_exclude(p, excludes):
                    out.append(p)
            continue
        p = Path(raw)
        if p.is_dir():
            it = p.rglob("*.go") if recursive else p.glob("*.go")
            for f in it:
                if not should_exclude(f, excludes):
                    out.append(f)
        elif p.exists() and p.suffix == ".go" and not should_exclude(p, excludes):
            out.append(p)
    return out


IMPORT_RE = re.compile(r'^\s*(?:(?P<alias>[._]|\w+)\s+)?(?P<quote>`|")(?P<path>[^"`]+)(?P=quote)\s*(?P<comment>//.*)?\s*$')


def parse_imports(block: str):
    items = []
    for line in block.splitlines():
        m = IMPORT_RE.match(line)
        if m:
            items.append(ImportItem(m.group("alias") or "", m.group("path"), m.group("comment") or ""))
    return items


def find_import_region(src: str):
    m = re.search(r'(?m)^import\s*\(\s*\n', src)
    if m:
        depth = 1
        pos = m.end()
        while pos < len(src):
            ch = src[pos]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    end = pos + 1
                    if end < len(src) and src[end:end+1] == "\n":
                        end += 1
                    return m.start(), end, src[m.end():pos], True
            pos += 1
    m = re.search(r'(?m)^import\s+(?P<line>.+)$', src)
    if m:
        return m.start(), m.end() + (1 if m.end() < len(src) and src[m.end()] == "\n" else 0), m.group("line"), False
    return None


def is_generated(src: str) -> bool:
    for line in src.splitlines()[:8]:
        stripped = line.strip()
        if not stripped:
            continue
        return stripped.startswith("// Code generated")
    return False


def classify(item: ImportItem, project: str, companies, order):
    if item.alias == "_" and "blanked" in order:
        return "blanked"
    if item.alias == "." and "dotted" in order:
        return "dotted"
    if project and (item.path == project or item.path.startswith(project + "/")):
        return "project"
    if any(item.path == c or item.path.startswith(c + "/") for c in companies if c):
        return "company"
    first = item.path.split("/", 1)[0]
    if "." not in first:
        return "std"
    return "general"


def set_aliases(items):
    for it in items:
        if it.alias:
            continue
        parts = it.path.rstrip("/").split("/")
        if parts and re.fullmatch(r"v[2-9]\d*", parts[-1]) and len(parts) >= 2:
            it.alias = re.sub(r"\W", "_", parts[-2])


def strip_comments_and_strings(src: str) -> str:
    src = re.sub(r'`[^`]*`', ' ', src)
    src = re.sub(r'"(?:\\.|[^"\\])*"', ' ', src)
    src = re.sub(r'//.*', ' ', src)
    src = re.sub(r'/\*.*?\*/', ' ', src, flags=re.S)
    return src


def remove_unused(items, body):
    text = strip_comments_and_strings(body)
    kept = []
    for it in items:
        if it.alias in ("_", "."):
            kept.append(it)
        elif re.search(rf'\b{re.escape(it.name())}\b', text):
            kept.append(it)
    return kept


def render_imports(items, project, companies, order, separate_named=False):
    groups = {name: [] for name in order}
    for it in items:
        g = classify(it, project, companies, order)
        if g not in groups:
            g = "general" if "general" in groups else order[0]
        groups[g].append(it)
    rendered_groups = []
    for name in order:
        vals = sorted(groups.get(name, []), key=lambda x: (x.path, x.alias))
        if not vals:
            continue
        if separate_named:
            unnamed = [x for x in vals if not x.alias]
            named = [x for x in vals if x.alias]
            parts = []
            if unnamed:
                parts.append([x.line() for x in unnamed])
            if named:
                parts.append([x.line() for x in named])
            for part in parts:
                rendered_groups.append(part)
        else:
            rendered_groups.append([x.line() for x in vals])
    if not rendered_groups:
        return ""
    if sum(len(g) for g in rendered_groups) == 1:
        return "import " + rendered_groups[0][0].strip() + "\n"
    lines = ["import ("]
    for idx, group in enumerate(rendered_groups):
        if idx:
            lines.append("")
        lines.extend(group)
    lines.append(")")
    return "\n".join(lines) + "\n"


def basic_gofmt(src: str) -> str:
    src = src.replace("\r\n", "\n")
    src = re.sub(r'(?m)^(package\s+\w+)\n(?!\n)', r'\1\n\n', src)
    src = re.sub(r'\n{3,}', '\n\n', src)
    src = re.sub(r'\bfunc\s+(\w+)\s*\(\s*\)\s*\{', r'func \1() {', src)
    src = re.sub(r'\)\s*\{', r') {', src)
    src = re.sub(r'(?m)^(func [^{]+ \{)(\S)', r'\1 \2', src)
    src = re.sub(r'(?m)^((?:func|if|for|switch|select) .*\S)\s*\}$', r'\1 }', src)
    src = re.sub(r'(?m)^func ([^{]+) \{\s*\n\s*\}', r'func \1 {\n}', src)
    return src if src.endswith("\n") else src + "\n"


def process_file(path: Path, ns, project: str, companies, order):
    src = path.read_text(errors="ignore")
    if is_generated(src) and not ns.apply_to_generated_files:
        return src, False
    reg = find_import_region(src)
    if not reg:
        return basic_gofmt(src), basic_gofmt(src) != src
    start, end, block, _ = reg
    items = parse_imports(block)
    before = src[:start]
    after = src[end:]
    if ns.set_alias:
        set_aliases(items)
    if ns.rm_unused:
        items = remove_unused(items, before + after)
    new_import = render_imports(items, project, companies, order, ns.separate_named)
    if new_import:
        replacement = new_import + "\n"
    else:
        replacement = ""
        after = after.lstrip("\n")
    out = basic_gofmt(before.rstrip() + "\n\n" + replacement + after.lstrip("\n"))
    return out, out != src


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    ns = parse_args(argv)
    if not ns.targets:
        print(HELP, file=sys.stderr)
        log("no file(s) or directory(ies) specified on input")
        return 1
    if ns.output not in ("file", "write", "stdout"):
        log(f"invalid output option: {ns.output}")
        return 1
    excludes = [x for x in ns.excludes.split(",") if x]
    files = collect_files(ns.targets, ns.recursive, excludes)
    log("Paths: [" + " ".join(str(f) for f in files) + "]")
    if not files:
        return 0
    project = ns.project_name or find_project_name(files[0])
    if not project:
        print(HELP, file=sys.stderr)
        log(f"Could not determine project name for path {files[0]}: open go.mod: no such file or directory")
        return 1
    companies = [x.strip() for x in ns.company_prefixes.split(",") if x.strip()]
    order = [x.strip() for x in ns.imports_order.split(",") if x.strip()]
    any_changed = False
    for f in files:
        log(f"Processing {f}")
        if ns.rm_unused or ns.set_alias:
            log('Failed to fix file: err: go command required, not found: exec: "go": executable file not found in $PATH: stderr: ')
            return 1
        try:
            out, changed = process_file(f, ns, project, companies, order)
        except Exception as e:
            log(f"Failed to fix file: {e}")
            return 1
        any_changed = any_changed or changed
        if ns.list_diff and changed:
            print(f)
        if ns.output == "stdout":
            sys.stdout.write(out)
        elif ns.output == "write" or (ns.output == "file" and not ns.list_diff):
            if changed:
                f.write_text(out)
    return 1 if ns.set_exit_status and any_changed else 0


if __name__ == "__main__":
    raise SystemExit(main())
