#!/usr/bin/env python3
import binascii
import os
import shlex
import stat
import struct
import sys
import time
import zlib
import zipfile
import io

VERSION = "pigz 2.8"
LICENSE = """pigz 2.8
Copyright (C) 2007-2023 Mark Adler
Subject to the terms of the zlib license.
No warranty is provided or implied.
"""

HELP = """Usage: pigz [options] [files ...]
  will compress files in place, adding the suffix '.gz'. If no files are
  specified, stdin will be compressed to stdout. pigz does what gzip does,
  but spreads the work over multiple processors and cores when compressing.

Options:
  -0 to -9, -11        Compression level (level 11, zopfli, is much slower)
  --fast, --best       Compression levels 1 and 9 respectively
  -A, --alias xxx      Use xxx as the name for any --zip entry from stdin
  -b, --blocksize mmm  Set compression block size to mmmK (default 128K)
  -c, --stdout         Write all processed output to stdout (won't delete)
  -C, --comment ccc    Put comment ccc in the gzip or zip header
  -d, --decompress     Decompress the compressed input
  -f, --force          Force overwrite, compress .gz, links, and to terminal
  -F  --first          Do iterations first, before block split for -11
  -h, --help           Display a help screen and quit
  -H, --huffman        Use only Huffman coding for compression
  -i, --independent    Compress blocks independently for damage recovery
  -I, --iterations n   Number of iterations for -11 optimization
  -J, --maxsplits n    Maximum number of split blocks for -11
  -k, --keep           Do not delete original file after processing
  -K, --zip            Compress to PKWare zip (.zip) single entry format
  -l, --list           List the contents of the compressed input
  -L, --license        Display the pigz license and quit
  -m, --no-time        Do not store or restore mod time
  -M, --time           Store or restore mod time
  -n, --no-name        Do not store or restore file name or mod time
  -N, --name           Store or restore file name and mod time
  -O  --oneblock       Do not split into smaller blocks for -11
  -p, --processes n    Allow up to n compression threads (default is the
                       number of online processors, or 8 if unknown)
  -q, --quiet          Print no messages, even on error
  -r, --recursive      Process the contents of all subdirectories
  -R, --rsyncable      Input-determined block locations for rsync
  -S, --suffix .sss    Use suffix .sss instead of .gz (for compression)
  -t, --test           Test the integrity of the compressed input
  -U, --rle            Use run-length encoding for compression
  -v, --verbose        Provide more verbose output
  -V  --version        Show the version of pigz
  -Y  --synchronous    Force output file write to permanent storage
  -z, --zlib           Compress to zlib (.zz) instead of gzip format
  --                   All arguments after "--" are treated as files
"""


class Opt:
    def __init__(self):
        self.decompress = False
        self.stdout = False
        self.force = False
        self.keep = False
        self.recursive = False
        self.test = False
        self.listing = False
        self.verbose = 0
        self.quiet = False
        self.zlibfmt = False
        self.zipfmt = False
        self.level = 6
        self.strategy = zlib.Z_DEFAULT_STRATEGY
        self.suffix = ".gz"
        self.name = True
        self.mtime = True
        self.name_explicit = False
        self.mtime_explicit = False
        self.comment = None
        self.alias = "-"
        self.sync = False


def err(opt, msg):
    if not opt.quiet:
        sys.stderr.write("executable: " + msg + "\n")


def split_args(args):
    out = []
    for var in ("GZIP", "PIGZ"):
        val = os.environ.get(var)
        if val:
            try:
                out.extend(shlex.split(val))
            except ValueError:
                out.extend(val.split())
    out.extend(args)
    return out


def parse(argv):
    opt = Opt()
    files = []
    args = split_args(argv[1:])
    i = 0
    after = False
    while i < len(args):
        a = args[i]
        if after:
            files.append(a)
            i += 1
            continue
        if a == "--":
            after = True
            i += 1
            continue
        if not a.startswith("-") or a == "-":
            files.append(a)
            i += 1
            continue
        def need():
            nonlocal i
            i += 1
            if i >= len(args):
                raise SystemExit(1)
            return args[i]
        if a.startswith("--"):
            name = a[2:]
            if name in ("help",):
                print(HELP, end="")
                raise SystemExit(0)
            if name == "version":
                print(VERSION)
                raise SystemExit(0)
            if name == "license":
                print(LICENSE, end="")
                raise SystemExit(0)
            if name in ("fast",):
                opt.level = 1
            elif name in ("best",):
                opt.level = 9
            elif name in ("stdout", "to-stdout"):
                opt.stdout = True
            elif name in ("decompress", "uncompress"):
                opt.decompress = True
            elif name == "force":
                opt.force = True
            elif name == "keep":
                opt.keep = True
            elif name == "recursive":
                opt.recursive = True
            elif name == "test":
                opt.test = True
                opt.decompress = True
            elif name == "list":
                opt.listing = True
                opt.decompress = True
            elif name in ("quiet", "silent"):
                opt.quiet = True
            elif name == "verbose":
                opt.verbose += 1
            elif name == "zlib":
                opt.zlibfmt = True
            elif name == "zip":
                opt.zipfmt = True
            elif name == "no-name":
                opt.name = False
                opt.mtime = False
                opt.name_explicit = True
                opt.mtime_explicit = True
            elif name == "name":
                opt.name = True
                opt.mtime = True
                opt.name_explicit = True
                opt.mtime_explicit = True
            elif name == "no-time":
                opt.mtime = False
                opt.mtime_explicit = True
            elif name == "time":
                opt.mtime = True
                opt.mtime_explicit = True
            elif name == "huffman":
                opt.strategy = zlib.Z_HUFFMAN_ONLY
            elif name == "rle":
                opt.strategy = zlib.Z_RLE
            elif name in ("rsyncable", "independent", "first", "oneblock"):
                pass
            elif name in ("blocksize", "processes", "iterations", "maxsplits"):
                need()
            elif name == "suffix":
                opt.suffix = need()
            elif name == "comment":
                opt.comment = need()
            elif name == "alias":
                opt.alias = need()
            else:
                sys.stderr.write("executable: abort: invalid option: --" + name + "\n")
                raise SystemExit(22)
            i += 1
            continue
        j = 1
        while j < len(a):
            ch = a[j]
            if ch.isdigit():
                if ch == "1" and j + 1 < len(a) and a[j + 1] == "1":
                    opt.level = 9
                    j += 2
                    continue
                opt.level = int(ch)
            elif ch == "c":
                opt.stdout = True
            elif ch == "d":
                opt.decompress = True
            elif ch == "f":
                opt.force = True
            elif ch == "h":
                print(HELP, end="")
                raise SystemExit(0)
            elif ch == "H":
                opt.strategy = zlib.Z_HUFFMAN_ONLY
            elif ch == "i" or ch == "R" or ch in "FOY":
                pass
            elif ch == "k":
                opt.keep = True
            elif ch == "K":
                opt.zipfmt = True
            elif ch == "l":
                opt.listing = True
                opt.decompress = True
            elif ch == "L":
                print(LICENSE, end="")
                raise SystemExit(0)
            elif ch == "m":
                opt.mtime = False
                opt.mtime_explicit = True
            elif ch == "M":
                opt.mtime = True
                opt.mtime_explicit = True
            elif ch == "n":
                opt.name = False
                opt.mtime = False
                opt.name_explicit = True
                opt.mtime_explicit = True
            elif ch == "N":
                opt.name = True
                opt.mtime = True
                opt.name_explicit = True
                opt.mtime_explicit = True
            elif ch == "q":
                opt.quiet = True
            elif ch == "r":
                opt.recursive = True
            elif ch == "t":
                opt.test = True
                opt.decompress = True
            elif ch == "U":
                opt.strategy = zlib.Z_RLE
            elif ch == "v":
                opt.verbose += 1
            elif ch == "V":
                print(VERSION if opt.verbose == 0 else VERSION + "\nzlib " + zlib.ZLIB_VERSION)
                raise SystemExit(0)
            elif ch == "z":
                opt.zlibfmt = True
            elif ch in "AbCpSIJ":
                val = a[j + 1:] if j + 1 < len(a) else need()
                if ch == "A":
                    opt.alias = val
                elif ch == "C":
                    opt.comment = val
                elif ch == "S":
                    opt.suffix = val
                j = len(a)
                continue
            else:
                sys.stderr.write("executable: abort: invalid option: -" + ch + "\n")
                raise SystemExit(22)
            j += 1
        i += 1
    if "unpigz" in os.path.basename(argv[0]):
        opt.decompress = True
    if opt.decompress:
        if not opt.name_explicit:
            opt.name = False
        if not opt.mtime_explicit:
            opt.mtime = False
    return opt, files


def xfl(level):
    if level == 9:
        return 2
    if level == 1:
        return 4
    return 0


def deflate_raw(data, opt):
    comp = zlib.compressobj(opt.level, zlib.DEFLATED, -15, zlib.DEF_MEM_LEVEL, opt.strategy)
    return comp.compress(data) + comp.flush()


def gzip_compress(data, opt, filename=None, mtime=0):
    flags = 0
    parts = [b"\x1f\x8b\x08"]
    name = os.path.basename(filename) if filename and opt.name else None
    if name:
        flags |= 8
    if opt.comment is not None:
        flags |= 16
    mt = int(mtime) if opt.mtime and mtime else 0
    parts.append(bytes([flags]))
    parts.append(struct.pack("<LBB", mt & 0xffffffff, xfl(opt.level), 3))
    if name:
        parts.append(name.encode("latin-1", "replace") + b"\0")
    if opt.comment is not None:
        parts.append(opt.comment.encode("latin-1", "replace") + b"\0")
    parts.append(deflate_raw(data, opt))
    parts.append(struct.pack("<LL", binascii.crc32(data) & 0xffffffff, len(data) & 0xffffffff))
    return b"".join(parts)


def zlib_compress(data, opt):
    comp = zlib.compressobj(opt.level, zlib.DEFLATED, zlib.MAX_WBITS, zlib.DEF_MEM_LEVEL, opt.strategy)
    return comp.compress(data) + comp.flush()


def zip_compress(data, opt, arcname, mtime=0):
    bio = io.BytesIO()
    dt = time.localtime(mtime if opt.mtime and mtime else time.time())[:6]
    zi = zipfile.ZipInfo(arcname or "-", dt)
    zi.compress_type = zipfile.ZIP_DEFLATED
    zi.comment = (opt.comment or "").encode("latin-1", "replace")
    with zipfile.ZipFile(bio, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=max(0, min(opt.level, 9))) as zf:
        zf.writestr(zi, data)
    return bio.getvalue()


def read_gzip_name(path):
    try:
        with open(path, "rb") as f:
            h = f.read(10)
            if len(h) < 10 or h[:3] != b"\x1f\x8b\x08":
                return None, None
            flg = h[3]
            mt = struct.unpack("<L", h[4:8])[0]
            if flg & 4:
                n = struct.unpack("<H", f.read(2))[0]
                f.read(n)
            name = None
            if flg & 8:
                bs = bytearray()
                while True:
                    c = f.read(1)
                    if not c or c == b"\0":
                        break
                    bs.extend(c)
                name = bs.decode("latin-1", "replace")
            return name, mt
    except OSError:
        pass
    return None, None


def decompress_data(data):
    if data.startswith(b"PK\x03\x04"):
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()
            if not names:
                return b"", "zip", None
            return zf.read(names[0]), "zip", names[0]
    if data.startswith(b"\x1f\x8b"):
        import gzip
        return gzip.decompress(data), "gzip", None
    return zlib.decompress(data), "zlib", None


def list_one(path, opt, totals):
    data = open(path, "rb").read() if path != "-" else sys.stdin.buffer.read()
    out, kind, zname = decompress_data(data)
    crc = binascii.crc32(out) & 0xffffffff
    comp = max(0, len(data) - 24) if kind == "gzip" else len(data)
    orig = len(out)
    red = 0.0 if orig == 0 else 100.0 * (orig - comp) / orig
    if kind == "gzip":
        name, mt = read_gzip_name(path) if path != "-" else (None, None)
        shown = name or strip_suffix(path)
        tstr = time.strftime("%b %d %H:%M", time.localtime(mt)) if mt else "------ -----"
        method = "gzip 8"
    elif kind == "zip":
        shown = zname or path
        tstr = "------ -----"
        method = "zip  8"
    else:
        shown = strip_suffix(path)
        tstr = "------ -----"
        method = "zlib 8"
    if opt.verbose:
        print(f"{method}  {crc:08x}  {tstr:12s} {comp:11d} {orig:10d} {red:6.1f}%  {shown}")
    else:
        print(f"{comp:9d} {orig:10d} {red:5.1f}% {shown}")
    totals[0] += comp
    totals[1] += orig


def strip_suffix(path):
    for suf in (".gz", ".zz", ".zip", ".z", "-gz", "-z", "_z"):
        if path.endswith(suf):
            return path[:-len(suf)] or path
    return path


def out_name_for_decompress(path, opt):
    name, mt = read_gzip_name(path)
    if opt.name and name:
        return name
    base = strip_suffix(path)
    return base


def collect(files, opt):
    if not files:
        return ["-"]
    out = []
    for p in files:
        if p == "-":
            out.append(p)
        elif os.path.isdir(p):
            if not opt.recursive:
                err(opt, f"skipping: {p} is a directory")
            else:
                for root, dirs, names in os.walk(p):
                    for n in sorted(names):
                        out.append(os.path.join(root, n))
        else:
            out.append(p)
    return out


def check_input_file(path, opt, compressing):
    if path == "-":
        return True
    if not os.path.exists(path):
        err(opt, f"skipping: {path} does not exist")
        return False
    if os.path.isdir(path):
        err(opt, f"skipping: {path} is a directory")
        return False
    if compressing and not opt.force:
        if path.endswith(opt.suffix) or path.endswith(".gz"):
            err(opt, f"skipping: {path} ends with {opt.suffix}")
            return False
    if not compressing and not opt.stdout and not (path.endswith(".gz") or path.endswith(".zz") or path.endswith(".zip") or path.endswith(".z")):
        err(opt, f"skipping: {path} does not have compressed suffix")
        return False
    return True


def write_output(path, data, opt):
    if opt.stdout or path == "-":
        sys.stdout.buffer.write(data)
        return True
    if os.path.exists(path) and not opt.force:
        err(opt, f"skipping: {path} exists")
        return False
    with open(path, "wb") as f:
        f.write(data)
        if opt.sync:
            f.flush()
            os.fsync(f.fileno())
    return True


def process_compress(path, opt):
    if not check_input_file(path, opt, True):
        return False
    data = sys.stdin.buffer.read() if path == "-" else open(path, "rb").read()
    st = None if path == "-" else os.stat(path)
    mtime = st.st_mtime if st else 0
    fname = None if path == "-" else path
    if opt.zipfmt:
        arc = opt.alias if path == "-" else os.path.basename(path)
        blob = zip_compress(data, opt, arc, mtime)
        suffix = ".zip"
    elif opt.zlibfmt:
        blob = zlib_compress(data, opt)
        suffix = ".zz"
    else:
        blob = gzip_compress(data, opt, fname, mtime)
        suffix = opt.suffix
    out = "-" if (opt.stdout or path == "-") else path + suffix
    if write_output(out, blob, opt):
        if path != "-" and not opt.keep and not opt.stdout:
            os.unlink(path)
        return True
    return False


def process_decompress(path, opt):
    if not check_input_file(path, opt, False):
        return False
    try:
        data = sys.stdin.buffer.read() if path == "-" else open(path, "rb").read()
        out, kind, zname = decompress_data(data)
    except Exception as e:
        err(opt, f"corrupt input: {path}")
        return False
    if opt.test:
        return True
    if opt.stdout or path == "-":
        sys.stdout.buffer.write(out)
        return True
    target = out_name_for_decompress(path, opt) if kind == "gzip" else (zname or strip_suffix(path))
    if write_output(target, out, opt):
        if not opt.keep:
            os.unlink(path)
        try:
            os.utime(target, (os.stat(path).st_atime, os.stat(path).st_mtime))
        except OSError:
            pass
        return True
    return False


def main(argv):
    try:
        opt, files = parse(argv)
    except BrokenPipeError:
        return 1
    files = collect(files, opt)
    ok = True
    if opt.listing:
        totals = [0, 0]
        if opt.verbose:
            print("method    check    timestamp    compressed   original reduced  name")
        else:
            print("compressed   original reduced  name")
        for p in files:
            if check_input_file(p, opt, False):
                try:
                    list_one(p, opt, totals)
                except Exception:
                    err(opt, f"corrupt input: {p}")
                    ok = False
            else:
                ok = False
        return 0 if ok else 1
    for p in files:
        if opt.decompress:
            ok = process_decompress(p, opt) and ok
        else:
            ok = process_compress(p, opt) and ok
    return 0 if ok else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv))
    except BrokenPipeError:
        raise SystemExit(1)
