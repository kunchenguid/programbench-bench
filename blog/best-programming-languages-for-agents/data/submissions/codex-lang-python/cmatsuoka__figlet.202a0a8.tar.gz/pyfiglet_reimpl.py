#!/usr/bin/env python3
import os
import shutil
import sys


VERSION_TEXT = """FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,
Christiaan Keet and Claudio Matsuoka
Internet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012

FIGlet, along with the various FIGlet fonts and documentation, may be
freely copied and distributed.

If you use FIGlet, please send an e-mail message to <info@figlet.org>.

The latest version of FIGlet is available from the web site,
\thttp://www.figlet.org/
"""

USAGE = """Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]
              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]
              [ -C controlfile ] [ -I infocode ] [ message ]"""


class FigletError(Exception):
    pass


class Font:
    def __init__(self, path):
        self.path = path
        self.name = os.path.splitext(os.path.basename(path))[0]
        self.glyphs = {}
        self.load()

    def load(self):
        with open(self.path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()
        if not lines:
            raise FigletError("empty font")
        header = lines[0].split()
        if not header or not header[0].startswith(("flf2", "tlf2")):
            raise FigletError("bad font")
        sig = header[0]
        self.hardblank = sig[-1]
        self.height = int(header[1])
        self.old_layout = int(header[4]) if len(header) > 4 else 0
        comment_lines = int(header[5]) if len(header) > 5 else 0
        self.print_direction = int(header[6]) if len(header) > 6 else 0
        self.full_layout = int(header[7]) if len(header) > 7 else self.old_layout
        pos = 1 + comment_lines
        for code in range(32, 127):
            if pos + self.height > len(lines):
                break
            self.glyphs[code] = [self._clean(lines[pos + i]) for i in range(self.height)]
            pos += self.height
        while pos < len(lines):
            tag = lines[pos].strip()
            pos += 1
            if not tag:
                continue
            try:
                code = int(tag, 0)
            except ValueError:
                continue
            if pos + self.height > len(lines):
                break
            self.glyphs[code] = [self._clean(lines[pos + i]) for i in range(self.height)]
            pos += self.height

    def _clean(self, line):
        endmark = line[-1:] or "@"
        while line.endswith(endmark):
            line = line[:-1]
        return line

    def glyph(self, ch):
        code = ord(ch)
        if code in self.glyphs:
            return self.glyphs[code]
        return self.glyphs.get(ord("?"), [""] * self.height)


def find_font(font_dir, font_name):
    candidates = []
    if os.path.isabs(font_name) or os.sep in font_name:
        candidates.append(font_name)
        if not os.path.splitext(font_name)[1]:
            candidates += [font_name + ".flf", font_name + ".tlf"]
    else:
        names = [font_name]
        if not os.path.splitext(font_name)[1]:
            names += [font_name + ".flf", font_name + ".tlf"]
        for n in names:
            candidates.append(os.path.join(font_dir, n))
            candidates.append(n)
    for p in candidates:
        if os.path.isfile(p):
            return p
    raise FileNotFoundError(font_name)


def smush_pair(left, right, hardblank, mode):
    if left == " ":
        return right
    if right == " ":
        return left
    if mode == "kern":
        return None
    if mode == "overlap":
        return right
    rules = mode if isinstance(mode, int) else 0
    if left == right and left != hardblank and (rules & 1):
        return left
    if (left == "_" and right in "|/\\[]{}()<>") or (right == "_" and left in "|/\\[]{}()<>"):
        if rules & 2:
            return right if left == "_" else left
    hierarchy = "|/\\[]{}()<>"
    if (rules & 4) and left in hierarchy and right in hierarchy:
        return hierarchy[max(hierarchy.index(left), hierarchy.index(right))]
    pairs = {"[": "]", "{": "}", "(": ")", "<": ">"}
    if rules & 8:
        if pairs.get(left) == right or pairs.get(right) == left:
            return "|"
    if (rules & 16) and left == hardblank and right == hardblank:
        return hardblank
    if rules & 32:
        return right
    return None


def can_overlap(out, glyph, overlap, font, mode):
    if overlap <= 0:
        return True
    for r in range(font.height):
        left = out[r]
        right = glyph[r]
        for i in range(overlap):
            li = len(left) - overlap + i
            if li < 0 or i >= len(right):
                continue
            lch = left[li]
            rch = right[i]
            if lch != " " and rch != " " and smush_pair(lch, rch, font.hardblank, mode) is None:
                return False
    return True


def merge(out, glyph, overlap, font, mode):
    res = []
    for r in range(font.height):
        left = out[r]
        right = glyph[r]
        if overlap <= 0:
            res.append(left + right)
            continue
        prefix = left[:-overlap] if overlap <= len(left) else ""
        merged = []
        for i in range(overlap):
            li = len(left) - overlap + i
            lch = left[li] if 0 <= li < len(left) else " "
            rch = right[i] if i < len(right) else " "
            merged.append(smush_pair(lch, rch, font.hardblank, mode) or rch)
        res.append(prefix + "".join(merged) + right[overlap:])
    return res


def append_glyph(out, glyph, font, mode):
    max_ov = min(max((len(x) for x in out), default=0), max((len(x) for x in glyph), default=0))
    kern = 0
    for ov in range(max_ov, -1, -1):
        if can_overlap(out, glyph, ov, font, "kern"):
            kern = ov
            break
    best = kern
    if mode != "kern":
        trial = min(max_ov, kern + 1)
        if trial > kern and can_overlap(out, glyph, trial, font, mode):
            best = trial
    return merge(out, glyph, best, font, mode)


def layout_mode(font, explicit):
    if explicit == "full":
        return "full"
    if explicit == "kern":
        return "kern"
    if explicit == "overlap":
        return "overlap"
    if isinstance(explicit, int):
        return explicit
    full = font.full_layout
    if full < 0:
        return "full"
    if full == 0:
        return "kern"
    return full & 63


def render_line(text, font, mode, rtl=False):
    out = [""] * font.height
    chars = list(text)
    if rtl:
        chars = chars[::-1]
    for ch in chars:
        glyph = font.glyph(ch)
        if mode == "full":
            out = [a + b for a, b in zip(out, glyph)]
        else:
            out = append_glyph(out, glyph, font, mode)
    return [line.replace(font.hardblank, " ") for line in out]


def visual_width(lines):
    return max((len(x.rstrip()) for x in lines), default=0)


def justify(lines, width, just):
    if just == "left":
        return lines
    w = visual_width(lines)
    if w >= width:
        return lines
    pad = width - w
    if just == "center":
        pad //= 2
    return [(" " * pad) + line for line in lines]


def render_text(text, font, mode, width=80, just="left", rtl=False):
    result = []
    raw_lines = text.split("\n")
    for raw in raw_lines:
        chunks = [raw]
        if width == 1 and raw:
            chunks = [ch for ch in raw if ch != " "] or [""]
        elif width > 1 and raw:
            chunks = wrap_text(raw, font, mode, width, rtl)
        for chunk in chunks:
            result.extend(justify(render_line(chunk, font, mode, rtl), width, just))
    return "\n".join(result) + "\n"


def wrap_text(raw, font, mode, width, rtl):
    words = raw.split(" ")
    lines = []
    cur = ""
    for word in words:
        cand = word if cur == "" else cur + " " + word
        if cur and visual_width(render_line(cand, font, mode, rtl)) > width:
            lines.append(cur)
            cur = word
        else:
            cur = cand
    lines.append(cur)
    return lines


def german_translate(s):
    table = str.maketrans({"[": "Ä", "\\": "Ö", "]": "Ü", "{": "ä", "|": "ö", "}": "ü", "~": "ß"})
    return s.translate(table)


def parse_args(argv):
    opts = {
        "font": "standard",
        "font_dir": os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts"),
        "width": 80,
        "just": "left",
        "mode": None,
        "rtl": None,
        "info": -1,
        "paragraph": False,
        "german": False,
    }
    msg = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--help":
            sys.stderr.write("./executable: invalid option -- '-'\n")
            sys.stderr.write(USAGE + "\n")
            raise SystemExit(1)
        if not arg.startswith("-") or arg == "-":
            msg = argv[i:]
            break
        j = 1
        while j < len(arg):
            c = arg[j]
            def need_value():
                nonlocal i, j
                if j + 1 < len(arg):
                    v = arg[j + 1:]
                    j = len(arg)
                    return v
                i += 1
                if i >= len(argv):
                    raise FigletError(f"option requires an argument -- '{c}'")
                return argv[i]
            if c == "f":
                opts["font"] = need_value()
            elif c == "d":
                opts["font_dir"] = need_value()
            elif c == "w":
                opts["width"] = int(need_value())
            elif c == "I":
                opts["info"] = int(need_value())
            elif c == "m":
                m = int(need_value())
                opts["mode"] = "kern" if m == 0 else "full" if m == -1 else None if m == -2 else m
            elif c == "c":
                opts["just"] = "center"
            elif c == "l":
                opts["just"] = "left"
            elif c == "r":
                opts["just"] = "right"
            elif c == "x":
                opts["just"] = "default"
            elif c == "k":
                opts["mode"] = "kern"
            elif c == "W":
                opts["mode"] = "full"
            elif c == "o":
                opts["mode"] = "overlap"
            elif c in "sS":
                opts["mode"] = None
            elif c == "n":
                opts["paragraph"] = False
            elif c == "p":
                opts["paragraph"] = True
            elif c == "t":
                opts["width"] = shutil.get_terminal_size((opts["width"], 24)).columns
            elif c == "L":
                opts["rtl"] = False
            elif c == "R":
                opts["rtl"] = True
            elif c == "X":
                opts["rtl"] = None
            elif c == "D":
                opts["german"] = True
            elif c == "E":
                opts["german"] = False
            elif c == "C":
                need_value()
            elif c == "N":
                pass
            elif c == "v":
                opts["info"] = 0
            else:
                sys.stderr.write(f"./executable: invalid option -- '{c}'\n")
                sys.stderr.write(USAGE + "\n")
                raise SystemExit(1)
            j += 1
        i += 1
    return opts, msg


def paragraph_filter(data):
    chars = list(data)
    out = []
    for idx, ch in enumerate(chars):
        if ch == "\n":
            prev = chars[idx - 1] if idx > 0 else "\n"
            nxt = chars[idx + 1] if idx + 1 < len(chars) else "\n"
            if prev != "\n" and nxt not in (" ", "\n"):
                out.append(" ")
            else:
                out.append(ch)
        else:
            out.append(ch)
    return "".join(out)


def message_text(args):
    lines = []
    current = []
    for arg in args:
        if arg == "":
            lines.append(" ".join(current))
            current = []
        else:
            current.append(arg)
    lines.append(" ".join(current))
    return "\n".join(lines) + "\n"


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    try:
        opts, msg = parse_args(argv)
        if opts["info"] == 0:
            print(VERSION_TEXT)
            print(USAGE)
            return 0
        if opts["info"] == 1:
            print("20205")
            return 0
        if opts["info"] == 2:
            print(opts["font_dir"] if opts["font_dir"] != os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts") else "/usr/local/share/figlet")
            return 0
        if opts["info"] == 3:
            print(os.path.splitext(os.path.basename(opts["font"]))[0])
            return 0
        if opts["info"] == 4:
            print(opts["width"])
            return 0
        if opts["info"] == 5:
            print("flf2 tlf2")
            return 0
        if opts["info"] > 5:
            return 0
        font = Font(find_font(opts["font_dir"], opts["font"]))
        rtl = opts["rtl"] if opts["rtl"] is not None else bool(font.print_direction)
        just = opts["just"]
        if just == "default":
            just = "right" if rtl else "left"
        text = message_text(msg) if msg else sys.stdin.read()
        if opts["paragraph"]:
            text = paragraph_filter(text)
        if opts["german"]:
            text = german_translate(text)
        mode = layout_mode(font, opts["mode"])
        sys.stdout.write(render_text(text.rstrip("\n"), font, mode, opts["width"], just, rtl))
        return 0
    except FileNotFoundError as e:
        sys.stderr.write(f"executable: {e.args[0]}: Unable to open font file\n")
        return 1
    except FigletError as e:
        sys.stderr.write(f"executable: {e}\n")
        return 1
    except ValueError:
        sys.stderr.write("executable: invalid number\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
