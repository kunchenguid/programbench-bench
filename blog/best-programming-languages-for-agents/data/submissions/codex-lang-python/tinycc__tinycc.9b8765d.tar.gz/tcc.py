#!/usr/bin/env python3
import os
import shlex
import subprocess
import sys
import tempfile
import time


VERSION = "0.9.28rc"
BUILD = "2026-04-21 build@237d0db*"


HELP = f"""Tiny C Compiler {VERSION} - Copyright (C) 2001-2006 Fabrice Bellard
Usage: tcc [options...] [-o outfile] [-c] infile(s)...
       tcc [options...] -run infile (or --) [arguments...]
General options:
  -c           compile only - generate an object file
  -o outfile   set output filename
  -run         run compiled source [with custom stdin: -rstdin FILE]
  -fflag       set or reset (with 'no-' prefix) 'flag' (see tcc -hh)
  -Wwarning    set or reset (with 'no-' prefix) 'warning' (see tcc -hh)
  -w           disable all warnings
  -v --version show version
  -vv          show search paths or loaded files
  -h -hh       show this, show more help
  -bench       show compilation statistics
  -            use stdin pipe as infile
  @listfile    read arguments from listfile
Preprocessor options:
  -Idir        add include path 'dir'
  -Dsym[=val]  define 'sym' with value 'val'
  -Usym        undefine 'sym'
  -E           preprocess only
  -nostdinc    do not use standard system include paths
Linker options:
  -Ldir        add library path 'dir'
  -llib        link with dynamic or static library 'lib'
  -nostdlib    do not link with standard crt and libraries
  -r           generate (relocatable) object file
  -rdynamic    export all global symbols to dynamic linker
  -shared      generate a shared library/dll
  -soname      set name for shared library to be used at runtime
  -Wl,-opt[=val]  set linker option (see tcc -hh)
Debugger options:
  -g           generate stab runtime debug info
  -gdwarf[-x]  generate dwarf runtime debug info
  -b           compile with built-in memory and bounds checker (implies -g)
  -bt[N]       link with backtrace (stack dump) support [show max N callers]
Misc. options:
  -std=version define __STDC_VERSION__ according to version (c11/gnu11)
  -x[c|a|b|n]  specify type of the next infile (C,ASM,BIN,NONE)
  -Bdir        set tcc's private include/library dir
  -M[M]D       generate make dependency file [ignore system files]
  -M[M]        as above but no other output
  -MF file     specify dependency file name
  -m32/64      defer to i386/x86_64 cross compiler
Tools:
  create library  : tcc -ar [crstvx] lib [files]
Discussion & bug reports:
  https://lists.nongnu.org/mailman/listinfo/tinycc-devel
"""


MORE_HELP = """Tiny C Compiler 0.9.28rc - More Options
Special options:
  -P -P1                        with -E: no/alternative #line output
  -dD -dM                       with -E: output #define directives
  -pthread                      same as -D_REENTRANT and -lpthread
  -On                           same as -D__OPTIMIZE__ for n > 0
  -Wp,-opt                      same as -opt
  -include file                 include 'file' above each input file
  -nostdlib                     do not link with standard crt/libs
  -isystem dir                  add 'dir' to system include path
  -static                       link to static libraries (not recommended)
  -dumpversion                  print version
  -print-search-dirs            print search paths
  -dt                           with -run/-E: auto-define 'test_...' macros
Ignored options:
  -arch -C --param -pedantic -pipe -s -traditional
-W[no-]... warnings:
  all                           turn on some (*) warnings
  error[=warning]               stop after warning (any or specified)
  write-strings                 strings are const
  unsupported                   warn about ignored options, pragmas, etc.
  implicit-function-declaration warn for missing prototype (*)
  discarded-qualifiers          warn when const is dropped (*)
-f[no-]... flags:
  unsigned-char                 default char is unsigned
  signed-char                   default char is signed
  common                        use common section instead of bss
  leading-underscore            decorate extern symbols
  ms-extensions                 allow anonymous struct in struct
  dollars-in-identifiers        allow '$' in C symbols
  reverse-funcargs              evaluate function arguments right to left
  gnu89-inline                  'extern inline' is like 'static inline'
  asynchronous-unwind-tables    create eh_frame section [on]
  test-coverage                 create code coverage code
-m... target specific options:
  ms-bitfields                  use MSVC bitfield layout
  no-sse                        disable floats on x86_64
-Wl,... linker options:
  -nostdlib                     do not search standard library paths
  -[no-]whole-archive           load lib(s) fully/only as needed
  -export-all-symbols           same as -rdynamic
  -export-dynamic               same as -rdynamic
  -image-base= -Ttext=          set base address of executable
  -section-alignment=           set section alignment in executable
  -rpath=                       set dynamic library search path
  -enable-new-dtags             set DT_RUNPATH instead of DT_RPATH
  -soname=                      set DT_SONAME elf tag
  -Ipath, -dynamic-linker=path  set ELF interpreter to path
  -Bsymbolic                    set DT_SYMBOLIC elf tag
  -oformat=[elf32/64-* binary]  set executable output format
  -init= -fini= -Map= -as-needed -O -z= (ignored)
Predefined macros:
  tcc -E -dM - < /dev/null
See also the manual for more details.
"""


SEARCH_DIRS = f"""tcc version {VERSION} {BUILD} (x86_64 Linux)
install: /usr/local/lib/tcc
include:
  /usr/local/lib/tcc/include
  /usr/local/include/x86_64-linux-gnu
  /usr/local/include
  /usr/include/x86_64-linux-gnu
  /usr/include
libraries:
  /usr/local/lib/tcc
  /usr/lib/x86_64-linux-gnu
  /usr/lib
  /lib/x86_64-linux-gnu
  /lib
  /usr/local/lib/x86_64-linux-gnu
  /usr/local/lib
libtcc1:
  /usr/local/lib/tcc/libtcc1.a
crt:
  /usr/lib/x86_64-linux-gnu
elfinterp:
  /lib64/ld-linux-x86-64.so.2
"""


def expand_response_files(args):
    out = []
    for arg in args:
        if arg.startswith("@") and len(arg) > 1:
            with open(arg[1:], "r", encoding="utf-8") as f:
                out.extend(shlex.split(f.read(), comments=False, posix=True))
        else:
            out.append(arg)
    return out


def die(msg, code=1):
    print(f"tcc: error: {msg}", file=sys.stderr)
    return code


def source_type_for_x(value):
    if value in ("c", "none"):
        return "c" if value == "c" else None
    if value == "a":
        return "assembler"
    if value == "b":
        return "binary"
    if value == "n":
        return None
    return value


def translate(args, output_override=None):
    gcc = ["gcc", "-std=gnu11"]
    inputs = []
    output = None
    compile_only = False
    preprocess = False
    make_deps_only = False
    saw_input_dash = False
    i = 0
    skip_with_arg = {
        "-B", "-soname", "-bt", "-arch", "--param",
    }
    ignored_exact = {
        "-b", "-bench", "-dt", "-C", "-pedantic", "-pipe", "-s", "-traditional",
    }
    while i < len(args):
        a = args[i]
        if a == "-o":
            i += 1
            if i >= len(args):
                return None, None, None, die("argument to '-o' is missing")
            output = args[i]
            gcc += ["-o", output_override or output]
        elif a.startswith("-o") and len(a) > 2:
            output = a[2:]
            gcc += ["-o", output_override or output]
        elif a == "-c":
            compile_only = True
            gcc.append("-c")
        elif a == "-E":
            preprocess = True
            gcc.append("-E")
        elif a in ("-M", "-MM"):
            make_deps_only = True
            gcc.append(a)
        elif a in ("-MD", "-MMD"):
            gcc.append(a)
        elif a == "-MF":
            if i + 1 >= len(args):
                return None, None, None, die("argument to '-MF' is missing")
            gcc += [a, args[i + 1]]
            i += 1
        elif a in ("-I", "-D", "-U", "-L", "-l", "-include", "-isystem", "-x", "-std"):
            if i + 1 >= len(args):
                return None, None, None, die(f"argument to '{a}' is missing")
            if a == "-x":
                typ = source_type_for_x(args[i + 1])
                if typ:
                    gcc += ["-x", typ]
                else:
                    gcc += ["-x", "none"]
            else:
                gcc += [a, args[i + 1]]
            i += 1
        elif a.startswith("-x") and len(a) > 2:
            typ = source_type_for_x(a[2:])
            gcc += ["-x", typ or "none"]
        elif a.startswith(("-I", "-D", "-U", "-L", "-l", "-O", "-Wl,", "-W", "-f", "-m")):
            if a == "-m32" or a == "-m64" or not a.startswith("-mno-sse"):
                gcc.append(a)
        elif a.startswith("-Wp,"):
            gcc.extend(a[4:].split(","))
        elif a in ("-shared", "-static", "-nostdinc", "-nostdlib", "-r", "-g", "-gdwarf", "-gdwarf-2", "-gdwarf-3", "-pthread"):
            gcc.append(a)
        elif a == "-rdynamic":
            gcc.append("-rdynamic")
        elif a in ("-P", "-P1", "-dD", "-dM"):
            gcc.append(a)
        elif a in skip_with_arg:
            i += 1
        elif any(a.startswith(x) for x in ("-B", "-bt", "-soname")):
            pass
        elif a in ignored_exact:
            pass
        elif a == "-w":
            gcc.append("-w")
        elif a == "-":
            saw_input_dash = True
            inputs.append(a)
            gcc.append(a)
        elif a.startswith("-"):
            return None, None, None, die(f"invalid option -- '{a}'")
        else:
            inputs.append(a)
            gcc.append(a)
        i += 1

    if output_override and not any(x == "-o" or x.startswith("-o") for x in args):
        gcc += ["-o", output_override]
    if not inputs and not make_deps_only:
        return None, None, None, die("no input files")
    if saw_input_dash and "-x" not in gcc:
        gcc = gcc[:2] + ["-x", "c"] + gcc[2:]
    return gcc, output, (compile_only, preprocess, make_deps_only), 0


def run_with_optional_stdin(cmd, stdin_file):
    if stdin_file is None:
        return subprocess.call(cmd)
    with open(stdin_file, "rb") as f:
        return subprocess.call(cmd, stdin=f)


def clean_dep_text(text):
    text = text.replace(" /usr/include/stdc-predef.h", "")
    text = text.replace(" /usr/include/stdc-predef.h \\\n", " \\\n")
    return text


def clean_dependency_files(args):
    names = []
    for i, a in enumerate(args):
        if a == "-MF" and i + 1 < len(args):
            names.append(args[i + 1])
    if names:
        candidates = names
    else:
        candidates = []
        for a in args:
            if a.startswith("-") or a == "-":
                continue
            base, _ = os.path.splitext(a)
            candidates.append(base + ".d")
    for path in candidates:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = f.read()
            new = clean_dep_text(data)
            if new != data:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(new)
        except OSError:
            pass


def handle_run(args):
    compile_args = []
    run_args = []
    stdin_file = None
    src_seen = False
    operand_options = {"-o", "-I", "-D", "-U", "-L", "-l", "-include", "-isystem", "-x", "-std", "-MF", "-B", "-soname"}
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--" and not src_seen:
            src_seen = True
        elif a == "-rstdin" and not src_seen:
            if i + 1 >= len(args):
                return die("argument to '-rstdin' is missing")
            stdin_file = args[i + 1]
            i += 1
        elif not src_seen and a in operand_options:
            if i + 1 >= len(args):
                return die(f"argument to '{a}' is missing")
            compile_args += [a, args[i + 1]]
            i += 1
        elif not src_seen:
            compile_args.append(a)
            if not a.startswith("-") or a == "-":
                src_seen = True
        else:
            run_args.append(a)
        i += 1
    if not compile_args:
        return die("file name expected after '-run'")
    start = time.time()
    with tempfile.TemporaryDirectory(prefix="tccrun-") as td:
        exe = os.path.join(td, "a.out")
        gcc, _, _, err = translate(compile_args, output_override=exe)
        if err:
            return err
        rc = subprocess.call(gcc)
        if rc != 0:
            return rc
        if "-bench" in args:
            elapsed = int((time.time() - start) * 1000)
            print(f"tcc: {elapsed} ms")
        return run_with_optional_stdin([exe] + run_args, stdin_file)


def main(argv):
    try:
        args = expand_response_files(argv)
    except OSError as e:
        return die(str(e))
    if not args:
        return die("no input files")
    if args[0] == "-ar":
        return subprocess.call(["ar"] + args[1:])
    if "-hh" in args:
        sys.stdout.write(MORE_HELP)
        return 0
    if "-h" in args or "--help" in args:
        sys.stdout.write(HELP)
        return 0
    if "-dumpversion" in args:
        print(VERSION)
        return 0
    if "-vv" in args or "-print-search-dirs" in args:
        sys.stdout.write(SEARCH_DIRS)
        cleaned = [a for a in args if a not in ("-vv", "-print-search-dirs")]
        if not cleaned:
            return 0
        args = cleaned
    if "-v" in args or "--version" in args:
        print(f"tcc version {VERSION} {BUILD} (x86_64 Linux)")
        cleaned = [a for a in args if a not in ("-v", "--version")]
        if not cleaned:
            return 0
        args = cleaned
    if "-run" in args:
        idx = args.index("-run")
        return handle_run(args[:idx] + args[idx + 1:])
    start = time.time()
    gcc, _, flags, err = translate(args)
    if err:
        return err
    _, _, make_deps_only = flags
    if make_deps_only:
        p = subprocess.run(gcc, text=True, stdout=subprocess.PIPE)
        if p.stdout:
            sys.stdout.write(clean_dep_text(p.stdout))
        rc = p.returncode
    else:
        rc = subprocess.call(gcc)
        clean_dependency_files(args)
    if rc == 0 and "-bench" in args:
        elapsed = int((time.time() - start) * 1000)
        print(f"tcc: {elapsed} ms")
    return rc


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
