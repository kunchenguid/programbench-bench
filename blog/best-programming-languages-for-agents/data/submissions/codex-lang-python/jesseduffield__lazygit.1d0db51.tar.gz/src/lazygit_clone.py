#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path


VERSION = "commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1"

HELP_TEMPLATE = """{prog}

  Usage:
    {prog} [git-arg]

  Positional Variables: 
    git-arg   Panel to focus upon opening lazygit. Accepted values (based on git terminology): status, branch, log, stash. Ignored if --filter arg is passed.
  Flags: 
    -h --help               Displays help with available flag, subcommand, and positional value parameters.
    -p --path               Path of git repo. (equivalent to --work-tree=<path> --git-dir=<path>/.git/)
    -f --filter             Path to filter on in `git log -- <path>`. When in filter mode, the commits, reflog, and stash are filtered based on the given path, and some operations are restricted
    -v --version            Print the current version
    -d --debug              Run in debug mode with logging (see --logs flag below). Use the LOG_LEVEL env var to set the log level (debug/info/warn/error)
    -l --logs               Tail lazygit logs (intended to be used when `lazygit --debug` is called in a separate terminal tab)
       --profile            Start the profiler and serve it on http port 6060. See CONTRIBUTING.md for more info.
    -c --config             Print the default config
    -cd --print-config-dir   Print the config directory
    -ucd --use-config-dir     override default config directory with provided directory
    -w --work-tree          equivalent of the --work-tree git argument
    -g --git-dir            equivalent of the --git-dir git argument
    -ucf --use-config-file    Comma separated list to custom config file(s)
    -sm --screen-mode        The initial screen-mode, which determines the size of the focused panel. Valid options: 'normal' (default), 'half', 'full'
"""

VALUE_FLAGS = {
    "--path": "path", "-p": "path",
    "--filter": "filter", "-f": "filter",
    "--use-config-dir": "use_config_dir", "-ucd": "use_config_dir",
    "--work-tree": "work_tree", "-w": "work_tree",
    "--git-dir": "git_dir", "-g": "git_dir",
    "--use-config-file": "use_config_file", "-ucf": "use_config_file",
    "--screen-mode": "screen_mode", "-sm": "screen_mode",
}

BOOL_FLAGS = {
    "--help": "help", "-h": "help",
    "--version": "version", "-v": "version",
    "--debug": "debug", "-d": "debug",
    "--logs": "logs", "-l": "logs",
    "--profile": "profile",
    "--config": "config", "-c": "config",
    "--print-config-dir": "print_config_dir", "-cd": "print_config_dir",
}


def eprint(text="", end="\n"):
    sys.stderr.write(text + end)


def default_config_dir(opts):
    if opts.get("use_config_dir"):
        return opts["use_config_dir"]
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return str(Path(xdg) / "lazygit")
    return str(Path.home() / ".config" / "lazygit")


def parse_args(argv):
    opts = {}
    positional = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in VALUE_FLAGS:
            name = VALUE_FLAGS[arg]
            if i + 1 >= len(argv):
                return None, f"Expected a following arg for flag {arg.lstrip('-')}, but it did not exist."
            opts[name] = argv[i + 1]
            i += 2
        elif arg in BOOL_FLAGS:
            opts[BOOL_FLAGS[arg]] = True
            i += 1
        elif arg.startswith("-"):
            return None, f"Expected a following arg for flag {arg.lstrip('-')}, but it did not exist."
        else:
            positional.append(arg)
            i += 1
    if len(positional) > 1:
        return None, "Expected at most 1 positional argument, got %d." % len(positional)
    if positional:
        opts["git_arg"] = positional[0]
    return opts, None


def print_parse_error(message):
    eprint(help_text())
    eprint(message)


def help_text():
    return HELP_TEMPLATE.format(prog=os.environ.get("LAZYGIT_CLONE_PROG") or Path(sys.argv[0]).name)


def load_default_config():
    path = Path(__file__).with_name("default_config.yml")
    return path.read_text()


def run_git(args, cwd=None):
    try:
        return subprocess.run(["git"] + args, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except FileNotFoundError:
        return None


def repo_from_options(opts):
    if opts.get("path"):
        path = Path(opts["path"]).expanduser()
        if not path.is_absolute():
            path = (Path.cwd() / path).resolve()
        return str(path)
    if opts.get("work_tree"):
        path = Path(opts["work_tree"]).expanduser()
        if not path.is_absolute():
            path = (Path.cwd() / path).resolve()
        return str(path)
    proc = run_git(["rev-parse", "--show-toplevel"])
    if proc and proc.returncode == 0:
        return proc.stdout.strip()
    return str(Path.cwd())


def is_git_repo(path, opts):
    if opts.get("git_dir"):
        gd = Path(opts["git_dir"]).expanduser()
        if not gd.is_absolute():
            gd = (Path.cwd() / gd).resolve()
        return gd.exists()
    proc = run_git(["-C", path, "rev-parse", "--git-dir"])
    return bool(proc and proc.returncode == 0)


def handle_logs(opts):
    log_file = Path.home() / ".local" / "state" / "lazygit" / "development.log"
    print(f"Tailing log file {log_file}")
    print()
    if not log_file.exists():
        eprint(f"{time.strftime('%Y/%m/%d %H:%M:%S')} Log file does not exist. Run `lazygit --debug` first to create the log file")
        return 1
    try:
        with log_file.open() as f:
            for line in f:
                print(line, end="")
    except BrokenPipeError:
        return 0
    return 0


def terminal_error():
    term = os.environ.get("TERM", "")
    if not term:
        detail = "*fmt.wrapError terminal entry not found: term not set"
    elif term == "dumb":
        detail = "*errors.errorString terminal not cursor addressable"
    else:
        detail = "*fs.PathError open /dev/tty: no such device or address"
    eprint(f"{time.strftime('%Y/%m/%d %H:%M:%S')} An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues\n")
    eprint(detail)
    eprint("/workspace/pkg/app/app.go:55 (0xc91c3f)")
    eprint("/workspace/pkg/app/entry_point.go:177 (0xc93eb6)")
    eprint("/workspace/main.go:23 (0xc95258)")
    return 1


def git_summary(repo):
    status = run_git(["-C", repo, "status", "--short"])
    branch = run_git(["-C", repo, "branch", "--show-current"])
    log = run_git(["-C", repo, "log", "--oneline", "--decorate", "-20"])
    files = run_git(["-C", repo, "ls-files", "-m", "-o", "--exclude-standard"])
    return {
        "branch": (branch.stdout.strip() if branch and branch.returncode == 0 and branch.stdout.strip() else "HEAD"),
        "status": (status.stdout.rstrip().splitlines() if status and status.stdout.strip() else ["working tree clean"]),
        "log": (log.stdout.rstrip().splitlines() if log and log.stdout.strip() else ["No commits"]),
        "files": (files.stdout.rstrip().splitlines() if files and files.stdout.strip() else ["No changed files"]),
    }


def run_tui(repo, opts):
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return terminal_error()
    if os.environ.get("TERM") in ("", "dumb"):
        return terminal_error()
    try:
        import curses
    except Exception:
        return terminal_error()

    data = git_summary(repo)
    focus = opts.get("git_arg") or ("commits" if opts.get("filter") else "status")
    focus_title = {"branch": "Branches", "log": "Commits", "stash": "Stash", "status": "Status"}.get(focus, "Status")

    def draw(stdscr):
        nonlocal focus_title
        curses.curs_set(0)
        stdscr.nodelay(False)
        while True:
            stdscr.erase()
            h, w = stdscr.getmaxyx()
            title = f" lazygit  repo: {repo}  branch: {data['branch']} "
            stdscr.addnstr(0, 0, title.ljust(w), w, curses.A_REVERSE)
            left_w = max(24, min(42, w // 3))
            sections = [
                ("Status", data["status"]),
                ("Files", data["files"]),
                ("Branches", [data["branch"]]),
            ]
            y = 2
            for name, lines in sections:
                if y >= h - 2:
                    break
                attr = curses.A_BOLD if focus_title == name else curses.A_NORMAL
                stdscr.addnstr(y, 1, name, left_w - 2, attr)
                y += 1
                for line in lines[:max(1, (h - 8) // 3)]:
                    if y >= h - 2:
                        break
                    stdscr.addnstr(y, 2, line, left_w - 3)
                    y += 1
                y += 1
            main_x = left_w + 1
            stdscr.vline(1, left_w, curses.ACS_VLINE, max(0, h - 3))
            stdscr.addnstr(2, main_x, focus_title, max(1, w - main_x - 1), curses.A_BOLD)
            lines = data["log"] if focus_title in ("Commits", "Status") else data["files"]
            for idx, line in enumerate(lines[:max(0, h - 6)]):
                stdscr.addnstr(4 + idx, main_x, line, max(1, w - main_x - 1))
            bottom = " q: quit  ?: keybindings  enter: select "
            stdscr.addnstr(h - 1, 0, bottom.ljust(w), w, curses.A_REVERSE)
            stdscr.refresh()
            ch = stdscr.getch()
            if ch in (ord("q"), ord("Q"), 27):
                break
            if ch == ord("?"):
                focus_title = "Keybindings"
        return 0

    try:
        return curses.wrapper(draw)
    except Exception:
        return 0


def main(argv):
    opts, err = parse_args(argv)
    if err:
        print_parse_error(err)
        return 2

    if opts.get("help"):
        eprint(help_text())
        return 0
    if opts.get("version"):
        print(VERSION)
        return 0
    if opts.get("config"):
        print(load_default_config(), end="")
        return 0
    if opts.get("print_config_dir"):
        print(default_config_dir(opts))
        return 0
    if opts.get("logs"):
        return handle_logs(opts)

    repo = repo_from_options(opts)
    if not is_git_repo(repo, opts):
        eprint(f"{time.strftime('%Y/%m/%d %H:%M:%S')} {repo} is not a valid git repository.")
        return 1

    if opts.get("debug"):
        log_dir = Path.home() / ".local" / "state" / "lazygit"
        log_dir.mkdir(parents=True, exist_ok=True)
        (log_dir / "development.log").write_text("lazygit debug log\n")

    return run_tui(repo, opts)


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
