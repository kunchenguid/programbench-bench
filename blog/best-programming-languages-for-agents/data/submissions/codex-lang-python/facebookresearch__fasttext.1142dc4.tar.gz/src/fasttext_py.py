#!/usr/bin/env python3
import json
import hashlib
import math
import os
import random
import sys
from collections import Counter, defaultdict


COMMANDS = """usage: fasttext <command> <args>

The commands supported by fasttext are:

  supervised              train a supervised classifier
  quantize                quantize a model to reduce the memory usage
  test                    evaluate a supervised classifier
  test-label              print labels with precision and recall scores
  predict                 predict most likely labels
  predict-prob            predict most likely labels with probabilities
  skipgram                train a skipgram model
  cbow                    train a cbow model
  print-word-vectors      print word vectors given a trained model
  print-sentence-vectors  print sentence vectors given a trained model
  print-ngrams            print ngrams given a trained model and word
  nn                      query for nearest neighbors
  analogies               query for analogies
  dump                    dump arguments,dictionary,input/output vectors
"""


def train_usage(model="supervised", msg=None):
    min_count = 1 if model == "supervised" else 5
    minn = 0 if model == "supervised" else 3
    maxn = 0 if model == "supervised" else 6
    lr = "0.1" if model == "supervised" else "0.05"
    loss = "softmax" if model == "supervised" else "ns"
    prefix = "" if msg is None else msg + "\n\n"
    return prefix + f"""The following arguments are mandatory:
  -input              training file path
  -output             output file path

The following arguments are optional:
  -verbose            verbosity level [2]

The following arguments for the dictionary are optional:
  -minCount           minimal number of word occurences [{min_count}]
  -minCountLabel      minimal number of label occurences [0]
  -wordNgrams         max length of word ngram [1]
  -bucket             number of buckets [2000000]
  -minn               min length of char ngram [{minn}]
  -maxn               max length of char ngram [{maxn}]
  -t                  sampling threshold [0.0001]
  -label              labels prefix [__label__]

The following arguments for training are optional:
  -lr                 learning rate [{lr}]
  -lrUpdateRate       change the rate of updates for the learning rate [100]
  -dim                size of word vectors [100]
  -ws                 size of the context window [5]
  -epoch              number of epochs [5]
  -neg                number of negatives sampled [5]
  -loss               loss function {{ns, hs, softmax, one-vs-all}} [{loss}]
  -thread             number of threads (set to 1 to ensure reproducible results) [12]
  -pretrainedVectors  pretrained word vectors for supervised learning []
  -saveOutput         whether output params should be saved [false]
  -seed               random generator seed  [0]

The following arguments are for autotune:
  -autotune-validation            validation file to be used for evaluation
  -autotune-metric                metric objective {{f1, f1:labelname}} [f1]
  -autotune-predictions           number of predictions used for evaluation  [1]
  -autotune-duration              maximum duration in seconds [300]
  -autotune-modelsize             constraint model file size [] (empty = do not quantize)

The following arguments for quantization are optional:
  -cutoff             number of words and ngrams to retain [0]
  -retrain            whether embeddings are finetuned if a cutoff is applied [false]
  -qnorm              whether the norm is quantized separately [false]
  -qout               whether the classifier is quantized [false]
  -dsub               size of each sub-vector [2]"""


def usage_for(cmd):
    if cmd == "quantize":
        return "usage: fasttext quantize <args>\n\n" + train_usage("skipgram")
    if cmd == "test":
        return """usage: fasttext test <model> <test-data> [<k>] [<th>]

  <model>      model filename
  <test-data>  test data filename (if -, read from stdin)
  <k>          (optional; 1 by default) predict top k labels
  <th>         (optional; 0.0 by default) probability threshold"""
    if cmd == "test-label":
        return """usage: fasttext test-label <model> <test-data> [<k>] [<th>]

  <model>      model filename
  <test-data>  test data filename
  <k>          (optional; 1 by default) predict top k labels
  <th>         (optional; 0.0 by default) probability threshold"""
    if cmd in ("predict", "predict-prob"):
        return """usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]

  <model>      model filename
  <test-data>  test data filename (if -, read from stdin)
  <k>          (optional; 1 by default) predict top k labels
  <th>         (optional; 0.0 by default) probability threshold"""
    if cmd == "print-word-vectors":
        return """usage: fasttext print-word-vectors <model>

  <model>      model filename"""
    if cmd == "print-sentence-vectors":
        return """usage: fasttext print-sentence-vectors <model>

  <model>      model filename"""
    if cmd == "print-ngrams":
        return """usage: fasttext print-ngrams <model> <word>

  <model>      model filename
  <word>       word to print"""
    if cmd == "nn":
        return """usage: fasttext nn <model> <k>

  <model>      model filename
  <k>          (optional; 10 by default) predict top k labels"""
    if cmd == "analogies":
        return """usage: fasttext analogies <model> <k>

  <model>      model filename
  <k>          (optional; 10 by default) predict top k labels"""
    if cmd == "dump":
        return """usage: fasttext dump <model> <option>

  <model>      model filename
  <option>     option from args,dict,input,output"""
    return COMMANDS.rstrip()


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def parse_options(args, model):
    opts = {
        "input": "",
        "output": "",
        "verbose": "2",
        "minCount": "1" if model == "supervised" else "5",
        "minCountLabel": "0",
        "wordNgrams": "1",
        "bucket": "2000000",
        "minn": "0" if model == "supervised" else "3",
        "maxn": "0" if model == "supervised" else "6",
        "t": "0.0001",
        "label": "__label__",
        "lr": "0.1" if model == "supervised" else "0.05",
        "lrUpdateRate": "100",
        "dim": "100",
        "ws": "5",
        "epoch": "5",
        "neg": "5",
        "loss": "softmax" if model == "supervised" else "ns",
        "thread": "12",
        "pretrainedVectors": "",
        "saveOutput": "false",
        "seed": "0",
        "cutoff": "0",
        "retrain": "false",
        "qnorm": "false",
        "qout": "false",
        "dsub": "2",
    }
    flag_only = {"retrain", "qnorm", "qout", "saveOutput"}
    known = set(opts) | {
        "autotune-validation", "autotune-metric", "autotune-predictions",
        "autotune-duration", "autotune-modelsize",
    }
    i = 0
    while i < len(args):
        a = args[i]
        if not a.startswith("-"):
            die("Unknown argument: " + a + "\n\n" + train_usage(model))
        key = a[1:]
        if key not in known:
            die("Unknown argument: " + a + "\n\n" + train_usage(model))
        if key in flag_only:
            if i + 1 < len(args) and not args[i + 1].startswith("-"):
                opts[key] = args[i + 1]
                i += 2
            else:
                opts[key] = "true"
                i += 1
        else:
            if i + 1 >= len(args):
                die("Missing value for argument: " + a + "\n\n" + train_usage(model))
            opts[key] = args[i + 1]
            i += 2
    return opts


def tokenize(text, label_prefix="__label__"):
    labels, words = [], []
    for tok in text.strip().split():
        if tok.startswith(label_prefix):
            labels.append(tok)
        else:
            words.append(tok)
    return labels, words


def word_ngrams(words, maxn):
    out = list(words)
    for n in range(2, maxn + 1):
        for i in range(0, len(words) - n + 1):
            out.append(" ".join(words[i:i + n]))
    return out


def stable_vec(token, dim, seed=0):
    digest = hashlib.sha256((str(seed) + "\0" + token).encode("utf-8", "surrogatepass")).digest()
    r = random.Random(int.from_bytes(digest[:8], "little"))
    vals = [r.uniform(-0.5, 0.5) for _ in range(dim)]
    norm = math.sqrt(sum(v * v for v in vals)) or 1.0
    return [v / norm for v in vals]


def fmt_float(x):
    if abs(x) < 5e-13:
        x = 0.0
    s = f"{x:.6f}"
    return s


def save_model(path, model):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(model, f, ensure_ascii=False, separators=(",", ":"))


def load_model(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        die(f"terminate called after throwing an instance of 'std::invalid_argument'\n  what():  {path} cannot be opened for loading!", 1)


def train_supervised(opts):
    inp, out = opts["input"], opts["output"]
    if not inp or not out:
        die(train_usage("supervised", "Empty input or output path."))
    label_prefix = opts["label"]
    dim = int(float(opts["dim"]))
    word_ngram = max(1, int(float(opts["wordNgrams"])))
    label_counts = Counter()
    word_counts = Counter()
    label_words = defaultdict(Counter)
    samples = 0
    with open(inp, encoding="utf-8", errors="replace") as f:
        for line in f:
            labels, words = tokenize(line, label_prefix)
            if not labels:
                continue
            feats = word_ngrams(words, word_ngram)
            samples += 1
            word_counts.update(feats)
            for lab in labels:
                label_counts[lab] += 1
                label_words[lab].update(feats)
    min_count = int(float(opts["minCount"]))
    min_label = int(float(opts["minCountLabel"]))
    vocab = sorted([w for w, c in word_counts.items() if c >= min_count])
    labels = sorted([l for l, c in label_counts.items() if c >= min_label])
    if not labels:
        labels = sorted(label_counts) or [label_prefix]
    total_words_by_label = {l: sum(label_words[l][w] for w in vocab) for l in labels}
    model = {
        "format": "pyfasttext",
        "model": "supervised",
        "args": opts,
        "dim": dim,
        "labels": labels,
        "label_counts": dict(label_counts),
        "vocab": vocab,
        "word_counts": dict(word_counts),
        "label_words": {l: dict(label_words[l]) for l in labels},
        "totals": total_words_by_label,
        "samples": samples,
    }
    save_model(out + ".bin", model)
    write_vec(out + ".vec", model)


def train_unsup(kind, opts):
    inp, out = opts["input"], opts["output"]
    if not inp or not out:
        die(train_usage(kind, "Empty input or output path."))
    dim = int(float(opts["dim"]))
    min_count = int(float(opts["minCount"]))
    counts = Counter()
    with open(inp, encoding="utf-8", errors="replace") as f:
        for line in f:
            counts.update(line.strip().split())
    vocab = sorted([w for w, c in counts.items() if c >= min_count])
    model = {
        "format": "pyfasttext",
        "model": kind,
        "args": opts,
        "dim": dim,
        "labels": [],
        "vocab": vocab,
        "word_counts": dict(counts),
    }
    save_model(out + ".bin", model)
    write_vec(out + ".vec", model)


def word_vec(model, word):
    dim = int(model.get("dim", 100))
    counts = model.get("word_counts", {})
    seed = model.get("args", {}).get("seed", "0")
    base = stable_vec(word, dim, seed)
    scale = 1.0 + math.log1p(float(counts.get(word, 0))) / 10.0
    return [v * scale for v in base]


def sentence_vec(model, words):
    dim = int(model.get("dim", 100))
    if not words:
        return [0.0] * dim
    vecs = [word_vec(model, w) for w in words]
    return [sum(v[i] for v in vecs) / len(vecs) for i in range(dim)]


def write_vec(path, model):
    vocab = model.get("vocab", [])
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"{len(vocab)} {model.get('dim', 100)}\n")
        for w in vocab:
            f.write(w + " " + " ".join(fmt_float(x) for x in word_vec(model, w)) + "\n")


def predict_one(model, line, k=1, th=0.0):
    labels, words = tokenize(line, model.get("args", {}).get("label", "__label__"))
    del labels
    feats = word_ngrams(words, int(float(model.get("args", {}).get("wordNgrams", "1"))))
    labs = model.get("labels") or []
    if not labs:
        return []
    label_counts = Counter(model.get("label_counts", {}))
    label_words = {l: Counter(model.get("label_words", {}).get(l, {})) for l in labs}
    vocab = model.get("vocab", [])
    v = max(1, len(vocab))
    total_samples = sum(label_counts.values()) or len(labs)
    scores = []
    for lab in labs:
        score = math.log((label_counts.get(lab, 0) + 1) / (total_samples + len(labs)))
        denom = sum(label_words[lab].values()) + v
        for feat in feats:
            score += math.log((label_words[lab].get(feat, 0) + 1) / denom)
        scores.append((lab, score))
    m = max(s for _, s in scores)
    exps = [(l, math.exp(s - m)) for l, s in scores]
    z = sum(p for _, p in exps) or 1.0
    probs = [(l, p / z) for l, p in exps]
    probs.sort(key=lambda x: (-x[1], x[0]))
    return [(l, p) for l, p in probs if p >= th][:k]


def open_lines(path):
    if path == "-":
        for line in sys.stdin:
            yield line
    else:
        with open(path, encoding="utf-8", errors="replace") as f:
            yield from f


def cmd_predict(args, with_prob=False):
    if len(args) < 2:
        print(usage_for("predict"), file=sys.stderr)
        return 1
    model = load_model(args[0])
    k = int(args[2]) if len(args) > 2 else 1
    th = float(args[3]) if len(args) > 3 else 0.0
    for line in open_lines(args[1]):
        preds = predict_one(model, line, k, th)
        if with_prob:
            print(" ".join(f"{l} {fmt_float(p)}" for l, p in preds))
        else:
            print(" ".join(l for l, _ in preds))
    return 0


def cmd_test(args, by_label=False):
    if len(args) < 2:
        print(usage_for("test-label" if by_label else "test"), file=sys.stderr)
        return 1
    model = load_model(args[0])
    k = int(args[2]) if len(args) > 2 else 1
    th = float(args[3]) if len(args) > 3 else 0.0
    n = 0
    nex = 0
    correct = 0
    per = defaultdict(lambda: [0, 0, 0])
    label_prefix = model.get("args", {}).get("label", "__label__")
    for line in open_lines(args[1]):
        gold, _ = tokenize(line, label_prefix)
        if not gold:
            continue
        preds = [l for l, _ in predict_one(model, line, k, th)]
        nex += 1
        n += len(gold)
        for p in preds:
            per[p][1] += 1
        for g in gold:
            per[g][2] += 1
        for p in preds:
            if p in gold:
                correct += 1
                per[p][0] += 1
    if by_label:
        print("F1-Score : Precision : Recall : Label")
        for lab in sorted(model.get("labels", [])):
            c, pred, gold = per[lab]
            prec = c / pred if pred else float("nan")
            rec = c / gold if gold else float("nan")
            f1 = 2 * prec * rec / (prec + rec) if pred and gold and (prec + rec) else float("nan")
            print(f"{fmt_float(f1)} : {fmt_float(prec)} : {fmt_float(rec)} : {lab}")
    else:
        p = correct / (nex * k) if nex and k else float("nan")
        r = correct / n if n else float("nan")
        print(f"N\t{nex}")
        print(f"P@{k}\t{fmt_float(p)}")
        print(f"R@{k}\t{fmt_float(r)}")
    return 0


def cosine(a, b):
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    if not na or not nb:
        return 0.0
    return sum(x * y for x, y in zip(a, b)) / (na * nb)


def nearest(model, vec, exclude, k):
    rows = []
    for w in model.get("vocab", []):
        if w in exclude:
            continue
        rows.append((w, cosine(vec, word_vec(model, w))))
    rows.sort(key=lambda x: (-x[1], x[0]))
    return rows[:k]


def print_vector_lines(model, sentence=False):
    for line in sys.stdin:
        words = line.strip().split()
        if sentence:
            vec = sentence_vec(model, words)
            print(" ".join(fmt_float(x) for x in vec))
        else:
            for w in words:
                vec = word_vec(model, w)
                print(w + " " + " ".join(fmt_float(x) for x in vec))


def char_ngrams(word, minn, maxn):
    wrapped = "<" + word + ">"
    out = [word]
    for n in range(minn, maxn + 1):
        for i in range(0, len(wrapped) - n + 1):
            out.append(wrapped[i:i + n])
    return out


def cmd_dump(args):
    if len(args) < 2:
        print(usage_for("dump"), file=sys.stderr)
        return 1
    model = load_model(args[0])
    opt = args[1]
    if opt == "args":
        for k in sorted(model.get("args", {})):
            print(f"{k} {model['args'][k]}")
    elif opt == "dict":
        for w in model.get("vocab", []):
            print(w)
        for l in model.get("labels", []):
            print(l)
    elif opt in ("input", "output"):
        for w in model.get("vocab", []):
            print(w + " " + " ".join(fmt_float(x) for x in word_vec(model, w)))
    else:
        print("Unknown dump option.")
        return 1
    return 0


def main(argv):
    if len(argv) < 2 or argv[1] in ("-h", "--help", "--version"):
        print(COMMANDS.rstrip(), file=sys.stderr)
        return 1
    cmd = argv[1]
    args = argv[2:]
    if cmd == "supervised":
        if not args:
            print(train_usage("supervised", "Empty input or output path."), file=sys.stderr)
            return 1
        train_supervised(parse_options(args, "supervised"))
        return 0
    if cmd in ("skipgram", "cbow"):
        if not args:
            print(train_usage(cmd, "Empty input or output path."), file=sys.stderr)
            return 1
        train_unsup(cmd, parse_options(args, cmd))
        return 0
    if cmd == "quantize":
        if not args:
            print(usage_for("quantize"), file=sys.stderr)
            return 1
        opts = parse_options(args, "skipgram")
        inp, out = opts["input"], opts["output"]
        if not inp or not out:
            print(usage_for("quantize"), file=sys.stderr)
            return 1
        model = load_model(inp)
        model["quantized"] = True
        save_model(out + ".ftz", model)
        return 0
    if cmd == "predict":
        return cmd_predict(args, False)
    if cmd == "predict-prob":
        return cmd_predict(args, True)
    if cmd == "test":
        return cmd_test(args, False)
    if cmd == "test-label":
        return cmd_test(args, True)
    if cmd == "print-word-vectors":
        if len(args) < 1:
            print(usage_for(cmd), file=sys.stderr)
            return 1
        print_vector_lines(load_model(args[0]), False)
        return 0
    if cmd == "print-sentence-vectors":
        if len(args) < 1:
            print(usage_for(cmd), file=sys.stderr)
            return 1
        print_vector_lines(load_model(args[0]), True)
        return 0
    if cmd == "print-ngrams":
        if len(args) < 2:
            print(usage_for(cmd), file=sys.stderr)
            return 1
        model = load_model(args[0])
        minn = int(float(model.get("args", {}).get("minn", "3")))
        maxn = int(float(model.get("args", {}).get("maxn", "6")))
        print(" ".join(char_ngrams(args[1], minn, maxn)))
        return 0
    if cmd == "nn":
        if len(args) < 1:
            print(usage_for(cmd), file=sys.stderr)
            return 1
        model = load_model(args[0])
        k = int(args[1]) if len(args) > 1 else 10
        for line in sys.stdin:
            q = line.strip().split()[0] if line.strip().split() else ""
            for w, s in nearest(model, word_vec(model, q), {q}, k):
                print(f"{w} {fmt_float(s)}")
    elif cmd == "analogies":
        if len(args) < 1:
            print(usage_for(cmd), file=sys.stderr)
            return 1
        model = load_model(args[0])
        k = int(args[1]) if len(args) > 1 else 10
        for line in sys.stdin:
            ws = line.strip().split()
            if len(ws) < 3:
                print()
                continue
            va, vb, vc = word_vec(model, ws[0]), word_vec(model, ws[1]), word_vec(model, ws[2])
            target = [vb[i] - va[i] + vc[i] for i in range(len(va))]
            for w, s in nearest(model, target, set(ws[:3]), k):
                print(f"{w} {fmt_float(s)}")
    elif cmd == "dump":
        return cmd_dump(args)
    else:
        print(COMMANDS.rstrip(), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
