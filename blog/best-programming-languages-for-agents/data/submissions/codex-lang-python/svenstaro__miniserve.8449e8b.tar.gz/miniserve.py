#!/usr/bin/env python3
import base64
import email.utils
import gzip
import hashlib
import html
import io
import mimetypes
import os
import posixpath
import random
import re
import shutil
import socket
import string
import sys
import tarfile
import tempfile
import urllib.parse
import zipfile
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

VERSION = "0.32.0"

HELP_LONG = """For when you really just want to serve some files over HTTP right now!

Usage: executable [OPTIONS] [PATH]

Arguments:
  [PATH]
          Which path to serve
          
          [env: MINISERVE_PATH=]

Options:
  -v, --verbose
          Be verbose, includes emitting access logs
          
          [env: MINISERVE_VERBOSE=]

      --temp-directory <TEMP_UPLOAD_DIRECTORY>
          The path to where file uploads will be written to before being moved to their correct
          location. It's wise to make sure that this directory will be written to disk and not into
          memory.
          
          This value will only be used **IF** file uploading is enabled. If this option is not set,
          the operating system default temporary directory will be used.
          
          [env: MINISERVER_TEMP_UPLOAD_DIRECTORY=]

      --index <INDEX>
          The name of a directory index file to serve, like "index.html"
          
          Normally, when miniserve serves a directory, it creates a listing for that directory.
          However, if a directory contains this file, miniserve will serve that file instead.
          
          [env: MINISERVE_INDEX=]

      --spa
          Activate SPA (Single Page Application) mode
          
          This will cause the file given by --index to be served for all non-existing file paths. In
          effect, this will serve the index file whenever a 404 would otherwise occur in order to
          allow the SPA router to handle the request instead.
          
          [env: MINISERVE_SPA=]

      --pretty-urls
          Activate Pretty URLs mode
          
          This will cause the server to serve the equivalent `.html` file indicated by the path.
          
          `/about` will try to find `about.html` and serve it.
          
          [env: MINISERVE_PRETTY_URLS=]

  -p, --port <PORT>
          Port to use
          
          [env: MINISERVE_PORT=]
          [default: 8080]

  -i, --interfaces <INTERFACES>
          Interface to listen on
          
          [env: MINISERVE_INTERFACE=]

  -a, --auth <AUTH>
          Set authentication
          
          Currently supported formats:
          username:password, username:sha256:hash, username:sha512:hash
          (e.g. joe:123,
          joe:sha256:a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3)
          
          [env: MINISERVE_AUTH=]

      --auth-file <AUTH_FILE>
          Read authentication values from a file
          
          Example file content:
          
          joe:123
          bob:sha256:a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3
          bill:
          
          [env: MINISERVE_AUTH_FILE=]

      --route-prefix <ROUTE_PREFIX>
          Use a specific route prefix
          
          [env: MINISERVE_ROUTE_PREFIX=]

      --random-route
          Generate a random 6-hexdigit route
          
          [env: MINISERVE_RANDOM_ROUTE=]

  -P, --no-symlinks
          Hide symlinks in listing and prevent them from being followed
          
          [env: MINISERVE_NO_SYMLINKS=]

  -H, --hidden
          Show hidden files
          
          [env: MINISERVE_HIDDEN=]

  -S, --default-sorting-method <DEFAULT_SORTING_METHOD>
          Default sorting method for file list

          Possible values:
          - name: Sort by name
          - size: Sort by size
          - date: Sort by last modification date (natural sort: follows alphanumerical order)
          
          [env: MINISERVE_DEFAULT_SORTING_METHOD=]
          [default: name]

  -O, --default-sorting-order <DEFAULT_SORTING_ORDER>
          Default sorting order for file list

          Possible values:
          - asc:  Ascending order
          - desc: Descending order
          
          [env: MINISERVE_DEFAULT_SORTING_ORDER=]
          [default: desc]

  -c, --color-scheme <COLOR_SCHEME>
          Default color scheme
          
          [env: MINISERVE_COLOR_SCHEME=]
          [default: squirrel]
          [possible values: squirrel, archlinux, zenburn, monokai]

  -d, --color-scheme-dark <COLOR_SCHEME_DARK>
          Default color scheme
          
          [env: MINISERVE_COLOR_SCHEME_DARK=]
          [default: archlinux]
          [possible values: squirrel, archlinux, zenburn, monokai]

  -q, --qrcode
          Enable QR code display
          
          [env: MINISERVE_QRCODE=]

  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]
          Enable file uploading (and optionally specify for which directory)
          
          [env: MINISERVE_ALLOWED_UPLOAD_DIR=]

      --web-upload-files-concurrency <WEB_UPLOAD_CONCURRENCY>
          Configure amount of concurrent uploads when visiting the website. Must have upload-files
          option enabled for this setting to matter.
          
          [env: MINISERVE_WEB_UPLOAD_CONCURRENCY=]
          [default: 0]

      --chmod <CHMOD>
          Set unix file permissions of uploaded files
          
          [env: MINISERVE_CHMOD=]

      --directory-size
          Enable recursive directory size calculation
          
          [env: MINISERVE_DIRECTORY_SIZE=]

  -U, --mkdir
          Enable creating directories
          
          [env: MINISERVE_MKDIR_ENABLED=]

  -m, --media-type <MEDIA_TYPE>
          Specify uploadable media types
          
          [env: MINISERVE_MEDIA_TYPE=]
          [possible values: image, audio, video]

  -M, --raw-media-type <MEDIA_TYPE_RAW>
          Directly specify the uploadable media type expression
          
          [env: MINISERVE_RAW_MEDIA_TYPE=]

  -o, --on-duplicate-files <ON_DUPLICATE_FILES>
          What to do if existing files with same name is present during file upload
          
          [env: MINISERVE_ON_DUPLICATE_FILES=]
          [default: error]
          [possible values: error, overwrite, rename]

  -R, --rm-files [<ALLOWED_RM_DIR>]
          Enable file and directory deletion (and optionally specify for which directory)
          
          [env: MINISERVE_ALLOWED_RM_DIR=]

  -r, --enable-tar
          Enable uncompressed tar archive generation
          
          [env: MINISERVE_ENABLE_TAR=]

  -g, --enable-tar-gz
          Enable gz-compressed tar archive generation
          
          [env: MINISERVE_ENABLE_TAR_GZ=]

  -z, --enable-zip
          Enable zip archive generation
          
          [env: MINISERVE_ENABLE_ZIP=]

  -C, --compress-response
          Compress response
          
          [env: MINISERVE_COMPRESS_RESPONSE=]

  -D, --dirs-first
          List directories first
          
          [env: MINISERVE_DIRS_FIRST=]

  -t, --title <TITLE>
          Shown instead of host in page title and heading
          
          [env: MINISERVE_TITLE=]

      --header <HEADER>
          Inserts custom headers into the responses. Specify each header as a 'Header:Value' pair.
          This parameter can be used multiple times to add multiple headers.
          
          [env: MINISERVE_HEADER=]

  -l, --show-symlink-info
          Visualize symlinks in directory listing
          
          [env: MINISERVE_SHOW_SYMLINK_INFO=]

  -F, --hide-version-footer
          Hide version footer
          
          [env: MINISERVE_HIDE_VERSION_FOOTER=]

      --hide-theme-selector
          Hide theme selector
          
          [env: MINISERVE_HIDE_THEME_SELECTOR=]

  -W, --show-wget-footer
          If enabled, display a wget command to recursively download the current directory
          
          [env: MINISERVE_SHOW_WGET_FOOTER=]

      --print-completions <shell>
          Generate completion file for a shell
          
          [possible values: bash, elvish, fish, powershell, zsh]

      --print-manpage
          Generate man page

      --tls-cert <TLS_CERT>
          TLS certificate to use
          
          [env: MINISERVE_TLS_CERT=]

      --tls-key <TLS_KEY>
          TLS private key to use
          
          [env: MINISERVE_TLS_KEY=]

      --readme
          Enable README.md rendering in directories
          
          [env: MINISERVE_README=]

  -I, --disable-indexing
          Disable indexing
          
          [env: MINISERVE_DISABLE_INDEXING=]

      --enable-webdav
          Enable read-only WebDAV support (PROPFIND requests)
          
          [env: MINISERVE_ENABLE_WEBDAV=]

      --size-display <SIZE_DISPLAY>
          Show served file size in exact bytes
          
          [env: MINISERVE_SIZE_DISPLAY=]
          [default: human]
          [possible values: human, exact]

      --file-external-url <FILE_EXTERNAL_URL>
          Optional external URL (e.g., 'http://external.example.com:8081') prepended to file links
          in listings.
          
          [env: MINISERVE_FILE_EXTERNAL_URL=]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


HELP_SHORT = """For when you really just want to serve some files over HTTP right now!

Usage: executable [OPTIONS] [PATH]

Arguments:
  [PATH]  Which path to serve [env: MINISERVE_PATH=]

Options:
  -v, --verbose
          Be verbose, includes emitting access logs [env: MINISERVE_VERBOSE=]
      --temp-directory <TEMP_UPLOAD_DIRECTORY>
          The path to where file uploads will be written to before being moved to their correct
          location. It's wise to make sure that this directory will be written to disk and not into
          memory [env: MINISERVER_TEMP_UPLOAD_DIRECTORY=]
      --index <INDEX>
          The name of a directory index file to serve, like "index.html" [env: MINISERVE_INDEX=]
      --spa
          Activate SPA (Single Page Application) mode [env: MINISERVE_SPA=]
      --pretty-urls
          Activate Pretty URLs mode [env: MINISERVE_PRETTY_URLS=]
  -p, --port <PORT>
          Port to use [env: MINISERVE_PORT=] [default: 8080]
  -i, --interfaces <INTERFACES>
          Interface to listen on [env: MINISERVE_INTERFACE=]
  -a, --auth <AUTH>
          Set authentication [env: MINISERVE_AUTH=]
      --auth-file <AUTH_FILE>
          Read authentication values from a file [env: MINISERVE_AUTH_FILE=]
      --route-prefix <ROUTE_PREFIX>
          Use a specific route prefix [env: MINISERVE_ROUTE_PREFIX=]
      --random-route
          Generate a random 6-hexdigit route [env: MINISERVE_RANDOM_ROUTE=]
  -P, --no-symlinks
          Hide symlinks in listing and prevent them from being followed [env:
          MINISERVE_NO_SYMLINKS=]
  -H, --hidden
          Show hidden files [env: MINISERVE_HIDDEN=]
  -S, --default-sorting-method <DEFAULT_SORTING_METHOD>
          Default sorting method for file list [env: MINISERVE_DEFAULT_SORTING_METHOD=] [default:
          name] [possible values: name, size, date]
  -O, --default-sorting-order <DEFAULT_SORTING_ORDER>
          Default sorting order for file list [env: MINISERVE_DEFAULT_SORTING_ORDER=] [default:
          desc] [possible values: asc, desc]
  -c, --color-scheme <COLOR_SCHEME>
          Default color scheme [env: MINISERVE_COLOR_SCHEME=] [default: squirrel] [possible values:
          squirrel, archlinux, zenburn, monokai]
  -d, --color-scheme-dark <COLOR_SCHEME_DARK>
          Default color scheme [env: MINISERVE_COLOR_SCHEME_DARK=] [default: archlinux] [possible
          values: squirrel, archlinux, zenburn, monokai]
  -q, --qrcode
          Enable QR code display [env: MINISERVE_QRCODE=]
  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]
          Enable file uploading (and optionally specify for which directory) [env:
          MINISERVE_ALLOWED_UPLOAD_DIR=]
      --web-upload-files-concurrency <WEB_UPLOAD_CONCURRENCY>
          Configure amount of concurrent uploads when visiting the website. Must have upload-files
          option enabled for this setting to matter [env: MINISERVE_WEB_UPLOAD_CONCURRENCY=]
          [default: 0]
      --chmod <CHMOD>
          Set unix file permissions of uploaded files [env: MINISERVE_CHMOD=]
      --directory-size
          Enable recursive directory size calculation [env: MINISERVE_DIRECTORY_SIZE=]
  -U, --mkdir
          Enable creating directories [env: MINISERVE_MKDIR_ENABLED=]
  -m, --media-type <MEDIA_TYPE>
          Specify uploadable media types [env: MINISERVE_MEDIA_TYPE=] [possible values: image,
          audio, video]
  -M, --raw-media-type <MEDIA_TYPE_RAW>
          Directly specify the uploadable media type expression [env: MINISERVE_RAW_MEDIA_TYPE=]
  -o, --on-duplicate-files <ON_DUPLICATE_FILES>
          What to do if existing files with same name is present during file upload [env:
          MINISERVE_ON_DUPLICATE_FILES=] [default: error] [possible values: error, overwrite,
          rename]
  -R, --rm-files [<ALLOWED_RM_DIR>]
          Enable file and directory deletion (and optionally specify for which directory) [env:
          MINISERVE_ALLOWED_RM_DIR=]
  -r, --enable-tar
          Enable uncompressed tar archive generation [env: MINISERVE_ENABLE_TAR=]
  -g, --enable-tar-gz
          Enable gz-compressed tar archive generation [env: MINISERVE_ENABLE_TAR_GZ=]
  -z, --enable-zip
          Enable zip archive generation [env: MINISERVE_ENABLE_ZIP=]
  -C, --compress-response
          Compress response [env: MINISERVE_COMPRESS_RESPONSE=]
  -D, --dirs-first
          List directories first [env: MINISERVE_DIRS_FIRST=]
  -t, --title <TITLE>
          Shown instead of host in page title and heading [env: MINISERVE_TITLE=]
      --header <HEADER>
          Inserts custom headers into the responses. Specify each header as a 'Header:Value' pair.
          This parameter can be used multiple times to add multiple headers [env: MINISERVE_HEADER=]
  -l, --show-symlink-info
          Visualize symlinks in directory listing [env: MINISERVE_SHOW_SYMLINK_INFO=]
  -F, --hide-version-footer
          Hide version footer [env: MINISERVE_HIDE_VERSION_FOOTER=]
      --hide-theme-selector
          Hide theme selector [env: MINISERVE_HIDE_THEME_SELECTOR=]
  -W, --show-wget-footer
          If enabled, display a wget command to recursively download the current directory [env:
          MINISERVE_SHOW_WGET_FOOTER=]
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,
          zsh]
      --print-manpage
          Generate man page
      --tls-cert <TLS_CERT>
          TLS certificate to use [env: MINISERVE_TLS_CERT=]
      --tls-key <TLS_KEY>
          TLS private key to use [env: MINISERVE_TLS_KEY=]
      --readme
          Enable README.md rendering in directories [env: MINISERVE_README=]
  -I, --disable-indexing
          Disable indexing [env: MINISERVE_DISABLE_INDEXING=]
      --enable-webdav
          Enable read-only WebDAV support (PROPFIND requests) [env: MINISERVE_ENABLE_WEBDAV=]
      --size-display <SIZE_DISPLAY>
          Show served file size in exact bytes [env: MINISERVE_SIZE_DISPLAY=] [default: human]
          [possible values: human, exact]
      --file-external-url <FILE_EXTERNAL_URL>
          Optional external URL (e.g., 'http://external.example.com:8081') prepended to file links
          in listings [env: MINISERVE_FILE_EXTERNAL_URL=]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


class Config:
    def __init__(self):
        self.path = os.environ.get("MINISERVE_PATH") or "."
        self.port = int(os.environ.get("MINISERVE_PORT") or "8080")
        self.interfaces = os.environ.get("MINISERVE_INTERFACE") or ""
        self.verbose = env_bool("MINISERVE_VERBOSE")
        self.index = os.environ.get("MINISERVE_INDEX")
        self.spa = env_bool("MINISERVE_SPA")
        self.pretty = env_bool("MINISERVE_PRETTY_URLS")
        self.hidden = env_bool("MINISERVE_HIDDEN")
        self.no_symlinks = env_bool("MINISERVE_NO_SYMLINKS")
        self.disable_indexing = env_bool("MINISERVE_DISABLE_INDEXING")
        self.dirs_first = env_bool("MINISERVE_DIRS_FIRST")
        self.title = os.environ.get("MINISERVE_TITLE")
        self.hide_footer = env_bool("MINISERVE_HIDE_VERSION_FOOTER")
        self.readme = env_bool("MINISERVE_README")
        self.auth = []
        self.route_prefix = os.environ.get("MINISERVE_ROUTE_PREFIX") or ""
        self.random_route = env_bool("MINISERVE_RANDOM_ROUTE")
        self.headers = []
        self.upload = os.environ.get("MINISERVE_ALLOWED_UPLOAD_DIR")
        self.mkdir = env_bool("MINISERVE_MKDIR_ENABLED")
        self.rm = os.environ.get("MINISERVE_ALLOWED_RM_DIR")
        self.enable_tar = env_bool("MINISERVE_ENABLE_TAR")
        self.enable_targz = env_bool("MINISERVE_ENABLE_TAR_GZ")
        self.enable_zip = env_bool("MINISERVE_ENABLE_ZIP")
        self.size_display = os.environ.get("MINISERVE_SIZE_DISPLAY") or "human"
        self.external_url = os.environ.get("MINISERVE_FILE_EXTERNAL_URL") or ""
        self.on_duplicate = os.environ.get("MINISERVE_ON_DUPLICATE_FILES") or "error"
        self.chmod = os.environ.get("MINISERVE_CHMOD")
        self.tempdir = os.environ.get("MINISERVER_TEMP_UPLOAD_DIRECTORY") or None


def env_bool(name):
    val = os.environ.get(name)
    return val is not None and val.lower() not in ("", "0", "false", "no", "off")


def parse_args(argv):
    cfg = Config()
    takes_value = {
        "--temp-directory": "tempdir", "--index": "index", "-p": "port", "--port": "port",
        "-i": "interfaces", "--interfaces": "interfaces", "-a": "auth", "--auth": "auth",
        "--auth-file": "auth_file", "--route-prefix": "route_prefix",
        "-S": "sort", "--default-sorting-method": "sort", "-O": "order",
        "--default-sorting-order": "order", "-c": "color", "--color-scheme": "color",
        "-d": "color_dark", "--color-scheme-dark": "color_dark",
        "--web-upload-files-concurrency": "ignored", "--chmod": "chmod",
        "-m": "ignored", "--media-type": "ignored", "-M": "ignored", "--raw-media-type": "ignored",
        "-o": "on_duplicate", "--on-duplicate-files": "on_duplicate", "-t": "title",
        "--title": "title", "--header": "header", "--print-completions": "completion",
        "--tls-cert": "ignored", "--tls-key": "ignored", "--size-display": "size_display",
        "--file-external-url": "external_url",
    }
    flags = {
        "-v": "verbose", "--verbose": "verbose", "--spa": "spa", "--pretty-urls": "pretty",
        "--random-route": "random_route", "-P": "no_symlinks", "--no-symlinks": "no_symlinks",
        "-H": "hidden", "--hidden": "hidden", "-q": "ignored", "--qrcode": "ignored",
        "--directory-size": "ignored", "-U": "mkdir", "--mkdir": "mkdir",
        "-r": "enable_tar", "--enable-tar": "enable_tar", "-g": "enable_targz",
        "--enable-tar-gz": "enable_targz", "-z": "enable_zip", "--enable-zip": "enable_zip",
        "-C": "ignored", "--compress-response": "ignored", "-D": "dirs_first",
        "--dirs-first": "dirs_first", "-l": "ignored", "--show-symlink-info": "ignored",
        "-F": "hide_footer", "--hide-version-footer": "hide_footer",
        "--hide-theme-selector": "ignored", "-W": "ignored", "--show-wget-footer": "ignored",
        "--print-manpage": "print_manpage", "--readme": "readme", "-I": "disable_indexing",
        "--disable-indexing": "disable_indexing", "--enable-webdav": "webdav",
    }
    optional = {"-u": "upload", "--upload-files": "upload", "-R": "rm", "--rm-files": "rm"}
    positionals = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            positionals.extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            print(HELP_SHORT if a == "-h" else HELP_LONG, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(f"miniserve {VERSION}")
            raise SystemExit(0)
        if a.startswith("--") and "=" in a:
            opt, val = a.split("=", 1)
            if opt in takes_value:
                set_value(cfg, takes_value[opt], val)
                i += 1
                continue
            if opt in optional:
                set_value(cfg, optional[opt], val or "/")
                i += 1
                continue
        if a in takes_value:
            if i + 1 >= len(argv):
                usage_error(f"a value is required for '{a} <{takes_value[a].upper()}>' but none was supplied")
            set_value(cfg, takes_value[a], argv[i + 1])
            i += 2
            continue
        if a in optional:
            val = "/"
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                val = argv[i + 1]
                i += 1
            set_value(cfg, optional[a], val)
            i += 1
            continue
        if a in flags:
            name = flags[a]
            if name == "print_manpage":
                print_manpage()
                raise SystemExit(0)
            if name != "ignored":
                setattr(cfg, name, True)
            i += 1
            continue
        if a.startswith("-"):
            usage_error(f"unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'")
        positionals.append(a)
        i += 1
    if len(positionals) > 1:
        usage_error(f"unexpected argument '{positionals[1]}' found")
    if positionals:
        cfg.path = positionals[0]
    if cfg.random_route:
        cfg.route_prefix = "/" + "".join(random.choice("0123456789abcdef") for _ in range(6))
    if cfg.route_prefix and not cfg.route_prefix.startswith("/"):
        cfg.route_prefix = "/" + cfg.route_prefix
    cfg.route_prefix = cfg.route_prefix.rstrip("/")
    if os.environ.get("MINISERVE_AUTH"):
        cfg.auth.append(os.environ["MINISERVE_AUTH"])
    return cfg


def set_value(cfg, name, val):
    if name == "auth":
        cfg.auth.append(val)
    elif name == "auth_file":
        try:
            with open(val, "r", encoding="utf-8") as f:
                cfg.auth.extend(line.strip() for line in f if line.strip())
        except OSError as e:
            print(f"Error: {e}", file=sys.stderr)
            raise SystemExit(1)
    elif name == "header":
        cfg.headers.append(val)
    elif name == "completion":
        print(f"# completion script for miniserve ({val})")
        raise SystemExit(0)
    elif name == "port":
        try:
            cfg.port = int(val)
        except ValueError:
            usage_error(f"invalid value '{val}' for '--port <PORT>': invalid digit found in string")
    elif name == "ignored":
        pass
    else:
        setattr(cfg, name, val)


def usage_error(msg):
    print(f"error: {msg}\n\nUsage: executable [OPTIONS] [PATH]\n\nFor more information, try '--help'.", file=sys.stderr)
    raise SystemExit(2)


def print_manpage():
    print(f""".ie \\n(.g .ds Aq \\(aq
.el .ds Aq '
.TH miniserve 1  "miniserve {VERSION}" 
.SH NAME
miniserve \\- For when you really just want to serve some files over HTTP right now!
.SH SYNOPSIS
\\fBminiserve\\fR [\\fBOPTIONS\\fR] [\\fIPATH\\fR]
.SH DESCRIPTION
For when you really just want to serve some files over HTTP right now!
.SH OPTIONS
.TP
\\fB\\-h\\fR, \\fB\\-\\-help\\fR
Print help
.TP
\\fB\\-V\\fR, \\fB\\-\\-version\\fR
Print version
""", end="")


def make_handler(cfg):
    root = Path(cfg.path).resolve()
    single_file = root.is_file()

    class Handler(BaseHTTPRequestHandler):
        server_version = "miniserve"
        sys_version = ""
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):
            if cfg.verbose:
                sys.stderr.write("%s - - [%s] %s\n" % (self.address_string(), self.log_date_time_string(), fmt % args))

        def do_HEAD(self):
            self.handle_request(head=True)

        def do_GET(self):
            self.handle_request(head=False)

        def do_POST(self):
            if self.path.startswith((cfg.route_prefix or "") + "/__miniserve_internal/api"):
                self.send_bytes(b"~", "text/plain")
                return
            if cfg.upload and self.clean_path().startswith("/upload"):
                self.handle_upload()
                return
            self.send_error_page(405, "Method Not Allowed")

        def do_DELETE(self):
            if not cfg.rm:
                self.send_error_page(405, "Method Not Allowed")
                return
            fs = self.resolve_path()
            if not fs or not fs.exists():
                self.send_error_page(404, "Not Found")
                return
            try:
                if fs.is_dir():
                    shutil.rmtree(fs)
                else:
                    fs.unlink()
                self.send_bytes(b"OK\n", "text/plain")
            except OSError as e:
                self.send_error_page(500, str(e))

        def do_MKCOL(self):
            if not cfg.mkdir:
                self.send_error_page(405, "Method Not Allowed")
                return
            fs = self.resolve_path()
            try:
                fs.mkdir(parents=True, exist_ok=True)
                self.send_response(201)
                self.send_common_headers(0, "text/plain")
                self.end_headers()
            except OSError as e:
                self.send_error_page(500, str(e))

        def do_PROPFIND(self):
            if not getattr(cfg, "webdav", False):
                self.send_error_page(405, "Method Not Allowed")
                return
            body = b'<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:"></D:multistatus>'
            self.send_response(207)
            self.send_common_headers(len(body), "application/xml; charset=utf-8")
            self.end_headers()
            self.wfile.write(body)

        def handle_request(self, head=False):
            if not self.check_auth():
                return
            if self.path_only().startswith((cfg.route_prefix or "") + "/__miniserve_internal/"):
                if self.path_only().endswith("favicon.svg"):
                    self.send_bytes(b"<svg xmlns='http://www.w3.org/2000/svg'/>", "image/svg+xml", head)
                else:
                    self.send_bytes(b"body{font-family:sans-serif}", "text/css", head)
                return
            if cfg.route_prefix:
                p = self.path_only()
                if p == cfg.route_prefix:
                    self.redirect(cfg.route_prefix + "/")
                    return
                if not p.startswith(cfg.route_prefix + "/"):
                    self.send_error_page(404, "Not Found", head)
                    return
            if single_file:
                if self.clean_path() not in ("/", "/" + root.name):
                    self.send_error_page(404, "Not Found", head)
                else:
                    self.serve_file(root, head)
                return
            fs = self.resolve_path()
            if (not fs or not fs.exists()) and cfg.pretty:
                alt = self.resolve_path(suffix=".html")
                if alt and alt.exists():
                    fs = alt
            if (not fs or not fs.exists()) and cfg.spa and cfg.index:
                idx = root / cfg.index
                if idx.exists():
                    fs = idx
            if not fs or not fs.exists():
                self.send_error_page(404, "Not Found", head)
                return
            if cfg.no_symlinks and fs.is_symlink():
                self.send_error_page(404, "Not Found", head)
                return
            if fs.is_dir():
                if not self.path_only().endswith("/"):
                    self.redirect(self.path_only() + "/")
                    return
                if cfg.index:
                    idx = fs / cfg.index
                    if idx.exists() and idx.is_file():
                        self.serve_file(idx, head)
                        return
                if cfg.disable_indexing:
                    self.send_error_page(404, "Not Found", head)
                    return
                self.serve_listing(fs, head)
            else:
                self.serve_file(fs, head)

        def path_only(self):
            return urllib.parse.urlsplit(self.path).path

        def clean_path(self):
            p = urllib.parse.unquote(self.path_only())
            if cfg.route_prefix and (p == cfg.route_prefix or p.startswith(cfg.route_prefix + "/")):
                p = p[len(cfg.route_prefix):] or "/"
            p = posixpath.normpath(p)
            if not p.startswith("/"):
                p = "/" + p
            return p

        def resolve_path(self, suffix=""):
            rel = self.clean_path().lstrip("/")
            if rel == "":
                target = root
            else:
                target = (root / rel).resolve()
            if suffix:
                target = Path(str(target) + suffix)
            try:
                target.resolve().relative_to(root)
            except ValueError:
                return None
            if not cfg.hidden and any(part.startswith(".") for part in target.relative_to(root).parts):
                return None
            return target

        def check_auth(self):
            if not cfg.auth:
                return True
            hdr = self.headers.get("Authorization", "")
            if not hdr.startswith("Basic "):
                self.auth_required()
                return False
            try:
                user, pw = base64.b64decode(hdr[6:]).decode("utf-8").split(":", 1)
            except Exception:
                self.auth_required()
                return False
            for entry in cfg.auth:
                parts = entry.split(":")
                if len(parts) >= 2 and parts[0] == user:
                    if len(parts) == 2 and parts[1] == pw:
                        return True
                    if len(parts) >= 3 and parts[1] in ("sha256", "sha512"):
                        digest = hashlib.new(parts[1], pw.encode()).hexdigest()
                        if digest == parts[2]:
                            return True
            self.auth_required()
            return False

        def auth_required(self):
            body = b"Authentication required"
            self.send_response(401)
            self.send_header("www-authenticate", 'Basic realm="miniserve"')
            self.send_common_headers(len(body), "text/plain")
            self.end_headers()
            self.wfile.write(body)

        def serve_file(self, fs, head=False):
            try:
                data_len = fs.stat().st_size
                start, end = 0, data_len - 1
                status = 200
                range_hdr = self.headers.get("Range")
                if range_hdr:
                    m = re.match(r"bytes=(\d*)-(\d*)", range_hdr)
                    if m:
                        if m.group(1) == "" and m.group(2):
                            n = int(m.group(2)); start = max(0, data_len - n)
                        else:
                            start = int(m.group(1) or 0)
                            end = int(m.group(2) or end)
                        end = min(end, data_len - 1)
                        status = 206
                length = max(0, end - start + 1) if data_len else 0
                ctype = mimetypes.guess_type(str(fs))[0] or "application/octet-stream"
                if ctype.startswith("text/") or ctype in ("application/javascript", "application/json", "image/svg+xml"):
                    ctype += "; charset=utf-8"
                self.send_response(status)
                self.send_header("content-length", str(length))
                self.send_header("etag", self.etag(fs))
                self.send_header("content-type", ctype)
                self.send_header("accept-ranges", "bytes")
                self.send_header("last-modified", email.utils.formatdate(fs.stat().st_mtime, usegmt=True))
                self.send_header("content-disposition", f'inline; filename="{fs.name}"')
                if status == 206:
                    self.send_header("content-range", f"bytes {start}-{end}/{data_len}")
                self.send_custom_headers()
                self.end_headers()
                if not head:
                    with open(fs, "rb") as f:
                        f.seek(start)
                        self.wfile.write(f.read(length))
            except OSError:
                self.send_error_page(404, "Not Found", head)

        def serve_listing(self, fs, head=False):
            entries = []
            for child in fs.iterdir():
                if not cfg.hidden and child.name.startswith("."):
                    continue
                if cfg.no_symlinks and child.is_symlink():
                    continue
                try:
                    st = child.stat()
                except OSError:
                    continue
                entries.append((child, st))
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            method = query.get("sort", [getattr(cfg, "sort", "name") or "name"])[0]
            order = query.get("order", [getattr(cfg, "order", "desc") or "desc"])[0]
            def key(item):
                child, st = item
                if method == "size":
                    return st.st_size
                if method == "date":
                    return st.st_mtime
                return natural_key(child.name.lower())
            entries.sort(key=key, reverse=(order == "desc"))
            if cfg.dirs_first:
                entries.sort(key=lambda it: not it[0].is_dir())
            title = cfg.title or self.headers.get("Host", "localhost")
            reltitle = self.clean_path()
            rows = []
            if self.clean_path() != "/":
                rows.append('<tr class="entry-type-directory"><td><p><a class="directory" href="../">../</a></p></td><td></td><td></td></tr>')
            for child, st in entries:
                name = child.name + ("/" if child.is_dir() else "")
                href = urllib.parse.quote(name)
                link = (cfg.external_url.rstrip("/") + self.path_only().rstrip("/") + "/" + href) if cfg.external_url and child.is_file() else href
                klass = "directory" if child.is_dir() else "file"
                etype = "directory" if child.is_dir() else "file"
                size = "" if child.is_dir() else fmt_size(st.st_size, cfg.size_display)
                date = datetime.fromtimestamp(st.st_mtime, timezone.utc).strftime("%Y-%m-%d %H:%M:%S +00:00 ")
                rows.append(f'<tr class="entry-type-{etype}"><td><p><a class="{klass}" href="{html.escape(link)}">{html.escape(name)}</a></p></td><td class="size-cell">{size}</td><td class="date-cell"><span>{date}</span></td></tr>')
            tools = []
            base = self.path_only().rstrip("/") or "/"
            if cfg.enable_tar:
                tools.append(f'<a href="{base}?download=tar">tar</a>')
            if cfg.enable_targz:
                tools.append(f'<a href="{base}?download=tar.gz">tar.gz</a>')
            if cfg.enable_zip:
                tools.append(f'<a href="{base}?download=zip">zip</a>')
            q = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            if "download" in q:
                self.serve_archive(fs, q["download"][0], head)
                return
            readme = ""
            if cfg.readme and (fs / "README.md").exists():
                readme = f"<pre>{html.escape((fs / 'README.md').read_text(errors='replace'))}</pre>"
            footer = "" if cfg.hide_footer else f'<div class="footer"><div class="version"><a href="https://github.com/svenstaro/miniserve">miniserve</a>/{VERSION}</div></div>'
            body = f'''<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="icon" type="image/svg+xml" href="{cfg.route_prefix}/__miniserve_internal/favicon.svg"><link rel="stylesheet" href="{cfg.route_prefix}/__miniserve_internal/style.css"><title>{html.escape(title)}</title></head><body><div class="container"><span id="top"></span><h1 class="title" dir="ltr"><span><bdi>{html.escape(title)}</bdi></span>{html.escape(reltitle)}</h1><div class="toolbar">{" ".join(tools)}</div><table><thead><th class="name"><a href="?sort=name&amp;order=asc">Name</a></th><th class="size"><a href="?sort=size&amp;order=asc">Size</a></th><th class="date"><a href="?sort=date&amp;order=asc">Last modification</a></th></thead><tbody>{''.join(rows)}</tbody></table>{readme}{footer}</div></body></html>'''.encode()
            self.send_bytes(body, "text/html; charset=utf-8", head)

        def serve_archive(self, fs, kind, head=False):
            buf = io.BytesIO()
            if kind == "zip" and cfg.enable_zip:
                with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                    for p in fs.rglob("*"):
                        if p.is_file():
                            zf.write(p, p.relative_to(fs))
                ctype, fname = "application/zip", fs.name + ".zip"
            elif kind == "tar.gz" and cfg.enable_targz:
                with tarfile.open(fileobj=buf, mode="w:gz") as tf:
                    tf.add(fs, arcname=fs.name)
                ctype, fname = "application/gzip", fs.name + ".tar.gz"
            elif kind == "tar" and cfg.enable_tar:
                with tarfile.open(fileobj=buf, mode="w") as tf:
                    tf.add(fs, arcname=fs.name)
                ctype, fname = "application/x-tar", fs.name + ".tar"
            else:
                self.send_error_page(404, "Not Found", head)
                return
            data = buf.getvalue()
            self.send_response(200)
            self.send_header("content-disposition", f'attachment; filename="{fname}"')
            self.send_common_headers(len(data), ctype)
            self.end_headers()
            if not head:
                self.wfile.write(data)

        def handle_upload(self):
            if not cfg.upload:
                self.send_error_page(403, "Forbidden")
                return
            length = int(self.headers.get("Content-Length", "0"))
            body = self.rfile.read(length)
            target_dir = root / (urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get("path", [cfg.upload or "/"])[0].strip("/"))
            target_dir.mkdir(parents=True, exist_ok=True)
            ctype = self.headers.get("Content-Type", "")
            saved = []
            if "multipart/form-data" in ctype:
                boundary = ctype.split("boundary=", 1)[-1].encode()
                for part in body.split(b"--" + boundary):
                    if b"filename=" not in part:
                        continue
                    head, _, data = part.partition(b"\r\n\r\n")
                    m = re.search(br'filename="([^"]*)"', head)
                    if not m:
                        continue
                    name = os.path.basename(m.group(1).decode("utf-8", "replace"))
                    data = data.rstrip(b"\r\n-")
                    dest = unique_dest(target_dir / name, cfg.on_duplicate)
                    if dest:
                        dest.write_bytes(data)
                        if cfg.chmod:
                            os.chmod(dest, int(cfg.chmod, 8))
                        saved.append(dest.name)
            else:
                dest = unique_dest(target_dir / "upload", cfg.on_duplicate)
                if dest:
                    dest.write_bytes(body); saved.append(dest.name)
            self.send_bytes(("Uploaded: " + ", ".join(saved)).encode(), "text/plain")

        def redirect(self, loc):
            self.send_response(308)
            self.send_header("location", loc)
            self.send_common_headers(0, "text/plain")
            self.end_headers()

        def send_error_page(self, code, message, head=False):
            body = f'<!DOCTYPE html><html><head><title>{code} {html.escape(message)}</title></head><body><h1>{code} {html.escape(message)}</h1></body></html>'.encode()
            self.send_response(code, message)
            self.send_common_headers(len(body), "text/html")
            self.end_headers()
            if not head:
                self.wfile.write(body)

        def send_bytes(self, body, ctype, head=False):
            self.send_response(200)
            self.send_common_headers(len(body), ctype)
            self.end_headers()
            if not head:
                self.wfile.write(body)

        def send_common_headers(self, length, ctype):
            self.send_header("content-length", str(length))
            self.send_header("content-type", ctype)
            self.send_custom_headers()

        def send_custom_headers(self):
            existing = set()
            for h in cfg.headers:
                if ":" in h:
                    k, v = h.split(":", 1)
                    if k.lower() not in existing:
                        self.send_header(k.strip(), v.strip())
                        existing.add(k.lower())

        def etag(self, fs):
            st = fs.stat()
            return f'"{st.st_ino:x}:{st.st_size:x}:{int(st.st_mtime):x}"'

    return Handler


def natural_key(s):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s)]


def fmt_size(n, mode):
    if mode == "exact":
        return str(n)
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    f = float(n)
    for u in units:
        if f < 1024 or u == units[-1]:
            return f"{int(f)} {u}" if u == "B" else f"{f:.1f} {u}"
        f /= 1024


def unique_dest(path, mode):
    if not path.exists() or mode == "overwrite":
        return path
    if mode == "error":
        return None
    stem, suffix = path.stem, path.suffix
    for i in range(1, 10000):
        cand = path.with_name(f"{stem}-{i}{suffix}")
        if not cand.exists():
            return cand
    return None


def main(argv=None):
    cfg = parse_args(sys.argv[1:] if argv is None else argv)
    root = Path(cfg.path).resolve()
    if not root.exists():
        print(f"Error: No such file or directory (os error 2): {root}", file=sys.stderr)
        return 1
    host = cfg.interfaces.split(",")[0] if cfg.interfaces else "::"
    if host in ("*", "0.0.0.0"):
        host = ""
    class V6Server(ThreadingHTTPServer):
        address_family = socket.AF_INET6 if host == "::" else socket.AF_INET
        daemon_threads = True
    try:
        httpd = V6Server((host, cfg.port), make_handler(cfg))
    except Exception as e:
        print(f"miniserve v{VERSION}", file=sys.stderr)
        print(f"Error: Failed to bind server to [{host}]:{cfg.port}", file=sys.stderr)
        print(f"caused by: {e}", file=sys.stderr)
        return 1
    print(f"miniserve v{VERSION}")
    print(f"Bound to [::]:{cfg.port}, 0.0.0.0:{cfg.port}")
    print(f"Serving path {root}")
    print("Available at (non-exhaustive list):")
    print(f"    http://127.0.0.1:{cfg.port}{cfg.route_prefix}")
    print(f"    http://[::1]:{cfg.port}{cfg.route_prefix}")
    print()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
