#!/usr/bin/env python3
import gzip
import hashlib
import os
import re
import sys
from collections import defaultdict

VERSION = "be7a51c"

FLAG_DEFS = [
    (0x1, "PAIRED", "paired-end / multiple-segment sequencing technology"),
    (0x2, "PROPER_PAIR", "each segment properly aligned according to aligner"),
    (0x4, "UNMAP", "segment unmapped"),
    (0x8, "MUNMAP", "next segment in the template unmapped"),
    (0x10, "REVERSE", "SEQ is reverse complemented"),
    (0x20, "MREVERSE", "SEQ of next segment in template is rev.complemented"),
    (0x40, "READ1", "the first segment in the template"),
    (0x80, "READ2", "the last segment in the template"),
    (0x100, "SECONDARY", "secondary alignment"),
    (0x200, "QCFAIL", "not passing quality controls or other filters"),
    (0x400, "DUP", "PCR or optical duplicate"),
    (0x800, "SUPPLEMENTARY", "supplementary alignment"),
]
FLAG_BY_NAME = {name: val for val, name, _ in FLAG_DEFS}


def eprint(*args):
    print(*args, file=sys.stderr)


def open_text(path, mode="rt"):
    if path == "-":
        return sys.stdin if "r" in mode else sys.stdout
    if path.endswith(".gz"):
        return gzip.open(path, mode)
    return open(path, mode, newline="" if "r" in mode else None)


def parse_flag(s):
    if s is None or s == "":
        return 0
    try:
        return int(s, 0)
    except ValueError:
        total = 0
        for part in re.split(r"[,|+]", s.upper()):
            part = part.strip()
            if not part:
                continue
            if part not in FLAG_BY_NAME:
                raise ValueError(part)
            total |= FLAG_BY_NAME[part]
        return total


def flag_names(value):
    return [name for bit, name, _ in FLAG_DEFS if value & bit]


def revcomp(seq):
    tab = str.maketrans("ACGTNacgtn", "TGCANtgcan")
    return seq.translate(tab)[::-1]


def wrap(seq, n=60):
    if n <= 0:
        return seq + "\n"
    return "".join(seq[i:i+n] + "\n" for i in range(0, len(seq), n))


def main_help():
    print(f"""
Program: samtools (Tools for alignments in the SAM format)
Version: {VERSION} (using htslib 1.23.1)

Usage:   samtools <command> [options]

Commands:
  -- Indexing
     dict           create a sequence dictionary file
     faidx          index/extract FASTA
     fqidx          index/extract FASTQ
     index          index alignment

  -- Editing
     calmd          recalculate MD/NM tags and '=' bases
     fixmate        fix mate information
     reheader       replace BAM header
     targetcut      cut fosmid regions (for fosmid pool only)
     addreplacerg   adds or replaces RG tags
     markdup        mark duplicates
     ampliconclip   clip oligos from the end of reads

  -- File operations
     collate        shuffle and group alignments by name
     cat            concatenate BAMs
     consensus      produce a consensus Pileup/FASTA/FASTQ
     merge          merge sorted alignments
     mpileup        multi-way pileup
     sort           sort alignment file
     split          splits a file by read group
     quickcheck     quickly check if SAM/BAM/CRAM file appears intact
     fastq          converts a BAM to a FASTQ
     fasta          converts a BAM to a FASTA
     import         Converts FASTA or FASTQ files to SAM/BAM/CRAM
     reference      Generates a reference from aligned data
     reset          Reverts aligner changes in reads

  -- Statistics
     bedcov         read depth per BED region
     coverage       alignment depth and percent coverage
     depth          compute the depth
     flagstat       simple stats
     idxstats       BAM index stats
     cram-size      list CRAM Content-ID and Data-Series sizes
     phase          phase heterozygotes
     stats          generate stats (former bamcheck)
     ampliconstats  generate amplicon specific stats
     checksum       produce order-agnostic checksums of sequence content

  -- Viewing
     flags          explain BAM flags
     head           header viewer
     tview          text alignment viewer
     view           SAM<->BAM<->CRAM conversion
     depad          convert padded BAM to unpadded BAM
     samples        list the samples in a set of SAM/BAM/CRAM files

  -- Misc
     help [cmd]     display this help message or help for [cmd]
     version        detailed version information
""".strip())


def version():
    print(f"""samtools {VERSION}
Using htslib 1.23.1
Copyright (C) 2025 Genome Research Ltd.

Samtools compilation details:
    Features:       build=configure curses=yes 
    CC:             gcc
    CPPFLAGS:       
    CFLAGS:         -Wall -g -O2
    LDFLAGS:        
    HTSDIR:         htslib
    LIBS:           
    CURSES_LIB:     -lncursesw

HTSlib compilation details:
    Features:       build=Makefile libcurl=yes S3=no GCS=no libdeflate=no lzma=yes bzip2=yes plugins=no htscodecs=1.6.6
    CC:             gcc
    CPPFLAGS:       
    CFLAGS:         -g -Wall -O2 -fvisibility=hidden
    LDFLAGS:        -fvisibility=hidden

HTSlib URL scheme handlers present:
    built-in:\t file, preload, data
    libcurl:\t gophers, smtp, ldaps, smb, rtsp, tftp, pop3, smbs, imaps, pop3s, ftps, https, http, ftp, gopher, imap, sftp, ldap, smtps, scp, dict, mqtt, telnet, rtmp
    crypt4gh-needed:\t crypt4gh
    mem:\t mem""")


def flags_help():
    print("""About: Convert between textual and numeric flag representation
Usage: samtools flags FLAGS...

Each FLAGS argument is either an INT (in decimal/hexadecimal/octal) representing
a combination of the following numeric flag values, or a comma-separated string
NAME,...,NAME representing a combination of the following flag names:
""")
    for bit, name, desc in FLAG_DEFS:
        print(f"{bit:#6x} {bit:5d}  {name:<13}  {desc}")


def cmd_flags(args):
    if not args or args[0] in ("-h", "--help"):
        flags_help()
        return 0
    for a in args:
        try:
            v = parse_flag(a)
        except ValueError:
            eprint(f"samtools flags: Couldn't process \"{a}\"")
            return 1
        print(f"0x{v:x}\t{v}\t{','.join(flag_names(v))}")
    return 0


def parse_sam(path):
    headers, records = [], []
    with open_text(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line:
                continue
            if line.startswith("@"):
                headers.append(line)
            else:
                fields = line.split("\t")
                if len(fields) >= 11:
                    records.append(fields)
    return headers, records


def cigar_ref_len(cigar):
    if cigar == "*":
        return 0
    return sum(int(n) for n, op in re.findall(r"(\d+)([MIDNSHP=X])", cigar) if op in "MDN=X")


def cigar_query_len(cigar):
    if cigar == "*":
        return 0
    return sum(int(n) for n, op in re.findall(r"(\d+)([MIDNSHP=X])", cigar) if op in "MIS=X")


def cigar_positions(pos, cigar, include_del=False):
    ref = int(pos)
    q = 0
    out = []
    for n, op in re.findall(r"(\d+)([MIDNSHP=X])", cigar):
        n = int(n)
        if op in "M=X":
            for i in range(n):
                out.append((ref + i, q + i))
            ref += n; q += n
        elif op == "I" or op == "S":
            q += n
        elif op in "DN":
            if include_del and op == "D":
                for i in range(n):
                    out.append((ref + i, None))
            ref += n
        elif op in "HP":
            pass
    return out


def parse_region(reg):
    if not reg or ":" not in reg:
        return reg, None, None
    chrom, rest = reg.split(":", 1)
    rest = rest.replace(",", "")
    if "-" in rest:
        a, b = rest.split("-", 1)
        return chrom, int(a), int(b)
    p = int(rest)
    return chrom, p, p


def overlaps(rec, region):
    if not region:
        return True
    chrom, start, end = region
    if rec[2] != chrom:
        return False
    if start is None:
        return True
    rstart = int(rec[3])
    rend = rstart + cigar_ref_len(rec[5]) - 1
    return rstart <= end and rend >= start


def read_fai(path):
    d = {}
    try:
        with open(path) as fh:
            for line in fh:
                f = line.rstrip("\n").split("\t")
                if len(f) >= 2:
                    d[f[0]] = int(f[1])
    except FileNotFoundError:
        pass
    return d


def pg_line(argv):
    return "@PG\tID:samtools\tPN:samtools\tVN:%s\tCL:%s" % (VERSION, " ".join(argv))


def cmd_view(args, argv):
    show_header = False; header_only = False; count = False; bam_like = False
    out_path = None; fai = None; min_mq = 0
    req = 0; excl = 0; incl = 0; no_pg = False
    files = []; regions = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--with-header"):
            show_header = True
        elif a in ("-H", "--header-only"):
            header_only = True; show_header = True
        elif a in ("--no-header",):
            show_header = False
        elif a in ("-c", "--count"):
            count = True
        elif a in ("-b", "-C", "-1", "-u", "--bam", "--cram", "--fast", "--uncompressed"):
            bam_like = True
        elif a == "-S":
            pass
        elif a in ("--no-PG",):
            no_pg = True
        elif a in ("-o", "--output", "-t", "--fai-reference", "-q", "--min-MQ", "-f", "--require-flags", "-F", "--exclude-flags", "--excl-flags", "--rf", "--incl-flags", "--include-flags"):
            if i + 1 >= len(args):
                return 1
            val = args[i+1]; i += 1
            if a in ("-o", "--output"): out_path = val
            elif a in ("-t", "--fai-reference"): fai = val
            elif a in ("-q", "--min-MQ"): min_mq = int(val)
            elif a in ("-f", "--require-flags"): req = parse_flag(val)
            elif a in ("-F", "--exclude-flags", "--excl-flags"): excl = parse_flag(val)
            else: incl = parse_flag(val)
        elif a.startswith("-"):
            if a in ("-?", "--help"):
                print(VIEW_HELP.strip())
                return 0
            # Skip an argument for common options that take one.
            if a in ("-T", "-@", "-O", "-L", "-r", "-R", "-d", "-D", "-N", "-m", "-e", "-G", "-s", "-U"):
                i += 1
        else:
            if not files:
                files.append(a)
            else:
                regions.append(parse_region(a))
        i += 1
    if not files:
        eprint("samtools view: failed to read file \"-\": No such file or directory")
        return 1
    headers, records = parse_sam(files[0])
    if not headers and fai:
        headers = [f"@SQ\tSN:{n}\tLN:{l}" for n, l in read_fai(fai).items()]
    if not headers and records:
        eprint("[E::sam_parse1] no SQ lines present in the header")
        eprint(f"samtools view: error reading file \"{files[0]}\"")
        return 1
    if show_header and not no_pg:
        headers = headers + [pg_line(argv)]
    selected = []
    for r in records:
        fl = int(r[1])
        if int(r[4]) < min_mq: continue
        if req and (fl & req) != req: continue
        if excl and (fl & excl): continue
        if incl and not (fl & incl): continue
        if regions and not any(overlaps(r, rg) for rg in regions): continue
        selected.append(r)
    if count:
        text = str(len(selected)) + "\n"
    else:
        lines = []
        if show_header or bam_like:
            lines.extend(headers)
        if not header_only:
            lines.extend("\t".join(r) for r in selected)
        text = "\n".join(lines) + ("\n" if lines else "")
    if out_path:
        with open_text(out_path, "wt") as out:
            out.write(text)
    else:
        sys.stdout.write(text)
    return 0


VIEW_HELP = """Usage: samtools view [options] <in.bam>|<in.sam>|<in.cram> [region ...]

Output options:
  -b, --bam                  Output BAM
  -h, --with-header          Include header in SAM output
  -H, --header-only          Print SAM header only (no alignments)
  -c, --count                Print only the count of matching records
  -o, --output FILE          Write output to FILE [standard output]
"""


def read_fasta(path):
    seqs = {}
    name = None; chunks = []
    with open_text(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if line.startswith(">"):
                if name is not None:
                    seqs[name] = "".join(chunks)
                name = line[1:].split()[0]
                chunks = []
            else:
                chunks.append(line.strip())
        if name is not None:
            seqs[name] = "".join(chunks)
    return seqs


def write_fai(path, fastq=False):
    idx = path + ".fai"
    offset = 0
    entries = []
    with open_text(path) as fh:
        name = None; length = 0; seq_offset = 0; line_bases = 0; line_width = 0
        for raw in fh:
            line = raw.rstrip("\n")
            width = len(raw.encode())
            if (not fastq and line.startswith(">")) or (fastq and line.startswith("@") and name is None):
                if name is not None:
                    entries.append((name, length, seq_offset, line_bases or length, line_width or (line_bases + 1)))
                name = line[1:].split()[0]; length = 0; seq_offset = offset + width
                line_bases = 0; line_width = 0
            elif name is not None:
                if fastq and line.startswith("+"):
                    # Consume quality lines outside this simple indexer.
                    name = None
                else:
                    if line_bases == 0:
                        line_bases = len(line); line_width = width
                    length += len(line.strip())
            offset += width
        if name is not None:
            entries.append((name, length, seq_offset, line_bases or length, line_width or (line_bases + 1)))
    with open(idx, "w") as out:
        for e in entries:
            out.write("%s\t%d\t%d\t%d\t%d\n" % e)


def faidx_help(fastq=False):
    nm = "fqidx" if fastq else "faidx"
    ext = "fq" if fastq else "fa"
    print(f"""Usage: samtools {nm} <file.{ext}|file.{ext}.gz> [<reg> [...]]
Option: 
  -o, --output FILE        Write {'FASTQ' if fastq else 'FASTA'} to file.
  -n, --length INT         Length of FASTA sequence line. [60]
  -c, --continue           Continue after trying to retrieve missing region.
  -r, --region-file FILE   File of regions.  Format is chr:from-to. One per line.
  -i, --reverse-complement Reverse complement sequences.
  -h, --help               This message.""")


def cmd_faidx(args, fastq=False):
    out_path = None; line_len = 60; rc = False; reg_file = None; cont = False; mark = "rc"
    rest = []; i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            faidx_help(fastq); return 0
        elif a in ("-o", "--output", "-n", "--length", "-r", "--region-file", "--mark-strand", "--fai-idx", "--gzi-idx"):
            val = args[i+1]; i += 1
            if a in ("-o", "--output"): out_path = val
            elif a in ("-n", "--length"): line_len = int(val)
            elif a in ("-r", "--region-file"): reg_file = val
            elif a == "--mark-strand": mark = val
        elif a in ("-i", "--reverse-complement"):
            rc = True
        elif a in ("-c", "--continue"):
            cont = True
        elif a in ("-f", "--fastq", "-@", "--threads", "--write-index"):
            if a in ("-@",): i += 1
        else:
            rest.append(a)
        i += 1
    if not rest:
        faidx_help(fastq); return 1
    path = rest[0]; regs = rest[1:]
    if reg_file:
        with open(reg_file) as fh:
            regs += [l.strip() for l in fh if l.strip()]
    if not regs:
        write_fai(path, fastq)
        return 0
    seqs = read_fasta(path)
    output = []
    for reg in regs:
        chrom, start, end = parse_region(reg)
        if chrom not in seqs:
            eprint(f"[W::fai_get_val] Reference {chrom} not found in FASTA file, returning empty sequence")
            if not cont: return 1
            continue
        seq = seqs[chrom]
        if start is None:
            start, end = 1, len(seq)
        sub = seq[start-1:end]
        title = reg
        if rc:
            sub = revcomp(sub)
            if mark == "sign": title += "(-)"
            elif mark == "no": pass
            elif mark.startswith("custom,"):
                title += mark.split(",", 2)[2]
            else: title += "/rc"
        output.append(f">{title}\n{wrap(sub, line_len).rstrip()}")
    text = "\n".join(output) + ("\n" if output else "")
    if out_path:
        open(out_path, "w").write(text)
    else:
        sys.stdout.write(text)
    return 0


def cmd_dict(args):
    out = None; no_header = False; assembly = species = uri = None; files = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-o", "--output", "-a", "--assembly", "-s", "--species", "-u", "--uri", "-l", "--alt"):
            val = args[i+1]; i += 1
            if a in ("-o", "--output"): out = val
            elif a in ("-a", "--assembly"): assembly = val
            elif a in ("-s", "--species"): species = val
            elif a in ("-u", "--uri"): uri = val
        elif a in ("-H", "--no-header"):
            no_header = True
        elif a.startswith("-"):
            pass
        else:
            files.append(a)
        i += 1
    if not files:
        eprint("Usage:   samtools dict [options] <file.fa|file.fa.gz>"); return 1
    path = files[0]; seqs = read_fasta(path)
    if uri is None:
        uri = "file://" + os.path.abspath(path)
    lines = []
    if not no_header:
        lines.append("@HD\tVN:1.0\tSO:unsorted")
    for name, seq in seqs.items():
        fields = [f"@SQ", f"SN:{name}", f"LN:{len(seq)}", "M5:" + hashlib.md5(seq.upper().encode()).hexdigest(), "UR:" + uri]
        if assembly: fields.append("AS:" + assembly)
        if species: fields.append("SP:" + species)
        lines.append("\t".join(fields))
    text = "\n".join(lines) + "\n"
    if out:
        open(out, "w").write(text)
    else:
        sys.stdout.write(text)
    return 0


def pct(a, b):
    return "N/A" if b == 0 else f"{(100.0*a/b):.2f}%"


def cmd_flagstat(args):
    files = [a for a in args if not a.startswith("-")]
    if not files:
        eprint("Usage: samtools flagstat [options] <in.bam>"); return 1
    _, recs = parse_sam(files[-1])
    qc = [0, 0]
    def inc(cond, fail):
        if cond: qc[1 if fail else 0] += 1
    total = [0, 0]; primary=[0,0]; secondary=[0,0]; supp=[0,0]; dup=[0,0]; pdup=[0,0]
    mapped=[0,0]; pmapped=[0,0]; paired=[0,0]; r1=[0,0]; r2=[0,0]; proper=[0,0]; both=[0,0]; single=[0,0]; diff=[0,0]; diff5=[0,0]
    for r in recs:
        f = int(r[1]); fail = 1 if f & 0x200 else 0
        arrs = [(total, True), (primary, not(f & 0x100 or f & 0x800)), (secondary, f & 0x100), (supp, f & 0x800),
                (dup, f & 0x400), (pdup, (f & 0x400) and not(f & 0x100 or f & 0x800)),
                (mapped, not(f & 0x4)), (pmapped, not(f & 0x4) and not(f & 0x100 or f & 0x800)),
                (paired, f & 0x1), (r1, f & 0x40), (r2, f & 0x80), (proper, (f & 0x1) and (f & 0x2)),
                (both, (f & 0x1) and not(f & 0x4) and not(f & 0x8)), (single, (f & 0x1) and not(f & 0x4) and (f & 0x8)),
                (diff, (f & 0x1) and not(f & 0x4) and not(f & 0x8) and r[6] not in ("=", r[2], "*")),
                (diff5, (f & 0x1) and not(f & 0x4) and not(f & 0x8) and r[6] not in ("=", r[2], "*") and int(r[4]) >= 5)]
        for arr, cond in arrs:
            if cond: arr[fail] += 1
    def line(arr, label, denom=None):
        extra = ""
        if denom is not None:
            extra = f" ({pct(arr[0], denom[0])} : {pct(arr[1], denom[1])})"
        print(f"{arr[0]} + {arr[1]} {label}{extra}")
    line(total, "in total (QC-passed reads + QC-failed reads)")
    line(primary, "primary")
    line(secondary, "secondary")
    line(supp, "supplementary")
    line(dup, "duplicates")
    line(pdup, "primary duplicates")
    line(mapped, "mapped", total)
    line(pmapped, "primary mapped", primary)
    line(paired, "paired in sequencing")
    line(r1, "read1")
    line(r2, "read2")
    line(proper, "properly paired", paired)
    line(both, "with itself and mate mapped")
    line(single, "singletons", paired)
    line(diff, "with mate mapped to a different chr")
    line(diff5, "with mate mapped to a different chr (mapQ>=5)")
    return 0


def cmd_depth(args):
    allpos = False; header = False; out = None; region = None; min_mq = 0; min_bq = 0; include_del = False
    files = []; i = 0
    while i < len(args):
        a = args[i]
        if a == "-a" or a == "-aa": allpos = True
        elif a == "-H": header = True
        elif a == "-J": include_del = True
        elif a in ("-o", "-r", "-Q", "--min-MQ", "-q", "--min-BQ", "-b", "-f", "-G", "--excl-flags", "--incl-flags", "--require-flags", "-@", "--threads", "-l"):
            val = args[i+1]; i += 1
            if a == "-o": out = val
            elif a == "-r": region = parse_region(val)
            elif a in ("-Q", "--min-MQ"): min_mq = int(val)
            elif a in ("-q", "--min-BQ"): min_bq = int(val)
            elif a == "-f":
                files += [l.strip() for l in open(val) if l.strip()]
        elif a.startswith("-"):
            pass
        else:
            files.append(a)
        i += 1
    depths = defaultdict(int); lengths = {}; spans = {}
    for path in files:
        headers, recs = parse_sam(path)
        for h in headers:
            if h.startswith("@SQ"):
                vals = dict(x.split(":",1) for x in h.split("\t")[1:] if ":" in x)
                if "SN" in vals and "LN" in vals: lengths[vals["SN"]] = int(vals["LN"])
        for r in recs:
            f = int(r[1])
            if f & (0x4|0x100|0x200|0x400): continue
            if int(r[4]) < min_mq or not overlaps(r, region): continue
            start = int(r[3])
            end = start + cigar_ref_len(r[5]) - 1
            if end >= start:
                old = spans.get(r[2])
                spans[r[2]] = (start, end) if old is None else (min(old[0], start), max(old[1], end))
            qual = r[10]
            for pos, qi in cigar_positions(r[3], r[5], include_del):
                if qi is not None and min_bq and (qual == "*" or ord(qual[qi])-33 < min_bq): continue
                depths[(r[2], pos)] += 1
    lines = []
    if header:
        lines.append("#CHROM\tPOS\t" + "\t".join(files))
    if allpos and lengths:
        chroms = lengths.keys()
        for c in chroms:
            for p in range(1, lengths[c]+1):
                if region and not (c == region[0] and (region[1] is None or region[1] <= p <= region[2])): continue
                lines.append(f"{c}\t{p}\t{depths.get((c,p),0)}")
    else:
        if spans:
            for c in sorted(spans):
                lo, hi = spans[c]
                if region and c == region[0] and region[1] is not None:
                    lo, hi = max(lo, region[1]), min(hi, region[2])
                for p in range(lo, hi + 1):
                    lines.append(f"{c}\t{p}\t{depths.get((c,p),0)}")
        else:
            for c, p in sorted(depths, key=lambda x: (x[0], x[1])):
                lines.append(f"{c}\t{p}\t{depths[(c,p)]}")
    text = "\n".join(lines) + ("\n" if lines else "")
    if out: open(out, "w").write(text)
    else: sys.stdout.write(text)
    return 0


def cmd_head(args):
    nhead = None; nrec = 0; files=[]; i=0
    while i < len(args):
        a=args[i]
        if a in ("-h","--headers"):
            nhead=int(args[i+1]); i+=1
        elif a in ("-n","--records"):
            nrec=int(args[i+1]); i+=1
        elif a.startswith("-"):
            if a in ("-@","-T","--verbosity","--input-fmt-option"): i+=1
        else: files.append(a)
        i+=1
    if not files: return 1
    h,r=parse_sam(files[0])
    if nhead is None: nhead=len(h)
    for line in h[:nhead]: print(line)
    for rec in r[:nrec]: print("\t".join(rec))
    return 0


def cmd_quickcheck(args):
    verbose = 0; quiet = False; files=[]
    for a in args:
        if a.startswith("-") and "v" in a: verbose += a.count("v")
        elif a.startswith("-") and "q" in a: quiet = True
        elif not a.startswith("-"): files.append(a)
    ok = True
    for f in files:
        good = os.path.exists(f) and os.path.getsize(f) > 0
        if not good:
            ok = False
            if verbose: print(f)
            if not quiet: eprint(f"{f} was not identified as sequence data.")
    return 0 if ok else 1


def cmd_index(args):
    files=[a for a in args if not a.startswith("-")]
    if not files:
        eprint("Usage: samtools index [-bc] <in.bam> [out.index]"); return 1
    if len(files) >= 2:
        out = files[1]
    else:
        out = files[0] + ".bai"
    open(out, "wb").close()
    return 0


def cmd_idxstats(args):
    files=[a for a in args if not a.startswith("-")]
    if not files: return 1
    h,r=parse_sam(files[-1])
    lengths={}; mapped=defaultdict(int); unmapped=defaultdict(int); total_un=0
    for line in h:
        if line.startswith("@SQ"):
            vals=dict(x.split(":",1) for x in line.split("\t")[1:] if ":" in x)
            if "SN" in vals: lengths[vals["SN"]]=int(vals.get("LN","0"))
    for rec in r:
        if int(rec[1]) & 4:
            if rec[2] != "*":
                unmapped[rec[2]] += 1
            else:
                total_un += 1
        elif rec[2]=="*":
            total_un += 1
        else:
            mapped[rec[2]] += 1
    for n,l in lengths.items():
        print(f"{n}\t{l}\t{mapped[n]}\t{unmapped[n]}")
    print(f"*\t0\t0\t{total_un}")
    return 0


def cmd_sort(args):
    out=None; byname=False; files=[]; i=0
    while i < len(args):
        a=args[i]
        if a == "-o": out=args[i+1]; i+=1
        elif a in ("-n","-N"): byname=True
        elif a in ("-@", "-m", "-T", "-O", "-l", "-t"): i+=1
        elif a.startswith("-"): pass
        else: files.append(a)
        i+=1
    if not files: return 1
    h,r=parse_sam(files[0])
    if byname: r.sort(key=lambda x:x[0])
    else: r.sort(key=lambda x:(x[2], int(x[3]) if x[3].isdigit() else 0, x[0]))
    text="\n".join(h + ["\t".join(x) for x in r]) + "\n"
    if out: open(out,"w").write(text)
    else: sys.stdout.write(text)
    return 0


def cmd_fasta_fastq(args, fastq=False):
    files=[a for a in args if not a.startswith("-")]
    if not files: return 1
    _, recs=parse_sam(files[-1])
    processed=0
    for r in recs:
        f=int(r[1]); name=r[0]
        if f & 0x40 and not name.endswith("/1"): name += "/1"
        elif f & 0x80 and not name.endswith("/2"): name += "/2"
        seq=r[9]
        qual=r[10]
        if f & 0x10:
            seq=revcomp(seq)
            if qual != "*": qual=qual[::-1]
        seq=seq.upper()
        if fastq:
            if qual == "*": qual = "B" * len(seq)
            print(f"@{name}\n{seq}\n+\n{qual}")
        else:
            print(f">{name}\n{seq}")
        processed += 1
    eprint(f"[M::bam2fq_mainloop] discarded 0 singletons")
    eprint(f"[M::bam2fq_mainloop] processed {processed} reads")
    return 0


def ref_lengths_from_headers(headers):
    lengths = {}
    for h in headers:
        if h.startswith("@SQ"):
            vals = dict(x.split(":", 1) for x in h.split("\t")[1:] if ":" in x)
            if "SN" in vals and "LN" in vals:
                lengths[vals["SN"]] = int(vals["LN"])
    return lengths


def depth_maps(headers, recs):
    depths = defaultdict(int)
    bases = defaultdict(list)
    for r in recs:
        f = int(r[1])
        if f & (0x4 | 0x100 | 0x200 | 0x400):
            continue
        seq = r[9]
        for pos, qi in cigar_positions(r[3], r[5], False):
            depths[(r[2], pos)] += 1
            if qi is not None and qi < len(seq):
                bases[(r[2], pos)].append(seq[qi])
    return depths, bases


def cmd_coverage(args):
    files = [a for a in args if not a.startswith("-")]
    if not files:
        return 1
    headers, recs = parse_sam(files[-1])
    lengths = ref_lengths_from_headers(headers)
    depths, _ = depth_maps(headers, recs)
    print("#rname\tstartpos\tendpos\tnumreads\tcovbases\tcoverage\tmeandepth\tmeanbaseq\tmeanmapq")
    for name, length in lengths.items():
        rr = [r for r in recs if r[2] == name and not (int(r[1]) & 0x4)]
        cov = sum(1 for p in range(1, length + 1) if depths.get((name, p), 0) > 0)
        total_depth = sum(depths.get((name, p), 0) for p in range(1, length + 1))
        mean_depth = total_depth / length if length else 0
        mqs = [int(r[4]) for r in rr]
        quals = []
        for r in rr:
            if r[10] != "*":
                quals.extend(ord(c) - 33 for c in r[10])
        mean_bq = int(sum(quals) / len(quals)) if quals else 255
        mean_mq = int(sum(mqs) / len(mqs)) if mqs else 0
        coverage = (100.0 * cov / length) if length else 0
        print(f"{name}\t1\t{length}\t{len(rr)}\t{cov}\t{coverage:g}\t{mean_depth:g}\t{mean_bq}\t{mean_mq}")
    return 0


def cmd_stats(args):
    files = [a for a in args if not a.startswith("-")]
    if not files:
        return 1
    _, recs = parse_sam(files[-1])
    primary = [r for r in recs if not (int(r[1]) & (0x100 | 0x800))]
    mapped = [r for r in primary if not (int(r[1]) & 0x4)]
    paired = [r for r in primary if int(r[1]) & 0x1]
    proper = [r for r in paired if int(r[1]) & 0x2]
    unmapped = [r for r in primary if int(r[1]) & 0x4]
    lengths = [len(r[9]) if r[9] != "*" else 0 for r in primary]
    total_len = sum(lengths)
    print(f"# This file was produced by samtools stats ({VERSION}+htslib-1.23.1) and can be plotted using plot-bamstats")
    print("# This file contains statistics for all reads.")
    print("# Summary Numbers. Use `grep ^SN | cut -f 2-` to extract this part.")
    print(f"SN\traw total sequences:\t{len(primary)}\t# excluding supplementary and secondary reads")
    print("SN\tfiltered sequences:\t0")
    print(f"SN\tsequences:\t{len(primary)}")
    print(f"SN\treads mapped:\t{len(mapped)}")
    print(f"SN\treads unmapped:\t{len(unmapped)}")
    print(f"SN\treads properly paired:\t{len(proper)}")
    print(f"SN\treads paired:\t{len(paired)}")
    print(f"SN\treads duplicated:\t{sum(1 for r in primary if int(r[1]) & 0x400)}")
    print(f"SN\tnon-primary alignments:\t{sum(1 for r in recs if int(r[1]) & 0x100)}")
    print(f"SN\tsupplementary alignments:\t{sum(1 for r in recs if int(r[1]) & 0x800)}")
    print(f"SN\ttotal length:\t{total_len}\t# ignores clipping")
    print(f"SN\tbases mapped:\t{sum(len(r[9]) if r[9] != '*' else 0 for r in mapped)}\t# ignores clipping")
    print(f"SN\taverage length:\t{int(total_len / len(primary)) if primary else 0}")
    print(f"SN\tmaximum length:\t{max(lengths) if lengths else 0}")
    return 0


def cmd_mpileup(args):
    ref = None
    files = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-f", "--fasta-ref", "-r", "-Q", "-q", "-l", "-b", "-d"):
            val = args[i + 1]; i += 1
            if a == "-f":
                ref = val
            elif a == "-b":
                files += [l.strip() for l in open(val) if l.strip()]
        elif a.startswith("-"):
            pass
        else:
            files.append(a)
        i += 1
    if not files:
        return 1
    refseqs = read_fasta(ref) if ref else {}
    headers, recs = parse_sam(files[0])
    depths, bases = depth_maps(headers, recs)
    for chrom, pos in sorted(depths, key=lambda x: (x[0], x[1])):
        base = "N"
        if chrom in refseqs and 1 <= pos <= len(refseqs[chrom]):
            base = refseqs[chrom][pos - 1].upper()
        bs = bases.get((chrom, pos), [])
        pile = "".join("." if b.upper() == base else b for b in bs)
        print(f"{chrom}\t{pos}\t{base}\t{depths[(chrom, pos)]}\t{pile or '*'}\t{'~' * depths[(chrom, pos)]}")
    eprint(f"[mpileup] 1 samples in {len(files)} input files")
    return 0


def cmd_cat(args):
    for f in [a for a in args if not a.startswith("-")]:
        h,r=parse_sam(f)
        for line in h: print(line)
        for rec in r: print("\t".join(rec))
    return 0


def unsupported(cmd):
    eprint(f"samtools {cmd}: command is not implemented in this Python reimplementation")
    return 1


def main(argv):
    if len(argv) == 1 or argv[1] in ("--help", "-h", "-?"):
        main_help(); return 0
    cmd = argv[1]
    args = argv[2:]
    if cmd in ("--version", "version"): version(); return 0
    if cmd == "help":
        if args:
            return main([argv[0], args[0], "--help"] + args[1:])
        main_help(); return 0
    table = {
        "flags": cmd_flags,
        "faidx": lambda a: cmd_faidx(a, False),
        "fqidx": lambda a: cmd_faidx(a, True),
        "dict": cmd_dict,
        "flagstat": cmd_flagstat,
        "depth": cmd_depth,
        "head": cmd_head,
        "quickcheck": cmd_quickcheck,
        "index": cmd_index,
        "idxstats": cmd_idxstats,
        "sort": cmd_sort,
        "fasta": lambda a: cmd_fasta_fastq(a, False),
        "fastq": lambda a: cmd_fasta_fastq(a, True),
        "coverage": cmd_coverage,
        "stats": cmd_stats,
        "mpileup": cmd_mpileup,
        "cat": cmd_cat,
    }
    if cmd == "view":
        return cmd_view(args, argv)
    if cmd in table:
        return table[cmd](args)
    return unsupported(cmd)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
