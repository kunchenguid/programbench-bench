#!/usr/bin/env python3
import json
import os
import shutil
import struct
import sys
from pathlib import Path

VERSION = "GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20"

WARNING = """WARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.
The project reserves the right to modify, rename, reorganize, and change the behavior of the utility
until it is officially frozen in a future feature release of GDAL."""

MAIN_HELP = """Usage: gdal <COMMAND> [OPTIONS]
where <COMMAND> is one of:
  - convert:  Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').
  - dataset:  Commands to manage datasets.
  - driver:   Command for driver specific operations.
  - info:     Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').
  - mdim:     Multidimensional commands.
  - pipeline: Process a dataset applying several steps.
  - raster:   Raster commands.
  - vector:   Vector commands.
  - vsi:      GDAL Virtual System Interface (VSI) commands.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --version               Display GDAL version and exit
  --drivers               Display driver list as JSON document

'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.
And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.

For more details, consult https://gdal.org/programs/index.html

""" + WARNING

HELP = {
    ("info",): """Usage: gdal info [OPTIONS] <INPUT>

Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input raster, vector or multidimensional raster dataset [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text

For all options, run 'gdal raster info --help' or 'gdal vector info --help'

For more details, consult https://gdal.org/programs/gdal_info.html

""" + WARNING,
    ("raster",): """Usage: gdal raster <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - convert:         Convert a raster dataset.
  - create:          Create a new raster dataset.
  - info:            Return information on a raster dataset.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display raster driver list as JSON document

For more details, consult https://gdal.org/programs/gdal_raster.html

""" + WARNING,
    ("vector",): """Usage: gdal vector <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - convert:             Convert a vector dataset.
  - create:              Create a vector dataset.
  - info:                Return information on a vector dataset.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display vector driver list as JSON document and exit

For more details, consult https://gdal.org/programs/gdal_vector.html

""" + WARNING,
    ("dataset",): """Usage: gdal dataset <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - check:    Check whether there are errors when reading the content of a dataset.
  - copy:     Copy files of a dataset. (alias: cp)
  - delete:   Delete dataset(s). (alias: rm, remove)
  - identify: Identify driver opening dataset(s).
  - rename:   Rename files of a dataset. (alias: ren, mv)

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_dataset.html

""" + WARNING,
    ("vsi",): """Usage: gdal vsi <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - copy:   Copy files located on GDAL Virtual System Interface (VSI). (alias: cp)
  - delete: Delete files located on GDAL Virtual System Interface (VSI). (alias: rm, rmdir, del)
  - list:   List files of one of the GDAL Virtual System Interface (VSI). (alias: ls)
  - move:   Move/rename a file/directory located on GDAL Virtual System Interface (VSI). (alias: mv, ren, rename)
  - sozip:  Seek-optimized ZIP (SOZIP) commands.
  - sync:   Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI).

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_vsi.html

""" + WARNING,
    ("raster", "info"): """Usage: gdal raster info [OPTIONS] <INPUT>

Return information on a raster dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input raster dataset [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  --mm, --min-max                                      Compute minimum and maximum value
  --stats                                              Retrieve or compute statistics, using all pixels
  --approx-stats                                       Retrieve or compute statistics, using a subset of pixels
  --hist                                               Retrieve or compute histogram

For more details, consult https://gdal.org/programs/gdal_raster_info.html

""" + WARNING,
    ("vector", "info"): """Usage: gdal vector info [OPTIONS] <INPUT>...

Return information on a vector dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input vector datasets [may be repeated] [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name [may be repeated]
  --features                                           List all features (beware of RAM consumption on large layers)
  --summary                                            List the layer names and the geometry type

For more details, consult https://gdal.org/programs/gdal_vector_info.html

""" + WARNING,
    ("raster", "create"): """Usage: gdal raster create [OPTIONS] <OUTPUT>

Create a new raster dataset.

Positional arguments:
  -o, --output <OUTPUT>                                    Output raster dataset [required]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>      Output format ("GDALG" allowed)
  --overwrite                                              Whether overwriting existing output dataset is allowed
  --size <width>,<height>                                  Output size in pixels
  --band-count <BAND-COUNT>                                Number of bands (default: 1)
  --ot, --datatype, --output-data-type <OUTPUT-DATA-TYPE>  Output data type. (default: Byte)
  --burn <BURN>                                            Burn value [may be repeated]

For more details, consult https://gdal.org/programs/gdal_raster_create.html

""" + WARNING,
}

DRIVERS = [
    {"short_name": "GTiff", "long_name": "GeoTIFF", "scopes": ["raster"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["tif", "tiff"]},
    {"short_name": "COG", "long_name": "Cloud optimized GeoTIFF generator", "scopes": ["raster"], "capabilities": ["create", "create_copy", "virtual_io"], "file_extensions": ["tif", "tiff"]},
    {"short_name": "VRT", "long_name": "Virtual Raster", "scopes": ["raster", "multidimensional_raster"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["vrt"]},
    {"short_name": "MEM", "long_name": "In Memory raster, vector and multidimensional raster", "scopes": ["raster", "multidimensional_raster", "vector"], "capabilities": ["open", "create"]},
    {"short_name": "GeoJSON", "long_name": "GeoJSON", "scopes": ["vector"], "capabilities": ["open", "create", "create_copy", "virtual_io"], "file_extensions": ["json", "geojson"]},
    {"short_name": "ESRI Shapefile", "long_name": "ESRI Shapefile", "scopes": ["vector"], "capabilities": ["open", "create", "create_copy", "virtual_io"], "file_extensions": ["shp"]},
    {"short_name": "GPKG", "long_name": "GeoPackage", "scopes": ["raster", "vector"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["gpkg"]},
    {"short_name": "CSV", "long_name": "Comma Separated Value (.csv)", "scopes": ["vector"], "capabilities": ["open", "create", "create_copy", "virtual_io"], "file_extensions": ["csv"]},
]


def eprint(s):
    print(s, file=sys.stderr)


def show_help(key=()):
    print(HELP.get(tuple(key), MAIN_HELP))


def json_usage(name="gdal", desc="Main gdal entry point."):
    print(json.dumps({"description": desc, "short_url": "/programs/index.html", "url": "https://gdal.org/programs/index.html", "name": name}, indent=2, separators=(",", ":")))


def print_json(obj):
    print(json.dumps(obj, indent=2, separators=(",", ":")))


def strip_global(args):
    out = []
    i = 0
    while i < len(args):
        if args[i] == "--config":
            i += 2
        elif args[i].startswith("--config="):
            i += 1
        else:
            out.append(args[i])
            i += 1
    return out


def option_value(args, names, default=None):
    for i, a in enumerate(args):
        if a in names and i + 1 < len(args):
            return args[i + 1]
        for n in names:
            if a.startswith(n + "="):
                return a.split("=", 1)[1]
    return default


def positional(args):
    vals = []
    skip = False
    value_opts = {
        "-f", "--of", "--format", "--output-format", "-i", "--input", "--dataset",
        "-o", "--output", "--size", "--band-count", "--ot", "--datatype",
        "--output-data-type", "--burn", "--co", "--creation-option", "--oo",
        "--open-option", "-l", "--layer", "--input-layer", "--filename",
        "--source", "--destination", "--depth", "--full-check"
    }
    for i, a in enumerate(args):
        if skip:
            skip = False
            continue
        if a in value_opts:
            skip = True
            continue
        if a.startswith("-"):
            continue
        vals.append(a)
    return vals


def driver_for(path):
    p = str(path)
    ext = Path(p).suffix.lower()
    try:
        with open(p, "rb") as f:
            head = f.read(16)
    except OSError:
        return None
    if head[:4] in (b"II*\x00", b"MM\x00*"):
        return "GTiff"
    if ext in (".json", ".geojson"):
        try:
            with open(p, "r", encoding="utf-8") as f:
                obj = json.load(f)
            if isinstance(obj, dict) and obj.get("type") in ("FeatureCollection", "Feature", "GeometryCollection", "Point", "LineString", "Polygon", "MultiPoint", "MultiLineString", "MultiPolygon"):
                return "GeoJSON"
        except Exception:
            pass
    if ext == ".csv":
        return "CSV"
    if ext == ".gpkg":
        return "GPKG"
    if ext == ".shp":
        return "ESRI Shapefile"
    return None


def parse_tiff(path):
    with open(path, "rb") as f:
        data = f.read()
    if data[:2] == b"II":
        endian = "<"
    elif data[:2] == b"MM":
        endian = ">"
    else:
        raise ValueError("not tiff")
    magic = struct.unpack(endian + "H", data[2:4])[0]
    if magic != 42:
        raise ValueError("not classic tiff")
    off = struct.unpack(endian + "I", data[4:8])[0]
    n = struct.unpack(endian + "H", data[off:off + 2])[0]
    tags = {}
    pos = off + 2
    for _ in range(n):
        tag, typ, cnt, val = struct.unpack(endian + "HHII", data[pos:pos + 12])
        tags[tag] = (typ, cnt, val)
        pos += 12
    return {"width": int(tags.get(256, (0, 0, 0))[2]), "height": int(tags.get(257, (0, 0, 0))[2]), "bands": int(tags.get(277, (0, 0, 1))[2] or 1)}


def write_tiff(path, width, height, bands=1, burn=0):
    samples = max(1, bands)
    pixels = bytes([int(float(burn)) & 255]) * width * height * samples
    entries = [
        (256, 4, 1, width), (257, 4, 1, height), (258, 3, 1, 8),
        (259, 3, 1, 1), (262, 3, 1, 1 if samples == 1 else 2),
        (273, 4, 1, 8), (277, 3, 1, samples), (278, 4, 1, height),
        (279, 4, 1, len(pixels)), (284, 3, 1, 1),
    ]
    ifd_off = 8 + len(pixels)
    blob = bytearray()
    blob += b"II*\x00" + struct.pack("<I", ifd_off)
    blob += pixels
    blob += struct.pack("<H", len(entries))
    for e in entries:
        blob += struct.pack("<HHII", *e)
    blob += struct.pack("<I", 0)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        f.write(blob)


def geojson_info(path):
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    features = obj.get("features", []) if obj.get("type") == "FeatureCollection" else ([obj] if obj.get("type") == "Feature" else [])
    coords = []
    gtypes = []
    fields = {}
    def walk(c):
        if isinstance(c, list) and c and isinstance(c[0], (int, float)):
            coords.append((float(c[0]), float(c[1])))
        elif isinstance(c, list):
            for x in c:
                walk(x)
    for feat in features:
        geom = feat.get("geometry") or {}
        if geom.get("type"):
            gtypes.append(geom.get("type"))
        walk(geom.get("coordinates"))
        for k, v in (feat.get("properties") or {}).items():
            if isinstance(v, bool):
                t = "Integer"
            elif isinstance(v, int):
                t = "Integer"
            elif isinstance(v, float):
                t = "Real"
            else:
                t = "String"
            fields.setdefault(k, t)
    xs = [c[0] for c in coords]
    ys = [c[1] for c in coords]
    extent = [min(xs), min(ys), max(xs), max(ys)] if coords else None
    name = Path(path).stem
    gtype = gtypes[0] if gtypes and all(g == gtypes[0] for g in gtypes) else ("Unknown" if not gtypes else "GeometryCollection")
    return name, gtype, len(features), extent, fields


def raster_json(path):
    info = parse_tiff(path)
    w, h, b = info["width"], info["height"], info["bands"]
    return {
        "description": str(path), "driverShortName": "GTiff", "driverLongName": "GeoTIFF",
        "files": [str(path)], "size": [w, h], "metadata": {"IMAGE_STRUCTURE": {"INTERLEAVE": "BAND"}},
        "cornerCoordinates": {"upperLeft": [0.0, 0.0], "lowerLeft": [0.0, float(h)], "lowerRight": [float(w), float(h)], "upperRight": [float(w), 0.0], "center": [w / 2.0, h / 2.0]},
        "bands": [{"band": i + 1, "block": [w, h], "type": "Byte", "colorInterpretation": "Gray" if i == 0 else "Undefined", "metadata": {}} for i in range(b)],
        "stac": {"proj:shape": [h, w], "raster:bands": [{"data_type": "uint8"} for _ in range(b)]},
    }


def cmd_raster_info(args):
    fmt = option_value(args, ["-f", "--of", "--format", "--output-format"], "text")
    vals = positional(args)
    path = option_value(args, ["-i", "--input", "--dataset"]) or (vals[-1] if vals else None)
    if not path or driver_for(path) != "GTiff":
        eprint(f"ERROR 4: `{path or ''}' not recognized as being in a supported file format.")
        eprint("Usage: gdal raster info [OPTIONS] <INPUT>")
        eprint("Try 'gdal raster info --help' for help.")
        return 1
    obj = raster_json(path)
    if fmt == "json":
        print_json(obj)
    else:
        w, h = obj["size"]
        print("Driver: GTiff/GeoTIFF")
        print(f"Files: {path}")
        print(f"Size is {w}, {h}")
        print("Image Structure Metadata:")
        print("  INTERLEAVE=BAND")
        print("Corner Coordinates:")
        print("Upper Left  (    0.0,    0.0)")
        print(f"Lower Left  (    0.0,    {float(h):.1f})")
        print(f"Upper Right (    {float(w):.1f},    0.0)")
        print(f"Lower Right (    {float(w):.1f},    {float(h):.1f})")
        print(f"Center      (    {w/2.0:.1f},    {h/2.0:.1f})")
        for band in obj["bands"]:
            print(f"Band {band['band']} Block={w}x{h} Type=Byte, ColorInterp={band['colorInterpretation']}")
    return 0


def cmd_vector_info(args):
    fmt = option_value(args, ["-f", "--of", "--format", "--output-format"], "text")
    vals = positional(args)
    path = option_value(args, ["-i", "--input", "--dataset"]) or (vals[-1] if vals else None)
    if not path or driver_for(path) != "GeoJSON":
        eprint(f"ERROR 4: `{path or ''}' not recognized as being in a supported file format.")
        eprint("Usage: gdal vector info [OPTIONS] <INPUT>")
        eprint("Try 'gdal vector info --help' for help.")
        return 1
    name, gtype, count, extent, fields = geojson_info(path)
    layer = {"name": name, "metadata": {}, "geometryFields": [{"name": "", "type": gtype, "nullable": True}], "featureCount": count, "fields": [{"name": k, "type": v, "nullable": True, "uniqueConstraint": False} for k, v in fields.items()]}
    if extent:
        layer["geometryFields"][0]["extent"] = extent
    obj = {"description": path, "driverShortName": "GeoJSON", "driverLongName": "GeoJSON", "layers": [layer], "metadata": {}, "domains": {}, "relationships": {}}
    if fmt == "json":
        print_json(obj)
    else:
        print(f"INFO: Open of `{path}'")
        print("      using driver `GeoJSON' successful.\n")
        print(f"Layer name: {name}")
        print(f"Geometry: {gtype}")
        print(f"Feature Count: {count}")
        if extent:
            print(f"Extent: ({extent[0]:.6f}, {extent[1]:.6f}) - ({extent[2]:.6f}, {extent[3]:.6f})")
        print("Layer Coordinate Reference System:")
        print("  - name: WGS 84")
        print("  - ID: EPSG:4326")
        print("  - type: Geographic 2D")
        print("Data axis to CRS axis mapping: 2,1")
        for k, v in fields.items():
            print(f"{k}: {v} (0.0)")
    return 0


def cmd_info(args):
    vals = positional(args)
    path = option_value(args, ["-i", "--input", "--dataset"]) or (vals[-1] if vals else None)
    drv = driver_for(path) if path else None
    if drv == "GTiff":
        return cmd_raster_info(args)
    if drv == "GeoJSON":
        return cmd_vector_info(args)
    eprint(f"ERROR 4: `{path or ''}' not recognized as being in a supported file format.")
    eprint("Usage: gdal info [OPTIONS] <INPUT>")
    eprint("Try 'gdal info --help' for help.")
    return 1


def cmd_identify(args):
    vals = positional(args)
    paths = [option_value(args, ["--input", "--filename"])] if option_value(args, ["--input", "--filename"]) else vals
    rc = 0
    for p in paths:
        if os.path.isdir(p) and ("-r" in args or "--recursive" in args):
            for root, _, files in os.walk(p):
                for f in files:
                    fp = os.path.join(root, f)
                    d = driver_for(fp)
                    if d:
                        print(f"{fp}: {d}")
        else:
            d = driver_for(p)
            if d:
                print(f"{p}: {d}")
            elif "--report-failures" in args:
                print(f"{p}: unrecognized")
                rc = 1
    return rc


def copy_any(src, dst, overwrite=False, recursive=False):
    if os.path.exists(dst):
        if not overwrite:
            raise FileExistsError(dst)
        if os.path.isdir(dst):
            shutil.rmtree(dst)
        else:
            os.remove(dst)
    if os.path.isdir(src):
        if recursive or True:
            shutil.copytree(src, dst)
    else:
        Path(dst).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def cmd_vsi_list(args):
    fmt = option_value(args, ["-f", "--of", "--format", "--output-format"], "text")
    vals = positional(args)
    path = option_value(args, ["--filename"]) or (vals[-1] if vals else ".")
    rec = "-R" in args or "-r" in args or "--recursive" in args
    long = "-l" in args or "--long" in args or "--long-listing" in args
    abs_path = "--abs" in args or "--absolute-path" in args
    names = []
    if rec:
        base = Path(path)
        for root, dirs, files in os.walk(path):
            for n in sorted(dirs + files):
                p = Path(root) / n
                names.append(str(p if abs_path else p.relative_to(base)))
    else:
        for n in sorted(os.listdir(path)):
            p = Path(path) / n
            names.append(str(p if abs_path else Path(n)))
    if fmt == "json":
        print(json.dumps(names, indent=2, separators=(",", ":")), end="")
    else:
        for n in names:
            if long:
                p = Path(n) if abs_path else Path(path) / n
                st = p.stat()
                mode = "d" if p.is_dir() else "-"
                print(f"{mode}rw-r--r-- 1 unknown unknown {st.st_size:12d} 2026-05-30 00:00 {n}")
            else:
                print(n)
    return 0


def cmd_raster_create(args):
    vals = positional(args)
    out = option_value(args, ["-o", "--output"]) or (vals[-1] if vals else None)
    if not out:
        eprint("ERROR 1: Missing output dataset")
        return 1
    if os.path.exists(out) and "--overwrite" not in args:
        eprint(f"ERROR 1: {out} already exists")
        return 1
    size = option_value(args, ["--size"], "512,512").replace("x", ",")
    try:
        w, h = [int(x) for x in size.split(",", 1)]
    except Exception:
        w, h = 512, 512
    bands = int(option_value(args, ["--band-count"], "1"))
    burn = option_value(args, ["--burn"], "0")
    write_tiff(out, w, h, bands, burn)
    return 0


def cmd_convert(args):
    vals = positional(args)
    inp = option_value(args, ["-i", "--input"]) or (vals[-2] if len(vals) >= 2 else None)
    out = option_value(args, ["-o", "--output"]) or (vals[-1] if vals else None)
    if not inp or not out:
        eprint("ERROR 1: Missing input or output")
        return 1
    try:
        copy_any(inp, out, overwrite=("--overwrite" in args))
        return 0
    except Exception as exc:
        eprint(f"ERROR 1: {exc}")
        return 1


def cmd_vsi(args):
    if not args or args[0] in ("-h", "--help"):
        show_help(("vsi",)); return 0
    sub = {"ls": "list", "cp": "copy", "mv": "move", "ren": "move", "rename": "move", "rm": "delete", "rmdir": "delete", "del": "delete"}.get(args[0], args[0])
    rest = args[1:]
    if sub == "list":
        return cmd_vsi_list(rest)
    vals = positional(rest)
    if sub in ("copy", "sync"):
        src = option_value(rest, ["--source"]) or (vals[0] if vals else None)
        dst = option_value(rest, ["--destination"]) or (vals[1] if len(vals) > 1 else None)
        try:
            copy_any(src, dst, overwrite=True, recursive=True); return 0
        except Exception as exc:
            eprint(f"ERROR 1: {exc}"); return 1
    if sub == "move":
        src = option_value(rest, ["--source"]) or (vals[0] if vals else None)
        dst = option_value(rest, ["--destination"]) or (vals[1] if len(vals) > 1 else None)
        try:
            shutil.move(src, dst); return 0
        except Exception as exc:
            eprint(f"ERROR 1: {exc}"); return 1
    if sub == "delete":
        p = option_value(rest, ["--filename"]) or (vals[-1] if vals else None)
        try:
            if os.path.isdir(p): shutil.rmtree(p)
            else: os.remove(p)
            return 0
        except Exception as exc:
            eprint(f"ERROR 1: {exc}"); return 1
    show_help(("vsi",)); return 1


def cmd_dataset(args):
    if not args or args[0] in ("-h", "--help"):
        show_help(("dataset",)); return 0
    sub = {"cp": "copy", "rm": "delete", "remove": "delete", "ren": "rename", "mv": "rename"}.get(args[0], args[0])
    rest = args[1:]
    if rest and rest[0] in ("-h", "--help"):
        if sub == "identify":
            print("""Usage: gdal dataset identify [OPTIONS] <FILENAME>

Identify driver opening dataset(s).

Positional arguments:
  --input, --filename <FILENAME>                       File or directory name [may be repeated] [required]

Options:
  -r, --recursive                                      Recursively scan files/folders for datasets
  --detailed                                           Most detailed output.
  --report-failures                                    Report failures if file type is unidentified

For more details, consult https://gdal.org/programs/gdal_dataset_identify.html

""" + WARNING)
        elif sub == "copy":
            print("""Usage: gdal dataset copy [OPTIONS] <SOURCE> <DESTINATION>

Copy files of a dataset.

Options:
  --overwrite                  Whether overwriting existing output dataset is allowed

For more details, consult https://gdal.org/programs/gdal_dataset_copy.html

""" + WARNING)
        elif sub == "rename":
            print("""Usage: gdal dataset rename [OPTIONS] <SOURCE> <DESTINATION>

Rename files of a dataset.

Options:
  --overwrite                  Whether overwriting existing output dataset is allowed

For more details, consult https://gdal.org/programs/gdal_dataset_rename.html

""" + WARNING)
        elif sub == "delete":
            print("""Usage: gdal dataset delete [OPTIONS] <FILENAME>

Delete dataset(s).

For more details, consult https://gdal.org/programs/gdal_dataset_delete.html

""" + WARNING)
        return 0
    if sub == "identify":
        return cmd_identify(rest)
    if sub == "check":
        vals = positional(rest)
        p = vals[-1] if vals else option_value(rest, ["--input"])
        d = driver_for(p)
        if d:
            if "--quiet" not in rest and "-q" not in rest:
                print("Check succeeded")
            return 0
        eprint(f"ERROR 4: `{p}' not recognized as being in a supported file format.")
        return 1
    vals = positional(rest)
    if sub == "copy":
        src = option_value(rest, ["--source"]) or (vals[0] if vals else None)
        dst = option_value(rest, ["--destination"]) or (vals[1] if len(vals) > 1 else None)
        try:
            copy_any(src, dst, overwrite=("--overwrite" in rest)); return 0
        except Exception as exc:
            eprint(f"ERROR 1: {exc}"); return 1
    if sub == "rename":
        src = option_value(rest, ["--source"]) or (vals[0] if vals else None)
        dst = option_value(rest, ["--destination"]) or (vals[1] if len(vals) > 1 else None)
        try:
            if os.path.exists(dst) and "--overwrite" in rest:
                os.remove(dst)
            shutil.move(src, dst); return 0
        except Exception as exc:
            eprint(f"ERROR 1: {exc}"); return 1
    if sub == "delete":
        for p in vals:
            if os.path.isdir(p): shutil.rmtree(p)
            elif os.path.exists(p): os.remove(p)
        return 0
    return 1


def main(argv):
    args = strip_global(argv[1:])
    if not args or args[0] in ("-h", "--help"):
        show_help(()); return 0
    if "--json-usage" in args:
        json_usage(); return 0
    if args[0] == "--version":
        print(VERSION); return 0
    if args[0] == "--drivers":
        print_json(DRIVERS); return 0
    cmd = args[0]
    rest = args[1:]
    if rest and rest[0] in ("-h", "--help"):
        if cmd in HELP:
            show_help((cmd,)); return 0
    if cmd == "raster":
        if not rest or rest[0] in ("-h", "--help"):
            show_help(("raster",)); return 0
        if rest[0] == "--drivers":
            print_json([d for d in DRIVERS if "raster" in d["scopes"]]); return 0
        if len(rest) > 1 and rest[1] in ("-h", "--help"):
            show_help(("raster", rest[0])); return 0
        if rest[0] == "info": return cmd_raster_info(rest[1:])
        if rest[0] == "create": return cmd_raster_create(rest[1:])
        if rest[0] == "convert": return cmd_convert(rest[1:])
    if cmd == "vector":
        if not rest or rest[0] in ("-h", "--help"):
            show_help(("vector",)); return 0
        if rest[0] == "--drivers":
            print_json([d for d in DRIVERS if "vector" in d["scopes"]]); return 0
        if len(rest) > 1 and rest[1] in ("-h", "--help"):
            show_help(("vector", rest[0])); return 0
        if rest[0] == "info": return cmd_vector_info(rest[1:])
        if rest[0] in ("convert", "create"): return cmd_convert(rest[1:]) if rest[0] == "convert" else 0
    if cmd == "info":
        if rest and rest[0] in ("-h", "--help"):
            show_help(("info",)); return 0
        return cmd_info(rest)
    if cmd == "convert":
        return cmd_convert(rest)
    if cmd == "dataset":
        return cmd_dataset(rest)
    if cmd == "vsi":
        return cmd_vsi(rest)
    if cmd in ("mdim", "pipeline", "driver"):
        print(f"Usage: gdal {cmd} <SUBCOMMAND> [OPTIONS]\n\n" + WARNING)
        return 0 if (rest and rest[0] in ("-h", "--help")) else 1
    if os.path.exists(cmd):
        return cmd_info(args)
    eprint(f"ERROR 1: gdal: Unknown command: '{cmd}'")
    show_help(())
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
