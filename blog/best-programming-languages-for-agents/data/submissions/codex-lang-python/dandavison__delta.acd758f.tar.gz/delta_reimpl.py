#!/usr/bin/env python3
import argparse
import difflib
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

VERSION = "delta 0.18.2"
RESET = "\033[0m"
BLUE = "\033[34m"
RED = "\033[31m"
GREEN = "\033[32m"
CYAN = "\033[36m"
BOLD = "\033[1m"
DIM = "\033[38;5;238m"
BG_RED = "\033[48;5;52m"
BG_GREEN = "\033[48;5;22;38;5;231m"
WHITE = "\033[38;5;231m"

HELP = """A viewer for git and diff output

Usage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]

Arguments:
  [MINUS_FILE]
          First file to be compared when delta is being used to diff two
          files.

          `delta file1 file2` is equivalent to `diff -u file1 file2 | delta`.

  [PLUS_FILE]
          Second file to be compared when delta is being used to diff two
          files

Options:
      --color-only
          Do not alter the input structurally in any way.

      --dark
          Use default colors appropriate for a dark terminal background.

  -@, --diff-args <STRING>
          Extra arguments to pass to `git diff` when using delta to diff two
          files.

      --diff-highlight
          Emulate diff-highlight.

      --diff-so-fancy
          Emulate diff-so-fancy.

      --generate-completion <GENERATE_COMPLETION>
          Generate shell completion file.

      --hyperlinks
          Render commit hashes and file paths as hyperlinks.

      --keep-plus-minus-markers
          Preserve leading `+` and `-` markers in displayed diff lines.

      --light
          Use default colors appropriate for a light terminal background.

      --line-numbers
          Show line numbers.

      --list-languages
          List supported languages and associated file extensions.

      --list-syntax-themes
          List supported syntax highlighting themes.

      --navigate
          Activate navigation markers for large diffs.

      --no-gitconfig
          Do not read configuration from git config.

      --paging <auto|always|never>
          Specify whether to use a pager.

      --raw
          Do not transform the input, only apply basic coloring.

      --show-colors
          Show available named colors and ANSI color samples.

      --show-config
          Show the delta configuration inferred from arguments and git config.

      --show-syntax-themes
          Show syntax theme previews.

      --show-themes
          Show delta themes.

      --side-by-side
          Display diffs in two columns.

      --syntax-theme <SYNTAX_THEME>
          Syntax highlighting theme.

      --true-color <auto|always|never>
          Whether to emit true color sequences.

      --width <N>
          Width of output.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

LANGUAGES = [
    ("ActionScript", "as"), ("Ada", "adb, ads, gpr"),
    ("Apache Conf", "htaccess, htpasswd"), ("AppleScript", "applescript"),
    ("ARM Assembly", "s, S"), ("AWK", "awk"), ("Batch File", "bat, cmd"),
    ("BibTeX", "bib"), ("Bourne Again Shell (bash)", "sh, bash, zsh"),
    ("C", "c, h"), ("C#", "cs, csx"), ("C++", "cpp, cc, cxx, hpp"),
    ("Cabal", "cabal"), ("Clojure", "clj, cljs"), ("CMake", "cmake"),
    ("CSS", "css"), ("D", "d"), ("Dart", "dart"), ("Diff", "diff, patch"),
    ("Dockerfile", "Dockerfile"), ("Elixir", "ex, exs"), ("Erlang", "erl, hrl"),
    ("Go", "go"), ("GraphQL", "graphql"), ("Haskell", "hs"), ("HTML", "html, htm"),
    ("Java", "java"), ("JavaScript", "js, jsx, mjs"), ("JSON", "json"),
    ("Julia", "jl"), ("Kotlin", "kt, kts"), ("LaTeX", "tex"), ("Lua", "lua"),
    ("Makefile", "Makefile, make"), ("Markdown", "md, markdown"),
    ("Objective-C", "m, mm"), ("Perl", "pl, pm"), ("PHP", "php"),
    ("Python", "py, pyw"), ("R", "r, R"), ("Ruby", "rb"), ("Rust", "rs"),
    ("Scala", "scala"), ("SQL", "sql"), ("Swift", "swift"),
    ("TOML", "toml"), ("TypeScript", "ts, tsx"), ("XML", "xml"), ("YAML", "yaml, yml"),
]
THEMES = ["1337", "Coldark-Cold", "Coldark-Dark", "DarkNeon", "Dracula", "GitHub", "Monokai Extended", "Nord", "OneHalfDark", "OneHalfLight", "Solarized (dark)", "Solarized (light)", "TwoDark", "Visual Studio Dark+"]

VALUE_OPTIONS = {
    "--blame-code-style", "--blame-format", "--blame-palette", "--blame-separator-format",
    "--blame-separator-style", "--blame-timestamp-format", "--blame-timestamp-output-format",
    "--config", "--commit-decoration-style", "--commit-regex", "--commit-style",
    "--default-language", "--detect-dark-light", "--diff-args", "-@", "--diff-stat-align-width",
    "--features", "--file-added-label", "--file-copied-label", "--file-decoration-style",
    "--file-modified-label", "--file-removed-label", "--file-renamed-label", "--file-style",
    "--file-transformation", "--generate-completion", "--grep-context-line-style",
    "--grep-file-style", "--grep-header-decoration-style", "--grep-header-file-style",
    "--grep-line-number-style", "--grep-output-type", "--grep-match-line-style",
    "--grep-match-word-style", "--grep-separator-symbol", "--hunk-header-decoration-style",
    "--hunk-header-file-style", "--hunk-header-line-number-style", "--hunk-header-style",
    "--hunk-label", "--hyperlinks-commit-link-format", "--hyperlinks-file-link-format",
    "--inline-hint-style", "--inspect-raw-lines", "--line-buffer-size", "--line-fill-method",
    "--line-numbers-left-format", "--line-numbers-left-style", "--line-numbers-minus-style",
    "--line-numbers-plus-style", "--line-numbers-right-format", "--line-numbers-right-style",
    "--line-numbers-zero-style", "--map-styles", "--max-line-distance",
    "--max-syntax-highlighting-length", "--max-line-length", "--merge-conflict-begin-symbol",
    "--merge-conflict-end-symbol", "--merge-conflict-ours-diff-header-decoration-style",
    "--merge-conflict-ours-diff-header-style", "--merge-conflict-theirs-diff-header-decoration-style",
    "--merge-conflict-theirs-diff-header-style", "--minus-empty-line-marker-style",
    "--minus-emph-style", "--minus-non-emph-style", "--minus-style", "--navigate-regex",
    "--pager", "--paging", "--plus-emph-style", "--plus-empty-line-marker-style",
    "--plus-non-emph-style", "--plus-style", "--relative-paths", "--right-arrow",
    "--syntax-theme", "--tabs", "--true-color", "--whitespace-error-style", "--width",
    "--word-diff-regex", "--wrap-left-symbol", "--wrap-max-lines", "--wrap-right-percent",
    "--wrap-right-prefix-symbol", "--wrap-right-symbol", "--zero-style", "--24-bit-color",
}
FLAG_OPTIONS = {
    "--color-only", "--dark", "--diff-highlight", "--diff-so-fancy", "--hyperlinks",
    "--keep-plus-minus-markers", "--light", "--line-numbers", "--list-languages",
    "--list-syntax-themes", "--navigate", "--no-gitconfig", "--parse-ansi", "--raw",
    "--show-colors", "--show-config", "--show-syntax-themes", "--show-themes", "--side-by-side",
}

class Opts:
    def __init__(self):
        self.raw = False; self.color_only = False; self.line_numbers = False
        self.side_by_side = False; self.keep_markers = False; self.width = 80
        self.generate_completion = None; self.show_config = False
        self.show_colors = False; self.show_themes = False; self.show_syntax_themes = False
        self.list_syntax_themes = False; self.list_languages = False
        self.paging = "auto"; self.diff_args = []


def color(s, c):
    return f"{c}{s}{RESET}"


def parse(argv):
    opts = Opts(); files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end=""); sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION); sys.exit(0)
        if a == "--":
            files.extend(argv[i+1:]); break
        key, val = (a.split("=", 1) + [None])[:2] if a.startswith("--") and "=" in a else (a, None)
        if key in VALUE_OPTIONS:
            if val is None:
                i += 1
                val = argv[i] if i < len(argv) else ""
            if key == "--width":
                try: opts.width = int(val)
                except ValueError: pass
            elif key == "--paging": opts.paging = val
            elif key in ("--diff-args", "-@"): opts.diff_args.append(val)
            elif key == "--generate-completion": opts.generate_completion = val
            i += 1; continue
        if key in FLAG_OPTIONS:
            if key == "--raw": opts.raw = True
            elif key == "--color-only": opts.color_only = True
            elif key == "--line-numbers": opts.line_numbers = True
            elif key == "--side-by-side": opts.side_by_side = True
            elif key == "--keep-plus-minus-markers": opts.keep_markers = True
            elif key == "--list-languages": opts.list_languages = True
            elif key == "--list-syntax-themes": opts.list_syntax_themes = True
            elif key == "--show-syntax-themes": opts.show_syntax_themes = True
            elif key == "--show-themes": opts.show_themes = True
            elif key == "--show-colors": opts.show_colors = True
            elif key == "--show-config": opts.show_config = True
            i += 1; continue
        if a.startswith("-") and a != "-":
            # Unknown delta option: accept it when possible to remain compatible.
            i += 1; continue
        files.append(a); i += 1
    return opts, files


def list_languages():
    for name, exts in LANGUAGES:
        ext_s = ", ".join(color(x.strip(), GREEN) for x in exts.split(","))
        print(f"{name:<26}{ext_s}")


def list_themes():
    for t in THEMES:
        print(t)


def show_syntax_themes():
    for t in THEMES[:6]:
        print(f"\nSyntax theme: {BOLD}{t}{RESET}\n")
        print(color("example.rs", BLUE))
        print(color("-" * 10, BLUE))
        print(f"{BG_RED}// Output the square of a number.{RESET}")
        print(f"{BG_GREEN}fn print_cube(num: f64) {{{RESET}")


def show_colors():
    names = [("black",30),("red",31),("green",32),("yellow",33),("blue",34),("magenta",35),("cyan",36),("white",37)]
    for name, code in names:
        print(f"\033[{code}m{name:<8}\033[0m ansi:{code}")


def show_config(opts):
    print("[delta]")
    print(f"    paging = {opts.paging}")
    print(f"    width = {opts.width}")
    if opts.line_numbers: print("    line-numbers = true")
    if opts.side_by_side: print("    side-by-side = true")
    if opts.raw: print("    raw = true")


def completion(shell):
    opts = sorted(VALUE_OPTIONS | FLAG_OPTIONS | {"--help", "--version"})
    if shell == "fish":
        for o in opts: print(f"complete -c delta -l {o[2:]}")
    elif shell == "zsh":
        print("#compdef delta\n_arguments \\")
        for o in opts: print(f"  '{o}[delta option]' \\")
    else:
        print("_delta() { COMPREPLY=( $( compgen -W '" + " ".join(opts) + "' -- \"${COMP_WORDS[COMP_CWORD]}\" ) ); }")
        print("complete -F _delta delta")


def file_diff(files, opts):
    a, b = files[0], files[1]
    try:
        with open(a, 'r', errors='replace') as f: left = f.readlines()
        with open(b, 'r', errors='replace') as f: right = f.readlines()
    except OSError as e:
        print(f"delta: {e}", file=sys.stderr); return 2
    # Match the useful shape of git diff --no-index closely enough for consumers.
    out = [f"diff --git a/{a.lstrip('/')} b/{b.lstrip('/')}\n"]
    out.extend(difflib.unified_diff(left, right, fromfile=f"a/{a.lstrip('/')}", tofile=f"b/{b.lstrip('/')}", lineterm=""))
    return process("\n".join(x.rstrip("\n") for x in out) + "\n", opts)


def parse_hunk_header(line):
    m = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(.*)", line)
    if not m: return None
    return int(m.group(1)), int(m.group(3))


def raw_color(line):
    if line.startswith("@@"):
        return color(line, CYAN)
    if line.startswith("+") and not line.startswith("+++"):
        return color(line, GREEN)
    if line.startswith("-") and not line.startswith("---"):
        return color(line, RED)
    if line.startswith(("diff --git", "index ", "--- ", "+++ ", "commit ")):
        return color(line, BOLD)
    return line


def process(text, opts):
    if opts.raw or opts.color_only:
        for line in text.splitlines(True):
            end = "\n" if line.endswith("\n") else ""
            body = line[:-1] if end else line
            sys.stdout.write(raw_color(body) + end)
        return 0
    if not looks_like_diff(text):
        sys.stdout.write(text); return 0
    render_diff(text.splitlines(), opts)
    return 0


def looks_like_diff(text):
    return bool(re.search(r"(?m)^(diff --git |@@ |--- |\+\+\+ )", text))


def clean_path(p):
    p = p.strip()
    if p.startswith("a/") or p.startswith("b/"):
        p = p[2:]
    if p == "/dev/null": return p
    return p.split("\t", 1)[0]


def render_diff(lines, opts):
    file_name = None; minus = plus = 0; in_hunk = False; pending = []
    def flush_pairs():
        nonlocal pending
        if not pending: return
        if opts.side_by_side:
            render_side_by_side(pending, opts)
        else:
            for kind, lno_old, lno_new, body in pending:
                render_line(kind, lno_old, lno_new, body, opts)
        pending = []
    for line in lines:
        if line.startswith("diff --git "):
            flush_pairs(); in_hunk = False; file_name = None
            parts = line.split()
            if len(parts) >= 4:
                file_name = clean_path(parts[3])
            continue
        if line.startswith("+++ "):
            p = clean_path(line[4:])
            if p != "/dev/null": file_name = p
            continue
        if line.startswith("--- ") or line.startswith("index ") or line.startswith("new file") or line.startswith("deleted file") or line.startswith("similarity index") or line.startswith("rename "):
            continue
        h = parse_hunk_header(line)
        if h:
            flush_pairs(); minus, plus = h; in_hunk = True
            if file_name:
                print(); print(color(file_name, BLUE)); print(color("─" * max(10, min(opts.width, 80)), BLUE)); print()
                file_name = None
            print(color("───┐", BLUE)); print(color(f"{plus}: │", BLUE)); print(color("───┘", BLUE))
            continue
        if not in_hunk:
            print(line); continue
        if line.startswith("\\ No newline"):
            flush_pairs(); print(DIM + line + RESET); continue
        if line.startswith("-"):
            pending.append(("-", minus, None, line[1:])); minus += 1
        elif line.startswith("+"):
            pending.append(("+", None, plus, line[1:])); plus += 1
        elif line.startswith(" "):
            pending.append((" ", minus, plus, line[1:])); minus += 1; plus += 1
        else:
            pending.append((" ", minus, plus, line)); minus += 1; plus += 1
    flush_pairs()


def render_line(kind, old, new, body, opts):
    prefix = ""
    if opts.line_numbers:
        lo = f"{old:>4}" if old is not None else "    "
        ln = f"{new:>4}" if new is not None else "    "
        prefix = color(lo, RED if kind == '-' else DIM) + color(" ⋮", BLUE) + color(ln, GREEN if kind == '+' else DIM) + color(" │", BLUE)
    marker = kind if opts.keep_markers and kind in "+-" else ""
    if kind == "-":
        print(prefix + BG_RED + marker + body + RESET)
    elif kind == "+":
        print(prefix + BG_GREEN + marker + body + RESET)
    else:
        print(prefix + WHITE + marker + body + RESET)


def render_side_by_side(items, opts):
    colw = max(20, (opts.width - 7) // 2)
    for kind, old, new, body in items:
        if kind == "-":
            left = fmt_cell(old, body, RED, BG_RED, colw); right = fmt_cell(None, "", GREEN, "", colw)
        elif kind == "+":
            left = fmt_cell(None, "", RED, "", colw); right = fmt_cell(new, body, GREEN, BG_GREEN, colw)
        else:
            left = fmt_cell(old, body, DIM, WHITE, colw); right = fmt_cell(new, body, DIM, WHITE, colw)
        print(color("│", BLUE) + left + color("│", BLUE) + right)


def fmt_cell(num, body, ncolor, bcolor, width):
    n = f"{num:>4}" if num is not None else "    "
    text = (body[:max(0, width-6)]).ljust(max(0, width-6))
    return color(n, ncolor) + color(" │", BLUE) + (bcolor + text + RESET if bcolor else text)


def main(argv=None):
    opts, files = parse(sys.argv[1:] if argv is None else argv)
    if opts.generate_completion:
        completion(opts.generate_completion); return 0
    if opts.list_languages:
        list_languages(); return 0
    if opts.list_syntax_themes:
        list_themes(); return 0
    if opts.show_syntax_themes or opts.show_themes:
        show_syntax_themes(); return 0
    if opts.show_colors:
        show_colors(); return 0
    if opts.show_config:
        show_config(opts); return 0
    if len(files) == 2:
        return file_diff(files, opts)
    if len(files) == 1:
        try:
            text = Path(files[0]).read_text(errors='replace')
        except OSError as e:
            print(f"delta: {e}", file=sys.stderr); return 2
    else:
        text = sys.stdin.read()
    return process(text, opts)

if __name__ == "__main__":
    raise SystemExit(main())
