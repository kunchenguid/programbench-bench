#!/usr/bin/env python3
import argparse
import datetime as _dt
import json
import os
import re
import subprocess
import sys
from pathlib import Path


HELP = """a conventional changelog for the rest of us

Usage: executable [OPTIONS]

Options:
  -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,
                          e.g. https://github.com/thoughtram/clog)
  -f, --from <COMMIT>     e.g. 12a8546
  -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible
                          values: markdown, json]
  -M, --major             Increment major version by one (Sets minor and patch to 0)
  -g, --git-dir <PATH>    Local .git directory (defaults to "$(pwd)/.git")
  -w, --work-tree <PATH>  Local working tree of the git project (defaults to "$(pwd)")
  -m, --minor             Increment minor version by one (Sets patch to 0)
  -p, --patch             Increment patch version by one
  -s, --subtitle <STR>    
  -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]
  -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)
  -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]
  -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with
                          --outfile)
      --setversion <VER>  e.g. 1.0.1
  -F, --from-latest-tag   use latest tag as start (instead of --from)
  -l, --link-style <STR>  The style of repository link to generate [default: github] [possible
                          values: github, gitlab, stash, cgit]
  -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the
                          same file for both --infile and --outfile and should not be used in
                          conjunction with either)
  -h, --help              Print help
  -V, --version           Print version


If your .git directory is a child of your project directory (most common, such as /myproject/.git)
AND not in the current working directory (i.e you need to use --work-tree or --git-dir) you only
need to specify either the --work-tree (i.e. /myproject) OR --git-dir (i.e. /myproject/.git), you
don't need to use both.

If using the --config to specify a clog configuration TOML file NOT in the current working directory
(meaning you need to use --work-tree or --git-dir) AND the TOML file is inside your project
directory (i.e. /myproject/.clog.toml) you do not need to use --work-tree or --git-dir.
"""


def eprint(msg):
    print(f"\033[1;31merror:\033[0m {msg}", file=sys.stderr)


def git(args, work_tree=None, git_dir=None, check=True):
    cmd = ["git"]
    if git_dir:
        cmd += ["--git-dir", git_dir]
    if work_tree:
        cmd += ["--work-tree", work_tree]
    cmd += args
    res = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and res.returncode != 0:
        raise RuntimeError(res.stderr.strip() or res.stdout.strip())
    return res.stdout


def parse_config(path):
    cfg = {"repository": None, "from-latest-tag": False, "sections": []}
    p = Path(path)
    if not p.exists():
        return cfg
    section = None
    try:
        for raw in p.read_text().splitlines():
            line = raw.split("#", 1)[0].strip()
            if not line:
                continue
            if line.startswith("[") and line.endswith("]"):
                section = line[1:-1].strip()
                continue
            if "=" not in line:
                continue
            key, val = [x.strip() for x in line.split("=", 1)]
            key = key.strip('"').strip("'")
            if section == "clog":
                if val.startswith('"') and val.endswith('"'):
                    val2 = val[1:-1]
                else:
                    val2 = val
                if key == "repository":
                    cfg["repository"] = val2
                elif key == "from-latest-tag":
                    cfg["from-latest-tag"] = val2.lower() == "true"
            elif section == "sections":
                m = re.match(r"\[(.*)\]$", val)
                if m:
                    aliases = []
                    for item in re.finditer(r'"([^"]+)"|\'([^\']+)\'|([^,\s]+)', m.group(1)):
                        aliases.append(next(g for g in item.groups() if g))
                    cfg["sections"].append((key, aliases))
    except Exception:
        eprint("Failed to parse TOML configuration file")
        sys.exit(1)
    return cfg


def latest_tag(work_tree, git_dir):
    out = git(["describe", "--tags", "--abbrev=0"], work_tree, git_dir, check=False).strip()
    return out or None


def commit_rows(start, end, work_tree, git_dir):
    rng = end if not start else f"{start}..{end}"
    fmt = "%H%x1f%h%x1f%s%x1f%b%x1e"
    out = git(["log", "--reverse", f"--format={fmt}", rng], work_tree, git_dir, check=False)
    rows = []
    for rec in out.split("\x1e"):
        rec = rec.strip("\n")
        if not rec:
            continue
        parts = rec.split("\x1f")
        if len(parts) >= 4:
            rows.append({"sha": parts[0], "short": parts[1], "subject_line": parts[2], "body": parts[3]})
    return rows


def parse_commit(row):
    subj = row["subject_line"]
    m = re.match(r"([A-Za-z0-9_-]+)(?:\(([^)]*)\))?(!)?:\s*(.*)$", subj)
    if not m:
        return None
    typ, comp, bang, rest = m.groups()
    breaks = []
    body = row.get("body") or ""
    if bang or re.search(r"(?im)^BREAKING[ -]CHANGE:", body):
        breaks.append("")
    closes = []
    for n in re.findall(r"(?i)(?:close[sd]?|fix(?:e[sd])?|resolve[sd]?)\s+#(\d+)", subj):
        if n not in closes:
            closes.append(n)
    return {"type": typ, "component": comp or None, "subject": " " + rest, "closes": closes or None, "breaks": breaks or None}


def commit_link(repo, sha, style):
    if not repo:
        return sha[:8]
    repo = repo[:-4] if repo.endswith(".git") else repo
    if style == "stash":
        return f"{repo}/commits/{sha}"
    if style == "cgit":
        return f"{repo}/commit/?id={sha}"
    return f"{repo}/commit/{sha}"


def issue_link(repo, num, style):
    if not repo:
        return f"#{num}"
    repo = repo[:-4] if repo.endswith(".git") else repo
    if style == "stash":
        return f"{repo}/browse?issue={num}"
    return f"{repo}/issues/{num}"


def build_sections(rows, cfg_sections, repo, style):
    alias_to_title = {}
    order = []
    for title, aliases in cfg_sections:
        order.append(title)
        for a in aliases:
            alias_to_title[a] = title
    buckets = {title: [] for title in order}
    for row in rows:
        parsed = parse_commit(row)
        if not parsed:
            continue
        title = alias_to_title.get(parsed["type"])
        if not title:
            continue
        item = {
            "component": parsed["component"],
            "subject": parsed["subject"],
            "commit_link": commit_link(repo, row["sha"], style),
            "closes": parsed["closes"],
            "breaks": parsed["breaks"],
            "_short": row["short"],
            "_sha": row["sha"],
        }
        buckets[title].append(item)
        if parsed["breaks"] and "Breaking Changes" in buckets and title != "Breaking Changes":
            buckets["Breaking Changes"].append(dict(item))
    return [{"title": t, "commits": buckets[t]} for t in order if buckets[t]]


def find_prev_version(text):
    m = re.search(r'<a name="v?([0-9]+\.[0-9]+\.[0-9]+)"></a>', text)
    if not m:
        m = re.search(r"^#+\s+v?([0-9]+\.[0-9]+\.[0-9]+)\b", text, re.M)
    return m.group(1) if m else None


def bump(ver, which):
    m = re.match(r"^v?(\d+)\.(\d+)\.(\d+)$", ver or "")
    if not m:
        eprint("Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.")
        sys.exit(2)
    a, b, c = map(int, m.groups())
    if which == "major":
        a, b, c = a + 1, 0, 0
    elif which == "minor":
        b, c = b + 1, 0
    elif which == "patch":
        c += 1
    return f"{a}.{b}.{c}"


def render_markdown(header, sections, repo, style):
    ver = header["version"] or ""
    sub = header["subtitle"] or ""
    level = "###" if header.get("patch_version") else "##"
    out = [f'<a name="{ver}"></a>', f"{level} {ver} {sub} ({header['date']})", "", ""]
    for sec in sections or []:
        out += [f"#### {sec['title']}", ""]
        for c in sec["commits"]:
            short = c.get("_sha", "")[:8] or c.get("_short", "")[:8] or (c["commit_link"].rstrip("/").split("/")[-1][:8])
            suffix = f"([{short[:8]}]({c['commit_link']})"
            extras = []
            if c.get("closes"):
                extras += [f"closes [#{n}]({issue_link(repo, n, style)})" for n in c["closes"]]
            if c.get("breaks") is not None:
                if c["breaks"]:
                    extras += [f"breaks [#{n}]({issue_link(repo, n, style)})" for n in c["breaks"]]
                elif c.get("breaks") == []:
                    extras += [f"breaks [#]({issue_link(repo, '', style)})"]
            if extras:
                suffix += ", " + ", ".join(extras)
            suffix += ")"
            subject = c["subject"]
            if c["component"]:
                if sec["title"] == "Breaking Changes":
                    out.append(f"* **{c['component']}:**")
                    out.append(f"  * {subject} {suffix}")
                else:
                    out.append(f"* **{c['component']}:** {subject} {suffix}")
            else:
                out.append(f"*  {subject} {suffix}")
        out += ["", ""]
    return "\n".join(out) + "\n"


def main(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP)
        return 0
    if "--version" in argv or "-V" in argv:
        print("clog 0.10.0")
        return 0
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("-r", "--repository")
    ap.add_argument("-f", "--from", dest="from_")
    ap.add_argument("-T", "--format", default="markdown", choices=["markdown", "json"])
    ap.add_argument("-M", "--major", action="store_true")
    ap.add_argument("-g", "--git-dir")
    ap.add_argument("-w", "--work-tree")
    ap.add_argument("-m", "--minor", action="store_true")
    ap.add_argument("-p", "--patch", action="store_true")
    ap.add_argument("-s", "--subtitle")
    ap.add_argument("-t", "--to", default="HEAD")
    ap.add_argument("-o", "--outfile")
    ap.add_argument("-c", "--config", default=".clog.toml")
    ap.add_argument("-i", "--infile")
    ap.add_argument("--setversion")
    ap.add_argument("-F", "--from-latest-tag", action="store_true")
    ap.add_argument("-l", "--link-style", default="github", choices=["github", "gitlab", "stash", "cgit"])
    ap.add_argument("-C", "--changelog")
    ns = ap.parse_args(argv)
    cfg = parse_config(ns.config)
    work_tree = ns.work_tree
    git_dir = ns.git_dir
    repo = ns.repository if ns.repository is not None else cfg.get("repository")
    start = ns.from_
    if ns.from_latest_tag or (cfg.get("from-latest-tag") and not start):
        start = latest_tag(work_tree, git_dir)
    rows = commit_rows(start, ns.to, work_tree, git_dir)
    sections = build_sections(rows, cfg.get("sections", []), repo, ns.link_style)
    old_text = ""
    infile = ns.infile or ns.changelog
    if infile and Path(infile).exists():
        old_text = Path(infile).read_text()
    version = ns.setversion
    patch_version = False
    if not version and (ns.major or ns.minor or ns.patch):
        base = find_prev_version(old_text) or (start if start and re.match(r"^v?\d+\.\d+\.\d+$", start) else None)
        which = "major" if ns.major else "minor" if ns.minor else "patch"
        version = bump(base, which)
        patch_version = which == "patch"
    elif version:
        patch_version = bool(re.match(r"^\d+\.\d+\.[1-9]\d*$", version))
    header = {"version": version, "patch_version": patch_version, "subtitle": ns.subtitle, "date": str(_dt.date.today())}
    if ns.format == "json":
        payload_sections = None if not sections else [
            {"title": s["title"], "commits": [{k: v for k, v in c.items() if not k.startswith("_")} for c in s["commits"]]}
            for s in sections
        ]
        text = json.dumps({"header": header, "sections": payload_sections}, separators=(",", ":")) + "\n"
    else:
        text = render_markdown(header, sections, repo, ns.link_style)
        if old_text:
            text += old_text
    out = ns.outfile or ns.changelog
    if out:
        Path(out).write_text(text)
        print("changelog written. (took 80 ms)")
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(1)
    except Exception as exc:
        eprint(str(exc) or "fatal I/O error with output file")
        raise SystemExit(1)
