#!/usr/bin/env python3
import argparse
import base64
import email.utils
import html
from html.parser import HTMLParser
import mimetypes
import os
import posixpath
import re
import sys
import time
from urllib.parse import urljoin, urlparse, unquote
from urllib.request import Request, urlopen

VERSION = "monolith 2.11.0"
BANNER = r''' _____    _____________   __________     ___________________    ___
|     \  /             \ |          |   |                   |  |   |
|      \/       __      \|    __    |   |    ___     ___    |__|   |
|              |  |          |  |   |   |   |   |   |   |          |
|   |\    /|   |__|          |__|   |___|   |   |   |   |    __    |
|   | \__/ |          |\                    |   |   |   |   |  |   |
|___|      |__________| \___________________|   |___|   |___|  |___|'''

VOID = {"area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"}
RAW = {"script", "style"}
URL_ATTRS = {"src", "href", "poster", "data", "action"}
SRCSET_TAGS = {"img", "source"}

class Node:
    def __init__(self, kind, name=None, attrs=None, data=None):
        self.kind = kind
        self.name = name
        self.attrs = list(attrs or [])
        self.children = []
        self.data = data or ""
    def get(self, key):
        key = key.lower()
        for k,v in self.attrs:
            if k.lower() == key:
                return v
        return None
    def set(self, key, val):
        lk = key.lower()
        for i,(k,v) in enumerate(self.attrs):
            if k.lower() == lk:
                self.attrs[i] = (k, val)
                return
        self.attrs.append((key, val))
    def delete(self, key):
        lk = key.lower()
        self.attrs = [(k,v) for k,v in self.attrs if k.lower() != lk]

class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.root = Node('root')
        self.stack = [self.root]
        self.doctype = None
    def handle_decl(self, decl):
        if decl.lower().startswith('doctype'):
            self.doctype = '<!' + decl + '>'
        else:
            self.stack[-1].children.append(Node('text', data='<!' + decl + '>'))
    def handle_starttag(self, tag, attrs):
        n = Node('tag', tag.lower(), [(k, '' if v is None else v) for k,v in attrs])
        self.stack[-1].children.append(n)
        if tag.lower() not in VOID:
            self.stack.append(n)
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
    def handle_endtag(self, tag):
        tag = tag.lower()
        for i in range(len(self.stack)-1, 0, -1):
            if self.stack[i].name == tag:
                del self.stack[i:]
                return
    def handle_data(self, data):
        self.stack[-1].children.append(Node('text', data=data))
    def handle_entityref(self, name):
        self.handle_data('&' + name + ';')
    def handle_charref(self, name):
        self.handle_data('&#' + name + ';')
    def handle_comment(self, data):
        self.stack[-1].children.append(Node('text', data='<!--' + data + '-->'))


def attrs_to_s(attrs):
    out = []
    for k,v in attrs:
        if v is None:
            out.append(k)
        else:
            out.append('%s="%s"' % (k, html.escape(str(v), quote=True)))
    return (' ' + ' '.join(out)) if out else ''

def serialize(node):
    if node.kind == 'root':
        return ''.join(serialize(c) for c in node.children)
    if node.kind == 'text':
        return node.data
    inner = ''.join(serialize(c) for c in node.children)
    if node.name in VOID and node.name not in {'meta', 'base'}:
        return '<%s%s>' % (node.name, attrs_to_s(node.attrs))
    return '<%s%s>%s</%s>' % (node.name, attrs_to_s(node.attrs), inner, node.name)

def walk(n):
    yield n
    for c in list(n.children):
        yield from walk(c)

def children_text(n):
    return ''.join(c.data if c.kind == 'text' else serialize(c) for c in n.children)

def set_text(n, text):
    n.children = [Node('text', data=text)] if text else []

def find_first(root, name):
    for n in walk(root):
        if n.kind == 'tag' and n.name == name:
            return n
    return None

def ensure_html(root):
    if find_first(root, 'html'):
        return
    old = root.children
    htmln = Node('tag','html')
    head = Node('tag','head')
    body = Node('tag','body')
    body.children = old
    htmln.children = [head, body]
    root.children = [htmln]

def ensure_head(root):
    ensure_html(root)
    htmln = find_first(root, 'html')
    head = find_first(root, 'head')
    if not head:
        head = Node('tag','head')
        htmln.children.insert(0, head)
    return head

def file_url(path):
    return 'file://' + os.path.abspath(path)

def is_data_or_special(u):
    return not u or u.startswith(('data:', 'javascript:', 'mailto:', '#', 'about:'))

def guess_mime(url, data=b''):
    mt = mimetypes.guess_type(urlparse(url).path)[0]
    if mt:
        return mt
    if data.lstrip().startswith(b'<'):
        return 'text/html'
    return 'text/plain'

def read_url(url, args, quiet=False):
    if not quiet and not args.quiet:
        print(url, file=sys.stderr)
    p = urlparse(url)
    try:
        if p.scheme == 'file':
            with open(unquote(p.path), 'rb') as f:
                return f.read(), guess_mime(url)
        if p.scheme in ('http','https'):
            req = Request(url, headers={'User-Agent': args.user_agent or 'Mozilla/5.0 Firefox'})
            with urlopen(req, timeout=float(args.timeout or 60)) as r:
                data = r.read()
                mt = r.headers.get_content_type() or guess_mime(url, data)
                return data, mt
        if p.scheme == '':
            with open(url, 'rb') as f:
                data = f.read()
                return data, guess_mime(url, data)
    except Exception as e:
        if not args.ignore_errors:
            raise
    return b'', 'text/plain'

def data_url(data, mime):
    return 'data:%s;base64,%s' % (mime or 'text/plain', base64.b64encode(data).decode('ascii'))

def absolutize(u, base):
    if is_data_or_special(u):
        return u
    return urljoin(base, u)

def embed(u, base, args, default_mime=None):
    if is_data_or_special(u):
        return u
    full = urljoin(base, u)
    try:
        data, mt = read_url(full, args)
        if (default_mime or mt) == 'text/html' and b'<html' not in data[:256].lower():
            data = b'<html><head></head><body>' + data + b'</body></html>'
    except Exception as e:
        print(f"{full} ({e})", file=sys.stderr)
        if not args.ignore_errors:
            return u
        data, mt = b'', default_mime or 'text/plain'
    return data_url(data, default_mime or mt)

URL_RE = re.compile(r'url\(\s*(["\']?)(.*?)\1\s*\)', re.I | re.S)
FONT_FACE_RE = re.compile(r'@font-face\s*\{[^{}]*\}', re.I | re.S)

def rewrite_css(css, base, args):
    if args.no_fonts:
        css = FONT_FACE_RE.sub('', css)
    def repl(m):
        q, u = m.group(1), m.group(2).strip()
        low = u.lower()
        if args.no_fonts and re.search(r'\.(woff2?|ttf|otf|eot)(\?|$)', low):
            return 'url("")'
        if args.no_images and re.search(r'\.(png|jpe?g|gif|webp|svg|ico|bmp)(\?|$)', low):
            return 'url("")'
        return 'url("%s")' % embed(u, base, args)
    return URL_RE.sub(repl, css)

def rewrite_srcset(val, base, args):
    pieces = []
    for item in val.split(','):
        parts = item.strip().split()
        if not parts:
            continue
        parts[0] = embed(parts[0], base, args)
        pieces.append(' '.join(parts))
    return ', '.join(pieces)

def remove_or_insert_base(head, base):
    for n in head.children:
        if n.kind == 'tag' and n.name == 'base':
            n.set('href', base); return
    base_n = Node('tag','base',[('href',base)])
    head.children.append(base_n)

def add_meta(head, attrs, at_start=False):
    n = Node('tag','meta', attrs)
    if at_start:
        head.children.insert(0, n)
    else:
        head.children.append(n)

def transform(root, base, args, stdin_base=False):
    head = ensure_head(root)
    csp = []
    if args.isolate: csp.append("default-src 'unsafe-eval' 'unsafe-inline' data:;")
    if args.no_css: csp.append("style-src 'none';")
    if args.no_js: csp.append("script-src 'none';")
    if args.no_frames: csp.append("frame-src 'none'; child-src 'none';")
    if args.no_fonts: csp.append("font-src 'none';")
    if args.no_images: csp.append("img-src data:;")
    if csp: add_meta(head, [('http-equiv','Content-Security-Policy'), ('content',' '.join(csp))], True)
    if stdin_base and args.base_url:
        remove_or_insert_base(head, args.base_url)

    # unwrap noscript first, preserving monolith's marker comments
    if args.unwrap_noscript:
        for parent in walk(root):
            if not hasattr(parent, 'children'): continue
            new = []
            for ch in parent.children:
                if ch.kind == 'tag' and ch.name == 'noscript':
                    new.append(Node('text', data='<!--noscript-->'))
                    new.extend(ch.children)
                    new.append(Node('text', data='<!--/noscript-->'))
                else:
                    new.append(ch)
            parent.children = new

    for n in list(walk(root)):
        if n.kind != 'tag':
            continue
        name = n.name
        if name == 'link' and (n.get('rel') or '').lower() == 'stylesheet':
            if args.no_css:
                n.delete('href')
            elif n.get('href'):
                u = n.get('href')
                full = urljoin(base, u)
                try:
                    data, mt = read_url(full, args)
                    css = data.decode(args.encoding or 'utf-8', 'replace')
                    css = rewrite_css(css, full, args)
                    n.set('href', data_url(css.encode(args.encoding or 'utf-8'), 'text/css'))
                except Exception as e:
                    print(f"{full} ({e})", file=sys.stderr)
                    if args.ignore_errors: n.set('href', data_url(b'', 'text/css'))
        elif name == 'style':
            set_text(n, '' if args.no_css else rewrite_css(children_text(n), base, args))
        elif name == 'script':
            if args.no_js:
                n.delete('src'); set_text(n, '')
            elif n.get('src'):
                full = urljoin(base, n.get('src'))
                try:
                    data, mt = read_url(full, args)
                    n.delete('src'); set_text(n, data.decode(args.encoding or 'utf-8', 'replace'))
                except Exception as e:
                    print(f"{full} ({e})", file=sys.stderr)
                    if args.ignore_errors: n.delete('src')
        elif name in ('img','input') and n.get('src'):
            n.set('src', '' if args.no_images else embed(n.get('src'), base, args))
        elif name in SRCSET_TAGS and n.get('srcset'):
            n.set('srcset', '' if args.no_images else rewrite_srcset(n.get('srcset'), base, args))
        elif name in ('video',) and n.get('src'):
            n.set('src', '' if args.no_video else embed(n.get('src'), base, args))
        elif name in ('audio',) and n.get('src'):
            n.set('src', '' if args.no_audio else embed(n.get('src'), base, args))
        elif name in ('iframe','frame') and n.get('src'):
            n.set('src', '' if args.no_frames else embed(n.get('src'), base, args, 'text/html'))
        elif name == 'source' and n.get('src'):
            parent_media = False
            if args.no_images or args.no_audio or args.no_video:
                n.set('src', '')
            else:
                n.set('src', embed(n.get('src'), base, args))
        else:
            for attr in list(URL_ATTRS):
                val = n.get(attr)
                if val and not (name == 'link' and attr == 'href'):
                    n.set(attr, absolutize(val, base))
    add_meta(head, [('name','robots'), ('content','none')])

def build_mhtml(html_text):
    boundary = '----=_NextPart_000_0000'
    return (f'MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary="{boundary}"\r\n\r\n'
            f'--{boundary}\r\nContent-Type: text/html; charset="utf-8"\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n'
            + html_text + f'\r\n--{boundary}--\r\n')

def parse_args(argv):
    if '--help' in argv or '-h' in argv:
        print(BANNER + '\n')
        print(VERSION + '\n')
        print('CLI tool and library for saving web pages as a single HTML file\n')
        print('Usage: executable [OPTIONS] <TARGET>\n')
        print('Arguments:\n  <TARGET>  URL or file path, use - for STDIN\n')
        print('Options:\n  -a, --no-audio\n  -b, --base-url <http://localhost/>\n  -B, --blacklist-domains\n  -c, --no-css\n  -C, --cookie-file <cookies.txt>\n  -d, --domain <example.com>\n  -e, --ignore-errors\n  -E, --encoding <UTF-8>\n  -f, --no-frames\n  -F, --no-fonts\n  -i, --no-images\n  -I, --isolate\n  -j, --no-js\n  -k, --insecure\n  -m, --mhtml\n  -M, --no-metadata\n  -n, --unwrap-noscript\n  -o, --output <result.html>\n  -q, --quiet\n  -t, --timeout <60>\n  -u, --user-agent <Firefox>\n  -v, --no-video\n  -h, --help\n  -V, --version')
        sys.exit(0)
    if '--version' in argv or '-V' in argv:
        print(VERSION); sys.exit(0)
    ap = argparse.ArgumentParser(add_help=False, prog='executable')
    ap.add_argument('-a','--no-audio', action='store_true')
    ap.add_argument('-b','--base-url', dest='base_url')
    ap.add_argument('-B','--blacklist-domains', action='store_true')
    ap.add_argument('-c','--no-css', action='store_true')
    ap.add_argument('-C','--cookie-file')
    ap.add_argument('-d','--domain', action='append', default=[])
    ap.add_argument('-e','--ignore-errors', action='store_true')
    ap.add_argument('-E','--encoding')
    ap.add_argument('-f','--no-frames', action='store_true')
    ap.add_argument('-F','--no-fonts', action='store_true')
    ap.add_argument('-i','--no-images', action='store_true')
    ap.add_argument('-I','--isolate', action='store_true')
    ap.add_argument('-j','--no-js', action='store_true')
    ap.add_argument('-k','--insecure', action='store_true')
    ap.add_argument('-m','--mhtml', action='store_true')
    ap.add_argument('-M','--no-metadata', action='store_true')
    ap.add_argument('-n','--unwrap-noscript', action='store_true')
    ap.add_argument('-o','--output')
    ap.add_argument('-q','--quiet', action='store_true')
    ap.add_argument('-t','--timeout')
    ap.add_argument('-u','--user-agent')
    ap.add_argument('-v','--no-video', action='store_true')
    ap.add_argument('target', nargs='?')
    ns, unknown = ap.parse_known_args(argv)
    if unknown:
        bad = unknown[0]
        print(f"error: unexpected argument '{bad}' found\n", file=sys.stderr)
        print(f"  tip: to pass '{bad}' as a value, use '-- {bad}'\n", file=sys.stderr)
        print("Usage: executable [OPTIONS] <TARGET>\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    if not ns.target:
        print('error: the following required arguments were not provided:\n  <TARGET>\n\nUsage: executable <TARGET>\n\nFor more information, try \'--help\'.', file=sys.stderr)
        sys.exit(2)
    return ns

def main(argv=None):
    args = parse_args(sys.argv[1:] if argv is None else argv)
    enc = args.encoding or 'utf-8'
    stdin_base = False
    try:
        if args.target == '-':
            data = sys.stdin.buffer.read()
            base = args.base_url or 'about:blank'
            stdin_base = True
        else:
            p = urlparse(args.target)
            if p.scheme in ('http','https','file'):
                base = args.target
                data, mt = read_url(base, args)
            elif os.path.exists(args.target):
                base = file_url(args.target)
                data, mt = read_url(base, args)
            else:
                hostish = args.target if '://' in args.target else 'http://' + args.target
                try:
                    data, mt = read_url(hostish, args)
                    base = hostish
                except Exception as e:
                    print(f"{hostish} ({e})", file=sys.stderr)
                    print('Error: could not retrieve target document', file=sys.stderr)
                    return 1
        text = data.decode(enc, 'replace')
        parser = Parser(); parser.feed(text)
        transform(parser.root, base, args, stdin_base)
        out = serialize(parser.root)
        if parser.doctype:
            out = out.lstrip()
            out = '<!DOCTYPE html>' + out if parser.doctype.lower().startswith('<!doctype') else parser.doctype + out
        if not args.no_metadata:
            src = 'local source' if base.startswith('file:') or args.target == '-' else base
            stamp = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
            out = f'<!-- Saved from {src} at {stamp} using monolith v2.11.0 -->\n' + out
        if args.mhtml:
            out = build_mhtml(out)
        if args.output and args.output != '-':
            with open(args.output, 'w', encoding=enc, newline='') as f: f.write(out)
        else:
            sys.stdout.write(out)
        return 0
    except BrokenPipeError:
        return 0
    except Exception as e:
        print('Error:', e, file=sys.stderr)
        return 1

if __name__ == '__main__':
    sys.exit(main())
