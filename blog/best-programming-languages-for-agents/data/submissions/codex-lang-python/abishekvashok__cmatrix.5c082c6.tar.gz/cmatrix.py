#!/usr/bin/env python3
import os
import random
import select
import signal
import sys
import termios
import time
import tty


USAGE = """ Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
"""

VERSION = """ CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)
Email: abishekvashok@gmail.com
Web: https://github.com/abishekvashok/cmatrix
"""

INVALID_COLOR = """ Invalid color selection
 Valid colors are green, red, blue, white, yellow, cyan, magenta and black.
"""

COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
}

KEY_COLORS = {
    "!": "red",
    "@": "green",
    "#": "yellow",
    "$": "blue",
    "%": "magenta",
    "^": "cyan",
    "&": "white",
    ")": "black",
}

ASCII_CHARS = tuple("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz@#$%&*+-=<>")
JAPANESE_CHARS = tuple("日ﾊﾐﾋｰｳｼﾅﾓﾆｻﾜﾂｵﾘｱﾎﾃﾏｹﾒｴｶｷﾑﾕﾗｾﾈｽﾀﾇﾍ")


class Options:
    def __init__(self):
        self.async_scroll = False
        self.bold = 0
        self.classic = False
        self.japanese = False
        self.force = False
        self.linux = False
        self.lock = False
        self.old = False
        self.screensaver = False
        self.xterm = False
        self.rainbow = False
        self.lambda_mode = False
        self.changing = False
        self.delay = 4
        self.color = "green"
        self.message = None
        self.tty_path = None


def print_usage():
    sys.stdout.write(USAGE)


def parse_args(argv):
    opts = Options()
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--help":
            print_usage()
            return None, 0
        if not arg.startswith("-") or arg == "-":
            print_usage()
            return None, 0
        if arg == "--version":
            print_usage()
            return None, 0

        j = 1
        while j < len(arg):
            ch = arg[j]
            if ch in ("h", "?"):
                print_usage()
                return None, 0
            if ch == "V":
                sys.stdout.write(VERSION)
                return None, 0
            if ch == "a":
                opts.async_scroll = True
            elif ch == "b":
                opts.bold = 1
            elif ch == "B":
                opts.bold = 2
            elif ch == "n":
                opts.bold = 0
            elif ch == "c":
                opts.japanese = True
            elif ch == "f":
                opts.force = True
            elif ch == "l":
                opts.linux = True
            elif ch == "L":
                opts.lock = True
                if opts.message is None:
                    opts.message = "Computer locked."
            elif ch == "o":
                opts.old = True
            elif ch == "s":
                opts.screensaver = True
            elif ch == "x":
                opts.xterm = True
            elif ch == "r":
                opts.rainbow = True
            elif ch == "m":
                opts.lambda_mode = True
            elif ch == "k":
                opts.changing = True
            elif ch in ("u", "C", "M", "t"):
                if j != len(arg) - 1:
                    val = arg[j + 1 :]
                    j = len(arg)
                else:
                    i += 1
                    if i >= len(argv):
                        print_usage()
                        return None, 0
                    val = argv[i]
                if ch == "u":
                    try:
                        opts.delay = int(val)
                    except ValueError:
                        opts.delay = 4
                    if opts.delay < 0:
                        opts.delay = 0
                elif ch == "C":
                    val = val.lower()
                    if val not in COLORS:
                        sys.stdout.write(INVALID_COLOR)
                        return None, 0
                    opts.color = val
                elif ch == "M":
                    opts.message = val
                else:
                    opts.tty_path = val
            else:
                print_usage()
                return None, 0
            j += 1
        i += 1
    return opts, None


def terminal_size():
    try:
        size = os.get_terminal_size(sys.stdout.fileno())
        return max(1, size.columns), max(1, size.lines)
    except OSError:
        return 80, 24


def choose_char(opts):
    if opts.lambda_mode:
        return "λ"
    chars = JAPANESE_CHARS if opts.japanese else ASCII_CHARS
    return random.choice(chars)


def enter_screen():
    sys.stdout.write("\x1b[?1049h\x1b[22;0;0t\x1b[?25l\x1b[H\x1b[2J")
    sys.stdout.flush()


def leave_screen():
    sys.stdout.write("\x1b[0m\x1b[?25h\x1b[H\x1b[2J\x1b[?1049l")
    sys.stdout.flush()


def set_stdin_raw():
    if not sys.stdin.isatty():
        return None
    old = termios.tcgetattr(sys.stdin.fileno())
    tty.setcbreak(sys.stdin.fileno())
    return old


def restore_stdin(old):
    if old is not None:
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)


def run_matrix(opts):
    term = os.environ.get("TERM", "")
    if term in ("", "unknown"):
        sys.stderr.write("Error opening terminal: unknown.\n")
        return 1

    random.seed()
    cols, rows = terminal_size()
    heads = [random.randrange(-rows, rows) for _ in range(cols)]
    lengths = [random.randrange(4, max(5, rows)) for _ in range(cols)]
    speeds = [random.randint(1, 3) if opts.async_scroll else 1 for _ in range(cols)]
    ticks = [0] * cols
    base_delay = max(0.005, min(10, opts.delay) * 0.01)
    current_color = opts.color
    running = True

    def on_signal(signum, frame):
        nonlocal running
        running = False

    previous_int = signal.signal(signal.SIGINT, on_signal)
    previous_term = signal.signal(signal.SIGTERM, on_signal)
    old_term = set_stdin_raw()
    enter_screen()
    try:
        frame = 0
        input_closed = False
        while running:
            if not input_closed and sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
                ch = sys.stdin.read(1)
                if ch == "":
                    input_closed = True
                elif opts.screensaver:
                    break
                elif ch == "q" and not opts.lock:
                    break
                elif ch == "a":
                    opts.async_scroll = not opts.async_scroll
                    speeds = [random.randint(1, 3) if opts.async_scroll else 1 for _ in range(cols)]
                elif ch == "b":
                    opts.bold = 1
                elif ch == "B":
                    opts.bold = 2
                elif ch == "n":
                    opts.bold = 0
                elif ch in "0123456789":
                    base_delay = max(0.005, int(ch) * 0.01)
                elif ch in KEY_COLORS:
                    current_color = KEY_COLORS[ch]

            if frame == 0:
                sys.stdout.write("\x1b[H\x1b[2J")
            for col in range(cols):
                ticks[col] += 1
                if ticks[col] < speeds[col]:
                    continue
                ticks[col] = 0
                head = heads[col]
                tail = head - lengths[col]
                if tail >= 0 and tail < rows:
                    sys.stdout.write(f"\x1b[{tail + 1};{col + 1}H ")
                if 0 <= head < rows:
                    if opts.rainbow:
                        code = random.choice(list(COLORS.values()))
                    else:
                        code = COLORS[current_color]
                    attr = "1;" if opts.bold == 2 or (opts.bold == 1 and random.randrange(3) == 0) else ""
                    sys.stdout.write(f"\x1b[{head + 1};{col + 1}H\x1b[{attr}{code}m{choose_char(opts)}")
                if 0 <= head - 1 < rows and opts.bold != 2:
                    sys.stdout.write(f"\x1b[{head};{col + 1}H\x1b[{COLORS[current_color]}m{choose_char(opts) if opts.changing else ' '}")
                heads[col] += 1
                if heads[col] - lengths[col] > rows:
                    heads[col] = random.randrange(-rows, 0)
                    lengths[col] = random.randrange(4, max(5, rows))
                    speeds[col] = random.randint(1, 3) if opts.async_scroll else 1

            if opts.message:
                msg = opts.message[: max(0, cols - 2)]
                row = rows // 2 + 1
                col = max(1, (cols - len(msg)) // 2 + 1)
                sys.stdout.write(f"\x1b[{row};{col}H\x1b[37;1m{msg}\x1b[{COLORS[current_color]}m")

            sys.stdout.flush()
            frame += 1
            time.sleep(base_delay)
    finally:
        leave_screen()
        restore_stdin(old_term)
        signal.signal(signal.SIGINT, previous_int)
        signal.signal(signal.SIGTERM, previous_term)
    return 0


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    opts, status = parse_args(argv)
    if status is not None:
        return status
    return run_matrix(opts)


if __name__ == "__main__":
    raise SystemExit(main())
