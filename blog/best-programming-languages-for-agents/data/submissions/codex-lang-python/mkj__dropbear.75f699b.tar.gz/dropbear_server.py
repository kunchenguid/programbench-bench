#!/usr/bin/env python3
import os
import signal
import socket
import sys
import time


VERSION = "2025.89"
DEFAULT_KEYS = [
    "/etc/dropbear/dropbear_rsa_host_key",
    "/etc/dropbear/dropbear_ecdsa_host_key",
    "/etc/dropbear/dropbear_ed25519_host_key",
]

HELP = f"""Dropbear server v{VERSION} https://matt.ucc.asn.au/dropbear/dropbear.html
Usage: ./executable [options]
-b bannerfile\tDisplay the contents of bannerfile before user login
\t\t(default: none)
-r keyfile      Specify hostkeys (repeatable)
\t\tdefaults: 
\t\t- rsa /etc/dropbear/dropbear_rsa_host_key
\t\t- ecdsa /etc/dropbear/dropbear_ecdsa_host_key
\t\t- ed25519 /etc/dropbear/dropbear_ed25519_host_key
-D\t\tDirectory containing authorized_keys file
-R\t\tCreate hostkeys as required
-F\t\tDon't fork into background
-e\t\tPass on server process environment to child process
(Syslog support not compiled in, using stderr)
-m\t\tDon't display the motd on login
-w\t\tDisallow root logins
-G\t\tRestrict logins to members of specified group
-s\t\tDisable password logins
-g\t\tDisable password logins for root
-B\t\tAllow blank password logins
-t\t\tEnable two-factor authentication (both password and public key required)
-T\t\tMaximum authentication tries (default 10)
-j\t\tDisable local port forwarding
-k\t\tDisable remote port forwarding
-a\t\tAllow connections to forwarded ports from any host
-c command\tForce executed command
-p [address:]port
\t\tListen on specified tcp port (and optionally address),
\t\tup to 10 can be specified
\t\t(default port is 22 if none specified)
-P PidFile\tCreate pid file PidFile
\t\t(default /var/run/dropbear.pid)
-l <interface>
\t\tinterface to bind on
-i\t\tStart for inetd
-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)
-K <keepalive>  (0 is never, default 0, in seconds)
-I <idle_timeout>  (0 is never, default 0, in seconds)
-z    disable QoS
-V    Version
"""


class EarlyExit(Exception):
    def __init__(self, message, status=1):
        super().__init__(message)
        self.message = message
        self.status = status


def log(message):
    stamp = time.strftime("%b %d %H:%M:%S", time.localtime())
    print(f"[{os.getpid()}] {stamp} {message}", file=sys.stderr)


def show_help(status, invalid=None):
    if invalid is not None:
        print(f"Invalid option {invalid}", file=sys.stderr)
    print(HELP, end="", file=sys.stderr)
    return status


def need_arg(argv, index, opt, attached):
    if attached:
        return attached, index
    if index + 1 >= len(argv):
        raise EarlyExit("Missing argument")
    return argv[index + 1], index + 1


def parse_args(argv):
    cfg = {
        "hostkeys": [],
        "ports": [],
        "create_keys": False,
        "foreground": False,
        "inetd": False,
        "pidfile": None,
        "banner": None,
    }
    no_arg = set("RFemwsgBtjkaz")
    needs = set("brDGTcpPlWKI")

    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "":
            i += 1
            continue
        if arg == "--":
            break
        if not arg.startswith("-") or arg == "-":
            i += 1
            continue
        if arg.startswith("--"):
            raise ValueError("--")

        cluster = arg[1:]
        pos = 0
        while pos < len(cluster):
            opt = cluster[pos]
            rest = cluster[pos + 1 :]
            if opt == "h":
                raise SystemExit(show_help(0))
            if opt == "V":
                print(f"Dropbear v{VERSION}", file=sys.stderr)
                raise SystemExit(0)
            if opt in needs:
                val, i = need_arg(argv, i, opt, rest)
                if opt == "r":
                    cfg["hostkeys"].append(val)
                elif opt == "p":
                    cfg["ports"].append(val)
                elif opt == "P":
                    cfg["pidfile"] = val
                elif opt == "b":
                    cfg["banner"] = val
                elif opt == "T":
                    try:
                        int(val)
                    except ValueError:
                        raise EarlyExit(f"Bad maxauthtries '{val}'")
                elif opt == "W":
                    try:
                        window = int(val)
                    except ValueError:
                        log(f"Bad recv window '{val}', using 24576")
                    else:
                        if window > 10 * 1024 * 1024:
                            log(f"Bad recv window '{val}', using 10485760")
                elif opt in ("K", "I"):
                    try:
                        int(val)
                    except ValueError:
                        name = "keepalive" if opt == "K" else "idle_timeout"
                        raise EarlyExit(f"Bad {name} '{val}'")
                pos = len(cluster)
                continue
            if opt in no_arg:
                if opt == "R":
                    cfg["create_keys"] = True
                elif opt == "F":
                    cfg["foreground"] = True
                elif opt == "i":
                    cfg["inetd"] = True
                pos += 1
                continue
            raise ValueError(f"-{opt}")
        i += 1
    return cfg


def validate_banner(path):
    if not path:
        return
    try:
        size = os.path.getsize(path)
    except OSError:
        log(f"Error opening banner file '{path}'")
        return
    if size > 2050:
        log("Banner file too large, max is 2050 bytes")


def check_hostkeys(cfg):
    keys = cfg["hostkeys"] or DEFAULT_KEYS
    if cfg["create_keys"]:
        return True
    ok = False
    for key in keys:
        if os.path.exists(key):
            log("Early exit: String too long")
            raise SystemExit(1)
        log(f"Failed loading {key}")
    log("Early exit: No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.")
    return False


def parse_listen(spec):
    if not spec:
        return "0.0.0.0", 22
    if spec.startswith("[") and "]:" in spec:
        host, port = spec[1:].split("]:", 1)
        return host, int(port)
    if ":" in spec:
        host, port = spec.rsplit(":", 1)
        return host or "0.0.0.0", int(port)
    return "0.0.0.0", int(spec)


def run_server(cfg):
    if cfg["foreground"]:
        log("Not backgrounding")
    if cfg["pidfile"]:
        try:
            with open(cfg["pidfile"], "w", encoding="ascii") as f:
                f.write(str(os.getpid()) + "\n")
        except OSError:
            pass

    listeners = []
    ports = cfg["ports"] or ([] if cfg["inetd"] else ["22"])
    for spec in ports[:10]:
        try:
            host, port = parse_listen(spec)
            family = socket.AF_INET6 if ":" in host and host != "0.0.0.0" else socket.AF_INET
            s = socket.socket(family, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, port))
            s.listen(20)
            listeners.append(s)
        except Exception as e:
            log(f"Failed listening on '{spec}': {e}")
            return 1

    if cfg["inetd"] and not listeners:
        return 0

    stop = False

    def handler(signum, frame):
        nonlocal stop
        stop = True
        log("Early exit: Terminated by signal")

    signal.signal(signal.SIGTERM, handler)
    signal.signal(signal.SIGINT, handler)

    while not stop:
        for s in list(listeners):
            s.settimeout(0.25)
            try:
                conn, _ = s.accept()
            except socket.timeout:
                continue
            except OSError:
                continue
            with conn:
                try:
                    conn.sendall(b"SSH-2.0-dropbear_2025.89\r\n")
                    conn.settimeout(1.0)
                    conn.recv(1024)
                except OSError:
                    pass
    for s in listeners:
        s.close()
    return 1


def main(argv):
    try:
        cfg = parse_args(argv)
    except SystemExit as e:
        return int(e.code or 0)
    except ValueError as e:
        return show_help(1, str(e))
    except EarlyExit as e:
        log(f"Early exit: {e.message}")
        return e.status

    validate_banner(cfg["banner"])
    if not check_hostkeys(cfg):
        return 1
    return run_server(cfg)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
