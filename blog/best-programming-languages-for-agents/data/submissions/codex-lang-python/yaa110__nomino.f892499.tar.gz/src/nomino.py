#!/usr/bin/env python3
import json
import os
import re
import shutil
import sys
from pathlib import Path


VERSION = "nomino 1.6.4"

HELP = """Batch rename utility for developers

Usage: executable [OPTIONS] [[SOURCE] OUTPUT]...

Arguments:
  [[SOURCE] OUTPUT]...  OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option

Options:
  -d, --dir <PATH>         Sets the working directory
      --depth <DEPTH>      Optional value to overwrite inferred subdirectory depth value in 'regex' mode
  -E, --no-extension       Does not preserve the extension of input files in 'sort' and 'regex' options
  -g, --generate <PATH>    Stores a JSON map file in '<PATH>' after renaming files
  -h, --help               Print help (see more with '--help')
  -k, --mkdir              Recursively creates all parent directories of '<OUTPUT>' if they are missing
  -m, --map <PATH>         Sets the path of map file to be used for renaming files [aliases: --from-file]
      --max-depth <DEPTH>  Optional value to set the maximum of subdirectory depth value in 'regex' mode
  -q, --quiet              Does not print the map table to stdout
  -r, --regex <PATTERN>    Regex pattern to match by filenames
  -s, --sort <ORDER>       Sets the order of natural sorting (by name) to rename files using enumerator [possible values: asc, desc]
  -t, --test               Runs in test mode without renaming actual files [aliases: --dry-run]
  -V, --version            Print version
  -w, --overwrite          Overwrites output files, otherwise, a '_' is prepended to filename

OUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information.
"""


def err(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def parse_args(argv):
    opts = {
        "dir": ".",
        "depth": None,
        "no_extension": False,
        "generate": None,
        "mkdir": False,
        "map": None,
        "max_depth": None,
        "quiet": False,
        "regex": None,
        "sort": None,
        "test": False,
        "overwrite": False,
        "pos": [],
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP)
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a in ("-E", "--no-extension"):
            opts["no_extension"] = True
        elif a in ("-k", "--mkdir"):
            opts["mkdir"] = True
        elif a in ("-q", "--quiet"):
            opts["quiet"] = True
        elif a in ("-t", "--test", "--dry-run"):
            opts["test"] = True
        elif a in ("-w", "--overwrite"):
            opts["overwrite"] = True
        elif a in ("-d", "--dir", "-g", "--generate", "-m", "--map", "--from-file", "-r", "--regex", "-s", "--sort", "--depth", "--max-depth"):
            if i + 1 >= len(argv):
                err(f"error: a value is required for '{a}'", 2)
            val = argv[i + 1]
            if a in ("-d", "--dir"):
                opts["dir"] = val
            elif a in ("-g", "--generate"):
                opts["generate"] = val
            elif a in ("-m", "--map", "--from-file"):
                opts["map"] = val
            elif a in ("-r", "--regex"):
                opts["regex"] = val
            elif a in ("-s", "--sort"):
                if val not in ("asc", "desc"):
                    print(f"error: invalid value '{val}' for '--sort <ORDER>'", file=sys.stderr)
                    print("  [possible values: asc, desc]\n", file=sys.stderr)
                    print("For more information, try '--help'.", file=sys.stderr)
                    sys.exit(2)
                opts["sort"] = val
            elif a == "--depth":
                opts["depth"] = int(val)
            elif a == "--max-depth":
                opts["max_depth"] = int(val)
            i += 1
        elif a.startswith("-") and a != "-":
            err(f"error: unexpected argument '{a}' found", 2)
        else:
            opts["pos"].append(a)
        i += 1
    return opts


def natural_key(s):
    parts = re.split(r"(\d+)", s)
    return [int(p) if p.isdigit() else p.lower() for p in parts]


def split_ext(path):
    base = os.path.basename(path)
    root, ext = os.path.splitext(base)
    return root, ext


def file_list(base, max_depth=0, min_depth=0):
    out = []
    for root, dirs, files in os.walk(base):
        relroot = os.path.relpath(root, base)
        depth = 0 if relroot == "." else relroot.count(os.sep) + 1
        if depth > max_depth:
            dirs[:] = []
            continue
        if depth < min_depth:
            continue
        for name in files:
            out.append(name if relroot == "." else os.path.join(relroot, name))
    return out


def format_value(value, pad):
    value = "" if value is None else str(value)
    if pad and re.fullmatch(r"[0-9]+", value):
        return value.zfill(int(pad))
    return value


def render_pattern(pattern, groups, auto_value=None):
    res = []
    i = 0
    auto_group = 1
    while i < len(pattern):
        ch = pattern[i]
        if ch == "{":
            j = pattern.find("}", i + 1)
            if j < 0:
                err("error: [output-format] an unclosed placeholder was found")
            body = pattern[i + 1:j]
            if "{" in body:
                err("error: [output-format] nested placeholders are not supported")
            if ":" in body:
                key, pad = body.split(":", 1)
            else:
                key, pad = body, ""
            if key == "":
                if auto_value is not None:
                    val = auto_value
                else:
                    val = groups.get(str(auto_group), "")
                    auto_group += 1
            else:
                val = groups.get(key, "")
            res.append(format_value(val, pad))
            i = j + 1
        elif ch == "}":
            err("error: [output-format] an unopened placeholder could not be closed by '}'")
        else:
            res.append(ch)
            i += 1
    return "".join(res)


def make_groups(match, relpath):
    groups = {"0": match.group(0)}
    for idx, val in enumerate(match.groups(), 1):
        groups[str(idx)] = val or ""
    groups.update({k: v or "" for k, v in match.groupdict().items()})
    groups.setdefault("filename", os.path.basename(relpath))
    return groups


def unique_target(target, seen, base, overwrite, src=None):
    if overwrite:
        seen.add(target)
        return target
    t = target
    while t in seen or (os.path.exists(os.path.join(base, t)) and t != src):
        d = os.path.dirname(t)
        b = os.path.basename(t)
        t = os.path.join(d, "_" + b) if d else "_" + b
    seen.add(t)
    return t


def build_table(rows):
    if not rows:
        return ""
    w1 = max(len("Input"), *(len(a) for a, _ in rows))
    w2 = max(len("Output"), *(len(b) for _, b in rows))
    sep = "+" + "-" * (w1 + 2) + "+" + "-" * (w2 + 2) + "+"
    lines = [sep, f"| {'Input'.ljust(w1)} | {'Output'.ljust(w2)} |", sep]
    for a, b in rows:
        lines.append(f"| {a.ljust(w1)} | {b.ljust(w2)} |")
    lines.append(sep)
    return "\n".join(lines)


def apply_moves(rows, base, mkdir, overwrite):
    for src, dst in rows:
        sp = os.path.join(base, src)
        dp = os.path.join(base, dst)
        parent = os.path.dirname(dp)
        if mkdir and parent:
            os.makedirs(parent, exist_ok=True)
        try:
            if overwrite and os.path.exists(dp):
                if os.path.isdir(dp):
                    shutil.rmtree(dp)
                else:
                    os.remove(dp)
            os.rename(sp, dp)
        except OSError as e:
            print(f"[error] unable to rename '{src}': {e.strerror} (os error {getattr(e, 'errno', 1)})", file=sys.stderr)
            sys.exit(1)


def infer_depth(regex):
    plain = regex.replace("\\/", "/")
    return plain.count("/")


def compile_regex(pattern):
    try:
        return re.compile(pattern)
    except re.error as e:
        print("error: regex parse error:", file=sys.stderr)
        print(f"    {pattern}", file=sys.stderr)
        print(f"error: {e.msg}", file=sys.stderr)
        sys.exit(1)


def main(argv):
    opts = parse_args(argv)
    base = os.path.abspath(opts["dir"])
    if not os.path.isdir(base):
        err(f"error: '{opts['dir']}' is not a directory")
    os.chdir(base)

    rows = []
    seen = set()
    gen_map = {}

    try:
        if opts["map"]:
            with open(opts["map"], "r", encoding="utf-8") as f:
                mapping = json.load(f)
            if not isinstance(mapping, dict):
                err("error: invalid type: sequence, expected a map at line 1 column 0")
            for src, dst in mapping.items():
                rows.append((str(src), str(dst)))
        elif opts["sort"]:
            if len(opts["pos"]) != 1:
                err("error: an output pattern is required for sort mode")
            pattern = opts["pos"][0]
            names = file_list(base, 0)
            names.sort(key=lambda x: natural_key(os.path.basename(x)))
            if opts["sort"] == "desc":
                names.reverse()
            for n, src in enumerate(names, 1):
                root, ext = split_ext(src)
                groups = {"0": root}
                out = render_pattern(pattern, groups, str(n))
                if not opts["no_extension"]:
                    out += ext
                out = unique_target(out, seen, base, opts["overwrite"], src)
                rows.append((src, out))
                gen_map[out] = src
        else:
            if opts["regex"] is not None:
                if len(opts["pos"]) != 1:
                    err("error: an output pattern is required for regex mode")
                regex, pattern = opts["regex"], opts["pos"][0]
            elif len(opts["pos"]) >= 2:
                regex, pattern = opts["pos"][0], opts["pos"][1]
            else:
                print("error: one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.", file=sys.stderr)
                print("usage: run '/workspace/executable --help' for more information.", file=sys.stderr)
                sys.exit(1)
            cre = compile_regex(regex)
            maxd = infer_depth(regex)
            if opts["max_depth"] is not None:
                maxd = opts["max_depth"]
            if opts["depth"] is not None:
                maxd = max(0, opts["depth"] - 1) if "/" not in regex else opts["depth"]
            mind = maxd if "/" in regex.replace("\\/", "/") else 0
            for src in sorted(file_list(base, maxd, mind), key=natural_key):
                rel = src.replace(os.sep, "/")
                m = cre.search(rel)
                if not m:
                    continue
                _, ext = split_ext(src)
                out = render_pattern(pattern, make_groups(m, rel))
                if not opts["no_extension"]:
                    out += ext
                out = unique_target(out, seen, base, opts["overwrite"], rel)
                rows.append((rel, out))
                gen_map[out] = rel
    except ValueError as e:
        err(f"error: {e}")
    except FileNotFoundError as e:
        err(f"error: {e}")
    except json.JSONDecodeError as e:
        err(f"error: {e}")

    if not opts["test"] and rows:
        apply_moves(rows, base, opts["mkdir"], opts["overwrite"])
    if opts["generate"]:
        with open(opts["generate"], "w", encoding="utf-8") as f:
            json.dump(gen_map, f, indent=2)
            f.write("\n")
    if not opts["quiet"] and rows:
        print(build_table(rows))


if __name__ == "__main__":
    main(sys.argv[1:])
