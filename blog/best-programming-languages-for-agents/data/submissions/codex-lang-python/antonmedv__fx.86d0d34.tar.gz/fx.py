#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys

VERSION = "39.2.0"


HELP = """
  fx 39.2.0
    Terminal JSON viewer

  Usage
    fx data.json
    fx data.json .field
    curl ... | fx

  Flags
    -h, --help            print help
    -v, --version         print version
    --themes              print themes
    --comp <shell>        print completion script
    -r, --raw             treat input as a raw string
    -s, --slurp           read all inputs into an array
    --yaml                parse input as YAML
    --toml                parse input as TOML
    --strict              strict mode
    --no-inline           disable inlining in output
    --game-of-life        play the game of life

  More info
    https://fx.wtf

  Author
    Anton Medvedev <anton@medv.io>
""".strip("\n")


def dump(value):
    if isinstance(value, str):
        return value + "\n"
    if value is True:
        return "true\n"
    if value is False:
        return "false\n"
    if value is None:
        return "null\n"
    return json.dumps(value, ensure_ascii=False, indent=2) + "\n"


def parse_json_stream(text, slurp=False):
    dec = json.JSONDecoder()
    vals = []
    i = 0
    n = len(text)
    while True:
        while i < n and text[i].isspace():
            i += 1
        if i >= n:
            break
        val, end = dec.raw_decode(text, i)
        vals.append(val)
        i = end
    if slurp:
        return vals
    if len(vals) == 1:
        return vals[0]
    return vals


def parse_scalar(s):
    s = s.strip()
    if s in ("true", "True"):
        return True
    if s in ("false", "False"):
        return False
    if s in ("null", "None", "~"):
        return None
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        return s[1:-1]
    try:
        return int(s)
    except ValueError:
        pass
    try:
        return float(s)
    except ValueError:
        return s


def parse_yaml(text):
    # Small YAML subset good enough for common docs/tests: mappings, lists, scalars.
    lines = []
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if line.strip():
            lines.append(line)
    if not lines:
        return None
    if all(l.lstrip().startswith("- ") for l in lines):
        return [parse_scalar(l.lstrip()[2:]) for l in lines]
    out = {}
    for line in lines:
        if ":" in line:
            k, v = line.split(":", 1)
            out[k.strip().strip('"\'')] = parse_scalar(v)
    return out


def parse_toml(text):
    try:
        import tomllib
        return tomllib.loads(text)
    except Exception:
        out = {}
        cur = out
        for raw in text.splitlines():
            line = raw.split("#", 1)[0].strip()
            if not line:
                continue
            if line.startswith("[") and line.endswith("]"):
                cur = out
                for part in line[1:-1].split("."):
                    cur = cur.setdefault(part, {})
            elif "=" in line:
                k, v = line.split("=", 1)
                cur[k.strip()] = parse_scalar(v)
        return out


def read_inputs(args, opts):
    files = []
    exprs = []
    for a in args:
        if os.path.exists(a) and not a.startswith("."):
            files.append(a)
        else:
            exprs.append(a)
    data = ""
    if files:
        parts = []
        for f in files:
            with open(f, "r", encoding="utf-8") as fh:
                parts.append(fh.read())
        data = "\n".join(parts)
    else:
        data = sys.stdin.read()
    if opts.raw:
        value = data
    elif opts.yaml:
        value = parse_yaml(data)
    elif opts.toml:
        value = parse_toml(data)
    else:
        value = parse_json_stream(data, opts.slurp)
    return value, exprs


def get_field(v, key):
    if isinstance(v, dict):
        return v.get(key)
    if isinstance(v, list):
        if key == "length":
            return len(v)
        return [get_field(x, key) for x in v]
    if isinstance(v, str) and key == "length":
        return len(v)
    return None


def tokenize_path(expr):
    tokens = []
    i = 0
    n = len(expr)
    if expr == ".":
        return []
    if expr.startswith("."):
        i = 1
    while i < n:
        c = expr[i]
        if c == ".":
            i += 1
            continue
        if expr.startswith("[]", i):
            tokens.append(("wild", None))
            i += 2
            continue
        if c == "[":
            j = expr.find("]", i)
            if j < 0:
                raise ValueError("missing ]")
            inner = expr[i + 1:j].strip()
            if inner in ("", "*"):
                tokens.append(("wild", None))
            elif (inner[0:1] in "\"'" and inner[-1:] == inner[0]):
                tokens.append(("field", inner[1:-1]))
            else:
                tokens.append(("index", int(inner)))
            i = j + 1
            continue
        m = re.match(r"[A-Za-z_$][\w$-]*", expr[i:])
        if not m:
            raise ValueError("bad path")
        tokens.append(("field", m.group(0)))
        i += len(m.group(0))
    return tokens


def apply_path(value, expr):
    vals = [value]
    for kind, arg in tokenize_path(expr):
        new = []
        for v in vals:
            if kind == "wild":
                if isinstance(v, list):
                    new.extend(v)
                elif isinstance(v, dict):
                    new.extend(v.values())
            elif kind == "index":
                if isinstance(v, list) and -len(v) <= arg < len(v):
                    new.append(v[arg])
            elif kind == "field":
                if isinstance(v, list):
                    new.append([get_field(x, arg) for x in v])
                else:
                    new.append(get_field(v, arg))
        vals = new
    if not vals:
        return None
    if len(vals) == 1:
        return vals[0]
    return vals


def eval_simple(obj, expr, env_name="x"):
    expr = expr.strip()
    if expr in ("x", "this", ".", env_name):
        return obj
    if expr.startswith("return "):
        expr = expr[7:].strip()
    expr = re.sub(r"\bthis\.", "x.", expr)
    expr = re.sub(rf"\b{re.escape(env_name)}\.", "x.", expr)
    m = re.fullmatch(r"Object\.keys\((?:x|this|" + re.escape(env_name) + r")\)", expr)
    if m:
        return list(obj.keys()) if isinstance(obj, dict) else []
    m = re.fullmatch(r"Object\.values\((?:x|this|" + re.escape(env_name) + r")\)", expr)
    if m:
        return list(obj.values()) if isinstance(obj, dict) else []
    m = re.fullmatch(r"Object\.entries\((?:x|this|" + re.escape(env_name) + r")\)", expr)
    if m:
        return [[k, v] for k, v in obj.items()] if isinstance(obj, dict) else []
    if expr in ("length", "len"):
        return len(obj) if hasattr(obj, "__len__") else None
    if expr in (".length", "x.length"):
        return len(obj) if hasattr(obj, "__len__") else None
    if expr.endswith(".length"):
        base = eval_simple(obj, expr[:-7], env_name)
        return len(base) if hasattr(base, "__len__") else None
    for op in ["===", "==", "!=", ">=", "<=", ">", "<"]:
        if op in expr:
            left, right = expr.split(op, 1)
            a = eval_simple(obj, left, env_name)
            b = parse_scalar(right)
            return {"===": a == b, "==": a == b, "!=": a != b, ">=": a >= b, "<=": a <= b, ">": a > b, "<": a < b}[op]
    for op in ["+", "-", "*", "/"]:
        parts = expr.split(op, 1)
        if len(parts) == 2:
            a = eval_simple(obj, parts[0], env_name)
            b = parse_scalar(parts[1])
            if op == "+": return a + b
            if op == "-": return a - b
            if op == "*": return a * b
            if op == "/": return a / b
    if expr.startswith("x."):
        return apply_path(obj, "." + expr[2:])
    if expr.startswith("."):
        return apply_path(obj, expr)
    return apply_path(obj, "." + expr) if re.fullmatch(r"[A-Za-z_$][\w$-]*", expr) else parse_scalar(expr)


def parse_arrow(expr):
    if "=>" not in expr:
        return None
    left, body = expr.split("=>", 1)
    left = left.strip()
    body = body.strip()
    if left.startswith("(") and left.endswith(")"):
        left = left[1:-1].split(",", 1)[0].strip()
    return left or "x", body


def apply_expr(value, expr):
    expr = expr.strip()
    m = re.fullmatch(r"(?:\.?map|map)\((.*)\)", expr)
    if m and isinstance(value, list):
        inner = m.group(1).strip()
        ar = parse_arrow(inner)
        if ar:
            return [eval_simple(x, ar[1], ar[0]) for x in value]
    m = re.fullmatch(r"(?:\.?filter|filter)\((.*)\)", expr)
    if m and isinstance(value, list):
        inner = m.group(1).strip()
        ar = parse_arrow(inner)
        if ar:
            return [x for x in value if eval_simple(x, ar[1], ar[0])]
    arrow = parse_arrow(expr)
    if arrow:
        name, body = arrow
        return eval_simple(value, body, name)
    return eval_simple(value, expr)


def print_themes():
    sample = {
        "string": "Fox jumps over the lazy dog",
        "number": 1234567890,
        "boolean": True,
        "null": None,
        "collapsed": {"preview": "…"},
    }
    for i in range(10):
        print(f'export FX_THEME="{i}"')
        print(json.dumps(sample, ensure_ascii=False, indent=2).replace('"…"', "…"))


def completion(shell):
    if shell == "bash":
        return "complete -o filenames -C fx fx\n"
    if shell == "zsh":
        return "#compdef fx\n_arguments '*:file:_files'\n"
    if shell == "fish":
        return "complete -c fx -f\n"
    return ""


def main(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP)
        return 0
    if "--version" in argv or "-v" in argv:
        print(VERSION)
        return 0
    if "--themes" in argv:
        print_themes()
        return 0
    if "--game-of-life" in argv:
        print("Game of Life is not available in this reimplementation.")
        return 0
    if "--comp" in argv:
        i = argv.index("--comp")
        shell = argv[i + 1] if i + 1 < len(argv) else "bash"
        sys.stdout.write(completion(shell))
        return 0

    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-r", "--raw", action="store_true")
    p.add_argument("-s", "--slurp", action="store_true")
    p.add_argument("--yaml", action="store_true")
    p.add_argument("--toml", action="store_true")
    p.add_argument("--strict", action="store_true")
    p.add_argument("--no-inline", action="store_true")
    p.add_argument("args", nargs="*")
    opts = p.parse_args(argv)
    try:
        value, exprs = read_inputs(opts.args, opts)
        for e in exprs:
            value = apply_expr(value, e)
        sys.stdout.write(dump(value))
        return 0
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
