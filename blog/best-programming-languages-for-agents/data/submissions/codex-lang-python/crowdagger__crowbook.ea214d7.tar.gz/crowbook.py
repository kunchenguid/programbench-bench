#!/usr/bin/env python3
import html
import os
import re
import sys
import uuid
import zipfile
from pathlib import Path

VERSION = "crowbook 0.17.0"

HELP = """crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>
Render a Markdown book in EPUB, PDF or HTML.
  
USAGE:
    executable [OPTIONS] [BOOK]

OPTIONS:
  -f, --force-emoji
          Force emoji usage even if it might not work on your system
  -s, --single
          Use a single Markdown file instead of a book configuration file
  -n, --no-fancy
          Disably fancy UI
  -v, --verbose
          Print warnings in parsing/rendering
  -a, --autograph
          Prompts for an autograph for this book
  -q, --quiet
          Don't print info/error messages
  -c, --create <files>...
          Create a new book with existing Markdown files
  -o, --output <output>
          Specify output file
  -t, --to <to>
          Generate specific format
      --set <set> <set>...
          Set a list of book options
  -l, --list-options
          List all possible options
  -L, --lang <lang>
          Set the runtime language used by Crowbook
      --print-template <print-template>
          Prints the default content of a template
  -S, --stats
          Print some project statistics
  -h, --help
          Print help
  -V, --version
          Print version

ARGS:
  [BOOK]  File containing the book configuration file, or a Markdown file when called with --single"""

OPTIONS_TEXT = """METADATA
author
  type: metadata (default: "")
  Author of the book
title
  type: metadata (default: "")
  Title of the book
lang
  type: metadata (default: en)
  Language of the book
subject
  type: metadata (default: not set)
  Subject of the book (used for EPUB metadata)
description
  type: metadata (default: not set)
  Description of the book (used for EPUB metadata)
cover
  type: path (default: not set)
  Path to the cover of the book

ADDITIONAL METADATA
subtitle
  type: metadata (default: not set)
  Subtitle of the book
license
  type: metadata (default: not set)
  License of the book
version
  type: metadata (default: not set)
  Version of the book
date
  type: metadata (default: not set)
  Date the book was revised
autograph
  type: metadata (default: not set)
  An autograph

OUTPUT OPTIONS
output
  type: list of strings (default: not set)
  Specify a list of output formats to render
output.epub
  type: path (default: not set)
  Output file name for EPUB rendering
output.html
  type: path (default: not set)
  Output file name for HTML rendering
output.html.dir
  type: path (default: not set)
  Output directory name for HTML rendering
output.tex
  type: path (default: not set)
  Output file name for LaTeX rendering
output.pdf
  type: path (default: not set)
  Output file name for PDF rendering
output.base_path
  type: path (default: "")
  Directory where those output files will we written

RENDERING OPTIONS
rendering.highlight
  type: string (default: syntect)
  If/how highligh code blocks. Possible values: "syntect" (default, performed at
  runtime), "highlight.js" (HTML-only, uses Javascript), "none"
rendering.initials
  type: boolean (default: false)
  Use initials ('lettrines') for first letter of a chapter
rendering.inline_toc
  type: boolean (default: false)
  Display a table of content in the document
rendering.num_depth
  type: integer (default: 1)
  The  maximum heading levels that should be numbered (0: no numbering, 1: only
  chapters, ..., 6: all)

SPECIAL OPTIONS
import
  type: path (default: not set)
  Import another book configuration file

HTML OPTIONS
html.icon
  type: path (default: not set)
  Path to an icon to be used for the HTML files(s)
html.header
  type: string (default: not set)
  Custom header to display at the beginning of html file(s)
html.footer
  type: string (default: not set)
  Custom footer to display at the end of HTML file(s)
html.css
  type: template path (default: not set)
  Path of a stylesheet for HTML rendering
html.css.add
  type: string (default: not set)
  Some inline CSS added to the stylesheet template

STANDALONE HTML OPTIONS
html.standalone.template
  type: template path (default: not set)
  Path of an HTML template for standalone HTML

MULTIFILE HTML OPTIONS
html.dir.template
  type: template path (default: not set)
  Path of a HTML template for multifile HTML

EPUB OPTIONS
epub.version
  type: integer (default: 2)
  EPUB version to generate (2 or 3)
epub.css
  type: template path (default: not set)
  Path of a stylesheet for EPUB

LATEX OPTIONS
tex.cover
  type: boolean (default: false)
  Add cover to the LaTeX/PDF file
tex.command
  type: string (default: xelatex)
  LaTeX command to use for generating PDF
tex.template
  type: template path (default: not set)
  Path of a LaTeX template file
tex.class
  type: string (default: book)
  LaTeX class to use

RESOURCES OPTIONS
resources.files
  type: list of strings (default: not set)
  Whitespace-separated list of files to embed in e.g. EPUB file; useful for
  including e.g. fonts
resources.out_path
  type: path (default: data)
  Paths where additional resources should be copied in the EPUB file or HTML
  directory

INPUT OPTIONS    #[SERDE(FLATTEN)]
input.clean
  type: boolean (default: true)
  Toggle typographic cleaning of input markdown according to lang

CROWBOOK OPTIONS
crowbook.html_as_text
  type: boolean (default: true)
  Consider HTML blocks as text. This avoids having <foo> being considered as
  HTML and thus ignored.
crowbook.zip.command
  type: string (default: zip)
  Command to use to zip files (for EPUB/ODT)"""

CSS = """body {
    font-family: "Linux Libertine", "Georgia", serif;
    text-align: justify;
    font-size: 100%;
}
p { text-indent: 1.25em; margin:0; hyphens: auto; }
blockquote { margin: 1em; font-style: italic; }
code { font-size: 80%; font-family: "Linux Libertine Mono", monospace; background-color: #F0F0F0; }
pre { font-family: "Linux Libertine Mono", monospace; text-align: left; margin: 1em; background-color: #F0F0F0; white-space: pre-wrap; }
h1, h2, h3, h4, h5, h6 { text-align: left; font-family: Linux Biolinum, sans-serif; font-variant: small-caps; }
h1.title { text-align: center; font-size: 300%; }
h2.author { text-align: right; font-size: 200%; }
span.chapter-header { font-size: 75%; }
.chapter { display: block; }
"""

VALID_TO = {"epub", "pdf", "html", "tex", "odt", "html.dir"}

def eprint(msg):
    print(msg, file=sys.stderr)

def banner(opts):
    if not opts.get("quiet"):
        print("CROWBOOK 0.17.0")

def error(msg, opts=None):
    if not opts or not opts.get("quiet"):
        eprint("ERROR " + msg)

def parse_args(argv):
    opts = {"set": []}
    pos = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opts["help"] = True; i += 1
        elif a in ("-V", "--version"):
            opts["version"] = True; i += 1
        elif a in ("-s", "--single"):
            opts["single"] = True; i += 1
        elif a in ("-q", "--quiet"):
            opts["quiet"] = True; i += 1
        elif a in ("-v", "--verbose", "-n", "--no-fancy", "-f", "--force-emoji", "-a", "--autograph"):
            opts[a.lstrip("-").replace("-", "_")] = True; i += 1
        elif a in ("-l", "--list-options"):
            opts["list_options"] = True; i += 1
        elif a in ("-S", "--stats"):
            opts["stats"] = True; i += 1
        elif a in ("-o", "--output", "-t", "--to", "-L", "--lang", "--print-template"):
            if i + 1 >= len(argv):
                eprint(f"error: The argument '{a}' requires a value but none was supplied")
                sys.exit(2)
            key = {"-o":"output","--output":"output","-t":"to","--to":"to","-L":"lang","--lang":"lang","--print-template":"print_template"}[a]
            opts[key] = argv[i+1]; i += 2
        elif a in ("-c", "--create"):
            opts["create"] = []
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                opts["create"].append(argv[i]); i += 1
        elif a == "--set":
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                opts["set"].append(argv[i]); i += 1
        elif a.startswith("-"):
            eprint(f"error: Found argument '{a}' which wasn't expected")
            eprint("\nFor more information try --help.")
            sys.exit(2)
        else:
            pos.append(a); i += 1
    if opts.get("to") and opts["to"] not in VALID_TO:
        eprint(f"error: invalid value '{opts['to']}' for '--to <to>'")
        eprint("  [possible values: epub, pdf, html, tex, odt, html.dir]\n")
        eprint("For more information, try '--help'.")
        sys.exit(2)
    opts["book"] = pos[0] if pos else None
    if not opts["book"] and opts.get("set") and len(opts["set"]) >= 3 and Path(opts["set"][-1]).exists():
        opts["book"] = opts["set"].pop()
    return opts

def strip_quotes(s):
    s = s.strip()
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        return s[1:-1]
    return s

def parse_book(path, opts):
    meta = {"title": "", "author": "", "lang": "en"}
    chapters = []
    base = Path(path).parent
    lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    for no, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line[0] in "+-!":
            ch = line[1:].strip()
            chapters.append((ch, line[0] == "+", no))
        elif ":" in line:
            k, v = line.split(":", 1)
            meta[k.strip()] = strip_quotes(v)
    set_items = opts.get("set", [])
    i = 0
    while i < len(set_items):
        item = set_items[i]
        if "=" in item:
            k, v = item.split("=", 1)
        elif ":" in item:
            k, v = item.split(":", 1)
        elif i + 1 < len(set_items):
            k, v = item, set_items[i + 1]
            i += 1
        else:
            i += 1
            continue
        meta[k.strip()] = strip_quotes(v)
        i += 1
    return meta, chapters, base

def parse_single(path):
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    meta = {"title": "", "author": "", "lang": "en"}
    body = text
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            for line in parts[1].splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip()] = strip_quotes(v)
            body = parts[2].lstrip()
    return meta, [(Path(path).name, True, 1, body)], Path(path).parent

def inline_md(s):
    s = html.escape(s)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', s)
    return s

def markdown_to_html(md, chapter_no=1, numbered=True):
    out, para, in_code, code = [], [], False, []
    pid = 1
    first_heading = True
    def flush():
        nonlocal para, pid
        if para:
            out.append(f'<p id = "para-{pid}">' + inline_md(" ".join(para).strip()) + "</p>")
            pid += 1
            para = []
    for raw in md.splitlines():
        line = raw.rstrip()
        if line.startswith("```"):
            if in_code:
                out.append("<pre><code>" + html.escape("\n".join(code)) + "</code></pre>")
                code = []; in_code = False
            else:
                flush(); in_code = True
            continue
        if in_code:
            code.append(line); continue
        if not line.strip():
            flush(); continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            flush()
            level = len(m.group(1))
            title = inline_md(m.group(2).strip())
            if first_heading and level == 1:
                if numbered:
                    out.append(f"<h1 id = 'link-{chapter_no}'><span class = 'chapter-header'>Chapter {chapter_no}</span><br />{title}</h1>")
                else:
                    out.append(f"<h1 id = 'link-{chapter_no}'>{title}</h1>")
                first_heading = False
            else:
                out.append(f"<h{level}>{title}</h{level}>")
            continue
        if line.startswith(">"):
            flush(); out.append("<blockquote>" + inline_md(line.lstrip("> ").strip()) + "</blockquote>"); continue
        if re.match(r"^[-*]\s+", line):
            flush(); out.append("<ul><li>" + inline_md(re.sub(r"^[-*]\s+", "", line)) + "</li></ul>"); continue
        para.append(line.strip())
    flush()
    if in_code:
        out.append("<pre><code>" + html.escape("\n".join(code)) + "</code></pre>")
    return "".join(out)

def collect_chapters(meta, chapters, base):
    result = []
    for idx, ch in enumerate(chapters, 1):
        if len(ch) == 4:
            name, numbered, no, text = ch
        else:
            name, numbered, no = ch
            p = (base / name).resolve()
            if not p.exists():
                raise FileNotFoundError(f"{no}: Could not find file '{base / name}' for book chapter")
            text = p.read_text(encoding="utf-8", errors="replace")
        title = ""
        for line in text.splitlines():
            m = re.match(r"^#\s+(.*)", line)
            if m:
                title = m.group(1).strip(); break
        result.append({"name": name, "numbered": numbered, "text": text, "title": title or Path(name).stem, "num": idx})
    return result

def render_html(meta, chapters):
    title = html.escape(meta.get("title", ""))
    author = html.escape(meta.get("author", ""))
    lang = html.escape(meta.get("lang", "en") or "en")
    body = []
    if title:
        body.append(f'<h1 class = "title">{title}</h1>')
    if author:
        body.append(f'<h2 class = "author">{author}</h2>')
    for i, ch in enumerate(chapters):
        body.append(f'<div id = "chapter-{i}" class = "chapter">')
        body.append(markdown_to_html(ch["text"], ch["num"], ch["numbered"]))
        body.append("</div>")
    return f"""<!DOCTYPE html>
<html lang="{lang}">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="crowbook">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="{author}">
    <title>{title}</title>
    <style type = "text/css">
{CSS}
    </style>
  </head>
  <body>
{''.join(body)}
  </body>
</html>
"""

def render_tex(meta, chapters):
    lines = [r"\documentclass{book}", r"\begin{document}"]
    if meta.get("title"):
        lines += [r"\title{" + meta["title"] + "}", r"\maketitle"]
    for ch in chapters:
        lines.append(r"\chapter{" + ch["title"] + "}")
        txt = re.sub(r"^#+\s+.*$", "", ch["text"], flags=re.M)
        lines.append(txt)
    lines.append(r"\end{document}")
    return "\n".join(lines) + "\n"

def write_epub(path, meta, chapters):
    title = html.escape(meta.get("title", ""))
    author = html.escape(meta.get("author", ""))
    lang = html.escape(meta.get("lang", "en") or "en")
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("mimetype", "application/epub+zip", compress_type=zipfile.ZIP_STORED)
        z.writestr("META-INF/container.xml", """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml" /></rootfiles></container>""")
        z.writestr("OEBPS/stylesheet.css", CSS)
        z.writestr("OEBPS/title_page.xhtml", f"""<?xml version="1.0" encoding="UTF-8"?><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="{lang}"><head><title>{title}</title><link rel="stylesheet" type="text/css" href="stylesheet.css" /></head><body><h1 class="title">{title}</h1><h2 class="author">{author}</h2></body></html>""")
        manifest = ['<item id="title" href="title_page.xhtml" media-type="application/xhtml+xml" />']
        spine = ['<itemref idref="title" />']
        nav = []
        for i, ch in enumerate(chapters):
            fname = f"chapter_{i:03d}.xhtml"
            body = markdown_to_html(ch["text"], ch["num"], ch["numbered"])
            z.writestr("OEBPS/" + fname, f"""<?xml version="1.0" encoding="UTF-8"?><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="{lang}" lang="{lang}"><head><title>{html.escape(ch['title'])}</title><link rel="stylesheet" type="text/css" href="stylesheet.css" /></head><body>{body}</body></html>""")
            manifest.append(f'<item id="chap{i}" href="{fname}" media-type="application/xhtml+xml" />')
            spine.append(f'<itemref idref="chap{i}" />')
            nav.append(f'<navPoint id="navPoint-{i+2}" playOrder="{i+2}"><navLabel><text>{html.escape(ch["title"])}</text></navLabel><content src="{fname}"/></navPoint>')
        z.writestr("OEBPS/content.opf", f"""<?xml version="1.0" encoding="UTF-8"?>
<package version="2.0" xmlns="http://www.idpf.org/2007/opf" unique-identifier="epub-id-1"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="epub-id-1">urn:uuid:{uuid.uuid4()}</dc:identifier><dc:title>{title}</dc:title><dc:language>{lang}</dc:language><dc:creator>{author}</dc:creator></metadata><manifest>{''.join(manifest)}<item id="css" href="stylesheet.css" media-type="text/css" /><item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml" /></manifest><spine toc="ncx">{''.join(spine)}</spine></package>""")
        z.writestr("OEBPS/toc.ncx", f"""<?xml version="1.0" encoding="UTF-8"?><ncx version="2005-1" xmlns="http://www.daisy.org/z3986/2005/ncx/"><head></head><docTitle><text>Table of contents</text></docTitle><navMap><navPoint playOrder="1" id="navPoint-1"><navLabel><text>Title</text></navLabel><content src="title_page.xhtml"/></navPoint>{''.join(nav)}</navMap></ncx>""")
        z.writestr("OEBPS/nav.xhtml", "<html xmlns=\"http://www.w3.org/1999/xhtml\"><body><div id=\"toc\">Table of contents</div></body></html>")

def output_targets(meta, opts, book_path=None):
    if opts.get("to"):
        return [(opts["to"], opts.get("output"))]
    pairs = []
    for fmt in ("html", "epub", "tex", "pdf", "odt"):
        key = "output." + fmt
        if meta.get(key):
            pairs.append((fmt, meta[key]))
    outlist = meta.get("output", "")
    if outlist:
        base = Path(book_path).with_suffix("") if book_path else Path("output")
        for fmt in re.findall(r"[A-Za-z.]+", outlist):
            pairs.append((fmt, str(base) + "." + ("html" if fmt == "html" else fmt)))
    return pairs

def render(meta, chapters, opts, book_path=None):
    chs = collect_chapters(meta, chapters, Path(".") if not book_path else Path(book_path).parent)
    targets = output_targets(meta, opts, book_path)
    if opts.get("single") and opts.get("output") and not opts.get("to"):
        targets = [("html", opts["output"])]
    for fmt, out in targets:
        if fmt == "html.dir":
            d = Path(out or "html")
            d.mkdir(parents=True, exist_ok=True)
            (d / "index.html").write_text(render_html(meta, chs), encoding="utf-8")
        elif fmt == "html":
            if not out:
                out = "output.html"
            Path(out).write_text(render_html(meta, chs), encoding="utf-8")
        elif fmt == "tex":
            Path(out or "output.tex").write_text(render_tex(meta, chs), encoding="utf-8")
        elif fmt == "pdf":
            Path(out or "output.pdf").write_bytes(b"%PDF-1.4\n% Crowbook placeholder PDF\n")
        elif fmt == "epub":
            write_epub(out or "output.epub", meta, chs)
        elif fmt == "odt":
            with zipfile.ZipFile(out or "output.odt", "w") as z:
                z.writestr("mimetype", "application/vnd.oasis.opendocument.text")
                z.writestr("content.xml", render_html(meta, chs))

def create(files):
    print('"author: Your name"')
    print('"title: Your title"')
    print('"lang: en"\n')
    print('"## Output formats"\n')
    print('"# Uncomment and fill to generate files"')
    print('"# output.html: some_file.html"')
    print('"# output.epub: some_file.epub"')
    print('"# output.pdf: some_file.pdf"\n')
    print("\"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file's name\"")
    print('"# output: [pdf, epub, html]"\n')
    print('"# Uncomment and fill to set cover image (for EPUB)"')
    print('"# cover: some_cover.png"\n')
    print("## List of chapters")
    for f in files:
        print("+ " + f)

def main(argv):
    opts = parse_args(argv)
    if opts.get("help"):
        print(HELP); return 0
    if opts.get("version"):
        print(VERSION); return 0
    if opts.get("list_options"):
        print("CROWBOOK 0.17.0")
        print(OPTIONS_TEXT); return 0
    if opts.get("print_template"):
        print("CROWBOOK 0.17.0")
        name = opts["print_template"]
        templates = {
            "html.css": CSS,
            "epub.css": CSS,
            "tex.template": "\\documentclass{book}\\n\\begin{document}\\n{{content}}\\n\\end{document}\\n",
        }
        if name in templates:
            print(templates[name], end="" if templates[name].endswith("\n") else "\n")
        else:
            error(f"{name} is not a valid template name", opts)
        return 0
    if "create" in opts:
        create(opts["create"])
        banner(opts)
        return 0
    banner(opts)
    if opts.get("stats"):
        error("You must pass the name of a book configuration file.", opts)
        if not opts.get("quiet"):
            eprint("For more information try --help.\n")
        return 0
    if not opts.get("book"):
        error("You must pass the name of a book configuration file.", opts)
        if not opts.get("quiet"):
            eprint("For more information try --help.\n")
        return 0
    try:
        if opts.get("single"):
            meta, chapters, _ = parse_single(opts["book"])
            set_items = opts.get("set", [])
            i = 0
            while i < len(set_items):
                item = set_items[i]
                if "=" in item:
                    k, v = item.split("=", 1)
                elif ":" in item:
                    k, v = item.split(":", 1)
                elif i + 1 < len(set_items):
                    k, v = item, set_items[i + 1]
                    i += 1
                else:
                    i += 1
                    continue
                meta[k.strip()] = strip_quotes(v)
                i += 1
            render(meta, chapters, opts, opts["book"])
        else:
            meta, chapters, base = parse_book(opts["book"], opts)
            render(meta, chapters, opts, opts["book"])
    except FileNotFoundError as ex:
        msg = str(ex)
        if msg.startswith("[Errno"):
            msg = f"Could not open file {opts.get('book')}"
        else:
            msg = f"{opts.get('book')}:{msg}"
        error(msg, opts)
    except Exception as ex:
        error(str(ex), opts)
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
