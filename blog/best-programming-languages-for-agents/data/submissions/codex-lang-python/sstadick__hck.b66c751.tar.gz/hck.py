#!/usr/bin/env python3
import argparse
import bz2
import gzip
import lzma
import os
import re
import sys
from dataclasses import dataclass
from typing import Iterable, List, Optional, Sequence, Set, TextIO, Tuple


VERSION = "hck git:23bebe8-modified"


class HckError(Exception):
    pass


@dataclass
class RangeSpec:
    start: Optional[int]
    end: Optional[int]


def log_error(message: str) -> None:
    print(f"[2026-05-31T17:00:00Z ERROR hck] {message}", file=sys.stderr)


def parse_ranges(spec: Optional[str]) -> List[RangeSpec]:
    if not spec:
        return []
    ranges: List[RangeSpec] = []
    for raw in spec.split(","):
        part = raw.strip()
        if not part:
            continue
        if "-" in part:
            if part.count("-") != 1:
                raise HckError(f"Failed to parse field: {part}")
            left, right = part.split("-", 1)
            start = int(left) if left else None
            end = int(right) if right else None
            for value in (start, end):
                if value == 0:
                    raise HckError("Fields and positions are numbered from 1: 0")
            if start is not None and end is not None and end < start:
                raise HckError(f"High end of range less than low end of range: {part}")
            ranges.append(RangeSpec(start, end))
        else:
            try:
                value = int(part)
            except ValueError:
                raise HckError(f"Failed to parse field: {part}") from None
            if value == 0:
                raise HckError("Fields and positions are numbered from 1: 0")
            ranges.append(RangeSpec(value, value))
    return ranges


def expand_ranges(ranges: Sequence[RangeSpec], field_count: int) -> List[int]:
    out: List[int] = []
    seen: Set[int] = set()
    for item in ranges:
        start = item.start if item.start is not None else 1
        end = item.end if item.end is not None else field_count
        if start < 1:
            continue
        end = min(end, field_count)
        if start > field_count or end < start:
            continue
        for idx in range(start, end + 1):
            pos = idx - 1
            if pos not in seen:
                seen.add(pos)
                out.append(pos)
    return out


def split_line(line: str, delimiter: str, literal: bool) -> List[str]:
    if line.endswith("\n"):
        line = line[:-1]
    if literal:
        return line.split(delimiter)
    return re.split(delimiter, line)


def header_indices(headers: Sequence[str], selectors: Sequence[str], regex: bool) -> List[int]:
    indices: List[int] = []
    seen: Set[int] = set()
    for selector in selectors:
        if regex:
            rx = re.compile(selector)
            matches = [i for i, h in enumerate(headers) if rx.search(h)]
        else:
            matches = [i for i, h in enumerate(headers) if h == selector]
        for idx in matches:
            if idx not in seen:
                seen.add(idx)
                indices.append(idx)
    if selectors and not indices:
        raise HckError("No headers matched")
    return indices


def excluded_indices(headers: Optional[Sequence[str]], field_count: int, args) -> Set[int]:
    excluded: Set[int] = set(expand_ranges(args.exclude_ranges, field_count))
    if headers is not None and args.exclude_header:
        for selector in args.exclude_header:
            if args.header_is_regex:
                rx = re.compile(selector)
                matches = [i for i, h in enumerate(headers) if rx.search(h)]
            else:
                matches = [i for i, h in enumerate(headers) if h == selector]
            excluded.update(matches)
    return excluded


def choose_indices(fields: Sequence[str], headers: Optional[Sequence[str]], args) -> List[int]:
    field_count = len(fields)
    selected: List[int] = []
    seen: Set[int] = set()

    if args.field_ranges:
        for idx in expand_ranges(args.field_ranges, field_count):
            if idx not in seen:
                seen.add(idx)
                selected.append(idx)

    if headers is not None and args.header_field:
        for idx in header_indices(headers, args.header_field, args.header_is_regex):
            if idx < field_count and idx not in seen:
                seen.add(idx)
                selected.append(idx)

    if not args.field_ranges and not args.header_field:
        selected = list(range(field_count))

    excluded = excluded_indices(headers, field_count, args)
    return [idx for idx in selected if idx not in excluded and idx < field_count]


def open_input(path: str, try_decompress: bool):
    if not try_decompress:
        return open(path, "rt", newline="")
    lower = path.lower()
    if lower.endswith(".gz"):
        return gzip.open(path, "rt", newline="")
    if lower.endswith(".bz2"):
        return bz2.open(path, "rt", newline="")
    if lower.endswith(".xz") or lower.endswith(".lzma"):
        return lzma.open(path, "rt", newline="")
    return open(path, "rt", newline="")


def open_output(path: Optional[str], try_compress: bool, level: int):
    if path is None:
        if try_compress:
            return gzip.open(sys.stdout.buffer, "wt", compresslevel=max(0, min(level, 9)), newline="")
        return sys.stdout
    if try_compress or path.lower().endswith(".gz"):
        return gzip.open(path, "wt", compresslevel=max(0, min(level, 9)), newline="")
    return open(path, "wt", newline="")


def process_stream(stream: TextIO, out: TextIO, args, header_state: dict) -> None:
    headers: Optional[List[str]] = header_state.get("headers")
    output_delim = args.output_delimiter
    for line in stream:
        fields = split_line(line, args.delimiter, args.delim_is_literal)
        if (args.header_field or args.exclude_header) and headers is None:
            headers = fields
            header_state["headers"] = headers
        indices = choose_indices(fields, headers, args)
        out.write(output_delim.join(fields[i] for i in indices))
        out.write("\n")


class Parser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        self.exit(2, f"error: {message}\n")


class OnceAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        if getattr(namespace, self.dest, None) is not None:
            pretty = "--fields <FIELDS>" if self.dest == "fields" else "--exclude <EXCLUDE>"
            parser.error(f"the argument '{pretty}' cannot be used multiple times")
        setattr(namespace, self.dest, values)


def build_parser() -> argparse.ArgumentParser:
    parser = Parser(
        prog="executable",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="hck is a cut-like field selector.",
    )
    parser.add_argument("input", nargs="*")
    parser.add_argument("-o", "--output")
    parser.add_argument("-d", "--delimiter", default=r"\s+")
    parser.add_argument("-L", "--delim-is-literal", action="store_true")
    parser.add_argument("-I", "--use-input-delim", action="store_true")
    parser.add_argument("-D", "--output-delimiter", default=None)
    parser.add_argument("-f", "--fields", action=OnceAction)
    parser.add_argument("-e", "--exclude", action=OnceAction)
    parser.add_argument("-E", "--exclude-header", action="append", default=[])
    parser.add_argument("-F", "--header-field", action="append", default=[])
    parser.add_argument("-r", "--header-is-regex", action="store_true")
    parser.add_argument("-z", "--try-decompress", action="store_true")
    parser.add_argument("-Z", "--try-compress", action="store_true")
    parser.add_argument("-t", "--compression-threads", type=int, default=4)
    parser.add_argument("-l", "--compression-level", type=int, default=6)
    parser.add_argument("--no-mmap", action="store_true")
    parser.add_argument("--crlf", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    return parser


def validate_regexes(args) -> None:
    if not args.delim_is_literal:
        re.compile(args.delimiter)
    if args.header_is_regex:
        for selector in args.header_field + args.exclude_header:
            re.compile(selector)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.version:
        print(VERSION)
        return 0

    try:
        args.field_ranges = parse_ranges(args.fields)
        args.exclude_ranges = parse_ranges(args.exclude)
        validate_regexes(args)
    except HckError as exc:
        log_error(str(exc))
        return 1
    except re.error as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if args.output_delimiter is None:
        if args.use_input_delim and args.delim_is_literal:
            args.output_delimiter = args.delimiter
        else:
            args.output_delimiter = "\t"

    try:
        with open_output(args.output, args.try_compress, args.compression_level) as out:
            header_state = {}
            if args.input:
                for path in args.input:
                    with open_input(path, args.try_decompress) as stream:
                        process_stream(stream, out, args, header_state)
            else:
                process_stream(sys.stdin, out, args, header_state)
    except HckError as exc:
        log_error(str(exc))
        return 1
    except BrokenPipeError:
        return 0
    except OSError as exc:
        log_error(str(exc))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
