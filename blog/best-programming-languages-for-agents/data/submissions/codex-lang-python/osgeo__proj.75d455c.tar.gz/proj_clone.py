#!/usr/bin/env python3
import math
import os
import re
import sys

VERSION = "Rel. 9.9.0, September 15th, 2026"
A = 6378137.0
RF = 298.257222101
F = 1.0 / RF
E2 = F * (2.0 - F)
E = math.sqrt(E2)

PROJ_LIST = [
    ("adams_hemi", "Adams Hemisphere in a Square"), ("adams_ws1", "Adams World in a Square I"),
    ("adams_ws2", "Adams World in a Square II"), ("aea", "Albers Equal Area"),
    ("aeqd", "Azimuthal Equidistant"), ("affine", "Affine transformation"),
    ("airy", "Airy"), ("aitoff", "Aitoff"), ("alsk", "Modified Stereographic of Alaska"),
    ("apian", "Apian Globular I"), ("august", "August Epicycloidal"), ("axisswap", "Axis ordering"),
    ("bacon", "Bacon Globular"), ("bertin1953", "Bertin 1953"), ("bipc", "Bipolar conic of western hemisphere"),
    ("boggs", "Boggs Eumorphic"), ("bonne", "Bonne (Werner lat_1=90)"), ("calcofi", "Cal Coop Ocean Fish Invest Lines/Stations"),
    ("cart", "Geodetic/cartesian conversions"), ("cass", "Cassini"), ("cc", "Central Cylindrical"),
    ("ccon", "Central Conic"), ("cea", "Equal Area Cylindrical"), ("chamb", "Chamberlin Trimetric"),
    ("collg", "Collignon"), ("col_urban", "Colombia Urban"), ("comill", "Compact Miller"),
    ("crast", "Craster Parabolic (Putnins P4)"), ("defmodel", "Deformation model"),
    ("deformation", "Kinematic grid shift"), ("denoy", "Denoyer Semi-Elliptical"),
    ("eck1", "Eckert I"), ("eck2", "Eckert II"), ("eck3", "Eckert III"), ("eck4", "Eckert IV"),
    ("eck5", "Eckert V"), ("eck6", "Eckert VI"), ("eqearth", "Equal Earth"),
    ("eqc", "Equidistant Cylindrical (Plate Carree)"), ("eqdc", "Equidistant Conic"),
    ("etmerc", "Extended Transverse Mercator"), ("gall", "Gall (Gall Stereographic)"),
    ("geoc", "Geocentric Latitude"), ("geos", "Geostationary Satellite View"), ("gnom", "Gnomonic"),
    ("goode", "Goode Homolosine"), ("igh", "Interrupted Goode Homolosine"), ("kav5", "Kavraisky V"),
    ("kav7", "Kavraisky VII"), ("laea", "Lambert Azimuthal Equal Area"), ("lcc", "Lambert Conformal Conic"),
    ("longlat", "Lat/long (Geodetic alias)"), ("latlong", "Lat/long (Geodetic alias)"),
    ("merc", "Mercator"), ("mill", "Miller Cylindrical"), ("moll", "Mollweide"),
    ("nsper", "Near-sided perspective"), ("omerc", "Oblique Mercator"), ("ortho", "Orthographic"),
    ("poly", "Polyconic (American)"), ("robin", "Robinson"), ("sinu", "Sinusoidal"),
    ("stere", "Stereographic"), ("tmerc", "Transverse Mercator"), ("utm", "Universal Transverse Mercator (UTM)"),
    ("vandg", "van der Grinten (I)"), ("webmerc", "Web Mercator / Pseudo Mercator"),
]

ELLPS_LIST = [
    "    MERIT a=6378137.0      rf=298.257       MERIT 1983",
    "    SGS85 a=6378136.0      rf=298.257       Soviet Geodetic System 85",
    "    GRS80 a=6378137.0      rf=298.257222101 GRS 1980(IUGG, 1980)",
    "     airy a=6377563.396    rf=299.3249646   Airy 1830",
    "   bessel a=6377397.155    rf=299.1528128   Bessel 1841",
    "   clrk66 a=6378206.4      b=6356583.8      Clarke 1866",
    "     intl a=6378388.0      rf=297.          International 1924 (Hayford 1909, 1910)",
    "    WGS72 a=6378135.0      rf=298.26        WGS 72",
    "    WGS84 a=6378137.0      rf=298.257223563 WGS 84",
    "   sphere a=6370997.0      b=6370997.0      Normal Sphere (r=6370997)",
]

UNIT_LIST = [
    "          mm 0.001                millimetre",
    "          cm 0.01                 centimetre",
    "           m 1                    metre",
    "          ft 0.3048               foot",
    "       us-ft 0.304800609601219    US survey foot",
    "          km 1000                 kilometre",
    "          mi 1609.344             Statute mile",
]


def die(msg, detail=None):
    if detail:
        print(detail, file=sys.stderr)
    print(VERSION, file=sys.stderr)
    print("<executable>: ", file=sys.stderr)
    print(msg, file=sys.stderr)
    print("program abnormally terminated", file=sys.stderr)
    sys.exit(3)


def parse_num(s):
    t = s.strip()
    sign = -1 if re.search(r"[WS]$", t, re.I) else 1
    t = re.sub(r"[NSEW]$", "", t, flags=re.I)
    if t.startswith("-"):
        sign = -1
        t = t[1:]
    elif t.startswith("+"):
        t = t[1:]
    parts = re.split(r"[dD°'\"]+", t)
    parts = [p for p in parts if p != ""]
    try:
        if len(parts) >= 3:
            val = float(parts[0]) + float(parts[1]) / 60.0 + float(parts[2]) / 3600.0
        elif len(parts) == 2:
            val = float(parts[0]) + float(parts[1]) / 60.0
        else:
            val = float(parts[0])
        return sign * val
    except Exception:
        raise ValueError(s)


def fmt_dms(v, pos, neg):
    hemi = pos if v >= 0 else neg
    x = abs(v)
    d = int(math.floor(x + 1e-12))
    mfull = (x - d) * 60.0
    m = int(math.floor(mfull + 1e-12))
    sec = (mfull - m) * 60.0
    if sec < 0.0005:
        if m == 0:
            return f"{d}d{hemi}"
        return f"{d}d{m}'{hemi}"
    if abs(sec - round(sec)) < 0.0005:
        return f"{d}d{m}'{int(round(sec))}\"{hemi}"
    return f"{d}d{m}'{sec:.3f}\"{hemi}".rstrip("0").rstrip(".") + ""


def meridional_arc(phi):
    e4 = E2 * E2
    e6 = e4 * E2
    return A * ((1 - E2/4 - 3*e4/64 - 5*e6/256) * phi
                - (3*E2/8 + 3*e4/32 + 45*e6/1024) * math.sin(2*phi)
                + (15*e4/256 + 45*e6/1024) * math.sin(4*phi)
                - (35*e6/3072) * math.sin(6*phi))


def inv_meridional_arc(m):
    mu = m / (A * (1 - E2/4 - 3*E2*E2/64 - 5*E2**3/256))
    e1 = (1 - math.sqrt(1 - E2)) / (1 + math.sqrt(1 - E2))
    return (mu + (3*e1/2 - 27*e1**3/32) * math.sin(2*mu)
            + (21*e1*e1/16 - 55*e1**4/32) * math.sin(4*mu)
            + (151*e1**3/96) * math.sin(6*mu)
            + (1097*e1**4/512) * math.sin(8*mu))


def msfn(phi):
    return math.cos(phi) / math.sqrt(1 - E2 * math.sin(phi) ** 2)


def qsfn(phi):
    s = math.sin(phi)
    return (1 - E2) * (s / (1 - E2 * s * s) - (1 / (2 * E)) * math.log((1 - E * s) / (1 + E * s)))


def tsfn(phi):
    s = math.sin(phi)
    return math.tan(math.pi / 4 - phi / 2) / (((1 - E * s) / (1 + E * s)) ** (E / 2))


class Transformer:
    def __init__(self, opts):
        self.opts = opts
        self.proj = opts.get("proj", "utm" if "zone" in opts else None)
        if not self.proj:
            die(f"projection initialization failure\ncause: Unknown error (code 2)", "proj_create: unrecognized format / unknown name")
        if self.proj in ("longlat", "latlong"):
            die("can't initialize operations that produce angular output coordinates")
        self.a = float(opts.get("R", opts.get("a", A)))
        self.k0 = float(opts.get("k_0", opts.get("k", 1.0)))
        self.x0 = float(opts.get("x_0", 0.0))
        self.y0 = float(opts.get("y_0", 0.0))
        self.lat0 = math.radians(float(opts.get("lat_0", 0.0)))
        self.lon0 = math.radians(float(opts.get("lon_0", 0.0)))
        if self.proj == "utm":
            zone = int(opts.get("zone", 0))
            if not 1 <= zone <= 60:
                die("projection initialization failure\ncause: Invalid value for an argument")
            self.lon0 = math.radians(zone * 6 - 183)
            self.k0 = 0.9996
            self.x0 = 500000.0
            self.y0 = 10000000.0 if ("south" in opts or opts.get("hemisphere", "").lower() == "s") else 0.0
        if self.proj in ("aea", "lcc") and "lat_1" not in opts and "lat_2" not in opts:
            die("projection initialization failure\ncause: Invalid value for an argument",
                f"proj_create: Error 1027 (Invalid value for an argument): {self.proj}: Invalid value for lat_1 and lat_2: |lat_1 + lat_2| should be > 0")

    def finish(self, x, y):
        return x * self.k0 + self.x0, y * self.k0 + self.y0

    def unfinish(self, x, y):
        return (x - self.x0) / self.k0, (y - self.y0) / self.k0

    def fwd(self, lon_deg, lat_deg):
        lam = math.radians(lon_deg)
        phi = math.radians(lat_deg)
        p = self.proj
        if p in ("merc",):
            x = self.a * (lam - self.lon0)
            s = math.sin(phi)
            y = self.a * math.log(math.tan(math.pi/4 + phi/2) * ((1 - E*s)/(1 + E*s)) ** (E/2))
            return self.finish(x, y)
        if p in ("webmerc", "popular_visualisation_pseudo_mercator"):
            x = self.a * (lam - self.lon0)
            y = self.a * math.log(math.tan(math.pi/4 + phi/2))
            return self.finish(x, y)
        if p in ("eqc", "plate_carree"):
            lat_ts = math.radians(float(self.opts.get("lat_ts", 0.0)))
            ms = math.cos(lat_ts) / math.sqrt(1 - E2 * math.sin(lat_ts) ** 2)
            x = self.a * (lam - self.lon0) * ms
            y = meridional_arc(phi) - meridional_arc(self.lat0)
            return self.finish(x, y)
        if p in ("utm", "tmerc", "etmerc"):
            return self._tmerc_fwd(lam, phi)
        if p == "sinu":
            ms = math.cos(phi) / math.sqrt(1 - E2 * math.sin(phi) ** 2)
            return self.finish(self.a * (lam - self.lon0) * ms, meridional_arc(phi) - meridional_arc(self.lat0))
        if p == "cea":
            lat_ts = math.radians(float(self.opts.get("lat_ts", 0.0)))
            k = math.cos(lat_ts) / math.sqrt(1 - E2 * math.sin(lat_ts) ** 2)
            s = math.sin(phi)
            q = (1 - E2) * (s / (1 - E2 * s * s) - (1 / (2 * E)) * math.log((1 - E * s) / (1 + E * s)))
            return self.finish(self.a * (lam - self.lon0) * k, self.a * q / (2 * k))
        if p == "gall":
            return self.finish(self.a * (lam - self.lon0) / math.sqrt(2), self.a * (1 + math.sqrt(2)/2) * math.tan(phi/2))
        if p == "mill":
            return self.finish(self.a * (lam - self.lon0), self.a * 1.25 * math.log(math.tan(math.pi/4 + 0.4*phi)))
        if p == "moll":
            th = phi
            for _ in range(12):
                d = -(2*th + math.sin(2*th) - math.pi*math.sin(phi)) / (2 + 2*math.cos(2*th))
                th += d
                if abs(d) < 1e-12:
                    break
            return self.finish(self.a * 2*math.sqrt(2)/math.pi * (lam-self.lon0)*math.cos(th),
                               self.a * math.sqrt(2) * math.sin(th))
        if p == "aea":
            return self._aea_fwd(lam, phi)
        if p == "lcc":
            return self._lcc_fwd(lam, phi)
        if p in ("ortho", "laea", "aeqd", "stere", "gnom"):
            return self._azimuthal(lam, phi)
        die("projection initialization failure\ncause: Unknown error (code 2)", "proj_create: unrecognized format / unknown name")

    def inv(self, x, y):
        p = self.proj
        x, y = self.unfinish(x, y)
        if p == "merc":
            t = math.exp(-y / self.a)
            phi = math.pi/2 - 2 * math.atan(t)
            for _ in range(15):
                s = math.sin(phi)
                phi2 = math.pi/2 - 2 * math.atan(t * ((1 - E*s)/(1 + E*s)) ** (E/2))
                if abs(phi2 - phi) < 1e-14:
                    phi = phi2
                    break
                phi = phi2
            return math.degrees(x / self.a + self.lon0), math.degrees(phi)
        if p == "webmerc":
            return math.degrees(x / self.a + self.lon0), math.degrees(2*math.atan(math.exp(y/self.a)) - math.pi/2)
        if p == "eqc":
            lat_ts = math.radians(float(self.opts.get("lat_ts", 0.0)))
            ms = math.cos(lat_ts) / math.sqrt(1 - E2 * math.sin(lat_ts) ** 2)
            return math.degrees(x / (self.a * ms) + self.lon0), math.degrees(inv_meridional_arc(y + meridional_arc(self.lat0)))
        if p in ("utm", "tmerc", "etmerc"):
            return self._tmerc_inv(x, y)
        if p == "sinu":
            phi = y / self.a + self.lat0
            return math.degrees(x / (self.a * math.cos(phi)) + self.lon0), math.degrees(phi)
        if p == "mill":
            return math.degrees(x / self.a + self.lon0), math.degrees(2.5 * (math.atan(math.exp(0.8*y/self.a)) - math.pi/4))
        die("inverse projection not implemented")

    def _tmerc_fwd(self, lam, phi):
        ep2 = E2 / (1 - E2)
        n = A / math.sqrt(1 - E2 * math.sin(phi)**2)
        t = math.tan(phi)**2
        c = ep2 * math.cos(phi)**2
        aa = (lam - self.lon0) * math.cos(phi)
        m = meridional_arc(phi) - meridional_arc(self.lat0)
        x = n * (aa + (1-t+c)*aa**3/6 + (5-18*t+t*t+72*c-58*ep2)*aa**5/120)
        y = m + n * math.tan(phi) * (aa*aa/2 + (5-t+9*c+4*c*c)*aa**4/24 + (61-58*t+t*t+600*c-330*ep2)*aa**6/720)
        return x * self.k0 + self.x0, y * self.k0 + self.y0

    def _tmerc_inv(self, x, y):
        ep2 = E2 / (1 - E2)
        m = y / self.k0 + meridional_arc(self.lat0)
        fp = inv_meridional_arc(m)
        c1 = ep2 * math.cos(fp)**2
        t1 = math.tan(fp)**2
        n1 = A / math.sqrt(1 - E2 * math.sin(fp)**2)
        r1 = A * (1 - E2) / (1 - E2 * math.sin(fp)**2) ** 1.5
        d = x / (n1 * self.k0)
        phi = fp - (n1 * math.tan(fp) / r1) * (d*d/2 - (5+3*t1+10*c1-4*c1*c1-9*ep2)*d**4/24
                                               + (61+90*t1+298*c1+45*t1*t1-252*ep2-3*c1*c1)*d**6/720)
        lam = self.lon0 + (d - (1+2*t1+c1)*d**3/6
                           + (5-2*c1+28*t1-3*c1*c1+8*ep2+24*t1*t1)*d**5/120) / math.cos(fp)
        return math.degrees(lam), math.degrees(phi)

    def _azimuthal(self, lam, phi):
        lam0 = self.lon0
        phi0 = self.lat0
        dlam = lam - lam0
        if self.proj == "ortho" and abs(phi0) < 1e-15:
            n = self.a / math.sqrt(1 - E2 * math.sin(phi) ** 2)
            return self.finish(n * math.cos(phi) * math.sin(dlam), n * (1 - E2) * math.sin(phi))
        sinp, cosp = math.sin(phi), math.cos(phi)
        sin0, cos0 = math.sin(phi0), math.cos(phi0)
        cosc = sin0*sinp + cos0*cosp*math.cos(dlam)
        p = self.proj
        if p == "ortho":
            k = 1.0
        elif p == "laea":
            k = math.sqrt(2 / max(1e-15, 1 + cosc))
        elif p == "aeqd":
            c = math.acos(max(-1, min(1, cosc)))
            k = 1 if abs(c) < 1e-14 else c / math.sin(c)
        elif p == "stere":
            k = 2 / max(1e-15, 1 + cosc)
        else:
            k = 1 / max(1e-15, cosc)
        x = self.a * k * cosp * math.sin(dlam)
        y = self.a * k * (cos0*sinp - sin0*cosp*math.cos(dlam))
        return self.finish(x, y)

    def _aea_fwd(self, lam, phi):
        p1 = math.radians(float(self.opts.get("lat_1", 0.0)))
        p2 = math.radians(float(self.opts.get("lat_2", math.degrees(p1))))
        q1, q2, q = qsfn(p1), qsfn(p2), qsfn(phi)
        m1, m2 = msfn(p1), msfn(p2)
        if abs(p1 - p2) < 1e-12:
            n = math.sin(p1)
        else:
            n = (m1 * m1 - m2 * m2) / (q2 - q1)
        c = m1 * m1 + n * q1
        rho = self.a * math.sqrt(max(0, c - n * q)) / n
        rho0 = self.a * math.sqrt(max(0, c - n * qsfn(self.lat0))) / n
        th = n * (lam - self.lon0)
        return self.finish(rho * math.sin(th), rho0 - rho * math.cos(th))

    def _lcc_fwd(self, lam, phi):
        p1 = math.radians(float(self.opts.get("lat_1", 0.0)))
        p2 = math.radians(float(self.opts.get("lat_2", math.degrees(p1))))
        t1, t2, t = tsfn(p1), tsfn(p2), tsfn(phi)
        m1, m2 = msfn(p1), msfn(p2)
        if abs(p1 - p2) < 1e-12:
            n = math.sin(p1)
        else:
            n = math.log(m1 / m2) / math.log(t1 / t2)
        ff = m1 / (n * (t1 ** n))
        rho = self.a * ff * (t ** n)
        rho0 = self.a * ff * (tsfn(self.lat0) ** n)
        th = n * (lam - self.lon0)
        return self.finish(rho * math.sin(th), rho0 - rho * math.cos(th))


def parse_args(argv):
    opts, files = {}, []
    cfg = {"inverse": False, "echo": False, "fmt": "%.2f", "scale": 1.0, "rin": False, "sout": False,
           "verbose": 0}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a.startswith("+"):
            k = a[1:]
            if "=" in k:
                key, val = k.split("=", 1)
                opts[key] = val
            else:
                opts[k] = True
        elif a == "-I":
            cfg["inverse"] = True
        elif a == "-E":
            cfg["echo"] = True
        elif a == "-s":
            cfg["sout"] = True
        elif a == "-r":
            cfg["rin"] = True
        elif a == "-v":
            cfg["verbose"] = max(cfg["verbose"], 1)
        elif a == "-V":
            cfg["verbose"] = max(cfg["verbose"], 2)
        elif a == "-f":
            i += 1; cfg["fmt"] = argv[i]
        elif a.startswith("-f") and len(a) > 2:
            cfg["fmt"] = a[2:]
        elif a == "-m":
            i += 1; cfg["scale"] = float(argv[i])
        elif a.startswith("-m") and len(a) > 2:
            cfg["scale"] = float(a[2:])
        elif a.startswith("-l"):
            handle_list(a)
            sys.exit(0)
        elif a.startswith("-") and a not in ("-",):
            die(f"invalid option: {a}")
        else:
            files.append(a)
        i += 1
    return opts, cfg, files


def handle_list(a):
    if a in ("-l", "-lp", "-l=proj"):
        for k, v in PROJ_LIST:
            print(f"{k} : {v}")
    elif a == "-lP":
        for k, v in PROJ_LIST:
            print(f"{k} : {v}")
            if k == "merc":
                print("\tCyl, Sph&Ell\n\tlat_ts=")
            elif k in ("utm", "tmerc", "etmerc"):
                print("\tCyl, Ell")
    elif a == "-le":
        print("\n".join(ELLPS_LIST))
    elif a == "-lu":
        print("\n".join(UNIT_LIST))
    else:
        die(f"invalid list option: {a[1:]}")


def printf(fmt, val):
    try:
        return fmt % val
    except Exception:
        return f"{val:.2f}"


def process_line(line, tr, cfg):
    raw = line.rstrip("\n")
    if raw.startswith("#"):
        return raw
    parts = raw.split()
    if len(parts) < 2:
        parts = ["0", "0"]
    rest = parts[2:]
    try:
        x1, y1 = parse_num(parts[0]), parse_num(parts[1])
    except Exception:
        return "*\t* " + " ".join(rest) if rest else "*\t*"
    if cfg["rin"]:
        x1, y1 = y1, x1
    try:
        if cfg["inverse"]:
            a, b = tr.inv(x1, y1)
            if cfg["fmt"] == "%.2f":
                out = [fmt_dms(a, "E", "W"), fmt_dms(b, "N", "S")]
            else:
                out = [printf(cfg["fmt"], a), printf(cfg["fmt"], b)]
        else:
            a, b = tr.fwd(x1, y1)
            a *= cfg["scale"]; b *= cfg["scale"]
            out = [printf(cfg["fmt"], a), printf(cfg["fmt"], b)]
    except Exception:
        out = ["*", "*"]
    if cfg["sout"]:
        out = [out[1], out[0]]
    if rest:
        out.append(" ".join(rest))
    body = "\t".join(out[:2]) + ((" " + out[2]) if len(out) > 2 else "")
    if cfg["echo"]:
        return " ".join(parts[:2]) + "\t" + body
    return body


def main(argv):
    if any(a.startswith("--") for a in argv):
        die(f"invalid option: {next(a for a in argv if a.startswith('--'))}")
    opts, cfg, files = parse_args(argv)
    if not argv:
        print(VERSION, file=sys.stderr)
        print("usage: executable [-bdeEfiIlmorsStTvVwW [args]] [+opt[=arg] ...] [file ...]", file=sys.stderr)
        return 0
    tr = Transformer(opts)
    if cfg["verbose"]:
        name = {"merc": "Mercator", "utm": "Universal Transverse Mercator", "tmerc": "Transverse Mercator",
                "etmerc": "Extended Transverse Mercator"}.get(tr.proj, tr.proj)
        print(f"#{name}", file=sys.stderr)
        print("# +proj=" + tr.proj + " +break_cs2cs_recursion +ellps=GRS80", file=sys.stderr)
        if cfg["verbose"] > 1:
            print("#Final Earth figure: ellipsoid", file=sys.stderr)
            print("#  Major axis (a): 6378137.000", file=sys.stderr)
    streams = []
    if files:
        for f in files:
            streams.append(open(f, "r"))
    else:
        streams.append(sys.stdin)
    for st in streams:
        for line in st:
            print(process_line(line, tr, cfg))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
