#!/usr/bin/env python3
import json
import re
import sys
import urllib.request


HELP = """Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable

Usage:
  gron [OPTIONS] [FILE|URL|-]

Options:
  -u, --ungron     Reverse the operation (turn assignments back into JSON)
  -v, --values     Print just the values of provided assignments
  -c, --colorize   Colorize output (default on tty)
  -m, --monochrome Monochrome (don't colorize output)
  -s, --stream     Treat each line of input as a separate JSON object
  -k, --insecure   Disable certificate validation
  -x, --proxy      Set proxy configuration
      --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.
  -j, --json       Represent gron data as JSON stream
      --no-sort    Don't sort output (faster)
      --version    Print version information

Exit Codes:
  0\tOK
  1\tFailed to open file
  2\tFailed to read input
  3\tFailed to form statements
  4\tFailed to fetch URL
  5\tFailed to parse statements
  6\tFailed to encode JSON

Examples:
  gron /tmp/apiresponse.json
  gron http://jsonplaceholder.typicode.com/users/1 
  curl -s http://jsonplaceholder.typicode.com/users/1 | gron
  gron http://jsonplaceholder.typicode.com/users/1 | grep company | gron --ungron"""


IDENT = re.compile(r"^[A-Za-z_$][A-Za-z0-9_$]*$")


class RawNum:
    def __init__(self, text):
        self.text = text

    def __repr__(self):
        return self.text


def load_json(text):
    return json.loads(text, parse_int=RawNum, parse_float=RawNum)


def dump_compact(v):
    if isinstance(v, RawNum):
        return v.text
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False, separators=(",", ":"))
    if v is True:
        return "true"
    if v is False:
        return "false"
    if v is None:
        return "null"
    if isinstance(v, list):
        return "[" + ",".join(dump_compact(x) for x in v) + "]"
    if isinstance(v, dict):
        return "{" + ",".join(dump_compact(str(k)) + ":" + dump_compact(val) for k, val in v.items()) + "}"
    return json.dumps(v, ensure_ascii=False, separators=(",", ":"))


def dump_pretty(v, indent=0):
    sp = " " * indent
    if isinstance(v, dict):
        if not v:
            return "{}"
        keys = sorted(v.keys())
        lines = ["{"]
        for i, k in enumerate(keys):
            comma = "," if i + 1 < len(keys) else ""
            lines.append(" " * (indent + 2) + dump_compact(str(k)) + ": " + dump_pretty(v[k], indent + 2) + comma)
        lines.append(sp + "}")
        return "\n".join(lines)
    if isinstance(v, list):
        if not v:
            return "[]"
        lines = ["["]
        for i, item in enumerate(v):
            comma = "," if i + 1 < len(v) else ""
            lines.append(" " * (indent + 2) + dump_pretty(item, indent + 2) + comma)
        lines.append(sp + "]")
        return "\n".join(lines)
    return dump_compact(v)


def path_part(p):
    if isinstance(p, int):
        return "[" + str(p) + "]"
    if IDENT.match(p):
        return "." + p
    return "[" + dump_compact(p) + "]"


def path_string(path):
    return "json" + "".join(path_part(p) for p in path)


def walk(value, path=()):
    out = []
    if isinstance(value, dict):
        out.append((list(path), {}))
        for k, v in value.items():
            out.extend(walk(v, path + (str(k),)))
    elif isinstance(value, list):
        out.append((list(path), []))
        for i, v in enumerate(value):
            out.extend(walk(v, path + (i,)))
    else:
        out.append((list(path), value))
    return out


def format_statement(path, value):
    return f"{path_string(path)} = {dump_compact(value)};"


def natural_key(path):
    s = path_string(path)
    return [int(part) if part.isdigit() else part for part in re.split(r"(\d+)", s)]


def emit_forward(data, as_json=False, no_sort=False):
    stmts = walk(data)
    if not no_sort:
        stmts.sort(key=lambda pv: natural_key(pv[0]))
    for path, val in stmts:
        if as_json:
            print(dump_compact([path, val]))
        else:
            print(format_statement(path, val))


def read_input(source):
    if source is None or source == "-":
        try:
            return sys.stdin.read()
        except Exception as e:
            print(f"Failed to read input: {e}", file=sys.stderr)
            sys.exit(2)
    if source.startswith("http://") or source.startswith("https://"):
        try:
            with urllib.request.urlopen(source) as r:
                return r.read().decode("utf-8")
        except Exception as e:
            print(f"Failed to fetch URL: {e}", file=sys.stderr)
            sys.exit(4)
    try:
        with open(source, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        print(f"Failed to open file: {e}", file=sys.stderr)
        sys.exit(1)


def parse_path(s):
    i = 0
    if not s.startswith("json"):
        raise ValueError("missing json root")
    i = 4
    path = []
    while i < len(s):
        if s[i] == ".":
            i += 1
            m = re.match(r"[A-Za-z_$][A-Za-z0-9_$]*", s[i:])
            if not m:
                raise ValueError("bad identifier")
            path.append(m.group(0))
            i += len(m.group(0))
        elif s[i] == "[":
            i += 1
            if i < len(s) and s[i] == '"':
                dec = json.JSONDecoder()
                val, end = dec.raw_decode(s[i:])
                i += end
                if i >= len(s) or s[i] != "]":
                    raise ValueError("bad bracket")
                i += 1
                path.append(val)
            else:
                m = re.match(r"-?\d+", s[i:])
                if not m:
                    raise ValueError("bad index")
                path.append(int(m.group(0)))
                i += len(m.group(0))
                if i >= len(s) or s[i] != "]":
                    raise ValueError("bad bracket")
                i += 1
        elif s[i].isspace():
            i += 1
        else:
            raise ValueError("bad path")
    return path


def split_assignment(line):
    in_str = False
    esc = False
    bracket = 0
    for i, ch in enumerate(line):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "[":
                bracket += 1
            elif ch == "]":
                bracket -= 1
            elif ch == "=" and bracket == 0:
                return line[:i].strip(), line[i + 1 :].strip()
    raise ValueError("no assignment")


def strip_semicolon(s):
    s = s.strip()
    if s.endswith(";"):
        return s[:-1].strip()
    return s


def parse_statement_line(line):
    left, right = split_assignment(line)
    path = parse_path(left)
    value = load_json(strip_semicolon(right))
    return path, value


def parse_statements(text, as_json=False):
    result = []
    if as_json:
        for line in text.splitlines():
            if not line.strip():
                continue
            item = load_json(line)
            if not isinstance(item, list) or len(item) != 2:
                raise ValueError("bad json statement")
            result.append(([int(p.text) if isinstance(p, RawNum) else p for p in item[0]], item[1]))
        return result
    for line in text.splitlines():
        if not line.strip():
            continue
        result.append(parse_statement_line(line))
    return result


def is_container(v):
    return isinstance(v, (dict, list))


def make_container(next_key):
    return [] if isinstance(next_key, int) else {}


def set_value(root_marker, path, value):
    if not path:
        return value
    if root_marker[0] is None:
        root_marker[0] = make_container(path[0])
    cur = root_marker[0]
    for idx, key in enumerate(path):
        last = idx == len(path) - 1
        if isinstance(key, int):
            if not isinstance(cur, list):
                return root_marker[0]
            while len(cur) <= key:
                cur.append(None)
            if last:
                cur[key] = value
            else:
                if cur[key] is None or not is_container(cur[key]):
                    cur[key] = make_container(path[idx + 1])
                cur = cur[key]
        else:
            if not isinstance(cur, dict):
                return root_marker[0]
            if last:
                cur[key] = value
            else:
                if key not in cur or not is_container(cur[key]):
                    cur[key] = make_container(path[idx + 1])
                cur = cur[key]
    return root_marker[0]


def scalar_values(stmts):
    for _, val in stmts:
        if isinstance(val, dict) or isinstance(val, list):
            continue
        if isinstance(val, str):
            print(val)
        else:
            print(dump_compact(val))


def ungron(text, as_json=False, values=False):
    try:
        stmts = parse_statements(text, as_json)
    except Exception as e:
        print(f"Failed to parse statements: {e}", file=sys.stderr)
        sys.exit(5)
    if values:
        scalar_values(stmts)
        return
    root = [None]
    for path, val in stmts:
        root[0] = set_value(root, path, val)
    if root[0] is None:
        root[0] = {}
    try:
        print(dump_pretty(root[0]))
    except Exception as e:
        print(f"Failed to encode JSON: {e}", file=sys.stderr)
        sys.exit(6)


def parse_args(argv):
    opts = {"ungron": False, "values": False, "stream": False, "json": False, "no_sort": False}
    source = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--help", "-h"):
            print(HELP)
            sys.exit(0)
        if a == "--version":
            print("gron version dev")
            sys.exit(0)
        if a in ("-u", "--ungron"):
            opts["ungron"] = True
        elif a in ("-v", "--values"):
            opts["values"] = True
        elif a in ("-s", "--stream"):
            opts["stream"] = True
        elif a in ("-j", "--json"):
            opts["json"] = True
        elif a == "--no-sort":
            opts["no_sort"] = True
        elif a in ("-c", "--colorize", "-m", "--monochrome", "-k", "--insecure"):
            pass
        elif a in ("-x", "--proxy", "--noproxy"):
            i += 1
        elif a.startswith("-") and len(a) > 2 and not a.startswith("--"):
            for ch in a[1:]:
                if ch == "u":
                    opts["ungron"] = True
                elif ch == "v":
                    opts["values"] = True
                elif ch == "s":
                    opts["stream"] = True
                elif ch == "j":
                    opts["json"] = True
                elif ch in "cmk":
                    pass
                else:
                    print(HELP)
                    sys.exit(0)
        elif source is None:
            source = a
        i += 1
    return opts, source


def main(argv):
    opts, source = parse_args(argv)
    text = read_input(source)
    if opts["ungron"] or opts["values"]:
        ungron(text, as_json=opts["json"], values=opts["values"])
        return
    try:
        if opts["stream"]:
            data = [load_json(line) for line in text.splitlines() if line.strip()]
        else:
            data = load_json(text)
    except Exception as e:
        print(f"Failed to read input: {e}", file=sys.stderr)
        sys.exit(2)
    try:
        emit_forward(data, as_json=opts["json"], no_sort=opts["no_sort"])
    except Exception as e:
        print(f"Failed to form statements: {e}", file=sys.stderr)
        sys.exit(3)


if __name__ == "__main__":
    main(sys.argv[1:])
