#!/usr/bin/env python3
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time


THEME_DESCRIPTIONS = [
    ("slate", "Slate theme by Jody Ribton <jody@ribton.me>"),
    ("alphare", "A beige theme by Alphare"),
    ("ubuntu", "Ubuntu theme by lasers"),
    ("flat-gray", "flat gray based theme"),
    ("purple", "Purple theme by AAlakkad <http://aalakkad.me>"),
    ("archlinux", "Archlinux theme by okraits <http://okraits.de>"),
    ("default", "Default theme for i3wm <http://i3wm.org>"),
    ("debian", "Debian theme by lasers"),
    ("oceanic-next", "Theme by Valentin Weber inspired by voronianski (https://github.com/voronianski/oceanic-next-color-scheme)"),
    ("base16-tomorrow", "Base16 Tomorrow, by Chris Kempson (http://chriskempson.com)"),
    ("okraits", "A simple theme by okraits <http://okraits.de>"),
    ("icelines", "icelines theme by mbfraga"),
    ("solarized", "Solarized theme by lasers"),
    ("deep-purple", "Inspired by the Purple and Default themes. By jcpst <http://jcpst.com>"),
    ("tomorrow-night-80s", "Tomorrow Night 80s theme by jmfurlott <http://jmfurlott.com>"),
    ("seti", "seti theme by Jody Ribton - based on the seti Atom theme at https://atom.io/themes/seti-ui"),
    ("lime", "Lime theme by wei2912 <http://wei2912.github.io>, based on Archlinux theme by okraits <http://okraits.de>"),
    ("gruvbox", "Made by freeware-preacher <https://github.com/freeware-preacher> to match gruvbox by morhetz <https://github.com/morhetz>"),
    ("mate", "Theme for blending i3 into MATE"),
]

THEMES = {
    "slate": {
        "bar": {"separator": ["#586e75"], "background": ["#002b36"], "statusline": ["#aea79f"], "focused_workspace": ["#586e75", "#586e75", "#ffffff"], "active_workspace": ["#073642", "#073642", "#ffffff"], "inactive_workspace": ["#002b36", "#002b36", "#aea79f"], "urgent_workspace": ["#77216f", "#77216f", "#ffffff"]},
        "client": {"focused": ["#586e75", "#586e75", "#fdf6e3", "#268bd2"], "focused_inactive": ["#073642", "#073642", "#93a1a1", "#002b36"], "unfocused": ["#002b36", "#002b36", "#586e75", "#002b36"], "urgent": ["#dc322f", "#dc322f", "#fdf6e3", "#dc322f"]},
    },
    "alphare": {
        "bar": {"separator": ["#000000"], "background": ["#FDF6E3"], "statusline": ["#002B36"], "focused_workspace": ["#000000", "#268BD2", "#FFFFFF"], "active_workspace": ["#333333", "#222222", "#FFFFFF"], "inactive_workspace": ["#333333", "#222222", "#888888"], "urgent_workspace": ["#2F343A", "#900000", "#FFFFFF"]},
        "client": {"focused": ["#000000", "#FDF6E3", "#002B36", "#000000"], "focused_inactive": ["#000000", "#5F676A", "#FDF6E3", "#484E50"], "unfocused": ["#000000", "#000000", "#FDF6E3", "#000000"], "urgent": ["#000000", "#DC322F", "#FDF6E3", "#DC322F"]},
    },
    "ubuntu": {
        "bar": {"separator": ["#333333"], "background": ["#2c001e"], "statusline": ["#aea79f"], "focused_workspace": ["#dd4814", "#dd4814", "#ffffff"], "active_workspace": ["#902a07", "#902a07", "#aea79f"], "inactive_workspace": ["#902a07", "#902a07", "#aea79f"], "urgent_workspace": ["#77216f", "#77216f", "#ffffff"]},
        "client": {"focused": ["#dd4814", "#dd4814", "#ffffff", "#902a07"], "focused_inactive": ["#5e2750", "#5e2750", "#aea79f", "#5e2750"], "unfocused": ["#5e2750", "#5e2750", "#aea79f", "#5e2750"], "urgent": ["#77216f", "#77216f", "#ffffff", "#efb73e"]},
    },
    "flat-gray": {
        "bar": {"separator": ["#111111"], "background": ["#333333"], "statusline": ["#AAAAAA"], "focused_workspace": ["#282828", "#282828", "#FFFFFF"], "inactive_workspace": ["#333333", "#333333", "#AAAAAA"]},
        "client": {"focused": ["#000000", "#000000", "#FFFFFF", "#000000"], "focused_inactive": ["#333333", "#333333", "#FFFFFF", "#000000"], "unfocused": ["#333333", "#333333", "#FFFFFF", "#333333"]},
    },
    "purple": {
        "bar": {"separator": ["#AAAAAA"], "background": ["#222133"], "statusline": ["#FFFFFF"], "focused_workspace": ["#664477", "#664477", "#cccccc"], "active_workspace": ["#DCCD69", "#DCCD69", "#181715"], "inactive_workspace": ["#222133", "#222133", "#AAAAAA"], "urgent_workspace": ["#CE4045", "#CE4045", "#FFFFFF"]},
        "client": {"focused": ["#664477", "#664477", "#cccccc", "#e7d8b1"], "focused_inactive": ["#e7d8b1", "#e7d8b1", "#181715", "#A074C4"], "unfocused": ["#222133", "#222133", "#AAAAAA", "#A074C4"], "urgent": ["#CE4045", "#CE4045", "#e7d8b1", "#DCCD69"]},
    },
    "archlinux": {
        "bar": {"separator": ["#666666"], "background": ["#222222"], "statusline": ["#dddddd"], "focused_workspace": ["#0088CC", "#0088CC", "#ffffff"], "active_workspace": ["#333333", "#333333", "#ffffff"], "inactive_workspace": ["#333333", "#333333", "#888888"], "urgent_workspace": ["#2f343a", "#900000", "#ffffff"]},
        "client": {"focused": ["#0088CC", "#0088CC", "#ffffff", "#dddddd"], "focused_inactive": ["#333333", "#333333", "#888888", "#292d2e"], "unfocused": ["#333333", "#333333", "#888888", "#292d2e"], "urgent": ["#2f343a", "#900000", "#ffffff", "#900000"]},
    },
    "default": {
        "bar": {"separator": ["#666666"], "background": ["#000000"], "statusline": ["#ffffff"], "focused_workspace": ["#4c7899", "#285577", "#ffffff"], "active_workspace": ["#333333", "#5f676a", "#ffffff"], "inactive_workspace": ["#333333", "#222222", "#888888"], "urgent_workspace": ["#2f343a", "#900000", "#ffffff"]},
        "client": {"focused": ["#4c7899", "#285577", "#ffffff", "#2e9ef4"], "focused_inactive": ["#333333", "#5f676a", "#ffffff", "#484e50"], "unfocused": ["#333333", "#222222", "#888888", "#292d2e"], "urgent": ["#2f343a", "#900000", "#ffffff", "#900000"]},
    },
    "debian": {
        "bar": {"separator": ["#444444"], "background": ["#222222"], "statusline": ["#666666"], "focused_workspace": ["#d70a53", "#d70a53", "#ffffff"], "active_workspace": ["#333333", "#333333", "#888888"], "inactive_workspace": ["#333333", "#333333", "#888888"], "urgent_workspace": ["#eb709b", "#eb709b", "#ffffff"]},
        "client": {"focused": ["#d70a53", "#d70a53", "#ffffff", "#8c0333"], "focused_inactive": ["#333333", "#333333", "#888888", "#333333"], "unfocused": ["#333333", "#333333", "#888888", "#333333"], "urgent": ["#eb709b", "#eb709b", "#ffffff", "#eb709b"]},
    },
    "oceanic-next": {
        "bar": {"separator": ["#65737E"], "background": ["#1B2B34"], "statusline": ["#D8DEE9"], "focused_workspace": ["#6699CC", "#6699CC", "#1B2B34"], "active_workspace": ["#5FB3B3", "#5FB3B3", "#1B2B34"], "inactive_workspace": ["#343D46", "#343D46", "#D8DEE9"], "urgent_workspace": ["#EC5f67", "#EC5f67", "#1B2B34"]},
        "client": {"focused": ["#6699CC", "#6699CC", "#1B2B34", "#6699CC"], "focused_inactive": ["#5FB3B3", "#5FB3B3", "#D8DEE9", "#A7ADBA"], "unfocused": ["#343D46", "#343D46", "#D8DEE9", "#343D46"], "urgent": ["#EC5f67", "#EC5f67", "#1B2B34", "#EC5f67"]},
    },
    "base16-tomorrow": {
        "bar": {"separator": ["#969896"], "background": ["#1d1f21"], "statusline": ["#c5c8c6"], "focused_workspace": ["#81a2be", "#81a2be", "#1d1f21"], "active_workspace": ["#373b41", "#373b41", "#ffffff"], "inactive_workspace": ["#282a2e", "#282a2e", "#969896"], "urgent_workspace": ["#cc6666", "#cc6666", "#ffffff"]},
        "client": {"focused": ["#81a2be", "#81a2be", "#1d1f21", "#282a2e"], "focused_inactive": ["#373b41", "#373b41", "#969896", "#282a2e"], "unfocused": ["#282a2e", "#282a2e", "#969896", "#282a2e"], "urgent": ["#373b41", "#cc6666", "#ffffff", "#cc6666"]},
    },
    "okraits": {
        "bar": {"separator": ["#666666"], "background": ["#333333"], "statusline": ["#bbbbbb"], "focused_workspace": ["#888888", "#dddddd", "#222222"], "active_workspace": ["#333333", "#555555", "#bbbbbb"], "inactive_workspace": ["#333333", "#555555", "#bbbbbb"], "urgent_workspace": ["#2f343a", "#900000", "#ffffff"]},
        "client": {"focused": ["#888888", "#dddddd", "#222222", "#2e9ef4"], "focused_inactive": ["#333333", "#555555", "#bbbbbb", "#484e50"], "unfocused": ["#333333", "#333333", "#888888", "#292d2e"], "urgent": ["#2f343a", "#900000", "#ffffff", "#900000"]},
    },
    "icelines": {
        "bar": {"separator": ["#7d7d7d"], "background": ["#141414"], "statusline": ["#00b0ef"], "focused_workspace": ["#00b0ef", "#141414", "#00b0ef"], "active_workspace": ["#141414", "#141414", "#00b0ef"], "inactive_workspace": ["#141414", "#141414", "#7d7d7d"], "urgent_workspace": ["#ff7066", "#141414", "#ff7066"]},
        "client": {"focused": ["#00b0ef", "#00b0ef", "#141414", "#ff7066"], "focused_inactive": ["#141414", "#141414", "#00b0ef", "#472b2a"], "unfocused": ["#141414", "#141414", "#7d7d7d", "#141414"], "urgent": ["#ff7066", "#ff7066", "#141414", "#ff7066"]},
    },
    "solarized": {
        "bar": {"separator": ["#dc322f"], "background": ["#002b36"], "statusline": ["#268bd2"], "focused_workspace": ["#fdf6e3", "#859900", "#fdf6e3"], "active_workspace": ["#fdf6e3", "#6c71c4", "#fdf6e3"], "inactive_workspace": ["#586e75", "#93a1a1", "#002b36"], "urgent_workspace": ["#d33682", "#d33682", "#fdf6e3"]},
        "client": {"focused": ["#859900", "#859900", "#fdf6e3", "#6c71c4"], "focused_inactive": ["#073642", "#073642", "#eee8d5", "#6c71c4"], "unfocused": ["#073642", "#073642", "#93a1a1", "#586e75"], "urgent": ["#d33682", "#d33682", "#fdf6e3", "#dc322f"]},
    },
    "deep-purple": {
        "bar": {"separator": ["#666666"], "background": ["#000000"], "statusline": ["#ffffff"], "focused_workspace": ["#551a8b", "#551a8b", "#ffffff"], "active_workspace": ["#333333", "#5f676a", "#ffffff"], "inactive_workspace": ["#000000", "#000000", "#888888"], "urgent_workspace": ["#2f343a", "#900000", "#ffffff"]},
        "client": {"focused": ["#3b1261", "#3b1261", "#ffffff", "#662b9c"], "focused_inactive": ["#333333", "#5f676a", "#ffffff", "#484e50"], "unfocused": ["#222222", "#222222", "#888888", "#292d2e"], "urgent": ["#2f343a", "#900000", "#ffffff", "#900000"]},
    },
    "tomorrow-night-80s": {
        "bar": {"separator": ["#515151"], "background": ["#2d2d2d"], "statusline": ["#cccccc"], "focused_workspace": ["#99cc99", "#99cc99", "#000000"], "active_workspace": ["#333333", "#333333", "#ffffff"], "inactive_workspace": ["#2d2d2d", "#2d2d2d", "#999999"], "urgent_workspace": ["#f2777a", "#f2777a", "#ffffff"]},
        "client": {"focused": ["#99cc99", "#99cc99", "#000000", "#2d2d2d"], "focused_inactive": ["#393939", "#393939", "#888888", "#292d2e"], "unfocused": ["#2d2d2d", "#2d2d2d", "#999999", "#292d2e"], "urgent": ["#2f343a", "#900000", "#ffffff", "#900000"]},
    },
    "seti": {
        "bar": {"separator": ["#AAAAAA"], "background": ["#1f2326"], "statusline": ["#FFFFFF"], "focused_workspace": ["#9FCA56", "#9FCA56", "#151718"], "active_workspace": ["#DCCD69", "#DCCD69", "#151718"], "inactive_workspace": ["#1f2326", "#1f2326", "#AAAAAA"], "urgent_workspace": ["#CE4045", "#CE4045", "#FFFFFF"]},
        "client": {"focused": ["#4F99D3", "#4F99D3", "#151718", "#9FCA56"], "focused_inactive": ["#9FCA56", "#9FCA56", "#151718", "#A074C4"], "unfocused": ["#1f2326", "#1f2326", "#AAAAAA", "#A074C4"], "urgent": ["#CE4045", "#CE4045", "#FFFFFF", "#DCCD69"]},
    },
    "lime": {
        "bar": {"separator": ["#888888"], "background": ["#333333"], "statusline": ["#FFFFFF"], "focused_workspace": ["#4E9C00", "#4E9C00", "#FFFFFF"], "active_workspace": ["#333333", "#333333", "#FFFFFF"], "inactive_workspace": ["#333333", "#333333", "#888888"], "urgent_workspace": ["#C20000", "#C20000", "#FFFFFF"]},
        "client": {"focused": ["#4E9C00", "#4E9C00", "#FFFFFF", "#FFFFFF"], "focused_inactive": ["#1B3600", "#1B3600", "#888888", "#FFFFFF"], "unfocused": ["#333333", "#333333", "#888888", "#FFFFFF"], "urgent": ["#C20000", "#C20000", "#FFFFFF", "#FFFFFF"]},
    },
    "gruvbox": {
        "bar": {"separator": ["#928374"], "background": ["#282828"], "statusline": ["#ebdbb2"], "focused_workspace": ["#689d6a", "#689d6a", "#282828"], "active_workspace": ["#1d2021", "#1d2021", "#928374"], "inactive_workspace": ["#32302f", "#32302f", "#928374"], "urgent_workspace": ["#cc241d", "#cc241d", "#ebdbb2"]},
        "client": {"focused": ["#689d6a", "#689d6a", "#282828", "#282828"], "focused_inactive": ["#1d2021", "#1d2021", "#928374", "#282828"], "unfocused": ["#32302f", "#32302f", "#928374", "#282828"], "urgent": ["#cc241d", "#cc241d", "#ebdbb2", "#282828"]},
    },
    "mate": {
        "bar": {"separator": ["#ffffff"], "background": ["#3c3b37"], "statusline": ["#ffffff"], "focused_workspace": ["#526532", "#526532", "#ffffff"], "active_workspace": ["#aea79f", "#aea79f", "#3c3b37"], "inactive_workspace": ["#3c3b37", "#3c3b37", "#aea79f"], "urgent_workspace": ["#FF0000", "#FF0000", "#ffffff"]},
        "client": {"focused": ["#526532", "#526532", "#ffffff", "#a4cb64"], "focused_inactive": ["#aea79f", "#aea79f", "#3c3b37", "#aea79f"], "unfocused": ["#3c3b37", "#3c3b37", "#aea79f", "#3c3b37"], "urgent": ["#FF0000", "#FF0000", "#ffffff", "#FF0000"]},
    },
}

BAR_ORDER = ["separator", "background", "statusline", "focused_workspace", "active_workspace", "inactive_workspace", "urgent_workspace"]
CLIENT_ORDER = ["focused", "focused_inactive", "unfocused", "urgent"]
HEX_RE = re.compile(r"#[0-9A-Fa-f]{6}")


def help_text():
    return """i3-style 1.0
Make your i3 config a bit more stylish

USAGE:
    executable [FLAGS] [OPTIONS] [theme]

FLAGS:
    -h, --help        Prints help information
    -l, --list-all    Print a list of all available themes
    -r, --reload      Apply the theme by reloading the config
    -s, --save        Set the output file to the path of the input file
    -V, --version     Prints version information

OPTIONS:
    -c, --config <file>      The config file the theme should be applied to. Defaults to the default i3 location.
    -o, --output <file>      Apply the theme, attempt to validate the result, and write it to <file>
    -t, --to-theme <file>    Prints an i3-style theme based on the given config suitable for sharing with others
                             [default: ]

ARGS:
    <theme>    The theme to use
"""


def print_list():
    print("Available themes:\n")
    width = max(len(n) for n, _ in THEME_DESCRIPTIONS)
    for name, desc in THEME_DESCRIPTIONS:
        print(f"  {name:<{width}} - {desc}")


def default_config_path():
    return os.path.expanduser("~/.config/i3/config")


def line_key(line):
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return None
    return stripped.split()[0]


def brace_delta(line):
    raw = line.split("#", 1)[0]
    return raw.count("{") - raw.count("}")


def find_block(lines, start_pat, start=0, end=None):
    if end is None:
        end = len(lines)
    depth = 0
    found = None
    for i in range(start, end):
        if found is None and re.match(start_pat, lines[i].strip()):
            found = i
            depth = brace_delta(lines[i])
            if depth <= 0:
                depth = 1
            continue
        if found is not None:
            depth += brace_delta(lines[i])
            if depth <= 0:
                return found, i
    if found is not None:
        return found, end - 1
    return None


def format_bar_line(key, values, old_line=None, indent="    "):
    vals = list(values)
    if key.endswith("_workspace"):
        appended = False
        if old_line:
            old_vals = HEX_RE.findall(old_line)
            if old_vals:
                vals.append(old_vals[-1])
                appended = True
        suffix = "" if appended else " "
        return f"{indent}{key} {' '.join(vals)}{suffix}\n"
    return f"{indent}{key} {' '.join(vals)}\n"


def format_client_line(key, values, old_line=None):
    return f"client.{key} {' '.join(values)}\n"


def transform_config(text, theme):
    lines = text.splitlines(True)
    if text and not text.endswith("\n"):
        lines[-1] += "\n"

    # Replace or insert bar colors in the first bar block only.
    bar_block = find_block(lines, r"^bar\s*\{")
    if bar_block:
        bs, be = bar_block
        colors_block = find_block(lines, r"^colors\s*\{", bs + 1, be)
        inserted_colors = False
        if colors_block:
            cs, ce = colors_block
        else:
            close = be
            lines[close:close] = ["  colors {\n"] + [format_bar_line(k, theme["bar"][k], indent="    ") for k in BAR_ORDER if k in theme["bar"]] + ["  }\n"]
            cs, ce = close, close + len([k for k in BAR_ORDER if k in theme["bar"]]) + 1
            inserted_colors = True
        seen = set()
        if not inserted_colors:
            i = cs + 1
            while i < ce:
                key = line_key(lines[i])
                if key in theme["bar"]:
                    indent = re.match(r"\s*", lines[i]).group(0)
                    lines[i] = format_bar_line(key, theme["bar"][key], lines[i], indent)
                    seen.add(key)
                i += 1
            missing = [k for k in BAR_ORDER if k in theme["bar"] and k not in seen]
            if missing:
                insert = cs + 1
                new = [format_bar_line(k, theme["bar"][k], indent="    ") for k in missing]
                lines[insert:insert] = new

    # Replace existing client lines, append missing lines in canonical order.
    seen_clients = set()
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("client."):
            name = stripped.split()[0][len("client."):]
            if name in theme["client"]:
                lines[i] = format_client_line(name, theme["client"][name], line)
                seen_clients.add(name)
    missing = [k for k in CLIENT_ORDER if k in theme["client"] and k not in seen_clients]
    if missing and lines and lines[-1] and not lines[-1].endswith("\n"):
        lines[-1] += "\n"
    for key in missing:
        lines.append(format_client_line(key, theme["client"][key]))
    return "".join(lines)


def parse_theme_file(path):
    try:
        txt = open(path, encoding="utf-8").read()
    except OSError:
        return None
    colors = {}
    section = None
    cur = None
    theme = {"bar": {}, "client": {}}
    for raw in txt.splitlines():
        line = raw.rstrip()
        s = line.strip()
        if not s or s.startswith("#") or s == "---":
            continue
        if re.match(r"^[A-Za-z_]+:", s) and not raw.startswith(" "):
            section = s[:-1]
            cur = None
            continue
        if section == "colors":
            m = re.match(r"([A-Za-z0-9_-]+):\s*[\"']?(#[0-9A-Fa-f]{6})[\"']?", s)
            if m:
                colors[m.group(1)] = m.group(2)
        elif section in ("window_colors", "bar_colors"):
            m = re.match(r"([A-Za-z_]+):\s*$", s)
            if m:
                cur = m.group(1)
                if section == "window_colors":
                    theme["client"].setdefault(cur, [])
                else:
                    theme["bar"].setdefault(cur, [])
                continue
            m = re.match(r"(separator|background|statusline):\s*([A-Za-z0-9_-]+|#[0-9A-Fa-f]{6})", s)
            if m and section == "bar_colors" and cur is None:
                theme["bar"][m.group(1)] = [colors.get(m.group(2), m.group(2))]
                continue
            m = re.match(r"(border|background|text|indicator|separator|statusline):\s*([A-Za-z0-9_-]+|#[0-9A-Fa-f]{6})", s)
            if m and cur:
                val = colors.get(m.group(2), m.group(2))
                if section == "window_colors":
                    order = ["border", "background", "text", "indicator"]
                    d = getattr(parse_theme_file, "_wd", {})
                else:
                    order = ["border", "background", "text"]
                    d = getattr(parse_theme_file, "_bd", {})
                key = (section, cur)
                d.setdefault(key, {})[m.group(1)] = val
                if section == "window_colors":
                    parse_theme_file._wd = d
                else:
                    parse_theme_file._bd = d
    for (section, name), vals in getattr(parse_theme_file, "_wd", {}).items():
        if section == "window_colors":
            theme["client"][name] = [vals[k] for k in ["border", "background", "text", "indicator"] if k in vals]
    for (section, name), vals in getattr(parse_theme_file, "_bd", {}).items():
        if section == "bar_colors":
            theme["bar"][name] = [vals[k] for k in ["border", "background", "text"] if k in vals]
    parse_theme_file._wd = {}
    parse_theme_file._bd = {}
    return theme if theme["client"] or theme["bar"] else None


COLOR_NAMES = {
    "#000000": "black", "#ffffff": "white", "#FFFFFF": "white", "#fdf6e3": "oldlace", "#FDF6E3": "oldlace",
    "#859900": "olive", "#6c71c4": "slateblue", "#6C71C4": "slateblue", "#073642": "darkslategray",
    "#eee8d5": "antiquewhite", "#EEE8D5": "antiquewhite", "#93a1a1": "darkgray", "#93A1A1": "darkgray",
    "#586e75": "dimgray", "#586E75": "dimgray", "#d33682": "mediumvioletred", "#D33682": "mediumvioletred",
    "#dc322f": "crimson", "#DC322F": "crimson",
}


def name_for_color(hex_color, used):
    base = COLOR_NAMES.get(hex_color, COLOR_NAMES.get(hex_color.lower()))
    if not base:
        base = "color" + hex_color[1:].lower()
    name = base
    n = 2
    while name in used and used[name].lower() != hex_color.lower():
        name = f"{base}{n}"
        n += 1
    used[name] = hex_color.upper()
    return name


def to_theme(text):
    win_keys = {"client.focused": "focused", "client.focused_inactive": "focused_inactive", "client.unfocused": "unfocused", "client.urgent": "urgent"}
    bar_keys = set(BAR_ORDER)
    clients = {}
    bars = {}
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        key = s.split()[0]
        vals = HEX_RE.findall(s)
        if key in win_keys and len(vals) >= 4:
            clients[win_keys[key]] = vals[:4]
        elif key in bar_keys:
            bars[key] = vals[:3] if key.endswith("_workspace") else vals[:1]
    used = {}
    all_colors = []
    for key in CLIENT_ORDER:
        all_colors += clients.get(key, [])
    for key in BAR_ORDER:
        all_colors += bars.get(key, [])
    color_refs = {c.lower(): name_for_color(c, used) for c in all_colors}
    out = ["---\n", "meta:\n", "  description: AUTOMATICALLY GENERATED THEME\n", "colors:\n"]
    for name, val in used.items():
        out.append(f'  {name}: "{val}"\n')
    out.append("window_colors:\n")
    for key in CLIENT_ORDER:
        if key in clients:
            vals = clients[key]
            out.append(f"  {key}:\n")
            for label, val in zip(["border", "background", "text", "indicator"], vals):
                out.append(f"    {label}: {color_refs[val.lower()]}\n")
    out.append("bar_colors: {}\n" if not bars else "bar_colors:\n")
    for key in BAR_ORDER:
        if key in bars:
            vals = bars[key]
            out.append(f"  {key}:\n")
            labels = ["border", "background", "text"] if key.endswith("_workspace") else [key]
            for label, val in zip(labels, vals):
                out.append(f"    {label}: {color_refs[val.lower()]}\n")
    return "".join(out)


def validate_config(path):
    if not shutil.which("i3"):
        return False
    try:
        return subprocess.run(["i3", "-C", "-c", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    except OSError:
        return False


def main(argv):
    if "--help" in argv or "-h" in argv:
        sys.stdout.write(help_text())
        return 0
    if "--version" in argv or "-V" in argv:
        print("i3-style 1.0")
        return 0
    if "--list-all" in argv or "-l" in argv:
        print_list()
        return 0

    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-c", "--config")
    p.add_argument("-o", "--output")
    p.add_argument("-t", "--to-theme", default="")
    p.add_argument("-s", "--save", action="store_true")
    p.add_argument("-r", "--reload", action="store_true")
    p.add_argument("theme", nargs="?")
    try:
        args = p.parse_args(argv)
    except SystemExit:
        return 1

    if args.to_theme:
        try:
            text = open(args.to_theme, encoding="utf-8").read()
            if not validate_config(args.to_theme):
                print("Could not validate config.", file=sys.stderr)
                print(f"Use `i3 -C -c {args.to_theme}` to see validation errors.", file=sys.stderr)
                return 1
            sys.stdout.write(to_theme(text))
            return 0
        except OSError:
            print("Could not find i3 config", file=sys.stderr)
            return 1

    if not args.theme:
        print("USAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n")
        print("Select a theme as the first argument. Use `--list-all` to see the themes.")
        return 1

    theme = THEMES.get(args.theme)
    if theme is None:
        theme = parse_theme_file(args.theme)
    if theme is None:
        print(f"Could not find theme `{args.theme}`", file=sys.stderr)
        return 1

    config = args.config or default_config_path()
    output = config if args.save else args.output
    if not output:
        output = config
    try:
        original = open(config, encoding="utf-8").read()
    except OSError:
        print("Could not find i3 config", file=sys.stderr)
        return 1

    transformed = transform_config(original, theme)
    if not validate_config(config):
        print("Could not validate config.", file=sys.stderr)
        print(f"Use `i3 -C -c {config}` to see validation errors.", file=sys.stderr)
        return 1

    backup_dir = os.path.join(tempfile.gettempdir(), "i3-style", str(int(time.time())))
    os.makedirs(backup_dir, exist_ok=True)
    backup = os.path.join(backup_dir, "config-input")
    try:
        with open(backup, "w", encoding="utf-8") as f:
            f.write(original)
        print(f"saving config at {config} to {backup}", file=sys.stderr)
    except OSError:
        pass

    if output:
        with open(output, "w", encoding="utf-8") as f:
            f.write(transformed)

    if args.reload:
        subprocess.run(["i3-msg", "reload"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
