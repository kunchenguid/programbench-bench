#!/usr/bin/env python3
import argparse, base64, csv, fnmatch, glob, hashlib, ipaddress, json, math, os, random, re, shlex, shutil, socket, stat, string, subprocess, sys, time, uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse


class AttrDict(dict):
    def __getattr__(self, k):
        try: return self[k]
        except KeyError: raise AttributeError(k)

def wrap(v):
    if isinstance(v, dict) and not isinstance(v, AttrDict):
        return AttrDict({str(k): wrap(val) for k, val in v.items()})
    if isinstance(v, list):
        return [wrap(x) for x in v]
    return v

def unwrap(v):
    if isinstance(v, dict):
        return {k: unwrap(val) for k, val in v.items()}
    if isinstance(v, list):
        return [unwrap(x) for x in v]
    return v

def go_str(v):
    if v is None: return "<no value>"
    if isinstance(v, bool): return "true" if v else "false"
    if isinstance(v, float):
        if v.is_integer(): return str(int(v))
        return ("%s" % v)
    if isinstance(v, list): return "[" + " ".join(go_str(x) for x in v) + "]"
    if isinstance(v, tuple): return "[" + " ".join(go_str(x) for x in v) + "]"
    if isinstance(v, dict): return "map[" + " ".join(f"{k}:{go_str(v[k])}" for k in sorted(v.keys())) + "]"
    return str(v)

def is_empty(v):
    return v is None or v is False or v == 0 or v == "" or v == [] or v == {}

def num(v):
    if isinstance(v, bool): return 1 if v else 0
    if isinstance(v, (int, float)): return v
    s = str(v)
    try:
        if "." in s or "e" in s.lower(): return float(s)
        return int(s, 0)
    except Exception:
        return 0

def maybe_int(x):
    return int(x) if isinstance(x, float) and x.is_integer() else x

def split_top(s, sep="|"):
    out, cur, q, esc, depth = [], [], None, False, 0
    for ch in s:
        if esc:
            cur.append(ch); esc=False; continue
        if q:
            cur.append(ch)
            if ch == "\\" and q != "`": esc=True
            elif ch == q: q=None
            continue
        if ch in ("'", '"', "`"):
            q=ch; cur.append(ch); continue
        if ch == "(":
            depth += 1; cur.append(ch); continue
        if ch == ")":
            depth -= 1; cur.append(ch); continue
        if ch == sep and depth == 0:
            out.append("".join(cur).strip()); cur=[]
        else:
            cur.append(ch)
    out.append("".join(cur).strip())
    return out

def tokenize(s):
    toks, i = [], 0
    while i < len(s):
        if s[i].isspace(): i += 1; continue
        if s[i] in "()":
            toks.append(s[i]); i += 1; continue
        if s[i] in ('"', "'", "`"):
            q=s[i]; j=i+1; buf=[]
            while j < len(s):
                c=s[j]
                if q != "`" and c == "\\" and j+1 < len(s):
                    nxt=s[j+1]
                    maps={"n":"\n","t":"\t","r":"\r",'"':'"',"\\":"\\"}
                    buf.append(maps.get(nxt,nxt)); j += 2; continue
                if c == q: break
                buf.append(c); j += 1
            toks.append(("str","".join(buf))); i = j+1; continue
        j=i
        while j < len(s) and not s[j].isspace() and s[j] not in "()":
            j += 1
        toks.append(s[i:j]); i=j
    return toks

class Engine:
    def __init__(self, args=None):
        self.args = args
        self.datasources = {}
        self.ds_cache = {}
        self.templates = {}
        self.plugins = {}
        self.missing = getattr(args, "missing_key", "error") if args else "error"
        self.left = getattr(args, "left_delim", None) or os.getenv("GOMPLATE_LEFT_DELIM", "{{")
        self.right = getattr(args, "right_delim", None) or os.getenv("GOMPLATE_RIGHT_DELIM", "}}")
        self.funcs = {}
        self.init_funcs()

    def init_context(self):
        return wrap({"Env": dict(os.environ)})

    def init_funcs(self):
        f = self.funcs
        def add(*a): return maybe_int(sum(num(x) for x in a))
        def sub(a,*rest):
            x=num(a)
            for r in rest: x-=num(r)
            return maybe_int(x)
        def mul(*a):
            x=1
            for r in a: x*=num(r)
            return maybe_int(x)
        def div(a,b): return num(a)/num(b)
        def seq(start, end=None, step=1):
            if end is None: start,end=1,start
            start,end,step=int(num(start)),int(num(end)),int(num(step))
            if step == 0: return []
            if end < start and step > 0: step = -step
            if end > start and step < 0: step = -step
            rem=(end-start)%step
            end -= rem
            res=[start]; last=start
            while last != end:
                last += step; res.append(last)
            return res
        for name,fn in {"add":add,"math.Add":add,"sub":sub,"math.Sub":sub,"mul":mul,"math.Mul":mul,"div":div,"math.Div":div,
                        "math.Rem":lambda a,b: int(num(a))%int(num(b)),"math.Pow":lambda a,b: math.pow(num(a),num(b)),
                        "math.Abs":lambda a: abs(num(a)),"math.Ceil":lambda a: math.ceil(num(a)),"math.Floor":lambda a: math.floor(num(a)),
                        "math.Round":lambda a: round(num(a)),"math.Max":lambda *a: max(num(x) for x in a),"math.Min":lambda *a: min(num(x) for x in a),
                        "seq":seq,"math.Seq":seq}.items(): f[name]=fn
        f.update({
            "print": lambda *a: "".join(go_str(x) for x in a),
            "println": lambda *a: " ".join(go_str(x) for x in a)+"\n",
            "printf": lambda fmt,*a: (str(fmt) % tuple(a)) if a else str(fmt),
            "eq": lambda a,b,*r: any(a == x for x in (b,)+r), "ne": lambda a,b: a != b,
            "lt": lambda a,b: a < b, "le": lambda a,b: a <= b, "gt": lambda a,b: a > b, "ge": lambda a,b: a >= b,
            "and": lambda *a: next((x for x in a if not x), a[-1] if a else None),
            "or": lambda *a: next((x for x in a if x), a[-1] if a else None),
            "not": lambda a: not bool(a), "len": lambda a: len(a), "default": lambda d,v=None: d if is_empty(v) else v,
            "conv.Default": lambda d,v=None: d if is_empty(v) else v,
            "required": lambda v=None: (_ for _ in ()).throw(Exception("a required value was not set")) if is_empty(v) else v,
            "index": self.index, "coll.Index": lambda *a: self.index(a[-1], *a[:-1]),
            "dict": self.dict_func, "coll.Dict": self.dict_func, "coll.Slice": lambda *a: list(a), "slice": lambda *a: list(a),
            "coll.GoSlice": self.go_slice, "has": self.has, "coll.Has": self.has, "coll.Keys": lambda m: sorted(list(m.keys())),
            "coll.Values": lambda m: [m[k] for k in sorted(m.keys())] if isinstance(m,dict) else list(m),
            "coll.Append": lambda item, arr: list(arr)+[item], "coll.Prepend": lambda item, arr: [item]+list(arr),
            "coll.Uniq": self.uniq, "coll.Flatten": self.flatten, "coll.Reverse": lambda a: list(reversed(list(a))),
            "coll.Sort": lambda a: sorted(list(a)), "coll.Merge": self.merge,
        })
        f.update({"getenv":lambda k,d="": os.getenv(str(k), d), "env.Getenv":lambda k,d="": os.getenv(str(k), d),
                  "env.Env":lambda: wrap(dict(os.environ)), "env.HasEnv":lambda k: str(k) in os.environ,
                  "env.ExpandEnv":lambda s: os.path.expandvars(str(s))})
        f.update({"join":lambda a,sep: str(sep).join(go_str(x) for x in a), "conv.Join":lambda a,sep: str(sep).join(go_str(x) for x in a),
                  "bool":self.to_bool, "conv.Bool":self.to_bool, "conv.ToBool":self.to_bool,
                  "conv.Atoi":lambda s:int(str(s)), "atoi":lambda s:int(str(s)), "conv.ToInt":lambda s:int(num(s)), "conv.ToInt64":lambda s:int(num(s)),
                  "conv.ToFloat64":lambda s:float(num(s)), "conv.ToString":lambda s:go_str(s),
                  "conv.ToStrings":lambda a:[go_str(x) for x in a], "conv.ParseInt":lambda s,base=10,bits=64:int(str(s),int(base)),
                  "conv.ParseUint":lambda s,base=10,bits=64:int(str(s),int(base)), "conv.ParseFloat":lambda s,bits=64:float(str(s))})
        f.update({"json":self.parse_json, "data.JSON":self.parse_json, "data.JSONArray":self.parse_json,
                  "toJSON":self.to_json, "data.ToJSON":self.to_json, "toJSONPretty":self.to_json_pretty, "data.ToJSONPretty":self.to_json_pretty,
                  "data.YAML":self.parse_yaml, "data.YAMLArray":self.parse_yaml, "data.ToYAML":self.to_yaml,
                  "yaml":self.parse_yaml, "toYAML":self.to_yaml,
                  "data.CSV":self.parse_csv, "data.CSVByRow":self.parse_csv_rows, "data.CSVByColumn":self.parse_csv_cols,
                  "datasource":self.datasource, "ds":self.datasource, "include":lambda name: self.read_source(self.datasources[str(name)], raw=True),
                  "datasourceExists":lambda name: str(name) in self.datasources, "listDatasources":lambda: sorted(self.datasources.keys())})
        f.update({"base64.Encode":lambda s: base64.b64encode(str(s).encode()).decode(),
                  "base64.Decode":lambda s: base64.b64decode(str(s)).decode(),
                  "base64.DecodeBytes":lambda s: list(base64.b64decode(str(s)))})
        for alg in ["SHA1","SHA224","SHA256","SHA384","SHA512"]:
            f["crypto."+alg]=lambda s, alg=alg: getattr(hashlib, alg.lower())(str(s).encode()).hexdigest()
        f.update({"uuid.V4":lambda: str(uuid.uuid4()), "uuid.Nil":lambda: "00000000-0000-0000-0000-000000000000",
                  "uuid.IsValid":lambda s: self.is_uuid(s), "uuid.Parse":lambda s: str(uuid.UUID(str(s)))})
        self.add_string_funcs(f); self.add_file_funcs(f); self.add_path_funcs(f); self.add_net_funcs(f); self.add_time_funcs(f); self.add_regexp_funcs(f); self.add_random_funcs(f)

    def add_string_funcs(self,f):
        f.update({
            "strings.Contains":lambda sub,s: str(sub) in str(s), "contains":lambda sub,s: str(sub) in str(s),
            "strings.HasPrefix":lambda p,s: str(s).startswith(str(p)), "strings.HasSuffix":lambda p,s: str(s).endswith(str(p)),
            "strings.ToUpper":lambda s:str(s).upper(), "toUpper":lambda s:str(s).upper(),
            "strings.ToLower":lambda s:str(s).lower(), "toLower":lambda s:str(s).lower(),
            "strings.Trim":lambda c,s:str(s).strip(str(c)), "strings.TrimLeft":lambda c,s:str(s).lstrip(str(c)), "strings.TrimRight":lambda c,s:str(s).rstrip(str(c)),
            "strings.TrimSpace":lambda s:str(s).strip(), "trimSpace":lambda s:str(s).strip(),
            "strings.TrimPrefix":lambda p,s: str(s)[len(str(p)):] if str(s).startswith(str(p)) else str(s),
            "strings.TrimSuffix":lambda p,s: str(s)[:-len(str(p))] if str(p) and str(s).endswith(str(p)) else str(s),
            "strings.ReplaceAll":lambda old,new,s: str(s).replace(str(old),str(new)), "replaceAll":lambda old,new,s: str(s).replace(str(old),str(new)),
            "strings.Split":lambda sep,s: str(s).split(str(sep)), "strings.SplitN":lambda sep,n,s: str(s).split(str(sep),int(n)-1),
            "strings.Repeat":lambda n,s: str(s)*int(num(n)), "strings.Quote":lambda s: json.dumps(str(s)), "quote":lambda s: json.dumps(str(s)),
            "strings.Squote":lambda s: "'" + str(s).replace("'","''") + "'", "squote":lambda s: "'" + str(s).replace("'","''") + "'",
            "strings.ShellQuote":lambda s: " ".join(shlex.quote(str(x)) for x in s) if isinstance(s,list) else shlex.quote(str(s)), "shellQuote":lambda s: " ".join(shlex.quote(str(x)) for x in s) if isinstance(s,list) else shlex.quote(str(s)),
            "strings.Title":lambda s: str(s).title(), "strings.Indent":lambda n,s: "\n".join(" "*int(num(n))+line for line in str(s).splitlines()),
            "strings.SkipLines":lambda n,s: "\n".join(str(s).splitlines()[int(num(n)):]), "strings.RuneCount":lambda s: len(str(s)),
            "strings.Trunc":lambda n,s: str(s)[:int(num(n))], "strings.Abbrev":lambda *a: self.abbrev(*a),
            "strings.CamelCase":lambda s: "".join(w.capitalize() for w in re.split(r"[^A-Za-z0-9]+",str(s)) if w),
            "strings.SnakeCase":lambda s: "_".join(w.lower() for w in re.split(r"[^A-Za-z0-9]+",str(s)) if w),
            "strings.KebabCase":lambda s: "-".join(w.lower() for w in re.split(r"[^A-Za-z0-9]+",str(s)) if w),
            "strings.Slug":lambda s: "-".join(w.lower() for w in re.split(r"[^A-Za-z0-9]+",str(s)) if w),
        })

    def add_file_funcs(self,f):
        f.update({"file.Exists":lambda p: os.path.exists(str(p)), "file.IsDir":lambda p: os.path.isdir(str(p)),
                  "file.Read":lambda p: Path(str(p)).read_text(), "file.ReadDir":lambda p: sorted(os.listdir(str(p))),
                  "file.Walk":lambda p: [os.path.join(r,x) for r,ds,fs in os.walk(str(p)) for x in sorted(ds+fs)],
                  "file.Write":self.file_write, "file.Stat":self.file_stat})

    def add_path_funcs(self,f):
        base={"Base":os.path.basename,"Clean":os.path.normpath,"Dir":os.path.dirname,"Ext":lambda p: os.path.splitext(str(p))[1],
              "IsAbs":os.path.isabs,"Join":lambda *a: os.path.join(*(str(x) for x in a)),"Match":lambda pat,p: fnmatch.fnmatch(str(p),str(pat)),
              "Rel":lambda base,p: os.path.relpath(str(p),str(base)),"ToSlash":lambda p:str(p).replace(os.sep,"/"),"FromSlash":lambda p:str(p).replace("/",os.sep),
              "VolumeName":lambda p:"","Split":lambda p: [os.path.dirname(str(p)), os.path.basename(str(p))]}
        for ns in ["path","filepath"]:
            for k,v in base.items(): f[f"{ns}.{k}"]=v

    def add_net_funcs(self,f):
        f.update({"net.LookupIP":lambda host: socket.gethostbyname(str(host)),
                  "net.LookupIPs":lambda host: sorted(set(x[4][0] for x in socket.getaddrinfo(str(host), None, socket.AF_INET))),
                  "net.LookupCNAME":lambda host: str(host).rstrip(".")+".",
                  "net.LookupTXT":lambda host: [], "net.ParseAddr":lambda a: ipaddress.ip_address(str(a)),
                  "net.ParsePrefix":lambda p: ipaddress.ip_network(str(p), strict=False)})

    def add_time_funcs(self,f):
        f.update({"time.Now":lambda: datetime.now(timezone.utc).isoformat().replace("+00:00","Z"),
                  "time.Unix":lambda sec,nsec=0: datetime.fromtimestamp(int(num(sec))+int(num(nsec))/1e9, timezone.utc).isoformat().replace("+00:00","Z"),
                  "time.Parse":lambda layout,s: str(s), "time.ParseDuration":lambda s: str(s)})

    def add_regexp_funcs(self,f):
        f.update({"regexp.Match":lambda pat,s: re.search(str(pat),str(s)) is not None,
                  "regexp.Find":lambda pat,s: (re.search(str(pat),str(s)).group(0) if re.search(str(pat),str(s)) else ""),
                  "regexp.FindAll":lambda pat,s,n=-1: re.findall(str(pat),str(s))[:None if int(num(n))<0 else int(num(n))],
                  "regexp.Replace":lambda pat,repl,s: re.sub(str(pat),str(repl),str(s)),
                  "regexp.ReplaceLiteral":lambda pat,repl,s: re.sub(str(pat),lambda m:str(repl),str(s)),
                  "regexp.Split":lambda pat,s,n=-1: re.split(str(pat),str(s),0 if int(num(n))<0 else int(num(n))),
                  "regexp.QuoteMeta":lambda s: re.escape(str(s))})

    def add_random_funcs(self,f):
        f.update({"random.ASCII":lambda n: "".join(random.choice(string.printable[:94]) for _ in range(int(num(n)))),
                  "random.Alpha":lambda n: "".join(random.choice(string.ascii_letters) for _ in range(int(num(n)))),
                  "random.AlphaNum":lambda n: "".join(random.choice(string.ascii_letters+string.digits) for _ in range(int(num(n)))),
                  "random.String":lambda n,chars=string.ascii_letters+string.digits: "".join(random.choice(str(chars)) for _ in range(int(num(n)))),
                  "random.Item":lambda a: random.choice(list(a)), "random.Number":lambda *a: random.randrange(int(num(a[0])) if len(a)==1 else int(num(a[0])), int(num(a[1])) if len(a)>1 else 2**31),
                  "random.Float":lambda: random.random()})

    def index(self, obj, *keys):
        cur=obj
        for k in keys:
            if isinstance(cur, dict): cur=cur.get(str(k))
            elif isinstance(cur, (list,tuple,str)): cur=cur[int(num(k))]
            else: cur=getattr(cur, str(k))
        return cur
    def dict_func(self,*a):
        d={}
        for i in range(0,len(a),2):
            d[str(a[i])] = a[i+1] if i+1 < len(a) else ""
        return wrap(d)
    def has(self, obj, item):
        return (str(item) in obj) if isinstance(obj,dict) else (item in obj)
    def go_slice(self, obj, *idx):
        vals=[int(num(x)) for x in idx]
        return obj[slice(*vals)]
    def uniq(self,a):
        out=[]
        for x in a:
            if x not in out: out.append(x)
        return out
    def flatten(self,a):
        out=[]
        for x in a:
            if isinstance(x,list): out += self.flatten(x)
            else: out.append(x)
        return out
    def merge(self,*maps):
        out={}
        for m in maps:
            if isinstance(m,dict): out.update(m)
        return wrap(out)
    def to_bool(self,v):
        if isinstance(v,bool): return v
        return str(v).lower() in ("1","t","true","y","yes","on")
    def parse_json(self,s): return wrap(json.loads(str(s)))
    def to_json(self,v): return json.dumps(unwrap(v), separators=(",",":"))
    def to_json_pretty(self,*a):
        indent = a[0] if len(a)>1 else "  "
        v = a[1] if len(a)>1 else a[0]
        return json.dumps(unwrap(v), indent=str(indent), sort_keys=False)
    def parse_yaml(self,s):
        try:
            import yaml
            return wrap(yaml.safe_load(str(s)))
        except Exception:
            return self.simple_yaml_load(str(s))
    def simple_yaml_load(self,s):
        d={}
        for line in s.splitlines():
            line=line.strip()
            if not line or line.startswith("#"): continue
            if ":" in line:
                k,v=line.split(":",1); v=v.strip()
                try: v=json.loads(v)
                except Exception: pass
                d[k.strip()]=v
        return wrap(d)
    def to_yaml(self,v):
        try:
            import yaml
            return yaml.safe_dump(unwrap(v), sort_keys=True)
        except Exception:
            if isinstance(v,dict): return "".join(f"{k}: {go_str(v[k])}\n" for k in sorted(v.keys()))
            return json.dumps(unwrap(v))+"\n"
    def parse_csv(self,s):
        return list(csv.reader(str(s).splitlines()))
    def parse_csv_rows(self,s):
        rows=list(csv.DictReader(str(s).splitlines())); return wrap(rows)
    def parse_csv_cols(self,s):
        rows=self.parse_csv_rows(s); cols={}
        for r in rows:
            for k,v in r.items(): cols.setdefault(k,[]).append(v)
        return wrap(cols)
    def file_write(self, filename, data):
        p=Path(str(filename))
        if p.is_absolute(): raise Exception("refusing to write outside current working directory")
        p.parent.mkdir(parents=True, exist_ok=True); p.write_text(go_str(data)); return ""
    def file_stat(self,p):
        st=os.stat(str(p)); mode=stat.filemode(st.st_mode)
        return wrap({"Name":os.path.basename(str(p)),"Size":st.st_size,"Mode":mode,"IsDir":stat.S_ISDIR(st.st_mode)})
    def is_uuid(self,s):
        try: uuid.UUID(str(s)); return True
        except Exception: return False
    def abbrev(self,*a):
        if len(a) == 2:
            off, width, s = 0, int(num(a[0])), str(a[1])
        else:
            off, width, s = int(num(a[0])), int(num(a[1])), str(a[2])
        if len(s) <= width: return s
        if off >= 4 and len(s) > width:
            take=max(0,width-6)
            return "..." + s[off:off+take] + "..."
        return s[:max(0,width-3)] + "..."
    def read_source(self, url, raw=False):
        u=str(url)
        if u.startswith("file://"): path=urlparse(u).path
        else: path=u
        text=Path(path).read_text()
        if raw: return text
        lower=path.lower()
        if lower.endswith(".json"): return self.parse_json(text)
        if lower.endswith((".yaml",".yml")): return self.parse_yaml(text)
        if lower.endswith(".csv"): return self.parse_csv_rows(text)
        return text
    def datasource(self,name):
        name=str(name)
        if name not in self.ds_cache: self.ds_cache[name]=self.read_source(self.datasources[name])
        return self.ds_cache[name]

    def eval_expr(self, expr, ctx, vars):
        expr=expr.strip()
        if not expr: return ""
        if expr.startswith("("):
            close=self.find_matching_paren(expr)
            if close > 0 and close < len(expr)-1 and expr[close+1] == ".":
                return self.resolve_dotted(self.eval_expr(expr[1:close], ctx, vars), expr[close+2:])
        parts=split_top(expr,"|")
        val=self.eval_cmd(parts[0], ctx, vars)
        for p in parts[1:]:
            val=self.eval_cmd(p, ctx, vars, pipe=val)
        return val

    def eval_cmd(self, cmd, ctx, vars, pipe=None):
        cmd=cmd.strip()
        if cmd.startswith("(") and cmd.endswith(")") and self.balanced(cmd[1:-1]):
            val=self.eval_expr(cmd[1:-1],ctx,vars)
            if pipe is not None: return self.apply_value(val, [pipe])
            return val
        toks=tokenize(cmd)
        if not toks: return pipe
        if len(toks)==1 and pipe is None:
            return self.atom(toks[0],ctx,vars)
        name=toks[0]
        args=[]; i=1
        while i < len(toks):
            if toks[i] == "(":
                j=self.find_close(toks,i)
                args.append(self.eval_expr(self.untok(toks[i+1:j]),ctx,vars)); i=j+1
            else:
                args.append(self.atom(toks[i],ctx,vars)); i+=1
        if pipe is not None: args.append(pipe)
        if isinstance(name, tuple): raise Exception("bad command")
        fn=self.funcs.get(name)
        if fn is None and name in self.plugins:
            return self.run_plugin(name,args)
        if fn is None and name.startswith("."):
            base=self.atom(name,ctx,vars)
            return base
        if fn is None: raise Exception(f"function {name!r} not defined")
        return fn(*args)

    def atom(self,t,ctx,vars):
        if isinstance(t,tuple) and t[0]=="str": return t[1]
        if t in ("true","false"): return t=="true"
        if t in ("nil","null"): return None
        if isinstance(t,str) and re.fullmatch(r"-?\d+",t): return int(t)
        if isinstance(t,str) and re.fullmatch(r"-?\d+\.\d+([eE]-?\d+)?",t): return float(t)
        if isinstance(t,str) and t.startswith("$"):
            return self.resolve(t, vars)
        if isinstance(t,str) and t.startswith("."):
            return self.resolve(t, ctx)
        if isinstance(t,str) and "." in t:
            parts=t.split(".")
            for n in range(len(parts),0,-1):
                prefix=".".join(parts[:n])
                if prefix in self.funcs:
                    cur=self.funcs[prefix]()
                    for part in parts[n:]:
                        cur = cur.get(part) if isinstance(cur,dict) else getattr(cur,part)
                    return cur
        return t

    def resolve(self,path,root):
        if path in (".","$"): return root
        if path.startswith("$") and isinstance(root,dict):
            m=re.match(r"^(\$[A-Za-z_][A-Za-z0-9_]*)(?:\.(.*))?$", path)
            if m and m.group(1) in root:
                cur=root[m.group(1)]
                rest=m.group(2) or ""
                for part in rest.split("."):
                    if not part: continue
                    cur = cur.get(part) if isinstance(cur,dict) else getattr(cur,part)
                return cur
        cur=root
        p=path[1:]
        if p.startswith("."): p=p[1:]
        for part in p.split("."):
            if part=="": continue
            if isinstance(cur,dict):
                if part in cur: cur=cur[part]
                elif self.missing in ("default","invalid","zero"): return None
                else: raise Exception(f"map has no entry for key {part!r}")
            elif isinstance(cur,(list,tuple)) and part.isdigit(): cur=cur[int(part)]
            else:
                cur=getattr(cur,part)
        return cur
    def resolve_dotted(self,cur,rest):
        for part in rest.split("."):
            if not part: continue
            if isinstance(cur,dict): cur=cur.get(part)
            elif isinstance(cur,(list,tuple)) and part.isdigit(): cur=cur[int(part)]
            else: cur=getattr(cur,part)
        return cur
    def find_matching_paren(self,s):
        q=None; esc=False; d=0
        for i,ch in enumerate(s):
            if esc: esc=False; continue
            if q:
                if ch == "\\" and q != "`": esc=True
                elif ch == q: q=None
                continue
            if ch in ('"', "'", "`"): q=ch; continue
            if ch=="(": d+=1
            elif ch==")":
                d-=1
                if d==0: return i
        return -1
    def balanced(self,s):
        return True
    def find_close(self,toks,i):
        d=0
        for j in range(i,len(toks)):
            if toks[j]=="(": d+=1
            elif toks[j]==")":
                d-=1
                if d==0: return j
        raise Exception("unclosed paren")
    def untok(self,toks):
        return " ".join(json.dumps(t[1]) if isinstance(t,tuple) else t for t in toks)
    def apply_value(self,val,args): return val
    def run_plugin(self,name,args):
        p=subprocess.run([self.plugins[name]]+[go_str(a) for a in args], text=True, stdout=subprocess.PIPE, check=True)
        return p.stdout.rstrip("\n")

    def render(self,text,ctx=None,vars=None):
        ctx = self.init_context() if ctx is None else ctx
        vars = {} if vars is None else vars
        return self.render_block(self.parse(text), ctx, vars)

    def parse(self,text):
        nodes=[]; pos=0
        while True:
            i=text.find(self.left,pos)
            if i<0:
                nodes.append(("text",text[pos:])); break
            if i>pos: nodes.append(("text",text[pos:i]))
            trim_left = text.startswith(self.left+"-", i)
            if trim_left and nodes and nodes[-1][0]=="text": nodes[-1]=("text",nodes[-1][1].rstrip())
            start=i+len(self.left)+(1 if trim_left else 0)
            j=text.find(self.right,start)
            if j<0:
                nodes.append(("text",text[i:])); break
            trim_right = text[j-1:j]=="-"
            action=text[start:j-(1 if trim_right else 0)].strip()
            nodes.append(("act",action))
            pos=j+len(self.right)
            if trim_right:
                while pos<len(text) and text[pos] in " \t\r\n": pos+=1
        return nodes

    def render_block(self,nodes,ctx,vars):
        out=[]; i=0
        while i < len(nodes):
            typ,val=nodes[i]
            if typ=="text": out.append(val); i+=1; continue
            a=val
            if not a or a.startswith("/*"): i+=1; continue
            word=a.split(None,1)[0]
            rest=a[len(word):].strip()
            if word=="define":
                body,j,_,_=self.collect(nodes,i+1)
                name=rest.strip().strip('"`')
                self.templates[name]=body; i=j+1; continue
            if word=="template":
                toks=tokenize(rest); name=toks[0][1] if isinstance(toks[0],tuple) else str(self.atom(toks[0],ctx,vars))
                tctx=ctx if len(toks)<2 else self.eval_expr(self.untok(toks[1:]),ctx,vars)
                out.append(self.render_block(self.templates.get(name,[]), wrap(tctx), vars.copy())); i+=1; continue
            if word in ("if","range","with"):
                body,j,elsebody,else_if=self.collect(nodes,i+1)
                expr = rest.split(":=",1)[1].strip() if word=="range" and ":=" in rest else rest
                cond=self.eval_expr(expr,ctx,vars)
                if word=="if":
                    if cond: out.append(self.render_block(body,ctx,vars.copy()))
                    elif else_if: out.append(self.render_block([("act",else_if)]+elsebody,ctx,vars.copy()))
                    else: out.append(self.render_block(elsebody,ctx,vars.copy()))
                elif word=="with":
                    if cond: out.append(self.render_block(body,wrap(cond),vars.copy()))
                    else: out.append(self.render_block(elsebody,ctx,vars.copy()))
                else:
                    want_pair = ":=" in rest and len([x.strip() for x in rest.split(":=",1)[0].strip().split(",")]) == 2
                    seq=cond.items() if isinstance(cond,dict) else (enumerate(cond or []) if want_pair else (cond or []))
                    did=False
                    for item in seq:
                        did=True
                        nvars=vars.copy()
                        if ":=" in rest:
                            lhs=rest.split(":=",1)[0].strip()
                            names=[x.strip() for x in lhs.split(",")]
                            if len(names)==2 and isinstance(item,tuple):
                                nvars[names[0]]=item[0]; nvars[names[1]]=item[1]; dot=item[1]
                            else: nvars[names[-1]]=item; dot=item[1] if isinstance(item,tuple) else item
                        else: dot=item[1] if isinstance(item,tuple) else item
                        out.append(self.render_block(body,wrap(dot),nvars))
                    if not did: out.append(self.render_block(elsebody,ctx,vars.copy()))
                i=j+1; continue
            if word in ("else","end"): return "".join(out)
            if ":=" in a or re.match(r"^\$\w+\s=",a):
                op=":=" if ":=" in a else "="
                lhs,rhs=a.split(op,1); vars[lhs.strip()]=self.eval_expr(rhs,ctx,vars); i+=1; continue
            out.append(go_str(self.eval_expr(a,ctx,vars))); i+=1
        return "".join(out)

    def collect(self,nodes,start):
        body=[]; elsebody=[]; cur=body; depth=0; else_if=None; i=start
        while i < len(nodes):
            typ,val=nodes[i]
            if typ=="act":
                w=val.split(None,1)[0] if val.split() else ""
                if w in ("if","range","with","define"): depth+=1
                elif w=="end":
                    if depth==0: return body,i,elsebody,else_if
                    depth-=1
                elif w=="else" and depth==0:
                    if val.startswith("else if "):
                        else_if=val[5:].strip()
                    cur=elsebody; i+=1; continue
            cur.append(nodes[i]); i+=1
        return body,i,elsebody,else_if

def add_arg(parser,*a,**kw):
    parser.add_argument(*a,**kw)

def parse_ds(s):
    if "=" in s:
        k,v=s.split("=",1)
    else:
        v=s; k=os.path.splitext(os.path.basename(s))[0]
    return k,v

def main(argv=None):
    p=argparse.ArgumentParser(prog="gomplate", description="Process text files with Go templates", add_help=False)
    p.add_argument("-h","--help",action="store_true"); p.add_argument("-v","--version",action="store_true")
    p.add_argument("-i","--in",dest="in_str"); p.add_argument("-f","--file",action="append",default=[])
    p.add_argument("-o","--out",action="append",default=[]); p.add_argument("-d","--datasource",action="append",default=[])
    p.add_argument("-c","--context",action="append",default=[]); p.add_argument("-t","--template",action="append",default=[])
    p.add_argument("--plugin",action="append",default=[]); p.add_argument("--input-dir"); p.add_argument("--output-dir",default=".")
    p.add_argument("--output-map"); p.add_argument("--exclude",action="append",default=[]); p.add_argument("--include",action="append",default=[])
    p.add_argument("--exclude-processing",action="append",default=[]); p.add_argument("--chmod")
    p.add_argument("--left-delim",default=os.getenv("GOMPLATE_LEFT_DELIM","{{")); p.add_argument("--right-delim",default=os.getenv("GOMPLATE_RIGHT_DELIM","}}"))
    p.add_argument("--missing-key",default="error"); p.add_argument("--config",default=".gomplate.yaml")
    p.add_argument("-H","--datasource-header",action="append",default=[]); p.add_argument("--experimental",action="store_true"); p.add_argument("-V","--verbose",action="store_true")
    args, extra = p.parse_known_args(argv)
    if args.help:
        print("""Process text files with Go templates

Usage:
  gomplate [flags]

Flags:
  -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.
  -c, --context datasource           pre-load a datasource into the context, in alias=URL form. Use the special alias `.` to set the root context.
  -f, --file file                    Template file to process. Omit to use standard input, or use --in or --input-dir (default [-])
  -i, --in string                    Template string to process (alternative to --file and --input-dir)
  -o, --out file                     output file name. Omit to use standard output. (default [-])
  -h, --help                         help for gomplate
  -v, --version                      version for gomplate"""); return 0
    if args.version:
        print("gomplate version 0.0.0"); return 0
    e=Engine(args)
    cfg_path = os.getenv("GOMPLATE_CONFIG", args.config)
    if cfg_path and os.path.exists(cfg_path):
        try:
            cfg = e.parse_yaml(Path(cfg_path).read_text()) or {}
            if not args.in_str and not args.file and not args.input_dir:
                args.in_str = cfg.get("in")
                args.file = list(cfg.get("inputFiles") or [])
                args.input_dir = cfg.get("inputDir")
            if not args.out:
                args.out = list(cfg.get("outputFiles") or [])
            args.output_dir = cfg.get("outputDir", args.output_dir)
            args.output_map = cfg.get("outputMap", args.output_map)
            args.chmod = cfg.get("chmod", args.chmod)
            args.missing_key = cfg.get("missingKey", args.missing_key)
            args.left_delim = cfg.get("leftDelim", args.left_delim)
            args.right_delim = cfg.get("rightDelim", args.right_delim)
            args.exclude += list(cfg.get("excludes") or [])
            args.exclude_processing += list(cfg.get("excludeProcessing") or [])
            for k,v in (cfg.get("datasources") or {}).items():
                args.datasource.append(f"{k}={v.get('url') if isinstance(v,dict) else v}")
            for k,v in (cfg.get("context") or {}).items():
                args.context.append(f"{k}={v.get('url') if isinstance(v,dict) else v}")
            for k,v in (cfg.get("plugins") or {}).items():
                args.plugin.append(f"{k}={v.get('cmd') if isinstance(v,dict) else v}")
            e.left, e.right, e.missing = args.left_delim, args.right_delim, args.missing_key
        except Exception:
            pass
    for ds in args.datasource:
        k,v=parse_ds(ds); e.datasources[k]=v
    ctx=e.init_context()
    for c in args.context:
        k,v=parse_ds(c); data=e.read_source(v)
        if k==".": ctx=wrap(data)
        else: ctx[k]=wrap(data)
    for t in args.template:
        k,v=parse_ds(t); e.templates[k]=e.parse(Path(v).read_text() if os.path.isfile(v) else str(v))
    for pl in args.plugin:
        k,v=parse_ds(pl); e.plugins[k]=v
    if args.input_dir:
        process_dir(e,args,ctx); return 0
    if args.in_str is not None:
        inputs=[("<arg>", args.in_str)]
    else:
        files=args.file or ["-"]; inputs=[]
        for f in files:
            inputs.append((f, sys.stdin.read() if f=="-" else Path(f).read_text()))
    outs=args.out or ["-"]*len(inputs)
    if len(outs)==1 and len(inputs)>1: outs=outs*len(inputs)
    for (name,text),outp in zip(inputs,outs):
        res=e.render(text,ctx)
        if outp=="-": sys.stdout.write(res)
        else:
            Path(outp).parent.mkdir(parents=True, exist_ok=True); Path(outp).write_text(res)
            if args.chmod: os.chmod(outp, int(args.chmod,8))
    return 0

def process_dir(e,args,ctx):
    indir=Path(args.input_dir)
    for path in sorted(p for p in indir.rglob("*") if p.is_file()):
        rel=str(path.relative_to(indir))
        if args.include and not any(fnmatch.fnmatch(rel,pat) for pat in args.include): continue
        if any(fnmatch.fnmatch(rel,pat) for pat in args.exclude): continue
        outrel=rel
        if args.output_map:
            mctx=wrap({"in":rel,"ctx":ctx})
            outrel=e.render(args.output_map,mctx).strip()
        out=Path(args.output_dir)/outrel
        out.parent.mkdir(parents=True, exist_ok=True)
        if any(fnmatch.fnmatch(rel,pat) for pat in args.exclude_processing):
            shutil.copyfile(path,out)
        else:
            out.write_text(e.render(path.read_text(),ctx))
        if args.chmod: os.chmod(out, int(args.chmod,8))

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        sys.stderr.write(json.dumps({"time":datetime.now(timezone.utc).isoformat().replace("+00:00","Z"),"level":"ERROR","msg":"","err":str(exc)})+"\n")
        sys.exit(1)
