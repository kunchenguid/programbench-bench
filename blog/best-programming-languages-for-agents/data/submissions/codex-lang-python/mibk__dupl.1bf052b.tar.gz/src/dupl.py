#!/usr/bin/env python3
import argparse
import html
import os
import re
import sys
import time
from dataclasses import dataclass
from typing import List, Tuple, Dict

HELP = """Usage: dupl [flags] [paths]

Paths:
  If the given path is a file, dupl will use it regardless of
  the file extension. If it is a directory, it will recursively
  search for *.go files in that directory.

  If no path is given, dupl will recursively search for *.go
  files in the current directory.

Flags:
  -files
    \tread file names from stdin one at each line
  -html
    \toutput the results as HTML, including duplicate code fragments
  -plumbing
    \tplumbing (easy-to-parse) output for consumption by scripts or tools
  -t, -threshold size
    \tminimum token sequence size as a clone (default 15)
  -vendor
    \tcheck files in vendor directory
  -v, -verbose
    \texplain what is being done

Examples:
  dupl -t 100
    \tSearch clones in the current directory of size at least
    \t100 tokens.
  dupl $(find app/ -name '*_test.go')
    \tSearch for clones in tests in the app directory.
  find app/ -name '*_test.go' |dupl -files
    \tThe same as above.
"""

KEYWORDS = {
    'break','default','func','interface','select','case','defer','go','map','struct',
    'chan','else','goto','package','switch','const','fallthrough','if','range','type',
    'continue','for','import','return','var'
}
MULTI_OPS = ['>>=','<<=','&^=','...',':=','++','--','==','!=','<=','>=','&&','||','<-','+=','-=','*=','/=','%=','&=','|=','^=','<<','>>','&^']
SINGLE = set('+-*/%&|^<>=!()[]{}.,;:')

@dataclass(frozen=True)
class Tok:
    val: str
    file: str
    line: int

@dataclass
class Occ:
    start: int
    length: int
    file: str
    start_line: int
    end_line: int

@dataclass
class Group:
    occs: List[Occ]
    length: int


def log(msg):
    now = time.strftime('%Y/%m/%d %H:%M:%S', time.localtime())
    print(f'{now} {msg}', file=sys.stderr)


def collect(paths, use_files, vendor):
    items = []
    if use_files:
        items.extend([x.strip() for x in sys.stdin if x.strip()])
    items.extend(paths)
    if not items:
        items = ['.']
    out = []
    for p in items:
        if os.path.isfile(p):
            out.append(p)
        elif os.path.isdir(p):
            for root, dirs, files in os.walk(p):
                if not vendor:
                    dirs[:] = [d for d in dirs if d != 'vendor']
                dirs.sort(); files.sort()
                for f in files:
                    if f.endswith('.go'):
                        out.append(os.path.join(root, f))
        else:
            log(f'lstat {p}: no such file or directory')
    return out


def tokenize_file(path):
    try:
        text = open(path, 'r', encoding='utf-8', errors='replace').read()
    except OSError as e:
        log(str(e)); return [], []
    lines = text.splitlines()
    toks = []
    i = 0; line = 1; n = len(text)
    while i < n:
        c = text[i]
        if c in ' \t\r\f':
            i += 1; continue
        if c == '\n':
            line += 1; i += 1; continue
        if text.startswith('//', i):
            j = text.find('\n', i+2)
            if j < 0: break
            i = j; continue
        if text.startswith('/*', i):
            j = text.find('*/', i+2)
            seg = text[i:n if j < 0 else j+2]
            line += seg.count('\n')
            i = n if j < 0 else j+2
            continue
        if c == '`':
            start = line; i += 1
            while i < n and text[i] != '`':
                if text[i] == '\n': line += 1
                i += 1
            if i < n: i += 1
            toks.append(Tok('LIT', path, start)); continue
        if c in ('"', "'"):
            quote = c; start = line; i += 1
            while i < n:
                if text[i] == '\n': line += 1
                if text[i] == '\\':
                    i += 2; continue
                if text[i] == quote:
                    i += 1; break
                i += 1
            toks.append(Tok('LIT', path, start)); continue
        if c.isalpha() or c == '_':
            j = i+1
            while j < n and (text[j].isalnum() or text[j] == '_'):
                j += 1
            word = text[i:j]
            toks.append(Tok(word if word in KEYWORDS else 'ID', path, line))
            i = j; continue
        if c.isdigit() or (c == '.' and i+1 < n and text[i+1].isdigit()):
            j = i+1
            while j < n and (text[j].isalnum() or text[j] in '._'):
                j += 1
            toks.append(Tok('LIT', path, line)); i = j; continue
        matched = False
        for op in MULTI_OPS:
            if text.startswith(op, i):
                toks.append(Tok(op, path, line)); i += len(op); matched = True; break
        if matched: continue
        if c in SINGLE:
            toks.append(Tok(c, path, line)); i += 1; continue
        i += 1
    # The Go parser does not treat the package clause as cloneable code.
    if toks and toks[0].val == 'package':
        pkg_line = toks[0].line
        toks = [t for t in toks if t.line != pkg_line]
    return toks, lines


def same_file_nonoverlap(starts, length, tokens):
    byf = {}
    for s in starts:
        byf.setdefault(tokens[s].file, []).append(s)
    for arr in byf.values():
        arr.sort()
        for a, b in zip(arr, arr[1:]):
            if a + length > b:
                return False
    return True


def find_groups(tokens: List[Tok], threshold: int) -> List[Group]:
    vals = [t.val for t in tokens]
    n = len(vals)
    if threshold <= 0: threshold = 1
    buckets: Dict[Tuple[str,...], List[int]] = {}
    for i in range(0, n - threshold + 1):
        key = tuple(vals[i:i+threshold])
        buckets.setdefault(key, []).append(i)
    candidates = []
    seen = set()
    for starts in buckets.values():
        if len(starts) < 2: continue
        # Extend groups sharing the same threshold prefix as far as all occurrences match.
        starts = sorted(starts)
        length = threshold
        while True:
            if any(s + length >= n for s in starts): break
            nxt = vals[starts[0] + length]
            if all(vals[s + length] == nxt for s in starts[1:]):
                length += 1
            else:
                break
        # Prefer clean, non-overlapping occurrences; overlapping self matches are noisy.
        if not same_file_nonoverlap(starts, length, tokens):
            continue
        key = (tuple(starts), length)
        if key in seen: continue
        seen.add(key)
        candidates.append((length, starts))
    candidates.sort(key=lambda x: (-x[0], x[1]))
    accepted: List[Group] = []
    covered = []
    for length, starts in candidates:
        occs = []
        for s in starts:
            occs.append(Occ(s, length, tokens[s].file, tokens[s].line, tokens[s+length-1].line))
        uniq = {}
        for o in occs:
            uniq.setdefault((o.file, o.start_line, o.end_line), o)
        occs = sorted(uniq.values(), key=lambda o: o.start)
        if len(occs) < 2:
            continue
        # Drop groups that are just interior slices of an already reported group.
        contained_all = True
        max_cover_count = 0
        for o in occs:
            covers = [cnt for c, cnt in covered if o.file == c.file and c.start <= o.start and o.start + o.length <= c.start + c.length]
            if not covers:
                contained_all = False; break
            max_cover_count = max(max_cover_count, max(covers))
        if contained_all and len(occs) <= max_cover_count:
            continue
        if contained_all and any(o.start_line != o.end_line for o in occs):
            continue
        accepted.append(Group(occs, length))
        covered.extend((o, len(occs)) for o in occs)
    accepted.sort(key=lambda g: min(o.start for o in g.occs))
    return accepted


def render_default(groups):
    for g in groups:
        print(f'found {len(g.occs)} clones:')
        for o in g.occs:
            print(f'  {o.file}:{o.start_line},{o.end_line}')
    print()
    print(f'Found total {len(groups)} clone groups.')


def render_plumbing(groups):
    for g in groups:
        m = len(g.occs)
        for i, o in enumerate(g.occs):
            d = g.occs[(i+1) % m]
            print(f'{o.file}:{o.start_line}-{o.end_line}: duplicate of {d.file}:{d.start_line}-{d.end_line}')


def render_html(groups, file_lines):
    print('<!DOCTYPE html>')
    print('<meta charset="utf-8"/>')
    print('<title>Duplicates</title>')
    print('<style>')
    print('\tpre {')
    print('\t\tbackground-color: #FFD;')
    print('\t\tborder: 1px solid #E2E2E2;')
    print('\t\tpadding: 1ex;')
    print('\t}')
    print('</style>')
    for idx, g in enumerate(groups, 1):
        print(f'<h1>#{idx} found {len(g.occs)} clones</h1>')
        for o in g.occs:
            print(f'<h2>{html.escape(o.file)}:{o.start_line}</h2>')
            lines = file_lines.get(o.file, [])
            frag = '\n'.join(lines[max(0,o.start_line-1):o.end_line])
            print('<pre>' + html.escape(frag) + '</pre>')


def parse(argv):
    paths=[]; files=False; html_out=False; plumbing=False; vendor=False; verbose=False; threshold=15
    i=0
    while i < len(argv):
        a=argv[i]
        if a in ('--help','-h'):
            print(HELP, file=sys.stderr, end=''); sys.exit(2)
        elif a == '-files': files=True
        elif a == '-html': html_out=True
        elif a == '-plumbing': plumbing=True
        elif a == '-vendor': vendor=True
        elif a in ('-v','-verbose'): verbose=True
        elif a in ('-t','-threshold'):
            i += 1
            if i >= len(argv):
                print(f'flag needs an argument: {a}', file=sys.stderr); print(HELP, file=sys.stderr, end=''); sys.exit(2)
            try: threshold=int(argv[i])
            except ValueError:
                print(f'invalid value "{argv[i]}" for flag {a}: parse error', file=sys.stderr); print(HELP, file=sys.stderr, end=''); sys.exit(2)
        elif a.startswith('-'):
            print(f'flag provided but not defined: {a}', file=sys.stderr); print(HELP, file=sys.stderr, end=''); sys.exit(2)
        else:
            paths.append(a)
        i += 1
    return paths, files, html_out, plumbing, vendor, verbose, threshold


def main(argv):
    paths, use_files, html_out, plumbing, vendor, verbose, threshold = parse(argv)
    files = collect(paths, use_files, vendor)
    all_tokens=[]; file_lines={}
    for f in files:
        toks, lines = tokenize_file(f)
        file_lines[f]=lines
        all_tokens.extend(toks)
        all_tokens.append(Tok('BOUNDARY:' + f, f, 10**9))
    if verbose: log('Building suffix tree')
    groups = find_groups(all_tokens, threshold)
    if verbose: log('Searching for clones')
    if html_out:
        render_html(groups, file_lines)
    elif plumbing:
        render_plumbing(groups)
    else:
        render_default(groups)
    return 0

if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
