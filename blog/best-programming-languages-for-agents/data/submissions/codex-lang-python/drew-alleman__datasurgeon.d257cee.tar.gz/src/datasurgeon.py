#!/usr/bin/env python3
import argparse
import os
import re
import sys
import time
from pathlib import Path

VERSION = "DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8"
PLUGIN_WARN = "Failed to open plugins.json file. PLUGIN_PATH: /home/agent/.DataSurgeon/plugins.json"


HELP = """Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.

Usage: executable [OPTIONS]

Options:
  -f, --file <file>            File to extract information from [default: ""]
      --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --update <update>        Updates a plugin from a GitHub repository. You can also use `ds --update all` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: ""]
      --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --list                   List all added plugins
  -C, --clean                  Only displays the matched result, rather than the entire line
      --directory <directory>  Process all files found in the specified directory [default: ""]
      --ignore                 Silences error messages
  -l, --line                   Displays the line number where the match occurred
  -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line
  -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)
  -S, --suppress               Suppress the 'Reading standard input' message when not providing a file
      --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop "^.{1,10}$" will hide all matches not under 10 characters) [default: ""]
      --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: ""]
  -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.
  -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: ""]
  -t, --time                   Time how long the operation took
  -e, --email                  Extract email addresses
  -p, --phone                  Extracts phone numbers
  -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)
  -i, --ip-addr                Extract IP addresses
  -6, --ipv6-addr              Extract IPv6 addresses
  -m, --mac-addr               Extract MAC addresses
  -c, --credit-card            Extract credit card numbers
  -u, --url                    Extract urls
  -F, --files                  Extract filenames
  -b, --bitcoin                Extract bitcoin wallets
  -a, --aws                    Extract AWS keys
  -g, --google                 Extract Google service account private key ids (used for google automations services)
  -d, --dns                    Extract Domain Name System records
  -s, --social                 Extract social security numbers
  -h, --help                   Print help
  -V, --version                Print version"""


PATTERNS = [
    ("files", "files", re.compile(r"(?:https?://[^\s'\"<>]+/)?[^\s'\"<>]*\.(?:txt|pdf|docx?|xlsx?|pptx?|csv|json|xml|html?|php|asp|aspx|jsp|js|css|png|jpe?g|gif|zip|tar|gz|7z|rar|log|db|sql|bak|conf|ini|exe|dll|sh|py|rs|go|c|cpp|h)\b", re.I)),
    ("hash", "hashes", re.compile(r"\b(?:[A-Fa-f0-9]{16}|[A-Fa-f0-9]{32}|[A-Fa-f0-9]{40}|[A-Fa-f0-9]{56}|[A-Fa-f0-9]{64}|[A-Fa-f0-9]{96}|[A-Fa-f0-9]{128}|\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53})\b")),
    ("email", "email", re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")),
    ("url", "url", re.compile(r"\bhttps?://[^\s'\"<>]+", re.I)),
    ("ip", "ip_address", re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b")),
    ("ipv6", "ipv6_address", re.compile(r"\b(?:[A-Fa-f0-9]{1,4}:){1,7}:?[A-Fa-f0-9]{0,4}\b|::[A-Fa-f0-9]{1,4}\b")),
    ("mac", "mac_address", re.compile(r"\b[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}\b")),
    ("credit", "credit_card", re.compile(r"\b(?:\d[ -]*?){13,19}\b")),
    ("bitcoin", "bitcoin_wallet", re.compile(r"\b(?:bc1[ac-hj-np-z02-9]{11,71}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\b")),
    ("aws", "aws_keys", re.compile(r"\baws_(?:access_key_id|secret_access_key)\s*=\s*[A-Za-z0-9/+=]{16,}\b", re.I)),
    ("google", "google", re.compile(r"\bprivate_key_id\b[^A-Fa-f0-9]*([A-Fa-f0-9]{40})\b", re.I)),
    ("dns", "dns", re.compile(r"\b(?:IN\s+)?(?:A|AAAA|CNAME|MX|NS|TXT|SOA|PTR)\s+[A-Za-z0-9_.-]+\b", re.I)),
    ("social", "social_security", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("phone", "phone", re.compile(r"a^")),
]

FLAG_TO_KEY = {
    "email": "email", "phone": "phone", "hash": "hash", "ip_addr": "ip",
    "ipv6_addr": "ipv6", "mac_addr": "mac", "credit_card": "credit",
    "url": "url", "files": "files", "bitcoin": "bitcoin", "aws": "aws",
    "google": "google", "dns": "dns", "social": "social",
}


def warn(args):
    if not getattr(args, "ignore", False):
        print(PLUGIN_WARN, file=sys.stderr)


def parse(argv):
    if "-h" in argv or "--help" in argv:
        dummy = argparse.Namespace(ignore=False)
        warn(dummy)
        print(HELP)
        raise SystemExit(0)
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-f", "--file", default="")
    p.add_argument("--add", default="")
    p.add_argument("--update", default="")
    p.add_argument("--remove", default="")
    p.add_argument("--list", action="store_true")
    p.add_argument("-C", "--clean", action="store_true")
    p.add_argument("--directory", default="")
    p.add_argument("--ignore", action="store_true")
    p.add_argument("-l", "--line", action="store_true")
    p.add_argument("-T", "--thorough", action="store_true")
    p.add_argument("-D", "--display", action="store_true")
    p.add_argument("-S", "--suppress", action="store_true")
    p.add_argument("--drop", default="")
    p.add_argument("--filter", default="")
    p.add_argument("-X", "--hide", action="store_true")
    p.add_argument("-o", "--output", default="")
    p.add_argument("-t", "--time", action="store_true")
    p.add_argument("-e", "--email", action="store_true")
    p.add_argument("-p", "--phone", action="store_true")
    p.add_argument("-H", "--hash", action="store_true")
    p.add_argument("-i", "--ip-addr", action="store_true")
    p.add_argument("-6", "--ipv6-addr", action="store_true")
    p.add_argument("-m", "--mac-addr", action="store_true")
    p.add_argument("-c", "--credit-card", action="store_true")
    p.add_argument("-u", "--url", action="store_true")
    p.add_argument("-F", "--files", action="store_true")
    p.add_argument("-b", "--bitcoin", action="store_true")
    p.add_argument("-a", "--aws", action="store_true")
    p.add_argument("-g", "--google", action="store_true")
    p.add_argument("-d", "--dns", action="store_true")
    p.add_argument("-s", "--social", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    return p.parse_args(argv)


def selected(args):
    keys = {key for attr, key in FLAG_TO_KEY.items() if getattr(args, attr)}
    return [(k, label, rx) for k, label, rx in PATTERNS if k in keys]


def iter_inputs(args):
    if args.directory:
        for root, _, files in os.walk(args.directory):
            for name in sorted(files):
                path = os.path.join(root, name)
                try:
                    with open(path, "r", errors="ignore") as f:
                        for n, line in enumerate(f, 1):
                            yield path, n, line.rstrip("\n")
                except OSError as e:
                    if not args.ignore:
                        print(f"[-] Failed to read file: {path}. Reason: {e}", file=sys.stderr)
    elif args.file:
        if not os.path.exists(args.file):
            if not args.ignore:
                print(f"[-] File not found: {args.file}", file=sys.stderr)
            raise SystemExit(1)
        with open(args.file, "r", errors="ignore") as f:
            for n, line in enumerate(f, 1):
                yield args.file, n, line.rstrip("\n")
    else:
        if not args.suppress:
            print("[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)", file=sys.stderr)
        for n, line in enumerate(sys.stdin, 1):
            yield "", n, line.rstrip("\n")


def clean_file_match(match):
    value = match.group(0)
    if "/" in value:
        return value.rsplit("/", 1)[-1]
    return value


def find_matches(line, extractors, args):
    out = []
    for key, label, rx in extractors:
        found = []
        for m in rx.finditer(line):
            val = m.group(1) if key == "google" and m.lastindex else m.group(0)
            if key == "files":
                val = clean_file_match(m)
            found.append(val)
        if not found:
            continue
        if args.clean:
            for val in found:
                out.append((label, val))
                if not args.thorough:
                    return out
        else:
            out.append((label, line))
            if args.thorough:
                for val in found:
                    out.append((label, val))
            if not args.thorough:
                return out
    return out


def render(label, data, path, line_no, args, csv_mode=False):
    if csv_mode:
        cols = [label]
        if args.display:
            cols.append(path)
        if args.line:
            cols.append(str(line_no))
        cols.append(data)
        return ", ".join(cols)
    prefix = "" if args.hide else label
    if args.display and args.line:
        return f"{prefix + ', ' if prefix else ''}file: {path} {data}, line: {line_no}"
    if args.display:
        return f"{prefix + ', ' if prefix else ''}file: {path} {data}"
    if args.line:
        return f"{prefix + ', ' if prefix else ''}{data}, line: {line_no}"
    if args.hide:
        return data
    return f"{label}: {data}"


def main(argv):
    args = parse(argv)
    warn(args)
    if args.version:
        print(VERSION)
        return 0
    if args.list:
        print("No plugins found. Plugin File: /home/agent/.DataSurgeon/plugins.json")
        return 1
    if args.add:
        print("[-] Error: Failed to parse plugins.json from the provided URL. Reason: builder error: relative URL without a base", file=sys.stderr)
        return 1
    if args.remove or args.update:
        return 1

    start = time.time()
    extractors = selected(args)
    lines = []
    try:
        filt = re.compile(args.filter) if args.filter else None
        drop = re.compile(args.drop) if args.drop else None
    except re.error as e:
        if not args.ignore:
            print(f"[-] Regex error: {e}", file=sys.stderr)
        return 1

    csv_mode = bool(args.output and (args.line or args.display))
    if csv_mode:
        headers = ["content_type"]
        if args.display:
            headers.append("file")
        if args.line:
            headers.append("line")
        headers.append("data")
        lines.append(", ".join(headers))

    for path, line_no, line in iter_inputs(args):
        if filt and not filt.search(line):
            continue
        if drop and drop.search(line):
            continue
        for label, data in find_matches(line, extractors, args):
            lines.append(render(label, data, path, line_no, args, csv_mode))

    if args.time:
        lines.append(f"Time elapsed: {time.time() - start:.2f}s")
    text = "\n".join(lines)
    if text:
        text += "\n"
    if args.output:
        Path(args.output).write_text(text)
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
