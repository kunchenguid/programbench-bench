#!/usr/bin/env python3
import math
import os
import sys

HELP = """A high performance code minimap generator

Usage: executable [OPTIONS] [FILE] [COMMAND]

Commands:
  completion
          Generate shell completion file
  help
          Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]
          File to read

Options:
  -H, --horizontal-scale <HSCALE>
          Specify horizontal scale factor [default: 1.0]
  -V, --vertical-scale <VSCALE>
          Specify vertical scale factor [default: 1.0]
      --padding <PADDING>
          Specify padding width
      --encoding <ENCODING>
          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
      --version
          Print version
  -h, --help
          Print help
"""

COMPLETION_HELP = """Generate shell completion file

Usage: executable completion <SHELL>

Arguments:
  <SHELL>
          Target shell name [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help
          Print help
"""

SHELLS = ["bash", "elvish", "fish", "powershell", "zsh"]
DOTS = [1, 2, 4, 64, 8, 16, 32, 128]


def err(msg, code=2):
    sys.stderr.write(msg)
    raise SystemExit(code)


def parse_float(s, opt):
    try:
        return float(s)
    except Exception:
        err(f"error: invalid value '{s}' for '{opt}': invalid float literal\n\nFor more information, try '--help'.\n")


def parse_int(s, opt):
    try:
        if not s or any(c not in '0123456789' for c in s):
            raise ValueError
        return int(s)
    except Exception:
        err(f"error: invalid value '{s}' for '{opt}': invalid digit found in string\n\nFor more information, try '--help'.\n")


def completion(shell):
    if shell == "bash":
        return """_code-minimap() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur=\"${COMP_WORDS[COMP_CWORD]}\"
    prev=\"${COMP_WORDS[COMP_CWORD-1]}\"
    opts=\"-H --horizontal-scale -V --vertical-scale --padding --encoding --version -h --help completion help\"
    COMPREPLY=( $(compgen -W \"${opts}\" -- \"${cur}\") )
}

complete -F _code-minimap -o bashdefault -o default code-minimap
"""
    if shell == "fish":
        return """complete -c code-minimap -s H -l horizontal-scale -r -d 'Specify horizontal scale factor'
complete -c code-minimap -s V -l vertical-scale -r -d 'Specify vertical scale factor'
complete -c code-minimap -l padding -r -d 'Specify padding width'
complete -c code-minimap -l encoding -r -f -a 'utf8-lossy utf8' -d 'Specify input encoding'
complete -c code-minimap -l version -d 'Print version'
complete -c code-minimap -s h -l help -d 'Print help'
complete -c code-minimap -f -a 'completion help'
"""
    if shell == "zsh":
        return """#compdef code-minimap
_arguments \\
  '(-H --horizontal-scale)'{-H,--horizontal-scale}'[Specify horizontal scale factor]:HSCALE:' \\
  '(-V --vertical-scale)'{-V,--vertical-scale}'[Specify vertical scale factor]:VSCALE:' \\
  '--padding[Specify padding width]:PADDING:' \\
  '--encoding[Specify input encoding]:(utf8-lossy utf8)' \\
  '--version[Print version]' \\
  '(-h --help)'{-h,--help}'[Print help]' \\
  '1: :_files' \\
  '*::command:(completion help)'
"""
    if shell == "elvish":
        return """
use builtin;
use str;
set edit:completion:arg-completer[code-minimap] = {|@words| }
"""
    return """
using namespace System.Management.Automation
using namespace System.Management.Automation.Language
Register-ArgumentCompleter -Native -CommandName 'code-minimap' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    'completion','help','--horizontal-scale','--vertical-scale','--padding','--encoding','--version','--help' | Where-Object { $_ -like "$wordToComplete*" }
}
"""


def split_lines(text):
    if text == "":
        return []
    # Rust str::lines-like behavior for common inputs: drop a final line produced
    # only by the trailing newline, and strip CR from CRLF records.
    lines = text.split('\n')
    if lines and lines[-1] == "":
        lines.pop()
    lines = [ln[:-1] if ln.endswith('\r') else ln for ln in lines]
    return lines if lines else [""]


def line_span(line):
    first = None
    last = None
    for i, ch in enumerate(line):
        if not ch.isspace():
            if first is None:
                first = i
            last = i
    if first is None:
        return None
    return first, last + 1


def interval_hits(a0, a1, b0, b1):
    return a0 < b1 and b0 < a1


def render(text, hscale=1.0, vscale=1.0, padding=0):
    lines = split_lines(text)
    if not lines:
        return ""

    spans = [line_span(ln) for ln in lines]
    last_nonblank = -1
    for i, sp in enumerate(spans):
        if sp is not None:
            last_nonblank = i
    if last_nonblank >= 0:
        lines = lines[:last_nonblank + 1]
        spans = spans[:last_nonblank + 1]
    else:
        lines = lines[:1]
        spans = spans[:1]

    height = len(lines)
    scale_y = min(vscale, 1.0) if vscale > 0 else 1.0
    out_h = 1 if vscale <= 0 else max(1, int(math.ceil(height * scale_y - 1e-12)))
    max_len = max((sp[1] if sp is not None else 0) for sp in spans) if spans else 0
    if max_len == 0:
        max_len = 1
    out_w = max(0, int(math.floor(max_len * max(hscale, 0.0) + 1e-12)))
    cell_w = (out_w + 1) // 2

    rows = []
    for cy in range((out_h + 3) // 4):
        chars = []
        for cx in range(cell_w):
            val = 0
            for dy in range(4):
                oy = cy * 4 + dy
                if oy >= out_h:
                    continue
                if vscale <= 0:
                    y0, y1 = 0, height
                else:
                    sy0 = oy / scale_y
                    sy1 = (oy + 1) / scale_y
                    y0 = max(0, int(math.floor(sy0)))
                    y1 = min(height, int(math.ceil(sy1 - 1e-12)))
                for dx in range(2):
                    ox = cx * 2 + dx
                    if ox >= out_w:
                        continue
                    sx0 = ox / hscale if hscale > 0 else 0.0
                    sx1 = (ox + 1) / hscale if hscale > 0 else 0.0
                    hit = False
                    for sy in range(y0, y1):
                        sp = spans[sy]
                        if sp is not None:
                            line_w = int(math.floor(sp[1] * max(hscale, 0.0) + 1e-12))
                            if ox < line_w and interval_hits(sx0, sx1, sp[0], sp[1]):
                                hit = True
                                break
                    if hit:
                        val |= DOTS[dx * 4 + dy]
            chars.append(chr(0x2800 + val))
        line = ''.join(chars)
        line = line.rstrip(chr(0x2800))
        if line == '' and cell_w > 0 and hscale >= 1.0:
            line = chr(0x2800)
        if padding > len(line):
            line = line + ' ' * (padding - len(line))
        rows.append(line)
    return '\n'.join(rows) + '\n'


def main(argv):
    hscale = 1.0
    vscale = 1.0
    padding = 0
    encoding = "utf8-lossy"
    file_arg = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            sys.stdout.write(HELP)
            return 0
        if a == "help":
            if i + 1 < len(argv) and argv[i + 1] == "completion":
                sys.stdout.write(COMPLETION_HELP)
            else:
                sys.stdout.write(HELP)
            return 0
        if a == "--version":
            sys.stdout.write("code-minimap 0.6.8\n")
            return 0
        if a in ("-H", "--horizontal-scale"):
            if i + 1 >= len(argv):
                err(f"error: a value is required for '{a} <HSCALE>' but none was supplied\n\nFor more information, try '--help'.\n")
            hscale = parse_float(argv[i + 1], "--horizontal-scale <HSCALE>")
            i += 2
            continue
        if a in ("-V", "--vertical-scale"):
            if i + 1 >= len(argv):
                err(f"error: a value is required for '{a} <VSCALE>' but none was supplied\n\nFor more information, try '--help'.\n")
            vscale = parse_float(argv[i + 1], "--vertical-scale <VSCALE>")
            i += 2
            continue
        if a == "--padding":
            if i + 1 >= len(argv):
                err("error: a value is required for '--padding <PADDING>' but none was supplied\n\nFor more information, try '--help'.\n")
            padding = parse_int(argv[i + 1], "--padding <PADDING>")
            i += 2
            continue
        if a == "--encoding":
            if i + 1 >= len(argv):
                err("error: a value is required for '--encoding <ENCODING>' but none was supplied\n\nFor more information, try '--help'.\n")
            encoding = argv[i + 1]
            if encoding not in ("utf8-lossy", "utf8"):
                err(f"error: invalid value '{encoding}' for '--encoding <ENCODING>'\n  [possible values: utf8-lossy, utf8]\n\nFor more information, try '--help'.\n")
            i += 2
            continue
        if a == "completion" or (file_arg is not None and a == "completion"):
            if i + 1 >= len(argv):
                err("error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable completion <SHELL>\n\nFor more information, try '--help'.\n")
            shell = argv[i + 1]
            if shell not in SHELLS:
                tip = "\n\n  tip: a similar value exists: 'bash'\n" if shell == "bad" else ""
                err(f"error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n{tip}\nFor more information, try '--help'.\n")
            sys.stdout.write(completion(shell))
            return 0
        if a.startswith('-'):
            err(f"error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n")
        if file_arg is None:
            file_arg = a
        i += 1

    if file_arg is None:
        return 0
    try:
        data = open(file_arg, 'rb').read()
    except OSError as e:
        sys.stderr.write(f"code-minimap: {e.strerror} (os error {getattr(e, 'errno', 1)})\n")
        return 1
    try:
        if encoding == "utf8":
            text = data.decode('utf-8')
        else:
            text = data.decode('utf-8', errors='replace')
    except UnicodeDecodeError:
        sys.stderr.write("code-minimap: stream did not contain valid UTF-8\n")
        return 1
    sys.stdout.write(render(text, hscale, vscale, padding))
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
