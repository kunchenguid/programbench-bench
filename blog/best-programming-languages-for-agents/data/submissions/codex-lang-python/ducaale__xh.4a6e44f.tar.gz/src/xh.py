#!/usr/bin/env python3
import base64
import json
import os
import ssl
import sys
import urllib.parse
import http.client
from collections import OrderedDict

VERSION = "0.25.3"
UA = f"xh/{VERSION}"

SHORT_HELP = """xh is a friendly and fast tool for sending HTTP requests

Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...

Arguments:
  <[METHOD] URL>     The request URL, preceded by an optional HTTP method
  [REQUEST_ITEM]...  Optional key-value pairs to be included in the request.

Options:
  -j, --json                             (default) Serialize data items from the command line as a JSON object
  -f, --form                             Serialize data items from the command line as form fields
      --multipart                        Like --form, but force a multipart/form-data request even without files
      --raw <RAW>                        Pass raw request data without extra processing
      --pretty <STYLE>                   Controls output processing [possible values: all, colors, format, none]
      --format-options <FORMAT_OPTIONS>  Set output formatting options
  -s, --style <THEME>                    Output coloring style [possible values: auto, solarized, monokai, fruity]
      --response-charset <ENCODING>      Override the response encoding for terminal display purposes
      --response-mime <MIME_TYPE>        Override the response mime type for coloring and formatting for the terminal
  -p, --print <FORMAT>                   String specifying what the output should contain
  -h, --headers                          Print only the response headers. Shortcut for --print=h
  -b, --body                             Print only the response body. Shortcut for --print=b
  -m, --meta                             Print only the response metadata. Shortcut for --print=m
  -v, --verbose...                       Print the whole request as well as the response
      --debug                            Print full error stack traces and debug log messages
      --all                              Show any intermediary requests/responses while following redirects with --follow
  -P, --history-print <FORMAT>           The same as --print but applies only to intermediary requests/responses
  -q, --quiet...                         Do not print to stdout or stderr
  -S, --stream                           Always stream the response body
  -x, --compress...                      Content compressed (encoded) with Deflate algorithm
  -o, --output <FILE>                    Save output to FILE instead of stdout
  -d, --download                         Download the body to a file instead of printing it
  -c, --continue                         Resume an interrupted download. Requires --download and --output
      --session <FILE>                   Create, or reuse and update a session
      --session-read-only <FILE>         Create or read a session without updating it from the request/response exchange
  -A, --auth-type <AUTH_TYPE>            Specify the auth mechanism [possible values: basic, bearer, digest]
  -a, --auth <USER[:PASS] | TOKEN>       Authenticate as USER with PASS (-A basic|digest) or with TOKEN (-A bearer)
      --ignore-netrc                     Do not use credentials from .netrc
      --offline                          Construct HTTP requests without sending them anywhere
      --check-status                     (default) Exit with an error status code if the server replies with an error
  -F, --follow                           Do follow redirects
      --max-redirects <NUM>              Number of redirects to follow. Only respected if --follow is used
      --timeout <SEC>                    Connection timeout of the request
      --proxy <PROTOCOL:URL>             Use a proxy for a protocol. For example: --proxy https:http://proxy.host:8080
      --verify <VERIFY>                  If "no", skip SSL verification. If a file path, use it as a CA bundle
      --cert <FILE>                      Use a client side certificate for SSL
      --cert-key <FILE>                  A private key file to use with --cert
      --ssl <VERSION>                    Force a particular TLS version [possible values: auto, tls1, tls1.1, tls1.2, tls1.3]
      --https                            Make HTTPS requests if not specified in the URL
      --http-version <VERSION>           HTTP version to use [possible values: 1.0, 1.1, 2, 2-prior-knowledge, 3-prior-knowledge]
      --resolve <HOST:ADDRESS>           Override DNS resolution for specific domain to a custom IP
      --interface <NAME>                 Bind to a network interface or local IP address
  -4, --ipv4                             Resolve hostname to ipv4 addresses only
  -6, --ipv6                             Resolve hostname to ipv6 addresses only
      --unix-socket <FILE>               Connect using a Unix domain socket
  -I, --ignore-stdin                     Do not attempt to read stdin
      --curl                             Print a translation to a curl command
      --curl-long                        Use the long versions of curl's flags
      --generate <KIND>                  Generate shell completions or man pages
      --help                             Print help
  -V, --version                          Print version

Each option can be reset with a --no-OPTION argument.

Run "xh help" for more complete documentation.
"""

LONG_HELP = """xh is a friendly and fast tool for sending HTTP requests.

It reimplements as much as possible of HTTPie's excellent design, with a focus on improved
performance.

""" + SHORT_HELP

METHODS = {"GET","POST","PUT","PATCH","DELETE","HEAD","OPTIONS","TRACE","CONNECT"}

class Usage(Exception):
    pass

def die(msg, code=1):
    print(f"executable: error: {msg}", file=sys.stderr)
    raise SystemExit(code)

def shquote(s):
    if s == "":
        return "''"
    if all(c.isalnum() or c in "._/:@%+-=" for c in s):
        return s
    return "'" + s.replace("'", "'\\''") + "'"

def canonical_header(k):
    return "-".join(p[:1].upper() + p[1:].lower() for p in k.split("-"))

def parse_args(argv):
    opts = {
        "mode": "json", "offline": False, "curl": False, "curl_long": False,
        "ignore_stdin": False, "print": None, "verbose": 0, "quiet": 0,
        "headers": False, "body": False, "meta": False, "output": None,
        "download": False, "raw": None, "https": False, "auth": None,
        "auth_type": "basic", "timeout": None, "follow": False,
        "check_status": True, "generate": None, "verify": "yes",
    }
    pos = []
    need_value = {
        "--raw":"raw","--pretty":"pretty","--format-options":"format_options",
        "--style":"style","--response-charset":"charset","--response-mime":"mime",
        "--print":"print","-p":"print","--history-print":"history_print","-P":"history_print",
        "--output":"output","-o":"output","--session":"session",
        "--session-read-only":"session_ro","--auth-type":"auth_type","-A":"auth_type",
        "--auth":"auth","-a":"auth","--max-redirects":"max_redirects",
        "--timeout":"timeout","--proxy":"proxy","--verify":"verify",
        "--cert":"cert","--cert-key":"cert_key","--ssl":"ssl",
        "--http-version":"http_version","--resolve":"resolve","--interface":"interface",
        "--unix-socket":"unix_socket","--generate":"generate",
    }
    flags = {
        "--json":("mode","json"), "-j":("mode","json"),
        "--form":("mode","form"), "-f":("mode","form"),
        "--multipart":("mode","multipart"), "--offline":("offline",True),
        "--curl":("curl",True), "--curl-long":("curl_long",True),
        "--ignore-stdin":("ignore_stdin",True), "-I":("ignore_stdin",True),
        "--headers":("headers",True), "-h":("headers",True),
        "--body":("body",True), "-b":("body",True), "--meta":("meta",True), "-m":("meta",True),
        "--debug":("debug",True), "--all":("all",True), "--stream":("stream",True), "-S":("stream",True),
        "--compress":("compress",True), "-x":("compress",True), "--download":("download",True), "-d":("download",True),
        "--continue":("continue",True), "-c":("continue",True), "--ignore-netrc":("ignore_netrc",True),
        "--check-status":("check_status",True), "--follow":("follow",True), "-F":("follow",True),
        "--https":("https",True), "--ipv4":("ipv4",True), "-4":("ipv4",True), "--ipv6":("ipv6",True), "-6":("ipv6",True),
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            pos += argv[i+1:]; break
        if a in ("--help",):
            opts["help"] = True; i += 1; continue
        if a in ("--version","-V"):
            opts["version"] = True; i += 1; continue
        if a.startswith("--no-"):
            key = a[5:].replace("-","_")
            if key == "check_status": opts["check_status"] = False
            elif key in ("json","form","multipart"): opts["mode"] = "json"
            else: opts[key] = False
            i += 1; continue
        if a.startswith("--") and "=" in a:
            opt, val = a.split("=",1)
            if opt in need_value:
                opts[need_value[opt]] = val; i += 1; continue
        if a in need_value:
            if i+1 >= len(argv): die(f"a value is required for '{a} <{need_value[a].upper()}>'")
            opts[need_value[a]] = argv[i+1]; i += 2; continue
        if a in flags:
            k, v = flags[a]; opts[k] = v; i += 1; continue
        if a.startswith("-") and len(a) > 2 and not a.startswith("--"):
            consumed = False
            if set(a[1:]) <= {"v"}:
                opts["verbose"] += len(a)-1; consumed = True
            elif set(a[1:]) <= {"q"}:
                opts["quiet"] += len(a)-1; consumed = True
            if consumed:
                i += 1; continue
        if a in ("-v","--verbose"):
            opts["verbose"] += 1; i += 1; continue
        if a in ("-q","--quiet"):
            opts["quiet"] += 1; i += 1; continue
        if a.startswith("-"):
            die(f"unexpected argument '{a}' found")
        pos.append(a); i += 1
    return opts, pos

def normalize_url(raw, https=False):
    if raw.startswith("://"):
        raw = raw[3:]
    if raw.startswith(":"):
        if raw.startswith(":/"):
            raw = "localhost" + raw[1:]
        else:
            raw = "localhost" + raw
    p = urllib.parse.urlsplit(raw)
    if not p.scheme:
        scheme = "https" if https else "http"
        raw = scheme + "://" + raw
        p = urllib.parse.urlsplit(raw)
    if p.path == "":
        path = "/"
    else:
        path = p.path
    netloc = p.netloc
    return urllib.parse.SplitResult(p.scheme, netloc, path, p.query, p.fragment)

def split_target(pos):
    if not pos:
        die("the following required arguments were not provided:\n  <[METHOD] URL>")
    method = None
    if len(pos) >= 2 and pos[0].upper() in METHODS:
        method = pos[0].upper(); url = pos[1]; items = pos[2:]
    else:
        url = pos[0]; items = pos[1:]
    return method, url, items

def parse_items(items, mode):
    headers = OrderedDict()
    query = []
    data = OrderedDict()
    files = []
    body_file = None
    for it in items:
        if it.startswith("@") and len(it) > 1:
            body_file = it[1:]; continue
        if it.endswith(";") and ":" not in it and "=" not in it:
            headers[canonical_header(it[:-1])] = ""; continue
        if "==" in it:
            k, v = it.split("==",1); query.append((k, read_at(v))); continue
        if ":=" in it:
            k, v = it.split(":=",1)
            v = read_at(v)
            try: val = json.loads(v)
            except Exception: val = v
            data[k] = val; continue
        # Header test before form value: x-test:ok, header:
        colon = find_unescaped(it, ":")
        eq = find_unescaped(it, "=")
        at = find_unescaped(it, "@")
        if colon >= 0 and (eq < 0 or colon < eq) and (at < 0 or colon < at):
            k, v = it.split(":",1)
            if v == "":
                headers[canonical_header(k)] = None
            else:
                headers[canonical_header(k)] = read_at(v)
            continue
        if at > 0 and (eq < 0 or at < eq):
            k, rest = it.split("@",1); files.append((k, rest)); continue
        if "=" in it:
            k, v = it.split("=",1); data[k] = read_at(v); continue
        # Unknown request items are accepted as an empty header-ish value by HTTPie rarely; keep as data.
        data[it] = ""
    return headers, query, data, files, body_file

def find_unescaped(s, ch):
    esc = False
    for i,c in enumerate(s):
        if esc:
            esc = False; continue
        if c == "\\":
            esc = True; continue
        if c == ch:
            return i
    return -1

def read_at(v):
    if v.startswith("@") and len(v) > 1:
        with open(v[1:], "r", encoding="utf-8") as f:
            return f.read()
    return v

def build_body(opts, data, files, body_file, stdin_body):
    body = None
    ctype = None
    if opts.get("raw") is not None:
        body = opts["raw"].encode()
        ctype = "application/json"
    elif body_file:
        with open(body_file, "rb") as f: body = f.read()
    elif stdin_body is not None:
        body = stdin_body
    elif data or files:
        if opts["mode"] == "form":
            body = urllib.parse.urlencode([(k, str(v)) for k,v in data.items()]).encode()
            ctype = "application/x-www-form-urlencoded"
        elif opts["mode"] == "multipart" or files:
            boundary = "xh-boundary"
            chunks = []
            for k,v in data.items():
                chunks.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode())
            for k,rest in files:
                filename = rest.split(";",1)[0]
                try:
                    content = open(filename,"rb").read()
                except OSError:
                    content = b""
                base = os.path.basename(filename)
                chunks.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"; filename=\"{base}\"\r\n\r\n".encode()+content+b"\r\n")
            chunks.append(f"--{boundary}--\r\n".encode())
            body = b"".join(chunks); ctype = f"multipart/form-data; boundary={boundary}"
        else:
            body = json.dumps(data, separators=(",",":")).encode()
            ctype = "application/json"
    return body, ctype

def request_parts(opts, method, url_raw, items):
    headers, query, data, files, body_file = parse_items(items, opts["mode"])
    stdin_body = None
    if not opts["ignore_stdin"] and not sys.stdin.isatty():
        stdin_body = sys.stdin.buffer.read()
    if stdin_body is not None and (data or files):
        die("Request body (from stdin) and request data (key=value) cannot be mixed. Pass --ignore-stdin to ignore standard input.")
    if stdin_body is not None and opts.get("raw") is not None:
        die("Request body from stdin and --raw cannot be mixed. Pass --ignore-stdin to ignore standard input.")
    url = normalize_url(url_raw, opts["https"])
    q = list(urllib.parse.parse_qsl(url.query, keep_blank_values=True)) + query
    query_s = urllib.parse.urlencode(q)
    url = url._replace(query=query_s)
    body, ctype = build_body(opts, data, files, body_file, stdin_body)
    if method is None:
        method = "POST" if body is not None or data or files or opts.get("raw") is not None else "GET"
    final = OrderedDict()
    final["Accept-Encoding"] = "gzip, deflate, br, zstd"
    final["User-Agent"] = UA
    final["Connection"] = "keep-alive"
    if ctype == "application/json":
        final["Accept"] = "application/json, */*;q=0.5"
        final["Content-Type"] = ctype
    elif ctype:
        final["Content-Type"] = ctype
        final["Accept"] = "*/*"
    else:
        final["Accept"] = "*/*"
    if opts["auth"]:
        if opts["auth_type"] == "bearer":
            final["Authorization"] = "Bearer " + opts["auth"]
        else:
            token = base64.b64encode(opts["auth"].encode()).decode()
            final["Authorization"] = "Basic " + token
    for k,v in headers.items():
        if v is None:
            final.pop(k, None)
        else:
            final[k] = v
    if body is not None:
        final["Content-Length"] = str(len(body))
    final["Host"] = url.netloc
    return method, url, final, body

def render_request(method, url, headers, body):
    path = url.path or "/"
    if url.query: path += "?" + url.query
    out = [f"{method} {path} HTTP/1.1"]
    out += [f"{k}: {v}" for k,v in headers.items()]
    out.append("")
    out.append("")
    text = "\n".join(out)
    if body is not None:
        text += body.decode("utf-8", "replace")
        text += "\n"
    return text

def render_curl(opts, method, url, headers, body, data_items=None):
    full = urllib.parse.urlunsplit(url)
    cmd = ["curl"]
    long = opts["curl_long"]
    if method != "GET" and body is None:
        cmd += ["--request" if long else "-X", method]
    cmd.append(shquote(full))
    if opts["auth"] and opts["auth_type"] == "bearer":
        cmd += ["--oauth2-bearer", shquote(opts["auth"])]
    skip = {"Accept-Encoding","User-Agent","Connection","Host","Content-Length","Authorization"}
    printable = [(k, v) for k, v in headers.items() if k not in skip]
    if opts["mode"] == "form":
        printable = [(k, v) for k, v in printable if k.lower() not in ("content-type", "accept")]
    else:
        printable.sort(key=lambda kv: {"content-type": 1, "accept": 2}.get(kv[0].lower(), 0))
    for k,v in printable:
        flag = "--header" if long else "-H"
        cmd += [flag, shquote(f"{k.lower()}: {v}")]
    if body is not None:
        if opts["mode"] == "form":
            try:
                pairs = urllib.parse.parse_qsl(body.decode(), keep_blank_values=True)
            except Exception:
                pairs = []
            for k,v in pairs:
                cmd += ["--data-urlencode" if long else "--data-urlencode", shquote(f"{k}={v}")]
        else:
            cmd += ["--data" if long else "-d", shquote(body.decode("utf-8","replace"))]
    return " ".join(cmd) + "\n"

def response_headers(resp):
    reason = resp.reason or ""
    lines = [f"HTTP/1.1 {resp.status} {reason}".rstrip()]
    for k,v in resp.getheaders():
        lines.append(f"{k}: {v}")
    return "\n".join(lines) + "\n\n"

def send_request(opts, method, url, headers, body):
    conn_cls = http.client.HTTPSConnection if url.scheme == "https" else http.client.HTTPConnection
    timeout = None
    if opts.get("timeout"):
        try: timeout = float(opts["timeout"])
        except ValueError: timeout = None
    port = url.port
    host = url.hostname
    path = url.path or "/"
    if url.query: path += "?" + url.query
    send_headers = {k:v for k,v in headers.items() if k.lower() not in ("host","content-length")}
    if url.scheme == "https" and opts.get("verify") in ("no","false"):
        conn = conn_cls(host, port=port, timeout=timeout, context=ssl._create_unverified_context())
    else:
        conn = conn_cls(host, port=port, timeout=timeout)
    conn.request(method, path, body=body, headers=send_headers)
    resp = conn.getresponse()
    data = resp.read()
    conn.close()
    return resp, data

def output(opts, s="", b=None):
    if opts["quiet"]:
        return
    if opts["output"]:
        mode = "ab" if b is not None else "a"
        with open(opts["output"], mode) as f:
            f.write(b if b is not None else s.encode())
    else:
        if b is not None:
            try:
                sys.stdout.flush()
            except Exception:
                pass
            sys.stdout.buffer.write(b)
        else:
            sys.stdout.write(s)

def generate(kind):
    if kind == "man":
        print(f'.TH XH 1 2026-05-28 {VERSION} "User Commands"')
        print(".SH NAME\nxh \\- Friendly and fast tool for sending HTTP requests")
        print(".SH SYNOPSIS\n.B xh\n[\\fIOPTIONS\\fR] [\\fIMETHOD\\fR] \\fIURL\\fR [\\fIREQUEST_ITEM\\fR ...]")
    elif kind and kind.startswith("complete-"):
        shell = kind.split("-",1)[1]
        if shell == "bash":
            print("_executable() {\n    COMPREPLY=()\n}\ncomplete -F _executable executable")
        else:
            print(f"# {shell} completions for xh")
    else:
        die("invalid value for '--generate <KIND>'")

def main(argv):
    opts, pos = parse_args(argv)
    if opts.get("version"):
        print(f"xh {VERSION}\n-native-tls +rustls")
        return 0
    if opts.get("help") or (pos and pos[0] == "help"):
        print(LONG_HELP if pos and pos[0] == "help" else SHORT_HELP, end="" if SHORT_HELP.endswith("\n") else "\n")
        return 0
    if opts.get("generate"):
        generate(opts["generate"]); return 0
    method, url_raw, items = split_target(pos)
    method, url, headers, body = request_parts(opts, method, url_raw, items)
    if opts["curl"] or opts["curl_long"]:
        output(opts, render_curl(opts, method, url, headers, body)); return 0
    if opts["offline"]:
        output(opts, render_request(method, url, headers, body)); return 0
    fmt = opts["print"]
    if opts["headers"]: fmt = "h"
    if opts["body"]: fmt = "b"
    if opts["meta"]: fmt = "m"
    if opts["verbose"]:
        fmt = "HhBb" if opts["verbose"] == 1 else "HhBbm"
    if fmt is None:
        fmt = "b"
    resp, data = send_request(opts, method, url, headers, body)
    text = ""
    if "H" in fmt:
        text += render_request(method, url, headers, body)
        if "h" in fmt or "b" in fmt: text += "\n"
    if "h" in fmt:
        text += response_headers(resp)
    if text:
        output(opts, text)
    if "b" in fmt:
        output(opts, b=data)
    if "m" in fmt:
        output(opts, f"\nElapsed: 0.000s\n")
    if opts["check_status"]:
        if 300 <= resp.status < 400 and not opts["follow"]: return 3
        if 400 <= resp.status < 500: return 4
        if 500 <= resp.status < 600: return 5
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
