#!/usr/bin/env python3
import argparse, json, os, re, shutil, subprocess, sys, textwrap
from pathlib import Path

VERSION = "Stacked Git 2.5.5"

class Error(Exception): pass

def run(args, check=True, capture=False, input=None):
    p = subprocess.run(args, text=True, input=input,
                       stdout=subprocess.PIPE if capture else None,
                       stderr=subprocess.PIPE if capture else None)
    if check and p.returncode != 0:
        if capture:
            if p.stdout: sys.stdout.write(p.stdout)
            if p.stderr: sys.stderr.write(p.stderr)
        raise SystemExit(p.returncode)
    return p

def git(args, check=True, capture=False, input=None):
    return run(["git"] + args, check=check, capture=capture, input=input)

def out_git(args):
    return git(args, capture=True).stdout

def err(msg, code=2):
    print(f"error: {msg}", file=sys.stderr)
    raise SystemExit(code)

def repo_root():
    p = git(["rev-parse", "--show-toplevel"], capture=True, check=False)
    if p.returncode != 0: err("not a git repository")
    return Path(p.stdout.strip())

def git_dir():
    p = git(["rev-parse", "--git-dir"], capture=True, check=False)
    if p.returncode != 0: err("not a git repository")
    gd = Path(p.stdout.strip())
    if not gd.is_absolute(): gd = Path.cwd() / gd
    return gd.resolve()

def branch():
    p = git(["symbolic-ref", "--quiet", "--short", "HEAD"], capture=True, check=False)
    if p.returncode != 0: return "HEAD"
    return p.stdout.strip()

def state_path(br=None):
    b = br or branch()
    safe = b.replace("/", "__")
    return git_dir() / "stgit_py" / (safe + ".json")

def default_state():
    base = out_git(["rev-parse", "HEAD"]).strip()
    return {"base": base, "patches": []}

def load(br=None, create=False):
    path = state_path(br)
    if path.exists():
        return json.loads(path.read_text())
    if create:
        st = default_state(); save(st, br); return st
    return {"base": out_git(["rev-parse", "HEAD"]).strip(), "patches": []}

def save(st, br=None):
    path = state_path(br); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(st, indent=2, sort_keys=True) + "\n")

def applied(st): return [p for p in st["patches"] if p.get("status") == "applied"]
def unapplied(st): return [p for p in st["patches"] if p.get("status") == "unapplied"]
def hidden(st): return [p for p in st["patches"] if p.get("status") == "hidden"]
def top_patch(st):
    a = applied(st)
    return a[-1] if a else None

def find_patch(st, name):
    if name in (None, "HEAD"):
        return top_patch(st)
    if name == "{base}": return {"name":"{base}", "commit":st["base"], "status":"base"}
    for p in st["patches"]:
        if p["name"] == name: return p
    return None

def ensure_clean_index_ok():
    return

def current_msg():
    p = top_patch(load())
    if not p: return ""
    return out_git(["log", "-1", "--format=%B", p["commit"]])

def commit_tree(message, refresh=False, paths=None, allow_empty=True):
    if refresh:
        if paths: git(["add"] + paths)
        else: git(["add", "-A"])
    args = ["commit"]
    if allow_empty: args.append("--allow-empty")
    args += ["-m", message]
    return git(args, capture=True, check=False)

def patch_empty(commit):
    p = git(["diff-tree", "--no-commit-id", "--name-only", "-r", commit], capture=True, check=False)
    return p.stdout.strip() == ""

def status_prefix(st, p):
    if p["status"] == "hidden": return "!"
    if p["status"] == "unapplied": return "-"
    if top_patch(st) and p["name"] == top_patch(st)["name"]: return ">"
    return "+"

def parse_common(argv):
    i=0; color=None
    while i < len(argv):
        a=argv[i]
        if a == "-C" and i+1 < len(argv): os.chdir(argv[i+1]); del argv[i:i+2]; continue
        if a.startswith("--color"):
            if a == "--color" and i+1 < len(argv): del argv[i:i+2]
            else: del argv[i]
            continue
        i+=1
    return argv

def print_version():
    print(VERSION)
    print("Copyright (C) 2005-2025 StGit authors")
    print("This is free software: you are free to change and redistribute it.")
    print("There is NO WARRANTY, to the extent permitted by law.")
    print("SPDX-License-Identifier: GPL-2.0-only")
    gv = git(["--version"], capture=True, check=False).stdout.strip()
    if gv: print(gv)

HELP = """Maintain a stack of patches on top of a Git branch.

Usage: stg [OPTIONS] <command> [...]
       stg [OPTIONS] <-h|--help>
       stg --version

Patch inspection commands:
  diff   Show a diff
  files  Show files modified by a patch
  id     Print git hash of a StGit revision
  name   Print patch name of a StGit revision
  show   Show patch commits

Patch manipulation commands:
  new      Create a new patch at top of the stack
  refresh  Incorporate worktree changes into current patch
  rename   Rename a patch

Stack inspection commands:
  next     Print the name of the next patch
  prev     Print the name of the previous patch
  series   Display the patch series
  top      Print the name of the top patch

Stack manipulation commands:
  branch    Branch operations
  clean     Delete empty patches from the series
  commit    Finalize patches to the stack base
  delete    Delete patches
  hide      Hide patches in the series
  init      Initialize a StGit stack on a branch
  pop       Pop patches
  push      Push patches
  uncommit  Convert regular Git commits into StGit patches
  unhide    Unhide hidden patches

Administration commands:
  version  Print version information and exit

Aliases:
  add mv resolved rm status
"""

SUBHELP = {
"init":"Initialize a StGit stack on a branch.\n\nUsage: stg init [OPTIONS]",
"new":"Create a new, empty patch on the current stack.\n\nUsage: stg new [OPTIONS] [patchname] [-- <path>...]",
"series":"Display the patch series.\n\nUsage: stg series [OPTIONS] [patch]...",
"refresh":"Include the latest work tree and index changes in the current patch.\n\nUsage: stg refresh [OPTIONS] [path]...",
"push":"Push one or more unapplied patches from the series onto the stack.\n\nUsage: stg push [OPTIONS] [patch]...",
"pop":"Pop (unapply) one or more applied patches.\n\nUsage: stg pop [OPTIONS] [patch]...",
"top":"Print the name of the top patch.\n\nUsage: stg top [OPTIONS]",
"files":"Show files modified by a patch\n\nUsage: stg files [OPTIONS] [revision]",
"diff":"Show a diff\n\nUsage: stg diff [OPTIONS] [path]...",
}

def cmd_init(args):
    br=None; i=0
    while i<len(args):
        if args[i] in ("-b","--branch") and i+1<len(args): br=args[i+1]; i+=2
        elif args[i] in ("-h","--help"): print(SUBHELP["init"]); return
        else: i+=1
    load(br, create=True)

def split_paths(args):
    if "--" in args:
        j=args.index("--"); return args[:j], args[j+1:]
    return args, []

def slug(s):
    s = re.sub(r"[^A-Za-z0-9._-]+", "-", s.strip().lower()).strip("-.")
    return s or "patch"

def cmd_new(args):
    opts, paths = split_paths(args)
    msg=None; name=None; refresh=False; filemsg=None; i=0; leftovers=[]
    while i<len(opts):
        a=opts[i]
        if a in ("-h","--help"): print(SUBHELP["new"]); return
        if a in ("-m","--message") and i+1<len(opts): msg=opts[i+1]; i+=2; continue
        if a in ("-f","--file") and i+1<len(opts):
            fp=opts[i+1]; filemsg=sys.stdin.read() if fp=="-" else Path(fp).read_text(); msg=filemsg; i+=2; continue
        if a in ("-n","--name") and i+1<len(opts): name=opts[i+1]; i+=2; continue
        if a in ("-r","--refresh","-i","--index","-F","--force"): refresh=True; i+=1; continue
        if a in ("-e","--edit","-d","--diff","--no-verify","--committer-date-is-author-date","--submodules","--no-submodules"): i+=1; continue
        if a in ("--author","--authname","--authemail","--authdate","--save-template") and i+1<len(opts): i+=2; continue
        if a.startswith("-") and a not in ("-",): i+=1; continue
        leftovers.append(a); i+=1
    if paths: refresh=True
    if not name and leftovers: name=leftovers[0].lstrip("\\")
    if not msg:
        msg = name or "patch"
    if not name: name=slug(msg.splitlines()[0])
    st=load(create=True)
    if find_patch(st,name): err(f"patch `{name}` already exists")
    p=commit_tree(msg, refresh=refresh, paths=paths, allow_empty=True)
    if p.returncode != 0:
        if p.stdout: sys.stdout.write(p.stdout)
        if p.stderr: sys.stderr.write(p.stderr)
        raise SystemExit(p.returncode)
    sha=out_git(["rev-parse","HEAD"]).strip()
    st["patches"].append({"name":name,"commit":sha,"message":msg,"status":"applied"})
    save(st)
    print(f"> {name} (new)")

def cmd_series(args):
    st=load(); select=None; no_prefix=False; count=False; desc=False; cid=None; empty=False; reverse=False; showbranch=False
    i=0
    while i<len(args):
        a=args[i]
        if a in ("-h","--help"): print(SUBHELP["series"]); return
        if a in ("-A","--applied"): select="applied"; i+=1; continue
        if a in ("-U","--unapplied"): select="unapplied"; i+=1; continue
        if a in ("-H","--hidden"): select="hidden"; i+=1; continue
        if a in ("-a","--all"): select="all"; i+=1; continue
        if a in ("-P","--no-prefix"): no_prefix=True; i+=1; continue
        if a in ("-c","--count"): count=True; i+=1; continue
        if a in ("-d","--description"): desc=True; i+=1; continue
        if a.startswith("--commit-id") or a == "-i":
            if "=" in a: cid=a.split("=",1)[1]
            elif i+1<len(args) and not args[i+1].startswith("-"): cid=args[i+1]; i+=1
            else: cid="full"
            i+=1; continue
        if a in ("-e","--empty"): empty=True; i+=1; continue
        if a in ("-r","--reverse"): reverse=True; i+=1; continue
        if a == "--showbranch": showbranch=True; i+=1; continue
        if a in ("-b","--branch","-m","--missing","-s","--short") and i+1<len(args): i+=2; continue
        i+=1
    ps=list(st["patches"])
    if select in ("applied","unapplied","hidden"): ps=[p for p in ps if p["status"]==select]
    elif select is None: ps=[p for p in ps if p["status"]!="hidden"]
    if reverse: ps=list(reversed(ps))
    if count: print(len(ps)); return
    for p in ps:
        parts=[]
        if empty: parts.append("0" if patch_empty(p["commit"]) else " ")
        if not no_prefix: parts.append(status_prefix(st,p))
        if cid:
            sha=p["commit"]
            if cid != "full":
                try: sha=sha[:int(cid)]
                except: pass
            parts.append(sha)
        nm = (branch()+":" if showbranch else "") + p["name"]
        parts.append(nm)
        line=" ".join(parts)
        if desc:
            subj=out_git(["log","-1","--format=%s",p["commit"]]).strip()
            line += " # " + subj
        print(line)

def cmd_top(args):
    if "-h" in args or "--help" in args: print(SUBHELP["top"]); return
    p=top_patch(load())
    if not p: err("no patches applied")
    print(p["name"])

def cmd_next(args):
    st=load(); ups=unapplied(st)
    if not ups: err("no next patch")
    print(ups[0]["name"])

def cmd_prev(args):
    st=load(); a=applied(st)
    if len(a)<2: err("no previous patch")
    print(a[-2]["name"])

def cmd_pop(args):
    st=load(); n=1; allflag=False; names=[]; spill=False; i=0
    while i<len(args):
        a=args[i]
        if a in ("-h","--help"): print(SUBHELP["pop"]); return
        if a in ("-a","--all"): allflag=True; i+=1; continue
        if a in ("-n","--number") and i+1<len(args): n=int(args[i+1]); i+=2; continue
        if a in ("-s","--spill","-k","--keep"): spill = spill or a in ("-s","--spill"); i+=1; continue
        if not a.startswith("-"): names.append(a)
        i+=1
    a=applied(st)
    if not a: err("no patches applied")
    if allflag: todo=list(reversed(a))
    elif names: todo=[find_patch(st,x) for x in names if find_patch(st,x)]
    else: todo=list(reversed(a[-n:]))
    for p in todo:
        if p["status"]!="applied": continue
        if spill:
            git(["reset", "--mixed", "HEAD^"], check=True)
        else:
            git(["reset", "--hard", "HEAD^"], check=True, capture=True)
        p["status"]="unapplied"
    save(st)

def cmd_push(args):
    st=load(); n=1; allflag=False; names=[]; i=0
    while i<len(args):
        a=args[i]
        if a in ("-h","--help"): print(SUBHELP["push"]); return
        if a in ("-a","--all"): allflag=True; i+=1; continue
        if a in ("-n","--number") and i+1<len(args): n=int(args[i+1]); i+=2; continue
        if a in ("-k","--keep","-m","--merged","--reverse","--noapply","--set-tree","--committer-date-is-author-date") or a.startswith("--conflicts"): i+=1; continue
        if not a.startswith("-"): names.append(a)
        i+=1
    ups=unapplied(st)
    if not ups: err("no patches to push")
    if allflag: todo=ups
    elif names: todo=[find_patch(st,x) for x in names if find_patch(st,x)]
    else: todo=ups[:n]
    for p in todo:
        if p["status"]!="unapplied": continue
        cp=git(["cherry-pick", "--allow-empty", p["commit"]], capture=True, check=False)
        if cp.returncode != 0:
            if cp.stdout: sys.stdout.write(cp.stdout)
            if cp.stderr: sys.stderr.write(cp.stderr)
            raise SystemExit(cp.returncode)
        p["commit"] = out_git(["rev-parse","HEAD"]).strip()
        p["status"]="applied"
    save(st)

def rev_for(st, rev):
    if not rev:
        p=top_patch(st); return p["commit"] if p else "HEAD"
    p=find_patch(st, rev)
    return p["commit"] if p else rev

def cmd_id(args):
    st=load(); rev=None; i=0
    while i<len(args):
        if args[i] in ("-h","--help"): print("Print the hash (object id) of a StGit revision.\n\nUsage: stg id [OPTIONS] [revision]"); return
        if args[i] in ("-b","--branch") and i+1<len(args): i+=2; continue
        if not args[i].startswith("-"): rev=args[i]
        i+=1
    print(out_git(["rev-parse", rev_for(st, rev)]).strip())

def cmd_name(args):
    st=load(); rev=None; showb=False
    for a in args:
        if a in ("-h","--help"): print("Print patch name of a StGit revision\n\nUsage: stg name [OPTIONS] [revision]"); return
        elif a=="--showbranch": showb=True
        elif not a.startswith("-"): rev=a
    p=find_patch(st, rev) if rev else top_patch(st)
    if not p: err("no patches applied")
    print((branch()+":" if showb else "") + p["name"])

def cmd_files(args):
    if "-h" in args or "--help" in args: print(SUBHELP["files"]); return
    st=load(); stat=False; rev=None
    for a in args:
        if a in ("-s","--stat"): stat=True
        elif a.startswith("-"): pass
        else: rev=a
    r=rev_for(st, rev)
    cmd=["show", "--stat", "--oneline", r] if stat else ["diff-tree", "--no-commit-id", "--name-status", "-r", r]
    sys.stdout.write(out_git(cmd))

def cmd_diff(args):
    if "-h" in args or "--help" in args: print(SUBHELP["diff"]); return
    st=load(); stat=False; rng=None; paths=[]; i=0
    while i<len(args):
        a=args[i]
        if a in ("-s","--stat"): stat=True; i+=1; continue
        if a in ("-r","--range") and i+1<len(args): rng=args[i+1]; i+=2; continue
        if a in ("-O","--diff-opt") and i+1<len(args): i+=2; continue
        if not a.startswith("-"): paths.append(a)
        i+=1
    cmd=["diff"]
    if stat: cmd.append("--stat")
    if rng: cmd.append(rng.replace("..", ".."))
    else:
        p=top_patch(st)
        if p: cmd += [p["commit"]+"^", p["commit"]]
    if paths: cmd += ["--"] + paths
    sys.stdout.write(out_git(cmd))

def cmd_show(args):
    st=load(); stat=False; revs=[]; paths=[]; after=False; i=0
    while i<len(args):
        a=args[i]
        if a in ("-h","--help"): print("Show patch commits\n\nUsage: stg show [OPTIONS] [patch-or-rev]..."); return
        if a=="--": after=True; i+=1; continue
        if after: paths.append(a); i+=1; continue
        if a in ("-s","--stat"): stat=True; i+=1; continue
        if a in ("-p","--patch") and i+1<len(args): revs.append(args[i+1]); i+=2; continue
        if a in ("-A","--applied"): revs += [p["name"] for p in applied(st)]; i+=1; continue
        if a in ("-U","--unapplied"): revs += [p["name"] for p in unapplied(st)]; i+=1; continue
        if a in ("-H","--hidden"): revs += [p["name"] for p in hidden(st)]; i+=1; continue
        if a in ("-b","--branch","-O","--diff-opt") and i+1<len(args): i+=2; continue
        if not a.startswith("-"): revs.append(a)
        i+=1
    if not revs: revs=[None]
    cmd=["show"]
    if stat: cmd.append("--stat")
    cmd += [rev_for(st,r) for r in revs]
    if paths: cmd += ["--"] + paths
    sys.stdout.write(out_git(cmd))

def cmd_refresh(args):
    if "-h" in args or "--help" in args: print(SUBHELP["refresh"]); return
    st=load(); p=top_patch(st)
    if not p: err("no patches applied")
    msg=None; paths=[]; i=0
    while i<len(args):
        a=args[i]
        if a in ("-m","--message") and i+1<len(args): msg=args[i+1]; i+=2; continue
        if a in ("-f","--file") and i+1<len(args):
            fp=args[i+1]; msg=sys.stdin.read() if fp=="-" else Path(fp).read_text(); i+=2; continue
        if a in ("-p","--patch","-a","--annotate","--author","--authname","--authemail","--authdate") and i+1<len(args): i+=2; continue
        if a.startswith("-"): i+=1; continue
        paths.append(a); i+=1
    if msg is None: msg=out_git(["log","-1","--format=%B",p["commit"]]).rstrip("\n")
    if paths: git(["add"]+paths)
    else: git(["add","-A"])
    c=git(["commit","--amend","--allow-empty","-m",msg], capture=True, check=False)
    if c.returncode!=0:
        if c.stdout: sys.stdout.write(c.stdout)
        if c.stderr: sys.stderr.write(c.stderr)
        raise SystemExit(c.returncode)
    p["commit"]=out_git(["rev-parse","HEAD"]).strip(); p["message"]=msg; save(st)

def cmd_rename(args):
    st=load(); vals=[a for a in args if not a.startswith("-")]
    if len(vals)==1: old=top_patch(st)["name"] if top_patch(st) else None; new=vals[0]
    elif len(vals)>=2: old,new=vals[0],vals[1]
    else: err("patch name required")
    p=find_patch(st,old)
    if not p: err(f"unknown patch `{old}`")
    p["name"]=new; save(st)

def cmd_delete(args):
    st=load(); names=[]; top=False; allflag=False; spill=False
    for a in args:
        if a in ("-h","--help"): print("Delete patches\n\nUsage: stg delete [OPTIONS] [<patch>...]"); return
        if a in ("-t","--top"): top=True
        elif a in ("-a","--all"): allflag=True
        elif a=="--spill": spill=True
        elif not a.startswith("-"): names.append(a)
    if allflag: targets=list(st["patches"])
    elif top: targets=[top_patch(st)] if top_patch(st) else []
    elif names: targets=[find_patch(st,n) for n in names if find_patch(st,n)]
    else: targets=[top_patch(st)] if top_patch(st) else []
    for p in list(targets):
        if not p: continue
        if p["status"]=="applied":
            # only handle top-applied deletion accurately
            if top_patch(st) and top_patch(st)["name"]==p["name"]:
                git(["reset", "--mixed" if spill else "--hard", "HEAD^"], capture=not spill)
            else:
                err("can only delete the top applied patch in this implementation")
        st["patches"]=[x for x in st["patches"] if x["name"]!=p["name"]]
    save(st)

def cmd_hide_unhide(args, hideit):
    st=load(); names=[a for a in args if not a.startswith("-")]
    for n in names:
        p=find_patch(st,n)
        if not p: err(f"unknown patch `{n}`")
        p["status"]="hidden" if hideit else "unapplied"
    save(st)

def cmd_clean(args):
    st=load(); rem=[]
    for p in st["patches"]:
        if patch_empty(p["commit"]): rem.append(p)
    for p in rem:
        if p["status"]=="applied" and top_patch(st) and top_patch(st)["name"]==p["name"]:
            git(["reset","--hard","HEAD^"], capture=True)
        st["patches"]=[x for x in st["patches"] if x["name"]!=p["name"]]
    save(st)

def cmd_commit(args):
    st=load(); n=None; allflag=False
    i=0
    while i<len(args):
        if args[i] in ("-h","--help"): print("Finalize patches to the stack base\n\nUsage: stg commit [OPTIONS] [patch]..."); return
        if args[i] in ("-a","--all"): allflag=True
        if args[i] in ("-n","--number") and i+1<len(args): n=int(args[i+1]); i+=1
        i+=1
    a=applied(st); cnt=len(a) if allflag or n is None else n
    done=a[:cnt]
    if done:
        st["base"]=done[-1]["commit"]
        st["patches"]=[p for p in st["patches"] if p not in done]
        save(st)

def cmd_uncommit(args):
    st=load(create=True); n=None; names=[]; to=None; i=0
    while i<len(args):
        a=args[i]
        if a in ("-h","--help"): print("Convert regular Git commits into StGit patches\n\nUsage: stg uncommit <patchname-1> ..."); return
        if a in ("-n","--number") and i+1<len(args): n=int(args[i+1]); i+=2; continue
        if a in ("-t","--to") and i+1<len(args): to=args[i+1]; i+=2; continue
        if not a.startswith("-"): names.append(a)
        i+=1
    if to:
        revs=out_git(["rev-list","--reverse", f"{to}..HEAD"]).splitlines()
    else:
        if n is None: n=len(names) if names else 1
        revs=list(reversed(out_git(["rev-list", f"--max-count={n}", "HEAD"]).splitlines()))
    if not revs: return
    base=out_git(["rev-parse", revs[0]+"^"]).strip(); st["base"]=base
    for idx,sha in enumerate(revs):
        nm=names[idx] if idx < len(names) else slug(out_git(["log","-1","--format=%s",sha]).strip())
        st["patches"].append({"name":nm,"commit":sha,"message":out_git(["log","-1","--format=%B",sha]),"status":"applied"})
    save(st)

def cmd_branch(args):
    if not args: print(branch()); return
    if args[0] in ("-l","--list"):
        sys.stdout.write(out_git(["branch"])); return
    if args[0] in ("-c","--create") and len(args)>=2:
        nm=args[1]; start=args[2] if len(args)>2 else "HEAD"; git(["checkout","-b",nm,start]); load(create=True); return
    if args[0] in ("-r","--rename"):
        git(["branch","-m"]+args[1:]); return
    if args[0] in ("-D","--delete"):
        git(["branch","-D"]+ [a for a in args[1:] if a!="--force"]); return
    if args[0] == "--cleanup":
        p=state_path(args[-1] if len(args)>1 and not args[-1].startswith("-") else None)
        if p.exists(): p.unlink()
        return
    if args[0] in ("-h","--help"): print("Create, clone, switch, rename, or delete StGit-enabled branches.\n\nUsage: stg branch [branch]"); return
    git(["checkout"]+args)

def cmd_patches(args):
    st=load(); paths=[a for a in args if not a.startswith("-")]
    for p in applied(st):
        names=out_git(["diff-tree","--no-commit-id","--name-only","-r",p["commit"]]).splitlines()
        if not paths or any(n in paths or any(n.startswith(x.rstrip('/')+'/') for x in paths) for n in names): print(p["name"])

def cmd_export(args):
    st=load(); stdout="-s" in args or "--stdout" in args; d="patches"; numbered=False; ext=""; names=[]; i=0
    while i<len(args):
        a=args[i]
        if a in ("-h","--help"): print("Export patches to a directory\n\nUsage: stg export [OPTIONS] [patch]..."); return
        if a in ("-d","--dir") and i+1<len(args): d=args[i+1]; i+=2; continue
        if a in ("-n","--numbered"): numbered=True
        elif a in ("-p","--patch"): ext=".patch"
        elif a in ("-e","--extension") and i+1<len(args): ext="."+args[i+1].lstrip('.'); i+=1
        elif not a.startswith("-"): names.append(a)
        i+=1
    ps=[find_patch(st,n) for n in names] if names else st["patches"]
    if stdout:
        for p in ps: sys.stdout.write(out_git(["format-patch","-1","--stdout",p["commit"]]))
    else:
        Path(d).mkdir(exist_ok=True)
        for idx,p in enumerate(ps,1):
            fn=(f"{idx:04d}-" if numbered else "") + p["name"] + ext
            Path(d,fn).write_text(out_git(["format-patch","-1","--stdout",p["commit"]]))


def cmd_import(args):
    st=load(create=True); name=None; source=None; strip=1; msg=None; i=0
    while i<len(args):
        a=args[i]
        if a in ("-h","--help"):
            print("Import patches to stack\n\nUsage: stg import [OPTIONS] <diff-path>"); return
        if a in ("-n","--name") and i+1<len(args): name=args[i+1]; i+=2; continue
        if a in ("-p","--strip") and i+1<len(args): strip=int(args[i+1]); i+=2; continue
        if a in ("-m","--mail","-M","--mbox","-S","--series","-u","--url","-3","--3way","-i","--ignore","--replace","--reject","--keep-cr","--message-id","-t","--stripname"):
            i+=1; continue
        if a in ("--directory","-b","--base","--author","--authname","--authemail","--authdate") and i+1<len(args): i+=2; continue
        if not a.startswith("-"): source=a
        i+=1
    if not source: err("patch file required")
    text = sys.stdin.read() if source == "-" else Path(source).read_text(errors="replace")
    subj=None
    for line in text.splitlines():
        if line.lower().startswith("subject:"):
            subj=line.split(":",1)[1].strip(); subj=re.sub(r"^\[[^\]]*\]\s*", "", subj); break
    if not name: name=slug(subj or Path(source).stem)
    ap=git(["apply", f"-p{strip}"], input=text, capture=True, check=False)
    if ap.returncode != 0:
        ap=git(["am", "--keep-cr"], input=text, capture=True, check=False)
        if ap.returncode == 0:
            sha=out_git(["rev-parse","HEAD"]).strip()
            st["patches"].append({"name":name,"commit":sha,"message":subj or name,"status":"applied"}); save(st); print(f"> {name} (new)"); return
        if ap.stdout: sys.stdout.write(ap.stdout)
        if ap.stderr: sys.stderr.write(ap.stderr)
        raise SystemExit(ap.returncode)
    git(["add","-A"])
    c=git(["commit","--allow-empty","-m",subj or name], capture=True, check=False)
    if c.returncode != 0:
        if c.stdout: sys.stdout.write(c.stdout)
        if c.stderr: sys.stderr.write(c.stderr)
        raise SystemExit(c.returncode)
    sha=out_git(["rev-parse","HEAD"]).strip()
    st["patches"].append({"name":name,"commit":sha,"message":subj or name,"status":"applied"}); save(st); print(f"> {name} (new)")

def cmd_fold(args):
    st=load(); p=top_patch(st)
    if not p: err("no patches applied")
    sources=[a for a in args if not a.startswith("-")]
    if not sources: err("diff file required")
    for src in sources:
        text=sys.stdin.read() if src=="-" else Path(src).read_text(errors="replace")
        ap=git(["apply"], input=text, capture=True, check=False)
        if ap.returncode != 0:
            if ap.stdout: sys.stdout.write(ap.stdout)
            if ap.stderr: sys.stderr.write(ap.stderr)
            raise SystemExit(ap.returncode)
    return cmd_refresh([])

def cmd_spill(args):
    st=load(); p=top_patch(st)
    if not p: err("no patches applied")
    git(["reset","--mixed","HEAD^"], check=True)
    p["status"]="unapplied"; save(st)

def cmd_goto(args):
    vals=[a for a in args if not a.startswith("-")]
    if not vals: err("patch required")
    target=vals[-1]; st=load(); names=[p["name"] for p in st["patches"]]
    if target not in names: err(f"unknown patch `{target}`")
    idx=names.index(target)
    # pop until target is top or below top, then push through target
    while top_patch(st) and names.index(top_patch(st)["name"]) > idx:
        cmd_pop([]); st=load()
    while (not top_patch(st)) or names.index(top_patch(st)["name"]) < idx:
        cmd_push([]); st=load()

def alias_git(cmd,args):
    mp={"add":"add","mv":"mv","rm":"rm","resolved":"add"}
    if cmd=="status": raise SystemExit(git(["status","-s"]+args, check=False).returncode)
    raise SystemExit(git([mp[cmd]]+args, check=False).returncode)

def main(argv):
    argv=parse_common(list(argv))
    if not argv or argv[0] in ("-h","--help"): print(HELP); return
    if argv[0] == "--version": print_version(); return
    cmd=argv[0]; args=argv[1:]
    if cmd == "help":
        if args: 
            c=args[0]; print(SUBHELP.get(c, HELP if c=="stg" else f"Usage: stg {c} [OPTIONS]"))
        else: print(HELP)
        return
    if cmd == "version": print_version(); return
    if cmd in ("add","mv","rm","resolved","status"): alias_git(cmd,args); return
    funcs={"init":cmd_init,"new":cmd_new,"series":cmd_series,"top":cmd_top,"next":cmd_next,"prev":cmd_prev,
           "pop":cmd_pop,"push":cmd_push,"id":cmd_id,"name":cmd_name,"files":cmd_files,"diff":cmd_diff,
           "show":cmd_show,"refresh":cmd_refresh,"rename":cmd_rename,"delete":cmd_delete,"clean":cmd_clean,
           "commit":cmd_commit,"uncommit":cmd_uncommit,"branch":cmd_branch,"patches":cmd_patches,"export":cmd_export,"import":cmd_import,"fold":cmd_fold,"spill":cmd_spill,"goto":cmd_goto}
    if cmd=="hide": return cmd_hide_unhide(args, True)
    if cmd=="unhide": return cmd_hide_unhide(args, False)
    if cmd in funcs: return funcs[cmd](args)
    err(f"unrecognized subcommand `{cmd}`")

if __name__ == "__main__":
    try: main(sys.argv[1:])
    except BrokenPipeError: pass
