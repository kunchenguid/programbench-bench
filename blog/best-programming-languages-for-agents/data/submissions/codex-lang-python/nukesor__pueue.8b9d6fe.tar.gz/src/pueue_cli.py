#!/usr/bin/env python3
import os
import sys

VERSION = "pueue 4.0.4"
COMMANDS = [
    "add", "remove", "switch", "stash", "enqueue", "start", "restart", "pause", "kill",
    "send", "edit", "env", "group", "status", "log", "follow", "wait", "clean", "reset",
    "shutdown", "parallel", "completions",
]

MAIN_HELP = """Interact with the Pueue daemon

Use the `--help` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...         Verbose mode (-v, -vv, -vvv)
      --color <COLOR>      Colorize the output; auto enables color output when connected to a tty
                           [default: auto] [possible values: auto, never, always]
  -c, --config <CONFIG>    If provided, Pueue only uses this config file
  -p, --profile <PROFILE>  The name of the profile that should be loaded from your config file
  -h, --help               Print help (see more with '--help')
  -V, --version            Print version"""

MAIN_HELP_LONG = """Interact with the Pueue daemon

Use the `--help` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...
          Verbose mode (-v, -vv, -vvv)

      --color <COLOR>
          Colorize the output; auto enables color output when connected to a tty
          
          [default: auto]
          [possible values: auto, never, always]

  -c, --config <CONFIG>
          If provided, Pueue only uses this config file.
          
          This path can also be set via the "PUEUE_CONFIG_PATH" environment variable. The
          commandline option overwrites the environment variable!

  -p, --profile <PROFILE>
          The name of the profile that should be loaded from your config file

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version"""

HELPS = {
"add": """Enqueue a task for execution.

There're many different options when scheduling a task. Check the individual option help texts for
more information. Furthermore, please remember that scheduled commands are executed via your system
shell. This means that the command needs proper shell escaping. The safest way to preserve shell
escaping is to surround your command with quotes, for example:

pueue add 'ls $HOME && echo \\"Some string\\"'

Usage: executable add [OPTIONS] <COMMAND>...

Arguments:
  <COMMAND>...
          The command to be added

Options:
  -w, --working-directory <working-directory>
          Specify current working directory

  -e, --escape
          Escape any special shell characters (" ", "&", "!", etc.).
          Beware: This implicitly disables nearly all shell specific syntax ("&&", "&>").

  -i, --immediate
          Immediately start the task

      --follow
          Immediately follow a task, if it's started with --immediate

  -s, --stashed
          Create the task in Stashed state.
          
          Useful to avoid immediate execution if the queue is empty.

  -d, --delay <delay>
          Prevents the task from being enqueued until 'delay' elapses. See "enqueue" for accepted
          formats

  -g, --group <GROUP>
          Assign the task to a group.
          
          Groups kind of act as separate queues. All groups run in parallel and you can specify the
          amount of parallel tasks for each group. If no group is specified, the default group will
          be used.
          
          Create groups via the `pueue group` subcommand

  -a, --after <after>...
          Start the task once all specified tasks have successfully finished.
          
          As soon as one of the dependencies fails, this task will fail as well.

  -o, --priority <PRIORITY>
          Start this task with a higher priority.
          
          The higher the number, the faster it will be processed.

  -l, --label <LABEL>
          Add some information for yourself.
          
          This string will be shown in the "status" table. There's no additional logic connected to
          it.

  -p, --print-task-id
          Only return the task id instead of a text.
          
          This is useful when working with dependencies in scripts.

  -h, --help
          Print help (see a summary with '-h')""",
"remove": """Remove tasks from the list. Running or paused tasks need to be killed first

Usage: executable remove <TASK_IDS>...

Arguments:
  <TASK_IDS>...  The task ids to be removed

Options:
  -h, --help  Print help""",
"switch": """Switches the queue position of two commands.

Only works on queued and stashed commands.

Usage: executable switch <TASK_ID_1> <TASK_ID_2>

Arguments:
  <TASK_ID_1>
          The first task id

  <TASK_ID_2>
          The second task id

Options:
  -h, --help
          Print help (see a summary with '-h')""",
"stash": """Stash a task. Stashed tasks won't be automatically started.

The enqueue an item, use the `pueue enqueue` subcommand. Stashed entries can also be explicitely
started via `pueue start $task_id`.

Usage: executable stash [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Stash these specific tasks

Options:
  -g, --group <GROUP>
          Stash all queued tasks in a group

  -a, --all
          Stash all queued tasks across all groups

  -d, --delay <delay>
          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below

  -h, --help
          Print help (see a summary with '-h')""",
"enqueue": """Enqueue stashed tasks. They'll be handled normally afterwards.

Enqueues all stashed task in the default group if no arguments are given.

Usage: executable enqueue [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Enqueue these specific tasks

Options:
  -g, --group <GROUP>
          Enqueue all stashed tasks in a group

  -a, --all
          Enqueue all stashed tasks across all groups

  -d, --delay <delay>
          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below

  -h, --help
          Print help (see a summary with '-h')

DELAY FORMAT:

    The --delay argument must be either a number of seconds or a "date expression" similar to GNU
    "date -d" with some extensions. It does not attempt to parse all natural language, but is
    incredibly flexible. Here are some supported examples.

    2020-04-01T18:30:00   // RFC 3339 timestamp
    2020-4-1 18:2:30      // Optional leading zeros
    2020-4-1 5:30pm       // Informal am/pm time
    2020-4-1 5pm          // Optional minutes and seconds
    April 1 2020 18:30:00 // English months
    1 Apr 8:30pm          // Implies current year
    4/1                   // American form date
    wednesday 10:30pm     // The closest wednesday in the future at 22:30
    wednesday             // The closest wednesday in the future
    4 months              // 4 months from today at 00:00:00
    1 week                // 1 week at the current time
    1days                 // 1 day from today at the current time
    1d 03:00              // The closest 3:00 after 1 day (24 hours)
    3h                    // 3 hours from now
    3600s                 // 3600 seconds from now""",
"start": """Resume operation of specific tasks or groups of tasks.

Without any parameters this resumes the default group and all its tasks. Can also be used
force-start specific tasks, which **ignores** any group parallelism limits or dependencies a task my
have!

Usage: executable start [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Start these specific tasks. Paused tasks will resumed. Queued/Stashed tasks will be
          force-started

Options:
  -g, --group <GROUP>
          Resume a specific group and all paused tasks in it.
          
          The group will be set to running and its paused tasks will be resumed.

  -a, --all
          Resume all groups!
          
          All groups will be set to running and paused tasks will be resumed.

  -h, --help
          Print help (see a summary with '-h')""",
"restart": """Restart failed or successful task(s).

By default, identical tasks will be created and enqueued, but it's possible to restart in-place. You
can also edit a few properties, such as the path and the command, before restarting.

Usage: executable restart [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Restart these specific tasks

Options:
  -a, --all-failed
          Restart all failed tasks across all groups.
          
          This is nice for usage in combination with `-i/--in-place` (or the respective config
          option).

  -g, --failed-in-group <FAILED_IN_GROUP>
          Like `--all-failed`, but only restart tasks failed tasks of a specific group

  -k, --immediate
          Immediately start the tasks, no matter how many open slots there are. This will ignore any
          dependencies tasks may have

  -s, --stashed
          Set the restarted task to a "Stashed" state. Useful to avoid immediate execution

  -i, --in-place
          Restart the task by reusing the already existing tasks. This will overwrite any previous
          logs of the restarted tasks.
          
          This can also be enabled by default via the `restart_in_place` config option.

      --not-in-place
          Restart the task by creating a new identical tasks. Only necessary if you have the
          `restart_in_place` configuration set to true

  -e, --edit
          Edit the task before restarting

  -h, --help
          Print help (see a summary with '-h')""",
"pause": """Either pause running tasks or specific groups of tasks.

By default, pauses the default group and all its tasks. A paused queue (group) won't start any new
tasks.

Usage: executable pause [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Pause these specific tasks

Options:
  -g, --group <GROUP>
          Pause a specific group

  -a, --all
          Pause all groups!

  -w, --wait
          Pause the specified groups, but let already running tasks finish by themselves

  -h, --help
          Print help (see a summary with '-h')""",
"kill": """Kill specific running tasks or whole task groups.

Kills all tasks of the default group when no ids or a specific group are provided.

Usage: executable kill [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Kill these specific tasks

Options:
  -g, --group <GROUP>
          Kill all running tasks in a group. This also pauses the group

  -a, --all
          Kill all running tasks across ALL groups. This also pauses all groups

  -s, --signal <SIGNAL>
          Send a UNIX signal instead of simply killing the process.
          
          DISCLAIMER: This bypasses Pueue's process handling logic! You might enter weird invalid
          states, use at your own descretion.
          
          This argument also excepts the integer representation as well as the signal short name.
          E.g. `sigint`, `int`, or `2` are the same.

  -h, --help
          Print help (see a summary with '-h')""",
"send": """Send something to a task. Useful for sending confirmations such as 'y\\n'

Usage: executable send <TASK_ID> <INPUT>

Arguments:
  <TASK_ID>  The id of the task
  <INPUT>    The input that should be sent to the process

Options:
  -h, --help  Print help""",
"edit": """Adjust editable properties of a task.

Only stashed or queued tasks can be edited. A temporary folder folder/file will be opened by your
$EDITOR to edit the tasks.

Usage: executable edit [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          The ids of all tasks that should be edited

Options:
  -h, --help
          Print help (see a summary with '-h')""",
"env": """Use this to add or remove environment variables from tasks

Usage: executable env <COMMAND>

Commands:
  set    Set a variable for a specific task's environment
  unset  Remove a specific variable from a task's environment
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help""",
"env set": """Set a variable for a specific task's environment

Usage: executable env set <TASK_ID> <KEY> <VALUE>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set
  <VALUE>    The value of the environment variable to set

Options:
  -h, --help  Print help""",
"env unset": """Remove a specific variable from a task's environment

Usage: executable env unset <TASK_ID> <KEY>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set

Options:
  -h, --help  Print help""",
"group": """Use this to add or remove groups.

By default, this will simply display all known groups.

Usage: executable group [OPTIONS] [COMMAND]

Commands:
  add     Add a group by name
  remove  Remove a group by name. This will move all tasks in this group to the default group!
  help    Print this message or the help of the given subcommand(s)

Options:
  -j, --json
          Print the list of groups as json

  -h, --help
          Print help (see a summary with '-h')""",
"group add": """Add a group by name

Usage: executable group add [OPTIONS] <NAME>

Arguments:
  <NAME>
          

Options:
  -p, --parallel <PARALLEL>
          Set the amount of parallel tasks this group can have.
          
          Setting this to 0 means an unlimited amount of parallel tasks.

  -h, --help
          Print help (see a summary with '-h')""",
"group remove": """Remove a group by name. This will move all tasks in this group to the default group!

Usage: executable group remove <NAME>

Arguments:
  <NAME>  

Options:
  -h, --help  Print help""",
"status": """Display the current status of all tasks

Usage: executable status [OPTIONS] [QUERY]...

Arguments:
  [QUERY]...
          Users can specify a custom query to filter for specific values, order by a column
          or limit the amount of tasks listed.
          
          Syntax:
             [column_selection]? [filter]* [order_by]? [limit]?
          
          where:
            - column_selection := `columns=[column]([column],)*`
            - column := `id | status | command | label | path | enqueue_at | dependencies | start |
            end`
            - filter := `[filter_column] [filter_op] [filter_value]`
              (note: not all columns support all operators, see "Filter columns" below.)
            - filter_column := `status | command | label | start | end | enqueue_at`
            - filter_op := `= | != | < | > | %=`
              (`%=` means 'contains', as in the test value is a substring of the column value)
            - order_by := `order_by [column] [order_direction]`
            - order_direction := `asc | desc`
            - limit := `[limit_type]? [limit_count]`
            - limit_type := `first | last`
            - limit_count := a positive integer
          
          Filter columns:
            - `status` supports the operators `=`, `!=`
              against test values that are:
                - strings like `queued`, `stashed`, `paused`, `running`, `success`, `failed`
            - `command`, `label` support the operators `=`, `!=`, `%=`
              against test values that are:
                - strings like `some text`
            - `start`, `end`, `enqueue_at` contain a datetime
              which support the operators `=`, `!=`, `<`, `>`
              against test values that are:
                - date like `YYYY-MM-DD`
                - time like `HH:mm:ss` or `HH:mm`
                - datetime like `YYYY-MM-DDHH:mm:ss`
                  (note there is currently no separator between the date and the time)
          
          Examples:
            - `status=running`
            - `command%=echo`
            - `label=mytask`
            - `columns=id,status,command status=running start > 2023-05-2112:03:17 order_by command
            first 5`
          
          The formal syntax is defined here:
          https://github.com/Nukesor/pueue/blob/main/pueue/src/client/commands/state/query/syntax.pest
          
          More documentation is on the query syntax PR:
          https://github.com/Nukesor/pueue/issues/350#issue-1359083118

Options:
  -j, --json
          Print the current state as json to stdout. This does not include the output of tasks. Use
          `log -j` if you want everything

  -g, --group <GROUP>
          Only show tasks of a specific group

  -h, --help
          Print help (see a summary with '-h')""",
"log": """Display the log output of finished tasks.

Only the last few lines will be shown by default. If you want to follow the output of a task, please
use the \\"follow\\" subcommand.

Usage: executable log [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          View the task output of these specific tasks

Options:
  -g, --group <GROUP>
          View the outputs of this specific group's tasks

  -a, --all
          Show the logs of all groups' tasks

  -j, --json
          Print the resulting tasks and output as json.
          
          By default only the last lines will be returned unless --full is provided. Take care, as
          the json cannot be streamed! If your logs are really huge, using --full can use all of
          your machine's RAM.

  -l, --lines <LINES>
          Only print the last X lines of each task's output.
          
          This is done by default if you're looking at multiple tasks.

  -f, --full
          Show the whole output

  -h, --help
          Print help (see a summary with '-h')""",
"follow": """Follow the output of a currently running task. This command works like "tail -f"

Usage: executable follow [OPTIONS] [TASK_ID]

Arguments:
  [TASK_ID]
          The id of the task you want to watch.
          
          If no or multiple tasks are running, you have to specify the id. If only a single task is
          running, you can omit the id.

Options:
  -l, --lines <LINES>
          Only print the last X lines of the output before following

  -h, --help
          Print help (see a summary with '-h')""",
"wait": """Wait until tasks are finished.

By default, this will wait for all tasks in the default group to finish.

Note: This will also wait for all tasks that aren't somehow 'Done'. Includes: [Paused, Stashed,
Locked, Queued, ...]

Usage: executable wait [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          This allows you to wait for specific tasks to finish

Options:
  -g, --group <GROUP>
          Wait for all tasks in a specific group

  -a, --all
          Wait for all tasks across all groups and the default group

  -q, --quiet
          Don't show any log output while waiting

  -s, --status <STATUS>
          Wait for tasks to reach a specific task status

  -h, --help
          Print help (see a summary with '-h')""",
"clean": """Remove all finished tasks from the list

Usage: executable clean [OPTIONS]

Options:
  -s, --successful-only  Only clean tasks that finished successfully
  -g, --group <GROUP>    Only clean tasks of a specific group
  -h, --help             Print help""",
"reset": """Kill all tasks, clean up afterwards and reset EVERYTHING!

Usage: executable reset [OPTIONS]

Options:
  -g, --groups <GROUPS>  If groups are specified, only those specific groups will be reset
  -f, --force            Don't ask for any confirmation
  -h, --help             Print help""",
"shutdown": """Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager

Usage: executable shutdown

Options:
  -h, --help  Print help""",
"parallel": """Set the amount of allowed parallel tasks

By default, adjusts the amount of the default group.

No tasks will be stopped, if this is lowered. This limit is only considered when tasks are
scheduled.

Usage: executable parallel [OPTIONS] [PARALLEL_TASKS]

Arguments:
  [PARALLEL_TASKS]
          The amount of allowed parallel tasks.
          
          Setting this to 0 means an unlimited amount of parallel tasks.

Options:
  -g, --group <group>
          Set the amount for a specific group

  -h, --help
          Print help (see a summary with '-h')""",
"completions": """Generates shell completion files.

This can be ignored during normal operations.

Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]

Arguments:
  <SHELL>
          The target shell
          
          [possible values: bash, elvish, fish, power-shell, zsh, nushell]

  [OUTPUT_DIRECTORY]
          The output directory to which the file should be written

Options:
  -h, --help
          Print help (see a summary with '-h')""",
}

REQS = {
    "add": ("<COMMAND>...", 1), "remove": ("<TASK_IDS>...", 1), "switch": ("<TASK_ID_1> <TASK_ID_2>", 2),
    "send": ("<TASK_ID> <INPUT>", 2), "env set": ("<TASK_ID> <KEY> <VALUE>", 3),
    "env unset": ("<TASK_ID> <KEY>", 2), "group add": ("<NAME>", 1), "group remove": ("<NAME>", 1),
}

OPTVALS = {
    "add": {"-w":"--working-directory <working-directory>","--working-directory":"--working-directory <working-directory>","-d":"--delay <delay>","--delay":"--delay <delay>","-g":"--group <GROUP>","--group":"--group <GROUP>","-a":"--after <after>","--after":"--after <after>","-o":"--priority <PRIORITY>","--priority":"--priority <PRIORITY>","-l":"--label <LABEL>","--label":"--label <LABEL>"},
    "stash": {"-g":"--group <GROUP>","--group":"--group <GROUP>","-d":"--delay <delay>","--delay":"--delay <delay>"},
    "enqueue": {"-g":"--group <GROUP>","--group":"--group <GROUP>","-d":"--delay <delay>","--delay":"--delay <delay>"},
    "start": {"-g":"--group <GROUP>","--group":"--group <GROUP>"},
    "restart": {"-g":"--failed-in-group <FAILED_IN_GROUP>","--failed-in-group":"--failed-in-group <FAILED_IN_GROUP>"},
    "pause": {"-g":"--group <GROUP>","--group":"--group <GROUP>"},
    "kill": {"-g":"--group <GROUP>","--group":"--group <GROUP>","-s":"--signal <SIGNAL>","--signal":"--signal <SIGNAL>"},
    "group": {},
    "group add": {"-p":"--parallel <PARALLEL>","--parallel":"--parallel <PARALLEL>"},
    "status": {"-g":"--group <GROUP>","--group":"--group <GROUP>"},
    "log": {"-g":"--group <GROUP>","--group":"--group <GROUP>","-l":"--lines <LINES>","--lines":"--lines <LINES>"},
    "follow": {"-l":"--lines <LINES>","--lines":"--lines <LINES>"},
    "wait": {"-g":"--group <GROUP>","--group":"--group <GROUP>","-s":"--status <STATUS>","--status":"--status <STATUS>"},
    "clean": {"-g":"--group <GROUP>","--group":"--group <GROUP>"},
    "reset": {"-g":"--groups <GROUPS>","--groups":"--groups <GROUPS>"},
    "parallel": {"-g":"--group <group>","--group":"--group <group>"},
}
FLAGS = {
    "add": {"-e","--escape","-i","--immediate","--follow","-s","--stashed","-p","--print-task-id"},
    "stash": {"-a","--all"}, "enqueue": {"-a","--all"}, "start": {"-a","--all"},
    "restart": {"-a","--all-failed","-k","--immediate","-s","--stashed","-i","--in-place","--not-in-place","-e","--edit"},
    "pause": {"-a","--all","-w","--wait"}, "kill": {"-a","--all"},
    "group": {"-j","--json"}, "status": {"-j","--json"}, "log": {"-a","--all","-j","--json","-f","--full"},
    "wait": {"-a","--all","-q","--quiet"}, "clean": {"-s","--successful-only"}, "reset": {"-f","--force"},
}
VARIADIC = {"add","stash","enqueue","start","restart","pause","kill","edit","status","log","wait"}
MAXARGS = {"switch": 2, "send": 2, "env set": 3, "env unset": 2, "group add": 1, "group remove": 1, "clean": 0, "reset": 0, "shutdown": 0, "parallel": 1, "follow": 1}

def out(s):
    print(s)

def err(s):
    print(s, file=sys.stderr)

def clap_error(msg, usage):
    err(f"error: {msg}\n\nUsage: executable {usage}\n\nFor more information, try '--help'.")
    return 2

def config_error(path=None):
    if path:
        msg = (f'Error: \n   0: \x1b[91mFailed to read configuration.\x1b[0m\n'
               f'   1: \x1b[91mI/O error at path "{path}" while opening config file:\n'
               f'      No such file or directory (os error 2)\x1b[0m\n\n'
               f'Location:\n   \x1b[35mpueue/src/bin/pueue.rs\x1b[0m:\x1b[35m51\x1b[0m\n\n'
               f'Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.\n'
               f'Run with RUST_BACKTRACE=full to include source snippets.')
    else:
        msg = ('Error: \n   0: \x1b[91mCouldn\'t find a configuration file. Did you start the daemon yet?\x1b[0m\n\n'
               'Location:\n   \x1b[35mpueue/src/bin/pueue.rs\x1b[0m:\x1b[35m61\x1b[0m\n\n'
               'Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.\n'
               'Run with RUST_BACKTRACE=full to include source snippets.')
    err(msg)
    return 1

def strip_options(args, opt_values):
    vals = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            vals.extend(args[i+1:])
            break
        if a in ("-h", "--help"):
            i += 1
            continue
        if a in opt_values:
            i += 2
            continue
        if a.startswith("--") and "=" in a and a.split("=", 1)[0] in opt_values:
            i += 1
            continue
        if a.startswith("-") and a not in ("-",):
            i += 1
            continue
        vals.append(a)
        i += 1
    return vals

def check_required(key, args, usage):
    req = REQS.get(key)
    if not req:
        return None
    names, n = req
    vals = strip_options(args, {"-w","--working-directory","-d","--delay","-g","--group","-a","--after","-o","--priority","-l","--label","-s","--signal","--status","--failed-in-group","--groups","-p","--parallel"})
    if len(vals) < n:
        missing = names.split()[len(vals):]
        if len(missing) == 1:
            msg = f"the following required arguments were not provided:\n  {missing[0]}"
        else:
            msg = "the following required arguments were not provided:\n  " + "\n  ".join(missing)
        return clap_error(msg, usage)
    return None

def validate_args(key, args, usage):
    optvals = OPTVALS.get(key, {})
    flags = FLAGS.get(key, set())
    vals = []
    i = 0
    passthrough = False
    while i < len(args):
        a = args[i]
        if passthrough:
            vals.append(a); i += 1; continue
        if a == "--":
            passthrough = True; i += 1; continue
        base = a.split("=", 1)[0] if a.startswith("--") else a
        if base in optvals:
            if "=" not in a:
                if i + 1 >= len(args) or args[i+1].startswith("-"):
                    return clap_value_required(optvals[base])
                i += 2
            else:
                i += 1
            continue
        if a in flags:
            i += 1; continue
        if a.startswith("-") and a != "-":
            return clap_unexpected(a, usage, tip=(key in VARIADIC or key == "status"))
        vals.append(a)
        i += 1
    maxn = MAXARGS.get(key)
    if maxn is not None and len(vals) > maxn:
        return clap_unexpected(vals[maxn], usage)
    return None

def clap_unexpected(arg, usage, tip=False):
    msg = f"error: unexpected argument '{arg}' found\n"
    if tip:
        msg += f"\n  tip: to pass '{arg}' as a value, use '-- {arg}'\n"
    msg += f"\nUsage: executable {usage}\n\nFor more information, try '--help'."
    err(msg)
    return 2

def clap_value_required(opt):
    err(f"error: a value is required for '{opt}' but none was supplied\n\nFor more information, try '--help'.")
    return 2

def completion_text(shell):
    names = " ".join(COMMANDS + ["help"])
    if shell == "fish":
        return f"""# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_pueue_global_optspecs
\tstring join \\n v/verbose color= c/config= p/profile= h/help V/version
end

complete -c pueue -f -n "__fish_use_subcommand" -a "{names}"
"""
    if shell == "zsh":
        return f"#compdef pueue\n_arguments '*:: :->cmds'\n# commands: {names}\n"
    if shell == "power-shell":
        return f"using namespace System.Management.Automation\n# commands: {names}\n"
    if shell == "elvish":
        return f"# elvish completions for pueue\nset edit:completion:arg-completer[pueue] = {{|@words| put {names} }}\n"
    if shell == "nushell":
        return f"# nushell completions for pueue\nextern pueue [command?: string]\n"
    return f"""_pueue() {{
    local i cur prev opts cmd
    COMPREPLY=()
    cur="${{COMP_WORDS[COMP_CWORD]}}"
    opts="{names} -h --help -V --version -v --verbose --color --config --profile"
    COMPREPLY=( $(compgen -W "$opts" -- "$cur") )
}}
complete -F _pueue -o bashdefault -o default pueue
"""

def completions(args):
    if not args:
        return clap_error("the following required arguments were not provided:\n  <SHELL>", "completions <SHELL> [OUTPUT_DIRECTORY]")
    shell = args[0]
    allowed = ["bash","elvish","fish","power-shell","zsh","nushell"]
    if shell not in allowed:
        err(f"error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n")
        if shell == "bad":
            err("  tip: a similar value exists: 'bash'\n")
        err("For more information, try '--help'.")
        return 2
    text = completion_text(shell)
    if len(args) > 1:
        os.makedirs(args[1], exist_ok=True)
        ext = {"bash":"bash","fish":"fish","zsh":"zsh","power-shell":"ps1","elvish":"elv","nushell":"nu"}[shell]
        with open(os.path.join(args[1], f"pueue.{ext}"), "w") as f:
            f.write(text)
    else:
        sys.stdout.write(text)
    return 0

def parse_global(argv):
    config = os.environ.get("PUEUE_CONFIG_PATH")
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            out(MAIN_HELP_LONG if a == "--help" else MAIN_HELP)
            sys.exit(0)
        if a in ("-V", "--version"):
            out(VERSION)
            sys.exit(0)
        if a in ("-v", "-vv", "-vvv", "--verbose"):
            i += 1
            continue
        if a in ("-c", "--config", "-p", "--profile", "--color"):
            if i + 1 >= len(argv):
                return config, [a]
            if a in ("-c", "--config"):
                config = argv[i+1]
            i += 2
            continue
        if a.startswith("--config="):
            config = a.split("=",1)[1]
            i += 1
            continue
        if a.startswith("-"):
            clap_error(f"unexpected argument '{a}' found", "[OPTIONS] [COMMAND]")
            sys.exit(2)
        rest = argv[i:]
        break
    return config, rest

def main():
    config, args = parse_global(sys.argv[1:])
    if not args:
        out(MAIN_HELP_LONG)
        return 0
    cmd = args[0]
    tail = args[1:]
    if cmd == "help":
        if not tail:
            out(MAIN_HELP_LONG)
            return 0
        key = " ".join(tail[:2]) if " ".join(tail[:2]) in HELPS else tail[0]
        if key in HELPS:
            out(HELPS[key])
            return 0
        return clap_error(f"unrecognized subcommand '{tail[0]}'", "[OPTIONS] [COMMAND]")
    if cmd not in COMMANDS:
        return clap_error(f"unrecognized subcommand '{cmd}'", "[OPTIONS] [COMMAND]")
    if "-h" in tail or "--help" in tail:
        key = cmd
        if cmd in ("env","group") and tail and tail[0] in ("set","unset","add","remove"):
            key = f"{cmd} {tail[0]}"
        out(HELPS[key])
        return 0
    if cmd == "completions":
        return completions(tail)
    key = cmd
    subtail = tail
    if cmd == "env":
        if not tail:
            out(HELPS["env"])
            return 2
        if tail[0] not in ("set","unset","help"):
            return clap_error(f"unrecognized subcommand '{tail[0]}'", "env <COMMAND>")
        if tail[0] == "help":
            out(HELPS["env"])
            return 0
        key = f"env {tail[0]}"
        subtail = tail[1:]
    if cmd == "group" and tail and tail[0] in ("add","remove","help"):
        if tail[0] == "help":
            out(HELPS["group"])
            return 0
        key = f"group {tail[0]}"
        subtail = tail[1:]
    elif cmd == "group" and tail and not tail[0].startswith("-"):
        return clap_error(f"unrecognized subcommand '{tail[0]}'", "group [OPTIONS] [COMMAND]")
    usage = f"{key} {REQS[key][0]}" if key in REQS else key
    if key == "status":
        usage = "status [OPTIONS] [QUERY]..."
    elif key == "add":
        usage = "add [OPTIONS] <COMMAND>..."
    elif key in ("stash","enqueue","start","restart","pause","kill","log","wait"):
        usage = key + " [OPTIONS] [TASK_IDS]..."
    elif key in ("clean","reset"):
        usage = key + " [OPTIONS]"
    elif key == "follow":
        usage = "follow [OPTIONS] [TASK_ID]"
    elif key == "parallel":
        usage = "parallel [OPTIONS] [PARALLEL_TASKS]"
    elif key == "group add":
        usage = "group add [OPTIONS] <NAME>"
    v = validate_args(key, subtail, usage)
    if v is not None:
        return v
    req = check_required(key, subtail, f"{key} {REQS[key][0]}" if key in REQS else key)
    if req is not None:
        return req
    if config and not os.path.exists(config):
        return config_error(config)
    return config_error(None)

if __name__ == "__main__":
    sys.exit(main())
