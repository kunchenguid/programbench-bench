#!/usr/bin/env python3
import os
import stat
import sys
import time

GREEN = "\033[32m"
CYAN = "\033[36m"
RESET = "\033[39m"

FORMATS = {"metric", "binary", "bytes", "gb", "gib", "mb", "mib"}
DEFAULT_IGNORES = ["/proc", "/dev", "/sys", "/run"]


TOP_HELP = """A tool to learn about disk usage, fast!

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

Commands:
  interactive  Launch the terminal user interface [aliases: i]
  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [INPUT]...
          One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -t, --threads <THREADS>
          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread
          
          [default: 0]

  -f, --format <FORMAT>
          The format with which to print byte counts
          
          [default: binary]
          [possible values: metric, binary, bytes, gb, gib, mb, mib]

  -A, --apparent-size
          Display apparent size instead of disk usage

  -l, --count-hard-links
          Count hard-linked files each time they are seen

  -x, --stay-on-filesystem
          If set, we will not cross filesystems or traverse mount points

  -i, --ignore-dirs <IGNORE_DIRS>
          One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path.
          
          Hence, they will only be ignored if they are eventually reached as part of the traversal.
          
          [default: /proc /dev /sys /run]

      --log-file <LOG_FILE>
          Write a log file with debug information, including panics

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version"""

AGG_HELP = """Aggregate the consumed space of one or more directories or files

Usage: executable aggregate [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
      --stats     If set, print additional statistics about the file traversal to stderr
      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending
      --no-total  If set, no total column will be computed for multiple inputs
  -h, --help      Print help"""

INT_HELP = """Launch the terminal user interface

Usage: executable interactive [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -e, --no-entry-check  Do not check entries for presence when listing a directory to avoid slugging performance on slow filesystems
  -h, --help            Print help"""

COMP_HELP = """Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate a completions-script for [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help  Print help"""


class Options:
    def __init__(self):
        self.format = "binary"
        self.apparent = False
        self.count_hard = False
        self.stay_fs = False
        self.ignore_dirs = list(DEFAULT_IGNORES)
        self.stats = False
        self.no_sort = False
        self.no_total = False
        self.inputs = []
        self.command = "aggregate"


class Counters:
    def __init__(self):
        self.entries = 0
        self.smallest = None
        self.largest = 0
        self.errors = 0

    def add_entry(self, size):
        self.entries += 1
        self.smallest = size if self.smallest is None else min(self.smallest, size)
        self.largest = max(self.largest, size)


def eprint_error(message, usage=None, tip=True):
    print(f"error: {message}", file=sys.stderr)
    if tip and message.startswith("unexpected argument"):
        arg = message.split("'", 2)[1]
        print("", file=sys.stderr)
        print(f"  tip: to pass '{arg}' as a value, use '-- {arg}'", file=sys.stderr)
    if usage:
        print("", file=sys.stderr)
        print(usage, file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def parse(argv):
    opt = Options()
    args = list(argv)
    if not args:
        return opt
    if args[0] == "help":
        if len(args) == 1:
            print(TOP_HELP)
        elif args[1] in ("aggregate", "a"):
            print(AGG_HELP)
        elif args[1] in ("interactive", "i"):
            print(INT_HELP)
        elif args[1] == "completions":
            print(COMP_HELP)
        else:
            print(TOP_HELP)
        raise SystemExit(0)
    if args[0] in ("aggregate", "a"):
        opt.command = "aggregate"
        args.pop(0)
        parse_aggregate_options(args, opt)
        return opt
    if args[0] in ("interactive", "i"):
        if "-h" in args or "--help" in args:
            print(INT_HELP)
            raise SystemExit(0)
        print("Error: interactive mode is not available in this reimplementation", file=sys.stderr)
        raise SystemExit(1)
    if args[0] == "completions":
        if len(args) == 1 or args[1] in ("-h", "--help"):
            print(COMP_HELP)
            raise SystemExit(0)
        shell = args[1]
        if shell not in ("bash", "elvish", "fish", "powershell", "zsh"):
            raise SystemExit(eprint_error(f"invalid value '{shell}' for '<SHELL>'", None, False))
        print_completion(shell)
        raise SystemExit(0)
    for idx, arg in enumerate(args):
        if arg == "--":
            break
        if arg in ("aggregate", "a"):
            parse_global_options(args[:idx], opt)
            opt.command = "aggregate"
            parse_aggregate_options(args[idx + 1 :], opt)
            return opt
    parse_global_options(args, opt)
    return opt


def parse_global_options(args, opt):
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(TOP_HELP)
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print("dua 2.32.2")
            raise SystemExit(0)
        if a in ("-A", "--apparent-size"):
            opt.apparent = True
        elif a in ("-l", "--count-hard-links"):
            opt.count_hard = True
        elif a in ("-x", "--stay-on-filesystem"):
            opt.stay_fs = True
        elif a in ("-f", "--format"):
            i += 1
            if i >= len(args):
                raise SystemExit(eprint_error("a value is required for '--format <FORMAT>' but none was supplied", "Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...", False))
            val = args[i]
            if val not in FORMATS:
                print(f"error: invalid value '{val}' for '--format <FORMAT>'", file=sys.stderr)
                print("  [possible values: metric, binary, bytes, gb, gib, mb, mib]", file=sys.stderr)
                print("", file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                raise SystemExit(2)
            opt.format = val
        elif a.startswith("--format="):
            val = a.split("=", 1)[1]
            if val not in FORMATS:
                raise SystemExit(eprint_error(f"invalid value '{val}' for '--format <FORMAT>'", None, False))
            opt.format = val
        elif a in ("-t", "--threads", "--log-file"):
            i += 1
        elif a in ("-i", "--ignore-dirs"):
            i += 1
            if i < len(args):
                opt.ignore_dirs.append(os.path.abspath(args[i]))
        elif a == "--":
            opt.inputs.extend(args[i + 1 :])
            break
        elif a.startswith("-"):
            raise SystemExit(eprint_error(f"unexpected argument '{a}' found", "Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]..."))
        else:
            opt.inputs.append(a)
        i += 1


def parse_aggregate_options(args, opt):
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(AGG_HELP)
            raise SystemExit(0)
        if a == "--stats":
            opt.stats = True
        elif a == "--no-sort":
            opt.no_sort = True
        elif a == "--no-total":
            opt.no_total = True
        elif a == "--":
            opt.inputs.extend(args[i + 1 :])
            break
        elif a.startswith("-"):
            raise SystemExit(eprint_error(f"unexpected argument '{a}' found", "Usage: executable aggregate [OPTIONS] [INPUT]..."))
        else:
            opt.inputs.append(a)
        i += 1


def size_of_stat(st, apparent):
    return int(st.st_size if apparent else getattr(st, "st_blocks", 0) * 512)


def is_dir_mode(st):
    return stat.S_ISDIR(st.st_mode)


def is_symlink_mode(st):
    return stat.S_ISLNK(st.st_mode)


def should_ignore(path, input_root, opt):
    ap = os.path.abspath(path)
    if os.path.abspath(input_root) == ap:
        return False
    return ap in opt.ignore_dirs


def scan_path(path, opt, seen, counters, input_root=None, include_root=True, root_dev=None):
    if input_root is None:
        input_root = path
    try:
        st = os.lstat(path)
    except OSError:
        counters.errors += 1
        return 0, True
    if root_dev is None:
        root_dev = st.st_dev
    if opt.stay_fs and st.st_dev != root_dev:
        return 0, False
    if is_symlink_mode(st):
        size = size_of_stat(st, opt.apparent)
        counters.add_entry(size)
        return size if include_root else 0, False
    key = (st.st_dev, st.st_ino)
    size = size_of_stat(st, opt.apparent)
    hard_duplicate = (not opt.count_hard and not is_dir_mode(st) and st.st_nlink > 1 and key in seen)
    if not is_dir_mode(st):
        counters.add_entry(size)
    if not opt.count_hard and not is_dir_mode(st):
        seen.add(key)
    total = 0 if hard_duplicate or not include_root else size
    if is_dir_mode(st):
        try:
            with os.scandir(path) as it:
                for ent in it:
                    child = ent.path
                    if should_ignore(child, input_root, opt):
                        continue
                    child_size, _ = scan_path(child, opt, seen, counters, input_root, True, root_dev)
                    total += child_size
        except OSError:
            counters.errors += 1
            return total, True
    return total, False


def direct_entries(path, opt, seen, counters):
    entries = []
    try:
        names = os.listdir(path)
    except OSError:
        counters.errors += 1
        return entries
    for name in names:
        child = os.path.join(path, name)
        if should_ignore(child, path, opt):
            continue
        try:
            if is_symlink_mode(os.lstat(child)):
                continue
        except OSError:
            pass
        size, had_err = scan_path(child, opt, seen, counters, path, True)
        entries.append((size, name, child, is_dir(child), had_err))
    return entries


def is_dir(path):
    try:
        return stat.S_ISDIR(os.lstat(path).st_mode)
    except OSError:
        return False


def format_size(n, fmt):
    if fmt == "bytes":
        return f"{n:10d} b"
    if fmt in ("gb", "gib", "mb", "mib"):
        base = 1000 if fmt in ("gb", "mb") else 1024
        power = 3 if fmt in ("gb", "gib") else 2
        unit = fmt.upper() if fmt in ("gb", "mb") else fmt[:2].upper() + "B"
        return f"{(n / (base ** power)):8.2f} {unit}"
    base = 1000 if fmt == "metric" else 1024
    units = ["B", "KB", "MB", "GB", "TB", "PB"] if fmt == "metric" else ["B", "KiB", "MiB", "GiB", "TiB", "PiB"]
    value = float(n)
    idx = 0
    while value > base and idx < len(units) - 1:
        value /= base
        idx += 1
    if idx == 0:
        unit_width = 2 if fmt == "metric" else 3
        return f"{int(value):7d} {units[idx]:>{unit_width}}"
    return f"{value:7.2f} {units[idx]}"


def print_row(size, name, is_directory=False, err_count=0, fmt="binary"):
    label = f"{CYAN}{name}{RESET}" if is_directory else name
    suffix = f"  <{err_count} IO Error>" if err_count else ""
    print(f"{GREEN}{format_size(size, fmt)}{RESET} {label}{suffix}")


def print_completion(shell):
    if shell == "bash":
        print("_dua() {")
        print("    COMPREPLY=( $(compgen -W \"--help --version --format --apparent-size --count-hard-links aggregate interactive completions\" -- \"${COMP_WORDS[COMP_CWORD]}\") )")
        print("}")
        print("complete -F _dua dua")
    else:
        print(f"# completion script for {shell} is not available in this reimplementation")


def run(opt):
    inputs = opt.inputs
    seen = set()
    counters = Counters()
    rows = []
    status = 0
    if not inputs:
        rows = direct_entries(".", opt, seen, counters)
        if not opt.no_sort:
            rows.sort(key=lambda r: (r[0], r[1]))
        total = sum(r[0] for r in rows)
        for size, name, _, idir, had_err in rows:
            print_row(size, name, idir, 1 if had_err else 0, opt.format)
        if len(rows) > 1 and not opt.no_total:
            print_row(total, "total", False, counters.errors, opt.format)
    elif len(inputs) == 1 and is_dir(inputs[0]):
        rows = direct_entries(inputs[0], opt, seen, counters)
        if not opt.no_sort:
            rows.sort(key=lambda r: (r[0], r[1]))
        total = sum(r[0] for r in rows)
        for size, name, _, idir, had_err in rows:
            print_row(size, name, idir, 1 if had_err else 0, opt.format)
        if len(rows) > 1 and not opt.no_total:
            print_row(total, "total", False, counters.errors, opt.format)
    else:
        for p in inputs:
            before = counters.errors
            size, had_err = scan_path(p, opt, set(), counters, p, True)
            if had_err or counters.errors > before:
                status = 1
            rows.append((size, p, p, is_dir(p) or had_err, counters.errors - before))
        if not opt.no_sort:
            rows.sort(key=lambda r: (r[0], r[1]))
        total = sum(r[0] for r in rows)
        for size, name, _, idir, errn in rows:
            print_row(size, name, idir, errn, opt.format)
        if len(rows) > 1 and not opt.no_total:
            print_row(total, "total", False, counters.errors, opt.format)
    if opt.stats:
        smallest = 0 if counters.smallest is None else counters.smallest
        print(f"Statistics {{ entries_traversed: {counters.entries}, smallest_file_in_bytes: {smallest}, largest_file_in_bytes: {counters.largest} }}", file=sys.stderr)
    return 1 if counters.errors else status


def main():
    try:
        opt = parse(sys.argv[1:])
        raise SystemExit(run(opt))
    except BrokenPipeError:
        try:
            sys.stdout.close()
        finally:
            raise SystemExit(0)


if __name__ == "__main__":
    main()
