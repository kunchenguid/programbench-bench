#!/usr/bin/env python3
import os
import re
import subprocess
import sys
import tempfile


VERSION = "0.4.2"

HELP_TEXT = """nsh 0.4.2
A command-line shell that focuses on performance and productivity.

USAGE:
    executable [FLAGS] [OPTIONS] [FILE]

FLAGS:
    -h, --help       Prints help information
    -l, --login      Behave like a login shell
        --norc       Don't load nshrc
        --version    Print the version

OPTIONS:
    -c <command>        The command to be executed

ARGS:
    <FILE>    The file to be executed
"""


def err_unexpected(arg, usage):
    sys.stderr.write(
        "error: Found argument '{}' which wasn't expected, or isn't valid in this context\n\n"
        "USAGE:\n"
        "    {}\n\n"
        "For more information try --help\n".format(arg, usage)
    )
    return 1


def err_missing_c():
    sys.stderr.write(
        "error: The argument '-c <command>' requires a value but none was supplied\n\n"
        "USAGE:\n"
        "    executable -c <command>\n\n"
        "For more information try --help\n"
    )
    return 1


def nshrc_path():
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        candidate = os.path.join(xdg, "nsh", "nshrc")
        if os.path.exists(candidate):
            return candidate
    home = os.path.expanduser("~")
    candidate = os.path.join(home, ".nshrc")
    if os.path.exists(candidate):
        return candidate
    return None


def build_bash_env(load_rc):
    fd, path = tempfile.mkstemp(prefix="nsh-env-", suffix=".bash", text=True)
    rc = nshrc_path() if load_rc else None
    with os.fdopen(fd, "w") as f:
        f.write("shopt -s expand_aliases\n")
        f.write("command_not_found_handle() {\n")
        f.write("    printf \"nsh: command not found \\`%s'\\n\" \"$1\" >&2\n")
        f.write("    return 1\n")
        f.write("}\n")
        f.write("cd() {\n")
        f.write("    local target\n")
        f.write("    if [ \"$#\" -eq 0 ]; then target=\"$HOME\"; else target=\"$1\"; fi\n")
        f.write("    if builtin cd \"$target\" 2>/dev/null; then return 0; fi\n")
        f.write("    printf \"nsh: cd: No such file or directory (os error 2): \\`%s'\\n\" \"$target\" >&2\n")
        f.write("    return 1\n")
        f.write("}\n")
        if rc:
            quoted = rc.replace("'", "'\"'\"'")
            f.write(". '{}'\n".format(quoted))
    return path


def filter_stderr(data):
    filtered = []
    redir = re.compile(r"^bash: (?:line [0-9]+: )?.+: (?:No such file or directory|Permission denied)$")
    for line in data.splitlines(True):
        if redir.match(line.rstrip("\n")):
            continue
        filtered.append(line)
    return "".join(filtered)


def run_bash(args, load_rc=True, login=False, interactive=False):
    env = os.environ.copy()
    bash_env = build_bash_env(load_rc)
    env["BASH_ENV"] = bash_env
    argv0 = "-bash" if login else "bash"
    argv = [argv0]
    if interactive:
        argv.append("-i")
    argv.extend(args)
    try:
        if interactive:
            return subprocess.call(argv, env=env, executable="/bin/bash")
        proc = subprocess.Popen(argv, env=env, executable="/bin/bash", stderr=subprocess.PIPE)
        _, stderr = proc.communicate()
        text = stderr.decode(errors="replace")
        sys.stderr.write(filter_stderr(text))
        return proc.returncode
    finally:
        try:
            os.unlink(bash_env)
        except OSError:
            pass


def parse(argv):
    load_rc = True
    login = False
    command = None
    file_arg = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            sys.stdout.write(HELP_TEXT)
            return ("done", 0)
        if arg == "--version":
            sys.stdout.write(VERSION + "\n")
            return ("done", 0)
        if arg in ("-l", "--login"):
            login = True
            i += 1
            continue
        if arg == "--norc":
            load_rc = False
            i += 1
            continue
        if arg == "-c":
            if i + 1 >= len(argv):
                return ("done", err_missing_c())
            command = argv[i + 1]
            i += 2
            continue
        if arg.startswith("-"):
            return ("done", err_unexpected(arg, "executable [FLAGS] [OPTIONS] [FILE]"))
        if file_arg is None:
            file_arg = arg
            i += 1
            continue
        if command is not None:
            usage_parts = ["executable", "-c <command>"]
            if not load_rc:
                usage_parts.append("--norc")
            return ("done", err_unexpected(arg, " ".join(usage_parts)))
        usage_parts = ["executable"]
        if not load_rc:
            usage_parts.append("--norc")
        return ("done", err_unexpected(arg, " ".join(usage_parts)))
    return ("run", load_rc, login, command, file_arg)


def main():
    parsed = parse(sys.argv[1:])
    if parsed[0] == "done":
        return parsed[1]
    _, load_rc, login, command, file_arg = parsed
    if command is not None:
        return run_bash(["-c", command], load_rc=load_rc, login=login)
    if file_arg is not None:
        if not os.path.exists(file_arg):
            sys.stderr.write(
                "nsh: panicked at src/main.rs:114:34:\n"
                "failed to open the file: Os { code: 2, kind: NotFound, message: \"No such file or directory\" }\n"
                "nsh: Something went wrong. Check out ~/.nsh.log and please file this bug on GitHub: https://github.com/nuta/nsh/issues\n"
            )
            return 101
        return run_bash([file_arg], load_rc=load_rc, login=login)
    return run_bash([], load_rc=load_rc, login=login, interactive=True)


if __name__ == "__main__":
    sys.exit(main())
