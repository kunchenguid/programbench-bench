#!/usr/bin/env python3
import gzip
import os
import shutil
import struct
import sys
from dataclasses import dataclass, field

VERSION = "*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***"
SHORT_HELP = """Compress or decompress the INPUT file(s); reads from STDIN if INPUT is `-` or not provided.

Usage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]

Options:
  -o OUTPUT                     Write output to a single file, OUTPUT.
  -k, --keep                    Preserve INPUT file(s). [Default] 
  --rm                          Remove INPUT file(s) after successful (de)compression to file.

  -#                            Desired compression level, where `#` is a number between 1 and 19;
                                lower numbers provide faster compression, higher numbers yield
                                better compression ratios. [Default: 3]

  -d, --decompress              Perform decompression.
  -D DICT                       Use DICT as the dictionary for compression or decompression.

  -f, --force                   Disable input and output checks. Allows overwriting existing files,
                                receiving input from the console, printing output to STDOUT, and
                                operating on links, block devices, etc. Unrecognized formats will be
                                passed-through through as-is.

  -h                            Display short usage and exit.
  -H, --help                    Display full help and exit.
  -V, --version                 Display the program version and exit.
"""
FULL_HELP = VERSION + "\n\n" + SHORT_HELP + """Advanced options:
  -c, --stdout                  Write to STDOUT (even if it is a console) and keep the INPUT file(s).

  -v, --verbose                 Enable verbose output; pass multiple times to increase verbosity.
  -q, --quiet                   Suppress warnings; pass twice to suppress errors.
  --trace LOG                   Log tracing information to LOG.

  --[no-]progress               Forcibly show/hide the progress counter.
  -r                            Operate recursively on directories.
  --filelist LIST               Read a list of files to operate on from LIST.
  --output-dir-flat DIR         Store processed files in DIR.
  --output-dir-mirror DIR       Store processed files in DIR, respecting original directory structure.
  --[no-]asyncio                Use asynchronous IO. [Default: Enabled]
  --[no-]check                  Add XXH64 integrity checksums during compression. [Default: Add, Validate]
  --format=zstd                 Compress files to the `.zst` format. [Default]
  --format=gzip                 Compress files to the `.gz` format.

Advanced decompression options:
  -l                            Print information about Zstandard-compressed files.
  --test                        Test compressed file integrity.
"""

MAGIC = b"\x28\xb5\x2f\xfd"
SKIPPABLE_BASE = 0x184D2A50
ZSTD_CONTENTSIZE_UNKNOWN = None


class ZstdError(Exception):
    pass


def _fcs_bytes(size: int):
    if size < 256:
        return 0, bytes([size])
    if size < 65792:
        return 1, struct.pack("<H", size - 256)
    if size <= 0xFFFFFFFF:
        return 2, struct.pack("<I", size)
    return 3, struct.pack("<Q", size)


def zstd_compress_raw(data: bytes) -> bytes:
    fcs_flag, fcs = _fcs_bytes(len(data))
    descriptor = (fcs_flag << 6) | 0x20
    out = bytearray(MAGIC)
    out.append(descriptor)
    out.extend(fcs)
    if not data:
        out.extend((1).to_bytes(3, "little"))
        return bytes(out)
    pos = 0
    while pos < len(data):
        chunk = data[pos:pos + 131072]
        pos += len(chunk)
        last = 1 if pos >= len(data) else 0
        header = (len(chunk) << 3) | last
        out.extend(header.to_bytes(3, "little"))
        out.extend(chunk)
    return bytes(out)


def _read_exact(buf: memoryview, pos: int, n: int):
    if pos + n > len(buf):
        raise ZstdError("truncated input")
    return bytes(buf[pos:pos + n]), pos + n


def _parse_frame_header(buf: memoryview, pos: int):
    desc_b, pos = _read_exact(buf, pos, 1)
    desc = desc_b[0]
    fcs_flag = desc >> 6
    single = bool(desc & 0x20)
    dict_id_flag = desc & 0x03
    checksum = bool(desc & 0x04)
    if desc & 0x08:
        raise ZstdError("unsupported reserved frame flag")
    if not single:
        _, pos = _read_exact(buf, pos, 1)  # window descriptor
    if dict_id_flag:
        n = [0, 1, 2, 4][dict_id_flag]
        _, pos = _read_exact(buf, pos, n)
    if fcs_flag == 0:
        fcs_size = 1 if single else 0
    else:
        fcs_size = [None, 2, 4, 8][fcs_flag]
    content_size = ZSTD_CONTENTSIZE_UNKNOWN
    if fcs_size:
        raw, pos = _read_exact(buf, pos, fcs_size)
        content_size = int.from_bytes(raw, "little")
        if fcs_flag == 1:
            content_size += 256
    return pos, checksum, content_size


def zstd_decompress_limited(data: bytes, pass_through: bool = False):
    buf = memoryview(data)
    pos = 0
    out = bytearray()
    frames = 0
    skips = 0
    content_size = 0
    while pos < len(buf):
        if pos + 4 > len(buf):
            if pass_through and frames == 0:
                return data, 0, 0, len(data)
            raise ZstdError("unsupported format")
        magic = int.from_bytes(buf[pos:pos + 4], "little")
        if bytes(buf[pos:pos + 4]) == MAGIC:
            pos += 4
            frames += 1
            pos, checksum, fcs = _parse_frame_header(buf, pos)
            frame_start_out = len(out)
            while True:
                raw, pos = _read_exact(buf, pos, 3)
                bh = int.from_bytes(raw, "little")
                last = bh & 1
                btype = (bh >> 1) & 0x3
                bsize = bh >> 3
                if btype == 0:
                    chunk, pos = _read_exact(buf, pos, bsize)
                    out.extend(chunk)
                elif btype == 1:
                    b, pos = _read_exact(buf, pos, 1)
                    out.extend(b * bsize)
                elif btype == 2:
                    raise ZstdError("compressed zstd blocks are not supported by this reimplementation")
                else:
                    raise ZstdError("invalid zstd block")
                if last:
                    break
            if checksum:
                _, pos = _read_exact(buf, pos, 4)
            got = len(out) - frame_start_out
            if fcs is not None and got != fcs:
                raise ZstdError("content size mismatch")
            content_size += got
        elif SKIPPABLE_BASE <= magic <= SKIPPABLE_BASE + 15:
            pos += 4
            raw, pos = _read_exact(buf, pos, 4)
            n = int.from_bytes(raw, "little")
            _, pos = _read_exact(buf, pos, n)
            skips += 1
        elif pass_through and frames == 0:
            return data, 0, 0, len(data)
        else:
            raise ZstdError("unsupported format")
    return bytes(out), frames, skips, content_size


@dataclass
class Opts:
    decompress: bool = False
    stdout: bool = False
    force: bool = False
    remove: bool = False
    quiet: int = 0
    verbose: int = 0
    output: str | None = None
    fmt: str = "zstd"
    test: bool = False
    list_info: bool = False
    recursive: bool = False
    pass_through: bool = False
    filelists: list[str] = field(default_factory=list)
    output_dir_flat: str | None = None
    output_dir_mirror: str | None = None
    inputs: list[str] = field(default_factory=list)


def eprint(msg: str, opts: Opts | None = None):
    if opts is None or opts.quiet < 2:
        print(msg, file=sys.stderr)


def parse(argv):
    opts = Opts()
    expanded = []
    for a in argv:
        if (a.startswith("-") and not a.startswith("--") and len(a) > 2
                and not a[1:].isdigit() and a[1] not in "oDMTbei"):
            known = set("dcfkvqtrlhHSV")
            if all(ch in known for ch in a[1:]):
                expanded.extend("-" + ch for ch in a[1:])
            else:
                expanded.append(a)
        else:
            expanded.append(a)
    argv = expanded
    i = 0
    after_dashdash = False
    while i < len(argv):
        a = argv[i]
        if after_dashdash:
            opts.inputs.append(a); i += 1; continue
        if a == "--":
            after_dashdash = True; i += 1; continue
        if a in ("-H", "--help"):
            print(FULL_HELP); raise SystemExit(0)
        if a == "-h":
            print(SHORT_HELP); raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION); raise SystemExit(0)
        if a in ("-d", "--decompress", "--uncompress"):
            opts.decompress = True
        elif a in ("-t", "--test"):
            opts.decompress = True; opts.test = True
        elif a == "-l":
            opts.list_info = True; opts.decompress = True
        elif a in ("-c", "--stdout"):
            opts.stdout = True
        elif a in ("-f", "--force"):
            opts.force = True
        elif a in ("-k", "--keep"):
            opts.remove = False
        elif a == "--rm":
            opts.remove = True
        elif a in ("-q", "--quiet"):
            opts.quiet += 1
        elif a in ("-v", "--verbose"):
            opts.verbose += 1
        elif a == "-r":
            opts.recursive = True
        elif a in ("--pass-through", "--no-pass-through"):
            opts.pass_through = a == "--pass-through"
        elif a.startswith("--format="):
            opts.fmt = a.split("=", 1)[1]
        elif a == "--format":
            i += 1; opts.fmt = argv[i]
        elif a == "-o":
            i += 1; opts.output = argv[i]
        elif a.startswith("-o") and len(a) > 2:
            opts.output = a[2:]
        elif a == "--filelist":
            i += 1; opts.filelists.append(argv[i])
        elif a.startswith("--filelist="):
            opts.filelists.append(a.split("=", 1)[1])
        elif a == "--output-dir-flat":
            i += 1; opts.output_dir_flat = argv[i]
        elif a.startswith("--output-dir-flat="):
            opts.output_dir_flat = a.split("=", 1)[1]
        elif a == "--output-dir-mirror":
            i += 1; opts.output_dir_mirror = argv[i]
        elif a.startswith("--output-dir-mirror="):
            opts.output_dir_mirror = a.split("=", 1)[1]
        elif a in ("-D", "-M", "-T", "-b", "-e", "-i", "--trace", "--maxdict", "--dictID", "--split", "--jobsize", "--stream-size", "--size-hint", "--target-compressed-block-size", "--patch-from"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
        elif (a.startswith("-") and len(a) > 1 and (a[1:].isdigit() or a[1] in "TbeiM")):
            pass
        elif a.startswith("--fast") or a.startswith("--long") or a.startswith("--train") or a in (
            "--ultra", "--adapt", "--single-thread", "--rsyncable", "--exclude-compressed",
            "--patch-apply", "--priority=rt", "-S", "--check", "--no-check",
            "--progress", "--no-progress", "--asyncio", "--no-asyncio", "--mmap-dict",
            "--no-mmap-dict", "--no-dictID", "--compress-literals", "--no-compress-literals",
            "--row-match-finder", "--no-row-match-finder", "--sparse", "--no-sparse",
            "--auto-threads=physical", "--auto-threads=logical"):
            pass
        elif a.startswith("-") and a != "-":
            eprint(f"Incorrect parameter: {a} ")
            print(SHORT_HELP, file=sys.stderr)
            raise SystemExit(1)
        else:
            opts.inputs.append(a)
        i += 1
    for fl in opts.filelists:
        with open(fl, "r", encoding="utf-8", errors="surrogateescape") as f:
            opts.inputs.extend(line.rstrip("\n") for line in f if line.rstrip("\n"))
    return opts


def gather_inputs(opts: Opts):
    inputs = opts.inputs[:] or ["-"]
    out = []
    for p in inputs:
        if p == "-":
            out.append(p)
        elif os.path.isdir(p):
            if not opts.recursive:
                eprint(f"{p} is a directory -- ignored ", opts)
                continue
            for root, _, files in os.walk(p):
                for name in files:
                    out.append(os.path.join(root, name))
        else:
            out.append(p)
    return out


def default_output_name(path: str, opts: Opts):
    if opts.decompress:
        for ext in (".zst", ".gz"):
            if path.endswith(ext):
                return path[:-len(ext)]
        return path + ".out"
    return path + (".gz" if opts.fmt == "gzip" else ".zst")


def final_output_name(path: str, opts: Opts):
    if opts.output:
        return opts.output
    name = default_output_name(path, opts)
    if opts.output_dir_flat:
        return os.path.join(opts.output_dir_flat, os.path.basename(name))
    if opts.output_dir_mirror:
        return os.path.join(opts.output_dir_mirror, name.lstrip(os.sep))
    return name


def read_input(path: str):
    if path == "-":
        return sys.stdin.buffer.read()
    with open(path, "rb") as f:
        return f.read()


def maybe_write(path: str, data: bytes, opts: Opts):
    if opts.stdout or path == "-":
        sys.stdout.buffer.write(data)
        return True
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if os.path.exists(path) and not opts.force:
        eprint(f"zstd: {path} already exists; overwrite (y/n) ? Not overwritten  \n ", opts)
        return False
    with open(path, "wb") as f:
        f.write(data)
    return True


def transform(data: bytes, opts: Opts):
    if opts.decompress:
        if data.startswith(b"\x1f\x8b"):
            return gzip.decompress(data), 1, 0, None
        dec, frames, skips, usize = zstd_decompress_limited(data, opts.pass_through or opts.force)
        return dec, frames, skips, usize
    if opts.fmt == "gzip":
        return gzip.compress(data), 1, 0, len(data)
    return zstd_compress_raw(data), 1, 0, len(data)


def size_fmt(n):
    if n is None:
        return "?"
    return f"{n}   B" if n < 1000 else f"{n} B"


def list_file(path: str, data: bytes, opts: Opts):
    try:
        if data.startswith(b"\x1f\x8b"):
            dec = gzip.decompress(data)
            frames, skips, usize = 1, 0, len(dec)
        else:
            _, frames, skips, usize = zstd_decompress_limited(data, opts.pass_through or opts.force)
    except Exception as ex:
        eprint(f"{path}: {ex}", opts); return False
    if not getattr(list_file, "header", False):
        print("Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename")
        list_file.header = True
    ratio = (len(data) / usize) if usize else 0
    print(f"{frames:6d} {skips:6d} {len(data):7d}   B {usize:9d}   B {ratio:5.3f}  --     {path}")
    return True


def main(argv):
    try:
        opts = parse(argv)
    except IndexError:
        eprint("Incorrect parameters")
        return 1
    ok_all = True
    inputs = gather_inputs(opts)
    if opts.output and len(inputs) > 1 and not opts.stdout:
        eprint("zstd: error: multiple inputs cannot be used with a single output", opts)
        return 1
    for inp in inputs:
        try:
            data = read_input(inp)
            if opts.list_info:
                ok_all = list_file(inp, data, opts) and ok_all
                continue
            out, _frames, _skips, usize = transform(data, opts)
            if opts.test:
                if opts.quiet < 1 and inp != "-":
                    eprint(f"{inp:<20}: {len(out)} bytes ", opts)
                continue
            outpath = "-" if (opts.stdout or inp == "-") else final_output_name(inp, opts)
            written = maybe_write(outpath, out, opts)
            ok_all = ok_all and written
            if written and inp != "-" and not opts.stdout:
                if opts.quiet < 1:
                    if opts.decompress:
                        eprint(f"{inp:<20}: {len(out)} bytes ", opts)
                    else:
                        pct = (len(out) * 100.0 / len(data)) if data else 0.0
                        eprint(f"{inp:<20}:{pct:6.2f}%   ({len(data):6d} B => {len(out):6d} B, {outpath}) ", opts)
                if opts.remove:
                    try:
                        os.remove(inp)
                    except OSError:
                        pass
        except KeyboardInterrupt:
            return 2
        except Exception as ex:
            ok_all = False
            if opts.quiet < 2:
                eprint(f"{inp}: {ex}", opts)
    return 0 if ok_all else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
