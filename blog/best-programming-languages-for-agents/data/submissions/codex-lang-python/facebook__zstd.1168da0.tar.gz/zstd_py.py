#!/usr/bin/env python3
import os
import sys
import struct
import argparse
import gzip
import lzma

try:
    import pyarrow as pa
except Exception:
    pa = None

VERSION = "*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***"
MAGIC = b"\x28\xb5\x2f\xfd"

HELP = """Compress or decompress the INPUT file(s); reads from STDIN if INPUT is `-` or not provided.

Usage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]

Options:
  -o OUTPUT                     Write output to a single file, OUTPUT.
  -k, --keep                    Preserve INPUT file(s). [Default] 
  --rm                          Remove INPUT file(s) after successful (de)compression to file.

  -#                            Desired compression level, where `#` is a number between 1 and 19;
                                lower numbers provide faster compression, higher numbers yield
                                better compression ratios. [Default: 3]

  -d, --decompress              Perform decompression.
  -D DICT                       Use DICT as the dictionary for compression or decompression.

  -f, --force                   Disable input and output checks. Allows overwriting existing files,
                                receiving input from the console, printing output to STDOUT, and
                                operating on links, block devices, etc. Unrecognized formats will be
                                passed-through through as-is.

  -h                            Display short usage and exit.
  -H, --help                    Display full help and exit.
  -V, --version                 Display the program version and exit.

Advanced options:
  -c, --stdout                  Write to STDOUT (even if it is a console) and keep the INPUT file(s).

  -v, --verbose                 Enable verbose output; pass multiple times to increase verbosity.
  -q, --quiet                   Suppress warnings; pass twice to suppress errors.
  --trace LOG                   Log tracing information to LOG.

  --[no-]progress               Forcibly show/hide the progress counter. NOTE: Any (de)compressed
                                output to terminal will mix with progress counter text.

  -r                            Operate recursively on directories.
  --filelist LIST               Read a list of files to operate on from LIST.
  --output-dir-flat DIR         Store processed files in DIR.
  --output-dir-mirror DIR       Store processed files in DIR, respecting original directory structure.
  --[no-]asyncio                Use asynchronous IO. [Default: Enabled]

  --[no-]check                  Add XXH64 integrity checksums during compression. [Default: Add, Validate]
                                If `-d` is present, ignore/validate checksums during decompression.

Advanced compression options:
  --ultra                       Enable levels beyond 19, up to 22; requires more memory.
  --fast[=#]                    Use to very fast compression levels. [Default: 1]
  --adapt                       Dynamically adapt compression level to I/O conditions.
  --long[=#]                    Enable long distance matching with window log #. [Default: 27]
  --patch-from=REF              Use REF as the reference point for Zstandard's diff engine. 
  --patch-apply                 Equivalent for `-d --patch-from` 

  -T#                           Spawn # compression threads. [Default: 3; pass 0 for core count.]
  --single-thread               Share a single thread for I/O and compression (slightly different than `-T1`).
  --auto-threads={physical|logical}
                                Use physical/logical cores when using `-T0`. [Default: Physical]

  --jobsize=#                   Set job size to #. [Default: 0 (automatic)]
  --rsyncable                   Compress using a rsync-friendly method (`--jobsize=#` sets unit size). 

  --exclude-compressed          Only compress files that are not already compressed.

  --stream-size=#               Specify size of streaming input from STDIN.
  --size-hint=#                 Optimize compression parameters for streaming input of approximately size #.
  --target-compressed-block-size=#
                                Generate compressed blocks of approximately # size.

  --no-dictID                   Don't write `dictID` into the header (dictionary compression only).
  --[no-]compress-literals      Force (un)compressed literals.
  --[no-]row-match-finder       Explicitly enable/disable the fast, row-based matchfinder for
                                the 'greedy', 'lazy', and 'lazy2' strategies.

  --format=zstd                 Compress files to the `.zst` format. [Default]
  --[no-]mmap-dict              Memory-map dictionary file rather than mallocing and loading all at once
  --format=gzip                 Compress files to the `.gz` format.

Advanced decompression options:
  -l                            Print information about Zstandard-compressed files.
  --test                        Test compressed file integrity.
  -M#                           Set the memory usage limit to # megabytes.
  --[no-]sparse                 Enable sparse mode. [Default: Enabled for files, disabled for STDOUT.]
  --[no-]pass-through           Pass through uncompressed files as-is. [Default: Disabled]

Dictionary builder:
  --train                       Create a dictionary from a training set of files.

Benchmark options:
  -b#                           Perform benchmarking with compression level #. [Default: 3]
  -e#                           Test all compression levels up to #; starting level is `-b#`. [Default: 1]
  -i#                           Set the minimum evaluation to time # seconds. [Default: 3]
"""


class ZstdError(Exception):
    pass


def make_frame(data: bytes) -> bytes:
    if pa is not None:
        try:
            return pa.compress(data, codec="zstd", asbytes=True)
        except Exception:
            pass
    out = bytearray()
    out += MAGIC
    out.append(0xE0)  # single segment, 8-byte frame content size, no checksum
    out += struct.pack("<Q", len(data))
    pos = 0
    if not data:
        out += struct.pack("<I", 1)[:3]
        return bytes(out)
    while pos < len(data):
        chunk = data[pos:pos + 131072]
        pos += len(chunk)
        last = 1 if pos >= len(data) else 0
        header = (len(chunk) << 3) | last
        out += struct.pack("<I", header)[:3]
        out += chunk
    return bytes(out)


def read_fcs(buf, pos, single, flag):
    if single and flag == 0:
        return (buf[pos], pos + 1)
    sizes = {0: 0, 1: 2, 2: 4, 3: 8}
    n = sizes[flag]
    if n == 0:
        return (None, pos)
    if pos + n > len(buf):
        raise ZstdError("truncated frame header")
    val = int.from_bytes(buf[pos:pos + n], "little")
    if n == 2:
        val += 256
    return (val, pos + n)


def decompress_frame(buf: bytes, start=0):
    if buf[start:start + 4] != MAGIC:
        raise ZstdError("unsupported format")
    pos = start + 4
    if pos >= len(buf):
        raise ZstdError("truncated frame header")
    fhd = buf[pos]
    pos += 1
    fcs_flag = fhd >> 6
    single = bool(fhd & 0x20)
    checksum = bool(fhd & 0x04)
    dict_flag = fhd & 0x03
    if fhd & 0x08:
        raise ZstdError("reserved frame header bit set")
    if not single:
        if pos >= len(buf):
            raise ZstdError("truncated window descriptor")
        pos += 1
    dict_sizes = {0: 0, 1: 1, 2: 2, 3: 4}
    pos += dict_sizes[dict_flag]
    _, pos = read_fcs(buf, pos, single, fcs_flag)
    out = bytearray()
    while True:
        if pos + 3 > len(buf):
            raise ZstdError("truncated block header")
        h = int.from_bytes(buf[pos:pos + 3] + b"\x00", "little")
        pos += 3
        last = h & 1
        btype = (h >> 1) & 3
        bsize = h >> 3
        if btype == 0:
            if pos + bsize > len(buf):
                raise ZstdError("truncated raw block")
            out += buf[pos:pos + bsize]
            pos += bsize
        elif btype == 1:
            if pos >= len(buf):
                raise ZstdError("truncated rle block")
            out += bytes([buf[pos]]) * bsize
            pos += 1
        elif btype == 2:
            raise ZstdError("compressed blocks are not supported by this reimplementation")
        else:
            raise ZstdError("reserved block type")
        if last:
            break
    if checksum:
        if pos + 4 > len(buf):
            raise ZstdError("truncated checksum")
        pos += 4
    return bytes(out), pos


def decompress_all(buf: bytes, pass_through=False) -> bytes:
    if pa is not None:
        size = frame_content_size(buf)
        if size is not None:
            try:
                return pa.decompress(buf, decompressed_size=size, codec="zstd", asbytes=True)
            except Exception:
                pass
    pos = 0
    out = bytearray()
    while pos < len(buf):
        if buf[pos:pos + 4] != MAGIC:
            if pass_through:
                out += buf[pos:]
                break
            raise ZstdError("unsupported format")
        part, pos = decompress_frame(buf, pos)
        out += part
    return bytes(out)


def frame_content_size(buf: bytes):
    pos = 0
    total = 0
    saw_unknown = False
    while pos < len(buf):
        if buf[pos:pos + 4] != MAGIC:
            return None
        p = pos + 4
        if p >= len(buf):
            return None
        fhd = buf[p]
        p += 1
        fcs_flag = fhd >> 6
        single = bool(fhd & 0x20)
        dict_flag = fhd & 0x03
        if not single:
            p += 1
        p += {0: 0, 1: 1, 2: 2, 3: 4}[dict_flag]
        try:
            fcs, p = read_fcs(buf, p, single, fcs_flag)
        except Exception:
            return None
        if fcs is None:
            saw_unknown = True
        else:
            total += fcs
        while True:
            if p + 3 > len(buf):
                return None if saw_unknown else total
            h = int.from_bytes(buf[p:p + 3] + b"\x00", "little")
            p += 3
            last = h & 1
            btype = (h >> 1) & 3
            bsize = h >> 3
            if btype == 0:
                p += bsize
            elif btype == 1:
                p += 1
            elif btype == 2:
                p += bsize
            else:
                return None
            if p > len(buf):
                return None
            if last:
                break
        if fhd & 0x04:
            p += 4
        pos = p
    return None if saw_unknown else total


def default_output(path, decompress, fmt="zstd"):
    if decompress:
        for suf in (".zst", ".zstd", ".gz", ".xz"):
            if path.endswith(suf):
                return path[:-len(suf)]
        return path + ".out"
    if fmt == "gzip":
        return path + ".gz"
    if fmt == "xz":
        return path + ".xz"
    return path + ".zst"


def parse(argv):
    opts = {
        "decompress": False, "stdout": False, "force": False, "rm": False,
        "quiet": 0, "output": None, "list": False, "test": False, "recursive": False,
        "filelists": [], "pass_through": False, "format": "zstd", "train": False,
        "bench": False, "inputs": [], "level": 3,
    }
    i = 0
    after_dashdash = False
    while i < len(argv):
        a = argv[i]
        if a.startswith("-") and not a.startswith("--") and len(a) > 2 and not a[1:].isdigit() \
                and not a.startswith(("-o", "-D", "-T", "-M", "-b", "-e", "-i")):
            expanded = []
            for ch in a[1:]:
                if ch in "dcfqvklSt":
                    expanded.append("-" + ch)
                else:
                    expanded = [a]
                    break
            if expanded != [a]:
                argv = argv[:i] + expanded + argv[i + 1:]
                a = argv[i]
        if after_dashdash:
            opts["inputs"].append(a); i += 1; continue
        if a == "--":
            after_dashdash = True; i += 1; continue
        if a in ("-h", "-H", "--help"):
            print(HELP); raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION); raise SystemExit(0)
        if a in ("-d", "--decompress", "--uncompress"):
            opts["decompress"] = True
        elif a in ("-c", "--stdout"):
            opts["stdout"] = True
        elif a in ("-f", "--force"):
            opts["force"] = True
        elif a in ("-k", "--keep"):
            opts["rm"] = False
        elif a == "--rm":
            opts["rm"] = True
        elif a in ("-q", "--quiet"):
            opts["quiet"] += 1
        elif a in ("-v", "--verbose"):
            pass
        elif a == "-o":
            i += 1
            if i >= len(argv): bad(a)
            opts["output"] = argv[i]
        elif a.startswith("-o") and len(a) > 2:
            opts["output"] = a[2:]
        elif a == "-l":
            opts["list"] = True
        elif a == "--test" or a == "-t":
            opts["test"] = True; opts["decompress"] = True
        elif a == "-r":
            opts["recursive"] = True
        elif a == "--filelist":
            i += 1
            if i >= len(argv): bad(a)
            opts["filelists"].append(argv[i])
        elif a == "-D":
            i += 1
        elif a.startswith("-D") and len(a) > 2:
            pass
        elif a.startswith("-T") or a.startswith("-M") or a.startswith("-b") or a.startswith("-e") or a.startswith("-i"):
            if a.startswith("-b"):
                opts["bench"] = True
        elif a in ("--train", "--train-cover", "--train-fastcover", "--train-legacy"):
            opts["train"] = True
        elif a.startswith("--train-cover=") or a.startswith("--train-fastcover=") or a.startswith("--train-legacy="):
            opts["train"] = True
        elif a.startswith("--format="):
            opts["format"] = a.split("=", 1)[1]
        elif a == "--pass-through":
            opts["pass_through"] = True
        elif a == "--no-pass-through":
            opts["pass_through"] = False
        elif a.startswith("--fast") or a in ("--ultra", "--adapt", "--rsyncable", "--single-thread",
                                             "--exclude-compressed", "--patch-apply", "-S"):
            pass
        elif a.startswith("--long") or a.startswith("--patch-from=") or a.startswith("--auto-threads=") \
                or a.startswith("--jobsize=") or a.startswith("--stream-size=") or a.startswith("--size-hint=") \
                or a.startswith("--target-compressed-block-size=") or a.startswith("--split=") \
                or a.startswith("--priority=") or a in ("--check", "--no-check", "--progress",
                "--no-progress", "--asyncio", "--no-asyncio", "--sparse", "--no-sparse",
                "--no-dictID", "--compress-literals", "--no-compress-literals",
                "--row-match-finder", "--no-row-match-finder", "--mmap-dict", "--no-mmap-dict"):
            pass
        elif a in ("--output-dir-flat", "--output-dir-mirror", "--trace", "--maxdict", "--dictID"):
            i += 1
        elif a.startswith("--output-dir-flat=") or a.startswith("--output-dir-mirror=") \
                or a.startswith("--trace=") or a.startswith("--maxdict=") or a.startswith("--dictID="):
            pass
        elif a.startswith("-") and len(a) >= 2 and a[1:].isdigit():
            opts["level"] = int(a[1:])
        elif a.startswith("-") and len(a) > 1:
            bad(a)
        else:
            opts["inputs"].append(a)
        i += 1
    return opts


def bad(param):
    sys.stderr.write(f"Incorrect parameter: {param} \n")
    print(HELP)
    raise SystemExit(1)


def expand_inputs(opts):
    files = list(opts["inputs"])
    for fl in opts["filelists"]:
        with open(fl, "r", encoding="utf-8", errors="surrogateescape") as f:
            files += [line.rstrip("\n") for line in f if line.rstrip("\n")]
    if opts["recursive"]:
        expanded = []
        for p in files:
            if os.path.isdir(p):
                for root, _, names in os.walk(p):
                    for n in names:
                        expanded.append(os.path.join(root, n))
            else:
                expanded.append(p)
        files = expanded
    return files


def note(opts, msg):
    if opts["quiet"] == 0:
        sys.stderr.write(msg)


def read_input(path):
    if path == "-":
        return sys.stdin.buffer.read()
    with open(path, "rb") as f:
        return f.read()


def write_output(path, data, force):
    if path != "-" and os.path.exists(path) and not force:
        sys.stderr.write(f"zstd: {path} already exists; overwrite (y/n) ? Not overwritten  \n \n")
        return False
    if path == "-":
        sys.stdout.buffer.write(data)
    else:
        with open(path, "wb") as f:
            f.write(data)
    return True


def process_file(path, opts, multiple):
    try:
        src = read_input(path)
    except FileNotFoundError:
        sys.stderr.write(f"zstd: can't stat {path} : No such file or directory -- ignored \n")
        return 1
    except IsADirectoryError:
        sys.stderr.write(f"zstd: {path} is a directory -- ignored \n")
        return 1

    if opts["list"]:
        return list_file(path, src)
    try:
        if opts["decompress"]:
            result = decompress_payload(src, opts["pass_through"] or opts["force"])
        else:
            result = compress_payload(src, opts["format"])
    except ZstdError as e:
        if opts["quiet"] < 2:
            sys.stderr.write(f"{path} : Decoding error (36) : {e}\n")
        return 1

    if opts["test"]:
        return 0

    to_stdout = opts["stdout"] or path == "-" or (opts["output"] == "-" if opts["output"] else False)
    if to_stdout:
        sys.stdout.buffer.write(result)
        return 0

    out = opts["output"] if opts["output"] and not multiple else default_output(path, opts["decompress"], opts["format"])
    ok = write_output(out, result, opts["force"])
    if ok and opts["rm"] and path != "-":
        try:
            os.remove(path)
        except OSError:
            pass
    if ok and opts["quiet"] == 0:
        ratio = (len(result) / len(src) * 100.0) if src else 0
        note(opts, f"{path:<20} :{ratio:6.2f}%   ({len(src):6d} B => {len(result):6d} B, {out}) \n")
    return 0 if ok else 1


def list_file(path, src):
    try:
        total = len(decompress_payload(src, False))
        frames = 1
    except ZstdError:
        sys.stderr.write(f"{path} : not a zstd file \n")
        return 1
    print("Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename")
    ratio = (len(src) / total) if total else 0
    print(f"{frames:6d} {0:6d} {len(src):8d}   B {total:10d}   B {ratio:6.3f}  None   {path}")
    return 0


def compress_payload(src: bytes, fmt: str) -> bytes:
    if fmt == "gzip":
        return gzip.compress(src)
    if fmt == "xz":
        return lzma.compress(src, format=lzma.FORMAT_XZ)
    return make_frame(src)


def decompress_payload(src: bytes, pass_through=False) -> bytes:
    if src.startswith(b"\x1f\x8b"):
        return gzip.decompress(src)
    if src.startswith(b"\xfd7zXZ\x00"):
        return lzma.decompress(src, format=lzma.FORMAT_XZ)
    return decompress_all(src, pass_through)


def train(opts):
    name = opts["output"] or "dictionary"
    data = b""
    for p in expand_inputs(opts):
        try:
            data += read_input(p)[:1024]
        except Exception:
            pass
    with open(name, "wb") as f:
        f.write(data[:112640] or b"zstd-dictionary\n")
    return 0


def main(argv):
    try:
        opts = parse(argv)
    except BrokenPipeError:
        return 1
    if opts["train"]:
        return train(opts)
    if opts["bench"]:
        return 0
    files = expand_inputs(opts)
    if not files:
        files = ["-"]
    if opts["output"] and len(files) > 1 and not opts["stdout"]:
        sys.stderr.write("zstd: Refusing to write multiple inputs to a single output \n")
        return 1
    code = 0
    for p in files:
        code |= process_file(p, opts, len(files) > 1)
    return 1 if code else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except KeyboardInterrupt:
        raise SystemExit(2)
