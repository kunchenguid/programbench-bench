#!/usr/bin/env python3
import os
import shutil
import signal
import sys
import time
from datetime import datetime, timezone


USAGE = """usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] 
    -s            Show seconds                                   
    -S            Screensaver mode                               
    -x            Show box                                       
    -c            Set the clock at the center of the terminal    
    -C [0-7]      Set the clock color                            
    -b            Use bold colors                                
    -t            Set the hour in 12h format                     
    -u            Use UTC time                                   
    -T tty        Display the clock on the specified terminal    
    -r            Do rebound the clock                           
    -f format     Set the date format                            
    -n            Don't quit on keypress                         
    -v            Show tty-clock version                         
    -i            Show some info about tty-clock                 
    -h            Show this page                                 
    -D            Hide date                                      
    -B            Enable blinking colon                          
    -d delay      Set the delay between two redraws of the clock. Default 1s. 
    -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns."""

VERSION = "TTY-Clock 2 \u00a9 devel version"
INFO = "TTY-Clock 2 \u00a9 by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)"

DIGITS = {
    "0": [" #### ", "##  ##", "##  ##", "##  ##", " #### "],
    "1": ["  ##  ", " ###  ", "  ##  ", "  ##  ", " #### "],
    "2": [" #### ", "##  ##", "   ## ", " ##   ", "######"],
    "3": [" #### ", "    ##", "  ### ", "    ##", " #### "],
    "4": ["##  ##", "##  ##", "######", "    ##", "    ##"],
    "5": ["######", "##    ", "##### ", "    ##", "##### "],
    "6": [" #### ", "##    ", "##### ", "##  ##", " #### "],
    "7": ["######", "    ##", "   ## ", "  ##  ", "  ##  "],
    "8": [" #### ", "##  ##", " #### ", "##  ##", " #### "],
    "9": [" #### ", "##  ##", " #####", "    ##", " #### "],
    ":": ["  ", "##", "  ", "##", "  "],
    " ": ["   ", "   ", "   ", "   ", "   "],
}

FG = [30, 31, 32, 33, 34, 35, 36, 37]


class Options:
    def __init__(self):
        self.seconds = False
        self.screensaver = False
        self.box = False
        self.center = False
        self.color = 2
        self.bold = False
        self.twelve = False
        self.utc = False
        self.tty = None
        self.rebound = False
        self.date_format = "%Y-%m-%d"
        self.no_quit = False
        self.hide_date = False
        self.blink = False
        self.delay = 1.0
        self.nsdelay = 0


def progname():
    return sys.argv[0] or "./executable"


def print_usage():
    print(USAGE)


def parse(argv):
    opts = Options()
    needs_arg = set("CTfda")
    flags = set("iuvsScbtrahDBxn")
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            i += 1
            break
        if not arg.startswith("-") or arg == "-":
            i += 1
            continue
        if arg.startswith("--"):
            sys.stderr.write(f"{progname()}: invalid option -- '-'\n")
            print_usage()
            return opts, "done", 0
        j = 1
        while j < len(arg):
            ch = arg[j]
            if ch in needs_arg:
                if j + 1 < len(arg):
                    val = arg[j + 1 :]
                    j = len(arg)
                else:
                    if i + 1 >= len(argv):
                        sys.stderr.write(f"{progname()}: option requires an argument -- '{ch}'\n")
                        print_usage()
                        return opts, "done", 0
                    i += 1
                    val = argv[i]
                set_option(opts, ch, val)
                break
            if ch not in flags:
                sys.stderr.write(f"{progname()}: invalid option -- '{ch}'\n")
                print_usage()
                return opts, "done", 0
            action = set_option(opts, ch, None)
            if action:
                return opts, action, 0
            j += 1
        i += 1
    return opts, "run", 0


def set_option(opts, ch, val):
    if ch == "h":
        print_usage()
        return "done"
    if ch == "v":
        print(VERSION)
        return "done"
    if ch == "i":
        print(INFO)
        return "done"
    if ch == "s":
        opts.seconds = True
    elif ch == "S":
        opts.screensaver = True
    elif ch == "x":
        opts.box = True
    elif ch == "c":
        opts.center = True
    elif ch == "C":
        try:
            opts.color = int(val)
        except ValueError:
            opts.color = 2
    elif ch == "b":
        opts.bold = True
    elif ch == "t":
        opts.twelve = True
    elif ch == "u":
        opts.utc = True
    elif ch == "T":
        opts.tty = val
    elif ch == "r":
        opts.rebound = True
    elif ch == "f":
        opts.date_format = val
    elif ch == "n":
        opts.no_quit = True
    elif ch == "D":
        opts.hide_date = True
    elif ch == "B":
        opts.blink = True
    elif ch == "d":
        try:
            opts.delay = float(val)
        except ValueError:
            opts.delay = 1.0
    elif ch == "a":
        try:
            opts.nsdelay = int(val)
        except ValueError:
            opts.nsdelay = 0
    return None


def now(opts):
    return datetime.now(timezone.utc if opts.utc else None)


def render_text(text):
    rows = ["", "", "", "", ""]
    for ch in text:
        pat = DIGITS.get(ch, DIGITS[" "])
        for i, row in enumerate(pat):
            rows[i] += row + " "
    return rows


def clock_lines(opts):
    dt = now(opts)
    if opts.twelve:
        fmt = "%I:%M:%S" if opts.seconds else "%I:%M"
    else:
        fmt = "%H:%M:%S" if opts.seconds else "%H:%M"
    t = dt.strftime(fmt)
    if opts.blink and int(time.time()) % 2:
        t = t.replace(":", " ")
    lines = render_text(t)
    if not opts.hide_date:
        try:
            date_s = dt.strftime(opts.date_format)
        except Exception:
            date_s = dt.strftime("%Y-%m-%d")
        width = max(len(x) for x in lines)
        lines.append("")
        lines.append(date_s.center(width))
    if opts.box:
        width = max(len(x) for x in lines)
        top = "+" + "-" * (width + 2) + "+"
        boxed = [top]
        boxed += ["| " + x.ljust(width) + " |" for x in lines]
        boxed.append(top)
        lines = boxed
    return lines


def term_size():
    size = shutil.get_terminal_size((80, 24))
    return size.columns, size.lines


def nonblocking_stdin():
    try:
        import fcntl

        fd = sys.stdin.fileno()
        old = fcntl.fcntl(fd, fcntl.F_GETFL)
        fcntl.fcntl(fd, fcntl.F_SETFL, old | os.O_NONBLOCK)
    except Exception:
        pass


def read_key():
    try:
        data = os.read(sys.stdin.fileno(), 16)
    except Exception:
        return ""
    try:
        return data.decode(errors="ignore")
    except Exception:
        return ""


def run_clock(opts):
    term = os.environ.get("TERM", "unknown")
    if term == "unknown":
        sys.stderr.write("Error opening terminal: unknown.\n")
        return 1

    out = sys.stdout
    if opts.tty:
        try:
            out = open(opts.tty, "w", buffering=1)
        except OSError as e:
            sys.stderr.write(f"tty-clock: {opts.tty}: {e.strerror}\n")
            return 1

    delay = max(0.0, opts.delay + opts.nsdelay / 1_000_000_000.0)
    if delay == 0:
        delay = 0.01
    x = y = 1
    dx = dy = 1
    fg = FG[opts.color] if 0 <= opts.color < len(FG) else FG[2]
    style = f"\033[{1 if opts.bold else 0};{fg}m"
    stop = False

    def handler(signum, frame):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, handler)
    signal.signal(signal.SIGINT, handler)
    nonblocking_stdin()

    out.write("\033[?1049h\033[?25l")
    out.flush()
    try:
        while not stop:
            cols, rows_count = term_size()
            lines = clock_lines(opts)
            width = max(len(line) for line in lines)
            height = len(lines)
            if opts.center:
                x = max(1, (cols - width) // 2 + 1)
                y = max(1, (rows_count - height) // 2 + 1)
            elif opts.rebound:
                x += dx
                y += dy
                if x <= 1 or x + width >= cols:
                    dx *= -1
                    x = max(1, min(x, max(1, cols - width)))
                if y <= 1 or y + height >= rows_count:
                    dy *= -1
                    y = max(1, min(y, max(1, rows_count - height)))
            out.write("\033[H\033[2J")
            for idx, line in enumerate(lines):
                out.write(f"\033[{y + idx};{x}H{style}{line}\033[0m")
            out.flush()
            key = read_key()
            if key:
                low = key.lower()
                if opts.screensaver and not opts.no_quit:
                    break
                if "q" in low and not opts.no_quit:
                    break
                if "s" in low:
                    opts.seconds = not opts.seconds
                if "t" in low:
                    opts.twelve = not opts.twelve
                if "x" in low:
                    opts.box = not opts.box
                if "c" in low:
                    opts.center = not opts.center
                if "b" in low:
                    opts.bold = not opts.bold
            time.sleep(delay)
    finally:
        out.write("\033[0m\033[?25h\033[?1049l")
        out.flush()
        if out is not sys.stdout:
            out.close()
    return 0


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    opts, action, code = parse(argv)
    if action == "done":
        return code
    return run_clock(opts)


if __name__ == "__main__":
    raise SystemExit(main())
