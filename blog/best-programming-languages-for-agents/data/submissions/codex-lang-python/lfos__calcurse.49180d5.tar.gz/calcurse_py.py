#!/usr/bin/env python3
import sys, os, re, hashlib, calendar
from dataclasses import dataclass, field
from datetime import datetime, date, time, timedelta

VERSION='4.8.2'
HELP='''Usage:
calcurse [-D <directory>] [-C <directory>] [-c <calendar file>]
calcurse -Q [--from <date>] [--to <date>] [--days <number>]
calcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]
calcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon

Operations in command line mode:
  -Q, --query   Print items in a given query range
  -G, --grep    Grep items from the data files
  -P, --purge   Read items and write them back
Query short forms:
-a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>

Note that filter, format and day-range options affect input or output:
  --filter-*              Filter items loaded by -Q, -G, -P and -x
  --format-*              Rewrite output from -Q, -G and --dump-imported
  --from <date>           Limit day range of -Q.
  --to <date>             Limit day range of -Q.
  --days <number>         Limit day range of -Q.

  --limit, -l <number>    Limit number of query results
  --search, -S <regexp>   Match regular expression in queries
Consult the man page for details.

Miscellaneous:
  -c, --calendar <file>   The calendar data file to use
  -C, --confdir <dir>     The configuration directory to use
  --daemon                Run notification daemon in the background
  -D, --datadir <dir>     The data directory to use
  -g, --gc                Run the garbage collector
  -h, --help              Show this help text
  -i, --import <file>     Import iCal data from file
  -q, --quiet             Suppress import/export result message
  --read-only             Do not save configuration or data files
  --status                Display status of running instances
  -v, --version           Show version information
  -x, --export[<format>]  Export to stdout in ical (default) or pcal format

For more information, type '?' from within calcurse, or read the manpage.
Submit feature requests and suggestions to <misc@calcurse.org>.
Submit bug reports to <bugs@calcurse.org>.
'''

@dataclass
class CalItem:
    kind: str
    start: datetime
    end: datetime|None
    msg: str
    raw: str=''
    recur: dict|None=None
    note: str=''
    order: int=0

@dataclass
class Todo:
    prio: int
    msg: str
    raw: str=''
    note: str=''
    order: int=0
    @property
    def completed(self): return self.prio < 0

WEEKDAYS={'mon':0,'monday':0,'tue':1,'tuesday':1,'wed':2,'wednesday':2,'thu':3,'thursday':3,'fri':4,'friday':4,'sat':5,'saturday':5,'sun':6,'sunday':6}


def preprocess(argv):
    out=[]
    for a in argv:
        if len(a)>2 and re.match(r'^-[rtxsd][^-]', a):
            out += [a[:2], a[2:]]
        else: out.append(a)
    return out

def consume(argv):
    opts={'filters':{},'formats':{},'quiet':False,'inputfmt':1,'outputfmt':'%m/%d/%y'}; pos=[]; i=0
    takes={'-D':'datadir','--datadir':'datadir','-C':'confdir','--confdir':'confdir','-c':'calfile','--calendar':'calfile','-i':'import','--import':'import','--from':'from','--to':'to','--days':'days','-d':'day','--day':'day','-l':'limit','--limit':'limit','-S':'search','--search':'search','--input-datefmt':'inputfmt','--output-datefmt':'outputfmt','--filter-type':'filter_type','--filter-pattern':'filter_pattern','--filter-priority':'filter_priority','--filter-hash':'filter_hash','--filter-start-before':'filter_start_before','--filter-start-after':'filter_start_after','--filter-start-from':'filter_start_from','--filter-start-to':'filter_start_to','--filter-end-before':'filter_end_before','--filter-end-after':'filter_end_after','--filter-end-from':'filter_end_from','--filter-end-to':'filter_end_to','--filter-start-range':'filter_start_range','--filter-end-range':'filter_end_range','--format-apt':'format_apt','--format-event':'format_event','--format-recur-apt':'format_recur_apt','--format-recur-event':'format_recur_event','--format-todo':'format_todo'}
    flags={'-h':'help','--help':'help','-v':'version','--version':'version','--status':'status','-Q':'query','--query':'query','-G':'grep','--grep':'grep','-P':'purge','--purge':'purge','-g':'gc','--gc':'gc','-a':'appointment','--appointment':'appointment','-n':'next','--next':'next','-q':'quiet','--quiet':'quiet','--read-only':'readonly','--filter-completed':'filter_completed','--filter-uncompleted':'filter_uncompleted','--filter-invert':'filter_invert','--dump-imported':'dump_imported','--export-uid':'export_uid','--daemon':'daemon'}
    while i < len(argv):
        a=argv[i]
        if a in takes:
            if i+1>=len(argv): die(f"option requires an argument -- {a}")
            opts[takes[a]]=argv[i+1]; i+=2
        elif a in flags:
            opts[flags[a]]=True; i+=1
        elif a in ('-r','--range','-s','--startday','-t','--todo','-x','--export'):
            key={'-r':'range','--range':'range','-s':'startday','--startday':'startday','-t':'todo','--todo':'todo','-x':'export','--export':'export'}[a]
            if i+1<len(argv) and not argv[i+1].startswith('-') and key in ('range','startday','todo','export'):
                # Only consume optional arguments when they look like values for the option.
                if key in ('export','todo') or re.match(r'^[A-Za-z0-9_./:-]+$', argv[i+1]):
                    opts[key]=argv[i+1]; i+=2; continue
            opts[key]=True; i+=1
        else:
            pos.append(a); i+=1
    for k in list(opts):
        if k.startswith('filter_'): opts['filters'][k[7:]]=opts[k]
        if k.startswith('format_'): opts['formats'][k[7:].replace('_','-')]=opts[k]
    if 'search' in opts: opts['filters']['pattern']=opts['search']
    try: opts['inputfmt']=int(opts.get('inputfmt',1))
    except: opts['inputfmt']=1
    return opts,pos

def die(msg, code=1):
    print(msg, file=sys.stderr); sys.exit(code)

def data_paths(opts):
    home=os.path.expanduser('~')
    if os.path.isdir(os.path.join(home,'.calcurse')): base=os.path.join(home,'.calcurse')
    else: base=os.path.join(os.environ.get('XDG_DATA_HOME', os.path.join(home,'.local','share')),'calcurse')
    datadir=opts.get('datadir') or base
    calfile=opts.get('calfile') or os.path.join(datadir,'apts')
    todo=os.path.join(datadir,'todo')
    return datadir,calfile,todo

def fmt_date(d): return d.strftime('%m/%d/%Y')
def raw_hash(raw): return hashlib.sha1(raw.rstrip('\n').encode()).hexdigest()

def parse_date(s, inputfmt=1):
    s=str(s).strip().lower(); today=date.today()
    if s in ('today','now'): return today
    if s=='tomorrow': return today+timedelta(days=1)
    if s=='yesterday': return today-timedelta(days=1)
    if s[:3] in WEEKDAYS:
        wd=WEEKDAYS[s[:3]]; delta=(wd-today.weekday())%7
        return today+timedelta(days=delta)
    sep='-' if '-' in s else '/'
    parts=s.split(sep)
    try:
        nums=[int(x) for x in parts]
        if len(nums[0]) if False else False: pass
    except: die(f"invalid date: {s}")
    if len(parts)!=3: die(f"invalid date: {s}")
    nums=[int(x) for x in parts]
    if sep=='-' or inputfmt==4 or len(parts[0])==4: y,m,d=nums
    elif inputfmt==2: d,m,y=nums
    elif inputfmt==3: y,m,d=nums
    else: m,d,y=nums
    if y<100: y+=2000 if y<70 else 1900
    return date(y,m,d)

def parse_dt_arg(s,inputfmt=1):
    if ' ' in s:
        ds,ts=s.rsplit(' ',1); h,m=map(int,ts.split(':')); return datetime.combine(parse_date(ds,inputfmt), time(h,m))
    return datetime.combine(parse_date(s,inputfmt), time.min)

def parse_apts(path):
    items=[]
    if not os.path.exists(path): return items
    for idx,line in enumerate(open(path,encoding='utf-8',errors='replace')):
        line=line.rstrip('\n')
        if not line: continue
        raw=line+'\n'; note=''
        # appointment
        m=re.match(r'^(\d\d)/(\d\d)/(\d{4}) @ (\d\d):(\d\d) -> (\d\d)/(\d\d)/(\d{4}) @ (\d\d):(\d\d)(?: \{([^}]*)\})?\s*(?:>([0-9a-f]+) )?\|(.*)$', line)
        if m:
            mo,da,yr,h,mi,mo2,da2,yr2,h2,mi2,rec,note,msg=m.groups()
            it=CalItem('apt', datetime(int(yr),int(mo),int(da),int(h),int(mi)), datetime(int(yr2),int(mo2),int(da2),int(h2),int(mi2)), msg, raw, parse_recur(rec), note or '', idx)
            if it.recur: it.kind='recur-apt'
            items.append(it); continue
        m=re.match(r'^(\d\d)/(\d\d)/(\d{4}) \[(\d+)\](?: \{([^}]*)\})?\s*(?:>([0-9a-f]+) )?(.*)$', line)
        if m:
            mo,da,yr,dur,rec,note,msg=m.groups(); st=datetime(int(yr),int(mo),int(da))
            it=CalItem('event', st, st+timedelta(days=int(dur)), msg, raw, parse_recur(rec), note or '', idx)
            if it.recur: it.kind='recur-event'
            items.append(it)
    return items

def parse_recur(s):
    if not s: return None
    parts=s.split(); first=parts[0]; interval=int(first[:-1] or 1); freq=first[-1]
    until=None; exc=[]; byday=None; bymonth=None
    i=1
    if i<len(parts) and parts[i]=='->':
        until=parse_date(parts[i+1],1); i+=2
    while i<len(parts):
        p=parts[i]
        if p.startswith('!'): exc.append(parse_date(p[1:],1))
        elif p.startswith('w'): byday=p[1:]
        elif p.startswith('m'): bymonth=int(p[1:])
        i+=1
    return {'freq':freq,'interval':interval,'until':until,'exceptions':exc,'byday':byday,'bymonth':bymonth}

def parse_todo(path):
    out=[]
    if not os.path.exists(path): return out
    for idx,line in enumerate(open(path,encoding='utf-8',errors='replace')):
        line=line.rstrip('\n')
        m=re.match(r'^\[(-?\d+)\](?: >([0-9a-f]+))? (.*)$',line)
        if m:
            p,n,msg=m.groups(); out.append(Todo(int(p),msg,line+'\n',n or '',idx))
    return out

def save_data(calfile,todofile,items,todos):
    os.makedirs(os.path.dirname(calfile) or '.', exist_ok=True); os.makedirs(os.path.dirname(todofile) or '.', exist_ok=True)
    def sk(x):
        cat={'recur-event':0,'event':1,'recur-apt':2,'apt':3}.get(x.kind,9)
        return (x.start.date(), cat, x.start.time(), x.end or x.start, x.msg)
    with open(calfile,'w',encoding='utf-8') as f:
        for it in sorted(items,key=sk): f.write(make_raw(it))
    with open(todofile,'w',encoding='utf-8') as f:
        for t in todos: f.write(t.raw or f"[{t.prio}] {t.msg}\n")

def make_raw(it):
    if it.raw: return it.raw if it.raw.endswith('\n') else it.raw+'\n'
    rec=recur_raw(it.recur) if it.recur else ''
    note=(('>'+it.note+' ') if it.note else '')
    if 'event' in it.kind:
        days=max(1,(it.end.date()-it.start.date()).days if it.end else 1)
        sep = ' ' if rec or note else ' '
        return f"{fmt_date(it.start.date())} [{days}]" + (rec if rec else '') + (f" >{it.note}" if it.note else '') + f" {it.msg}\n"
    tail = (rec if rec else '') + (f" >{it.note}" if it.note else '')
    return f"{fmt_date(it.start.date())} @ {it.start:%H:%M} -> {fmt_date(it.end.date())} @ {it.end:%H:%M}{tail}|{it.msg}\n"

def recur_raw(r):
    if not r: return ''
    s=f" {{{r.get('interval',1)}{r.get('freq','D')}"
    if r.get('until'): s+=f" -> {fmt_date(r['until'])}"
    if r.get('byday'): s+=f" w{r['byday']}"
    if r.get('bymonth'): s+=f" m{r['bymonth']}"
    for e in r.get('exceptions',[]): s+=f" !{fmt_date(e)}"
    return s+'}'

def unesc(s):
    return s.replace('\\n','\n').replace('\\,',',').replace('\\;',';').replace('\\\\','\\')
def esc(s):
    return s.replace('\\','\\\\').replace('\n','\\n').replace(';','\\;').replace(',','\\,')

def unfold(text):
    lines=text.replace('\r\n','\n').replace('\r','\n').split('\n')
    out=[]
    for l in lines:
        if (l.startswith(' ') or l.startswith('\t')) and out: out[-1]+=l[1:]
        else: out.append(l)
    return out

def prop(line):
    inq=False
    for i,ch in enumerate(line):
        if ch=='"': inq=not inq
        elif ch==':' and not inq:
            left=line[:i]; val=line[i+1:]; name=left.split(';',1)[0].upper(); return name,left.upper(),val
    return None,None,None

def parse_ical_dt(val,left):
    allday='VALUE=DATE' in left or re.match(r'^\d{8}$',val or '')
    v=val.rstrip('Z')
    if allday: return datetime.strptime(v[:8],'%Y%m%d'), True
    return datetime.strptime(v[:15],'%Y%m%dT%H%M%S'), False

def parse_duration(s):
    m=re.match(r'^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$',s or '')
    if not m: return timedelta(0)
    d,h,mi,se=[int(x or 0) for x in m.groups()]
    return timedelta(days=d,hours=h,minutes=mi,seconds=se)

def import_ical(path, existing_items, existing_todos):
    text=open(path,encoding='utf-8',errors='replace').read(); lines=unfold(text); total=len(lines)
    new_items=[]; new_todos=[]; skipped=0; i=0
    while i<len(lines):
        line=lines[i].strip('\n')
        if line.upper() in ('BEGIN:VEVENT','BEGIN:VTODO'):
            typ=line.upper()[6:]; block=[]; i+=1
            while i<len(lines) and lines[i].upper()!=('END:'+typ): block.append(lines[i]); i+=1
            d={}; lefts={}
            multi={}
            malformed=False
            for b in block:
                n,l,v=prop(b)
                if n is None: malformed=True; continue
                if n in ('EXDATE',): multi.setdefault(n,[]).append((l,v))
                else: d[n]=v; lefts[n]=l
            try:
                if typ=='VTODO':
                    pr=int(d.get('PRIORITY','9') or '9')
                    if pr<1 or pr>9: raise ValueError
                    msg=unesc(d.get('SUMMARY',''))
                    if d.get('STATUS','').upper()=='COMPLETED': pr=-pr
                    raw=f"[{pr}] {msg}\n"; new_todos.append(Todo(pr,msg,raw,order=len(existing_todos)+len(new_todos))); continue
                if 'DTSTART' not in d or malformed: raise ValueError
                st,allday=parse_ical_dt(d['DTSTART'],lefts.get('DTSTART',''))
                if 'DTEND' in d:
                    en,_=parse_ical_dt(d['DTEND'],lefts.get('DTEND',''))
                else:
                    en=st+parse_duration(d.get('DURATION','P1D' if allday else 'PT0S'))
                    if allday and 'DURATION' not in d: en=st+timedelta(days=1)
                msg=unesc(d.get('SUMMARY',''))
                r=parse_rrule(d.get('RRULE'), st, en, allday)
                ex=[]
                for l,v in multi.get('EXDATE',[]):
                    for part in v.split(','):
                        try: ex.append(parse_ical_dt(part,l)[0].date())
                        except: pass
                if r: r['exceptions']=ex
                kind='event' if allday else 'apt'
                if r: kind='recur-'+kind
                if allday and not r and (en.date()-st.date()).days>1:
                    r={'freq':'D','interval':1,'until':en.date()-timedelta(days=1),'exceptions':[]}; kind='recur-event'; en=st+timedelta(days=1)
                it=CalItem(kind,st,en,msg,recur=r,order=len(existing_items)+len(new_items)); it.raw=''; new_items.append(it)
            except Exception:
                skipped+=1
        i+=1
    return new_items,new_todos,total,skipped

def parse_rrule(s, st, en, allday):
    if not s: return None
    vals={}
    for p in s.split(';'):
        if '=' in p:
            k,v=p.split('=',1); vals[k.upper()]=v
    freq=vals.get('FREQ','').upper(); mp={'DAILY':'D','WEEKLY':'W','MONTHLY':'M','YEARLY':'Y'}
    if freq not in mp: raise ValueError
    r={'freq':mp[freq],'interval':int(vals.get('INTERVAL','1') or '1'),'exceptions':[]}
    if 'UNTIL' in vals:
        u,_=parse_ical_dt(vals['UNTIL'], '')
        if not allday and u.time() < st.time(): u=u-timedelta(days=1)
        r['until']=u.date()
    if 'COUNT' in vals:
        count=int(vals['COUNT']); occ=list(gen_occurrences(st, en, {'freq':r['freq'],'interval':r['interval'],'until':date(2100,1,1),'exceptions':[],'rrule':vals}, date(1900,1,1), date(2100,1,1), limit=count))
        if occ: r['until']=occ[-1][0].date()
    if 'BYMONTH' in vals: r['bymonth']=int(vals['BYMONTH'].split(',')[0])
    if 'BYDAY' in vals:
        # Store calcurse-style compact weekday marker approximately; generation uses original info.
        r['rrule']=vals; bd=vals['BYDAY'].split(',')[0]; n=bd[:-2]; wd=['MO','TU','WE','TH','FR','SA','SU'].index(bd[-2:])
        if n: r['byday']=str((int(n)-1)*7+wd+1 if int(n)>0 else int(n)*7+wd+1)
    elif 'BYMONTHDAY' in vals: r['rrule']=vals
    return r

def add_months(d,n):
    y=d.year+(d.month-1+n)//12; m=(d.month-1+n)%12+1; last=calendar.monthrange(y,m)[1]
    return d.replace(year=y,month=m,day=min(d.day,last))

def nth_weekday(year,month,n,wd):
    days=[date(year,month,day) for day in range(1,calendar.monthrange(year,month)[1]+1) if date(year,month,day).weekday()==wd]
    return days[n-1] if n>0 and n<=len(days) else (days[n] if n<0 and -n<=len(days) else None)

def by_candidates(base, r):
    vals=r.get('rrule') or {}
    if 'BYDAY' in vals and r.get('freq') in ('W','M','Y'):
        out=[]
        for bd in vals['BYDAY'].split(','):
            wd=['MO','TU','WE','TH','FR','SA','SU'].index(bd[-2:]); num=bd[:-2]
            if r['freq']=='W':
                start=base-timedelta(days=base.weekday()); out.append(start+timedelta(days=wd))
            else:
                month=int(vals.get('BYMONTH',base.month)) if r['freq']=='Y' else base.month
                cand=nth_weekday(base.year,month,int(num or '1'),wd) if num else None
                if cand: out.append(cand)
        return out
    if 'BYMONTHDAY' in vals and r.get('freq')=='M':
        out=[]; last=calendar.monthrange(base.year,base.month)[1]
        for p in vals['BYMONTHDAY'].split(','):
            n=int(p); day=n if n>0 else last+n+1
            if 1<=day<=last: out.append(date(base.year,base.month,day))
        return out
    return [base]

def gen_occurrences(st,en,r,fromd,tod,limit=10000):
    if not r:
        if en.date()>=fromd and st.date()<=tod: yield st,en
        return
    dur=en-st; cur=st.date(); until=r.get('until') or date(2100,1,1); n=0; yielded=0
    while cur<=until and yielded<limit and n<10000:
        for cd in by_candidates(cur,r):
            if cd < st.date() or cd>until or cd in r.get('exceptions',[]): continue
            ost=datetime.combine(cd, st.time()); oen=ost+dur
            if oen.date()>=fromd and ost.date()<=tod:
                yield ost,oen; yielded+=1
                if yielded>=limit: return
        n+=1
        if r['freq']=='D': cur=cur+timedelta(days=r.get('interval',1))
        elif r['freq']=='W': cur=cur+timedelta(weeks=r.get('interval',1))
        elif r['freq']=='M': cur=add_months(cur,r.get('interval',1))
        elif r['freq']=='Y': cur=cur.replace(year=cur.year+r.get('interval',1))
        else: break

def type_match(kind, t):
    if not t: return True
    vals=[]
    for x in t.split(','):
        if x=='cal': vals+=['event','apt','recur-event','recur-apt']
        elif x=='recur': vals+=['recur-event','recur-apt']
        else: vals.append(x)
    return kind in vals

def filter_items(items,todos,opts):
    f=opts.get('filters',{}); pat=f.get('pattern')
    if pat:
        try: rx=re.compile(pat)
        except: rx=re.compile(re.escape(pat))
    else: rx=None
    out=[]
    for it in items:
        ok=type_match(it.kind,f.get('type'))
        if rx and not rx.search(it.msg): ok=False
        if f.get('hash'):
            h=raw_hash(make_raw(it)); s=f['hash']; neg=s.startswith('!'); s=s[1:] if neg else s; ok = ok and ((not h.startswith(s)) if neg else h.startswith(s))
        for key,cmp in [('start_before','<'),('start_after','>'),('start_from','>='),('start_to','<=')]:
            if f.get(key):
                dt=parse_dt_arg(f[key],opts.get('inputfmt',1)); ok=ok and eval('it.start '+cmp+' dt')
        for key,cmp in [('end_before','<'),('end_after','>'),('end_from','>='),('end_to','<=')]:
            if f.get(key) and it.end:
                dt=parse_dt_arg(f[key],opts.get('inputfmt',1)); ok=ok and eval('it.end '+cmp+' dt')
        if f.get('invert'): ok=not ok
        if ok: out.append(it)
    tout=[]
    for t in todos:
        ok=type_match('todo',f.get('type'))
        if rx and not rx.search(t.msg): ok=False
        if f.get('priority') and abs(t.prio)!=int(f['priority']): ok=False
        if f.get('completed') and not t.completed: ok=False
        if f.get('uncompleted') and t.completed: ok=False
        if f.get('hash'):
            h=raw_hash(t.raw); s=f['hash']; neg=s.startswith('!'); s=s[1:] if neg else s; ok = ok and ((not h.startswith(s)) if neg else h.startswith(s))
        if f.get('invert'): ok=not ok
        if ok: tout.append(t)
    return out,tout

def interpret_format(fmt,obj,day=None,occ=None):
    raw = obj.raw if hasattr(obj,'raw') else ''
    if isinstance(obj,Todo):
        rep={'%m':obj.msg,'%p':str(abs(obj.prio)),'%n':obj.note,'%N':'','%(raw)':raw,'%(hash)':raw_hash(raw)}
    else:
        st,en=occ if occ else (obj.start,obj.end); dur=int((obj.end-obj.start).total_seconds()) if obj.end else 0
        S=st.strftime('%H:%M') if not day or st.date()>=day else '..:..'
        if not day:
            E=en.strftime('%H:%M')
        elif en.date() <= day or (en.time() == time.min and en.date() == day + timedelta(days=1)):
            E=en.strftime('%H:%M')
        else:
            E='..:..'
        rep={'%m':obj.msg,'%n':obj.note,'%N':'','%s':str(int(obj.start.timestamp())),'%e':str(int(obj.end.timestamp())),'%d':str(dur),'%S':S,'%E':E,'%(raw)':make_raw(obj),'%(hash)':raw_hash(make_raw(obj))}
    def ext(m):
        namefmt=m.group(1); parts=namefmt.split(':',1); name=parts[0]; fr=parts[1] if len(parts)>1 else None
        if name=='raw': return rep.get('%(raw)','')
        if name=='hash': return rep.get('%(hash)','')
        if name=='start': return obj.start.strftime(fr) if fr and fr not in ('epoch','default') else rep.get('%s','')
        if name=='end': return obj.end.strftime(fr) if fr and fr not in ('epoch','default') else rep.get('%e','')
        if name=='duration': return rep.get('%d','')
        return ''
    s=re.sub(r'%\(([^)]+)\)', ext, fmt)
    for k in sorted(rep,key=len,reverse=True): s=s.replace(k,rep[k])
    return s.encode('utf-8').decode('unicode_escape')

def query(items,todos,opts,only_cal=False,only_todo=False):
    today=date.today(); inputfmt=opts.get('inputfmt',1)
    if 'from' in opts: start=parse_date(opts['from'],inputfmt)
    else: start=today
    if 'to' in opts: end=parse_date(opts['to'],inputfmt)
    elif 'days' in opts:
        n=int(opts['days']); end=start+timedelta(days=n-1) if n>=0 else start; start=start+timedelta(days=n+1) if n<0 else start
    else: end=start
    limit=int(opts.get('limit') or 0); count=0
    if not only_cal and todos:
        opens=[t for t in todos if not t.completed]; comps=[t for t in todos if t.completed]
        if only_todo:
            if opens:
                print('to do:')
                for t in opens:
                    print(interpret_format(opts['formats'].get('todo','%p. %m\n'),t), end=''); count+=1
                print()
            if comps:
                print('completed tasks:')
                for t in comps: print(interpret_format(opts['formats'].get('todo','%p. %m\n'),t), end='')
        else:
            both=opens+comps
            if both:
                print('to do:')
                for t in both:
                    print(interpret_format(opts['formats'].get('todo','%p. %m\n'),t), end=''); count+=1
                print()
    if only_todo: return
    d=start
    while d<=end:
        occs=[]
        for it in items:
            for st,en in gen_occurrences(it.start,it.end,it.recur,d,d):
                if 'event' in it.kind:
                    active = st.date() <= d < en.date()
                else:
                    active = st.date() <= d and (d < en.date() or (d == en.date() and en.time() != time.min))
                if active: occs.append((it,st,en))
        occs.sort(key=lambda x:(0 if 'event' in x[0].kind else 1, x[1].time(), x[0].order))
        if occs:
            print(d.strftime(opts.get('outputfmt') or '%m/%d/%y')+':')
            for it,st,en in occs:
                key='recur-event' if it.kind=='recur-event' else 'event' if 'event' in it.kind else 'recur-apt' if it.kind=='recur-apt' else 'apt'
                default=' * %m\n' if 'event' in key else ' - %S -> %E\n\t%m\n'
                print(interpret_format(opts['formats'].get(key,default),it,d,(st,en)), end='')
            print()
        d+=timedelta(days=1)

def grep(items,todos,opts):
    allobjs=todos+items
    allobjs.sort(key=lambda x:x.order if isinstance(x,Todo) else 100000+x.order)
    for o in allobjs:
        if isinstance(o,Todo): fmt=opts['formats'].get('todo','%(raw)')
        else:
            k=o.kind; fmt=opts['formats'].get(k,'%(raw)')
        print(interpret_format(fmt,o), end='')

def export_ical(items,todos):
    print('BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//calcurse//NONSGML v4.8.2//EN')
    for it in sorted(items,key=lambda x:(x.start,x.order)):
        print('BEGIN:VEVENT')
        if 'event' in it.kind:
            print('DTSTART;VALUE=DATE:'+it.start.strftime('%Y%m%d'))
            if it.recur: print(rrule_export(it.recur, all_day=True))
        else:
            print('DTSTART:'+it.start.strftime('%Y%m%dT%H%M%S'))
            dur=it.end-it.start; days=dur.days; secs=dur.seconds; h=secs//3600; m=(secs%3600)//60; s=secs%60
            print(f'DURATION:P{days}DT{h}H{m}M{s}S')
            if it.recur: print(rrule_export(it.recur, all_day=False))
        print('SUMMARY:'+esc(it.msg)); print('END:VEVENT')
    for t in todos:
        print('BEGIN:VTODO'); print('PRIORITY:'+str(abs(t.prio))); print('SUMMARY:'+esc(t.msg))
        if t.completed: print('STATUS:COMPLETED')
        print('END:VTODO')
    print('END:VCALENDAR')

def rrule_export(r,all_day=False):
    rev={'D':'DAILY','W':'WEEKLY','M':'MONTHLY','Y':'YEARLY'}; s=f"RRULE:FREQ={rev.get(r.get('freq'),'DAILY')}"
    if r.get('interval',1)!=1: s+=f";INTERVAL={r['interval']}"
    if r.get('until'): s+=';UNTIL='+r['until'].strftime('%Y%m%d' if all_day else '%Y%m%dT000000')
    return s

def main():
    opts,pos=consume(preprocess(sys.argv[1:]))
    if opts.get('help'): print(HELP,end=''); return 0
    if opts.get('version'):
        print(f'calcurse {VERSION} -- text-based organizer\n\nCopyright (c) 2004-2023 calcurse Development Team.\nThis is free software; see the source for copying conditions.'); return 0
    if opts.get('status'): print('calcurse is not running'); return 0
    if opts.get('gc') or opts.get('daemon'): return 0
    datadir,calfile,todofile=data_paths(opts); items=parse_apts(calfile); todos=parse_todo(todofile)
    if 'import' in opts:
        newi,newt,total,skipped=import_ical(opts['import'],items,todos); items+=newi; todos+=newt
        if not opts.get('readonly'): save_data(calfile,todofile,items,todos)
        if opts.get('dump_imported'):
            grep(newi,newt,opts)
        if not opts.get('quiet'):
            if skipped: print(f'Some items could not be imported.\nSee /tmp/calcurse_log.fake for details.')
            print(f'Import process report: {total:04d} lines read')
            print(f'{sum(1 for x in newi if "apt" in x.kind)} apps / {sum(1 for x in newi if "event" in x.kind)} events / {len(newt)} todo / {skipped} skipped')
        return 1 if skipped else 0
    if opts.get('appointment'): opts['query']=True; opts['filters']['type']='cal'
    if 'day' in opts:
        opts['query']=True; opts['filters']['type']='cal'
        if re.match(r'^-?\d+$',str(opts['day'])): opts['days']=opts['day']
        else: opts['from']=opts['day']
    if 'range' in opts: opts['query']=True; opts['filters']['type']='cal'; opts['days']='1' if opts['range'] is True else opts['range']
    if 'startday' in opts: opts['query']=True; opts['filters']['type']='cal'; opts['from']=date.today().isoformat() if opts['startday'] is True else opts['startday']; opts['inputfmt']=4 if opts['startday'] is True else opts.get('inputfmt',1)
    if 'todo' in opts:
        opts['query']=True; opts['filters']['type']='todo'
        if opts['todo'] is not True:
            n=int(opts['todo']);
            if n==0: opts['filters']['completed']=True
            else: opts['filters']['priority']=str(n); opts['filters']['uncompleted']=True
    all_items, all_todos = items, todos
    items,todos=filter_items(items,todos,opts)
    if opts.get('grep'): grep(items,todos,opts); return 0
    if opts.get('purge'):
        if not opts.get('readonly'):
            drop_items = {id(x) for x in items}
            drop_todos = {id(x) for x in todos}
            save_data(calfile,todofile,[x for x in all_items if id(x) not in drop_items],[x for x in all_todos if id(x) not in drop_todos])
        return 0
    if 'export' in opts: export_ical(items,todos); return 0
    if opts.get('next'):
        future=[]; now=datetime.now()
        for it in items:
            if 'apt' in it.kind:
                for st,en in gen_occurrences(it.start,it.end,it.recur,now.date(),(now+timedelta(days=1)).date()):
                    if st>=now: future.append((st,it))
        if future:
            st,it=min(future); delta=st-now; h=int(delta.total_seconds()//3600); m=int((delta.total_seconds()%3600)//60); print(f'{h:02d}:{m:02d} {it.msg}')
        return 0
    if opts.get('query'):
        query(items,todos,opts,only_cal=opts['filters'].get('type')=='cal',only_todo=opts['filters'].get('type')=='todo'); return 0
    # Non-interactive fallback in this reimplementation.
    return 0
if __name__=='__main__': sys.exit(main())
