#!/usr/bin/env python3
import os
import re
import sys
from pathlib import Path

VERSION = "bat 0.26.1 (610b77c)"
ROOT = Path(__file__).resolve().parent.parent


def resource(path, fallback=""):
    try:
        return (ROOT / path).read_text(encoding="utf-8")
    except OSError:
        return fallback


SHORT_HELP = resource("doc/short-help.txt")
LONG_HELP = resource("doc/long-help.txt")
LANGUAGES = resource("src/languages.txt")
THEMES = resource("src/themes.txt")


class Options:
    def __init__(self):
        self.files = []
        self.plain = 0
        self.number = False
        self.show_all = False
        self.notation = "unicode"
        self.tabs = 4
        self.line_ranges = []
        self.squeeze = False
        self.squeeze_limit = None
        self.quiet_empty = False
        self.decorations = "auto"
        self.color = "auto"
        self.style = None
        self.file_name = None
        self.binary = "no-printing"
        self.strip_ansi = "never"
        self.unbuffered = False
        self.wrap = "auto"
        self.terminal_width = None


TAKES_VALUE = {
    "--language", "-l", "--fallback-syntax", "--fallback-language",
    "--highlight-line", "-H", "--file-name", "--diff-context", "--tabs",
    "--wrap", "--terminal-width", "--color", "--italic-text",
    "--decorations", "--paging", "--pager", "--map-syntax", "-m", "--theme",
    "--theme-light", "--theme-dark", "--style", "--line-range", "-r",
    "--completion", "--nonprintable-notation", "--binary", "--squeeze-limit",
    "--strip-ansi", "--ignored-suffix",
}


def print_usage_error(arg):
    sys.stderr.write(f"error: unexpected argument '{arg}' found\n\n")
    sys.stderr.write(f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n")
    sys.stderr.write("Usage: executable [OPTIONS] [FILE]...\n")
    sys.stderr.write("       executable <COMMAND>\n")
    return 2


def parse_args(argv):
    opts = Options()
    i = 0
    stop = False
    while i < len(argv):
        arg = argv[i]
        if stop:
            opts.files.append(arg)
            i += 1
            continue
        if arg == "--":
            stop = True
            i += 1
            continue
        if arg in ("-h", "--help"):
            sys.stdout.write(LONG_HELP if arg == "--help" else SHORT_HELP)
            if not (LONG_HELP if arg == "--help" else SHORT_HELP).endswith("\n"):
                sys.stdout.write("\n")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg in ("-L", "--list-languages"):
            sys.stdout.write(LANGUAGES)
            raise SystemExit(0)
        if arg == "--list-themes":
            sys.stdout.write(THEMES)
            raise SystemExit(0)
        if arg in ("cache", "config"):
            handle_command(arg, argv[i + 1:])
            raise SystemExit(0)
        if arg == "--diagnostic":
            diagnostic(argv)
            raise SystemExit(0)
        if arg == "--acknowledgements":
            acknowledgements()
            raise SystemExit(0)
        if arg.startswith("--completion="):
            completion(arg.split("=", 1)[1])
            raise SystemExit(0)
        if arg == "--completion":
            shell = argv[i + 1] if i + 1 < len(argv) else ""
            completion(shell)
            raise SystemExit(0)
        if arg.startswith("--") and "=" in arg:
            key, val = arg.split("=", 1)
            apply_option(opts, key, val)
            i += 1
            continue
        if arg in TAKES_VALUE:
            if i + 1 >= len(argv):
                sys.stderr.write(f"error: a value is required for '{arg}' but none was supplied\n")
                raise SystemExit(2)
            apply_option(opts, arg, argv[i + 1])
            i += 2
            continue
        if arg in ("--show-all",):
            opts.show_all = True
            i += 1
            continue
        if arg in ("--plain",):
            opts.plain += 1
            i += 1
            continue
        if arg in ("--number",):
            opts.number = True
            i += 1
            continue
        if arg in ("--squeeze-blank",):
            opts.squeeze = True
            i += 1
            continue
        if arg in ("--quiet-empty",):
            opts.quiet_empty = True
            i += 1
            continue
        if arg in ("--unbuffered",):
            opts.unbuffered = True
            i += 1
            continue
        if arg in ("--diff", "--set-terminal-title"):
            i += 1
            continue
        if arg in ("--chop-long-lines",):
            opts.wrap = "never"
            i += 1
            continue
        if arg in ("--force-colorization",):
            opts.decorations = "always"
            opts.color = "always"
            i += 1
            continue
        if arg.startswith("-") and arg != "-":
            if set(arg[1:]) <= {"p"}:
                opts.plain += len(arg) - 1
            elif arg in ("-A",):
                opts.show_all = True
            elif arg == "-n":
                opts.number = True
            elif arg == "-s":
                opts.squeeze = True
            elif arg == "-u":
                opts.unbuffered = True
            elif arg == "-E":
                opts.quiet_empty = True
            elif arg == "-d":
                pass
            elif arg == "-S":
                opts.wrap = "never"
            elif arg == "-f":
                opts.decorations = "always"
                opts.color = "always"
            elif arg == "-P":
                pass
            else:
                raise SystemExit(print_usage_error(arg))
            i += 1
            continue
        opts.files.append(arg)
        i += 1
    return opts


def apply_option(opts, key, val):
    if key in ("--line-range", "-r"):
        opts.line_ranges.append(val)
    elif key in ("--tabs",):
        try:
            opts.tabs = max(0, int(val))
        except ValueError:
            opts.tabs = 4
    elif key == "--style":
        opts.style = val
    elif key == "--decorations":
        opts.decorations = val
    elif key == "--color":
        opts.color = val
    elif key == "--file-name":
        opts.file_name = val
    elif key == "--nonprintable-notation":
        opts.notation = val
    elif key == "--binary":
        opts.binary = val
    elif key == "--squeeze-limit":
        try:
            opts.squeeze_limit = int(val)
        except ValueError:
            opts.squeeze_limit = None
    elif key == "--strip-ansi":
        opts.strip_ansi = val
    elif key == "--wrap":
        opts.wrap = val
    elif key == "--terminal-width":
        opts.terminal_width = val
    elif key in ("--language", "-l", "--fallback-syntax", "--fallback-language",
                 "--highlight-line", "-H", "--diff-context", "--paging", "--pager",
                 "--map-syntax", "-m", "--theme", "--theme-light", "--theme-dark",
                 "--italic-text", "--ignored-suffix"):
        pass
    else:
        raise SystemExit(print_usage_error(key))


def handle_command(cmd, rest):
    if "--help" in rest or "-h" in rest:
        if cmd == "cache":
            print("""Modify the syntax-definition and theme cache

Usage: executable cache [OPTIONS]

Options:
  -h, --help
          Print help

  -b, --build
          Initialize (or update) the syntax/theme cache by loading from the source directory
          (default: the configuration directory).

  -c, --clear
          Remove the cached syntax definitions and themes.

      --source <dir>
          Use a different directory to load syntaxes and themes from.

      --target <dir>
          Use a different directory to store the cached syntax and theme set.

      --blank
          Create completely new syntax and theme sets (instead of appending to the default sets).

      --acknowledgements
          Build acknowledgements.bin.""")
        else:
            sys.stdout.write(LONG_HELP)
        return
    if cmd == "cache":
        print("bat: cache operations are not available in this reimplementation")
    else:
        sys.stdout.write(LONG_HELP)


def completion(shell):
    if shell == "bash":
        print("_bat() { COMPREPLY=( $(compgen -f -- \"${COMP_WORDS[COMP_CWORD]}\") ); }\ncomplete -F _bat bat executable")
    elif shell == "fish":
        print("complete -c bat -f")
    elif shell == "zsh":
        print("#compdef bat\n_arguments '*:file:_files'")
    elif shell == "ps1":
        print("using namespace System.Management.Automation")
    else:
        sys.stderr.write("error: invalid value for '--completion <SHELL>'\n")
        raise SystemExit(2)


def diagnostic(argv):
    print(f"""#### Software version

{VERSION}

#### Operating system

- OS: Linux (Ubuntu 22.04)

#### Command-line

```bash
{' '.join(['./executable'] + argv)} 
```

#### Environment variables

```bash
BAT_CACHE_PATH={os.environ.get('BAT_CACHE_PATH', '<not set>')}
BAT_CONFIG_PATH={os.environ.get('BAT_CONFIG_PATH', '<not set>')}
BAT_OPTS={os.environ.get('BAT_OPTS', '<not set>')}
BAT_PAGER={os.environ.get('BAT_PAGER', '<not set>')}
BAT_PAGING={os.environ.get('BAT_PAGING', '<not set>')}
BAT_STYLE={os.environ.get('BAT_STYLE', '<not set>')}
BAT_TABS={os.environ.get('BAT_TABS', '<not set>')}
BAT_THEME={os.environ.get('BAT_THEME', '<not set>')}
BAT_WIDTH={os.environ.get('BAT_WIDTH', '<not set>')}
```

#### Config file

Could not read contents of '/home/agent/.config/bat/config': No such file or directory (os error 2).
""")


def acknowledgements():
    print("""Copyright (c) 2018-2021 bat-developers (https://github.com/sharkdp/bat).

bat is made available under the terms of either the MIT License or the Apache
License 2.0, at your option.
""")


def decode_bytes(data):
    return data.decode("utf-8", errors="surrogateescape")


def strip_ansi_text(s):
    return re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", s)


def split_lines_preserve(text):
    if text == "":
        return []
    return text.splitlines(True)


def parse_line_range(spec, total):
    if "::" in spec:
        center, ctx = spec.split("::", 1)
        try:
            c, n = int(center), int(ctx)
            return max(1, c - n), min(total, c + n)
        except ValueError:
            return 1, total
    parts = spec.split(":")
    if len(parts) == 3:
        try:
            start = int(parts[0]) if parts[0] else 1
            end = int(parts[1]) if parts[1] else total
            ctx = int(parts[2])
            return max(1, start - ctx), min(total, end + ctx)
        except ValueError:
            return 1, total
    if len(parts) == 1:
        try:
            n = int(parts[0])
            return n, n
        except ValueError:
            return 1, total
    left, right = parts[0], parts[1]
    try:
        if left.startswith("-") and right == "":
            n = abs(int(left))
            return max(1, total - n + 1), total
        start = int(left) if left else 1
        if right.startswith("+"):
            end = start + int(right[1:])
        else:
            end = int(right) if right else total
        return max(1, start), min(total, end)
    except ValueError:
        return 1, total


def apply_ranges(lines, specs):
    if not specs:
        return lines
    total = len(lines)
    keep = set()
    for spec in specs:
        a, b = parse_line_range(spec, total)
        for n in range(a, b + 1):
            if 1 <= n <= total:
                keep.add(n)
    return [line for idx, line in enumerate(lines, 1) if idx in keep]


def squeeze_lines(lines, limit):
    max_blank = 1 if limit is None else max(0, limit)
    out = []
    blanks = 0
    for line in lines:
        if line.strip("\r\n") == "":
            blanks += 1
            if blanks <= max_blank:
                out.append(line)
        else:
            blanks = 0
            out.append(line)
    return out


UNICODE_CTRL = {
    "\n": "␊\n", "\r": "␍", "\t": None, "\0": "␀",
}


def caret_char(ch):
    o = ord(ch)
    if ch == "\n":
        return "$\n"
    if ch == "\t":
        return "^I"
    if o == 0:
        return "^@"
    if o < 32:
        return "^" + chr(o + 64)
    if o == 127:
        return "^?"
    return ch


def show_all_text(line, opts):
    if opts.notation == "caret":
        return "".join(caret_char(c) for c in line)
    out = []
    col = 0
    for ch in line:
        if ch == " ":
            out.append("·")
            col += 1
        elif ch == "\t":
            if opts.tabs == 0:
                out.append("\t")
            else:
                width = opts.tabs - (col % opts.tabs)
                out.append("├" + ("─" * max(0, width - 2)) + "┤")
                col += width
        elif ch == "\n":
            out.append("␊\n")
            col = 0
        elif ch == "\r":
            out.append("␍")
        elif ord(ch) < 32 or ord(ch) == 127:
            out.append(UNICODE_CTRL.get(ch, f"␦"))
            col += 1
        else:
            out.append(ch)
            col += 1
    return "".join(out)


def expand_tabs(line, opts):
    if opts.tabs == 0:
        return line
    return line.expandtabs(opts.tabs)


def colorize_error(msg):
    if sys.stderr.isatty():
        return f"\033[31m[bat error]\033[0m: {msg}\n"
    return f"\033[31m[bat error]\033[0m: {msg}\n"


def read_input(name):
    if name == "-":
        return sys.stdin.buffer.read(), None
    try:
        with open(name, "rb") as f:
            return f.read(), None
    except OSError as e:
        return None, e


def file_size(path):
    try:
        n = os.path.getsize(path)
    except OSError:
        return None
    if n < 1000:
        return f"{n} B"
    if n < 1000 * 1000:
        return f"{n / 1000:.1f} KB"
    return f"{n / 1000000:.1f} MB"


def should_decorate(opts):
    if opts.plain:
        return False
    if opts.style == "plain":
        return False
    if opts.number:
        return True
    if opts.decorations == "always":
        return True
    return False


def style_components(opts):
    if opts.number:
        return {"numbers"}
    style = opts.style or os.environ.get("BAT_STYLE", "")
    if not style and opts.decorations == "always":
        return {"numbers", "grid", "header-filename", "changes", "snip"}
    if not style or style in ("auto", "plain"):
        return set()
    if style == "default":
        return {"numbers", "grid", "header-filename", "changes", "snip"}
    if style == "full":
        return {"numbers", "grid", "header-filename", "header-filesize", "rule", "changes", "snip"}
    comps = set()
    for part in style.split(","):
        part = part.strip()
        if part == "header":
            part = "header-filename"
        if part:
            comps.add(part)
    return comps


def emit_decorated(lines, display_name, opts, original_path=None):
    comps = style_components(opts)
    if not comps and not opts.number:
        for line in lines:
            sys.stdout.write(line)
        return
    numbers = "numbers" in comps or opts.number
    grid = "grid" in comps
    width = max(4, len(str(len(lines)))) if (grid or numbers) else max(1, len(str(len(lines))))
    rule = "─────" + ("┬" if "header-filename" in comps or "rule" in comps else "─") + "─" * 74
    if grid and ("header-filename" in comps or "rule" in comps):
        print(rule)
    if "header-filename" in comps and display_name:
        print(f"{'':>{width+1}}│ File: {display_name}" if grid else f"File: {display_name}")
    if "header-filesize" in comps and original_path and original_path != "-":
        sz = file_size(original_path)
        if sz:
            print(f"{'':>{width+1}}│ Size: {sz}" if grid else f"Size: {sz}")
    if grid and ("header-filename" in comps or "rule" in comps):
        print("─────" + "┼" + "─" * 74)
    for idx, line in enumerate(lines, 1):
        if numbers:
            prefix = f"{idx:>{width}} "
            if grid:
                prefix += "│ "
            sys.stdout.write(prefix + line)
            if not line.endswith("\n"):
                sys.stdout.write("\n")
        else:
            sys.stdout.write(line)
    if grid and ("rule" in comps or "header-filename" in comps):
        print("─────" + "┴" + "─" * 74)


def process_one(name, opts):
    data, err = read_input(name)
    if err:
        sys.stderr.write(colorize_error(f"'{name}': {err.strerror} (os error {err.errno})"))
        return 1
    if opts.quiet_empty and data == b"":
        return 0
    text = decode_bytes(data)
    if opts.strip_ansi == "always":
        text = strip_ansi_text(text)
    lines = split_lines_preserve(text)
    lines = apply_ranges(lines, opts.line_ranges)
    if opts.squeeze or opts.squeeze_limit is not None:
        lines = squeeze_lines(lines, opts.squeeze_limit)
    if opts.show_all:
        lines = [show_all_text(line, opts) for line in lines]
    elif should_decorate(opts):
        lines = [expand_tabs(line, opts) for line in lines]
    display = opts.file_name if opts.file_name else (None if name == "-" else name)
    if should_decorate(opts):
        emit_decorated(lines, display, opts, name)
    else:
        for line in lines:
            sys.stdout.write(line)
    return 0


def main(argv):
    bat_opts = os.environ.get("BAT_OPTS")
    if bat_opts:
        argv = bat_opts.split() + argv
    opts = parse_args(argv)
    if not opts.files:
        opts.files = ["-"]
    rc = 0
    for name in opts.files:
        rc = max(rc, process_one(name, opts))
    return rc


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
