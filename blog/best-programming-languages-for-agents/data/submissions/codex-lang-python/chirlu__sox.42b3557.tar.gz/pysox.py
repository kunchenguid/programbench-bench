#!/usr/bin/env python3
import sys, os, wave, aifc, sunau, math, struct, audioop, shutil
from dataclasses import dataclass

VERSION = "SoX v14.4.2"
EFFECTS = {"allpass","band","bandpass","bandreject","bass","bend","biquad","chorus","channels","compand","contrast","dcshift","deemph","delay","dither","divide","downsample","earwax","echo","echos","equalizer","fade","fir","firfit","flanger","gain","highpass","hilbert","ladspa","loudness","lowpass","mcompand","noiseprof","noisered","norm","oops","overdrive","pad","phaser","pitch","rate","remix","repeat","reverb","reverse","riaa","silence","sinc","speed","splice","stat","stats","stretch","swap","synth","tempo","treble","tremolo","trim","upsample","vad","vol"}
HELP = """{prog}:      {ver}

Usage summary: [gopts] [[fopts] infile]... [fopts] outfile [effect [effopt]]...

SPECIAL FILENAMES (infile, outfile):
-                        Pipe/redirect input/output (stdin/stdout); may need -t
-d, --default-device     Use the default audio device (where available)
-n, --null               Use the `null' file handler; e.g. with synth effect
-p, --sox-pipe           Alias for `-t sox -'

GLOBAL OPTIONS (gopts) (can be specified at any point before the first effect):
--buffer BYTES           Set the size of all processing buffers (default 8192)
--clobber                Don't prompt to overwrite output file (default)
--combine concatenate    Concatenate all input files (default for sox, rec)
-D, --no-dither          Don't dither automatically
-G, --guard              Use temporary files to guard against clipping
-h, --help               Display version number and usage information
--help-effect NAME       Show usage of effect NAME, or NAME=all for all
--help-format NAME       Show info on format NAME, or NAME=all for all
--i, --info              Behave as soxi(1)
-m, --combine mix        Mix multiple input files (instead of concatenating)
-M, --combine merge      Merge multiple input files (instead of concatenating)
--norm                   Guard (see --guard) & normalise
-q, --no-show-progress   Run in quiet mode; opposite of -S
--version                Display version number of SoX and exit
-V[LEVEL]                Increment or set verbosity level (default 2)
FORMAT OPTIONS (fopts):
-v|--volume FACTOR       Input file volume adjustment factor (real number)
-t|--type FILETYPE       File type of audio
-e|--encoding ENCODING   Set encoding
-b|--bits BITS           Encoded sample size in bits
-c|--channels CHANNELS   Number of channels of audio data; e.g. 2 = stereo
-r|--rate RATE           Sample rate of audio
-C|--compression FACTOR  Compression factor for output format

AUDIO FILE FORMATS: aif aiff au f32 f64 raw s16 s8 u8 wav wavpcm
EFFECTS: channels fade gain norm rate repeat reverse speed stat stats synth trim vol
  * Deprecated effect    + Experimental effect    # LibSoX-only effect
"""
HELP_EFFECT = {
 "trim":"trim {position}",
 "channels":"channels number",
 "rate":"rate [-q|-l|-m|-h|-v] [override-options] RATE[k]",
 "vol":"vol GAIN [TYPE [LIMITERGAIN]]\n\t(default TYPE=amplitude: 1 is constant, < 0 change phase;\n\tTYPE=power 1 is constant; TYPE=dB: 0 is constant, +6 doubles ampl.)",
 "gain":"gain [-e|-b|-B|-r] [-n] [-l|-h] [gain-dB]",
 "synth":"synth [-j KEY] [-n] [length [offset [phase [p1 [p2 [p3]]]]]]] {type [combine] [[%]freq[k][:|+|/|-[%]freq2[k]] [offset [phase [p1 [p2 [p3]]]]]]}",
 "fade":"fade [ type ] fade-in-length [ stop-time [ fade-out-length ] ]",
 "stat":"stat [ -s N ] [ -rms ] [-freq] [ -v ] [ -d ]",
 "stats":"stats [ -b bits|-x bits|-s scale ]",
 "reverse":"reverse",
 "repeat":"repeat count",
 "speed":"speed factor[c]",
 "norm":"norm [level]",
}
@dataclass
class Audio:
    rate:int=8000; channels:int=1; bits:int=16; samples:list=None; encoding:str="Signed Integer PCM"
    def frames(self): return 0 if not self.samples else len(self.samples)//max(1,self.channels)

def prog(): return os.path.basename(sys.argv[0]) or "sox"
def die(msg, code=2): print(f"{prog()} FAIL {msg}", file=sys.stderr); sys.exit(code)
def parse_rate(s):
    s=str(s).lower(); mult=1000 if s.endswith('k') else 1
    if s.endswith('k'): s=s[:-1]
    return int(float(s)*mult+0.5)
def parse_time(s, rate):
    if s is None: return 0
    s=str(s)
    if ':' in s:
        parts=[float(p) for p in s.split(':')]
        sec=0
        for p in parts: sec=sec*60+p
        return int(sec*rate+0.5)
    if s.endswith('s'): s=s[:-1]
    return int(float(s)*rate+0.5)
def fmt_dur(frames, rate):
    sec = frames/float(rate) if rate else 0
    h=int(sec//3600); m=int((sec%3600)//60); ss=sec-h*3600-m*60
    return f"{h:02d}:{m:02d}:{ss:05.2f}"
def human_size(n):
    if n < 10000: return str(n)
    for suf in ['k','M','G']:
        n/=1000.0
        if abs(n)<1000: return f"{n:.3g}{suf}"
    return f"{n:.3g}T"
def bitrate(path, a):
    try: size=os.path.getsize(path)
    except Exception: return "0"
    dur=a.frames()/a.rate if a.rate else 0
    if dur<=0: return "0"
    bps=size*8/dur
    return f"{bps/1000:.3g}k" if bps>=1000 else f"{bps:.3g}"
def ext_type(path, forced=None):
    if forced: return forced.lower()
    e=os.path.splitext(path)[1].lower().lstrip('.')
    return {'aif':'aiff','aifc':'aiff','wavpcm':'wav'}.get(e,e or 'raw')

def bytes_to_samples(data, width, channels, unsigned8=False, endian='little'):
    if width==1:
        vals=[(b-128)/128.0 if unsigned8 else struct.unpack('b', bytes([b]))[0]/128.0 for b in data]
    elif width==2:
        fmt=('<' if endian=='little' else '>')+'h'; vals=[struct.unpack(fmt,data[i:i+2])[0]/32768.0 for i in range(0,len(data)-1,2)]
    elif width==3:
        vals=[]
        for i in range(0,len(data)-2,3):
            b=data[i:i+3] if endian=='little' else data[i:i+3][::-1]
            x=int.from_bytes(b+(b'\xff' if b[2]&0x80 else b'\x00'),'little',signed=True); vals.append(x/8388608.0)
    elif width==4:
        fmt=('<' if endian=='little' else '>')+'i'; vals=[struct.unpack(fmt,data[i:i+4])[0]/2147483648.0 for i in range(0,len(data)-3,4)]
    else: vals=[]
    return vals

def samples_to_bytes(samples, bits):
    out=bytearray(); width=max(1,(bits+7)//8)
    for x in samples:
        if x>1: x=1
        if x<-1: x=-1
        if bits==8:
            out.append(max(0,min(255,int(round(x*127+128)))))
        elif bits==16:
            out += struct.pack('<h', max(-32768,min(32767,int(round(x*32767)))))
        elif bits==24:
            v=max(-8388608,min(8388607,int(round(x*8388607)))); out += int(v).to_bytes(3,'little',signed=True)
        else:
            v=max(-2147483648,min(2147483647,int(round(x*2147483647)))); out += struct.pack('<i',v)
    return bytes(out)

def read_audio(path, opts):
    typ=ext_type(path, opts.get('type'))
    if path=='-': data=sys.stdin.buffer.read(); typ=opts.get('type','raw')
    if path!='-' and not os.path.exists(path): die(f"formats: can't open input file `{path}': No such file or directory", 1 if opts.get('soxi') else 2)
    try:
        if typ in ('wav','wave'):
            with wave.open(path,'rb') as w:
                ch=w.getnchannels(); rate=w.getframerate(); width=w.getsampwidth(); frames=w.getnframes(); data=w.readframes(frames)
            return Audio(rate,ch,width*8,bytes_to_samples(data,width,ch,unsigned8=(width==1)), 'Unsigned Integer PCM' if width==1 else 'Signed Integer PCM')
        if typ in ('aiff','aif','aifc'):
            with aifc.open(path,'rb') as f:
                ch=f.getnchannels(); rate=f.getframerate(); width=f.getsampwidth(); frames=f.getnframes(); data=f.readframes(frames)
            return Audio(rate,ch,width*8,bytes_to_samples(data,width,ch,endian='big'),'Signed Integer PCM')
        if typ in ('au','snd'):
            with sunau.open(path,'rb') as f:
                ch=f.getnchannels(); rate=f.getframerate(); width=f.getsampwidth(); frames=f.getnframes(); data=f.readframes(frames)
            return Audio(rate,ch,width*8,bytes_to_samples(data,width,ch),'Signed Integer PCM')
        if path!='-': data=open(path,'rb').read()
        rate=int(opts.get('rate') or 8000); ch=int(opts.get('channels') or 1); bits=int(opts.get('bits') or 16); enc=opts.get('encoding','signed-integer')
        return Audio(rate,ch,bits,bytes_to_samples(data,max(1,(bits+7)//8),ch,unsigned8=enc.startswith('unsigned') or bits==8 and typ.startswith('u')),'Unsigned Integer PCM' if enc.startswith('unsigned') or typ.startswith('u') else 'Signed Integer PCM')
    except Exception as e:
        die(f"formats: can't open input file `{path}': {e}", 1 if opts.get('soxi') else 2)

def write_wav(path,a):
    bits=int(a.bits or 16); ch=int(a.channels or 1); rate=int(a.rate or 8000)
    data=samples_to_bytes(a.samples or [], bits)
    if path=='-':
        f=sys.stdout.buffer; close=False
    else:
        f=open(path,'wb'); close=True
    try:
        with wave.open(f,'wb') as w:
            w.setnchannels(ch); w.setsampwidth(max(1,(bits+7)//8)); w.setframerate(rate); w.writeframes(data)
    finally:
        if close: f.close()

def write_raw(path,a):
    data=samples_to_bytes(a.samples or [], int(a.bits or 16))
    (sys.stdout.buffer if path=='-' else open(path,'wb')).write(data)

def write_audio(path,a,opts):
    typ=ext_type(path, opts.get('type'))
    a.bits=int(opts.get('bits') or a.bits or 16); a.rate=int(opts.get('rate') or a.rate or 8000); a.channels=int(opts.get('channels') or a.channels or 1)
    if typ in ('raw','s16','s8','u8') or path=='-' and opts.get('type')=='raw': write_raw(path,a)
    else: write_wav(path,a)

def convert_channels(a,n):
    n=int(n); old=a.channels
    if n==old: return a
    frames=a.frames(); out=[]
    for i in range(frames):
        fr=a.samples[i*old:(i+1)*old]
        if n==1: out.append(sum(fr)/len(fr) if fr else 0)
        else:
            for c in range(n): out.append(fr[c] if c<len(fr) else (fr[0] if fr else 0))
    a.channels=n; a.samples=out; return a

def resample(a,newrate):
    newrate=parse_rate(newrate); old=a.rate
    if newrate==old or a.frames()==0: a.rate=newrate; return a
    frames=a.frames(); newframes=max(1,int(round(frames*newrate/old))); out=[]; ch=a.channels
    for i in range(newframes):
        pos=i*old/newrate; j=int(pos); frac=pos-j
        if j>=frames-1: j=frames-1; frac=0
        for c in range(ch):
            x=a.samples[j*ch+c]; y=a.samples[min(j+1,frames-1)*ch+c]
            out.append(x*(1-frac)+y*frac)
    a.samples=out; a.rate=newrate; return a

def synth_audio(opts, args):
    rate=int(opts.get('rate') or 8000); ch=int(opts.get('channels') or 1); bits=int(opts.get('bits') or 16)
    dur=1.0; idx=0
    if args and not args[0].isalpha() and not args[0].startswith('-'):
        try: dur=float(args[0]); idx=1
        except Exception: pass
    waves=[]
    while idx < len(args):
        typ=args[idx].lower(); idx+=1
        if typ in ('sine','sin','square','triangle','tri','sawtooth','saw','noise','pinknoise','brownnoise','pluck'):
            if idx < len(args) and args[idx] not in EFFECTS:
                f=args[idx]; idx+=1
            else: f='440'
            try: freq=float(str(f).rstrip('k'))*(1000 if str(f).endswith('k') else 1)
            except Exception: freq=440.0
            waves.append((typ,freq))
        else:
            break
    if not waves: waves=[('sine',440.0)]
    frames=max(0,int(round(dur*rate))); samples=[]
    for i in range(frames):
        t=i/rate; val=0.0
        for typ,freq in waves:
            ph=(t*freq)%1.0
            if typ in ('sine','sin'): v=math.sin(2*math.pi*freq*t)
            elif typ=='square': v=1.0 if ph<0.5 else -1.0
            elif typ in ('triangle','tri'): v=4*abs(ph-0.5)-1
            elif typ in ('sawtooth','saw'): v=2*ph-1
            else: v=0.0
            val += v
        val=0.705*val/len(waves)
        for _ in range(ch): samples.append(val)
    return Audio(rate,ch,bits,samples,'Signed Integer PCM')

def amplify(a, factor): a.samples=[max(-1,min(1,x*factor)) for x in a.samples]; return a
def normalize(a, level=0.0):
    peak=max([abs(x) for x in (a.samples or [0])]) or 0
    target=10**(float(level)/20.0) if level is not None else 1.0
    if peak>0: amplify(a,target/peak)
    return a

def apply_effects(a,effects,out_opts):
    i=0
    while i < len(effects):
        e=effects[i].lower(); i+=1
        if e==':': continue
        if e=='channels' and i<len(effects): a=convert_channels(a,int(effects[i])); i+=1
        elif e=='rate':
            while i<len(effects) and effects[i].startswith('-'): i+=1
            if i<len(effects): a=resample(a,effects[i]); i+=1
        elif e=='speed' and i<len(effects):
            fac=float(str(effects[i]).rstrip('c')); i+=1; a=resample(a, int(a.rate/fac)); a.rate=out_opts.get('rate', a.rate)
        elif e=='trim':
            start=parse_time(effects[i] if i<len(effects) else '0', a.rate); i+=1
            dur=None
            if i<len(effects) and effects[i] not in EFFECTS: dur=parse_time(effects[i], a.rate); i+=1
            ch=a.channels; s=start*ch; end=len(a.samples) if dur is None else s+dur*ch; a.samples=a.samples[max(0,s):max(0,end)]
        elif e=='reverse':
            ch=a.channels; frames=[a.samples[j:j+ch] for j in range(0,len(a.samples),ch)]; a.samples=[x for fr in reversed(frames) for x in fr]
        elif e=='repeat' and i<len(effects):
            n=int(float(effects[i])); i+=1; a.samples=a.samples*(n+1)
        elif e=='vol' and i<len(effects):
            gain=float(effects[i]); i+=1
            if i<len(effects) and effects[i].lower()=='db': gain=10**(gain/20.0); i+=1
            a=amplify(a,gain)
        elif e=='gain':
            norm=False; db=0.0
            while i<len(effects) and (effects[i].startswith('-') or effects[i] not in EFFECTS):
                if effects[i]=='-n': norm=True
                else:
                    try: db=float(effects[i])
                    except Exception: pass
                i+=1
                if i<len(effects) and effects[i] in EFFECTS: break
            if norm: normalize(a,db)
            elif db: amplify(a,10**(db/20.0))
        elif e=='norm':
            level=0.0
            if i<len(effects) and effects[i] not in EFFECTS:
                try: level=float(effects[i]); i+=1
                except Exception: pass
            normalize(a,level)
        elif e=='fade':
            typ='t'
            if i<len(effects) and effects[i].isalpha(): typ=effects[i]; i+=1
            fi=parse_time(effects[i] if i<len(effects) else '0', a.rate); i+=1
            stop=None; fo=0
            if i<len(effects) and effects[i] not in EFFECTS: stop=parse_time(effects[i], a.rate); i+=1
            if i<len(effects) and effects[i] not in EFFECTS: fo=parse_time(effects[i], a.rate); i+=1
            ch=a.channels; frames=a.frames()
            if stop is not None: a.samples=a.samples[:stop*ch]; frames=a.frames()
            for f in range(min(fi,frames)):
                fac=f/max(1,fi)
                for c in range(ch): a.samples[f*ch+c]*=fac
            if fo:
                for k in range(min(fo,frames)):
                    fac=(fo-k)/max(1,fo); f=frames-1-k
                    for c in range(ch): a.samples[f*ch+c]*=fac
        elif e in ('stat','stats'):
            print_stats(a, e)
        else:
            # skip likely option operands until next known effect
            while i<len(effects) and effects[i] not in EFFECTS: i+=1
    return a

def print_stats(a, name):
    vals=a.samples or [0.0]; n=len(vals); peak=max(vals); trough=min(vals); rms=math.sqrt(sum(x*x for x in vals)/n) if n else 0
    if name=='stat':
        sys.stderr.write(f"Samples read:          {a.frames()}\nLength (seconds):      {a.frames()/a.rate:.6f}\nScaled by:         2147483647.0\nMaximum amplitude:     {peak:.6f}\nMinimum amplitude:     {trough:.6f}\nMidline amplitude:     {(peak+trough)/2:.6f}\nMean    norm:          {sum(abs(x) for x in vals)/n:.6f}\nMean    amplitude:     {sum(vals)/n:.6f}\nRMS     amplitude:     {rms:.6f}\nMaximum delta:         0.000000\nMinimum delta:         0.000000\nMean    delta:         0.000000\nRMS     delta:         0.000000\nRough   frequency:            0\nVolume adjustment:        {(1/max(abs(peak),abs(trough))) if max(abs(peak),abs(trough)) else 1:.3f}\n")
    else:
        sys.stderr.write(f"DC offset   {sum(vals)/n:.6f}\nMin level   {trough:.6f}\nMax level   {peak:.6f}\nPk lev dB      {20*math.log10(max(abs(peak),abs(trough),1e-12)):.2f}\nRMS lev dB     {20*math.log10(max(rms,1e-12)):.2f}\n")

def soxi(args):
    opts=[]; files=[]; total=False
    for x in args:
        if x=='-T': total=True
        elif x.startswith('-') and x!='-': opts.extend(list(x[1:]))
        else: files.append(x)
    if not files: die('soxi: missing filename',1)
    mode=opts[-1] if opts else None
    total_samples=0; audios=[]
    for f in files:
        a=read_audio(f, {'soxi':True}); audios.append((f,a)); total_samples += a.frames()
    if mode and len(mode)==1:
        if total and mode in 'sDd':
            a=audios[0][1]; frames=total_samples
            if mode=='s': print(frames)
            elif mode=='d': print(fmt_dur(frames,a.rate))
            else: print(f"{frames/a.rate:.6f}")
            return
        for f,a in audios:
            if mode=='t': print(ext_type(f))
            elif mode=='r': print(a.rate)
            elif mode=='c': print(a.channels)
            elif mode=='s': print(a.frames())
            elif mode=='d': print(fmt_dur(a.frames(),a.rate))
            elif mode=='D': print(f"{a.frames()/a.rate:.6f}")
            elif mode=='b': print(a.bits)
            elif mode=='B': print(bitrate(f,a))
            elif mode=='p': print(a.bits)
            elif mode=='e': print(a.encoding)
            elif mode=='a': pass
        return
    for f,a in audios:
        print(f"\nInput File     : '{f}'")
        print(f"Channels       : {a.channels}")
        print(f"Sample Rate    : {a.rate}")
        print(f"Precision      : {a.bits}-bit")
        sectors=(a.frames()/a.rate*75.0) if a.rate else 0
        sectxt=f"~ {sectors:.3g} CDDA sectors" if abs(sectors-round(sectors))>1e-9 else f"= {int(round(sectors))} CDDA sectors"
        print(f"Duration       : {fmt_dur(a.frames(),a.rate)} = {a.frames()} samples {sectxt}")
        print(f"File Size      : {human_size(os.path.getsize(f)) if f!='-' and os.path.exists(f) else 0}")
        print(f"Bit Rate       : {bitrate(f,a)}")
        print(f"Sample Encoding: {a.bits}-bit {a.encoding}\n")

def split_effects(tokens):
    for idx,t in enumerate(tokens):
        if t.lower() in EFFECTS: return tokens[:idx], tokens[idx:]
    return tokens, []

def parse_main(args):
    combine='concatenate'; global_norm=False; files=[]; pending={}; i=0
    file_tokens,effects=split_effects(args)
    while i<len(file_tokens):
        t=file_tokens[i]
        if t in ('--i','--info'): return 'soxi', file_tokens[i+1:]+effects
        if t in ('-h','--help'): print(HELP.format(prog=prog(),ver=VERSION)); sys.exit(0)
        if t=='--version': print(f"{prog()}:      {VERSION}"); sys.exit(0)
        if t=='--help-effect':
            name=file_tokens[i+1] if i+1<len(file_tokens) else ''
            print(f"{prog()}:      {VERSION}\n\nEffect usage:\n")
            if name=='all':
                for k in sorted(HELP_EFFECT): print(HELP_EFFECT[k]+"\n")
            else: print(HELP_EFFECT.get(name, f"{name}\n")+"\n")
            sys.exit(0)
        if t=='--help-format':
            name=file_tokens[i+1] if i+1<len(file_tokens) else ''
            print(f"{prog()}:      {VERSION}\n\nFormat: {name}\nDescription: {'Microsoft audio format' if name in ('wav','wavpcm') else name.upper()+' format'}\nReads: yes\nWrites:\n  16-bit Signed Integer PCM (16-bit precision)\n  24-bit Signed Integer PCM (24-bit precision)\n  32-bit Signed Integer PCM (32-bit precision)\n   8-bit Unsigned Integer PCM (8-bit precision)")
            sys.exit(0)
        if t in ('-m','--combine'):
            combine='mix' if t=='-m' else (file_tokens[i+1] if i+1<len(file_tokens) else 'concatenate'); i += 1 if t=='-m' else 2; continue
        if t=='-M': combine='merge'; i+=1; continue
        if t=='--norm': global_norm=True; i+=1; continue
        if t in ('-q','-S','-G','-D','--no-dither','--clobber','--no-clobber','--show-progress','--no-show-progress','--guard') or t.startswith('-V'):
            i+=1; continue
        if t in ('-r','--rate'): pending['rate']=parse_rate(file_tokens[i+1]); i+=2; continue
        if t in ('-c','--channels'): pending['channels']=int(file_tokens[i+1]); i+=2; continue
        if t in ('-b','--bits'): pending['bits']=int(file_tokens[i+1]); i+=2; continue
        if t in ('-e','--encoding'): pending['encoding']=file_tokens[i+1]; i+=2; continue
        if t in ('-t','--type'): pending['type']=file_tokens[i+1]; i+=2; continue
        if t in ('-v','--volume'): pending['volume']=float(file_tokens[i+1]); i+=2; continue
        if t in ('-C','--compression','--buffer','--input-buffer','--temp','--play-rate-arg','--replay-gain','--comment','--add-comment','--comment-file','--effects-file','--plot','--dft-min'):
            i+=2; continue
        if t in ('-n','--null'): files.append(('null', dict(pending))); pending={}; i+=1; continue
        if t=='-p': pending['type']='sox'; files.append(('-',dict(pending))); pending={}; i+=1; continue
        files.append((t,dict(pending))); pending={}; i+=1
    return 'run',(files,effects,combine,global_norm,pending)

def combine_audios(audios, mode):
    if not audios: return Audio(samples=[])
    base=audios[0]
    for idx in range(1,len(audios)):
        if audios[idx].rate!=base.rate: audios[idx]=resample(audios[idx], base.rate)
        if audios[idx].channels!=base.channels: audios[idx]=convert_channels(audios[idx], base.channels)
    if mode=='mix':
        n=max(a.frames() for a in audios)*base.channels; out=[]
        for i in range(n): out.append(max(-1,min(1,sum((a.samples[i] if i<len(a.samples) else 0) for a in audios)/len(audios))))
        base.samples=out; return base
    if mode=='merge':
        frames=max(a.frames() for a in audios); out=[]; ch=sum(a.channels for a in audios)
        for f in range(frames):
            for a in audios:
                for c in range(a.channels): out.append(a.samples[f*a.channels+c] if f<a.frames() else 0)
        return Audio(base.rate,ch,base.bits,out,base.encoding)
    out=[]
    for a in audios: out.extend(a.samples)
    base.samples=out; return base

def main():
    args=sys.argv[1:]
    if prog().startswith('soxi') and args and not any(x in ('-h','--help','--version') for x in args):
        soxi(args); return
    if not args: die('sox: No input filenames specified')
    mode,data=parse_main(args)
    if mode=='soxi': soxi(data); return
    files,effects,combine,gnorm,out_pending=data
    if len(files)<2: die('sox: Not enough input filenames specified')
    out_path,out_opts=files[-1]; input_specs=files[:-1]
    audios=[]; null_opts={}
    for p,o in input_specs:
        if p=='null': null_opts=o; continue
        a=read_audio(p,o)
        if 'volume' in o: amplify(a,float(o['volume']))
        audios.append(a)
    if not audios and effects and effects[0]=='synth':
        opts={**null_opts, **out_opts, **out_pending}; a=synth_audio(opts,effects[1:]); effects=[]
    else:
        a=combine_audios(audios, combine)
    if out_opts.get('rate') and a.rate!=out_opts['rate']: a=resample(a,out_opts['rate'])
    if out_opts.get('channels') and a.channels!=out_opts['channels']: a=convert_channels(a,out_opts['channels'])
    if out_opts.get('bits'): a.bits=out_opts['bits']
    a=apply_effects(a,effects,out_opts)
    if gnorm: normalize(a,0.0)
    write_audio(out_path,a,out_opts)
if __name__=='__main__': main()
