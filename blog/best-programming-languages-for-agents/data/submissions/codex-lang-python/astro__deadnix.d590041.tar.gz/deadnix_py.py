#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path


VERSION = "deadnix 1.3.1"
IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_'-]*")
KEYWORDS = {
    "let", "in", "inherit", "rec", "with", "assert", "if", "then", "else",
    "true", "false", "null", "or",
}


@dataclass
class Finding:
    line: int
    column: int
    endColumn: int
    message: str
    decl_start: int
    decl_end: int
    stmt_start: int
    stmt_end: int

    def as_json(self):
        return {
            "column": self.column,
            "endColumn": self.endColumn,
            "line": self.line,
            "message": self.message,
        }


def mask_nix(src: str) -> str:
    out = list(src)
    i = 0
    n = len(src)
    while i < n:
        c = src[i]
        if c == "#":
            j = i
            while j < n and src[j] != "\n":
                if out[j] != "\n":
                    out[j] = " "
                j += 1
            i = j
        elif c == '"':
            out[i] = " "
            i += 1
            while i < n:
                if src[i] == "\\":
                    out[i] = " "
                    if i + 1 < n:
                        out[i + 1] = " "
                    i += 2
                elif src[i] == '"':
                    out[i] = " "
                    i += 1
                    break
                elif src[i] == "$" and i + 1 < n and src[i + 1] == "{":
                    out[i] = out[i + 1] = " "
                    i += 2
                    depth = 1
                    while i < n and depth:
                        if src[i] == "{":
                            depth += 1
                        elif src[i] == "}":
                            depth -= 1
                            out[i] = " "
                        elif src[i] == "#":
                            j = i
                            while j < n and src[j] != "\n":
                                out[j] = " "
                                j += 1
                            i = j
                            continue
                        i += 1
                else:
                    if out[i] != "\n":
                        out[i] = " "
                    i += 1
        elif c == "'" and i + 1 < n and src[i + 1] == "'":
            out[i] = out[i + 1] = " "
            i += 2
            while i < n:
                if src[i] == "'" and i + 1 < n and src[i + 1] == "'":
                    out[i] = out[i + 1] = " "
                    i += 2
                    break
                if src[i] == "$" and i + 1 < n and src[i + 1] == "{":
                    out[i] = out[i + 1] = " "
                    i += 2
                    depth = 1
                    while i < n and depth:
                        if src[i] == "{":
                            depth += 1
                        elif src[i] == "}":
                            depth -= 1
                            out[i] = " "
                        i += 1
                    continue
                if out[i] != "\n":
                    out[i] = " "
                i += 1
        else:
            i += 1
    return "".join(out)


def line_starts(src: str):
    starts = [0]
    for m in re.finditer("\n", src):
        starts.append(m.end())
    return starts


def loc(starts, pos):
    import bisect
    idx = bisect.bisect_right(starts, pos) - 1
    return idx + 1, pos - starts[idx] + 1


def index_line_col(src, line, col):
    starts = line_starts(src)
    if line - 1 >= len(starts):
        return len(src)
    return min(len(src), starts[line - 1] + col - 1)


def previous_line_has_skip(src, pos):
    start = src.rfind("\n", 0, pos)
    prev_end = start
    if prev_end <= 0:
        return False
    prev_start = src.rfind("\n", 0, prev_end - 1) + 1
    return "deadnix: skip" in src[prev_start:prev_end]


def find_stmt_end(clean, start):
    depth = 0
    i = start
    while i < len(clean):
        c = clean[i]
        if c in "({[":
            depth += 1
        elif c in ")}]":
            depth = max(0, depth - 1)
        elif c == ";" and depth == 0:
            return i + 1
        i += 1
    nl = clean.find("\n", start)
    return len(clean) if nl < 0 else nl


def find_stmt_start(clean, pos):
    j = clean.rfind(";", 0, pos)
    nl = clean.rfind("\n", 0, pos)
    return max(j + 1, nl + 1, 0)


def token_positions(clean, name):
    pat = re.compile(r"(?<![A-Za-z0-9_'-])" + re.escape(name) + r"(?![A-Za-z0-9_'-])")
    return [m.start() for m in pat.finditer(clean)]


def all_ident_positions(clean):
    d = {}
    for m in IDENT_RE.finditer(clean):
        s = m.group(0)
        if s not in KEYWORDS:
            d.setdefault(s, []).append(m.start())
    return d


@dataclass
class Decl:
    name: str
    start: int
    end: int
    stmt_start: int
    stmt_end: int
    kind: str
    alias: bool = False


def in_let_regions(clean):
    regions = []
    for m in re.finditer(r"(?<![A-Za-z0-9_'-])let(?![A-Za-z0-9_'-])", clean):
        i = m.end()
        depth = 0
        while i < len(clean):
            c = clean[i]
            if c in "({[":
                depth += 1
            elif c in ")}]":
                depth = max(0, depth - 1)
            elif depth == 0 and re.match(r"in(?![A-Za-z0-9_'-])", clean[i:]):
                regions.append((m.end(), i))
                break
            i += 1
    return regions


def collect_let_decls(src, clean):
    decls = []
    for a, b in in_let_regions(clean):
        region = clean[a:b]
        base = a
        for m in re.finditer(r"(?m)(^|[;\n])([ \t]*)([A-Za-z_][A-Za-z0-9_'-]*)(?:\s*\.[^=;\n]+)?\s*=", region):
            name = m.group(3)
            pos = base + m.start(3)
            if previous_line_has_skip(src, pos):
                continue
            stmt_start = base + m.start(0)
            if clean[stmt_start] in ";\n":
                stmt_start += 1
            decls.append(Decl(name, pos, pos + len(name), stmt_start, find_stmt_end(clean, stmt_start), "let binding"))
        for m in re.finditer(r"inherit\s*(?:\([^)]*\)\s*)?([^;]+);", region):
            stmt_start = base + m.start()
            if previous_line_has_skip(src, stmt_start):
                continue
            names_part = m.group(1)
            off = base + m.start(1)
            for im in IDENT_RE.finditer(names_part):
                name = im.group(0)
                if name in KEYWORDS:
                    continue
                pos = off + im.start()
                decls.append(Decl(name, pos, pos + len(name), stmt_start, base + m.end(), "let binding"))
    return decls


def split_top_commas(text):
    parts = []
    start = 0
    depth = 0
    for i, c in enumerate(text):
        if c in "({[":
            depth += 1
        elif c in ")}]":
            depth = max(0, depth - 1)
        elif c == "," and depth == 0:
            parts.append((start, i))
            start = i + 1
    parts.append((start, len(text)))
    return parts


def collect_lambda_decls(src, clean, check_arg=True, check_pattern=True):
    decls = []
    if check_pattern:
        pat = re.compile(r"(?:(?P<alias1>[A-Za-z_][A-Za-z0-9_'-]*)\s*@\s*)?\{(?P<body>[^{}]*)\}\s*(?:@\s*(?P<alias2>[A-Za-z_][A-Za-z0-9_'-]*))?\s*:")
        for m in pat.finditer(clean):
            stmt_start = m.start()
            if previous_line_has_skip(src, stmt_start):
                continue
            if m.group("alias1"):
                pos = m.start("alias1")
                decls.append(Decl(m.group("alias1"), pos, pos + len(m.group("alias1")), stmt_start, m.end(), "lambda pattern", True))
            if m.group("alias2"):
                pos = m.start("alias2")
                decls.append(Decl(m.group("alias2"), pos, pos + len(m.group("alias2")), stmt_start, m.end(), "lambda pattern", True))
            body_start = m.start("body")
            body = m.group("body")
            for a, z in split_top_commas(body):
                part = body[a:z]
                im = IDENT_RE.search(part)
                if im and im.group(0) != "...":
                    name = im.group(0)
                    pos = body_start + a + im.start()
                    decls.append(Decl(name, pos, pos + len(name), stmt_start, m.end(), "lambda pattern"))
    if check_arg:
        # Simple-name lambdas. Do not treat attr-pattern aliases or already underscored args as reportable.
        for m in re.finditer(r"(?<![@A-Za-z0-9_'-])([A-Za-z_][A-Za-z0-9_'-]*)\s*:", clean):
            name = m.group(1)
            if name in KEYWORDS or name.startswith("_"):
                continue
            prev = clean[max(0, m.start() - 2):m.start()]
            if "}" in prev:
                continue
            pos = m.start(1)
            # Skip attr names in attrsets: "x = y:" is a lambda arg, but "x: y" is valid.
            decls.append(Decl(name, pos, pos + len(name), find_stmt_start(clean, pos), m.end(), "lambda argument"))
    return decls


def is_used(decl, positions_by_name, same_name_decls):
    positions = positions_by_name.get(decl.name, [])
    next_same = min([d.start for d in same_name_decls if d.start > decl.start] or [len(positions_by_name) + 10**9])
    for p in positions:
        if decl.start <= p < decl.end:
            continue
        # References inside the left side of the same declaration don't count.
        if decl.stmt_start <= p < decl.stmt_end and decl.start <= p < decl.end + 2:
            continue
        if decl.alias and decl.stmt_start <= p < decl.start:
            return True
        if p > decl.start and p < next_same:
            return True
        if p < decl.start and decl.kind.startswith("lambda"):
            continue
    return False


def analyze_file(path, opts):
    try:
        src = Path(path).read_text()
    except Exception as e:
        print(f"Error: {path}: {e}", file=sys.stderr)
        return []
    clean = mask_nix(src)
    starts = line_starts(src)
    decls = []
    decls.extend(collect_let_decls(src, clean))
    decls.extend(collect_lambda_decls(src, clean, not opts.no_lambda_arg, not opts.no_lambda_pattern_names))
    positions = all_ident_positions(clean)
    by_name = {}
    for d in decls:
        by_name.setdefault(d.name, []).append(d)
    findings = []
    for d in sorted(decls, key=lambda x: x.start):
        if opts.no_underscore and d.name.startswith("_"):
            continue
        used = is_used(d, positions, by_name.get(d.name, []))
        if not used:
            line, col = loc(starts, d.start)
            findings.append(Finding(line, col, col + len(d.name), f"Unused {d.kind}: {d.name}", d.start, d.end, d.stmt_start, d.stmt_end))
        elif opts.warn_used_underscore and d.name.startswith("_") and d.kind == "let binding":
            line, col = loc(starts, d.start)
            findings.append(Finding(line, col, col + len(d.name), f"Used let binding: {d.name}", d.start, d.end, d.stmt_start, d.stmt_end))
    return findings


def human_report(path, findings):
    if not findings:
        return
    print("Warning: Unused declarations were found.")
    first = findings[0]
    print(f"    ╭─[{path}:{first.line}:{first.column}]")
    lines = Path(path).read_text().splitlines()
    for f in findings:
        line_text = lines[f.line - 1] if f.line - 1 < len(lines) else ""
        print(f"{f.line:3} │{line_text}")
        caret_pad = " " * max(0, f.column - 1)
        tail = "─" * max(3, min(17, f.endColumn - f.column + 2))
        print(f"    │{caret_pad}╰{tail} {f.message}")


def apply_edit(path, findings):
    if not findings:
        return
    p = Path(path)
    src = p.read_text()
    # Remove whole statements once; this matches common let bindings and inherit statements.
    ranges = []
    for f in findings:
        if f.message.startswith("Unused let binding"):
            a = f.stmt_start
            while a > 0 and src[a - 1] in " \t":
                a -= 1
            b = f.stmt_end
            if b < len(src) and src[b:b+1] == "\n":
                b += 1
            ranges.append((a, b))
    merged = []
    for a, b in sorted(ranges):
        if merged and a <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], b))
        else:
            merged.append((a, b))
    replacements = []
    for f in findings:
        if f.message.startswith("Unused lambda argument"):
            name = f.message.rsplit(": ", 1)[-1]
            if not name.startswith("_"):
                replacements.append((f.decl_start, f.decl_end, "_" + name))
    out = []
    last = 0
    edits = [(a, b, "") for a, b in merged] + replacements
    for a, b, repl in sorted(edits):
        if a < last:
            continue
        out.append(src[last:a])
        out.append(repl)
        last = b
    out.append(src[last:])
    p.write_text("".join(out))


def collect_paths(args):
    roots = args.file_paths or ["."]
    excludes = {os.path.abspath(x) for x in (args.excludes or [])}
    paths = []
    for r in roots:
        p = Path(r)
        if os.path.abspath(str(p)) in excludes:
            continue
        if p.is_file():
            if p.suffix == ".nix" and (args.hidden or not p.name.startswith(".")):
                paths.append(str(p))
        elif p.is_dir():
            for root, dirs, files in os.walk(p):
                if not args.hidden:
                    dirs[:] = [d for d in dirs if not d.startswith(".")]
                dirs[:] = [d for d in dirs if os.path.abspath(os.path.join(root, d)) not in excludes]
                for fn in files:
                    full = os.path.join(root, fn)
                    if os.path.abspath(full) in excludes:
                        continue
                    if fn.endswith(".nix") and (args.hidden or not fn.startswith(".")):
                        paths.append(full)
    return sorted(dict.fromkeys(paths))


class Parser(argparse.ArgumentParser):
    def error(self, message):
        print(f"error: {message}", file=sys.stderr)
        self.print_usage(sys.stderr)
        sys.exit(2)


def main(argv=None):
    parser = Parser(description="Find dead code in .nix files", add_help=False)
    parser.add_argument("-l", "--no-lambda-arg", action="store_true")
    parser.add_argument("-L", "--no-lambda-pattern-names", action="store_true")
    parser.add_argument("-_", "--no-underscore", action="store_true")
    parser.add_argument("-W", "--warn-used-underscore", action="store_true")
    parser.add_argument("-q", "--quiet", action="store_true")
    parser.add_argument("-e", "--edit", action="store_true")
    parser.add_argument("-h", "--hidden", action="store_true")
    parser.add_argument("--help", action="store_true")
    parser.add_argument("-f", "--fail", action="store_true")
    parser.add_argument("-o", "--output-format", choices=["human-readable", "json"], default="human-readable")
    parser.add_argument("--exclude", dest="excludes", nargs="+")
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("file_paths", nargs="*")
    args = parser.parse_args(argv)
    if args.help:
        print("""Find dead code in .nix files

Usage: executable [OPTIONS] [FILE_PATHS]...

Arguments:
  [FILE_PATHS]...  .nix files, or directories with .nix files inside [default: .]

Options:
  -l, --no-lambda-arg                  Don't check lambda parameter arguments
  -L, --no-lambda-pattern-names        Don't check lambda attrset pattern names (don't break nixpkgs callPackage)
  -_, --no-underscore                  Don't check any bindings that start with a _
  -W, --warn-used-underscore           Warn if bindings are referenced that start with '_'
  -q, --quiet                          Don't print dead code report
  -e, --edit                           Remove unused code and write to source file
  -h, --hidden                         Recurse into hidden subdirectories and process hidden .*.nix files
      --help
  -f, --fail                           Exit with 1 if unused code has been found
  -o, --output-format <OUTPUT_FORMAT>  Output format to use [default: human-readable] [possible values: human-readable, json]
      --exclude <EXCLUDES>...          Files to exclude from analysis
  -V, --version                        Print version""")
        return 0
    if args.version:
        print(VERSION)
        return 0
    all_results = []
    paths = collect_paths(args)
    for path in paths:
        findings = analyze_file(path, args)
        if findings:
            all_results.append((path, findings))
            if args.edit:
                apply_edit(path, findings)
            if not args.quiet:
                if args.output_format == "json":
                    print(json.dumps({"file": path, "results": [f.as_json() for f in findings]}, separators=(",", ":")))
                else:
                    human_report(path, findings)
    return 1 if args.fail and all_results else 0


if __name__ == "__main__":
    sys.exit(main())
