#!/usr/bin/env python3
import argparse
import copy
import json
import math
import os
import re
import sys


VERSION = "jq-build-2b77eb1"
HELP = """jq - commandline JSON processor [version build-2b77eb1]

Usage:\tjq [options] <jq filter> [file...]
\tjq [options] --args <jq filter> [strings...]
\tjq [options] --jsonargs <jq filter> [JSON_TEXTS...]

jq is a tool for processing JSON inputs, applying the given filter to
its JSON text inputs and producing the filter's results as JSON on
standard output.

Command options:
  -n, --null-input          use `null` as the single input value;
  -R, --raw-input           read each line as string instead of JSON;
  -s, --slurp               read all inputs into an array and use it as
                            the single input value;
  -c, --compact-output      compact instead of pretty-printed output;
  -r, --raw-output          output strings without escapes and quotes;
      --raw-output0         implies -r and output NUL after each output;
  -j, --join-output         implies -r and output without newline after
                            each output;
  -a, --ascii-output        output strings by only ASCII characters
                            using escape sequences;
  -S, --sort-keys           sort keys of each object on output;
  -C, --color-output        colorize JSON output;
  -M, --monochrome-output   disable colored output;
      --tab                 use tabs for indentation;
      --indent n            use n spaces for indentation (max 7 spaces);
  -f, --from-file           load the filter from a file;
  -L, --library-path dir    search modules from the directory;
      --arg name value      set $name to the string value;
      --argjson name value  set $name to the JSON value;
      --slurpfile name file set $name to an array of JSON values read
                            from the file;
      --rawfile name file   set $name to string contents of file;
      --args                consume remaining arguments as positional
                            string values;
      --jsonargs            consume remaining arguments as positional
                            JSON values;
  -e, --exit-status         set exit status code based on the output;
  -V, --version             show the version;
  --build-configuration     show jq's build configuration;
  -h, --help                show the help;
  --                        terminates argument processing;

Named arguments are also available as $ARGS.named[], while
positional arguments are available as $ARGS.positional[].
"""


class JQError(Exception):
    pass


def truthy(v):
    return not (v is False or v is None)


def jtype(v):
    if v is None:
        return "null"
    if v is True or v is False:
        return "boolean"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return "number"
    if isinstance(v, str):
        return "string"
    if isinstance(v, list):
        return "array"
    if isinstance(v, dict):
        return "object"
    return "unknown"


TOKEN_RE = re.compile(
    r"""\s*(?:
    (?P<num>-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)|
    (?P<str>"(?:\\.|[^"\\])*")|
    (?P<var>\$[A-Za-z_][A-Za-z0-9_]*)|
    (?P<op>//=|\|=|\+=|-=|\*=|/=|==|!=|<=|>=|//|\.\.|[.\[\]{}():,|?+\-*/=<>;])|
    (?P<id>[A-Za-z_][A-Za-z0-9_]*)
    )""",
    re.X,
)


class Lexer:
    def __init__(self, text):
        self.toks = []
        i = 0
        while i < len(text):
            m = TOKEN_RE.match(text, i)
            if not m:
                raise JQError(f"syntax error, unexpected {text[i:i+12]!r}")
            i = m.end()
            if m.lastgroup == "num":
                s = m.group("num")
                self.toks.append(("num", float(s) if any(c in s for c in ".eE") else int(s)))
            elif m.lastgroup == "str":
                val = decode_jq_string(m.group("str"))
                self.toks.append(("interp" if isinstance(val, list) else "str", val))
            elif m.lastgroup == "var":
                self.toks.append(("var", m.group("var")[1:]))
            elif m.lastgroup == "id":
                self.toks.append(("id", m.group("id")))
            else:
                self.toks.append((m.group("op"), m.group("op")))
        self.toks.append(("EOF", None))
        self.i = 0

    def peek(self):
        return self.toks[self.i][0]

    def val(self):
        return self.toks[self.i][1]

    def pop(self, typ=None):
        t = self.toks[self.i]
        if typ is not None and t[0] != typ:
            raise JQError(f"syntax error, expected {typ}, got {t[0]}")
        self.i += 1
        return t

    def eat(self, typ):
        if self.peek() == typ:
            return self.pop()
        return None


class Parser:
    def __init__(self, text):
        self.lx = Lexer(text)

    def parse(self):
        n = self.expr()
        self.lx.eat(";")
        if self.lx.peek() != "EOF":
            raise JQError(f"syntax error near {self.lx.peek()}")
        return n

    def expr(self):
        return self.comma()

    def comma(self):
        n = self.pipe()
        if self.lx.eat(","):
            parts = [n]
            while True:
                parts.append(self.pipe())
                if not self.lx.eat(","):
                    break
            return ("comma", parts)
        return n

    def pipe(self):
        n = self.asexpr()
        while self.lx.eat("|"):
            n = ("pipe", n, self.asexpr())
        return n

    def asexpr(self):
        n = self.alt()
        if self.lx.peek() in ("=", "|=", "+=", "-=", "*=", "/="):
            op = self.lx.pop()[0]
            return ("assign", op, n, self.expr())
        if self.lx.peek() == "id" and self.lx.val() == "as":
            self.lx.pop()
            name = self.lx.pop("var")[1]
            if self.lx.peek() == "id" and self.lx.val() == "as":
                raise JQError("nested as not supported")
            if not (self.lx.peek() == "id" and self.lx.val() == "|"):
                pass
            self.lx.pop("|")
            return ("as", n, name, self.asexpr())
        return n

    def alt(self):
        n = self.logic("or")
        while self.lx.eat("//"):
            n = ("bin", "//", n, self.logic("or"))
        return n

    def logic(self, opname):
        nextp = self.cmp if opname == "and" else (lambda: self.logic("and"))
        n = nextp()
        while self.lx.peek() == "id" and self.lx.val() == opname:
            self.lx.pop()
            n = ("bin", opname, n, nextp())
        return n

    def cmp(self):
        n = self.add()
        while self.lx.peek() in ("==", "!=", "<", ">", "<=", ">="):
            op = self.lx.pop()[0]
            n = ("bin", op, n, self.add())
        return n

    def add(self):
        n = self.mul()
        while self.lx.peek() in ("+", "-"):
            op = self.lx.pop()[0]
            n = ("bin", op, n, self.mul())
        return n

    def mul(self):
        n = self.unary()
        while self.lx.peek() in ("*", "/"):
            op = self.lx.pop()[0]
            n = ("bin", op, n, self.unary())
        return n

    def unary(self):
        if self.lx.eat("-"):
            return ("neg", self.unary())
        if self.lx.peek() == "id" and self.lx.val() == "not":
            self.lx.pop()
            return ("not", self.unary())
        return self.postfix(self.primary())

    def primary(self):
        p = self.lx.peek()
        if p == ".":
            self.lx.pop()
            if self.lx.peek() == "id":
                return ("field", ("id",), self.lx.pop()[1], self.lx.eat("?") is not None)
            return ("id",)
        if p == "..":
            self.lx.pop()
            return ("recurse", ("id",))
        if p == "num":
            return ("lit", self.lx.pop()[1])
        if p == "str":
            return ("lit", self.lx.pop()[1])
        if p == "interp":
            return ("interp", self.lx.pop()[1])
        if p == "var":
            return ("var", self.lx.pop()[1])
        if p == "(":
            self.lx.pop()
            n = self.expr()
            self.lx.pop(")")
            return n
        if p == "[":
            self.lx.pop()
            if self.lx.eat("]"):
                return ("lit", [])
            n = self.expr()
            self.lx.pop("]")
            return ("array", n)
        if p == "{":
            return self.object()
        if p == "id":
            name = self.lx.pop()[1]
            if name == "null":
                return ("lit", None)
            if name == "true":
                return ("lit", True)
            if name == "false":
                return ("lit", False)
            if name == "empty":
                return ("empty",)
            if name == "have_decnum":
                return ("lit", True)
            if name == "infinite":
                return ("lit", sys.float_info.max)
            if name == "nan":
                return ("lit", None)
            if name == "if":
                c = self.expr()
                self.expect_id("then")
                t = self.expr()
                self.expect_id("else")
                e = self.expr()
                self.expect_id("end")
                return ("if", c, t, e)
            if self.lx.eat("("):
                args = []
                if not self.lx.eat(")"):
                    while True:
                        args.append(self.expr())
                        if self.lx.eat(")"):
                            break
                        if not (self.lx.eat(";") or self.lx.eat(",")):
                            self.lx.pop(")")
                return ("call", name, args)
            return ("call", name, [])
        raise JQError(f"syntax error near {p}")

    def expect_id(self, s):
        if not (self.lx.peek() == "id" and self.lx.val() == s):
            raise JQError(f"syntax error, expected {s}")
        self.lx.pop()

    def object(self):
        self.lx.pop("{")
        pairs = []
        if self.lx.eat("}"):
            return ("object", pairs)
        while True:
            dyn = False
            if self.lx.peek() == "str":
                key = ("lit", self.lx.pop()[1])
            elif self.lx.peek() == "id":
                name = self.lx.pop()[1]
                key = ("lit", name)
                if self.lx.peek() not in (":", "}"):
                    val = ("field", ("id",), name, False)
                    pairs.append((key, val, False))
                    if self.lx.eat("}"):
                        break
                    self.lx.pop(",")
                    continue
            elif self.lx.peek() == "(":
                self.lx.pop()
                key = self.expr()
                self.lx.pop(")")
                dyn = True
            else:
                raise JQError("bad object key")
            if self.lx.eat(":"):
                val = self.expr()
            else:
                if key[0] == "lit" and isinstance(key[1], str):
                    val = ("field", ("id",), key[1], False)
                else:
                    val = ("id",)
            pairs.append((key, val, dyn))
            if self.lx.eat("}"):
                break
            self.lx.pop(",")
        return ("object", pairs)

    def postfix(self, n):
        while True:
            opt = False
            if self.lx.eat("."):
                if self.lx.peek() == "id":
                    n = ("field", n, self.lx.pop()[1], False)
                    if self.lx.eat("?"):
                        n = n[:-1] + (True,)
                elif self.lx.eat("["):
                    n = self.bracket(n)
                else:
                    n = ("recurse", n)
            elif self.lx.eat("["):
                n = self.bracket(n)
            elif self.lx.eat("?"):
                n = ("try", n)
            else:
                break
        return n

    def bracket(self, base):
        if self.lx.eat("]"):
            node = ("iter", base, False)
        elif self.lx.eat(":"):
            end = None if self.lx.peek() == "]" else self.expr()
            self.lx.pop("]")
            node = ("slice", base, None, end, False)
        else:
            start = self.expr()
            if self.lx.eat(":"):
                end = None if self.lx.peek() == "]" else self.expr()
                self.lx.pop("]")
                node = ("slice", base, start, end, False)
            else:
                self.lx.pop("]")
                node = ("index", base, start, False)
        if self.lx.eat("?"):
            node = node[:-1] + (True,)
        return node


def decode_jq_string(raw):
    inner = raw[1:-1]
    parts = []
    buf = []
    i = 0
    while i < len(inner):
        if inner.startswith("\\(", i):
            if buf:
                parts.append((False, json.loads('"' + "".join(buf) + '"')))
                buf = []
            i += 2
            start = i
            depth = 1
            in_str = False
            esc = False
            while i < len(inner):
                c = inner[i]
                if in_str:
                    if esc:
                        esc = False
                    elif c == "\\":
                        esc = True
                    elif c == '"':
                        in_str = False
                else:
                    if c == '"':
                        in_str = True
                    elif c == "(":
                        depth += 1
                    elif c == ")":
                        depth -= 1
                        if depth == 0:
                            break
                i += 1
            expr = inner[start:i]
            parts.append((True, Parser(expr).parse()))
            i += 1
        else:
            buf.append(inner[i])
            i += 1
    if not parts:
        return json.loads(raw)
    if buf:
        parts.append((False, json.loads('"' + "".join(buf) + '"')))
    return parts


def one(vals):
    return vals[0] if vals else None


class Evaluator:
    def __init__(self, vars=None):
        self.vars = vars or {}

    def ev(self, n, inp, env=None):
        env = env or {}
        k = n[0]
        try:
            if k == "id":
                return [inp]
            if k == "lit":
                return [n[1]]
            if k == "interp":
                outs = [""]
                for isexpr, part in n[1]:
                    if not isexpr:
                        outs = [s + part for s in outs]
                    else:
                        vals = self.ev(part, inp, env)
                        outs = [s + (v if isinstance(v, str) else dumps(v, True, False, None)) for s in outs for v in vals]
                return outs
            if k == "var":
                if n[1] == "ARGS":
                    return [self.vars.get("ARGS", {"named": {}, "positional": []})]
                return [env.get(n[1], self.vars.get(n[1]))]
            if k == "empty":
                return []
            if k == "comma":
                out = []
                for p in n[1]:
                    out.extend(self.ev(p, inp, env))
                return out
            if k == "pipe":
                out = []
                for v in self.ev(n[1], inp, env):
                    out.extend(self.ev(n[2], v, env))
                return out
            if k == "as":
                out = []
                vals = self.ev(n[1], inp, env)
                for v in vals:
                    e2 = dict(env)
                    e2[n[2]] = v
                    out.extend(self.ev(n[3], inp, e2))
                return out
            if k == "array":
                return [self.ev(n[1], inp, env)]
            if k == "object":
                objs = [{}]
                for keyn, valn, dyn in n[1]:
                    kvals = self.ev(keyn, inp, env)
                    vvals = self.ev(valn, inp, env)
                    if not vvals:
                        vvals = [None]
                    new_objs = []
                    for kv in kvals:
                        for vv in vvals:
                            for base in objs:
                                obj = dict(base)
                                obj[str(kv)] = vv
                                new_objs.append(obj)
                    objs = new_objs
                return objs
            if k == "field":
                out = []
                for b in self.ev(n[1], inp, env):
                    if isinstance(b, dict):
                        out.append(b.get(n[2]))
                    elif n[3]:
                        pass
                    else:
                        raise JQError(f"Cannot index {jtype(b)} with string \"{n[2]}\"")
                return out
            if k == "index":
                out = []
                for b in self.ev(n[1], inp, env):
                    for idx in self.ev(n[2], inp, env):
                        if isinstance(b, list) and isinstance(idx, int):
                            ii = idx + len(b) if idx < 0 else idx
                            out.append(b[ii] if 0 <= ii < len(b) else None)
                        elif isinstance(b, dict):
                            out.append(b.get(str(idx)))
                        elif isinstance(b, str) and isinstance(idx, int):
                            ii = idx + len(b) if idx < 0 else idx
                            out.append(b[ii] if 0 <= ii < len(b) else None)
                        elif n[3]:
                            pass
                        else:
                            raise JQError(f"Cannot index {jtype(b)}")
                return out
            if k == "slice":
                out = []
                for b in self.ev(n[1], inp, env):
                    s = one(self.ev(n[2], inp, env)) if n[2] is not None else None
                    e = one(self.ev(n[3], inp, env)) if n[3] is not None else None
                    if isinstance(b, (list, str)):
                        out.append(b[s:e])
                    elif n[4]:
                        pass
                    else:
                        raise JQError(f"Cannot slice {jtype(b)}")
                return out
            if k == "iter":
                out = []
                for b in self.ev(n[1], inp, env):
                    if isinstance(b, list):
                        out.extend(b)
                    elif isinstance(b, dict):
                        out.extend(b.values())
                    elif n[2]:
                        pass
                    else:
                        raise JQError(f"Cannot iterate over {jtype(b)}")
                return out
            if k == "try":
                try:
                    return self.ev(n[1], inp, env)
                except Exception:
                    return []
            if k == "recurse":
                out = []
                for b in self.ev(n[1], inp, env):
                    self._recurse(b, out)
                return out
            if k == "neg":
                return [-v for v in self.ev(n[1], inp, env)]
            if k == "not":
                return [not truthy(v) for v in self.ev(n[1], inp, env)]
            if k == "if":
                out = []
                for c in self.ev(n[1], inp, env):
                    out.extend(self.ev(n[2] if truthy(c) else n[3], inp, env))
                return out
            if k == "assign":
                v = copy.deepcopy(inp)
                paths = paths_from_expr(n[2], inp, self, env)
                for p in paths:
                    cur = get_path(v, p)
                    if n[1] == "=":
                        newv = (self.ev(n[3], inp, env) or [None])[-1]
                    elif n[1] == "|=":
                        newv = (self.ev(n[3], cur, env) or [None])[-1]
                    else:
                        rhs = (self.ev(n[3], cur if n[1] == "|=" else inp, env) or [None])[-1]
                        op = n[1][0]
                        if op == "+":
                            newv = jadd(cur, rhs)
                        elif op == "-":
                            newv = jsub(cur, rhs)
                        elif op == "*":
                            newv = jmul(cur, rhs)
                        else:
                            newv = jdiv(cur, rhs)
                    if p:
                        set_path(v, p, newv)
                    else:
                        v = newv
                return [v]
            if k == "bin":
                return self.binop(n[1], n[2], n[3], inp, env)
            if k == "call":
                return self.call(n[1], n[2], inp, env)
        except JQError:
            raise
        except Exception as e:
            raise JQError(str(e))
        raise JQError(f"unsupported node {k}")

    def _recurse(self, v, out):
        out.append(v)
        if isinstance(v, dict):
            for x in v.values():
                self._recurse(x, out)
        elif isinstance(v, list):
            for x in v:
                self._recurse(x, out)

    def binop(self, op, a, b, inp, env):
        if op in ("and", "or"):
            av = one(self.ev(a, inp, env))
            if op == "and":
                return [truthy(av) and truthy(one(self.ev(b, inp, env)))]
            return [truthy(av) or truthy(one(self.ev(b, inp, env)))]
        if op == "//":
            avs = [x for x in self.ev(a, inp, env) if x is not None and x is not False]
            return avs if avs else self.ev(b, inp, env)
        out = []
        avs = self.ev(a, inp, env)
        bvs = self.ev(b, inp, env)
        for x in avs:
            for y in bvs:
                if op == "+":
                    out.append(jadd(x, y))
                elif op == "-":
                    out.append(jsub(x, y))
                elif op == "*":
                    out.append(jmul(x, y))
                elif op == "/":
                    out.append(jdiv(x, y))
                elif op == "==":
                    out.append(x == y)
                elif op == "!=":
                    out.append(x != y)
                elif op in ("<", ">", "<=", ">="):
                    out.append(jcmp(x, y, op))
        return out

    def call(self, name, args, inp, env):
        aval = lambda i=0, base=inp: self.ev(args[i], base, env) if i < len(args) else []
        onea = lambda i=0, base=inp: one(aval(i, base))
        if name == "length":
            if inp is None:
                return [0]
            if isinstance(inp, (str, list, dict)):
                return [len(inp)]
            if isinstance(inp, (int, float)):
                return [abs(inp)]
        if name == "type":
            return [jtype(inp)]
        if name == "utf8bytelength":
            return [len(str(inp).encode("utf-8"))]
        if name == "keys" or name == "keys_unsorted":
            if isinstance(inp, dict):
                ks = list(inp.keys())
                if name == "keys":
                    ks.sort()
                return [ks]
            if isinstance(inp, list):
                return [list(range(len(inp)))]
            return [[]]
        if name == "has":
            k = onea()
            if isinstance(inp, dict):
                if not isinstance(k, str):
                    raise JQError(f"Cannot check whether object has a {jtype(k)} key")
                return [k in inp]
            if isinstance(inp, list):
                if not isinstance(k, int):
                    raise JQError(f"Cannot check whether array has a {jtype(k)} key")
                return [0 <= k < len(inp)]
            return [False]
        if name == "in":
            obj = onea()
            if isinstance(obj, dict):
                return [str(inp) in obj]
            if isinstance(obj, list):
                return [isinstance(inp, int) and 0 <= inp < len(obj)]
            return [False]
        if name == "map":
            if not isinstance(inp, list):
                return [[]]
            return [[y for x in inp for y in self.ev(args[0], x, env)]]
        if name == "map_values":
            if isinstance(inp, list):
                return [[(self.ev(args[0], x, env) or [None])[-1] for x in inp]]
            if isinstance(inp, dict):
                return [{k: (self.ev(args[0], v, env) or [None])[-1] for k, v in inp.items()}]
        if name == "select":
            return [inp] if any(truthy(x) for x in aval(0)) else []
        if name == "empty":
            return []
        if name == "add":
            if args:
                vals = self.ev(args[0], inp, env)
                return self.call("add", [], vals, env)
            if not isinstance(inp, list) or not inp:
                return [None]
            r = inp[0]
            for v in inp[1:]:
                r = jadd(r, v)
            return [r]
        if name == "abs":
            return [abs(inp)]
        if name == "floor":
            return [math.floor(inp)]
        if name == "ceil":
            return [math.ceil(inp)]
        if name == "sqrt":
            return [math.sqrt(inp)]
        if name == "tonumber":
            return [float(inp) if (isinstance(inp, str) and any(c in inp for c in ".eE")) else int(inp)]
        if name == "toboolean":
            if isinstance(inp, bool):
                return [inp]
            if inp == "true":
                return [True]
            if inp == "false":
                return [False]
            raise JQError("cannot parse as boolean")
        if name == "tostring":
            return [inp if isinstance(inp, str) else dumps(inp, True, False, None)]
        if name == "tojson":
            return [dumps(inp, True, False, None)]
        if name == "fromjson":
            return [json.loads(inp)]
        if name == "contains":
            return [jcontains(inp, onea())]
        if name == "startswith":
            return [isinstance(inp, str) and inp.startswith(str(onea()))]
        if name == "endswith":
            return [isinstance(inp, str) and inp.endswith(str(onea()))]
        if name == "ltrimstr":
            s = str(onea())
            return [inp[len(s):] if isinstance(inp, str) and inp.startswith(s) else inp]
        if name == "rtrimstr":
            s = str(onea())
            return [inp[:-len(s)] if isinstance(inp, str) and s and inp.endswith(s) else inp]
        if name == "trimstr":
            return self.call("rtrimstr", args, self.call("ltrimstr", args, inp, env)[0], env)
        if name == "trim":
            return [inp.strip()]
        if name == "ltrim":
            return [inp.lstrip()]
        if name == "rtrim":
            return [inp.rstrip()]
        if name == "ascii_upcase":
            return [inp.upper()]
        if name == "ascii_downcase":
            return [inp.lower()]
        if name == "explode":
            return [[ord(c) for c in inp]]
        if name == "implode":
            return ["".join(chr(int(x)) for x in inp)]
        if name == "split":
            return [inp.split(str(onea()))]
        if name == "join":
            sep = str(onea())
            return [sep.join("" if x is None else str(x) for x in inp)]
        if name == "reverse":
            return [list(reversed(inp)) if isinstance(inp, list) else inp[::-1]]
        if name == "sort":
            return [sorted(inp, key=lambda x: dumps(x, True, True, None))]
        if name == "sort_by":
            return [sorted(inp, key=lambda x: tuple((self.ev(a, x, env) or [None])[0] for a in args))]
        if name == "group_by":
            arr = sorted(inp, key=lambda x: tuple((self.ev(a, x, env) or [None])[0] for a in args))
            groups = []
            for x in arr:
                key = tuple((self.ev(a, x, env) or [None])[0] for a in args)
                if not groups or groups[-1][0] != key:
                    groups.append((key, [x]))
                else:
                    groups[-1][1].append(x)
            return [[g for _, g in groups]]
        if name == "unique":
            res = []
            for x in sorted(inp, key=lambda x: dumps(x, True, True, None)):
                if x not in res:
                    res.append(x)
            return [res]
        if name == "unique_by":
            arr = sorted(inp, key=lambda x: tuple((self.ev(a, x, env) or [None])[0] for a in args))
            seen, res = [], []
            for x in arr:
                key = tuple((self.ev(a, x, env) or [None])[0] for a in args)
                if key not in seen:
                    seen.append(key); res.append(x)
            return [res]
        if name == "min":
            return [min(inp)] if inp else [None]
        if name == "max":
            return [max(inp)] if inp else [None]
        if name == "min_by":
            return [min(inp, key=lambda x: tuple((self.ev(a, x, env) or [None])[0] for a in args))] if inp else [None]
        if name == "max_by":
            return [max(inp, key=lambda x: tuple((self.ev(a, x, env) or [None])[0] for a in args))] if inp else [None]
        if name == "flatten":
            depth = onea(0) if args else None
            return [flatten(inp, depth)]
        if name == "range":
            vals = [onea(i) for i in range(len(args))]
            if len(vals) == 1:
                start, end, step = 0, vals[0], 1
            elif len(vals) == 2:
                start, end, step = vals[0], vals[1], 1
            else:
                start, end, step = vals[0], vals[1], vals[2]
            return list(range(int(start), int(end), int(step)))
        if name == "to_entries":
            if isinstance(inp, dict):
                return [[{"key": k, "value": v} for k, v in inp.items()]]
            if isinstance(inp, list):
                return [[{"key": i, "value": v} for i, v in enumerate(inp)]]
        if name == "from_entries":
            return [{str(e.get("key", e.get("Key"))): e.get("value", e.get("Value")) for e in inp}]
        if name == "with_entries":
            ents = Evaluator(self.vars).call("to_entries", [], inp, env)[0]
            mapped = [y for x in ents for y in self.ev(args[0], x, env)]
            return Evaluator(self.vars).call("from_entries", [], mapped, env)
        if name == "pick":
            obj = {}
            arr = []
            root_is_arr = False
            for a in args:
                for p in paths_from_expr(a, inp, self, env):
                    if p:
                        if isinstance(p[0], int):
                            root_is_arr = True
                            while p[0] >= len(arr):
                                arr.append(None)
                            set_path(arr, p, get_path(inp, p))
                        else:
                            set_path(obj, p, get_path(inp, p))
            return [arr if root_is_arr else obj]
        if name == "del":
            v = copy.deepcopy(inp)
            for p in paths_from_expr(args[0], inp, self, env):
                delete_path(v, p)
            return [v]
        if name == "getpath":
            out = []
            for p in aval(0):
                out.append(get_path(inp, p))
            return out
        if name == "setpath":
            v = copy.deepcopy(inp)
            set_path(v, onea(0), onea(1))
            return [v]
        if name == "delpaths":
            v = copy.deepcopy(inp)
            for p in onea(0) or []:
                delete_path(v, p)
            return [v]
        if name == "path":
            return paths_from_expr(args[0], inp, self, env) or [[]]
        if name == "paths":
            ps = []
            collect_paths(inp, [], ps)
            ps = [p for p in ps if p]
            if args:
                ps = [p for p in ps if any(truthy(x) for x in self.ev(args[0], get_path(inp, p), env))]
            return ps
        if name == "any":
            if not args:
                return [any(truthy(x) for x in (inp if isinstance(inp, list) else []))]
            vals = inp if isinstance(inp, list) else [inp]
            return [any(any(truthy(y) for y in self.ev(args[-1], x, env)) for x in vals)]
        if name == "all":
            if not args:
                return [all(truthy(x) for x in (inp if isinstance(inp, list) else []))]
            vals = inp if isinstance(inp, list) else [inp]
            return [all(any(truthy(y) for y in self.ev(args[-1], x, env)) for x in vals)]
        if name == "indices":
            needle = onea()
            return [indices(inp, needle)]
        if name == "index":
            xs = indices(inp, onea())
            return [xs[0] if xs else None]
        if name == "rindex":
            xs = indices(inp, onea())
            return [xs[-1] if xs else None]
        if name == "inside":
            return [jcontains(onea(), inp)]
        if name == "combinations":
            pools = inp
            reps = int(onea()) if args else 1
            if reps != 1:
                pools = pools * reps
            return combos(pools)
        if name == "transpose":
            if not inp:
                return [[]]
            m = max(len(x) for x in inp)
            return [[[row[i] if i < len(row) else None for row in inp] for i in range(m)]]
        if name == "bsearch":
            x = onea()
            lo, hi = 0, len(inp)
            while lo < hi:
                mid = (lo + hi) // 2
                if inp[mid] < x:
                    lo = mid + 1
                else:
                    hi = mid
            return [lo if lo < len(inp) and inp[lo] == x else -1 - lo]
        if name in ("env", "ENV"):
            return [dict(os.environ)]
        if name == "test":
            pat = str(onea(0)); flags = re.I if (len(args) > 1 and "i" in str(onea(1))) else 0
            return [re.search(pat, inp, flags) is not None]
        if name == "match":
            pat = str(onea(0)); flags_s = str(onea(1)) if len(args) > 1 else ""
            flags = re.I if "i" in flags_s else 0
            matches = list(re.finditer(pat, inp, flags)) if "g" in flags_s else ([re.search(pat, inp, flags)] if re.search(pat, inp, flags) else [])
            return [match_obj(m, inp) for m in matches if m]
        if name == "capture":
            m = re.search(str(onea()), inp)
            return [m.groupdict() if m else {}]
        if name == "scan":
            pat = str(onea())
            out = []
            for m in re.finditer(pat, inp):
                if m.groups():
                    out.append(list(m.groups()) if len(m.groups()) > 1 else m.group(1))
                else:
                    out.append(m.group(0))
            return out
        if name == "not":
            return [not truthy(inp)]
        if name == "values":
            return [] if inp is None else [inp]
        if name == "arrays":
            return [inp] if isinstance(inp, list) else []
        if name == "objects":
            return [inp] if isinstance(inp, dict) else []
        if name == "strings":
            return [inp] if isinstance(inp, str) else []
        if name == "numbers":
            return [inp] if isinstance(inp, (int, float)) and not isinstance(inp, bool) else []
        if name == "booleans":
            return [inp] if isinstance(inp, bool) else []
        if name == "nulls":
            return [inp] if inp is None else []
        raise JQError(f"{name}/0 is not defined")


def jadd(a, b):
    if a is None:
        return b
    if b is None:
        return a
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return a + b
    if isinstance(a, str) and isinstance(b, str):
        return a + b
    if isinstance(a, list) and isinstance(b, list):
        return a + b
    if isinstance(a, dict) and isinstance(b, dict):
        r = dict(a)
        r.update(b)
        return r
    raise JQError(f"{jtype(a)} and {jtype(b)} cannot be added")


def jsub(a, b):
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return a - b
    if isinstance(a, list) and isinstance(b, list):
        return [x for x in a if x not in b]
    raise JQError("subtraction type error")


def jmul(a, b):
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return a * b
    if isinstance(a, str) and isinstance(b, int):
        return a * b
    if isinstance(a, int) and isinstance(b, str):
        return a * b
    if isinstance(a, dict) and isinstance(b, dict):
        r = copy.deepcopy(a)
        for k, v in b.items():
            if k in r and isinstance(r[k], dict) and isinstance(v, dict):
                r[k] = jmul(r[k], v)
            else:
                r[k] = v
        return r
    raise JQError("multiplication type error")


def jdiv(a, b):
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return a / b
    if isinstance(a, str) and isinstance(b, str):
        return a.split(b)
    raise JQError("division type error")


def jcmp(a, b, op):
    if op == "<":
        return a < b
    if op == ">":
        return a > b
    if op == "<=":
        return a <= b
    return a >= b


def jcontains(a, b):
    if isinstance(a, str):
        return str(b) in a
    if isinstance(a, list):
        return all(any(jcontains(x, y) if isinstance(x, (list, dict, str)) else x == y for x in a) for y in b)
    if isinstance(a, dict):
        return isinstance(b, dict) and all(k in a and jcontains(a[k], v) if isinstance(a.get(k), (list, dict, str)) else a.get(k) == v for k, v in b.items())
    return a == b


def flatten(v, depth=None):
    if not isinstance(v, list) or depth == 0:
        return v
    out = []
    for x in v:
        if isinstance(x, list) and (depth is None or depth > 0):
            out.extend(flatten(x, None if depth is None else depth - 1))
        else:
            out.append(x)
    return out


def collect_paths(v, p, out):
    out.append(list(p))
    if isinstance(v, dict):
        for k, x in v.items():
            collect_paths(x, p + [k], out)
    elif isinstance(v, list):
        for i, x in enumerate(v):
            collect_paths(x, p + [i], out)


def indices(hay, needle):
    out = []
    if isinstance(hay, str):
        start = 0
        needle = str(needle)
        while True:
            i = hay.find(needle, start)
            if i < 0:
                break
            out.append(i)
            start = i + 1
    elif isinstance(hay, list):
        n = len(needle) if isinstance(needle, list) else 1
        for i in range(0, len(hay) - n + 1):
            if (hay[i:i+n] == needle) if isinstance(needle, list) else (hay[i] == needle):
                out.append(i)
    return out


def combos(pools):
    if not pools:
        return [[]]
    res = [[]]
    for pool in pools:
        res = [r + [x] for r in res for x in pool]
    return res


def match_obj(m, s):
    caps = []
    for i, g in enumerate(m.groups()):
        st = m.start(i + 1)
        caps.append({"offset": st if st >= 0 else -1, "length": len(g) if g is not None else 0, "string": g, "name": None})
    return {"offset": m.start(), "length": m.end() - m.start(), "string": m.group(0), "captures": caps}


def get_path(v, path):
    cur = v
    for p in path:
        if isinstance(cur, dict):
            cur = cur.get(str(p))
        elif isinstance(cur, list) and isinstance(p, int):
            cur = cur[p] if 0 <= p < len(cur) else None
        else:
            return None
    return cur


def set_path(v, path, val):
    cur = v
    for p in path[:-1]:
        if isinstance(cur, dict):
            cur = cur.setdefault(str(p), {})
        elif isinstance(cur, list) and isinstance(p, int):
            while p >= len(cur):
                cur.append({})
            cur = cur[p]
    if not path:
        return val
    p = path[-1]
    if isinstance(cur, dict):
        cur[str(p)] = val
    elif isinstance(cur, list) and isinstance(p, int):
        while p >= len(cur):
            cur.append(None)
        cur[p] = val


def delete_path(v, path):
    if not path:
        return
    cur = v
    for p in path[:-1]:
        cur = cur.get(str(p)) if isinstance(cur, dict) else (cur[p] if isinstance(cur, list) and isinstance(p, int) and p < len(cur) else None)
        if cur is None:
            return
    p = path[-1]
    if isinstance(cur, dict):
        cur.pop(str(p), None)
    elif isinstance(cur, list) and isinstance(p, int) and 0 <= p < len(cur):
        del cur[p]


def paths_from_expr(n, inp, evr, env):
    if n[0] == "field":
        return [p + [n[2]] for p in paths_from_expr(n[1], inp, evr, env)]
    if n[0] == "index":
        return [p + [idx] for p in paths_from_expr(n[1], inp, evr, env) for idx in evr.ev(n[2], inp, env)]
    if n[0] == "id":
        return [[]]
    if n[0] == "comma":
        out = []
        for x in n[1]:
            out.extend(paths_from_expr(x, inp, evr, env))
        return out
    return []


def dumps(v, compact=False, sort_keys=False, indent=None, ascii_only=False):
    if compact:
        return json.dumps(v, ensure_ascii=ascii_only, sort_keys=sort_keys, separators=(",", ":"))
    if indent == "tab":
        s = json.dumps(v, ensure_ascii=ascii_only, sort_keys=sort_keys, indent=1)
        return re.sub(r"^ +", lambda m: "\t" * len(m.group(0)), s, flags=re.M)
    return json.dumps(v, ensure_ascii=ascii_only, sort_keys=sort_keys, indent=2 if indent is None else indent)


def parse_inputs(files, raw=False, slurp=False, null_input=False, seq=False):
    if null_input:
        return [None]
    data = ""
    if not files:
        data = sys.stdin.read()
    else:
        chunks = []
        for f in files:
            with open(f, "r", encoding="utf-8") as fh:
                chunks.append(fh.read())
        data = "".join(chunks)
    if raw:
        if slurp:
            return [data]
        vals = data.splitlines()
        return vals
    if seq:
        data = data.replace("\x1e", "\n")
    dec = json.JSONDecoder()
    vals = []
    i = 0
    while True:
        while i < len(data) and data[i].isspace():
            i += 1
        if i >= len(data):
            break
        v, j = dec.raw_decode(data, i)
        vals.append(v)
        i = j
    return [vals] if slurp else vals


def parse_argv(argv):
    opts = {
        "null": False, "rawin": False, "slurp": False, "compact": False, "rawout": False,
        "join": False, "ascii": False, "sort": False, "indent": None, "exit": False,
        "from_file": None, "seq": False, "raw0": False,
    }
    vars = {"ARGS": {"named": {}, "positional": []}}
    args = list(argv)
    i = 0
    filter_text = None
    files = []
    while i < len(args):
        a = args[i]
        if a == "--":
            i += 1
            break
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a == "--build-configuration":
            print("--disable-docs --with-oniguruma=builtin --enable-static --enable-all-static --prefix=/usr/local")
            sys.exit(0)
        if a in ("-n", "--null-input"): opts["null"] = True; i += 1; continue
        if a in ("-R", "--raw-input"): opts["rawin"] = True; i += 1; continue
        if a in ("-s", "--slurp"): opts["slurp"] = True; i += 1; continue
        if a in ("-c", "--compact-output"): opts["compact"] = True; i += 1; continue
        if a in ("-r", "--raw-output"): opts["rawout"] = True; i += 1; continue
        if a == "--raw-output0": opts["rawout"] = True; opts["raw0"] = True; i += 1; continue
        if a in ("-j", "--join-output"): opts["rawout"] = True; opts["join"] = True; i += 1; continue
        if a in ("-a", "--ascii-output"): opts["ascii"] = True; i += 1; continue
        if a in ("-S", "--sort-keys"): opts["sort"] = True; i += 1; continue
        if a in ("-C", "--color-output", "-M", "--monochrome-output", "--unbuffered"): i += 1; continue
        if a == "--seq": opts["seq"] = True; i += 1; continue
        if a == "--tab": opts["indent"] = "tab"; i += 1; continue
        if a == "--indent": opts["indent"] = int(args[i+1]); i += 2; continue
        if a in ("-e", "--exit-status"): opts["exit"] = True; i += 1; continue
        if a in ("-f", "--from-file"): opts["from_file"] = args[i+1]; i += 2; continue
        if a in ("-L", "--library-path"): i += 2; continue
        if a == "--arg":
            name, val = args[i+1], args[i+2]
            vars[name] = val; vars["ARGS"]["named"][name] = val
            i += 3; continue
        if a == "--argjson":
            name, val = args[i+1], json.loads(args[i+2])
            vars[name] = val; vars["ARGS"]["named"][name] = val
            i += 3; continue
        if a == "--rawfile":
            name = args[i+1]
            with open(args[i+2], encoding="utf-8") as fh: val = fh.read()
            vars[name] = val; vars["ARGS"]["named"][name] = val
            i += 3; continue
        if a == "--slurpfile":
            name = args[i+1]
            val = parse_inputs([args[i+2]], False, False, False)
            vars[name] = val; vars["ARGS"]["named"][name] = val
            i += 3; continue
        if a == "--args":
            if filter_text is None:
                filter_text = args[i+1]; rest = args[i+2:]
            else:
                rest = args[i+1:]
            vars["ARGS"]["positional"] = rest
            return opts, vars, filter_text, []
        if a == "--jsonargs":
            if filter_text is None:
                filter_text = args[i+1]; rest = args[i+2:]
            else:
                rest = args[i+1:]
            vars["ARGS"]["positional"] = [json.loads(x) for x in rest]
            return opts, vars, filter_text, []
        if a.startswith("-") and a != "-":
            for ch in a[1:]:
                if ch == "n": opts["null"] = True
                elif ch == "R": opts["rawin"] = True
                elif ch == "s": opts["slurp"] = True
                elif ch == "c": opts["compact"] = True
                elif ch == "r": opts["rawout"] = True
                elif ch == "j": opts["rawout"] = True; opts["join"] = True
                elif ch == "a": opts["ascii"] = True
                elif ch == "S": opts["sort"] = True
                elif ch == "e": opts["exit"] = True
            i += 1; continue
        break
    if opts["from_file"]:
        with open(opts["from_file"], encoding="utf-8") as fh:
            filter_text = fh.read()
    elif filter_text is None and i < len(args):
        filter_text = args[i]; i += 1
    files = args[i:]
    if filter_text is None:
        filter_text = "."
    return opts, vars, filter_text, files


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    try:
        opts, vars, filt, files = parse_argv(argv)
        ast = Parser(filt).parse()
        inputs = parse_inputs(files, opts["rawin"], opts["slurp"], opts["null"], opts["seq"])
        evr = Evaluator(vars)
        last = None
        anyout = False
        sep = "\0" if opts["raw0"] else ("" if opts["join"] else "\n")
        for inp in inputs:
            for out in evr.ev(ast, inp):
                anyout = True
                last = out
                if opts["seq"]:
                    sys.stdout.write("\x1e")
                if opts["rawout"] and isinstance(out, str):
                    sys.stdout.write(out)
                else:
                    sys.stdout.write(dumps(out, opts["compact"], opts["sort"], opts["indent"], opts["ascii"]))
                sys.stdout.write(sep)
        if opts["exit"]:
            if not anyout:
                return 4
            return 0 if truthy(last) else 1
        return 0
    except BrokenPipeError:
        return 0
    except Exception as e:
        sys.stderr.write(f"jq: error: {e}\n")
        return 3


if __name__ == "__main__":
    sys.exit(main())
