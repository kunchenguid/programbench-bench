#!/usr/bin/env python3
import os
import sys
import termios
import tty
import shutil
import stat
import subprocess

VERSION = "v1.13.0"
HELP = """
  walk v1.13.0

  Usage: walk [path]

    arrows, hjkl  Move cursor
    enter         Enter directory
    backspace     Exit directory
    space         Toggle preview
    esc, q        Exit with cd
    ctrl+c        Exit without cd
    /             Fuzzy search
    d, delete     Delete file or dir
    y             Copy to clipboard
    .             Hide hidden files
    ?             Show help

  Flags:

    --icons        display icons
    --dir-only     show dirs only
    --hide-hidden  hide hidden files
    --preview      display preview
    --with-border  preview with border
    --fuzzy        fuzzy mode

"""

FLAGS = {"--icons", "--dir-only", "--hide-hidden", "--preview", "--with-border", "--fuzzy"}


def go_panic(msg="could not open a new TTY: open /dev/tty: no such device or address"):
    sys.stderr.write(f"panic: {msg}\n\n")
    sys.stderr.write("goroutine 1 [running]:\n")
    sys.stderr.write("main.main()\n")
    sys.stderr.write("\t/workspace/main.go:135 +0x87d\n")
    return 2


def parse(argv):
    opts = {f: False for f in FLAGS}
    path = None
    for arg in argv:
        if arg in ("--help", "-h"):
            sys.stderr.write(HELP)
            raise SystemExit(1)
        if arg in ("--version", "-v"):
            print(VERSION)
            raise SystemExit(0)
        if arg in FLAGS:
            opts[arg] = True
        elif path is None:
            path = arg
    return opts, path


def display_name(path):
    name = os.path.basename(path.rstrip(os.sep)) or path
    try:
        if os.path.isdir(path):
            return name + "/"
    except OSError:
        pass
    return name


def icon_for(path):
    if os.path.isdir(path):
        return "\uf115"
    if os.access(path, os.X_OK):
        return "\uf427"
    return "\uf40e"


def entries(cwd, opts):
    try:
        names = os.listdir(cwd)
    except OSError:
        return []
    out = []
    for name in names:
        if opts.get("--hide-hidden") and name.startswith("."):
            continue
        p = os.path.join(cwd, name)
        if opts.get("--dir-only") and not os.path.isdir(p):
            continue
        out.append((name.lower(), name, p))
    out.sort(key=lambda x: (x[0], x[1]))
    return [p for _, _, p in out]


def size_text(path):
    try:
        st = os.stat(path)
        n = st.st_size
    except OSError:
        return ""
    units = ["B", "K", "M", "G", "T"]
    f = float(n)
    for u in units:
        if f < 1024 or u == units[-1]:
            if u == "B":
                return f"{int(f)}B"
            return f"{f:.1f}{u}"
        f /= 1024


def status_bar(path, files):
    expr = os.environ.get("WALK_STATUS_BAR")
    if not expr:
        return ""
    # Small compatibility subset for the documented common functions.
    mode = owner = mtime = ""
    try:
        st = os.stat(path)
        mode = stat.filemode(st.st_mode)
        import pwd, grp, time
        owner = pwd.getpwuid(st.st_uid).pw_name + " " + grp.getgrgid(st.st_gid).gr_name
        mtime = time.strftime("%b %d %H:%M", time.localtime(st.st_mtime))
    except Exception:
        pass
    s = expr
    repl = {"Size()": size_text(path), "Mode()": mode, "Owner()": owner, "ModTime()": mtime}
    for k, v in repl.items():
        s = s.replace(k, v)
    return s if len(s) < 200 else s[:200]


def render(ttyf, cwd, opts, idx, message=None, preview=False):
    cols, rows = shutil.get_terminal_size((80, 24))
    if cols < 20:
        cols = 80
    if rows < 5:
        rows = 24
    ents = entries(cwd, opts)
    limit = max(1, rows - 3)
    lines = []
    if opts.get("--preview") or preview:
        lines.append(os.path.basename(cwd.rstrip(os.sep)) or cwd)
    if message:
        width = min(cols - 2, max(10, len(message) + 4))
        top = "╭" + "─" * (width - 2) + "╮"
        mid = "│ " + message[: width - 4].ljust(width - 4) + " │"
        bot = "╰" + "─" * (width - 2) + "╯"
        lines += [top, mid, bot]
    elif not ents:
        lines += ["╭──────────╮", "│ No files │", "╰──────────╯"]
    else:
        start = 0
        if idx >= limit:
            start = idx - limit + 1
        for i, p in enumerate(ents[start:start + limit], start):
            name = display_name(p)
            if opts.get("--icons"):
                name = icon_for(p) + " " + name
            prefix = "" if i != idx else ""
            lines.append((prefix + name).ljust(min(cols, max(1, len(name) + 1)))[:cols])
    if ents and 0 <= idx < len(ents):
        sb = status_bar(ents[idx], ents)
        if sb:
            lines.append(sb[:cols])
    data = "\r" + "\x1b[2K" + "\r\n".join(lines) + "\x1b[D"
    ttyf.write(data.encode("utf-8", "replace"))
    ttyf.flush()


def read_key(ttyf):
    ch = ttyf.read(1)
    if not ch:
        return ""
    if ch == b"\x1b":
        rest = b""
        try:
            import select
            while select.select([ttyf], [], [], 0.02)[0]:
                rest += ttyf.read(1)
                if len(rest) > 8:
                    break
        except Exception:
            pass
        seq = ch + rest
        if seq in (b"\x1b[A",): return "up"
        if seq in (b"\x1b[B",): return "down"
        if seq in (b"\x1b[3~",): return "delete"
        if seq in (b"\x1b[1;2A", b"\x1b[H"): return "home"
        if seq in (b"\x1b[1;2B", b"\x1b[F"): return "end"
        if seq.endswith(b"R") and seq.startswith(b"\x1b["):
            return ""
        return "esc"
    if ch in (b"\r", b"\n"):
        return "enter"
    if ch in (b"\x7f", b"\x08"):
        return "backspace"
    if ch == b"\x03":
        return "ctrlc"
    try:
        return ch.decode()
    except UnicodeDecodeError:
        return ""


def main(argv):
    opts, arg_path = parse(argv)
    try:
        ttyf = open("/dev/tty", "r+b", buffering=0)
    except OSError:
        return go_panic()

    base = os.getcwd()
    cwd = os.path.abspath(arg_path) if arg_path is not None else base
    message = None
    if arg_path is not None and not os.path.isdir(cwd):
        try:
            open(cwd, "rb").close()
            message = f"not a directory: {cwd}"
        except OSError as e:
            message = f"open {cwd}: {e.strerror.lower() if e.strerror else 'no such file or directory'}"
        # Reference keeps this as the selected output path.
    old = None
    try:
        old = termios.tcgetattr(ttyf.fileno())
        tty.setcbreak(ttyf.fileno())
    except Exception:
        old = None
    preview = False
    idx = 0
    exit_path = None
    try:
        ttyf.write(b"\x1b]11;?\x1b\\\x1b[6n\x1b[?25l\x1b[?2004h")
        render(ttyf, cwd if os.path.isdir(cwd) else os.path.dirname(cwd) or os.getcwd(), opts, idx, message, preview)
        while True:
            try:
                key = read_key(ttyf)
            except KeyboardInterrupt:
                return 0
            if not key:
                continue
            if key == "ctrlc":
                return 0
            if key in ("q", "esc"):
                exit_path = cwd
                return 0
            if key in ("j", "down"):
                es = entries(cwd, opts) if os.path.isdir(cwd) else []
                if es:
                    idx = min(len(es) - 1, idx + 1)
            elif key in ("k", "up"):
                idx = max(0, idx - 1)
            elif key == "home":
                idx = 0
            elif key == "end":
                es = entries(cwd, opts) if os.path.isdir(cwd) else []
                idx = max(0, len(es) - 1)
            elif key == "enter":
                es = entries(cwd, opts) if os.path.isdir(cwd) else []
                if es and 0 <= idx < len(es) and os.path.isdir(es[idx]):
                    cwd = os.path.abspath(es[idx])
                    idx = 0
                    message = None
                elif es and 0 <= idx < len(es):
                    editor = os.environ.get("WALK_EDITOR") or os.environ.get("EDITOR")
                    if editor:
                        try:
                            subprocess.call(editor.split() + [es[idx]])
                        except Exception:
                            pass
            elif key == "backspace":
                parent = os.path.dirname(cwd.rstrip(os.sep)) or os.sep
                cwd = parent
                idx = 0
                message = None
            elif key == ".":
                opts["--hide-hidden"] = not opts.get("--hide-hidden")
                idx = 0
            elif key == " ":
                preview = not preview
            elif key == "?":
                message = "walk v1.13.0"
            render(ttyf, cwd if os.path.isdir(cwd) else os.path.dirname(cwd) or os.getcwd(), opts, idx, message, preview)
    finally:
        if old is not None:
            try:
                termios.tcsetattr(ttyf.fileno(), termios.TCSADRAIN, old)
            except Exception:
                pass
        try:
            ttyf.write(b"\x1b[?2004l\x1b[?25h\x1b[?1002l\x1b[?1003l\x1b[?1006l")
            ttyf.flush()
        except Exception:
            pass
        ttyf.close()
        if exit_path is not None:
            sys.stdout.write(exit_path + "\n")
            sys.stdout.flush()

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
