#!/usr/bin/env python3
import os, sys, re, json, shlex, subprocess, textwrap
from dataclasses import dataclass, field

VERSION='argc 1.23.0'

@dataclass
class Param:
    kind: str
    id: str
    names: list = field(default_factory=list)
    short: str|None = None
    long: str|None = None
    desc: str = ''
    required: bool = False
    multiple: bool = False
    multi_occurs: bool = False
    delimiter: str|None = None
    terminated: bool = False
    default: str|None = None
    default_fn: str|None = None
    choices: list|None = None
    choice_fn: str|None = None
    skip_choice_check: bool = False
    notations: list = field(default_factory=list)
    num_min: int = 1
    num_max: int = 1
    env: str|None = None
    flag: bool = False

@dataclass
class Command:
    name: str
    fn: str|None = None
    desc: str = ''
    aliases: list = field(default_factory=list)
    opts: list = field(default_factory=list)
    args: list = field(default_factory=list)
    envs: list = field(default_factory=list)
    sub: dict = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)
    parent: 'Command|None' = None


def camel_id(name):
    s=name.lstrip('-+').replace('-','_').replace(':','').replace('+','')
    return re.sub(r'[^A-Za-z0-9_]', '_', s).lower().strip('_') or 'arg'

def script_name(path):
    b=os.path.basename(path)
    return re.sub(r'\.(sh|bash)$','',b)

def parse_word_spec(tok):
    # id modifiers defaults choices, e.g. val*, --foo=bar, --x*,[a|b], --a:[x|y]
    env=None
    if tok.endswith('~'):
        terminated=True; tok=tok[:-1]
    else: terminated=False
    delimiter=None
    if ',' in tok and tok.index(',') < len(tok):
        # only comma before choice/default suffix
        tok=tok.replace(',', '', 1); delimiter=','
    choices=None; choice_fn=None; skip=False; default=None
    m=re.search(r'\[(.*)\]$', tok)
    if m:
        data=m.group(1); tok=tok[:m.start()]
        if data.startswith('?'):
            skip=True; data=data[1:]
        if data.startswith('='):
            default=data[1:].split('|')[0] if data[1:] else ''
            choices=data[1:].split('|') if data[1:] else []
        elif data.startswith('`') and data.endswith('`'):
            choice_fn=data[1:-1]
        else:
            choices=data.split('|') if data else []
    else:
        default=None
    default_fn=None
    if tok.endswith(':'):
        tok=tok[:-1]
    if '=' in tok and not tok.startswith(('>=','<=')):
        base, val = tok.split('=',1)
        tok=base
        if val.startswith('`') and val.endswith('`'):
            default_fn=val[1:-1]
        else:
            default=val
    required=False; multiple=False; multi_occurs=False
    if tok.endswith('!'):
        required=True; tok=tok[:-1]
    elif tok.endswith('+'):
        required=True; multiple=True; multi_occurs=True; tok=tok[:-1]
    elif tok.endswith('*'):
        multiple=True; multi_occurs=True; tok=tok[:-1]
    return tok, required, multiple, multi_occurs, delimiter, terminated, default, default_fn, choices, choice_fn, skip

def split_desc(rest):
    return shlex.split(rest, comments=False, posix=True) if rest.strip() else []

def parse_param(tag, rest):
    toks=split_desc(rest)
    names=[]; i=0
    while i < len(toks) and (toks[i].startswith('-') or toks[i].startswith('+')):
        names.append(toks[i]); i+=1
    if tag=='arg':
        if not toks: return None
        spec=toks[0]; i=1
        p=Param('arg', '')
        base, req, mult, mo, delim, term, dflt, dfn, choices, cfn, skip = parse_word_spec(spec)
        p.id=camel_id(base); p.required=req; p.multiple=mult; p.multi_occurs=mo; p.delimiter=delim; p.terminated=term
        p.default=dflt; p.default_fn=dfn; p.choices=choices; p.choice_fn=cfn; p.skip_choice_check=skip
        # env binding token
        if i < len(toks) and toks[i].startswith('$'):
            p.env = p.id.upper() if toks[i]=='$$' else toks[i].lstrip('$'); i+=1
        if i < len(toks) and toks[i].startswith('<'):
            p.notations=[toks[i].strip('<>')]; i+=1
        else:
            p.notations=[(base.upper()+('~' if term else ''))]
        p.desc=' '.join(toks[i:])
        return p
    # option/flag
    p=Param(tag, '', flag=(tag=='flag'))
    if not names: return None
    parsed=[]
    for nm in names:
        base, req, mult, mo, delim, term, dflt, dfn, choices, cfn, skip = parse_word_spec(nm)
        parsed.append((base, req, mult, mo, delim, term, dflt, dfn, choices, cfn, skip))
    p.names=[x[0] for x in parsed]
    p.long=next((n for n in p.names if n.startswith('--') or (len(n)>2 and n.startswith(('+','-')))), p.names[-1])
    p.short=next((n for n in p.names if n != p.long and len(n)==2), None)
    if p.short is None and len(p.long)==2 and p.long.startswith('-') and not p.long.startswith('--'):
        p.short=None
    p.id=camel_id(p.long)
    anyp=parsed[-1]
    p.required=any(x[1] for x in parsed); p.multiple=any(x[2] for x in parsed); p.multi_occurs=any(x[3] for x in parsed)
    p.delimiter=anyp[4]; p.terminated=anyp[5]; p.default=anyp[6]; p.default_fn=anyp[7]; p.choices=anyp[8]; p.choice_fn=anyp[9]; p.skip_choice_check=anyp[10]
    if tag=='flag':
        p.num_min=p.num_max=0
    else:
        nots=[]
        while i < len(toks) and toks[i].startswith('<'):
            val=toks[i].strip('<>'); nots.append(val); i+=1
        if nots:
            p.notations=nots
            mn=mx=0
            for n in nots:
                if n.endswith('*'): mx=32767
                elif n.endswith('+'): mn+=1; mx=32767
                elif n.endswith('?'): mx+=1
                else: mn+=1; mx+=1
            p.num_min=mn; p.num_max=mx
            if mx>1: p.multiple=True
        else:
            p.notations=[p.id.upper()+('~' if p.terminated else '')]
            p.num_min=1; p.num_max=32767 if p.terminated else 1
            if p.terminated: p.multiple=True
    if i < len(toks) and toks[i].startswith('$'):
        p.env=p.id.upper() if toks[i]=='$$' else toks[i].lstrip('$'); i+=1
    p.desc=' '.join(toks[i:])
    return p

def parse_file(path):
    try: lines=open(path).read().splitlines()
    except Exception as e:
        sys.stderr.write(str(e)+'\n'); sys.exit(1)
    root=Command(script_name(path), None)
    pending=[]; last_tag=None
    def flush_for_func(fn):
        nonlocal pending
        cmd=None; aliases=[]; opts=[]; args=[]; envs=[]; meta={}; desc_parts=[]; explicit_cmd=False
        for tag, rest, extras in pending:
            if tag=='describe': root.desc=(rest + ('\n'+'\n'.join(extras) if extras else '')).strip()
            elif tag=='meta':
                parts=rest.split(None,1); key=parts[0] if parts else ''; val=parts[1] if len(parts)>1 else None
                meta[key]=val
            elif tag=='alias': aliases += rest.split()
            elif tag=='cmd': explicit_cmd=True; desc_parts.append((rest + ('\n'+'\n'.join(extras) if extras else '')).strip())
            elif tag in ('flag','option'):
                p=parse_param(tag, rest)
                if p: opts.append(p)
            elif tag=='arg':
                p=parse_param(tag, rest)
                if p: args.append(p)
            elif tag=='env':
                pass
        pending=[]
        if not explicit_cmd:
            if opts or args or meta:
                root.opts += opts; root.args += args; root.metadata.update(meta)
                if fn == 'main': root.fn = 'main'
            return
        parts=fn.split('::')
        cur=root
        for part in parts:
            nm=part
            if nm not in cur.sub: cur.sub[nm]=Command(nm, None, parent=cur)
            cur=cur.sub[nm]
        cur.fn=fn; cur.desc='\n'.join([d for d in desc_parts if d]).strip(); cur.aliases+=aliases
        hyp=fn.split('::')[-1].replace('_','-')
        if hyp != cur.name and hyp not in cur.aliases: cur.aliases.insert(0,hyp)
        cur.opts+=opts; cur.args+=args; cur.metadata.update(meta)
    i=0
    while i < len(lines):
        line=lines[i]
        m=re.match(r'\s*#\s*@([A-Za-z_-]+)\s*(.*)$', line)
        if m:
            tag=m.group(1); rest=m.group(2).rstrip(); extras=[]; j=i+1
            while j<len(lines):
                mm=re.match(r'\s*#\s?(.*)$', lines[j])
                if not mm: break
                cont=mm.group(1)
                if cont.lstrip().startswith('@'): break
                extras.append(cont.rstrip()); j+=1
            pending.append((tag,rest,extras)); i+=1; continue
        fm=re.match(r'\s*([A-Za-z_][A-Za-z0-9_:_-]*)\s*\(\)\s*\{', line) or re.match(r'\s*function\s+([A-Za-z_][A-Za-z0-9_:_-]*)', line)
        if fm:
            flush_for_func(fm.group(1))
        i+=1
    # top-level pending applies to root
    for tag,rest,extras in pending:
        if tag=='describe': root.desc=(rest + ('\n'+'\n'.join(extras) if extras else '')).strip()
        elif tag=='meta':
            parts=rest.split(None,1); root.metadata[parts[0]]=parts[1] if len(parts)>1 else None
        elif tag in ('flag','option'):
            p=parse_param(tag,rest); root.opts.append(p) if p else None
        elif tag=='arg':
            p=parse_param(tag,rest); root.args.append(p) if p else None
        elif tag=='env': pass
    if 'main' in open(path).read():
        if root.fn is None and (root.opts or root.args or not root.sub): root.fn='main'
    if 'inherit-flag-options' in root.metadata:
        for c in root.sub.values():
            existing={o.id for o in c.opts}; c.opts=[o for o in root.opts if o.id not in ('help','version') and o.id not in existing]+c.opts
    return root

def q(s): return shlex.quote(str(s))
def bash_str(s): return shlex.quote(str(s))
def bash_arr(vals): return '('+' '.join('['+str(i)+']='+bash_str(v) for i,v in enumerate(vals))+')'

def run_shell_fn(script, fn):
    if not fn: return ''
    cmd=f'. {shlex.quote(script)} >/dev/null 2>/dev/null || true; {fn}'
    try: return subprocess.check_output(['bash','-lc',cmd], text=True, stderr=subprocess.DEVNULL).strip().splitlines()[0]
    except Exception: return ''

def choices_for(p, script):
    if p.choices is not None: return p.choices
    if p.choice_fn:
        try:
            out=subprocess.check_output(['bash','-lc',f'. {shlex.quote(script)} >/dev/null 2>/dev/null || true; {p.choice_fn}'], text=True, stderr=subprocess.DEVNULL)
            return [x for x in out.splitlines() if x]
        except Exception: return []
    return None

def find_sub(cmd, token):
    for n,c in cmd.sub.items():
        if token==n or token in c.aliases or token==n.replace('_','-'):
            return c
    return None

def select_cmd(root,args):
    cur=root; idx=0
    while idx < len(args):
        c=find_sub(cur,args[idx])
        if not c: break
        cur=c; idx+=1
    if cur is root and root.sub:
        for c in root.sub.values():
            if 'default-subcommand' in c.metadata:
                return c,0
    return cur,idx

def help_text(root, cmd, prog, path_parts):
    lines=[]
    if cmd.desc: lines.append(cmd.desc); lines.append('')
    usage=[prog]+path_parts
    if cmd.sub: usage.append('<COMMAND>')
    reqopts=[]
    if cmd.opts: usage.append('[OPTIONS]')
    for p in cmd.opts:
        if p.required and not p.flag:
            reqopts.append(f"{p.long} <{p.notations[0]}>" + ('...' if p.multiple else ''))
    for a in cmd.args:
        n=a.notations[0]
        if a.required:
            usage.append(f"<{n}>" + ('...' if a.multiple else ''))
        else:
            usage.append(f"[{n}]" + ('...' if a.multiple else ''))
    lines.append('USAGE: '+' '.join(usage+reqopts))
    if cmd.args:
        lines+=['','ARGS:']
        width=max(len((f"<{a.notations[0]}>" if a.required else f"[{a.notations[0]}]") + ('...' if a.multiple else '')) for a in cmd.args)
        for a in cmd.args:
            left=(f"<{a.notations[0]}>" if a.required else f"[{a.notations[0]}]") + ('...' if a.multiple else '')
            lines.append(f"  {left:<{width}}"+(('  '+a.desc) if a.desc else ''))
    if cmd.opts:
        lines+=['','OPTIONS:']
        opts=cmd.opts+[Param('flag','help',names=['-h','--help'],short='-h',long='--help',desc='Print help',flag=True,num_min=0,num_max=0)]
        lefts=[]
        for p in opts:
            names=[]
            if p.short: names.append(p.short)
            if p.long: names.append(p.long)
            left=', '.join(names) if names else p.names[0]
            if not p.flag: left += ' <'+(p.notations[0] if p.notations else p.id.upper())+'>' + ('...' if p.multiple and p.num_max==1 else '')
            lefts.append(left)
        width=max(len(x) for x in lefts)
        for left,p in zip(lefts,opts):
            desc=p.desc
            ch=choices_for(p, '') if False else p.choices
            extra=''
            if p.choices: extra+=' [possible values: '+', '.join(p.choices)+']'
            if p.default is not None: extra+=' [default: '+p.default+']'
            lines.append(f"  {left:<{width}}"+(('  '+desc+extra) if (desc or extra) else ''))
    if cmd.sub:
        lines+=['','COMMANDS:']
        entries=[]
        for c in cmd.sub.values():
            name=c.name; aliases=[]
            for a in c.aliases:
                if a!=name.replace('_','-'): aliases.append(a)
            d=c.desc.split('\n')[0] if c.desc else ''
            if aliases: d += (' ' if d else '')+'[aliases: '+', '.join(aliases)+']'
            entries.append((name,d))
        w=max(len(n) for n,d in entries)
        for n,d in entries: lines.append(f"  {n:<{w}}"+(('  '+d) if d else ''))
    return '\n'.join(lines)+'\n'

def parse_args(root, cmd, argv, script):
    vals={}; arrays=set(); pos=[]; remaining=[]
    for p in cmd.opts:
        if p.flag: vals[p.id]='0'
        elif p.multiple or p.num_max>1: vals[p.id]=[]; arrays.add(p.id)
        else: vals[p.id]=''
        if p.default is not None: vals[p.id]=p.default
        if p.default_fn: vals[p.id]=run_shell_fn(script,p.default_fn)
        if p.env and os.environ.get(p.env): vals[p.id]=os.environ[p.env]
    i=0; positionals=[]
    name_map={}
    for p in cmd.opts:
        for n in p.names:
            name_map[n]=p
    while i < len(argv):
        a=argv[i]
        if a=='--': positionals += argv[i+1:]; break
        matched=None; optval=None
        if '=' in a:
            k,v=a.split('=',1)
            if k in name_map: matched=name_map[k]; optval=v
        if not matched and ':' in a:
            k,v=a.split(':',1)
            if k in name_map: matched=name_map[k]; optval=v
        if not matched and a in name_map: matched=name_map[a]
        if not matched:
            for nm, pp in name_map.items():
                if nm.endswith('-') and a.startswith(nm) and len(a)>len(nm):
                    matched=pp; optval=a[len(nm):]; break
        if not matched and len(a)>2 and a.startswith('-') and not a.startswith('--'):
            # combine shorts flags -rf
            chars=['-'+c for c in a[1:]]
            if all(c in name_map and name_map[c].flag for c in chars):
                for c in chars:
                    p=name_map[c]; vals[p.id]=str(int(vals.get(p.id,'0') or 0)+1) if p.multi_occurs else '1'
                i+=1; continue
        if matched:
            p=matched
            if p.flag:
                vals[p.id]=str(int(vals.get(p.id,'0') or 0)+1) if p.multi_occurs else '1'; i+=1; continue
            if p.terminated:
                got=[]
                if optval is not None: got.append(optval)
                got += argv[i+1:]; i=len(argv)
            else:
                got=[]
                if optval is not None: got=[optval]
                else:
                    need=p.num_min
                    got=argv[i+1:i+1+need]; i += 1+len(got)
                    if len(got)<need: raise ValueError(f"error: a value is required for `{a} <{p.notations[0]}>`")
                    extra=0
                    while p.num_max>p.num_min and i<len(argv) and not argv[i].startswith('-') and extra < p.num_max-p.num_min:
                        got.append(argv[i]); i+=1; extra+=1
                    i-=0
                if optval is not None: i+=1
            final=[]
            for g in got:
                final += g.split(p.delimiter) if p.delimiter else [g]
            ch=choices_for(p, script)
            if ch and not p.skip_choice_check:
                for g in final:
                    if g not in ch: raise ValueError(f"error: invalid value `{g}` for `{p.long} <{p.notations[0]}>`\n  [possible values: {', '.join(ch)}]")
            if p.multiple or p.num_max>1:
                if not isinstance(vals.get(p.id), list): vals[p.id]=[]
                vals[p.id].extend(final); arrays.add(p.id)
            else: vals[p.id]=final[0] if final else ''
            continue
        positionals.append(a); i+=1
    if not cmd.args:
        pos = positionals[:]
        return vals, arrays, pos
    pi=0
    for p in cmd.args:
        if p.terminated or p.multiple:
            got=positionals[pi:]; pi=len(positionals)
        elif pi < len(positionals): got=[positionals[pi]]; pi+=1
        else: got=[]
        if not got and p.env and os.environ.get(p.env): got=[os.environ[p.env]]
        if not got and p.default is not None: got=[p.default]
        if not got and p.default_fn: got=[run_shell_fn(script,p.default_fn)]
        if p.required and not got:
            raise ValueError('error: the following required arguments were not provided:\n  <'+p.notations[0]+'>')
        ch=choices_for(p, script)
        if ch and not p.skip_choice_check:
            for g in got:
                items=g.split(p.delimiter) if p.delimiter else [g]
                for it in items:
                    if it not in ch: raise ValueError(f"error: invalid value `{it}` for `{'['+p.notations[0]+']...' if p.multiple else '<'+p.notations[0]+'>'}`\n  [possible values: {', '.join(ch)}]")
        if p.multiple:
            vals[p.id]=[]; arrays.add(p.id)
            for g in got: vals[p.id].extend(g.split(p.delimiter) if p.delimiter else [g])
        else: vals[p.id]=got[0] if got else ''
        pos += got
    if pi < len(positionals):
        raise ValueError('error: unexpected argument `'+positionals[pi]+'` found')
    return vals, arrays, pos

def emit_eval(script,args):
    root=parse_file(script); cmd,idx=select_cmd(root,args); rest=args[idx:]
    prog=script_name(script); path=[]; c=cmd
    while c and c.parent: path.insert(0,c.name); c=c.parent
    if rest and rest[0] in ('-h','--help'):
        print('cat <<\'EOF\''); print(help_text(root,cmd,prog,path), end=''); print('EOF'); print('exit 0'); return
    if args and args[0] in ('-h','--help') and cmd is root:
        print('cat <<\'EOF\''); print(help_text(root,cmd,prog,[]), end=''); print('EOF'); print('exit 0'); return
    if args and args[0] in ('-V','--version'):
        print(f"echo {bash_str(prog+' 0.0.0')}"); print('exit 0'); return
    if cmd.sub and cmd.fn is None and not rest:
        print('cat <<\'EOF\''); print(help_text(root,cmd,prog,path), end=''); print('EOF'); print('exit 0'); return
    try: vals, arrays, pos=parse_args(root,cmd,rest,script)
    except ValueError as e:
        print('echo '+bash_str(str(e))+' >&2'); print('exit 1'); return
    lines=[]
    fullargs=[prog]+args
    lines.append('argc__args='+bash_arr(fullargs))
    lines.append('argc__positionals='+bash_arr(pos))
    if cmd.fn: lines.append('argc__fn='+bash_str(cmd.fn))
    for k,v in vals.items():
        if isinstance(v, list):
            if len(v)>0: lines.append(f'argc_{k}='+bash_arr(v))
        elif v!='' and v!='0':
            lines.append(f'argc_{k}='+bash_str(v))
    fn=cmd.fn
    if fn:
        lines.append('set -- "${argc__positionals[@]}"')
        lines.append('if declare -F _argc_before >/dev/null; then _argc_before; fi')
        lines.append(f'{fn} "$@"')
        lines.append('argc__status=$?')
        lines.append('if declare -F _argc_after >/dev/null; then _argc_after; fi')
        lines.append('exit $argc__status')
    print('\n'.join(lines))

def export_json(path):
    def conv(c):
        return {'name':c.name,'describe':c.desc,'aliases':c.aliases,'flag_options':[vars(p) for p in c.opts]+([] if c.sub else []),'positionals':[vars(p) for p in c.args],'subcommands':[conv(x) for x in c.sub.values()],'command_fn':c.fn}
    print(json.dumps(conv(parse_file(path)), indent=2))

def cmd_path_parts(root, cmd):
    parts=[]; c=cmd
    while c and c.parent: parts.insert(0,c.name); c=c.parent
    return parts

def compgen(shell, script, cargs):
    root=parse_file(script)
    args=cargs[1:] if cargs and cargs[0]==script_name(script) else cargs[:]
    cur,idx=select_cmd(root,args)
    rest=args[idx:]
    prefix=rest[-1] if rest else ''
    if cur.sub and (not rest or not prefix.startswith('-')):
        for c in cur.sub.values():
            if c.name.startswith(prefix):
                d=c.desc.split('\n')[0] if c.desc else ''
                print(f"{c.name} ({d})" if d else c.name+' ')
        if 'help'.startswith(prefix): print('help (Show help for a command)')
        return
    opts=cur.opts+[Param('flag','help',names=['-h','--help'],short='-h',long='--help',desc='Print help',flag=True), Param('flag','version',names=['-V','--version'],short='-V',long='--version',desc='Print version',flag=True)]
    for o in opts:
        for n in [o.long,o.short]:
            if n and n.startswith(prefix): print(n+' '+(('('+o.desc+')') if o.desc else ''))

def mangen(path,outdir):
    root=parse_file(path); os.makedirs(outdir, exist_ok=True)
    def one(c, parts):
        name='-'.join([script_name(path)]+parts)
        fn=os.path.join(outdir,name+'.1')
        ht=help_text(root,c,script_name(path),parts)
        with open(fn,'w') as f:
            f.write(f'.TH {name.upper()} 1  "{name} 0.0.0" \n')
            first=(c.desc.split('\n')[0] if c.desc else '')
            f.write(f'.SH NAME\n{name} - {first}\n.SH SYNOPSIS\n')
            for line in ht.splitlines():
                if line.startswith('USAGE: '): f.write(line[7:]+'\n')
            f.write('.SH DESCRIPTION\n'+ht)
        print('saved '+fn)
        for sub in c.sub.values(): one(sub, parts+[sub.name])
    one(root, [])

def build_script(path,outpath):
    out=outpath
    if os.path.isdir(outpath): out=os.path.join(outpath, os.path.basename(path))
    data=open(path).read()
    py=os.path.abspath(sys.argv[0])
    data=data.replace('argc --argc-eval', f'python3 {shlex.quote(py)} --argc-eval')
    with open(out,'w') as f: f.write(data)
    os.chmod(out,0o755)

def main():
    av=sys.argv[1:]
    if not av:
        print('Argcfile not found, try `argc --argc-help` for help.', file=sys.stderr); sys.exit(1)
    if av[0]=='--argc-help':
        print('A bash cli framework, also a bash-based command runner - https://github.com/sigoden/argc\n')
        print('USAGE:\n    argc --argc-eval <FILE> <ARGS~>            Use `eval "$(argc --argc-eval "$0" "$@")"`\n    argc --argc-create <RECIPES~>              Create a boilerplate argcfile\n    argc --argc-run <FILE> <ARGS~>             Run an argc-based script\n    argc --argc-build <FILE> <OUTPATH?>        Generate bashscript without argc dependency\n    argc --argc-mangen <FILE> <OUTDIR>         Generate man pages\n    argc --argc-completions <SHELL> <CMDS>     Generate shell completion scripts\n    argc --argc-compgen <SHELL> <FILE> <ARGS>  Generate completion candidates\n    argc --argc-export <FILE>                  Export command line definitions as json\n    argc --argc-parallel <FILE> <ARGS~>        Run functions in parallel\n    argc --argc-script-path                    Print current argcfile path\n    argc --argc-shell-path                     Print current shell path\n    argc --argc-help                           Print help information\n    argc --argc-version                        Print version information')
    elif av[0]=='--argc-version': print(VERSION)
    elif av[0]=='--argc-shell-path': print(os.environ.get('SHELL','/bin/bash'))
    elif av[0]=='--argc-script-path': print(os.getcwd()+'/Argcfile.sh')
    elif av[0]=='--argc-eval' and len(av)>=2: emit_eval(av[1], av[2:])
    elif av[0]=='--argc-run' and len(av)>=2:
        os.environ['PATH']=os.getcwd()+os.pathsep+os.environ.get('PATH','')
        os.execvp('bash',['bash',av[1]]+av[2:])
    elif av[0]=='--argc-export' and len(av)>=2: export_json(av[1])
    elif av[0]=='--argc-compgen' and len(av)>=4: compgen(av[1], av[2], av[3:])
    elif av[0]=='--argc-mangen' and len(av)>=3: mangen(av[1], av[2])
    elif av[0] in ('--argc-build','--argc-export-script') and len(av)>=2: build_script(av[1], av[2] if len(av)>2 else av[1]+'.out')
    elif av[0]=='--argc-completions': print('# completion script generated by argc')
    elif av[0]=='--argc-create': print('#!/usr/bin/env bash\n\neval "$(argc --argc-eval "$0" "$@")"')
    elif av[0] in ('--help','-h','--version','-V'):
        print('Argcfile not found, try `argc --argc-help` for help.', file=sys.stderr); sys.exit(1)
    else:
        print('Argcfile not found, try `argc --argc-help` for help.', file=sys.stderr); sys.exit(1)
if __name__=='__main__': main()
