#!/usr/bin/env python3
import argparse
import fnmatch
import glob as globmod
import os
import re
import shutil
import stat
import sys


VERSION = "xcp 0.24.3"
DESCRIPTION = "A (partial) clone of the Unix `cp` command with progress and pluggable drivers."
SHORT_HELP = """A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  Path list

Options:
  -v, --verbose...
          Verbosity
  -r, --recursive
          Copy directories recursively
  -L, --dereference
          Dereference symlinks in source
  -w, --workers <WORKERS>
          Number of parallel workers [default: 4]
      --block-size <BLOCK_SIZE>
          Block size for operations [default: 1MB]
  -n, --no-clobber
          Do not overwrite an existing file
  -f, --force
          Force (compatability only)
      --gitignore
          Use .gitignore if present
  -g, --glob
          Expand file patterns
      --no-progress
          Disable progress bar
      --no-perms
          Do not copy the file permissions
      --no-timestamps
          Do not copy the file timestamps
  -o, --ownership
          Copy ownership
      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel' [default: parfile]
  -T, --no-target-directory
          Target should not be a directory
      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target
      --fsync
          Sync each file to disk after writing
      --reflink <REFLINK>
          Reflink options [default: auto]
      --backup <BACKUP>
          Backup options [default: none]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""

LONG_HELP = """A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          Path list.
          
          Source and destination files, or multiple source(s) to a directory.

Options:
  -v, --verbose...
          Verbosity.
          
          Can be specified multiple times to increase logging.

  -r, --recursive
          Copy directories recursively

  -L, --dereference
          Dereference symlinks in source
          
          Follow symlinks, possibly recursively, when copying source files.

  -w, --workers <WORKERS>
          Number of parallel workers.
          
          Default is 4; if the value is negative or 0 it uses the number of logical CPUs.
          
          [default: 4]

      --block-size <BLOCK_SIZE>
          Block size for operations.
          
          Accepts standard size modifiers like "M" and "GB". Actual usage internally depends on the driver.
          
          [default: 1MB]

  -n, --no-clobber
          Do not overwrite an existing file

  -f, --force
          Force (compatability only)
          
          Overwrite files; this is the default behaviour, this flag is for compatibility with `cp` only. See `--no-clobber` for the inverse flag. Using this in conjunction with `--no-clobber` will cause an error.

      --gitignore
          Use .gitignore if present.
          
          NOTE: This is fairly basic at the moment, and only honours a .gitignore in the directory root for directory copies; global or sub-directory ignores are skipped.

  -g, --glob
          Expand file patterns.
          
          Glob (expand) filename patterns natively (note; the shell may still do its own expansion first)

      --no-progress
          Disable progress bar

      --no-perms
          Do not copy the file permissions

      --no-timestamps
          Do not copy the file timestamps

  -o, --ownership
          Copy ownership.
          
          Whether to copy ownship (user/group).  This option requires root permissions or appropriate capabilities; if the attempt to copy ownership fails a warning is issued but the operation continues.

      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel'.
          
          Currently there are 2; the default "parfile", which parallelises copies across workers at the file level, and an experimental "parblock" driver, which parellelises at the block level. See also '--block-size'.
          
          [default: parfile]

  -T, --no-target-directory
          Target should not be a directory.
          
          Analogous to cp's no-target-directory. Expected behavior is that when copying a directory to another directory, instead of creating a sub-folder in target, overwrite target.

      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target

      --fsync
          Sync each file to disk after writing

      --reflink <REFLINK>
          Reflink options.
          
          Whether and how to use reflinks. 'auto' (the default) will attempt to reflink and fallback to a copy if it is not possible, 'always' will return an error if it cannot reflink, and 'never' will always perform a full data copy.
          
          Note: when using Linux accelerated copy operations (the default when available) the kernel may choose to reflink rather than perform a fully copy regardless of this setting.
          
          [default: auto]

      --backup <BACKUP>
          Backup options
          
          Whether to create backups of overwritten files. Current options are 'none'/'off', or 'numbered', or 'auto'. Numbered backups follow the semantics of `cp` numbered backups (e.g. `file.txt.~123~`). 'auto' will only create a numbered backup if a previous backups exists. Default is 'none'.
          
          [default: none]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


class XcpError(Exception):
    pass


class Parser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        self.exit(2, f"error: {message}\n")


def build_parser():
    p = Parser(
        prog="executable",
        description=DESCRIPTION,
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("-v", "--verbose", action="count", default=0, help="Verbosity")
    p.add_argument("-r", "--recursive", action="store_true", help="Copy directories recursively")
    p.add_argument("-L", "--dereference", action="store_true", help="Dereference symlinks in source")
    p.add_argument("-w", "--workers", default="4", help="Number of parallel workers [default: 4]")
    p.add_argument("--block-size", default="1MB", help="Block size for operations [default: 1MB]")
    p.add_argument("-n", "--no-clobber", action="store_true", help="Do not overwrite an existing file")
    p.add_argument("-f", "--force", action="store_true", help="Force (compatability only)")
    p.add_argument("--gitignore", action="store_true", help="Use .gitignore if present")
    p.add_argument("-g", "--glob", action="store_true", dest="do_glob", help="Expand file patterns")
    p.add_argument("--no-progress", action="store_true", help="Disable progress bar")
    p.add_argument("--no-perms", action="store_true", help="Do not copy the file permissions")
    p.add_argument("--no-timestamps", action="store_true", help="Do not copy the file timestamps")
    p.add_argument("-o", "--ownership", action="store_true", help="Copy ownership")
    p.add_argument("--driver", default="parfile", help="Driver to use, defaults to 'file-parallel' [default: parfile]")
    p.add_argument("-T", "--no-target-directory", action="store_true", help="Target should not be a directory")
    p.add_argument("--target-directory", help="Copy into a subdirectory of the target")
    p.add_argument("--fsync", action="store_true", help="Sync each file to disk after writing")
    p.add_argument("--reflink", default="auto", help="Reflink options [default: auto]")
    p.add_argument("--backup", default="none", help="Backup options [default: none]")
    p.add_argument("-h", "--help", action="help", help="Print help (see more with '--help')")
    p.add_argument("-V", "--version", action="store_true", help="Print version")
    p.add_argument("paths", nargs="*", help="Path list")
    return p


def parse_args(argv):
    p = build_parser()
    try:
        ns = p.parse_intermixed_args(argv)
    except AttributeError:
        ns = p.parse_args(argv)
    if ns.version:
        print(VERSION)
        sys.exit(0)
    if ns.driver not in ("parfile", "file-parallel", "parblock"):
        sys.stderr.write(f"error: invalid value '{ns.driver}' for '--driver <DRIVER>': Unknown driver: {ns.driver}\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        sys.exit(2)
    if ns.reflink not in ("auto", "always", "never"):
        sys.stderr.write(f"error: invalid value '{ns.reflink}' for '--reflink <REFLINK>': Invalid arguments: Unexpected value for 'reflink': {ns.reflink}\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        sys.exit(2)
    if ns.backup not in ("none", "off", "numbered", "auto"):
        sys.stderr.write(f"error: invalid value '{ns.backup}' for '--backup <BACKUP>': Invalid arguments: Unexpected value for 'backup': {ns.backup}\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        sys.exit(2)
    if ns.force and ns.no_clobber:
        raise XcpError("Invalid arguments: --force and --noclobber cannot be set at the same time.")
    return ns


def expand_sources(ns):
    paths = list(ns.paths)
    if ns.target_directory is not None:
        paths.append(ns.target_directory)
    if ns.do_glob:
        expanded = []
        for path in paths[:-1] if len(paths) > 1 else paths:
            matches = sorted(globmod.glob(path))
            expanded.extend(matches)
        if len(paths) > 1:
            expanded.append(paths[-1])
        paths = expanded
        if not paths or (ns.target_directory is None and len(paths) < 2) or (ns.target_directory is not None and len(paths) < 2):
            raise XcpError("Invalid source: No source files found.")
    return paths


def numbered_backup_name(path):
    n = 1
    while True:
        candidate = f"{path}.~{n}~"
        if not os.path.lexists(candidate):
            return candidate
        n += 1


def has_numbered_backup(path):
    directory = os.path.dirname(path) or "."
    base = os.path.basename(path)
    try:
        names = os.listdir(directory)
    except FileNotFoundError:
        return False
    pat = re.compile(re.escape(base) + r"\.~[0-9]+~$")
    return any(pat.match(name) for name in names)


def maybe_backup(path, mode):
    if not os.path.lexists(path):
        return
    if mode in ("none", "off"):
        return
    if mode == "auto" and not has_numbered_backup(path):
        return
    os.replace(path, numbered_backup_name(path))


def read_gitignore(root):
    ignore_file = os.path.join(root, ".gitignore")
    patterns = []
    try:
        with open(ignore_file, "r", encoding="utf-8", errors="ignore") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                patterns.append(line)
    except FileNotFoundError:
        pass
    return patterns


def ignored(rel, is_dir, patterns):
    rel = rel.replace(os.sep, "/")
    name = rel.rsplit("/", 1)[-1]
    for pat in patterns:
        p = pat.strip()
        if p.startswith("/"):
            p = p[1:]
        dir_only = p.endswith("/")
        if dir_only:
            p = p[:-1]
        if dir_only and not is_dir:
            continue
        if "/" in p:
            if fnmatch.fnmatch(rel, p) or rel == p or rel.startswith(p + "/"):
                return True
        else:
            if fnmatch.fnmatch(name, p) or fnmatch.fnmatch(rel, p):
                return True
            if is_dir and (rel == p or rel.startswith(p + "/")):
                return True
    return False


def ensure_parent(path):
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)


def copy_metadata(src, dst, ns, follow):
    if not ns.no_timestamps:
        try:
            shutil.copystat(src, dst, follow_symlinks=follow)
        except OSError:
            pass
    elif not ns.no_perms:
        try:
            mode = os.stat(src, follow_symlinks=follow).st_mode & 0o7777
            os.chmod(dst, mode, follow_symlinks=follow)
        except OSError:
            pass
    if ns.ownership:
        try:
            st = os.stat(src, follow_symlinks=follow)
            os.chown(dst, st.st_uid, st.st_gid, follow_symlinks=follow)
        except OSError as e:
            sys.stderr.write(f"Warning: failed to copy ownership for {dst}: {e}\n")


def fsync_file(path):
    try:
        fd = os.open(path, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError:
        pass


def copy_file(src, dst, ns):
    if os.path.lexists(dst):
        if ns.no_clobber:
            raise XcpError(f"Destination Exists: Destination file exists and --no-clobber is set., {dst}")
        maybe_backup(dst, ns.backup)
    ensure_parent(dst)
    if ns.no_timestamps and ns.no_perms:
        shutil.copyfile(src, dst, follow_symlinks=ns.dereference)
    elif ns.no_timestamps:
        shutil.copy(src, dst, follow_symlinks=ns.dereference)
    else:
        shutil.copy2(src, dst, follow_symlinks=ns.dereference)
    if ns.fsync and not os.path.islink(dst):
        fsync_file(dst)


def copy_symlink(src, dst, ns):
    if ns.dereference:
        copy_any(src, dst, ns, None)
        return
    if os.path.lexists(dst):
        if ns.no_clobber:
            raise XcpError(f"Destination Exists: Destination file exists and --no-clobber is set., {dst}")
        maybe_backup(dst, ns.backup)
        if os.path.lexists(dst):
            if os.path.isdir(dst) and not os.path.islink(dst):
                shutil.rmtree(dst)
            else:
                os.unlink(dst)
    ensure_parent(dst)
    os.symlink(os.readlink(src), dst)
    copy_metadata(src, dst, ns, False)


def copy_special(src, dst, ns):
    mode = os.lstat(src).st_mode
    if stat.S_ISFIFO(mode):
        if os.path.lexists(dst):
            if ns.no_clobber:
                raise XcpError(f"Destination Exists: Destination file exists and --no-clobber is set., {dst}")
            maybe_backup(dst, ns.backup)
            if os.path.lexists(dst):
                os.unlink(dst)
        os.mkfifo(dst, mode & 0o777)
        copy_metadata(src, dst, ns, False)
    else:
        raise XcpError(f"Invalid source: Unsupported file type., {src}")


def copy_dir_contents(src, dst, ns, patterns):
    os.makedirs(dst, exist_ok=True)
    copy_metadata(src, dst, ns, True)
    for root, dirs, files in os.walk(src, followlinks=ns.dereference):
        relroot = os.path.relpath(root, src)
        if relroot == ".":
            relroot = ""
        kept_dirs = []
        for d in dirs:
            rel = os.path.join(relroot, d) if relroot else d
            full = os.path.join(root, d)
            is_link_dir = os.path.islink(full)
            if ns.gitignore and ignored(rel, True, patterns):
                continue
            if is_link_dir and not ns.dereference:
                target = os.path.join(dst, rel)
                copy_symlink(full, target, ns)
                continue
            kept_dirs.append(d)
            os.makedirs(os.path.join(dst, rel), exist_ok=True)
        dirs[:] = kept_dirs
        for f in files:
            rel = os.path.join(relroot, f) if relroot else f
            if ns.gitignore and ignored(rel, False, patterns):
                continue
            copy_any(os.path.join(root, f), os.path.join(dst, rel), ns, patterns)


def copy_dir(src, dst, ns):
    if not ns.recursive:
        raise XcpError("Invalid source: Source is directory and --recursive not specified.")
    if os.path.lexists(dst) and not os.path.isdir(dst):
        raise XcpError("Invalid destination: Cannot copy a directory to a file.")
    patterns = read_gitignore(src) if ns.gitignore else []
    copy_dir_contents(src, dst, ns, patterns)


def copy_any(src, dst, ns, patterns=None):
    try:
        st = os.stat(src) if ns.dereference else os.lstat(src)
    except FileNotFoundError:
        raise XcpError("Invalid source: Source does not exist.")
    mode = st.st_mode
    if stat.S_ISLNK(mode):
        copy_symlink(src, dst, ns)
    elif stat.S_ISDIR(mode):
        copy_dir(src, dst, ns)
    elif stat.S_ISREG(mode):
        copy_file(src, dst, ns)
    else:
        copy_special(src, dst, ns)


def destination_for(src, dest, multiple, ns):
    if ns.no_target_directory:
        return dest
    if multiple or (os.path.isdir(dest) and not os.path.islink(dest)):
        return os.path.join(dest, os.path.basename(src.rstrip(os.sep)))
    return dest


def run(ns):
    paths = expand_sources(ns)
    if len(paths) < 2:
        raise XcpError("Invalid arguments: Insufficient arguments")
    dest = paths[-1]
    sources = paths[:-1]
    if ns.target_directory is not None:
        os.makedirs(dest, exist_ok=True)
    elif len(sources) > 1 and not os.path.isdir(dest):
        raise XcpError("Invalid destination: Multiple sources and destination is not a directory.")
    failures = []
    for src in sources:
        if not os.path.lexists(src):
            failures.append(XcpError("Invalid source: Source does not exist."))
            continue
        out = destination_for(src, dest, len(sources) > 1, ns)
        try:
            copy_any(src, out, ns)
        except XcpError as e:
            failures.append(e)
    if failures:
        raise failures[0]


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--help" in argv:
        sys.stdout.write(LONG_HELP)
        return 0
    if "-h" in argv:
        sys.stdout.write(SHORT_HELP)
        return 0
    try:
        ns = parse_args(argv)
        run(ns)
        return 0
    except XcpError as e:
        msg = str(e)
        if msg.startswith("Destination Exists:"):
            sys.stderr.write(f"Error: {msg}\n")
        else:
            sys.stderr.write(f"Error: {msg}\n")
        return 1
    except BrokenPipeError:
        return 1
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1


if __name__ == "__main__":
    sys.exit(main())
