#!/usr/bin/env python3
import os
import re
import sys
import textwrap
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field


XSD_NS = "http://www.w3.org/2001/XMLSchema"
WSDL_NS = "http://schemas.xmlsoap.org/wsdl/"
SOAP_ENV = "http://schemas.xmlsoap.org/soap/envelope/"


def local(tag):
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def ns(tag):
    return tag[1:].split("}", 1)[0] if tag.startswith("{") else ""


def children(el, name=None):
    out = [c for c in list(el) if name is None or local(c.tag) == name]
    return out


def first_child(el, *names):
    for c in list(el):
        if local(c.tag) in names:
            return c
    return None


def attr_local(el, name, default=""):
    return el.attrib.get(name, default)


def split_qname(value):
    if not value:
        return "", ""
    if ":" in value:
        return value.split(":", 1)
    return "", value


INITIALISMS = {}


def camel(name, public=True):
    if not name:
        return name
    parts = re.split(r"[^A-Za-z0-9]+|(?<=[a-z])(?=[A-Z])", name)
    parts = [p for p in parts if p]
    if not parts:
        return name
    words = []
    for p in parts:
        low = p.lower()
        if low in INITIALISMS:
            words.append(INITIALISMS[low])
        elif p.isupper() and len(p) > 1:
            words.append(p[:1] + p[1:].lower())
        else:
            words.append(p[:1].upper() + p[1:])
    out = "".join(words)
    if not public:
        out = out[:1].lower() + out[1:]
    if out and out[0].isdigit():
        out = "N" + out
    return out


def const_suffix(value):
    if value == "":
        return "EmptyString"
    return camel(value.replace("+", " Plus ").replace("-", " "))


def lower_first(s):
    return s[:1].lower() + s[1:] if s else s


def doc_text(el):
    ann = first_child(el, "annotation")
    if ann is None:
        return ""
    docs = []
    for d in children(ann, "documentation"):
        t = "".join(d.itertext()).strip()
        if t:
            docs.append(re.sub(r"\s+", " ", t))
    return "\n".join(docs)


def go_comment(text, indent=""):
    if not text:
        return ""
    lines = []
    for para in text.splitlines():
        wrapped = textwrap.wrap(para, width=78) or [""]
        for w in wrapped:
            lines.append(f"{indent}// {w}".rstrip())
    return "\n".join(lines) + "\n"


def quote(s):
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


@dataclass
class Field:
    name: str
    xml_name: str
    typ: str
    doc: str = ""
    attr: bool = False
    repeated: bool = False
    pointer: bool = False
    namespace: str = ""
    anonymous: list = field(default_factory=list)
    chardata: bool = False


@dataclass
class TypeDef:
    name: str
    kind: str
    namespace: str = ""
    fields: list = field(default_factory=list)
    base: str = "string"
    enum_values: list = field(default_factory=list)
    doc: str = ""
    xml_root: bool = False
    alias_custom_xml: bool = False


@dataclass
class Operation:
    name: str
    input_el: str = ""
    output_el: str = ""
    action: str = "''"


class Model:
    def __init__(self):
        self.target_ns = ""
        self.schemas = []
        self.types = []
        self.type_by_name = {}
        self.elements = {}
        self.messages = {}
        self.port_types = {}
        self.actions = {}
        self.raw_wsdl = ""

    def add_type(self, td):
        if not td.name or td.name in self.type_by_name:
            return
        self.types.append(td)
        self.type_by_name[td.name] = td


class Parser:
    def __init__(self, path):
        self.path = path
        self.base_dir = os.path.dirname(os.path.abspath(path))
        self.model = Model()

    def parse(self):
        with open(self.path, "r", encoding="utf-8", errors="replace") as f:
            self.model.raw_wsdl = f.read()
        root = ET.fromstring(self.model.raw_wsdl)
        self.model.target_ns = root.attrib.get("targetNamespace", "")
        self._parse_root(root)
        return self.model

    def _parse_root(self, root):
        for types in children(root, "types"):
            for schema in list(types):
                if local(schema.tag) == "schema":
                    self._parse_schema(schema)
        for msg in children(root, "message"):
            name = msg.attrib.get("name", "")
            part = first_child(msg, "part")
            if part is not None:
                self.model.messages[name] = split_qname(part.attrib.get("element") or part.attrib.get("type"))[1]
        for binding in children(root, "binding"):
            for op in children(binding, "operation"):
                opname = op.attrib.get("name", "")
                action = "''"
                for c in list(op):
                    if local(c.tag) == "operation" and "soapAction" in c.attrib:
                        action = c.attrib.get("soapAction", "")
                self.model.actions[opname] = action
        for pt in children(root, "portType"):
            ops = []
            for op in children(pt, "operation"):
                oper = Operation(op.attrib.get("name", ""))
                inp = first_child(op, "input")
                out = first_child(op, "output")
                if inp is not None:
                    oper.input_el = self.model.messages.get(split_qname(inp.attrib.get("message", ""))[1], "")
                if out is not None:
                    oper.output_el = self.model.messages.get(split_qname(out.attrib.get("message", ""))[1], "")
                oper.action = self.model.actions.get(oper.name, "''")
                ops.append(oper)
            self.model.port_types[pt.attrib.get("name", "Service")] = ops

    def _parse_schema(self, schema):
        self.model.schemas.append(schema)
        schema_ns = schema.attrib.get("targetNamespace", self.model.target_ns)
        for inc in list(schema):
            if local(inc.tag) in ("include", "import") and inc.attrib.get("schemaLocation"):
                loc = inc.attrib["schemaLocation"]
                if "://" not in loc:
                    p = os.path.join(self.base_dir, loc)
                    if os.path.exists(p):
                        try:
                            self._parse_schema(ET.parse(p).getroot())
                        except Exception:
                            pass
        for st in children(schema, "simpleType"):
            self._simple_type(st, st.attrib.get("name", ""), schema_ns)
        for el in children(schema, "element"):
            self._element(el, schema_ns, top=True)
        for ct in children(schema, "complexType"):
            self._complex_type(ct, ct.attrib.get("name", ""), schema_ns, top=False)

    def _simple_type(self, el, name, namespace):
        if not name:
            return None
        rest = first_child(el, "restriction")
        base = "string"
        values = []
        if rest is not None:
            base = go_type(rest.attrib.get("base", "string"), name_hint=name)
            for enum in children(rest, "enumeration"):
                values.append((enum.attrib.get("value", ""), doc_text(enum)))
        td = TypeDef(camel(name), "enum" if values else "alias", namespace=namespace,
                     base=base, enum_values=values, doc=doc_text(el))
        self.model.add_type(td)
        return td.name

    def _element(self, el, namespace, top=False):
        name = el.attrib.get("name") or split_qname(el.attrib.get("ref", ""))[1]
        if not name:
            return None
        type_attr = el.attrib.get("type", "")
        doc = doc_text(el)
        complex_el = first_child(el, "complexType")
        simple_el = first_child(el, "simpleType")
        go_name = camel(name)
        if complex_el is not None:
            td = self._complex_type(complex_el, name, namespace, top=top)
            if td:
                td.doc = doc or td.doc
                td.xml_root = top
                self.model.elements[name] = td.name
                return td.name
        if simple_el is not None:
            rest = first_child(simple_el, "restriction")
            values = []
            base = "string"
            if rest is not None:
                base = go_type(rest.attrib.get("base", "string"), name_hint=name)
                values = [(e.attrib.get("value", ""), doc_text(e)) for e in children(rest, "enumeration")]
            td = TypeDef(go_name, "enum" if values else "alias", namespace=namespace,
                         base=base, enum_values=values, doc=doc, xml_root=top)
            self.model.add_type(td)
            self.model.elements[name] = td.name
            return td.name
        if type_attr:
            typ = go_type(type_attr, name_hint=name)
            if top:
                td = TypeDef(go_name, "alias", namespace=namespace, base=typ, doc=doc, xml_root=True,
                             alias_custom_xml=typ == "soap.XSDDateTime")
                self.model.add_type(td)
                self.model.elements[name] = td.name
                return td.name
            return typ
        return "string"

    def _complex_type(self, ct, name, namespace, top=False):
        if not name:
            return None
        td = TypeDef(camel(name), "struct", namespace=namespace, doc=doc_text(ct), xml_root=top)
        fields = []
        sc = first_child(ct, "simpleContent")
        if sc is not None:
            ext = first_child(sc, "extension")
            base = go_type(ext.attrib.get("base", "string") if ext is not None else "string")
            fields.append(Field("Value", "", base, chardata=True))
            if ext is not None:
                fields.extend(self._attributes(ext, namespace))
        for group_name in ("sequence", "all", "choice"):
            group = first_child(ct, group_name)
            if group is not None:
                for child in list(group):
                    if local(child.tag) == "element":
                        fields.append(self._field_from_element(child, namespace))
        fields.extend(self._attributes(ct, namespace))
        td.fields = fields
        self.model.add_type(td)
        return td

    def _attributes(self, el, namespace):
        fields = []
        for a in children(el, "attribute"):
            nm = a.attrib.get("name") or split_qname(a.attrib.get("ref", ""))[1]
            if not nm:
                continue
            typ = go_type(a.attrib.get("type", "string"), name_hint=nm)
            fields.append(Field(camel(nm), nm, typ, doc_text(a), attr=True, namespace=namespace))
        return fields

    def _field_from_element(self, el, namespace):
        nm = el.attrib.get("name") or split_qname(el.attrib.get("ref", ""))[1]
        maxo = el.attrib.get("maxOccurs", "1")
        mino = el.attrib.get("minOccurs", "1")
        repeated = maxo == "unbounded" or (maxo.isdigit() and int(maxo) > 1)
        pointer = mino == "0"
        doc = doc_text(el)
        anon = []
        complex_el = first_child(el, "complexType")
        simple_el = first_child(el, "simpleType")
        if complex_el is not None:
            sc = first_child(complex_el, "simpleContent")
            if sc is not None:
                ext = first_child(sc, "extension")
                typ = go_type(ext.attrib.get("base", "string") if ext is not None else "string")
                anon.append(Field("Value", "", typ, chardata=True))
                if ext is not None:
                    anon.extend(self._attributes(ext, namespace))
                typ = "struct"
            else:
                anon = self._complex_type_to_fields(complex_el, namespace)
                typ = "struct"
        elif simple_el is not None:
            typ = "string"
        else:
            typ = go_type(el.attrib.get("type", ""), name_hint=nm)
        return Field(camel(nm), nm, typ, doc, False, repeated, pointer, "", anon)

    def _complex_type_to_fields(self, ct, namespace):
        fs = []
        for group_name in ("sequence", "all", "choice"):
            group = first_child(ct, group_name)
            if group is not None:
                for child in list(group):
                    if local(child.tag) == "element":
                        fs.append(self._field_from_element(child, namespace))
        fs.extend(self._attributes(ct, namespace))
        return fs


def go_type(xsd_type, name_hint=""):
    _, t = split_qname(xsd_type)
    if not t:
        return "string"
    m = {
        "string": "string", "normalizedString": "string", "token": "string",
        "anyURI": "string", "NCName": "string", "ID": "string",
        "boolean": "bool", "bool": "bool",
        "float": "float32", "double": "float64", "decimal": "float64",
        "int": "int32", "integer": "int32", "positiveInteger": "int32",
        "nonNegativeInteger": "int32", "short": "int16", "byte": "int8",
        "long": "int64", "unsignedInt": "uint32", "unsignedShort": "uint16",
        "unsignedByte": "uint8", "unsignedLong": "uint64",
        "dateTime": "soap.XSDDateTime", "date": "soap.XSDDate",
        "base64Binary": "[]byte", "hexBinary": "[]byte",
        "anyType": "AnyType",
    }
    return m.get(t, camel(t))


class Generator:
    def __init__(self, model, package):
        self.m = model
        self.package = package
        self.needs_context = bool(model.port_types)
        self.needs_soap = True
        self.needs_time = True

    def client(self):
        out = ["// Code generated by gowsdl DO NOT EDIT.\n\n", f"package {self.package}\n\n"]
        imports = ['"encoding/xml"', '"github.com/hooklift/gowsdl/soap"', '"time"']
        if self.needs_context:
            imports.insert(0, '"context"')
        out.append("import (\n")
        for i in imports:
            out.append(f"\t{i}\n")
        out.append(")\n\n")
        out.append("// against \"unused imports\"\nvar _ time.Time\nvar _ xml.Name\n\n")
        out.append('type AnyType struct {\n\tInnerXML string `xml:",innerxml"`\n}\n\n')
        out.append("type AnyURI string\n\ntype NCName string\n\n")
        for td in self.m.types:
            out.append(self.emit_type(td))
        for pt, ops in self.m.port_types.items():
            out.append(self.emit_service(pt, ops))
        return "".join(out)

    def emit_type(self, td):
        s = go_comment(td.doc)
        if td.kind == "struct":
            s += f"type {td.name} struct {{\n"
            if td.xml_root:
                s += f"\tXMLName xml.Name `xml:\"{td.namespace} {xml_original_name(td.name, self.m.elements)}\"`\n\n"
            for f in td.fields:
                s += self.emit_field(f, "\t")
            s += "}\n\n"
            return s
        s += f"type {td.name} {td.base}\n\n"
        if td.alias_custom_xml and td.base == "soap.XSDDateTime":
            s += f"func (xdt {td.name}) MarshalXML(e *xml.Encoder, start xml.StartElement) error {{\n\treturn soap.XSDDateTime(xdt).MarshalXML(e, start)\n}}\n\n"
            s += f"func (xdt *{td.name}) UnmarshalXML(d *xml.Decoder, start xml.StartElement) error {{\n\treturn (*soap.XSDDateTime)(xdt).UnmarshalXML(d, start)\n}}\n\n"
        if td.kind == "enum":
            s += "const (\n"
            for val, doc in td.enum_values:
                s += "\n" + go_comment(doc, "\t")
                s += f"\t{td.name}{const_suffix(val)} {td.name} = {quote(val)}\n"
            s += ")\n\n"
        return s

    def emit_field(self, f, indent):
        s = "\n" if f.doc else ""
        s += go_comment(f.doc, indent)
        if f.chardata:
            return s + f'{indent}{f.name} {f.typ} `xml:",chardata" json:"-,"`\n\n'
        typ = f.typ
        if f.anonymous:
            typ = ("[]" if f.repeated else "") + "struct {\n"
            for af in f.anonymous:
                typ += self.emit_field(af, indent + "\t")
            typ += indent + "}"
        else:
            if f.pointer and not typ.startswith("*") and typ not in ("string", "bool", "int32", "int64", "float32", "float64"):
                typ = "*" + typ
            if f.repeated:
                typ = "[]" + typ.lstrip("*")
        tagname = f.xml_name
        if f.attr:
            tagname = (f.namespace + " " + tagname) if f.namespace else tagname
            tag = f'`xml:"{tagname},attr,omitempty" json:"{f.xml_name},omitempty"`'
        else:
            tag = f'`xml:"{tagname},omitempty" json:"{tagname},omitempty"`'
        return s + f"{indent}{f.name} {typ} {tag}\n"

    def emit_service(self, pt, ops):
        iface = camel(pt)
        recv = lower_first(iface)
        s = f"type {iface} interface {{\n"
        for op in ops:
            inp = self.m.elements.get(op.input_el, camel(op.input_el) if op.input_el else "interface{}")
            out = self.m.elements.get(op.output_el, camel(op.output_el) if op.output_el else "interface{}")
            s += f"\t{camel(op.name)}(request *{inp}) (*{out}, error)\n\n"
            s += f"\t{camel(op.name)}Context(ctx context.Context, request *{inp}) (*{out}, error)\n"
        s += "}\n\n"
        s += f"type {recv} struct {{\n\tclient *soap.Client\n}}\n\n"
        s += f"func New{iface}(client *soap.Client) {iface} {{\n\treturn &{recv}{{\n\t\tclient: client,\n\t}}\n}}\n\n"
        for op in ops:
            inp = self.m.elements.get(op.input_el, camel(op.input_el) if op.input_el else "interface{}")
            out = self.m.elements.get(op.output_el, camel(op.output_el) if op.output_el else "interface{}")
            action = op.action if op.action == "''" else op.action
            s += f"func (service *{recv}) {camel(op.name)}Context(ctx context.Context, request *{inp}) (*{out}, error) {{\n"
            s += f"\tresponse := new({out})\n"
            s += f"\terr := service.client.CallContext(ctx, {quote(action)}, request, response)\n"
            s += "\tif err != nil {\n\t\treturn nil, err\n\t}\n\n\treturn response, nil\n}\n\n"
            s += f"func (service *{recv}) {camel(op.name)}(request *{inp}) (*{out}, error) {{\n"
            s += f"\treturn service.{camel(op.name)}Context(\n\t\tcontext.Background(),\n\t\trequest,\n\t)\n}}\n\n"
        return s

    def server(self, outname):
        requests = []
        responses = []
        funcs = []
        for ops in self.m.port_types.values():
            for op in ops:
                inp = self.m.elements.get(op.input_el, camel(op.input_el) if op.input_el else "AnyType")
                out = self.m.elements.get(op.output_el, camel(op.output_el) if op.output_el else "AnyType")
                requests.append((inp, inp))
                responses.append((inp, out))
                funcs.append((inp, out))
        raw_wsdl = self.m.raw_wsdl.replace("`", "` + \"`\" + `")
        s = f"""// Code generated by gowsdl DO NOT EDIT.

package {self.package}

import (
\t"encoding/xml"
\t"errors"
\t"fmt"
\t"net/http"
\t"reflect"
\t"strings"
)

var wsdl = `{raw_wsdl}`

var WSDLUndefinedError = errors.New("Server was unable to process request. --> Object reference not set to an instance of an object.")

type SOAPEnvelopeRequest struct {{
\tXMLName xml.Name `xml:"{SOAP_ENV} Envelope"`
\tBody    SOAPBodyRequest
}}

type SOAPBodyRequest struct {{
\tXMLName xml.Name `xml:"{SOAP_ENV} Body"`

"""
        for name, typ in requests:
            s += f"\t{name} *{typ} `xml:,omitempty`\n"
        s += """}

type SOAPEnvelopeResponse struct {
\tXMLName    xml.Name `xml:"soap:Envelope"`
\tPrefixSoap string   `xml:"xmlns:soap,attr"`
\tPrefixXsi  string   `xml:"xmlns:xsi,attr"`
\tPrefixXsd  string   `xml:"xmlns:xsd,attr"`

\tBody SOAPBodyResponse
}

func NewSOAPEnvelopResponse() *SOAPEnvelopeResponse {
\treturn &SOAPEnvelopeResponse{
\t\tPrefixSoap: "http://schemas.xmlsoap.org/soap/envelope/",
\t\tPrefixXsd:  "http://www.w3.org/2001/XMLSchema",
\t\tPrefixXsi:  "http://www.w3.org/2001/XMLSchema-instance",
\t}
}

type Fault struct {
\tXMLName xml.Name `xml:"SOAP-ENV:Fault"`
\tSpace   string   `xml:"xmlns:SOAP-ENV,omitempty,attr"`

\tCode   string `xml:"faultcode,omitempty"`
\tString string `xml:"faultstring,omitempty"`
\tActor  string `xml:"faultactor,omitempty"`
\tDetail string `xml:"detail,omitempty"`
}

type SOAPBodyResponse struct {
\tXMLName xml.Name `xml:"soap:Body"`
\tFault   *Fault   `xml:",omitempty"`

"""
        for name, typ in responses:
            s += f"\t{name} *{typ} `xml:\",omitempty\"`\n"
        s += "}\n\n"
        for name, typ in funcs:
            s += f"func (service *SOAPBodyRequest) {name}Func(request *{name}) (*{typ}, error) {{\n\treturn nil, WSDLUndefinedError\n}}\n\n"
        s += """func (service *SOAPEnvelopeRequest) call(w http.ResponseWriter, r *http.Request) {
\tw.Header().Add("Content-Type", "text/xml; charset=utf-8")
\tval := reflect.ValueOf(&service.Body).Elem()
\tn := val.NumField()
\tvar field reflect.Value
\tvar name string
\tfind := false

\tif r.Method == http.MethodGet {
\t\tw.Write([]byte(wsdl))
\t\treturn
\t}

\tresp := NewSOAPEnvelopResponse()
\tdefer func() {
\t\tif r := recover(); r != nil {
\t\t\tresp.Body.Fault = &Fault{}
\t\t\tresp.Body.Fault.Space = "http://schemas.xmlsoap.org/soap/envelope/"
\t\t\tresp.Body.Fault.Code = "soap:Server"
\t\t\tresp.Body.Fault.Detail = fmt.Sprintf("%v", r)
\t\t\tresp.Body.Fault.String = fmt.Sprintf("%v", r)
\t\t}
\t\txml.NewEncoder(w).Encode(resp)
\t}()

\theader := r.Header.Get("Content-Type")
\tif strings.Index(header, "application/soap+xml") >= 0 {
\t\tpanic("Could not find an appropriate Transport Binding to invoke.")
\t}

\terr := xml.NewDecoder(r.Body).Decode(service)
\tif err != nil {
\t\tpanic(err)
\t}

\tfor i := 0; i < n; i++ {
\t\tfield = val.Field(i)
\t\tname = val.Type().Field(i).Name
\t\tif field.Kind() != reflect.Ptr {
\t\t\tcontinue
\t\t}
\t\tif field.IsNil() {
\t\t\tcontinue
\t\t}
\t\tif field.IsValid() {
\t\t\tfind = true
\t\t\tbreak
\t\t}
\t}

\tif !find {
\t\tpanic(WSDLUndefinedError)
\t} else {
\t\tm := val.Addr().MethodByName(name + "Func")
\t\tif !m.IsValid() {
\t\t\tpanic(WSDLUndefinedError)
\t\t}

\t\tvals := m.Call([]reflect.Value{field})
\t\tif vals[1].IsNil() {
\t\t\treflect.ValueOf(&resp.Body).Elem().FieldByName(name).Set(vals[0])
\t\t} else {
\t\t\tpanic(vals[1].Interface())
\t\t}
\t}

}

func Endpoint(w http.ResponseWriter, r *http.Request) {
\trequest := SOAPEnvelopeRequest{}
\trequest.call(w, r)
}
"""
        return s


def xml_original_name(go_name, elements):
    for xmln, gon in elements.items():
        if gon == go_name:
            return xmln
    return go_name


HELP = """Usage: {prog} [options] myservice.wsdl
  -d string
\tDirectory under which package directory will be created (default "./")
  -i\tSkips TLS Verification
  -make-public
\tMake the generated types public/exported (default true)
  -o string
\tFile where the generated code will be saved (default "myservice.go")
  -p string
\tPackage under which code will be generated (default "myservice")
  -v\tShows gowsdl version
"""


def usage(prog):
    sys.stderr.write(HELP.format(prog=prog))


def parse_args(argv):
    opts = {"-d": "./", "-o": "myservice.go", "-p": "myservice", "-i": False, "-v": False, "-make-public": True}
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--help", "-h"):
            usage(sys.argv[0])
            return None, 0
        if a == "-v":
            opts["-v"] = True
            i += 1
        elif a == "-i":
            opts["-i"] = True
            i += 1
        elif a.startswith("-make-public"):
            if a == "-make-public":
                opts["-make-public"] = True
            elif a.startswith("-make-public="):
                opts["-make-public"] = a.split("=", 1)[1].lower() not in ("false", "0")
            i += 1
        elif a in ("-d", "-o", "-p"):
            if i + 1 >= len(argv):
                sys.stderr.write(f"flag needs an argument: {a}\n")
                usage(sys.argv[0])
                return None, 2
            opts[a] = argv[i + 1]
            i += 2
        elif a.startswith("-"):
            sys.stderr.write(f"flag provided but not defined: {a}\n")
            usage(sys.argv[0])
            return None, 2
        else:
            files.append(a)
            i += 1
    opts["files"] = files
    return opts, None


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    opts, code = parse_args(argv)
    if code is not None:
        return code
    if opts["-v"]:
        print("🍀  v0.5.0")
        return 0
    if not opts["files"]:
        usage(sys.argv[0])
        return 0
    path = opts["files"][0]
    abs_path = os.path.abspath(path)
    print(f"🍀  Reading file {abs_path}")
    try:
        model = Parser(path).parse()
        gen = Generator(model, opts["-p"])
        outdir = os.path.join(opts["-d"], opts["-p"])
        os.makedirs(outdir, exist_ok=True)
        outname = opts["-o"]
        with open(os.path.join(outdir, outname), "w", encoding="utf-8") as f:
            f.write(gen.client())
        with open(os.path.join(outdir, "server" + outname), "w", encoding="utf-8") as f:
            f.write(gen.server(outname))
    except Exception as e:
        sys.stderr.write(str(e) + "\n")
        return 1
    print("🍀  Done 👍")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
