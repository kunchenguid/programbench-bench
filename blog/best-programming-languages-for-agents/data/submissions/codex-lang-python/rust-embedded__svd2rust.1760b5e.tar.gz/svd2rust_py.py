#!/usr/bin/env python3
import argparse
import os
import re
import sys
import textwrap
import xml.etree.ElementTree as ET

VERSION = "svd2rust 0.37.1 (e29353d 2026-03-03)"


def log(level, msg, err=False):
    stream = sys.stderr if err else sys.stdout
    print(f"[{level:<5} svd2rust] {msg}", file=stream)


def strip_ns(tag):
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def children(node, name=None):
    if node is None:
        return []
    out = [c for c in list(node) if name is None or strip_ns(c.tag) == name]
    return out


def child(node, name):
    for c in children(node):
        if strip_ns(c.tag) == name:
            return c
    return None


def text(node, name=None, default=""):
    n = child(node, name) if name else node
    if n is None or n.text is None:
        return default
    return n.text.strip()


def intval(s, default=0):
    if s is None:
        return default
    s = str(s).strip().replace("_", "")
    if not s:
        return default
    try:
        return int(s, 0)
    except ValueError:
        try:
            return int(float(s))
        except ValueError:
            return default


def clean_doc(s):
    s = re.sub(r"\s+", " ", s or "").strip()
    return s.replace("\\", "\\\\").replace('"', '\\"')


def words(s):
    return re.findall(r"[A-Za-z0-9]+", s or "")


def snake(s):
    ws = words(s)
    return "_".join(w.lower() for w in ws) or "unnamed"


def pascal(s):
    ws = words(s)
    return "".join(w[:1].upper() + w[1:].lower() for w in ws) or "Unnamed"


def const_ident(s):
    ws = words(s)
    return "_".join(w.upper() for w in ws) or "UNNAMED"


def rust_int_type(bits):
    bits = intval(bits, 32)
    if bits <= 8:
        return "u8"
    if bits <= 16:
        return "u16"
    if bits <= 32:
        return "u32"
    return "u64"


def access_kind(reg, field=None):
    a = (text(field, "access") if field is not None else "") or text(reg, "access") or ""
    a = a.lower()
    readable = "read" in a or a in ("", "read-write", "read-only", "read-writeonce")
    writable = "write" in a or a in ("", "read-write", "write-only", "writeonce", "read-writeonce")
    if "read-only" in a:
        writable = False
    if "write-only" in a:
        readable = False
    return readable, writable


def parse_fields(reg):
    out = []
    fs = child(reg, "fields")
    for f in children(fs, "field"):
        for idx_i, idx in enumerate(dim_indices(f)):
            name = expand_name(text(f, "name"), idx)
            if not name:
                continue
            lsb = text(f, "lsb")
            msb = text(f, "msb")
            bit_offset = text(f, "bitOffset")
            bit_width = text(f, "bitWidth")
            bit_range = text(f, "bitRange")
            if bit_range:
                m = re.search(r"\[(\d+)\s*:\s*(\d+)\]", bit_range)
                if m:
                    msb, lsb = m.group(1), m.group(2)
            off = intval(bit_offset if bit_offset else lsb, 0) + idx_i * intval(text(f, "dimIncrement"), 0)
            if bit_width:
                width = intval(bit_width, 1)
            elif msb:
                width = intval(msb, off) - off + 1
            else:
                width = 1
            out.append({
                "name": name,
                "doc": text(f, "description"),
                "offset": off,
                "width": max(width, 1),
                "readable": access_kind(reg, f)[0],
                "writable": access_kind(reg, f)[1],
            })
    return out


def dim_indices(node):
    dim = intval(text(node, "dim"), 0)
    if dim <= 0:
        return [None]
    raw = text(node, "dimIndex")
    if not raw:
        return [str(i) for i in range(dim)]
    out = []
    for part in raw.split(","):
        part = part.strip()
        m = re.match(r"^(\d+)\s*-\s*(\d+)$", part)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            out.extend(str(i) for i in range(a, b + 1))
        elif part:
            out.append(part)
    return (out + [str(i) for i in range(len(out), dim)])[:dim]


def expand_name(name, idx):
    if not name:
        return ""
    if idx is None:
        return name
    return name.replace("[%s]", str(idx)).replace("%s", str(idx))


def parse_registers(parent, inherited=None):
    regs = []
    rnode = child(parent, "registers")
    for r in children(rnode):
        if strip_ns(r.tag) == "register":
            if text(r, "derivedFrom") and inherited:
                base = next((x for x in inherited if x["name"] == text(r, "derivedFrom")), {})
            else:
                base = {}
            inc = intval(text(r, "dimIncrement"), max(1, intval(text(r, "size"), base.get("size", 32)) // 8))
            for idx_i, idx in enumerate(dim_indices(r)):
                regs.append({
                    "name": expand_name(text(r, "name") or base.get("name", "REG"), idx),
                    "doc": text(r, "description") or base.get("doc", ""),
                    "offset": intval(text(r, "addressOffset"), base.get("offset", 0)) + idx_i * inc,
                    "size": intval(text(r, "size"), base.get("size", 32)),
                    "reset": intval(text(r, "resetValue"), base.get("reset", 0)),
                    "readable": access_kind(r)[0],
                    "writable": access_kind(r)[1],
                    "fields": parse_fields(r) or base.get("fields", []),
                })
        elif strip_ns(r.tag) == "cluster":
            base_off = intval(text(r, "addressOffset"), 0)
            cname = text(r, "name") or "cluster"
            for sub in parse_registers(r):
                sub = dict(sub)
                sub["name"] = f"{cname}_{sub['name']}"
                sub["offset"] += base_off
                regs.append(sub)
    return regs


def parse_device(xml_bytes):
    root = ET.fromstring(xml_bytes)
    if strip_ns(root.tag) != "device":
        raise ValueError("root element is not <device>")
    pname_map = {}
    periph_nodes = children(child(root, "peripherals"), "peripheral")
    periphs = []
    for p in periph_nodes:
        name = text(p, "name")
        pname_map[name] = p
    for p in periph_nodes:
        base = {}
        dfrom = text(p, "derivedFrom")
        if dfrom and dfrom in pname_map:
            bp = pname_map[dfrom]
            base = {
                "doc": text(bp, "description"),
                "base": intval(text(bp, "baseAddress"), 0),
                "regs": parse_registers(bp),
            }
        regs = parse_registers(p, base.get("regs"))
        inc = intval(text(p, "dimIncrement"), 0)
        for idx_i, idx in enumerate(dim_indices(p)):
            periphs.append({
                "name": expand_name(text(p, "name") or "PERIPHERAL", idx),
                "doc": text(p, "description") or base.get("doc", ""),
                "base": intval(text(p, "baseAddress"), base.get("base", 0)) + idx_i * inc,
                "group": text(p, "groupName"),
                "regs": regs or base.get("regs", []),
            })
    interrupts = []
    for intr in root.iter():
        if strip_ns(intr.tag) == "interrupt":
            nm = text(intr, "name")
            if nm:
                interrupts.append((nm, intval(text(intr, "value"), 0), text(intr, "description")))
    return {
        "name": text(root, "name") or "DEVICE",
        "doc": text(root, "description"),
        "width": intval(text(root, "width"), 32),
        "periphs": periphs,
        "interrupts": interrupts,
    }


GENERIC = r'''
use core::cell::UnsafeCell;
use core::marker::PhantomData;

pub struct Reg<U> {
    register: UnsafeCell<U>,
}

unsafe impl<U: Send> Send for Reg<U> {}
unsafe impl<U: Send> Sync for Reg<U> {}

impl<U: Copy> Reg<U> {
    #[inline(always)]
    pub fn read(&self) -> R<U> {
        R { bits: unsafe { core::ptr::read_volatile(self.register.get()) } }
    }
    #[inline(always)]
    pub fn write<F>(&self, f: F)
    where
        U: Default,
        F: FnOnce(&mut W<U>) -> &mut W<U>,
    {
        let mut w = W { bits: U::default() };
        f(&mut w);
        unsafe { core::ptr::write_volatile(self.register.get(), w.bits) };
    }
    #[inline(always)]
    pub fn write_with_zero<F>(&self, f: F)
    where
        U: Default,
        F: FnOnce(&mut W<U>) -> &mut W<U>,
    {
        self.write(f)
    }
    #[inline(always)]
    pub fn modify<F>(&self, f: F)
    where
        F: FnOnce(&R<U>, &mut W<U>) -> &mut W<U>,
    {
        let bits = unsafe { core::ptr::read_volatile(self.register.get()) };
        let r = R { bits };
        let mut w = W { bits };
        f(&r, &mut w);
        unsafe { core::ptr::write_volatile(self.register.get(), w.bits) };
    }
}

pub struct R<U> {
    bits: U,
}

impl<U: Copy> R<U> {
    #[inline(always)]
    pub const fn bits(&self) -> U {
        self.bits
    }
}

pub struct W<U> {
    bits: U,
}

impl<U: Copy> W<U> {
    #[inline(always)]
    pub unsafe fn bits(&mut self, bits: U) -> &mut Self {
        self.bits = bits;
        self
    }
}

pub struct FieldReader<U = u8> {
    bits: U,
}

impl<U: Copy> FieldReader<U> {
    #[inline(always)]
    pub const fn new(bits: U) -> Self {
        Self { bits }
    }
    #[inline(always)]
    pub const fn bits(&self) -> U {
        self.bits
    }
}

pub struct BitReader {
    bits: bool,
}

impl BitReader {
    #[inline(always)]
    pub const fn new(bits: bool) -> Self {
        Self { bits }
    }
    #[inline(always)]
    pub const fn bit(&self) -> bool {
        self.bits
    }
    #[inline(always)]
    pub const fn bit_is_set(&self) -> bool {
        self.bits
    }
    #[inline(always)]
    pub const fn bit_is_clear(&self) -> bool {
        !self.bits
    }
}

pub struct FieldWriter<'a, U, const WI: u8> {
    w: &'a mut W<U>,
    o: u8,
    _p: PhantomData<U>,
}

impl<'a, U, const WI: u8> FieldWriter<'a, U, WI>
where
    U: Copy
        + From<u8>
        + core::ops::BitAnd<Output = U>
        + core::ops::BitOr<Output = U>
        + core::ops::Not<Output = U>
        + core::ops::Shl<u8, Output = U>,
{
    #[inline(always)]
    pub fn new(w: &'a mut W<U>, o: u8) -> Self {
        Self { w, o, _p: PhantomData }
    }
    #[inline(always)]
    pub unsafe fn bits(self, value: U) -> &'a mut W<U> {
        self.w.bits = self.w.bits | ((value) << self.o);
        self.w
    }
}

pub struct BitWriter<'a, U> {
    w: &'a mut W<U>,
    o: u8,
}

impl<'a, U> BitWriter<'a, U>
where
    U: Copy + From<u8> + core::ops::BitOr<Output = U> + core::ops::Shl<u8, Output = U>,
{
    #[inline(always)]
    pub fn new(w: &'a mut W<U>, o: u8) -> Self {
        Self { w, o }
    }
    #[inline(always)]
    pub fn set_bit(self) -> &'a mut W<U> {
        self.bit(true)
    }
    #[inline(always)]
    pub fn clear_bit(self) -> &'a mut W<U> {
        self.bit(false)
    }
    #[inline(always)]
    pub fn bit(self, value: bool) -> &'a mut W<U> {
        if value {
            self.w.bits = self.w.bits | (U::from(1u8) << self.o);
        }
        self.w
    }
}
'''


def reg_struct_lines(periph):
    regs = sorted(periph["regs"], key=lambda r: r["offset"])
    lines = ["#[repr(C)]", "pub struct RegisterBlock {"]
    pos = 0
    reserved = 0
    for r in regs:
        off = r["offset"]
        if off > pos:
            gap = off - pos
            lines.append(f"    _reserved{reserved}: [u8; {gap}],")
            reserved += 1
            pos = off
        lines.append(f"    #[doc = \"{clean_doc(r['doc'])}\"]")
        lines.append(f"    pub {snake(r['name'])}: crate::generic::Reg<{rust_int_type(r['size'])}>,")
        pos += max(1, r["size"] // 8)
    lines.append("}")
    return lines


def render_register_mod(r):
    mod = snake(r["name"])
    spec = pascal(r["name"]) + "Spec"
    ux = rust_int_type(r["size"])
    out = [f"pub mod {mod} {{", "    use crate::generic::*;", f"    #[doc = \"{clean_doc(r['doc'])}\"]", f"    pub struct {spec};",
           f"    pub type R = crate::generic::R<{ux}>;", f"    pub type W = crate::generic::W<{ux}>;"]
    if r["readable"]:
        for f in r["fields"]:
            if not f["readable"]:
                continue
            nm = snake(f["name"])
            if f["width"] == 1:
                out.append(f"    pub type {pascal(f['name'])}R = BitReader;")
                out.append(f"    impl R {{ #[doc = \"{clean_doc(f['doc'])}\"] #[inline(always)] pub fn {nm}(&self) -> {pascal(f['name'])}R {{ BitReader::new(((self.bits() >> {f['offset']}) & 1) != 0) }} }}")
            else:
                mask = (1 << min(f["width"], 63)) - 1
                out.append(f"    pub type {pascal(f['name'])}R = FieldReader<{ux}>;")
                out.append(f"    impl R {{ #[doc = \"{clean_doc(f['doc'])}\"] #[inline(always)] pub fn {nm}(&self) -> {pascal(f['name'])}R {{ FieldReader::new((self.bits() >> {f['offset']}) & {mask}) }} }}")
    if r["writable"]:
        for f in r["fields"]:
            if not f["writable"]:
                continue
            nm = snake(f["name"])
            if f["width"] == 1:
                out.append(f"    pub type {pascal(f['name'])}W<'a> = BitWriter<'a, {ux}>;")
                out.append(f"    impl W {{ #[doc = \"{clean_doc(f['doc'])}\"] #[inline(always)] pub fn {nm}(&mut self) -> {pascal(f['name'])}W<'_> {{ BitWriter::new(self, {f['offset']}) }} }}")
            else:
                out.append(f"    pub type {pascal(f['name'])}W<'a> = FieldWriter<'a, {ux}, {f['width']}>;")
                out.append(f"    impl W {{ #[doc = \"{clean_doc(f['doc'])}\"] #[inline(always)] pub fn {nm}(&mut self) -> {pascal(f['name'])}W<'_> {{ FieldWriter::new(self, {f['offset']}) }} }}")
    out.append("}")
    return out


def render_periph(p):
    mn = snake(p["name"])
    cn = const_ident(p["name"])
    ty = pascal(p["name"])
    out = [f"#[doc = \"{clean_doc(p['doc'])}\"]", f"pub mod {mn} {{", "    use super::*;"]
    out.extend("    " + line for line in reg_struct_lines(p))
    for r in p["regs"]:
        out.extend("    " + line for line in render_register_mod(r))
    out.append(f"}}")
    out.append(f"#[doc = \"{clean_doc(p['doc'])}\"]")
    out.append(f"pub type {ty} = crate::Periph<{ty}Spec>;")
    out.append(f"pub struct {ty}Spec;")
    out.append(f"impl crate::PeripheralSpec for {ty}Spec {{ type RB = {mn}::RegisterBlock; const ADDRESS: usize = 0x{p['base']:X}; const NAME: &'static str = \"{cn}\"; }}")
    out.append(f"pub const {cn}: {ty} = unsafe {{ {ty}::steal() }};")
    return out


def render_lib(dev, make_mod=False, skip_attrs=False, generic_mod=False, edition=None, target=None, reexport_interrupt=False):
    root_name = "mod.rs" if make_mod else "lib.rs"
    lines = []
    if not skip_attrs and not make_mod:
        lines += [
            f"#![doc = \"Peripheral access API for {clean_doc(dev['name'])} microcontrollers (generated using svd2rust v0.37.1 (e29353d 2026-03-03))\"]",
            "#![allow(non_camel_case_types)]",
            "#![allow(non_snake_case)]",
            "#![allow(dead_code)]",
            "#![no_std]",
        ]
    else:
        lines.append(f"#[doc = \"Peripheral access API for {clean_doc(dev['name'])} microcontrollers\"]")
    if generic_mod:
        lines.append("pub mod generic;")
    else:
        lines.append("pub mod generic {")
        lines.extend("    " + x for x in GENERIC.strip().splitlines())
        lines.append("}")
    lines.append("pub use generic::*;")
    lines.append("impl<PER: PeripheralSpec> Periph<PER> { pub const PTR: *const PER::RB = PER::ADDRESS as *const _; pub const fn ptr() -> *const PER::RB { Self::PTR } pub const unsafe fn steal() -> Self { Self { _marker: core::marker::PhantomData } } }")
    lines.append("pub mod __periph_support { pub trait Sealed {} }")
    lines.append("pub mod generic_periph_decl { pub use crate::generic::*; }")
    lines.append("pub mod generic_periph_impl { pub use crate::generic::*; }")
    lines.insert(lines.index("pub use generic::*;"), "pub mod generic_extra { }")
    # Add Periph and PeripheralSpec after generic module. Kept separate so generic.rs can be small and self-contained.
    periph_support = r'''
pub mod generic_device {
    use core::marker::PhantomData;
    pub struct Periph<PER: PeripheralSpec> {
        pub(crate) _marker: PhantomData<PER>,
    }
    pub trait PeripheralSpec {
        type RB;
        const ADDRESS: usize;
        const NAME: &'static str;
    }
    unsafe impl<PER: PeripheralSpec> Send for Periph<PER> {}
    impl<PER: PeripheralSpec> core::ops::Deref for Periph<PER> {
        type Target = PER::RB;
        fn deref(&self) -> &Self::Target {
            unsafe { &*(PER::ADDRESS as *const PER::RB) }
        }
    }
}
pub use generic_device::{Periph, PeripheralSpec};
'''
    if generic_mod:
        lines.append(periph_support)
    else:
        # inject into generic module by a compatibility reexport at crate root too
        lines.append(periph_support)
    for p in dev["periphs"]:
        lines.extend(render_periph(p))
    if dev["interrupts"]:
        lines.append("#[derive(Clone, Copy, Debug, Eq, PartialEq)]")
        lines.append("#[repr(u16)]")
        lines.append("pub enum Interrupt {")
        seen = set()
        for nm, val, doc in dev["interrupts"]:
            ci = const_ident(nm)
            if ci in seen:
                continue
            seen.add(ci)
            lines.append(f"    #[doc = \"{clean_doc(doc)}\"]")
            lines.append(f"    {ci} = {val},")
        lines.append("}")
        if reexport_interrupt:
            lines.append("pub use Interrupt as interrupt;")
    return root_name, "\n".join(lines) + "\n"


def render_generic_rs():
    return "pub use crate::generic_device::{Periph, PeripheralSpec};\n" + GENERIC.strip() + "\n"


def render_build():
    return '#![doc = r" Builder file for Peripheral access crate generated by svd2rust tool"]\nuse std::env; use std::fs::File; use std::io::Write; use std::path::PathBuf;\nfn main() { if env::var_os("CARGO_FEATURE_RT").is_some() { let out = &PathBuf::from(env::var_os("OUT_DIR").unwrap()); File::create(out.join("device.x")).unwrap().write_all(include_bytes!("device.x")).unwrap(); println!("cargo:rustc-link-search={}", out.display()); println!("cargo:rerun-if-changed=device.x"); } println!("cargo:rerun-if-changed=build.rs"); }\n'


class Parser(argparse.ArgumentParser):
    def error(self, message):
        if "unrecognized arguments:" in message:
            arg = message.split(":", 1)[1].strip().split()[0]
            self.exit(2, f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n")
        super().error(message)


def make_parser():
    p = Parser(prog="executable", add_help=False, formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument("-i", metavar="FILE", dest="input")
    p.add_argument("-o", "--output-dir", metavar="PATH", default=".")
    p.add_argument("-c", "--config", metavar="TOML_FILE")
    p.add_argument("--settings", metavar="YAML_FILE")
    p.add_argument("--edition", metavar="YEAR")
    p.add_argument("--target", metavar="ARCH")
    p.add_argument("--atomics", action="store_true")
    p.add_argument("--atomics-feature")
    p.add_argument("--ignore-groups", action="store_true")
    p.add_argument("--keep-list", action="store_true")
    p.add_argument("-g", "--generic-mod", action="store_true")
    p.add_argument("--feature-group", action="store_true")
    p.add_argument("--feature-peripheral", action="store_true")
    p.add_argument("-f", "--ident-format", action="append")
    p.add_argument("--ident-formats-theme")
    p.add_argument("--field-names-for-enums", action="store_true")
    p.add_argument("--max-cluster-size", action="store_true")
    p.add_argument("--impl-debug", action="store_true")
    p.add_argument("--impl-debug-feature")
    p.add_argument("--impl-defmt")
    p.add_argument("-m", "--make-mod", action="store_true")
    p.add_argument("--skip-crate-attributes", action="store_true")
    p.add_argument("-s", "--strict", action="store_true")
    p.add_argument("--source-type")
    p.add_argument("--reexport-core-peripherals", action="store_true")
    p.add_argument("--reexport-interrupt", action="store_true")
    p.add_argument("-b", "--base-address-shift", default="0")
    p.add_argument("-l", "--log")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("--help-long", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    return p


HELP = """Generate a Rust API from SVD files

Usage: executable [OPTIONS]

Options:
  -i <FILE>
          Input SVD file
  -o, --output-dir <PATH>
          Directory to place generated files
  -c, --config <TOML_FILE>
          Config TOML file
      --settings <YAML_FILE>
          Target-specific settings YAML file
      --edition <YEAR>
          Rust edition of generated code
      --target <ARCH>
          Target architecture
      --atomics
          Generate atomic register modification API
      --atomics-feature <FEATURE>
          add feature gating for atomic register modification API
      --ignore-groups
          Don't add alternateGroup name as prefix to register name
      --keep-list
          Keep lists when generating code of dimElement, instead of trying to generate arrays
  -g, --generic-mod
          Push generic mod in separate file
      --feature-group
          Use group_name of peripherals as feature
      --feature-peripheral
          Use independent cfg feature flags for each peripheral
  -m, --make-mod
          Create mod.rs instead of lib.rs, without inner attributes
      --skip-crate-attributes
          Do not generate crate attributes
  -s, --strict
          Make advanced checks due to parsing SVD
  -b, --base-address-shift <base_address_shift>
          Add offset to all base addresses on all peripherals in the SVD file.
  -l, --log <log_level>
          Choose which messages to log (overrides RUST_LOG) [possible values: off, error, warn, info, debug, trace]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version"""


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    parser = make_parser()
    ns, extra = parser.parse_known_args(argv)
    if extra:
        parser.error("unrecognized arguments: " + " ".join(extra))
    if ns.help:
        print(HELP)
        return 0
    if ns.version:
        print(VERSION)
        return 0
    try:
        if ns.input:
            try:
                with open(ns.input, "rb") as f:
                    data = f.read()
            except OSError as e:
                print("[ERROR svd2rust] Cannot open the SVD file\n    \n    Caused by:\n        " + str(e), file=sys.stderr)
                return 1
        else:
            data = sys.stdin.buffer.read()
        log("INFO", "Parsing device from SVD file")
        if not data.strip():
            print("[ERROR svd2rust] Error parsing SVD XML file\n    \n    Caused by:\n        the document does not have a root node", file=sys.stderr)
            return 1
        dev = parse_device(data)
        shift = intval(ns.base_address_shift, 0)
        if shift:
            for p in dev["periphs"]:
                p["base"] += shift
        log("INFO", "Rendering device")
        outdir = ns.output_dir
        root, lib = render_lib(dev, ns.make_mod, ns.skip_crate_attributes, ns.generic_mod, ns.edition, ns.target, ns.reexport_interrupt)
        os.makedirs(outdir, exist_ok=True)
        with open(os.path.join(outdir, root), "w") as f:
            f.write(lib)
        if ns.generic_mod:
            with open(os.path.join(outdir, "generic.rs"), "w") as f:
                f.write(render_generic_rs())
        with open(os.path.join(outdir, "build.rs"), "w") as f:
            f.write(render_build())
        with open(os.path.join(outdir, "device.x"), "w") as f:
            f.write("\n")
        return 0
    except ET.ParseError as e:
        print("[ERROR svd2rust] Error parsing SVD XML file\n    \n    Caused by:\n        " + str(e), file=sys.stderr)
        return 1
    except Exception as e:
        print("[ERROR svd2rust] " + str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
