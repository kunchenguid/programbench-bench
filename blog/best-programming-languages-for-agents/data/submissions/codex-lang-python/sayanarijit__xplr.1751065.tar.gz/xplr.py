#!/usr/bin/env python3
import json
import os
import re
import stat
import sys


VERSION = "xplr 1.1.0"

HELP = """xplr 1.1.0
Arijit Basu <hi@arijitbasu.in>
A hackable, minimal, fast TUI file explorer

USAGE:
    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...

FLAGS:
  -                            Reads new-line (\\n) separated paths from stdin
  --                           Denotes the end of command-line flags and options
      --force-focus            Focuses on the given <PATH>, even if it is a directory
  -h, --help                   Prints help information
  -m, --pipe-msg-in            Helps safely passing messages to the active xplr
                                 session, use %%, %s and %q as the placeholders
  -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of
                                 passing to the active xplr session
      --print-pwd-as-result    Prints the present working directory when quitting
                                 with `PrintResultAndQuit`
      --read-only              Enables read-only mode (config.general.read_only)
      --read0                  Reads paths separated using the null character (\\0)
      --write0                 Prints paths separated using the null character (\\0)
  -0  --null                   Combines --read0 and --write0
  -V, --version                Prints version information

OPTIONS:
  -c, --config <PATH>             Specifies a custom config file (default is
                                    "$HOME/.config/xplr/init.lua")
  -C, --extra-config <PATH>...    Specifies extra config files to load
      --on-load <MESSAGE>...      Sends messages when xplr loads
      --vroot <PATH>              Treats the specified path as the virtual root

ARGS:
  <PATH>            Path to focus on, or enter if directory, (default is `.`)
  <SELECTION>...    Paths to select, requires <PATH> to be set explicitly
"""

VALID_MESSAGES = {
    "ExplorePwd", "ExplorePwdAsync", "ExploreParentsAsync", "TryCompletePath",
    "ClearScreen", "Refresh", "FocusNext", "FocusNextSelection",
    "FocusNextByRelativeIndex", "FocusNextByRelativeIndexFromInput",
    "FocusPrevious", "FocusPreviousSelection", "FocusPreviousByRelativeIndex",
    "FocusPreviousByRelativeIndexFromInput", "FocusFirst", "FocusLast",
    "FocusPath", "FocusPathFromInput", "FocusByIndex", "FocusByIndexFromInput",
    "FocusByFileName", "ScrollUp", "ScrollDown", "ScrollUpHalf",
    "ScrollDownHalf", "ChangeDirectory", "Enter", "Back", "LastVisitedPath",
    "NextVisitedPath", "PreviousVisitedDeepBranch", "NextVisitedDeepBranch",
    "FollowSymlink", "SetVroot", "UnsetVroot", "ToggleVroot", "ResetVroot",
    "SetInputPrompt", "UpdateInputBuffer", "UpdateInputBufferFromKey",
    "BufferInput", "BufferInputFromKey", "SetInputBuffer",
    "RemoveInputBufferLastCharacter", "RemoveInputBufferLastWord",
    "ResetInputBuffer", "SwitchMode", "SwitchModeKeepingInputBuffer",
    "SwitchModeBuiltin", "SwitchModeBuiltinKeepingInputBuffer",
    "SwitchModeCustom", "SwitchModeCustomKeepingInputBuffer", "PopMode",
    "PopModeKeepingInputBuffer", "SwitchLayout", "SwitchLayoutBuiltin",
    "SwitchLayoutCustom", "Call", "Call0", "CallSilently", "CallSilently0",
    "BashExec", "BashExec0", "BashExecSilently", "BashExecSilently0",
    "CallLua", "CallLuaSilently", "LuaEval", "LuaEvalSilently", "Select",
    "SelectAll", "SelectPath", "UnSelect", "UnSelectAll", "UnSelectPath",
    "ToggleSelection", "ToggleSelectAll", "ToggleSelectionByPath",
    "ClearSelection", "AddNodeFilter", "RemoveNodeFilter", "ToggleNodeFilter",
    "AddNodeFilterFromInput", "RemoveNodeFilterFromInput",
    "RemoveLastNodeFilter", "ResetNodeFilters", "ClearNodeFilters",
    "AddNodeSorter", "RemoveNodeSorter", "ReverseNodeSorter",
    "ToggleNodeSorter", "ReverseNodeSorters", "RemoveLastNodeSorter",
    "ResetNodeSorters", "ClearNodeSorters", "Search", "SearchFromInput",
    "SearchFuzzy", "SearchFuzzyFromInput", "SearchFuzzyUnordered",
    "SearchFuzzyUnorderedFromInput", "SearchRegex", "SearchRegexFromInput",
    "SearchRegexUnordered", "SearchRegexUnorderedFromInput",
    "ToggleSearchAlgorithm", "EnableSearchOrder", "DisableSearchOrder",
    "ToggleSearchOrder", "AcceptSearch", "CancelSearch", "EnableMouse",
    "DisableMouse", "ToggleMouse", "StartFifo", "StopFifo", "ToggleFifo",
    "LogInfo", "LogSuccess", "LogWarning", "LogError", "Debug", "Quit",
    "PrintPwdAndQuit", "PrintFocusPathAndQuit", "PrintSelectionAndQuit",
    "PrintResultAndQuit", "PrintAppStateAndQuit", "Terminate",
}


def fail(message):
    sys.stderr.write(f"error: {message}\n")
    return 1


def json_quote(value):
    return json.dumps(value, separators=(",", ":"))


def substitute_template(template, values):
    out = []
    i = 0
    value_index = 0
    while i < len(template):
        ch = template[i]
        if ch != "%":
            out.append(ch)
            i += 1
            continue
        col = i + 1
        if i + 1 >= len(template):
            out.append("%")
            i += 1
            continue
        nxt = template[i + 1]
        if nxt == "%":
            out.append("%")
            i += 2
        elif nxt in ("s", "q"):
            if value_index >= len(values):
                raise ValueError(f"xplr -m: placeholder missing value at column {col}")
            val = values[value_index]
            value_index += 1
            out.append(val if nxt == "s" else json_quote(val))
            i += 2
        elif nxt == "*" and i + 2 < len(template) and template[i + 2] in ("s", "q"):
            kind = template[i + 2]
            rest = values[value_index:]
            value_index = len(values)
            if kind == "q":
                out.append(",".join(json_quote(v) for v in rest))
            else:
                out.append(",".join(rest))
            i += 3
        else:
            out.append("%")
            i += 1
    return "".join(out)


def parse_scalar(text):
    text = text.strip()
    if not text:
        return ""
    if text[0] == '"' or text[0] == "[" or text[0] == "{":
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
    if re.fullmatch(r"-?\d+", text):
        try:
            return int(text)
        except ValueError:
            pass
    if re.fullmatch(r"-?(?:\d+\.\d*|\d*\.\d+)", text):
        try:
            return float(text)
        except ValueError:
            pass
    if text == "true":
        return True
    if text == "false":
        return False
    if text in ("null", "~"):
        return None
    return text


def split_top_level(text, sep=","):
    parts, buf = [], []
    depth = 0
    in_str = False
    esc = False
    for ch in text:
        if in_str:
            buf.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
            buf.append(ch)
        elif ch in "[{":
            depth += 1
            buf.append(ch)
        elif ch in "]}":
            depth -= 1
            buf.append(ch)
        elif ch == sep and depth == 0:
            parts.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    if buf or text.endswith(sep):
        parts.append("".join(buf).strip())
    return parts


def parse_value(text):
    text = text.strip()
    if text.startswith("{") and text.endswith("}"):
        inner = text[1:-1].strip()
        obj = {}
        if inner:
            for part in split_top_level(inner):
                if ":" not in part:
                    return parse_scalar(text)
                k, v = part.split(":", 1)
                obj[k.strip().strip('"')] = parse_value(v)
        return obj
    if text.startswith("[") and text.endswith("]"):
        inner = text[1:-1].strip()
        if not inner:
            return []
        return [parse_value(p) for p in split_top_level(inner)]
    return parse_scalar(text)


def render_message(template, values):
    try:
        text = substitute_template(template, values)
    except ValueError as exc:
        raise RuntimeError(str(exc))
    stripped = text.strip()
    if ":" in stripped:
        key, val = stripped.split(":", 1)
        key = key.strip()
        if key not in VALID_MESSAGES:
            raise RuntimeError(f"unknown variant `{key}`")
        return json.dumps({key: parse_value(val)}, separators=(",", ":"))
    if stripped not in VALID_MESSAGES:
        raise RuntimeError(f"unknown variant `{stripped}`")
    return json.dumps(stripped, separators=(",", ":"))


def usage_for(opt):
    forms = {
        "-c": "xplr -c PATH",
        "--config": "xplr --config PATH",
        "-C": "xplr -C PATH",
        "--extra-config": "xplr --extra-config PATH",
        "--vroot": "xplr --vroot PATH",
        "-m": "xplr -m FORMAT [ARGUMENT]...",
        "--pipe-msg-in": "xplr --pipe-msg-in FORMAT [ARGUMENT]...",
        "-M": "xplr -M FORMAT [ARGUMENT]...",
        "--print-msg-in": "xplr --print-msg-in FORMAT [ARGUMENT]...",
    }
    return f"usage: {forms.get(opt, 'xplr')}"


def path_exists(path):
    return os.path.exists(os.path.expanduser(path))


def shown_path(path):
    expanded = os.path.expanduser(path)
    if os.path.isabs(expanded):
        return expanded
    return os.path.abspath(expanded)


def handle_message(print_only, opt, args):
    if not args:
        return fail(usage_for(opt))
    try:
        rendered = render_message(args[0], args[1:])
    except RuntimeError as exc:
        return fail(str(exc))
    if print_only or not os.environ.get("XPLR_PIPE_MSG_IN"):
        sys.stdout.write(rendered)
        return 0
    pipe = os.environ["XPLR_PIPE_MSG_IN"]
    try:
        mode = os.stat(pipe).st_mode
        if not stat.S_ISFIFO(mode):
            return fail("failed to detect delimmiter")
        with open(pipe, "w", encoding="utf-8") as fh:
            fh.write(rendered)
        return 0
    except OSError as exc:
        return fail(str(exc))


def parse_and_run(argv):
    positional = []
    i = 0
    end_flags = False
    while i < len(argv):
        arg = argv[i]
        if not end_flags and arg == "--":
            end_flags = True
            i += 1
            continue
        if not end_flags and arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            return 0
        if not end_flags and arg in ("-V", "--version"):
            sys.stdout.write(VERSION + "\n")
            return 0
        if not end_flags and arg in ("-M", "--print-msg-in"):
            return handle_message(True, arg, argv[i + 1 :])
        if not end_flags and arg in ("-m", "--pipe-msg-in"):
            return handle_message(False, arg, argv[i + 1 :])
        if not end_flags and arg in ("-c", "--config", "-C", "--extra-config", "--vroot"):
            if i + 1 >= len(argv):
                return fail(usage_for(arg))
            if not path_exists(argv[i + 1]):
                return fail(f"path doesn't exist: {shown_path(argv[i + 1])}")
            i += 2
            continue
        if not end_flags and arg == "--on-load":
            if i + 1 >= len(argv):
                return fail("No such device or address (os error 6)")
            i += 2
            continue
        if not end_flags and arg in ("--force-focus", "--print-pwd-as-result", "--read-only", "--read0", "--write0", "-0", "--null"):
            i += 1
            continue
        if not end_flags and arg == "-":
            try:
                sys.stdin.buffer.read()
            except Exception:
                pass
            i += 1
            continue
        if not end_flags and arg.startswith("-"):
            return fail(f'invalid argument: "{arg}", try `-- "{arg}"` or `--help`')
        positional.append(arg)
        i += 1

    for p in positional:
        if not path_exists(p):
            return fail(f"path doesn't exist: {shown_path(p)}")
    return fail("No such device or address (os error 6)")


def main():
    sys.exit(parse_and_run(sys.argv[1:]))


if __name__ == "__main__":
    main()
