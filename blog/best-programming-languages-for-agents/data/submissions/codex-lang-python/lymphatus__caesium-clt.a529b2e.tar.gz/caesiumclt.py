#!/usr/bin/env python3
import os
import re
import sys
import math
import shutil
import argparse
from pathlib import Path

try:
    from PIL import Image, ImageOps
except Exception as exc:
    print(f"failed to import Pillow: {exc}", file=sys.stderr)
    sys.exit(1)

VERSION = "caesiumclt 1.3.0"
FORMATS = ("jpeg", "png", "gif", "webp", "tiff", "original")
EXTS = {
    "jpeg": ".jpg",
    "png": ".png",
    "gif": ".gif",
    "webp": ".webp",
    "tiff": ".tiff",
}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".tif", ".tiff"}

HELP_FULL = """A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...
          Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality

      --lossless
          Use lossless compression (may increase file size for some formats)

      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)

      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)

      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)

      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image

      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image

      --no-upscale
          Prevents upscaling of the image when resizing

  -o, --output <OUTPUT>
          Output directory path

      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)

      --format <FORMAT>
          Convert to the selected output format or keep the original
          
          [default: original]
          [possible values: jpeg, png, gif, webp, tiff, original]

      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression
          
          [default: 3]

      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files
          
          [default: auto]
          [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]

      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)

      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)

  -e, --exif
          Keep EXIF metadata during compression

      --keep-dates
          Preserve original file timestamps

      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag

      --suffix <SUFFIX>
          Add suffix to output filenames

  -R, --recursive
          Scan subfolders recursively when input is a directory

  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)

  -d, --dry-run
          Simulate compression without writing files

      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors)
          
          [default: 0]

  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files

          Possible values:
          - all:    Always overwrite existing files
          - never:  Never overwrite existing files
          - bigger: Overwrite only if the existing file is bigger
          
          [default: all]

      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes

  -Q, --quiet
          Suppress all output

      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all
          
          [default: 1]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version"""


HELP_SHORT = """A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...  Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality
      --lossless
          Use lossless compression (may increase file size for some formats)
      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)
      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)
      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)
      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image
      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image
      --no-upscale
          Prevents upscaling of the image when resizing
  -o, --output <OUTPUT>
          Output directory path
      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)
      --format <FORMAT>
          Convert to the selected output format or keep the original [default: original] [possible values: jpeg, png, gif, webp, tiff, original]
      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression [default: 3]
      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files [default: auto] [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]
      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)
      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)
  -e, --exif
          Keep EXIF metadata during compression
      --keep-dates
          Preserve original file timestamps
      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag
      --suffix <SUFFIX>
          Add suffix to output filenames
  -R, --recursive
          Scan subfolders recursively when input is a directory
  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)
  -d, --dry-run
          Simulate compression without writing files
      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors) [default: 0]
  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files [default: all] [possible values: all, never, bigger]
      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes
  -Q, --quiet
          Suppress all output
      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all [default: 1]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version"""


class Parser(argparse.ArgumentParser):
    def error(self, message):
        m = re.fullmatch(r"argument -q/--quality: (Quality must be between 0 and 100, but got ([0-9]+))", message)
        if m:
            message = f"invalid value '{m.group(2)}' for '--quality <QUALITY>': {m.group(1)}"
        m = re.fullmatch(r"argument --format: invalid choice: '([^']+)' .*", message)
        if m:
            print(f"error: invalid value '{m.group(1)}' for '--format <FORMAT>'", file=sys.stderr)
            print("  [possible values: jpeg, png, gif, webp, tiff, original]", file=sys.stderr)
            print("\nFor more information, try '--help'.", file=sys.stderr)
            raise SystemExit(2)
        print(f"error: {message}", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        raise SystemExit(2)


def parse_int_range(name, value, lo=None, hi=None):
    try:
        n = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"invalid digit found in string")
    if lo is not None and n < lo or hi is not None and n > hi:
        if name == "quality":
            raise argparse.ArgumentTypeError(f"Quality must be between 0 and 100, but got {n}")
        raise argparse.ArgumentTypeError(f"value must be between {lo} and {hi}")
    return n


def make_parser():
    p = Parser(add_help=False, usage=argparse.SUPPRESS)
    p.add_argument("files", nargs="*")
    p.add_argument("-q", "--quality", type=lambda s: parse_int_range("quality", s, 0, 100))
    p.add_argument("--lossless", action="store_true")
    p.add_argument("--max-size")
    p.add_argument("--width", type=lambda s: parse_int_range("width", s, 1, None))
    p.add_argument("--height", type=lambda s: parse_int_range("height", s, 1, None))
    p.add_argument("--long-edge", type=lambda s: parse_int_range("long", s, 1, None))
    p.add_argument("--short-edge", type=lambda s: parse_int_range("short", s, 1, None))
    p.add_argument("--no-upscale", action="store_true")
    p.add_argument("-o", "--output")
    p.add_argument("--same-folder-as-input", action="store_true")
    p.add_argument("--format", choices=FORMATS, default="original")
    p.add_argument("--png-opt-level", type=lambda s: parse_int_range("png", s, 0, 6), default=3)
    p.add_argument("--jpeg-chroma-subsampling", choices=("4:4:4", "4:2:2", "4:2:0", "4:1:1", "auto"), default="auto")
    p.add_argument("--jpeg-baseline", action="store_true")
    p.add_argument("--zopfli", action="store_true")
    p.add_argument("-e", "--exif", action="store_true")
    p.add_argument("--keep-dates", action="store_true")
    p.add_argument("--strip-icc", action="store_true")
    p.add_argument("--suffix", default="")
    p.add_argument("-R", "--recursive", action="store_true")
    p.add_argument("-S", "--keep-structure", action="store_true")
    p.add_argument("-d", "--dry-run", action="store_true")
    p.add_argument("--threads", type=int, default=0)
    p.add_argument("-O", "--overwrite", choices=("all", "never", "bigger"), default="all")
    p.add_argument("--min-savings")
    p.add_argument("-Q", "--quiet", action="store_true")
    p.add_argument("--verbose", type=int, default=1)
    return p


def fail_required(args):
    missing = []
    if args.quality is None and not args.lossless and args.max_size is None:
        missing.append("  <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>")
    if args.output is None and not args.same_folder_as_input:
        missing.append("  <--output <OUTPUT>|--same-folder-as-input>")
    if missing:
        print("error: the following required arguments were not provided:", file=sys.stderr)
        print("\n".join(missing), file=sys.stderr)
        files = " [FILES]..." if not args.files else " <FILES>..."
        print(f"\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input>{files}", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)


def validate(args):
    modes = sum([args.quality is not None, args.lossless, args.max_size is not None])
    if modes > 1:
        print("error: the argument '--quality <QUALITY>' cannot be used with '--lossless' or '--max-size <MAX_SIZE>'", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    fail_required(args)
    if args.output and args.same_folder_as_input:
        print("error: the argument '--output <OUTPUT>' cannot be used with '--same-folder-as-input'", file=sys.stderr)
        print("\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    if args.keep_structure and not args.recursive:
        # The reference accepts this for file inputs and simply has no effect; keep it permissive.
        pass
    edge_opts = [args.width is not None or args.height is not None, args.long_edge is not None, args.short_edge is not None]
    if sum(edge_opts) > 1:
        print("error: resizing options --width/--height, --long-edge and --short-edge are mutually exclusive", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)


def human(n):
    n = float(n)
    units = ["B", "KiB", "MiB", "GiB"]
    i = 0
    while abs(n) >= 1024 and i < len(units) - 1:
        n /= 1024.0
        i += 1
    if i == 0:
        return f"{int(n)} B"
    return f"{n:.1f} {units[i]}"


def parse_size(text):
    m = re.fullmatch(r"\s*([0-9]+(?:\.[0-9]+)?)\s*([kmgt]?i?b?)?\s*", text, re.I)
    if not m:
        return None
    value = float(m.group(1))
    unit = (m.group(2) or "").lower()
    mul = 1
    if unit in ("k", "kb"):
        mul = 1000
    elif unit == "kib":
        mul = 1024
    elif unit in ("m", "mb"):
        mul = 1000 ** 2
    elif unit == "mib":
        mul = 1024 ** 2
    elif unit in ("g", "gb"):
        mul = 1000 ** 3
    elif unit == "gib":
        mul = 1024 ** 3
    return int(value * mul)


def parse_min_savings(text, original):
    if not text:
        return 0
    if text.endswith("%"):
        try:
            return original * float(text[:-1]) / 100.0
        except ValueError:
            return 0
    return parse_size(text) or 0


def collect(files, recursive):
    result = []
    for raw in files:
        path = Path(raw)
        if path.is_dir():
            iterator = path.rglob("*") if recursive else path.iterdir()
            for item in iterator:
                if item.is_file() and item.suffix.lower() in IMAGE_EXTS:
                    result.append((item, path))
        elif path.is_file():
            result.append((path, path.parent))
    return result


def out_format(src, requested):
    if requested != "original":
        return requested
    ext = src.suffix.lower()
    if ext in (".jpg", ".jpeg"):
        return "jpeg"
    if ext == ".png":
        return "png"
    if ext == ".gif":
        return "gif"
    if ext == ".webp":
        return "webp"
    if ext in (".tif", ".tiff"):
        return "tiff"
    return "png"


def out_path(src, root, args):
    fmt = out_format(src, args.format)
    ext = src.suffix if args.format == "original" else EXTS[fmt]
    name = src.stem + args.suffix + ext
    if args.same_folder_as_input:
        return src.with_name(name)
    base = Path(args.output)
    if args.keep_structure and root and root.is_dir():
        try:
            rel_parent = src.parent.relative_to(root)
        except ValueError:
            rel_parent = Path()
        return base / rel_parent / name
    return base / name


def resize_image(img, args):
    w, h = img.size
    nw, nh = w, h
    if args.width and args.height:
        nw, nh = args.width, args.height
    elif args.width:
        nw = args.width
        nh = max(1, round(h * nw / w))
    elif args.height:
        nh = args.height
        nw = max(1, round(w * nh / h))
    elif args.long_edge:
        scale = args.long_edge / max(w, h)
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    elif args.short_edge:
        scale = args.short_edge / min(w, h)
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    if args.no_upscale and (nw > w or nh > h):
        return img
    if (nw, nh) == (w, h):
        return img
    return img.resize((nw, nh), Image.Resampling.LANCZOS)


def save_with_options(img, src, dest, fmt, args, quality):
    save_kwargs = {}
    if args.exif and "exif" in img.info:
        save_kwargs["exif"] = img.info["exif"]
    if not args.strip_icc and "icc_profile" in img.info:
        save_kwargs["icc_profile"] = img.info["icc_profile"]

    if fmt == "jpeg":
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        save_kwargs.update(format="JPEG", quality=max(1, min(100, quality)), optimize=True, progressive=not args.jpeg_baseline)
        subsampling = {"4:4:4": 0, "4:2:2": 1, "4:2:0": 2, "4:1:1": 2}.get(args.jpeg_chroma_subsampling)
        if subsampling is not None:
            save_kwargs["subsampling"] = subsampling
    elif fmt == "png":
        save_kwargs.update(format="PNG", optimize=True, compress_level=max(0, min(9, args.png_opt_level + 3)))
        if args.quality is not None and args.quality < 100 and img.mode not in ("P", "1"):
            colors = max(2, min(256, round(2 + args.quality / 100 * 254)))
            img = img.convert("RGBA").quantize(colors=colors)
    elif fmt == "webp":
        save_kwargs.update(format="WEBP", quality=max(1, min(100, quality)), lossless=args.lossless)
    elif fmt == "gif":
        save_kwargs.update(format="GIF", optimize=True)
        if getattr(img, "is_animated", False):
            img.save(dest, save_all=True, optimize=True)
            return
        if img.mode not in ("P", "L"):
            img = img.convert("P", palette=Image.Palette.ADAPTIVE)
    elif fmt == "tiff":
        save_kwargs.update(format="TIFF", compression="tiff_lzw")
    img.save(dest, **save_kwargs)


def compress_one(src, dest, args):
    original = src.stat().st_size
    fmt = out_format(src, args.format)
    quality = args.quality if args.quality is not None else (100 if args.lossless else 85)
    target = parse_size(args.max_size) if args.max_size else None
    if args.dry_run:
        return "success", original, max(1, int(original * (quality / 100.0 if not args.lossless else 0.95)))
    tmp = dest.with_name(dest.name + ".tmp")
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        with Image.open(src) as im0:
            im = ImageOps.exif_transpose(im0)
            im = resize_image(im, args)
            if target and fmt in ("jpeg", "webp"):
                best = None
                lo, hi = 1, 100
                for _ in range(7):
                    q = (lo + hi) // 2
                    save_with_options(im, src, tmp, fmt, args, q)
                    size = tmp.stat().st_size
                    if size <= target:
                        best = tmp.read_bytes()
                        lo = q + 1
                    else:
                        hi = q - 1
                if best is None:
                    save_with_options(im, src, tmp, fmt, args, 1)
                else:
                    tmp.write_bytes(best)
            else:
                save_with_options(im, src, tmp, fmt, args, quality)
    except Exception as exc:
        if tmp.exists():
            tmp.unlink()
        return "error", original, 0

    new_size = tmp.stat().st_size
    min_savings = parse_min_savings(args.min_savings, original)
    if min_savings and original - new_size < min_savings:
        tmp.unlink()
        return "skipped", original, 0
    if dest.exists():
        if args.overwrite == "never":
            tmp.unlink()
            return "skipped", original, 0
        if args.overwrite == "bigger" and dest.stat().st_size <= new_size:
            tmp.unlink()
            return "skipped", original, 0
    os.replace(tmp, dest)
    if args.keep_dates:
        st = src.stat()
        os.utime(dest, (st.st_atime, st.st_mtime))
    return "success", original, new_size


def main(argv):
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        return 0
    if "--help" in argv:
        print(HELP_FULL)
        return 0
    if "-h" in argv:
        print(HELP_SHORT)
        return 0
    parser = make_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as e:
        return int(e.code)
    validate(args)
    quiet = args.quiet or args.verbose == 0
    files = collect(args.files, args.recursive)
    if args.files and not files:
        print("Unable to compute the base path for the files.")
        return 255
    total_in = total_out = 0
    success = skipped = errors = 0
    for src, root in files:
        dest = out_path(src, root, args)
        status, old, new = compress_one(src, dest, args)
        total_in += old
        if status == "success":
            success += 1
            total_out += new
        elif status == "skipped":
            skipped += 1
        else:
            errors += 1
    if not quiet:
        print(f"Compressed {len(files)} files ({success} success, {skipped} skipped, {errors} errors)")
        diff = total_out - total_in
        pct = (diff / total_in * 100.0) if total_in else 0.0
        print(f"{human(total_in)} -> {human(total_out)} [{diff:+.0f} B | {pct:+.2f}%]" if abs(diff) < 1024 else f"{human(total_in)} -> {human(total_out)} [{human(diff) if diff < 0 else '+' + human(diff)} | {pct:+.2f}%]")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
