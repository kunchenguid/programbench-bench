#!/usr/bin/env python3
import math
import os
import re
import struct
import sys


VERSION = "Sloth 0.1"
BG = (25, 25, 25)


HELP = """Sloth 0.1
Mitchell Hynes. <mshynes@mun.ca>
A toy for rendering 3D objects in the command line

USAGE:
    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -x, --yaw <x>      Sets the object's static X rotation (in radians)
    -y, --pitch <y>    Sets the object's static Y rotation (in radians)
    -z, --roll <z>     Sets the object's static Z rotation (in radians)

ARGS:
    <input filename(s)>...    Sets the input file to render

SUBCOMMANDS:
    help     Prints this message or the help of the given subcommand(s)
    image    Generates a colorless terminal output as lines of text"""


IMAGE_HELP = """executable-image 
Mitchell Hynes <mitchell.hynes@ecumene.xyz>
Generates a colorless terminal output as lines of text

USAGE:
    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>

FLAGS:
        --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -j, --webify <frame count>    Generates a portable JS based render of your object for the web
    -h <height>                   Sets the height of the image to generate
    -w <width>                    Sets the width of the image to generate
    -x, --yaw <x>                 Sets the object's static X rotation (in radians)
    -y, --pitch <y>               Sets the object's static Y rotation (in radians)
    -z, --roll <z>                Sets the object's static Z rotation (in radians)"""


def fail(msg, code=1):
    print(msg, file=sys.stderr)
    raise SystemExit(code)


def rust_panic(message):
    print("\nthread 'main' panicked at src/inputs.rs:112:39:", file=sys.stderr)
    print(message, file=sys.stderr)
    print("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace", file=sys.stderr)
    raise SystemExit(101)


def parse_float(value, name):
    try:
        return float(value)
    except Exception:
        fail(f"error: Invalid value for '{name}': {value}")


def parse_int(value, name):
    try:
        return int(value)
    except Exception:
        fail(f"error: Invalid value for '{name}': {value}")


def parse_args(argv):
    cfg = {
        "inputs": [],
        "image": False,
        "width": None,
        "height": None,
        "webify": None,
        "yaw": 0.0,
        "pitch": 0.0,
        "roll": 0.0,
        "plain": False,
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("--help", "-h") and not cfg["image"]:
            print(HELP)
            raise SystemExit(0)
        if arg == "help":
            if i + 1 < len(argv) and argv[i + 1] == "image":
                print(IMAGE_HELP)
            else:
                print(HELP)
            raise SystemExit(0)
        if arg == "image":
            cfg["image"] = True
            i += 1
            continue
        if arg == "--help" and cfg["image"]:
            print(IMAGE_HELP)
            raise SystemExit(0)
        if arg in ("--version", "-V"):
            print(VERSION)
            raise SystemExit(0)
        if arg == "-b":
            cfg["plain"] = True
            i += 1
            continue
        if arg in ("-x", "--yaw", "-y", "--pitch", "-z", "--roll", "-w", "-j", "--webify"):
            if i + 1 >= len(argv):
                fail(f"error: The argument '{arg}' requires a value but none was supplied")
            val = argv[i + 1]
            if arg in ("-x", "--yaw"):
                cfg["yaw"] = parse_float(val, arg)
            elif arg in ("-y", "--pitch"):
                cfg["pitch"] = parse_float(val, arg)
            elif arg in ("-z", "--roll"):
                cfg["roll"] = parse_float(val, arg)
            elif arg == "-w":
                cfg["width"] = parse_int(val, arg)
            elif arg in ("-j", "--webify"):
                cfg["webify"] = parse_int(val, arg)
            i += 2
            continue
        if arg == "-h" and cfg["image"]:
            if i + 1 >= len(argv):
                fail("error: The argument '-h' requires a value but none was supplied")
            cfg["height"] = parse_int(argv[i + 1], arg)
            i += 2
            continue
        if arg.startswith("-"):
            fail(f"error: Found argument '{arg}' which wasn't expected")
        cfg["inputs"].extend(arg.split())
        i += 1
    if not cfg["inputs"]:
        print(HELP)
        raise SystemExit(0)
    if cfg["image"] and cfg["width"] is None:
        fail("error: The following required arguments were not provided:\n    -w <width>")
    if cfg["width"] is None:
        cfg["width"] = 80
    if cfg["height"] is None:
        cfg["height"] = max(1, cfg["width"] // 2)
    return cfg


def vec_sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def norm(v):
    l = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    if l == 0:
        return (0.0, 0.0, 1.0)
    return (v[0] / l, v[1] / l, v[2] / l)


def color255(rgb):
    return tuple(max(0, min(255, int(round(c * 255 if c <= 1 else c)))) for c in rgb)


def load_mtl(path):
    colors = {}
    current = None
    try:
        with open(path, "r", errors="ignore") as f:
            for line in f:
                parts = line.strip().split()
                if not parts:
                    continue
                if parts[0] == "newmtl" and len(parts) > 1:
                    current = parts[1]
                elif parts[0] == "Kd" and current and len(parts) >= 4:
                    colors[current] = color255(tuple(float(x) for x in parts[1:4]))
    except OSError:
        rust_panic("Expected to have materials.: OpenFileFailed")
    return colors


def parse_face_token(tok, nverts):
    idx = tok.split("/")[0]
    if not idx:
        return None
    val = int(idx)
    return val - 1 if val > 0 else nverts + val


def load_obj(path):
    verts = []
    tris = []
    colors = {}
    current_color = (255, 255, 0)
    base = os.path.dirname(path) or "."
    with open(path, "r", errors="ignore") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            parts = s.split()
            if parts[0] == "mtllib" and len(parts) > 1:
                colors.update(load_mtl(os.path.join(base, parts[1])))
            elif parts[0] == "usemtl" and len(parts) > 1:
                current_color = colors.get(parts[1], current_color)
            elif parts[0] == "v" and len(parts) >= 4:
                verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
            elif parts[0] == "f" and len(parts) >= 4:
                ids = [parse_face_token(p, len(verts)) for p in parts[1:]]
                ids = [x for x in ids if x is not None and 0 <= x < len(verts)]
                for k in range(1, len(ids) - 1):
                    tri = (verts[ids[0]], verts[ids[k]], verts[ids[k + 1]], current_color)
                    tris.append(tri)
    return tris


def load_ascii_stl(text):
    verts = []
    tris = []
    for line in text.splitlines():
        parts = line.strip().split()
        if len(parts) == 4 and parts[0] == "vertex":
            verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
            if len(verts) == 3:
                tris.append((verts[0], verts[1], verts[2], (255, 255, 0)))
                verts = []
    return tris


def load_binary_stl(data):
    if len(data) < 84:
        return []
    count = struct.unpack_from("<I", data, 80)[0]
    off = 84
    tris = []
    for _ in range(min(count, (len(data) - 84) // 50)):
        vals = struct.unpack_from("<12fH", data, off)
        p1 = (vals[3], vals[4], vals[5])
        p2 = (vals[6], vals[7], vals[8])
        p3 = (vals[9], vals[10], vals[11])
        tris.append((p1, p2, p3, (255, 255, 0)))
        off += 50
    return tris


def load_stl(path):
    data = open(path, "rb").read()
    head = data[:256].decode("utf-8", errors="ignore")
    if head.lstrip().startswith("solid"):
        tris = load_ascii_stl(data.decode("utf-8", errors="ignore"))
        if tris:
            return tris
    return load_binary_stl(data)


def load_model(paths):
    tris = []
    for path in paths:
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext == ".obj":
                tris.extend(load_obj(path))
            elif ext == ".stl":
                tris.extend(load_stl(path))
            else:
                tris.extend(load_obj(path))
        except FileNotFoundError:
            rust_panic(f"Unable to open file: {path}")
    return tris


def rotate_point(p, yaw, pitch, roll):
    x, y, z = p
    cy, sy = math.cos(yaw), math.sin(yaw)
    y, z = y * cy - z * sy, y * sy + z * cy
    cp, sp = math.cos(pitch), math.sin(pitch)
    x, z = x * cp + z * sp, -x * sp + z * cp
    cr, sr = math.cos(roll), math.sin(roll)
    x, y = x * cr - y * sr, x * sr + y * cr
    return (x, y, z)


def edge(a, b, c):
    return (c[0] - a[0]) * (b[1] - a[1]) - (c[1] - a[1]) * (b[0] - a[0])


def shade_char(intensity):
    chars = " .:-=+*#%@"
    return chars[max(0, min(len(chars) - 1, int(intensity * (len(chars) - 1))))]


def render(tris, width, height, yaw, pitch, roll):
    if width <= 0 or height <= 0:
        return []
    rtris = []
    pts = []
    for a, b, c, color in tris:
        ra, rb, rc = rotate_point(a, yaw, pitch, roll), rotate_point(b, yaw, pitch, roll), rotate_point(c, yaw, pitch, roll)
        rtris.append((ra, rb, rc, color))
        pts.extend([ra, rb, rc])
    if not pts:
        return [[(" ", (0, 0, 0)) for _ in range(width)] for _ in range(height)]
    minx, maxx = min(p[0] for p in pts), max(p[0] for p in pts)
    miny, maxy = min(p[1] for p in pts), max(p[1] for p in pts)
    sx = (width - 2) / (maxx - minx or 1.0)
    sy = (height - 2) / (maxy - miny or 1.0)
    scale = min(sx, sy)
    ox = (width - (maxx - minx) * scale) / 2.0
    oy = (height - (maxy - miny) * scale) / 2.0

    def project(p):
        return (ox + (p[0] - minx) * scale, height - 1 - (oy + (p[1] - miny) * scale), p[2])

    zbuf = [[-1e100 for _ in range(width)] for _ in range(height)]
    frame = [[(" ", (0, 0, 0)) for _ in range(width)] for _ in range(height)]
    light = norm((-0.25, -0.35, 1.0))
    for a, b, c, color in rtris:
        n = norm(cross(vec_sub(b, a), vec_sub(c, a)))
        intensity = max(0.15, min(1.0, n[0] * light[0] + n[1] * light[1] + n[2] * light[2]))
        pa, pb, pc = project(a), project(b), project(c)
        xs = [pa[0], pb[0], pc[0]]
        ys = [pa[1], pb[1], pc[1]]
        min_px = max(0, int(math.floor(min(xs))))
        max_px = min(width - 1, int(math.ceil(max(xs))))
        min_py = max(0, int(math.floor(min(ys))))
        max_py = min(height - 1, int(math.ceil(max(ys))))
        area = edge(pa, pb, pc)
        if abs(area) < 1e-9:
            continue
        for yy in range(min_py, max_py + 1):
            for xx in range(min_px, max_px + 1):
                p = (xx + 0.5, yy + 0.5)
                w0 = edge(pb, pc, p) / area
                w1 = edge(pc, pa, p) / area
                w2 = edge(pa, pb, p) / area
                if w0 >= -1e-6 and w1 >= -1e-6 and w2 >= -1e-6:
                    z = w0 * pa[2] + w1 * pb[2] + w2 * pc[2]
                    if z > zbuf[yy][xx]:
                        zbuf[yy][xx] = z
                        char = shade_char(intensity)
                        shaded = tuple(max(0, min(255, int(cn * (0.45 + 0.55 * intensity)))) for cn in color)
                        frame[yy][xx] = (char, shaded)
    return frame


def ansi_frame(frame, plain=False):
    lines = []
    for row in frame:
        out = []
        for ch, fg in row:
            if plain:
                fg = (255, 255, 255) if ch != " " else (0, 0, 0)
            out.append(f"\x1b[48;2;{BG[0]};{BG[1]};{BG[2]}m\x1b[38;2;{fg[0]};{fg[1]};{fg[2]}m{ch}\x1b[49m\x1b[39m")
        lines.append("".join(out))
    return "\n".join(lines)


def html_frame(frame, plain=False):
    lines = []
    for row in frame:
        out = []
        for ch, fg in row:
            if plain:
                fg = (255, 255, 255) if ch != " " else (0, 0, 0)
            out.append(f'<span style="color:rgb({fg[0]},{fg[1]},{fg[2]})">{ch}')
        lines.append("".join(out))
    return "\n".join(lines)


def interactive(cfg, tris):
    # The original is an animated terminal toy. In non-interactive test runs a
    # single frame is the useful observable behavior and avoids blocking.
    frame = render(tris, cfg["width"], cfg["height"], cfg["yaw"], cfg["pitch"], cfg["roll"])
    print(ansi_frame(frame, cfg["plain"]))


def main(argv):
    cfg = parse_args(argv)
    tris = load_model(cfg["inputs"])
    if cfg["image"]:
        if cfg["webify"] is not None:
            count = max(0, cfg["webify"])
            print("let frames = [")
            for i in range(count):
                angle = cfg["yaw"] + (2 * math.pi * i / max(1, count))
                frame = render(tris, cfg["width"], cfg["height"], angle, cfg["pitch"], cfg["roll"])
                comma = "," if i + 1 < count else ""
                print("`")
                print(html_frame(frame, cfg["plain"]), end="")
                print(f"`{comma}")
            print("];")
        else:
            frame = render(tris, cfg["width"], cfg["height"], cfg["yaw"], cfg["pitch"], cfg["roll"])
            print(ansi_frame(frame, cfg["plain"]))
    else:
        interactive(cfg, tris)


if __name__ == "__main__":
    main(sys.argv[1:])
