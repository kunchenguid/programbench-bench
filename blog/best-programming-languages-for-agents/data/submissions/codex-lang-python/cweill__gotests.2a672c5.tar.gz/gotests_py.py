#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
from dataclasses import dataclass

VERSION = """gotests v0.0.0-20260303205902-f3b63d74369a
Go version: go1.24.5
Git commit: f3b63d74369a8c405a9a3990a656a278a4f9096f
Build time: 2026-03-03T20:59:02Z"""


@dataclass
class Param:
    name: str
    typ: str
    variadic: bool = False


@dataclass
class Result:
    name: str
    typ: str


@dataclass
class Func:
    name: str
    recv_name: str
    recv_type: str
    recv_base: str
    type_params: str
    recv_type_params: str
    params: list
    results: list


def strip_comments(src):
    out = []
    i = 0
    n = len(src)
    in_str = ""
    while i < n:
        c = src[i]
        if in_str:
            out.append(c)
            if c == "\\" and i + 1 < n:
                out.append(src[i + 1])
                i += 2
                continue
            if c == in_str:
                in_str = ""
            i += 1
            continue
        if c in ('"', "'", "`"):
            in_str = c
            out.append(c)
            i += 1
            continue
        if src.startswith("//", i):
            j = src.find("\n", i)
            if j == -1:
                break
            out.append("\n")
            i = j + 1
            continue
        if src.startswith("/*", i):
            j = src.find("*/", i + 2)
            if j == -1:
                break
            out.append("\n" * src[i:j + 2].count("\n"))
            i = j + 2
            continue
        out.append(c)
        i += 1
    return "".join(out)


def find_matching(s, start, op, cl):
    depth = 0
    in_str = ""
    i = start
    while i < len(s):
        c = s[i]
        if in_str:
            if c == "\\" and in_str != "`":
                i += 2
                continue
            if c == in_str:
                in_str = ""
            i += 1
            continue
        if c in ('"', "'", "`"):
            in_str = c
        elif c == op:
            depth += 1
        elif c == cl:
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def split_top(s, sep=","):
    parts, cur = [], []
    depths = {"(": 0, "[": 0, "{": 0}
    pairs = {")": "(", "]": "[", "}": "{"}
    in_str = ""
    i = 0
    while i < len(s):
        c = s[i]
        if in_str:
            cur.append(c)
            if c == "\\" and in_str != "`" and i + 1 < len(s):
                cur.append(s[i + 1])
                i += 2
                continue
            if c == in_str:
                in_str = ""
            i += 1
            continue
        if c in ('"', "'", "`"):
            in_str = c
            cur.append(c)
        elif c in depths:
            depths[c] += 1
            cur.append(c)
        elif c in pairs:
            depths[pairs[c]] -= 1
            cur.append(c)
        elif c == sep and all(v == 0 for v in depths.values()):
            part = "".join(cur).strip()
            if part:
                parts.append(part)
            cur = []
        else:
            cur.append(c)
        i += 1
    part = "".join(cur).strip()
    if part:
        parts.append(part)
    return parts


def split_fields(part):
    fields, cur = [], []
    depths = {"(": 0, "[": 0, "{": 0}
    pairs = {")": "(", "]": "[", "}": "{"}
    for c in part.strip():
        if c in depths:
            depths[c] += 1
        elif c in pairs:
            depths[pairs[c]] -= 1
        if c.isspace() and all(v == 0 for v in depths.values()):
            if cur:
                fields.append("".join(cur))
                cur = []
        else:
            cur.append(c)
    if cur:
        fields.append("".join(cur))
    return fields


def parse_params(s):
    if not s.strip():
        return []
    res = []
    pending = []
    parts = split_top(s)
    for idx, part in enumerate(parts):
        fields = split_fields(part)
        if not fields:
            continue
        if len(fields) == 1:
            # In Go signatures, "a, b int" is tokenized here as "a" then
            # "b int"; keep the bare identifiers pending until the typed part.
            if idx + 1 < len(parts) and len(split_fields(parts[idx + 1])) >= 2 and re.match(r"^[_A-Za-z]\w*$", fields[0]):
                pending.append(fields[0])
                continue
            typ = fields[0]
            names = [f"arg{len(res)}"]
        else:
            typ = fields[-1]
            names = pending + [x for x in " ".join(fields[:-1]).split(",") if x.strip()]
            pending = []
        variadic = typ.startswith("...")
        if variadic:
            typ = "[]" + typ[3:].strip()
        for nm in names:
            nm = nm.strip()
            if not nm or nm == "_":
                nm = f"arg{len(res)}"
            res.append(Param(nm, typ.strip(), variadic))
    return res


def parse_results(s):
    s = s.strip()
    if not s:
        return []
    if s.startswith("(") and s.endswith(")"):
        parts = split_top(s[1:-1])
    else:
        parts = [s]
    out = []
    for part in parts:
        fields = split_fields(part)
        if not fields:
            continue
        if len(fields) == 1:
            out.append(Result("", fields[0]))
        else:
            typ = fields[-1]
            for nm in " ".join(fields[:-1]).split(","):
                out.append(Result(nm.strip(), typ))
    return out


def base_recv_type(t):
    t = re.sub(r"^\*+", "", t.strip())
    t = t.split("[", 1)[0]
    return t


def parse_receiver(s):
    ps = parse_params(s)
    if ps:
        return ps[0].name, ps[0].typ, base_recv_type(ps[0].typ)
    fields = split_fields(s)
    typ = fields[-1] if fields else ""
    return "", typ, base_recv_type(typ)


def parse_functions(src):
    clean = strip_comments(src)
    funcs = []
    pkg_m = re.search(r"(?m)^\s*package\s+([A-Za-z_]\w*)", clean)
    pkg = pkg_m.group(1) if pkg_m else "main"
    type_params_by_name = {}
    for tm in re.finditer(r"\btype\s+([A-Za-z_]\w*)\s*\[", clean):
        lb = tm.end() - 1
        rb = find_matching(clean, lb, "[", "]")
        if rb != -1:
            type_params_by_name[tm.group(1)] = clean[lb + 1:rb].strip()
    i = 0
    while True:
        m = re.search(r"\bfunc\b", clean[i:])
        if not m:
            break
        pos = i + m.start()
        j = pos + 4
        while j < len(clean) and clean[j].isspace():
            j += 1
        recv_name = recv_type = recv_base = ""
        if j < len(clean) and clean[j] == "(":
            k = find_matching(clean, j, "(", ")")
            recv_name, recv_type, recv_base = parse_receiver(clean[j + 1:k])
            j = k + 1
            while j < len(clean) and clean[j].isspace():
                j += 1
        nm = re.match(r"([A-Za-z_]\w*)", clean[j:])
        if not nm:
            i = j + 1
            continue
        name = nm.group(1)
        j += len(name)
        type_params = ""
        while j < len(clean) and clean[j].isspace():
            j += 1
        if j < len(clean) and clean[j] == "[":
            k = find_matching(clean, j, "[", "]")
            type_params = clean[j + 1:k].strip()
            j = k + 1
            while j < len(clean) and clean[j].isspace():
                j += 1
        if j >= len(clean) or clean[j] != "(":
            i = j + 1
            continue
        k = find_matching(clean, j, "(", ")")
        params = parse_params(clean[j + 1:k])
        j = k + 1
        while j < len(clean) and clean[j].isspace():
            j += 1
        rstart = j
        if j < len(clean) and clean[j] == "(":
            r_end = find_matching(clean, j, "(", ")")
            returns = clean[j:r_end + 1]
            j = r_end + 1
        else:
            while j < len(clean) and clean[j] not in "{\n":
                j += 1
            returns = clean[rstart:j].strip()
        recv_type_params = type_params_by_name.get(recv_base, "")
        funcs.append(Func(name, recv_name, recv_type, recv_base, type_params, recv_type_params, params, parse_results(returns)))
        i = j + 1
    return pkg, funcs


def is_exported(name):
    return bool(name and name[0].isupper())


def concrete_type(t):
    t = t.strip()
    if t in ("any", "interface{}"):
        return "int"
    if t == "comparable":
        return "string"
    if "|" in t:
        return concrete_type(t.split("|", 1)[0])
    if t.startswith("~"):
        return t[1:].strip()
    return "int"


def type_map(type_params):
    mp = {}
    for part in split_top(type_params):
        f = split_fields(part)
        if len(f) >= 2:
            typ = concrete_type(" ".join(f[1:]))
            for name in f[0].split(","):
                mp[name.strip()] = typ
    return mp


def subst_type(t, mp):
    t = t.strip()
    for k, v in mp.items():
        t = re.sub(rf"\b{re.escape(k)}\b", v, t)
    return t


def comparable(t):
    t = t.strip()
    return not (t.startswith("[]") or t.startswith("map[") or t.startswith("func(") or t == "interface{}" or t == "any")


def has_error(results):
    return results and results[-1].typ.strip() == "error"


def align(rows):
    if not rows:
        return []
    width = max(len(r[0]) for r in rows)
    return [r[0] + (" " * (width - len(r[0]) + 1)) + r[1] for r in rows]


def test_name(fn):
    if fn.recv_base:
        sep = "_" if is_exported(fn.name) else "_"
        return f"Test{fn.recv_base}{sep}{fn.name}"
    return f"Test{fn.name}" if is_exported(fn.name) else f"Test_{fn.name}"


def call_name(fn, mp):
    suffix = ""
    if fn.type_params:
        vals = [v for v in mp.values()]
        suffix = "[" + ", ".join(vals) + "]"
    return fn.name + suffix


def actual_args(fn):
    args = []
    for p in fn.params:
        a = f"tt.args.{p.name}"
        if p.variadic:
            a += "..."
        args.append(a)
    return ", ".join(args)


def msg_args(fn):
    return ", ".join(f"tt.args.{p.name}" for p in fn.params)


def emit_func(fn, opt):
    mp = type_map(fn.type_params)
    for k, v in type_map(fn.recv_type_params).items():
        mp.setdefault(k, v)
    params = [Param(p.name, subst_type(p.typ, mp), p.variadic) for p in fn.params]
    results = [Result(r.name, subst_type(r.typ, mp)) for r in fn.results]
    efn = Func(fn.name, fn.recv_name, subst_type(fn.recv_type, mp), fn.recv_base, fn.type_params, fn.recv_type_params, params, results)
    out = [f"func {test_name(fn)}(t *testing.T) {{"]
    if opt.parallel:
        out.append("\tt.Parallel()")
    if params:
        out.append("\ttype args struct {")
        for line in align([(p.name, p.typ) for p in params]):
            out.append("\t\t" + line)
        out.append("\t}")
    named = opt.named
    out.append("\ttests := " + ("map[string]struct {" if named else "[]struct {"))
    rows = []
    if not named:
        rows.append(("name", "string"))
    if efn.recv_base:
        rn = fn.recv_name or fn.recv_base[:1].lower()
        rows.append((rn, efn.recv_type))
    if params:
        rows.append(("args", "args"))
    err = has_error(results)
    check_results = results[:-1] if err else results
    for idx, r in enumerate(check_results):
        base = "want" if idx == 0 else f"want{idx}"
        if r.name:
            base = "want" + r.name[:1].upper() + r.name[1:]
        rows.append((base, r.typ))
    if err:
        rows.append(("wantErr", "bool"))
    for line in align(rows):
        out.append("\t\t" + line)
    out.append("\t}{")
    out.append("\t\t// TODO: Add test cases.")
    out.append("\t}")
    loop = "for name, tt := range tests {" if named else "for _, tt := range tests {"
    out.append("\t" + loop)
    use_sub = not opt.nosubtests
    if use_sub:
        out.append(('\t\tt.Run(name, func(t *testing.T) {' if named else '\t\tt.Run(tt.name, func(t *testing.T) {'))
        body_indent = "\t\t\t"
        if opt.parallel:
            out.append(body_indent + "t.Parallel()")
    else:
        body_indent = "\t\t"
    recv_var = ""
    if efn.recv_base:
        recv_var = fn.recv_name or efn.recv_base[:1].lower()
        out.append(body_indent + f"{recv_var} := {zero_recv(efn.recv_type)}")
    call = (f"{recv_var}.{call_name(fn, mp)}({actual_args(efn)})" if recv_var else f"{call_name(fn, mp)}({actual_args(efn)})")
    label = f"{efn.recv_base}.{fn.name}" if efn.recv_base else fn.name
    if not results:
        out.append(body_indent + call)
    else:
        got_names = []
        for i, r in enumerate(check_results):
            if r.name:
                got_names.append("got" + r.name[:1].upper() + r.name[1:])
            else:
                got_names.append("got" if i == 0 else f"got{i}")
        if err:
            assigns = got_names + ["err"]
        else:
            assigns = got_names
        if len(assigns) == 1:
            prefix = f"if got := {call}; "
            emit_compare(out, body_indent, opt, label, params, "got", "tt.want", check_results[0].typ, prefix=prefix, single_if=True, multi=False)
        else:
            out.append(body_indent + ", ".join(assigns) + f" := {call}")
            if err:
                fail = "Fatalf" if use_sub else "Errorf"
                prefix = input_prefix(label, params, opt, " error")
                if opt.i and params:
                    fmt = f'{label}({prefix[0]}) error = %v, wantErr %v'
                    vals = prefix[1] + ["err", "tt.wantErr"]
                else:
                    fmt = f'{label}() error = %v, wantErr %v'
                    vals = ["err", "tt.wantErr"]
                if not use_sub:
                    fmt = '%q. ' + fmt
                    vals = ["tt.name"] + vals
                out.append(body_indent + f'if (err != nil) != tt.wantErr {{')
                out.append(body_indent + f'\tt.{fail}("{fmt}", {", ".join(vals)})')
                if not use_sub:
                    out.append(body_indent + "\tcontinue")
                out.append(body_indent + "}")
                out.append(body_indent + "if tt.wantErr {")
                out.append(body_indent + "\treturn")
                out.append(body_indent + "}")
            for i, r in enumerate(check_results):
                want = "tt.want" if i == 0 else f"tt.want{i}"
                if r.name:
                    want = "tt.want" + r.name[:1].upper() + r.name[1:]
                emit_compare(out, body_indent, opt, label, params, got_names[i], want, r.typ, multi=(len(check_results) > 1))
    if use_sub:
        out.append("\t\t})")
    out.append("\t}")
    out.append("}")
    return "\n".join(out)


def zero_recv(t):
    if t.strip().startswith("*"):
        return "&" + t.strip()[1:] + "{}"
    return t.strip() + "{}"


def input_prefix(label, params, opt, extra=""):
    if opt.i and params:
        return ("%v" + (", %v" * (len(params) - 1)), [f"tt.args.{p.name}" for p in params])
    return ("", [])


def emit_compare(out, indent, opt, label, params, got, want, typ, prefix="", single_if=False, multi=False):
    deep = not comparable(typ)
    if deep:
        if opt.use_go_cmp:
            cond = f"!cmp.Equal({want}, {got})"
        else:
            cond = f"!reflect.DeepEqual({got}, {want})"
    else:
        cond = f"{got} != {want}"
    if single_if:
        out.append(indent + prefix + cond + " {")
    else:
        out.append(indent + f"if {cond} {{")
    lead = f"{label}()"
    vals = []
    if opt.i and params:
        fmt_args = "%v" + (", %v" * (len(params) - 1))
        lead = f"{label}({fmt_args})"
        vals.extend(f"tt.args.{p.name}" for p in params)
    suffix = ""
    if multi:
        suffix = (" got" if got == "got" else f" {got}") + " ="
    else:
        suffix = " ="
    fmt = f"{lead}{suffix} %v, want %v"
    vals.extend([got, want])
    if opt.use_go_cmp and deep:
        fmt += "\\ndiff=%s"
        vals.append(f"cmp.Diff({want}, {got})")
    if opt.nosubtests:
        fmt = "%q. " + fmt
        vals = ["tt.name"] + vals
    out.append(indent + f'\tt.Errorf("{fmt}", {", ".join(vals)})')
    out.append(indent + "}")


def render(pkg, funcs, opt):
    use_reflect = False
    use_cmp = False
    chunks = []
    for fn in funcs:
        txt = emit_func(fn, opt)
        chunks.append(txt)
        for r in fn.results:
            if r.typ != "error" and not comparable(subst_type(r.typ, type_map(fn.type_params))):
                if opt.use_go_cmp:
                    use_cmp = True
                else:
                    use_reflect = True
    imports = ['"testing"']
    if use_reflect:
        imports.insert(0, '"reflect"')
    if use_cmp:
        imports.append('"github.com/google/go-cmp/cmp"')
    out = [f"package {pkg}", ""]
    if len(imports) == 1:
        out += [f"import {imports[0]}", ""]
    else:
        out.append("import (")
        for idx, im in enumerate(imports):
            if use_cmp and idx == 1:
                out.append("")
            out.append("\t" + im)
        out += [")", ""]
    out.append("\n\n".join(chunks))
    out.append("")
    return "\n".join(out)


def select_funcs(funcs, opt):
    out = []
    only_re = re.compile(opt.only) if opt.only else None
    excl_re = re.compile(opt.excl) if opt.excl else None
    for f in funcs:
        tn = test_name(f)[4:]
        ok = False
        if opt.excl:
            ok = not (excl_re.search(f.name) or excl_re.search(tn))
        elif opt.exported:
            ok = is_exported(f.name)
        elif opt.only:
            ok = bool(only_re.search(f.name) or only_re.search(tn))
        elif opt.all:
            ok = True
        if ok:
            out.append(f)
    return out


def expand_paths(paths):
    res = []
    for p in paths:
        if p.endswith("/..."):
            root = p[:-4] or "."
            for d, dirs, files in os.walk(root):
                dirs[:] = [x for x in dirs if not x.startswith(".")]
                for f in files:
                    if f.endswith(".go") and not f.endswith("_test.go"):
                        res.append(os.path.join(d, f))
        elif os.path.isdir(p):
            for f in sorted(os.listdir(p)):
                if f.endswith(".go") and not f.endswith("_test.go"):
                    res.append(os.path.join(p, f))
        else:
            res.append(p)
    return res


def test_path(path):
    if path.endswith("_test.go"):
        return path
    return path[:-3] + "_test.go" if path.endswith(".go") else path + "_test.go"


def process_file(path, opt):
    with open(path, "r", encoding="utf-8") as f:
        src = f.read()
    pkg, funcs = parse_functions(src)
    chosen = select_funcs(funcs, opt)
    for fn in chosen:
        print(f"Generated {test_name(fn)}")
    if not chosen:
        return ""
    return render(pkg, chosen, opt)


def main(argv):
    p = argparse.ArgumentParser(add_help=False, usage="Usage of ./executable:")
    p.add_argument("-ai", action="store_true")
    p.add_argument("-ai-endpoint", default="http://localhost:11434")
    p.add_argument("-ai-max-cases", type=int, default=10)
    p.add_argument("-ai-min-cases", type=int, default=3)
    p.add_argument("-ai-model", default="qwen2.5-coder:0.5b")
    p.add_argument("-all", action="store_true")
    p.add_argument("-excl", default="")
    p.add_argument("-exported", action="store_true")
    p.add_argument("-i", action="store_true")
    p.add_argument("-named", action="store_true")
    p.add_argument("-nosubtests", action="store_true")
    p.add_argument("-only", default="")
    p.add_argument("-parallel", action="store_true")
    p.add_argument("-template", default=os.environ.get("GOTESTS_TEMPLATE", ""))
    p.add_argument("-template_dir", default=os.environ.get("GOTESTS_TEMPLATE_DIR", ""))
    p.add_argument("-template_params", default="")
    p.add_argument("-template_params_file", default="")
    p.add_argument("-use_go_cmp", action="store_true")
    p.add_argument("-version", action="store_true")
    p.add_argument("-w", action="store_true")
    p.add_argument("--help", action="store_true")
    p.add_argument("-help", action="store_true")
    p.add_argument("paths", nargs="*")
    opt, unknown = p.parse_known_args(argv)
    if opt.help:
        print("""Usage of ./executable:
  -ai
    \tgenerate test cases using AI (requires Ollama)
  -ai-endpoint string
    \tOllama API endpoint (default "http://localhost:11434")
  -ai-max-cases int
    \tmaximum number of test cases to generate with AI (default 10)
  -ai-min-cases int
    \tminimum number of test cases to generate with AI (default 3)
  -ai-model string
    \tAI model to use for test generation (default "qwen2.5-coder:0.5b")
  -all
    \tgenerate tests for all functions and methods
  -excl string
    \tregexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all
  -exported
    \tgenerate tests for exported functions and methods. Takes precedence over -only and -all
  -i\tprint test inputs in error messages
  -named
    \tswitch table tests from using slice to map (with test name for the key)
  -nosubtests
    \tdisable generating tests using the Go 1.7 subtests feature
  -only string
    \tregexp. generate tests for functions and methods that match only. Takes precedence over -all
  -parallel
    \tenable generating parallel subtests using the Go 1.7 feature
  -template string
    \toptional. Specify custom test code templates, e.g. testify. This can also be set via environment variable GOTESTS_TEMPLATE
  -template_dir string
    \toptional. Path to a directory containing custom test code templates. Takes precedence over -template. This can also be set via environment variable GOTESTS_TEMPLATE_DIR
  -template_params string
    \tread external parameters to template by json with stdin
  -template_params_file string
    \tread external parameters to template by json with file
  -use_go_cmp
    \tuse cmp.Equal (google/go-cmp) instead of reflect.DeepEqual
  -version
    \tprint version information and exit
  -w\twrite output to (test) files instead of stdout""")
        return 0
    if opt.version:
        print(VERSION)
        return 0
    if not (opt.only or opt.excl or opt.exported or opt.all):
        print("Please specify either the -only, -excl, -exported, or -all flag")
        return 0
    if opt.template_params:
        try:
            json.load(sys.stdin)
        except Exception:
            pass
    if opt.template_params_file:
        try:
            with open(opt.template_params_file, "r", encoding="utf-8") as f:
                json.load(f)
        except Exception:
            pass
    if not opt.paths:
        return 0
    for path in expand_paths(opt.paths):
        try:
            txt = process_file(path, opt)
        except Exception as e:
            print(str(e))
            continue
        if not txt:
            continue
        if opt.w:
            with open(test_path(path), "w", encoding="utf-8") as f:
                f.write(txt)
        else:
            sys.stdout.write(txt)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
