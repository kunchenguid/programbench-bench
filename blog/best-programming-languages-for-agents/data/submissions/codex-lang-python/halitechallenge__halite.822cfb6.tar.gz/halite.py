#!/usr/bin/env python3
import argparse
import math
import os
import random
import select
import subprocess
import sys
import time
from dataclasses import dataclass


HELP = """
USAGE: 

   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                 string containing two space-seprated positive integers>]
                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                 [-h] <Array of strings> ...


Where: 

   -i <path to directory>,  --replaydirectory <path to directory>
     The path to directory for replay output.

   -s <positive integer>,  --seed <positive integer>
     The seed for the map generator.

   -d <a string containing two space-seprated positive integers>, 
      --dimensions <a string containing two space-seprated positive
      integers>
     The dimensions of the map.

   -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>
     Create a map that will accommodate n players [SINGLE PLAYER MODE
     ONLY].

   -r,  --noreplay
     Turns off the replay generation.

   -t,  --timeout
     Causes game environment to ignore timeouts (give all bots infinite
     time).

   -o,  --override
     Overrides player-sent names using cmd args [SERVER ONLY].

   -q,  --quiet
     Runs game in quiet mode, producing machine-parsable output.

   --,  --ignore_rest
     Ignores the rest of the labeled arguments following this flag.

   --version
     Displays version information and exits.

   -h,  --help
     Displays usage information and exits.

   <Array of strings>  (accepted multiple times)
     Start commands for bots.


   Halite Game Environment
"""


DIRS = {0: (0, 0), 1: (0, -1), 2: (1, 0), 3: (0, 1), 4: (-1, 0)}


@dataclass
class Bot:
    pid: int
    command: str
    proc: subprocess.Popen
    name: str = ""
    alive: bool = True
    last_alive: int = 0
    rank: int = 0
    error: str = ""


def parse_args(argv):
    if "--version" in argv:
        print("./executable  version: 1.2")
        raise SystemExit(0)
    if "-h" in argv or "--help" in argv:
        print(HELP)
        raise SystemExit(0)

    replay_dir = "."
    seed = None
    dims = None
    nplayers = None
    noreplay = False
    timeout = False
    override = False
    quiet = False
    bots = []

    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            bots.extend(argv[i + 1 :])
            break
        if a in ("-i", "--replaydirectory"):
            i += 1
            replay_dir = argv[i] if i < len(argv) else replay_dir
        elif a in ("-s", "--seed"):
            i += 1
            try:
                seed = int(argv[i])
            except Exception:
                seed = None
        elif a in ("-d", "--dimensions"):
            i += 1
            if i < len(argv):
                parts = argv[i].replace(",", " ").split()
                if len(parts) >= 2:
                    dims = (max(1, int(parts[0])), max(1, int(parts[1])))
        elif a in ("-n", "--nplayers"):
            i += 1
            try:
                nplayers = max(1, min(6, int(argv[i])))
            except Exception:
                nplayers = None
        elif a in ("-r", "--noreplay"):
            noreplay = True
        elif a in ("-t", "--timeout"):
            timeout = True
        elif a in ("-o", "--override"):
            override = True
        elif a in ("-q", "--quiet"):
            quiet = True
        else:
            bots.append(a)
        i += 1
    return replay_dir, seed, dims, nplayers, noreplay, timeout, override, quiet, bots


def adjusted_dimensions(dims, players):
    if dims is None:
        return (25, 25)
    w, h = dims
    if players > 1:
        if players in (2, 4):
            w -= w % 2
            h -= h % 2
        elif players in (3, 6):
            w -= w % 2
            h -= h % 2
    return max(1, w), max(1, h)


def rle(values):
    out = []
    i = 0
    while i < len(values):
        v = values[i]
        j = i + 1
        while j < len(values) and values[j] == v:
            j += 1
        out.extend([j - i, v])
        i = j
    return out


class Game:
    def __init__(self, w, h, slot_count, seed):
        self.w = w
        self.h = h
        self.turn = 0
        self.rng = random.Random(seed)
        self.production = [self.rng.randint(1, 15) for _ in range(w * h)]
        self.owner = [0 for _ in range(w * h)]
        self.strength = [self.rng.randint(40, 200) for _ in range(w * h)]
        self.place_players(slot_count)

    def idx(self, x, y):
        return (y % self.h) * self.w + (x % self.w)

    def place_players(self, n):
        spots = []
        if n == 1:
            spots = [(self.w // 2, self.h // 2)]
        elif n == 2:
            spots = [(self.w // 4, self.h // 2), ((3 * self.w) // 4, self.h // 2)]
        elif n == 3:
            spots = [(self.w // 2, self.h // 5), (self.w // 4, (4 * self.h) // 5), ((3 * self.w) // 4, (4 * self.h) // 5)]
        elif n == 4:
            spots = [(self.w // 4, self.h // 4), ((3 * self.w) // 4, self.h // 4), (self.w // 4, (3 * self.h) // 4), ((3 * self.w) // 4, (3 * self.h) // 4)]
        else:
            spots = [(int((self.w - 1) * (0.5 + 0.42 * math.cos(2 * math.pi * i / n))), int((self.h - 1) * (0.5 + 0.42 * math.sin(2 * math.pi * i / n)))) for i in range(n)]
        used = set()
        for pid, (x, y) in enumerate(spots[:n], 1):
            while (x % self.w, y % self.h) in used:
                x += 1
            used.add((x % self.w, y % self.h))
            k = self.idx(x, y)
            self.owner[k] = pid
            self.strength[k] = 100

    def frame(self):
        return " ".join(map(str, rle(self.owner) + self.strength))

    def production_line(self):
        return " ".join(map(str, self.production))

    def owned(self, pid):
        return any(o == pid for o in self.owner)

    def step(self, moves_by_player):
        self.turn += 1
        destinations = {}
        stationary = set()
        for y in range(self.h):
            for x in range(self.w):
                k = self.idx(x, y)
                pid = self.owner[k]
                if pid == 0:
                    continue
                direction = moves_by_player.get(pid, {}).get((x, y), 0)
                if direction not in DIRS:
                    direction = 0
                dx, dy = DIRS[direction]
                dest = self.idx(x + dx, y + dy)
                destinations.setdefault(dest, []).append((pid, self.strength[k]))
                if direction == 0:
                    stationary.add(k)

        new_owner = self.owner[:]
        new_strength = [0 if self.owner[i] else self.strength[i] for i in range(self.w * self.h)]
        for dest, pieces in destinations.items():
            defenders = []
            if self.owner[dest] != 0 and dest not in [self.idx(x, y) for y in range(self.h) for x in range(self.w) if False]:
                pass
            totals = {}
            for pid, strength in pieces:
                totals[pid] = totals.get(pid, 0) + strength
            if self.owner[dest] != 0 and dest not in stationary:
                pass
            if self.owner[dest] == 0:
                totals[0] = self.strength[dest]
            elif dest not in [self.idx(0, 0) - 1]:
                # A stationary friendly piece is represented by its move; a vacated
                # owned destination has no separate defender.
                if dest not in stationary and all(pid != self.owner[dest] for pid, _ in pieces):
                    totals[self.owner[dest]] = totals.get(self.owner[dest], 0) + self.strength[dest]
            winner, win_strength = max(totals.items(), key=lambda kv: kv[1])
            opposing = sum(v for p, v in totals.items() if p != winner)
            remain = max(0, min(255, win_strength - opposing))
            new_owner[dest] = winner if remain > 0 else 0
            new_strength[dest] = remain

        for i, owner in enumerate(new_owner):
            if owner != 0 and i in stationary:
                new_strength[i] = min(255, new_strength[i] + self.production[i])

        self.owner = new_owner
        self.strength = new_strength


def readline(proc, timeout, infinite=False):
    if infinite:
        return proc.stdout.readline()
    fd = proc.stdout.fileno()
    ready, _, _ = select.select([fd], [], [], timeout)
    if not ready:
        return None
    return proc.stdout.readline()


def start_bot(pid, command):
    return Bot(pid, command, subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1))


def send(proc, text):
    try:
        proc.stdin.write(text + "\n")
        proc.stdin.flush()
        return True
    except Exception:
        return False


def parse_moves(line):
    nums = []
    for part in (line or "").split():
        try:
            nums.append(int(part))
        except ValueError:
            pass
    moves = {}
    for i in range(0, len(nums) - 2, 3):
        moves[(nums[i], nums[i + 1])] = nums[i + 2]
    return moves


def main(argv):
    replay_dir, seed, dims, nplayers, noreplay, ignore_timeouts, override, quiet, commands = parse_args(argv)
    if not commands:
        print("Please provide the launch command string for at least one bot.")
        print("Use the --help flag for usage details.")
        return 0
    if seed is None:
        seed = random.SystemRandom().randint(0, 2**32 - 1)
    slot_count = nplayers or len(commands)
    w, h = adjusted_dimensions(dims, slot_count)

    for c in commands:
        print(c)
    print(f"{w} {h}")

    game = Game(w, h, slot_count, seed)
    bots = [start_bot(i + 1, c) for i, c in enumerate(commands)]
    ranks = []

    for bot in bots:
        for line in (str(bot.pid), f"{w} {h}", game.production_line(), game.frame()):
            send(bot.proc, line)
        if not quiet:
            print(f"Init Message sent to player {bot.pid}.")
        name = readline(bot.proc, 2.0, ignore_timeouts)
        if name is None:
            bot.alive = False
            bot.error = "timeout"
            name = ""
        bot.name = name.strip() or bot.command
        if override:
            bot.name = bot.command
        if not quiet:
            print(f"Init Message received from player {bot.pid}, {bot.name}.")

    max_turns = max(1, int(10 * math.sqrt(w * h)))
    for turn in range(1, max_turns + 1):
        if not quiet:
            print(f"Turn {turn}")
        moves_by_player = {}
        for bot in bots:
            if not bot.alive:
                continue
            if not send(bot.proc, game.frame()):
                bot.alive = False
            line = readline(bot.proc, 1.0, ignore_timeouts) if bot.alive else None
            if line is None:
                bot.alive = False
                bot.error = "timeout or error (Unix) 0"
                ranks.append(bot)
                if not quiet:
                    print(f"Bot #{bot.pid} {bot.error}")
            else:
                moves_by_player[bot.pid] = parse_moves(line)
        game.step(moves_by_player)
        for bot in bots:
            if bot.alive and game.owned(bot.pid):
                bot.last_alive = turn
            elif bot.alive and not game.owned(bot.pid):
                bot.alive = False
                bot.last_alive = turn - 1
                ranks.append(bot)
        if sum(1 for b in bots if b.alive and game.owned(b.pid)) <= 1 and turn > 0:
            for bot in bots:
                if bot.alive:
                    bot.last_alive = turn
            # The original still runs single-player games to the turn limit.
            if len(bots) > 1:
                break

    for bot in bots:
        if bot not in ranks:
            ranks.append(bot)
    ranks.sort(key=lambda b: (b.last_alive, sum(1 for o in game.owner if o == b.pid)), reverse=True)
    for i, bot in enumerate(ranks, 1):
        bot.rank = i

    replay_path = ""
    if not noreplay:
        os.makedirs(replay_dir, exist_ok=True)
        replay_path = os.path.join(replay_dir, f"{int(time.time())}-{seed}.hlt")
        with open(replay_path, "w", encoding="utf-8") as f:
            f.write(f"Halite replay placeholder\n{w} {h}\n{seed}\n")
        if not quiet:
            print(f"Map seed was {seed}")
            print(f"Opening a file at {replay_path}")

    if quiet:
        if replay_path:
            print(f"{replay_path} {seed}")
        for bot in sorted(bots, key=lambda b: b.pid):
            print(f"{bot.rank} {bot.pid} {bot.last_alive}")
        print(" ")
    else:
        if noreplay:
            pass
        else:
            pass
        for bot in sorted(bots, key=lambda b: b.rank):
            print(f"Player #{bot.pid}, {bot.name}, came in rank #{bot.rank} and was last alive on frame #{bot.last_alive}!")

    for bot in bots:
        try:
            bot.proc.kill()
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
