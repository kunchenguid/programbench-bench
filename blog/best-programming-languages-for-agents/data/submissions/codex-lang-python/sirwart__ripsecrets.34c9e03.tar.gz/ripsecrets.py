#!/usr/bin/env python3
import argparse
import fnmatch
import math
import os
import re
import stat
import sys
from pathlib import Path

VERSION = "ripsecrets 0.1.11"
DESCRIPTION = """ripsecrets searches files and directories recursively for secret API keys.
It's primarily designed to be used as a pre-commit to prevent committing
secrets into version control."""

BASE_PATTERN = r'''([A-Za-z]+://\S{3,50}:(\S{8,50})@[\dA-Za-z#%&+./:=?_~-]+|\beyJ[\dA-Za-z=_-]+(?:\.[\dA-Za-z=_-]{3,}){1,4}|(?:gh[oprsu]|github_pat)_[\dA-Za-z_]{36}|glpat-[\dA-Za-z_=-]{20,22}|[rs]k_live_[\dA-Za-z]{24,247}|sq0i[a-z]{2}-[\dA-Za-z_-]{22,43}|sq0c[a-z]{2}-[\dA-Za-z_-]{40,50}|EAAA[\dA-Za-z+=-]{60}|AccountKey=[\d+/=A-Za-z]{88}|AIzaSy[\dA-Za-z_-]{33}|npm_[\dA-Za-z]{36}|//.+/:_authToken=[\dA-Za-z_-]+|xox[aboprs]-(?:\d+-)+[\da-z]+|<master>\{[\dA-Za-z]+\\}</master>|https://hooks\.slack\.com/services/T[\dA-Za-z_]+/B[\dA-Za-z_]+/[\dA-Za-z_]+|SG\.[\dA-Za-z_-]{22}\.[\dA-Za-z_-]{43}|(?:AC|SK)[\da-z]{32}|[\da-f]{32}-us\d{1,2}|s-s4t2(?:af|ud)-[\da-f]{64}|PuTTY-User-Key-File-2|AGE-SECRET-KEY-1[\dA-Z]{58}|-{5}BEGIN DSA PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN EC PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN OPENSSH PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN PGP PRIVATE KEY BLOCK-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN RSA PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN SSH2 ENCRYPTED PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|(?i:key|token|secret|password)\w*["']?]?\s*(?:[:=]|:=|=>|<-|>)\s*[\t "'`]?(\w[\w+./=~\-\\`^]{14,89})(?:[\t\n "'`]|</|$))'''

# The first two groups belong to the whole alternation and URL passwords; the
# password/key/token heuristic captures the candidate in the last group.
GROUP_ENTROPY_THRESHOLD = 3.0
GENERIC_GROUP_THRESHOLD = 3.0


def entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = {}
    for ch in s:
        counts[ch] = counts.get(ch, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def has_long_ordered_run(s: str) -> bool:
    best = 1
    prev_delta = None
    run = 1
    for a, b in zip(s, s[1:]):
        if (a.isalpha() and b.isalpha()) or (a.isdigit() and b.isdigit()):
            delta = ord(b.lower()) - ord(a.lower())
            if delta in (1, -1) and delta == prev_delta:
                run += 1
            elif delta in (1, -1):
                run = 2
                prev_delta = delta
            else:
                run = 1
                prev_delta = None
        else:
            run = 1
            prev_delta = None
        best = max(best, run)
    return best >= 6


def looks_random(candidate: str) -> bool:
    if len(candidate) < 8:
        return False
    lowered = candidate.lower()
    obvious = {"example", "notsecret", "password", "changeme", "dummy", "placeholder"}
    if lowered in obvious:
        return False
    if len(set(candidate)) < 5 and len(candidate) < 24:
        return False
    if has_long_ordered_run(candidate):
        return False
    return entropy(candidate) >= GROUP_ENTROPY_THRESHOLD


def display_help(long: bool = True) -> None:
    if not long:
        print("A command-line tool to prevent committing secret keys into your source code")
    else:
        print(DESCRIPTION)
    print()
    print("Usage: executable [OPTIONS] [Source files]...")
    print()
    print("Arguments:")
    if not long:
        print("  [Source files]...  Source files. Can be files or directories. Defaults to '.'")
    else:
        print("  [Source files]...")
        print("          Source files. Can be files or directories. Defaults to '.'")
    print()
    print("Options:")
    print("      --install-pre-commit")
    print("          Install `ripsecrets` as a pre-commit hook automatically in git directory provided")
    print()
    print("      --strict-ignore")
    print("          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit")
    print()
    print("      --only-matching")
    print("          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line")
    print()
    print("      --additional-pattern <ADDITIONAL_PATTERNS>")
    print("          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret")
    print()
    print("  -h, --help")
    if not long:
        print("          Print help (see more with '--help')")
    else:
        print("          Print help (see a summary with '-h')")
    print()
    print("  -V, --version")
    print("          Print version")


def parse_args(argv):
    sources = []
    additional = []
    strict = False
    only = False
    install = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            sources.extend(argv[i+1:])
            break
        if a in ("-h", "--help"):
            display_help(a == "--help")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a == "--strict-ignore":
            strict = True
        elif a == "--only-matching":
            only = True
        elif a == "--install-pre-commit":
            install = True
        elif a == "--additional-pattern":
            if i + 1 >= len(argv):
                print("error: a value is required for '--additional-pattern <ADDITIONAL_PATTERNS>'", file=sys.stderr)
                raise SystemExit(2)
            i += 1
            additional.append(argv[i])
        elif a.startswith("--additional-pattern="):
            additional.append(a.split("=", 1)[1])
        elif a.startswith("-") and a != "-":
            print(f"error: unexpected argument '{a}' found", file=sys.stderr)
            print("\n  tip: to pass '%s' as a value, use '-- %s'" % (a, a), file=sys.stderr)
            print("\nUsage: executable [OPTIONS] [Source files]...", file=sys.stderr)
            print("\nFor more information, try '--help'.", file=sys.stderr)
            raise SystemExit(2)
        else:
            sources.append(a)
        i += 1
    return sources or ["."], additional, strict, only, install


class IgnoreRules:
    def __init__(self):
        self.paths = []
        self.secrets = set()

    @classmethod
    def load(cls, start: Path):
        rules = cls()
        # ripsecrets uses the ignore file in the current working directory.
        p = Path.cwd() / ".secretsignore"
        if not p.exists():
            return rules
        in_secrets = False
        try:
            for raw in p.read_text(errors="ignore").splitlines():
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if line == "[secrets]":
                    in_secrets = True
                    continue
                if line.startswith("[") and line.endswith("]"):
                    in_secrets = False
                    continue
                if in_secrets:
                    rules.secrets.add(line)
                else:
                    rules.paths.append(line)
        except OSError:
            pass
        return rules

    def ignored_path(self, rel: str, is_dir: bool) -> bool:
        rel = rel.replace(os.sep, "/")
        base = rel.rsplit("/", 1)[-1]
        for pat in self.paths:
            p = pat.strip()
            if not p:
                continue
            neg = p.startswith("!")
            if neg:
                p = p[1:]
            matched = False
            if p.endswith("/"):
                q = p.rstrip("/")
                matched = is_dir and (rel == q or rel.startswith(q + "/") or base == q)
            elif "/" in p:
                matched = fnmatch.fnmatch(rel, p) or rel == p
            else:
                matched = fnmatch.fnmatch(base, p) or fnmatch.fnmatch(rel, p)
            if matched:
                return not neg
        return False


def compile_regex(additional):
    pat = BASE_PATTERN
    if additional:
        pat = pat[:-1] + "|" + "|".join(additional) + ")"
    try:
        return re.compile(pat, re.MULTILINE)
    except re.error as e:
        print("Error: regex parse error:", file=sys.stderr)
        print(f"    {pat}", file=sys.stderr)
        pos = getattr(e, "pos", None)
        if pos is not None:
            print("    " + " " * pos + "^", file=sys.stderr)
        print(f"error: {e.msg}", file=sys.stderr)
        raise SystemExit(2)


def install_pre_commit():
    git = Path(".git")
    if not git.exists():
        print("Error: .git directory not found", file=sys.stderr)
        return 2
    hooks = git / "hooks"
    hooks.mkdir(parents=True, exist_ok=True)
    hook = hooks / "pre-commit"
    hook.write_text("ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n")
    hook.chmod(hook.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return 0


def iter_files(sources, rules: IgnoreRules, strict: bool):
    cwd = Path.cwd()
    for src in sources:
        p = Path(src)
        try:
            if not p.exists():
                print(f"{src}: No such file or directory (os error 2)")
                continue
            rel_arg = os.path.relpath(str(p), str(cwd)) if p.is_absolute() else src
            if strict and rules.ignored_path(rel_arg, p.is_dir()):
                continue
            if p.is_file():
                yield p, src
            elif p.is_dir():
                for root, dirs, files in os.walk(p):
                    kept_dirs = []
                    for d in dirs:
                        if d.startswith("."):
                            continue
                        full = Path(root) / d
                        rel = os.path.relpath(str(full), str(cwd))
                        if rules.ignored_path(rel, True):
                            continue
                        kept_dirs.append(d)
                    dirs[:] = kept_dirs
                    for f in files:
                        if f.startswith("."):
                            continue
                        full = Path(root) / f
                        rel = os.path.relpath(str(full), str(cwd))
                        if rules.ignored_path(rel, False):
                            continue
                        display = str(full)
                        if src == "." and not display.startswith("./"):
                            display = "./" + display
                        yield full, display
        except OSError as e:
            print(f"{src}: {e.strerror} (os error {e.errno})")


def line_number(text, offset):
    return text.count("\n", 0, offset) + 1


def line_text(text, start):
    b = text.rfind("\n", 0, start) + 1
    e = text.find("\n", start)
    if e == -1:
        e = len(text)
    return text[b:e]


def reportable_match(m):
    groups = [g for g in m.groups()[1:] if g]
    if groups:
        # Built-in URL/password groups and user-provided capturing groups are
        # intentionally entropy-tested before reporting.
        for g in groups:
            if looks_random(g):
                return g
        return None
    return m.group(0)


def scan_file(path: Path, display: str, regex, rules: IgnoreRules, only_matching: bool):
    try:
        data = path.read_bytes()
    except OSError as e:
        print(f"{display}: {e.strerror} (os error {e.errno})")
        return False
    if b"\0" in data[:4096]:
        return False
    text = data.decode("utf-8", errors="replace")
    found = False
    for m in regex.finditer(text):
        candidate = reportable_match(m)
        if not candidate or candidate in rules.secrets:
            continue
        found = True
        lineno = line_number(text, m.start())
        out = candidate if only_matching else line_text(text, m.start())
        print(f"{display}:{lineno}:{out}")
    return found


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    sources, additional, strict, only, install = parse_args(argv)
    if install:
        return install_pre_commit()
    regex = compile_regex(additional)
    rules = IgnoreRules.load(Path.cwd())
    any_found = False
    for path, display in iter_files(sources, rules, strict):
        if scan_file(path, display, regex, rules, only):
            any_found = True
    return 1 if any_found else 0


if __name__ == "__main__":
    raise SystemExit(main())
