#!/usr/bin/env python3
import argparse
import math
import os
import sys


class CalcError(Exception):
    def __init__(self, msg, code=1):
        super().__init__(msg)
        self.code = code


class Token:
    def __init__(self, kind, value):
        self.kind = kind
        self.value = value


FUNCTION_ARITY = {
    "sin": 1, "cos": 1, "tan": 1, "csc": 1, "sec": 1, "cot": 1,
    "sinh": 1, "cosh": 1, "tanh": 1,
    "asin": 1, "acos": 1, "atan": 1, "acsc": 1, "asec": 1, "acot": 1,
    "ln": 1, "log2": 1, "log10": 1, "sqrt": 1, "ceil": 1, "floor": 1, "abs": 1,
    "log": 2, "nroot": 2,
}


def tokenize(expr):
    out = []
    i = 0
    while i < len(expr):
        c = expr[i]
        if c.isspace():
            i += 1
            continue
        if c.isdigit() or c == ".":
            j = i
            dots = 0
            while j < len(expr) and (expr[j].isdigit() or expr[j] == "."):
                if expr[j] == ".":
                    dots += 1
                j += 1
            if dots > 1 or expr[i:j] == ".":
                raise CalcError("Parser Error: Too many operators, too few operands")
            out.append(Token("num", float(expr[i:j])))
            i = j
            continue
        if c.isalpha() or c == "_":
            j = i
            while j < len(expr) and (expr[j].isalnum() or expr[j] == "_"):
                j += 1
            out.append(Token("ident", expr[i:j]))
            i = j
            continue
        if c == "*" and i + 1 < len(expr) and expr[i + 1] == "*":
            out.append(Token("op", "**"))
            i += 2
            continue
        if c in "+-*/^(),":
            kind = {"(": "lpar", ")": "rpar", ",": "comma"}.get(c, "op")
            out.append(Token(kind, c))
            i += 1
            continue
        raise CalcError("Parser Error: Too many operators, too few operands")
    return insert_implicit_mult(balance_parens(out))


def balance_parens(tokens):
    bal = 0
    for t in tokens:
        if t.kind == "lpar":
            bal += 1
        elif t.kind == "rpar":
            bal -= 1
    if bal > 0:
        tokens = tokens + [Token("rpar", ")") for _ in range(bal)]
    return tokens


def insert_implicit_mult(tokens):
    res = []
    for idx, t in enumerate(tokens):
        if res:
            a = res[-1]
            left = a.kind in ("num", "rpar") or (a.kind == "ident" and a.value in ("pi", "e", "_"))
            right = t.kind in ("num", "lpar") or t.kind == "ident"
            if left and right:
                # Do not split a function name from its opening parenthesis.
                if not (a.kind == "ident" and a.value in FUNCTION_ARITY and t.kind == "lpar"):
                    res.append(Token("op", "*"))
        res.append(t)
    return res


class Parser:
    def __init__(self, tokens, angle_unit, prev=None):
        self.tokens = tokens
        self.pos = 0
        self.angle_unit = angle_unit
        self.prev = prev

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def pop(self):
        t = self.peek()
        if t is not None:
            self.pos += 1
        return t

    def parse(self):
        if not self.tokens:
            raise CalcError("No previous history.", 0)
        value = self.expr(0)
        if self.peek() is not None:
            raise CalcError("Parser Error: Too many operators, too few operands")
        return value

    def expr(self, min_prec):
        t = self.pop()
        if t is None:
            raise CalcError("Parser Error: Too many operators, too few operands")
        if t.kind == "op" and t.value in "+-":
            left = self.expr(5)
            if t.value == "-":
                left = -left
        elif t.kind == "num":
            left = t.value
        elif t.kind == "ident":
            left = self.ident_value(t.value)
        elif t.kind == "lpar":
            left = self.expr(0)
            if self.peek() and self.peek().kind == "rpar":
                self.pop()
            else:
                raise CalcError("Parser Error: Too many operators, too few operands")
        else:
            raise CalcError("Parser Error: Too many operators, too few operands")

        while True:
            op = self.peek()
            if op is None or op.kind != "op":
                break
            prec, right_assoc = self.prec(op.value)
            if prec < min_prec:
                break
            self.pop()
            rhs = self.expr(prec if right_assoc else prec + 1)
            left = self.apply_op(op.value, left, rhs)
        return left

    def prec(self, op):
        if op in ("^", "**"):
            return 4, True
        if op in ("*", "/"):
            return 3, False
        if op in ("+", "-"):
            return 2, False
        raise CalcError("Parser Error: Too many operators, too few operands")

    def ident_value(self, name):
        if name == "pi":
            return math.pi
        if name == "e":
            return math.e
        if name == "_":
            if self.prev is None:
                raise CalcError("No previous history.", 0)
            return self.prev
        if name not in FUNCTION_ARITY:
            raise CalcError("Parser Error: Too many operators, too few operands")
        if not (self.peek() and self.peek().kind == "lpar"):
            raise CalcError("Parser Error: Too many operators, too few operands")
        self.pop()
        args = []
        if self.peek() and self.peek().kind == "rpar":
            self.pop()
            need = FUNCTION_ARITY[name]
            raise CalcError(f"Parser Error: To few arguments for function, need {need}")
        while True:
            args.append(self.expr(0))
            t = self.peek()
            if t and t.kind == "comma":
                self.pop()
                continue
            if t and t.kind == "rpar":
                self.pop()
                break
            raise CalcError("Parser Error: Too many operators, too few operands")
        if len(args) < FUNCTION_ARITY[name]:
            raise CalcError(f"Parser Error: To few arguments for function, need {FUNCTION_ARITY[name]}")
        if len(args) > FUNCTION_ARITY[name]:
            raise CalcError(f"Parser Error: To many arguments for function, need {FUNCTION_ARITY[name]}")
        return self.apply_func(name, args)

    def angle_in(self, x):
        if self.angle_unit == "radian":
            return x
        return math.radians(x)

    def apply_func(self, name, args):
        x = args[0]
        try:
            if name == "sin": return math.sin(self.angle_in(x))
            if name == "cos": return math.cos(self.angle_in(x))
            if name == "tan": return math.tan(self.angle_in(x))
            if name == "csc": return 1.0 / math.sin(self.angle_in(x))
            if name == "sec": return 1.0 / math.cos(self.angle_in(x))
            if name == "cot": return 1.0 / math.tan(self.angle_in(x))
            if name == "sinh": return math.sinh(x)
            if name == "cosh": return math.cosh(x)
            if name == "tanh": return math.tanh(x)
            if name == "asin": return math.asin(x)
            if name == "acos": return math.acos(x)
            if name == "atan": return math.atan(x)
            if name == "acsc": return math.asin(1.0 / x)
            if name == "asec": return math.acos(1.0 / x)
            if name == "acot": return math.atan(1.0 / x)
            if name == "ln": return math.log(x)
            if name == "log2": return math.log2(x)
            if name == "log10": return math.log10(x)
            if name == "sqrt": return math.sqrt(x)
            if name == "ceil": return float(math.ceil(x))
            if name == "floor": return float(math.floor(x))
            if name == "abs": return abs(x)
            if name == "log":
                return math.log(args[0], args[1])
            if name == "nroot":
                return args[0] ** (1.0 / args[1])
        except ZeroDivisionError:
            raise CalcError("Math Error: Divide by zero error!")
        except ValueError:
            raise CalcError("Domain Error: Out of bounds!")
        raise CalcError("Parser Error: Too many operators, too few operands")

    def apply_op(self, op, a, b):
        try:
            if op == "+": return a + b
            if op == "-": return a - b
            if op == "*": return a * b
            if op == "/":
                if b == 0:
                    raise ZeroDivisionError
                return a / b
            if op in ("^", "**"): return a ** b
        except ZeroDivisionError:
            raise CalcError("Math Error: Divide by zero error!")
        except ValueError:
            raise CalcError("Domain Error: Out of bounds!")
        raise CalcError("Parser Error: Too many operators, too few operands")


def evaluate(expr, angle_unit="degree", prev=None):
    return Parser(tokenize(expr), angle_unit, prev).parse()


def base_digits(value, base, fix):
    if base == 10:
        return f"{value:.{fix}f}"
    sign = "-" if value < 0 else ""
    value = abs(value)
    integer = int(math.floor(value))
    frac = value - integer
    chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if integer == 0:
        int_s = "0"
    else:
        digs = []
        while integer:
            digs.append(chars[integer % base])
            integer //= base
        int_s = "".join(reversed(digs))
    frac_digs = []
    for _ in range(fix):
        frac *= base
        d = int(frac)
        frac_digs.append(chars[d])
        frac -= d
    after = "".join(frac_digs).rstrip("0") or "0"
    before = sign + int_s
    groups = []
    s = before
    while s:
        groups.append(s[-3:].rjust(3))
        s = s[:-3]
    groups = list(reversed(groups))
    if len(groups) < 4:
        groups = [" "] + ["   "] * (3 - len(groups)) + groups
    grouped = ",".join(groups)
    return grouped + "." + after


def make_parser():
    p = argparse.ArgumentParser(
        prog="executable",
        description="Calculator REPL similar to bc(1)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("-f", "--fix", type=int, default=10, metavar="FIX",
                   help="Number of decimal places in output (1 - 64) [default: 10]")
    p.add_argument("-b", "--base", type=int, default=10, metavar="RADIX",
                   help="Radix of calculation output (1 - 36) [default: 10]")
    p.add_argument("-a", "--angle_unit", default="degree", choices=["degree", "radian", "gradian"],
                   help="Angle unit [default: degree] [possible values: degree, radian, gradian]")
    p.add_argument("-V", "--version", action="store_true", help="Print version")
    p.add_argument("input", nargs="?", metavar="INPUT", help="Optional expression string to run eva in command mode")
    return p


def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print("""Calculator REPL similar to bc(1)

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Optional expression string to run eva in command mode

Options:
  -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]
  -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]
  -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]
  -h, --help                     Print help
  -V, --version                  Print version""")
        sys.exit(0)
    ns = make_parser().parse_args(argv)
    if ns.version:
        print("eva 0.3.1")
        sys.exit(0)
    if not 1 <= ns.fix <= 64:
        print(f"error: invalid value '{ns.fix}' for '--fix <FIX>': {ns.fix} is not in 1..=64", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    if not 1 <= ns.base <= 36:
        print(f"error: invalid value '{ns.base}' for '--base <RADIX>': {ns.base} is not in 1..=36", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    return ns


def repl(ns):
    prev = None
    while True:
        try:
            line = input("> ")
        except EOFError:
            break
        if line.strip() in ("quit", "exit"):
            break
        try:
            val = evaluate(line, ns.angle_unit, prev)
            prev = val
            print(base_digits(val, ns.base, ns.fix))
        except CalcError as e:
            print(str(e))


def main(argv=None):
    ns = parse_args(sys.argv[1:] if argv is None else argv)
    if ns.input is None:
        repl(ns)
        return 0
    try:
        value = evaluate(ns.input, ns.angle_unit)
        print(base_digits(value, ns.base, ns.fix))
        return 0
    except CalcError as e:
        print(str(e))
        return e.code


if __name__ == "__main__":
    sys.exit(main())
