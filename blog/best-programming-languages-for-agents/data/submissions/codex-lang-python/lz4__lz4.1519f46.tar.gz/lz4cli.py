#!/usr/bin/env python3
import argparse
import os
import stat
import struct
import sys


VERSION = "*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***"
MAGIC = b"\x04\x22\x4d\x18"
LEGACY_MAGIC = b"\x02\x21\x4c\x18"
SKIPPABLE_MASK = 0xFFFFFFF0
SKIPPABLE_MAGIC = 0x184D2A50


def rotl32(x, r):
    return ((x << r) | (x >> (32 - r))) & 0xFFFFFFFF


def xxh32(data, seed=0):
    p1 = 0x9E3779B1
    p2 = 0x85EBCA77
    p3 = 0xC2B2AE3D
    p4 = 0x27D4EB2F
    p5 = 0x165667B1
    data = memoryview(data)
    n = len(data)
    i = 0
    if n >= 16:
        v1 = (seed + p1 + p2) & 0xFFFFFFFF
        v2 = (seed + p2) & 0xFFFFFFFF
        v3 = seed & 0xFFFFFFFF
        v4 = (seed - p1) & 0xFFFFFFFF
        limit = n - 16
        while i <= limit:
            d1, d2, d3, d4 = struct.unpack_from("<IIII", data, i)
            v1 = (rotl32((v1 + d1 * p2) & 0xFFFFFFFF, 13) * p1) & 0xFFFFFFFF
            v2 = (rotl32((v2 + d2 * p2) & 0xFFFFFFFF, 13) * p1) & 0xFFFFFFFF
            v3 = (rotl32((v3 + d3 * p2) & 0xFFFFFFFF, 13) * p1) & 0xFFFFFFFF
            v4 = (rotl32((v4 + d4 * p2) & 0xFFFFFFFF, 13) * p1) & 0xFFFFFFFF
            i += 16
        h = (rotl32(v1, 1) + rotl32(v2, 7) + rotl32(v3, 12) + rotl32(v4, 18)) & 0xFFFFFFFF
    else:
        h = (seed + p5) & 0xFFFFFFFF
    h = (h + n) & 0xFFFFFFFF
    while i + 4 <= n:
        (k1,) = struct.unpack_from("<I", data, i)
        h = (rotl32((h + k1 * p3) & 0xFFFFFFFF, 17) * p4) & 0xFFFFFFFF
        i += 4
    while i < n:
        h = (rotl32((h + data[i] * p5) & 0xFFFFFFFF, 11) * p1) & 0xFFFFFFFF
        i += 1
    h ^= h >> 15
    h = (h * p2) & 0xFFFFFFFF
    h ^= h >> 13
    h = (h * p3) & 0xFFFFFFFF
    h ^= h >> 16
    return h & 0xFFFFFFFF


class LZ4Error(Exception):
    pass


def read_len(buf, pos, base):
    total = base
    if base == 15:
        while True:
            if pos >= len(buf):
                raise LZ4Error("corrupt input")
            b = buf[pos]
            pos += 1
            total += b
            if b != 255:
                break
    return total, pos


def decompress_block(block, prefix=b""):
    pos = 0
    out = bytearray()
    src = memoryview(block)
    while pos < len(src):
        token = src[pos]
        pos += 1
        lit_len, pos = read_len(src, pos, token >> 4)
        if pos + lit_len > len(src):
            raise LZ4Error("corrupt input")
        out.extend(src[pos:pos + lit_len])
        pos += lit_len
        if pos >= len(src):
            break
        if pos + 2 > len(src):
            raise LZ4Error("corrupt input")
        offset = src[pos] | (src[pos + 1] << 8)
        pos += 2
        if offset == 0:
            raise LZ4Error("corrupt input")
        match_len, pos = read_len(src, pos, token & 0x0F)
        match_len += 4
        for _ in range(match_len):
            idx = len(out) - offset
            if idx >= 0:
                out.append(out[idx])
            else:
                pidx = len(prefix) + idx
                if pidx < 0:
                    raise LZ4Error("corrupt input")
                out.append(prefix[pidx])
    return bytes(out)


def parse_frames(data, verify=True, collect=True):
    pos = 0
    all_out = bytearray()
    infos = []
    while pos < len(data):
        if pos + 4 > len(data):
            raise LZ4Error("Error 44 : Unrecognized header")
        magic = data[pos:pos + 4]
        pos += 4
        m = struct.unpack("<I", magic)[0]
        if (m & SKIPPABLE_MASK) == SKIPPABLE_MAGIC:
            if pos + 4 > len(data):
                raise LZ4Error("corrupt input")
            size = struct.unpack_from("<I", data, pos)[0]
            pos += 4 + size
            continue
        if magic == LEGACY_MAGIC:
            raise LZ4Error("legacy format not supported")
        if magic != MAGIC:
            raise LZ4Error("Error 44 : Unrecognized header")
        if pos + 3 > len(data):
            raise LZ4Error("corrupt input")
        header_start = pos
        flg = data[pos]
        bd = data[pos + 1]
        pos += 2
        if (flg >> 6) != 1:
            raise LZ4Error("unsupported frame version")
        block_independent = bool(flg & 0x20)
        block_checksum = bool(flg & 0x10)
        has_content_size = bool(flg & 0x08)
        content_checksum = bool(flg & 0x04)
        has_dict = bool(flg & 0x01)
        content_size = None
        if has_content_size:
            if pos + 8 > len(data):
                raise LZ4Error("corrupt input")
            content_size = struct.unpack_from("<Q", data, pos)[0]
            pos += 8
        if has_dict:
            pos += 4
        if pos >= len(data):
            raise LZ4Error("corrupt input")
        hc = data[pos]
        header = data[header_start:pos]
        pos += 1
        if verify and ((xxh32(header) >> 8) & 0xFF) != hc:
            raise LZ4Error("header checksum error")
        frame_out = bytearray()
        compressed_total = pos
        last_block = b""
        blocks = 0
        while True:
            if pos + 4 > len(data):
                raise LZ4Error("corrupt input")
            block_size = struct.unpack_from("<I", data, pos)[0]
            pos += 4
            compressed_total += 4
            if block_size == 0:
                break
            raw = bool(block_size & 0x80000000)
            block_size &= 0x7FFFFFFF
            if pos + block_size > len(data):
                raise LZ4Error("corrupt input")
            block = data[pos:pos + block_size]
            pos += block_size
            compressed_total += block_size
            if raw:
                dec = block
            else:
                dec = decompress_block(block, b"" if block_independent else last_block)
            if block_checksum:
                if pos + 4 > len(data):
                    raise LZ4Error("corrupt input")
                if verify and struct.unpack_from("<I", data, pos)[0] != xxh32(block):
                    raise LZ4Error("block checksum error")
                pos += 4
                compressed_total += 4
            frame_out.extend(dec)
            last_block = (last_block + dec)[-65536:]
            blocks += 1
        if content_size is not None and len(frame_out) != content_size:
            raise LZ4Error("content size error")
        if content_checksum:
            if pos + 4 > len(data):
                raise LZ4Error("corrupt input")
            want = struct.unpack_from("<I", data, pos)[0]
            if verify and want != xxh32(frame_out):
                raise LZ4Error("content checksum error")
            pos += 4
            compressed_total += 4
        all_out.extend(frame_out)
        infos.append((compressed_total, len(frame_out), content_size, bd, block_independent, blocks))
    return bytes(all_out) if collect else b"", infos


def make_frame(payload, content_size=False, checksum=True, block_size_id=7):
    max_sizes = {4: 64 << 10, 5: 256 << 10, 6: 1 << 20, 7: 4 << 20}
    max_block = max_sizes.get(block_size_id, 4 << 20)
    flg = 0x40 | 0x20
    if content_size:
        flg |= 0x08
    if checksum:
        flg |= 0x04
    bd = block_size_id << 4
    header = bytearray([flg, bd])
    if content_size:
        header.extend(struct.pack("<Q", len(payload)))
    hc = (xxh32(header) >> 8) & 0xFF
    out = bytearray(MAGIC + bytes(header) + bytes([hc]))
    for i in range(0, len(payload), max_block):
        block = payload[i:i + max_block]
        out.extend(struct.pack("<I", len(block) | 0x80000000))
        out.extend(block)
    out.extend(b"\x00\x00\x00\x00")
    if checksum:
        out.extend(struct.pack("<I", xxh32(payload)))
    return bytes(out)


HELP = """*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***
Usage : 
      executable [arg] [input] [output] 

input   : a filename 
          with no FILE, or when FILE is - or stdin, read standard input
Arguments : 
 -1     : fast compression (default) 
 -12    : slowest compression level 
 -T#    : use # threads for compression (default:0==auto) 
 -d     : decompression (default for .lz4 extension)
 -f     : overwrite output without prompting 
 -k     : preserve source files(s)  (default) 
--rm    : remove source file(s) after successful de/compression 
 -h/-H  : display help/long help and exit 

Advanced arguments :
 -V     : display Version number and exit 
 -v     : verbose mode 
 -q     : suppress warnings; specify twice to suppress errors too
 -c     : force write to standard output, even if it is the console
 -t     : test compressed file integrity
 -m     : multiple input files (implies automatic output filenames)
 -r     : operate recursively on directories (sets also -m) 
 -l     : compress using Legacy format (Linux kernel compression)
 -z     : force compression 
 -D FILE: use FILE as dictionary (compression & decompression)
 -B#    : cut file into blocks of size # bytes [32+] 
                     or predefined block size [4-7] (default: 7) 
 -BI    : Block Independence (default) 
 -BD    : Block dependency (improves compression ratio) 
 -BX    : enable block checksum (default:disabled) 
--no-frame-crc : disable stream checksum (default:enabled) 
--content-size : compressed frame includes original size (default:not present)
--list FILE : lists information about .lz4 files (useful for files compressed with --content-size flag)
--[no-]sparse  : sparse mode (default:enabled on file, disabled on stdout)
--favor-decSpeed: compressed files decompress faster, but are less compressed 
--fast[=#]: switch to ultra fast compression level (default: 1)
--best  : same as -12
Benchmark arguments : 
 -b#    : benchmark file(s), using # compression level (default : 1) 
 -e#    : test all compression levels from -bX to # (default : 1)
 -i#    : minimum evaluation time in seconds (default : 3s) 
"""


def expand_args(argv):
    out = []
    for a in argv:
        if a.startswith("--") or not a.startswith("-") or a == "-":
            out.append(a)
            continue
        if len(a) > 2 and a[1] not in "BDeiTb":
            for ch in a[1:]:
                out.append("-" + ch)
        else:
            out.append(a)
    return out


def parse_args(argv):
    opts = {
        "mode": None, "force": False, "stdout": False, "test": False,
        "rm": False, "quiet": 0, "multiple": False, "recursive": False,
        "content_size": False, "frame_crc": True, "list": False,
        "block_size_id": 7,
    }
    files = []
    argv = expand_args(argv)
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "-H", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a in ("-z", "--compress"):
            opts["mode"] = "compress"
        elif a in ("-d", "--decompress", "--uncompress"):
            opts["mode"] = "decompress"
        elif a == "-t":
            opts["test"] = True
            opts["mode"] = "decompress"
        elif a == "-f" or a == "--force":
            opts["force"] = True
        elif a == "-c":
            opts["stdout"] = True
        elif a == "--rm":
            opts["rm"] = True
        elif a in ("-k", "--keep"):
            opts["rm"] = False
        elif a in ("-m", "--multiple"):
            opts["multiple"] = True
        elif a in ("-r", "--recursive"):
            opts["recursive"] = True
            opts["multiple"] = True
        elif a in ("-q", "--quiet"):
            opts["quiet"] += 1
        elif a == "-v":
            pass
        elif a == "--content-size":
            opts["content_size"] = True
        elif a == "--no-frame-crc":
            opts["frame_crc"] = False
        elif a == "--list":
            opts["list"] = True
            i += 1
            if i < len(argv):
                files.append(argv[i])
        elif a.startswith("-B"):
            val = a[2:]
            if val in ("4", "5", "6", "7"):
                opts["block_size_id"] = int(val)
        elif a.startswith("-") and len(a) >= 2 and a[1:].isdigit():
            pass
        elif a.startswith("--fast") or a == "--best" or a in ("-BI", "-BD", "-BX", "-l", "--no-sparse", "--sparse", "--favor-decSpeed"):
            pass
        elif a == "-D":
            i += 1
        elif a.startswith("-D"):
            pass
        elif a.startswith("-T") or a.startswith("-b") or a.startswith("-e") or a.startswith("-i"):
            pass
        else:
            files.append(a)
        i += 1
    return opts, files


def default_output_name(path, mode):
    if mode == "compress":
        return path + ".lz4"
    if path.endswith(".lz4"):
        return path[:-4]
    raise LZ4Error(f"{path}: unknown suffix -- ignored")


def read_input(path):
    if path in (None, "-"):
        return sys.stdin.buffer.read()
    with open(path, "rb") as f:
        return f.read()


def write_output(path, data, force=False):
    if path in (None, "-", "stdout"):
        sys.stdout.buffer.write(data)
        return
    if path == "null":
        return
    if os.path.exists(path) and not force:
        raise LZ4Error(f"{path} already exists; not overwritten  ")
    with open(path, "wb") as f:
        f.write(data)


def gather(paths, recursive):
    result = []
    for p in paths:
        if recursive and os.path.isdir(p):
            for root, _, names in os.walk(p):
                for n in names:
                    result.append(os.path.join(root, n))
        else:
            result.append(p)
    return result


def list_files(files):
    print("    Frames           Type Block  Compressed  Uncompressed    Ratio   Filename")
    rc = 0
    for fn in files:
        try:
            data = read_input(fn)
            _, infos = parse_frames(data, verify=False, collect=False)
            known = all(i[2] is not None for i in infos)
            uncomp = sum(i[2] for i in infos) if known else 0
            ratio = "-" if not known or uncomp == 0 else f"{(len(data) / uncomp * 100):5.2f}%"
            uncomp_s = str(uncomp) if known else "-"
            block = "B4I"
            if infos:
                bid = (infos[0][3] >> 4) & 7
                block = f"B{bid}{'I' if infos[0][4] else 'D'}"
            print(f"{len(infos):10d}       LZ4Frame {block:>4} {len(data):11.2f} {uncomp_s:>13} {ratio:>8}   {fn}")
        except Exception as e:
            print(f"{fn}: {e}", file=sys.stderr)
            rc = 1
    return rc


def process_one(infile, outfile, opts):
    mode = opts["mode"]
    if mode is None:
        mode = "decompress" if infile and infile.endswith(".lz4") else "compress"
    data = read_input(infile)
    if mode == "compress":
        out = make_frame(data, opts["content_size"], opts["frame_crc"], opts["block_size_id"])
    else:
        out, _ = parse_frames(data, verify=True, collect=not opts["test"])
    if opts["test"]:
        return
    write_output(outfile, out, opts["force"])
    if opts["rm"] and infile not in (None, "-"):
        os.unlink(infile)


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    opts, files = parse_args(argv)
    if opts["list"]:
        return list_files(files)
    try:
        if not files:
            process_one(None, "-" if opts["stdout"] or not sys.stdout.isatty() else None, opts)
            return 0
        if opts["multiple"] or len(files) > 2:
            rc = 0
            for infile in gather(files, opts["recursive"]):
                try:
                    mode = opts["mode"] or ("decompress" if infile.endswith(".lz4") else "compress")
                    outfile = None if opts["stdout"] else default_output_name(infile, mode)
                    process_one(infile, "-" if opts["stdout"] else outfile, opts)
                except Exception as e:
                    if opts["quiet"] < 2:
                        print(e, file=sys.stderr)
                    rc = 1
            return rc
        infile = files[0]
        mode = opts["mode"] or ("decompress" if infile.endswith(".lz4") else "compress")
        if len(files) >= 2:
            outfile = files[1]
        elif opts["stdout"]:
            outfile = "-"
        else:
            outfile = default_output_name(infile, mode)
        process_one(infile, outfile, opts)
        return 0
    except BrokenPipeError:
        return 0
    except Exception as e:
        if opts.get("quiet", 0) < 2:
            print(e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
