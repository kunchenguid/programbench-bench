#!/usr/bin/env python3
import base64
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

VERSION = "2.37.1"

HELP = f"""direnv v{VERSION}
Usage: direnv COMMAND [...ARGS]

Available commands
------------------
allow [PATH_TO_RC]:
  aliases: permit, grant
  Grants direnv permission to load the given .envrc or .env file.
block [PATH_TO_RC]:
  aliases: deny, disallow, revoke
  Revokes the authorization of a given .envrc or .env file.
edit [PATH_TO_RC]:
  Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow
  the file to be loaded afterwards.
exec DIR COMMAND [...ARGS]:
  Executes a command after loading the first .envrc or .env found in DIR
export SHELL:
  Loads an .envrc or .env and prints the diff in terms of exports.
  Supported SHELL values are: [murex, vim, pwsh, bash, fish, gha, gzenv, json, systemd, elvish, tcsh, zsh]
fetchurl <url> [<integrity-hash>]:
  Fetches a given URL into direnv's CAS
help [SHOW_PRIVATE]:
  Shows this help
hook SHELL:
  Used to setup the shell hook
prune:
  Removes old allowed and required files
reload:
  Triggers an env reload
status [--json]:
  Prints some debug status information
stdlib:
  Displays the stdlib available in the .envrc execution context
version [VERSION_AT_LEAST]:
  prints the version or checks that direnv is older than VERSION_AT_LEAST.
log [--status | --error] <message>:
  Logs a given message
"""


def eprint(msg, error=True):
    prefix = "direnv: error " if error else "direnv: "
    print(prefix + msg, file=sys.stderr)


def home():
    return Path(os.environ.get("HOME") or str(Path.home()))


def config_dir():
    if os.environ.get("DIRENV_CONFIG"):
        return Path(os.environ["DIRENV_CONFIG"])
    return Path(os.environ.get("XDG_CONFIG_HOME", home() / ".config")) / "direnv"


def data_dir():
    return Path(os.environ.get("XDG_DATA_HOME", home() / ".local/share")) / "direnv"


def cache_dir():
    return Path(os.environ.get("XDG_CACHE_HOME", home() / ".cache")) / "direnv"


def self_path():
    return os.path.abspath(sys.argv[0])


def parse_config():
    cfg = {"load_dotenv": False, "hide_env_diff": False, "bash_path": "/usr/bin/bash"}
    p = config_dir() / "direnv.toml"
    if not p.exists():
        return cfg
    section = None
    try:
        for raw in p.read_text().splitlines():
            line = raw.split("#", 1)[0].strip()
            if not line:
                continue
            if line.startswith("[") and line.endswith("]"):
                section = line[1:-1].strip()
                continue
            if section == "global" and "=" in line:
                k, v = [x.strip() for x in line.split("=", 1)]
                if v.lower() in ("true", "false"):
                    cfg[k] = v.lower() == "true"
                elif v.startswith('"') and v.endswith('"'):
                    cfg[k] = v[1:-1]
    except OSError:
        pass
    return cfg


def resolve_rc(arg=None, start=None):
    if arg:
        p = Path(arg)
        if p.is_dir():
            for name in (".envrc", ".env"):
                q = p / name
                if q.exists():
                    return q.resolve()
            return (p / ".envrc").resolve()
        return p.resolve()
    start = Path(start or os.getcwd()).resolve()
    cfg = parse_config()
    for d in [start] + list(start.parents):
        envrc = d / ".envrc"
        if envrc.exists():
            return envrc
        env = d / ".env"
        if cfg.get("load_dotenv") and env.exists():
            return env
    return None


def allow_key(path):
    path = Path(path).resolve()
    try:
        content = path.read_bytes()
    except OSError:
        content = b""
    return hashlib.sha256(str(path).encode() + b"\0" + content).hexdigest()


def allow_dir():
    return data_dir() / "allow"


def is_allowed(path):
    p = Path(path).resolve()
    f = allow_dir() / allow_key(p)
    if not f.exists():
        return False
    try:
        return f.read_text().strip() == str(p)
    except OSError:
        return False


def set_allowed(path, allowed=True):
    p = Path(path).resolve()
    if not p.exists():
        eprint(f"lstat {p}: no such file or directory")
        return 1
    f = allow_dir() / allow_key(p)
    if allowed:
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(str(p) + "\n")
    else:
        if f.exists():
            f.unlink()
    return 0


def shell_quote_bash(v):
    return "$" + shlex.quote(v).replace("'", "'\\''") if "\n" in v else shlex.quote(v)


def shell_export(name, value, shell):
    if shell in ("bash", "zsh"):
        return f"export {name}={shlex.quote(value)};"
    if shell == "fish":
        return f"set -gx {name} {shlex.quote(value)};"
    if shell == "tcsh":
        return f"setenv {name} {shlex.quote(value)};"
    if shell == "pwsh":
        return f"$env:{name} = {json.dumps(value)}"
    if shell == "vim":
        return f"let ${name} = {json.dumps(value)}"
    if shell == "systemd":
        return f"{name}={value}"
    return f"export {name}={shlex.quote(value)};"


def shell_unset(name, shell):
    if shell in ("bash", "zsh"):
        return f"unset {name};"
    if shell == "fish":
        return f"set -e {name};"
    if shell == "tcsh":
        return f"unsetenv {name};"
    if shell == "pwsh":
        return f"Remove-Item Env:{name} -ErrorAction SilentlyContinue"
    return f"unset {name};"


def stdlib():
    return f'''#!/usr/bin/env bash
shopt -s nullglob
shopt -s extglob
direnv="{self_path()}"
direnv_config_dir="${{DIRENV_CONFIG:-${{XDG_CONFIG_HOME:-$HOME/.config}}/direnv}}"
export DIRENV_IN_ENVRC=1

log_status() {{ "$direnv" log --status "$*"; }}
log_error() {{ "$direnv" log --error "$*"; }}
has() {{ type "$1" >/dev/null 2>&1; }}
expand_path() {{
  local p="$1" base="${{2:-$PWD}}"
  [[ "$p" = /* ]] && printf '%s\\n' "$p" || (cd "$base" 2>/dev/null && cd "$(dirname "$p")" 2>/dev/null && printf '%s/%s\\n' "$PWD" "$(basename "$p")")
}}
user_rel_path() {{ case "$1" in "$HOME"/*) printf '~/%s\\n' "${{1#"$HOME"/}}" ;; "$HOME") echo '~' ;; *) echo "$1" ;; esac; }}
find_up() {{
  local f="$1" d="$PWD"
  while true; do [[ -e "$d/$f" ]] && {{ echo "$d/$f"; return 0; }}; [[ "$d" = / ]] && return 1; d="$(dirname "$d")"; done
}}
source_env() {{ local p="$1"; [[ -d "$p" ]] && p="$p/.envrc"; source "$p"; }}
source_env_if_exists() {{ [[ -f "$1" ]] && source "$1" || true; }}
source_up() {{ local p; p="$(find_up "${{1:-.envrc}}")" || return 1; source "$p"; }}
source_up_if_exists() {{ local p; p="$(find_up "${{1:-.envrc}}")" || return 0; source "$p"; }}
direnv_apply_dump() {{ source "$1"; }}
direnv_load() {{ eval "$("$@")"; }}
fetchurl() {{ "$direnv" fetchurl "$@"; }}
source_url() {{ source "$("$direnv" fetchurl "$1" "$2")"; }}
path_add() {{ local var="$1" p; p="$(expand_path "$2")"; eval "export $var=\\"$p${{!var:+:${{!var}}}}\\""; }}
PATH_add() {{ path_add PATH "$1"; }}
MANPATH_add() {{ path_add MANPATH "$1"; }}
PATH_rm() {{
  local out="" part pat keep
  IFS=: read -ra parts <<< "$PATH"
  for part in "${{parts[@]}}"; do keep=1; for pat in "$@"; do [[ "$part" == $pat ]] && keep=0; done; [[ $keep = 1 ]] && out="${{out:+$out:}}$part"; done
  export PATH="$out"
}}
dotenv() {{
  local f="${{1:-.env}}"; [[ -f "$f" ]] || return 1
  set -a; source "$f"; set +a
}}
dotenv_if_exists() {{ [[ -f "${{1:-.env}}" ]] && dotenv "$1" || true; }}
direnv_layout_dir() {{ echo "${{direnv_layout_dir:-$PWD/.direnv}}"; }}
layout() {{
  case "$1" in
    go) export GOPATH="$(direnv_layout_dir)/go"; PATH_add bin ;;
    node) PATH_add node_modules/.bin ;;
    php) PATH_add vendor/bin ;;
    python|python3) local py="${{2:-python3}}"; export VIRTUAL_ENV="$(direnv_layout_dir)/python"; PATH_add "$VIRTUAL_ENV/bin" ;;
    ruby) export GEM_HOME="$(direnv_layout_dir)/ruby"; PATH_add "$GEM_HOME/bin" ;;
  esac
}}
use() {{ local f="use_$1"; shift; "$f" "$@"; }}
watch_file() {{ :; }}
watch_dir() {{ :; }}
strict_env() {{ if (($#)); then (set -euo pipefail; "$@"); else set -euo pipefail; fi; }}
unstrict_env() {{ if (($#)); then (set +e +u +o pipefail; "$@"); else set +e +u +o pipefail; fi; }}
direnv_version() {{ "$direnv" version "$1"; }}
on_git_branch() {{ git rev-parse --abbrev-ref HEAD >/dev/null 2>&1 || return 1; local b; b="$(git rev-parse --abbrev-ref HEAD)"; [[ $# = 0 || "$b" = "$1" ]]; }}
'''


def dump_script(rc):
    if rc.name == ".env":
        body = f"set -a\nsource {shlex.quote(str(rc))}\nset +a\n"
    else:
        body = f"source {shlex.quote(str(rc))}\n"
    return stdlib() + "\n" + body + "python3 - <<'PY'\nimport os, json\nprint(json.dumps(dict(os.environ), sort_keys=True))\nPY\n"


def evaluate_rc(rc):
    bash = parse_config().get("bash_path") or shutil.which("bash") or "/bin/bash"
    env = dict(os.environ)
    env["DIRENV_FILE"] = str(rc)
    env["DIRENV_DIR"] = "-" + str(rc.parent)
    with tempfile.NamedTemporaryFile("w", delete=False, suffix=".sh") as f:
        f.write(dump_script(rc))
        name = f.name
    try:
        proc = subprocess.run([bash, name], cwd=str(rc.parent), env=env, text=True, capture_output=True)
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass
    if proc.stderr:
        sys.stderr.write(proc.stderr)
    if proc.returncode != 0:
        return None, proc.returncode
    try:
        out = proc.stdout.strip().splitlines()[-1]
        newenv = json.loads(out)
    except Exception:
        return None, 1
    newenv.pop("DIRENV_IN_ENVRC", None)
    return newenv, 0


def make_diff(old, new):
    ignore = {"_", "SHLVL", "PWD", "OLDPWD"}
    changes = {}
    removed = {}
    for k, v in new.items():
        if k in ignore or k.startswith("BASH_FUNC_"):
            continue
        if old.get(k) != v:
            changes[k] = v
            removed[k] = old.get(k)
    unsets = []
    for k in old:
        if k in ignore or k.startswith("DIRENV_") or k.startswith("BASH_FUNC_"):
            continue
        if k not in new:
            unsets.append(k)
            removed[k] = old.get(k)
    payload = {"changes": changes, "unsets": unsets, "old": removed}
    encoded = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode()
    changes["DIRENV_DIFF"] = encoded
    return changes, unsets, payload


def parse_own_diff():
    val = os.environ.get("DIRENV_DIFF")
    if not val:
        return None
    try:
        return json.loads(base64.urlsafe_b64decode(val.encode()).decode())
    except Exception:
        return None


def export_cmd(args):
    if not args:
        eprint("unknown target shell ''")
        return 1
    shell = args[0]
    supported = {"bash", "zsh", "fish", "tcsh", "elvish", "pwsh", "murex", "json", "vim", "gha", "gzenv", "systemd"}
    if shell not in supported:
        eprint(f"unknown target shell '{shell}'")
        return 1
    rc = resolve_rc()
    if not rc:
        diff = parse_own_diff()
        if diff:
            changes = {}
            unsets = ["DIRENV_DIFF", "DIRENV_FILE", "DIRENV_DIR", "DIRENV_WATCHES"]
            for k, old in diff.get("old", {}).items():
                if old is None:
                    unsets.append(k)
                else:
                    changes[k] = old
            output_env(shell, changes, unsets)
        return 0
    if not is_allowed(rc):
        if shell == "json":
            print("{}")
        else:
            print(shell_export("DIRENV_FILE", str(rc), shell) + shell_export("DIRENV_DIR", "-" + str(rc.parent), shell))
        eprint(f"{rc} is blocked. Run `direnv allow` to approve its content")
        return 1
    newenv, code = evaluate_rc(rc)
    if code:
        return code
    newenv["DIRENV_FILE"] = str(rc)
    newenv["DIRENV_DIR"] = "-" + str(rc.parent)
    changes, unsets, _ = make_diff(os.environ, newenv)
    output_env(shell, changes, unsets)
    if not parse_config().get("hide_env_diff"):
        names = [("+" + k) for k in changes if not k.startswith("DIRENV_")]
        names += [("-" + k) for k in unsets]
        changed = [("~" + k) for k in changes if k in os.environ and not k.startswith("DIRENV_")]
        shown = " ".join(sorted(set(names + changed)))
        eprint(f"loading {rc}", error=False)
        if shown:
            eprint(f"export {shown}", error=False)
    return 0


def output_env(shell, changes, unsets):
    if shell == "json":
        print(json.dumps(changes, indent=2, sort_keys=True))
        return
    if shell == "gha":
        for k, v in changes.items():
            print(f"{k}={v}")
        return
    parts = [shell_unset(k, shell) for k in unsets]
    parts += [shell_export(k, v, shell) for k, v in changes.items()]
    print("".join(parts))


def hook(shell):
    exe = self_path()
    if shell == "bash":
        print(f'''
_direnv_hook() {{
  local previous_exit_status=$?;
  vars="$("{exe}" export bash)";
  trap -- '' SIGINT;
  eval "$vars";
  trap - SIGINT;
  return $previous_exit_status;
}};
if [[ ";${{PROMPT_COMMAND[*]:-}};" != *";_direnv_hook;"* ]]; then
  if [[ "$(declare -p PROMPT_COMMAND 2>&1)" == "declare -a"* ]]; then
    PROMPT_COMMAND=(_direnv_hook "${{PROMPT_COMMAND[@]}}")
  else
    PROMPT_COMMAND="_direnv_hook${{PROMPT_COMMAND:+;$PROMPT_COMMAND}}"
  fi
fi''')
    elif shell == "zsh":
        print(f'''
_direnv_hook() {{
  vars="$("{exe}" export zsh)"
  trap -- '' SIGINT
  eval "$vars"
  trap - SIGINT
}}
typeset -ag precmd_functions
if (( ! ${{precmd_functions[(I)_direnv_hook]}} )); then
  precmd_functions=(_direnv_hook $precmd_functions)
fi
typeset -ag chpwd_functions
if (( ! ${{chpwd_functions[(I)_direnv_hook]}} )); then
  chpwd_functions=(_direnv_hook $chpwd_functions)
fi''')
    elif shell == "fish":
        print(f'''
    function __direnv_export_eval --on-event fish_prompt;
        "{exe}" export fish | source;
    end;''')
    elif shell == "tcsh":
        print(f"alias precmd 'eval `{exe} export tcsh`'")
    elif shell == "pwsh":
        print(f'Invoke-Expression "$(&"{exe}" export pwsh)"')
    else:
        eprint(f"unknown target shell '{shell}'")
        return 1
    return 0


def version(args):
    if not args:
        print(VERSION)
        return 0
    want = [int(x) for x in args[0].lstrip("v").split(".") if x.isdigit()]
    have = [int(x) for x in VERSION.split(".")]
    if have < want:
        eprint(f"current version v{VERSION} is older than the desired version v{args[0]}")
        return 1
    return 0


def status(args):
    rc = resolve_rc()
    if args and args[0] == "--json":
        print(json.dumps({"config": {"ConfigDir": str(config_dir()), "SelfPath": self_path()}, "state": {"foundRC": str(rc) if rc else None, "loadedRC": os.environ.get("DIRENV_FILE")}}, indent=2))
        return 0
    print(f"direnv exec path {self_path()}")
    print(f"DIRENV_CONFIG {config_dir()}")
    print(f"bash_path {parse_config().get('bash_path')}")
    print("disable_stdin false")
    print("warn_timeout 5s")
    print("whitelist.prefix []")
    print("whitelist.exact map[]")
    if os.environ.get("DIRENV_FILE"):
        print(f"Loaded RC path {os.environ.get('DIRENV_FILE')}")
    else:
        print("No .envrc or .env loaded")
    print(f"Found RC path {rc}" if rc else "No .envrc or .env found")
    return 0


def exec_cmd(args):
    if len(args) < 2:
        eprint("not enough arguments")
        return 1
    d = Path(args[0]).resolve()
    rc = resolve_rc(start=d)
    env = dict(os.environ)
    if rc:
        if not is_allowed(rc):
            eprint(f"{rc} is blocked. Run `direnv allow` to approve its content")
            return 1
        newenv, code = evaluate_rc(rc)
        if code:
            return code
        env.update(newenv)
    p = subprocess.run(args[1:], cwd=str(d), env=env)
    return p.returncode


def fetchurl(args):
    eprint("fetchurl requires network access, which is not available in this build")
    return 1


def main():
    args = sys.argv[1:]
    if not args or args[0] in ("help", "--help", "-h"):
        print(HELP)
        return 0
    cmd, rest = args[0], args[1:]
    aliases_allow = {"allow", "permit", "grant"}
    aliases_block = {"block", "deny", "disallow", "revoke"}
    if cmd in aliases_allow:
        return set_allowed(resolve_rc(rest[0] if rest else None) or Path(".envrc").resolve(), True)
    if cmd in aliases_block:
        return set_allowed(resolve_rc(rest[0] if rest else None) or Path(".envrc").resolve(), False)
    if cmd == "export":
        return export_cmd(rest)
    if cmd == "dotenv":
        path = rest[-1] if rest else ".env"
        env = {}
        try:
            for raw in Path(path).read_text().splitlines():
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                if line.startswith("export "):
                    line = line[7:].strip()
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip().strip('"').strip("'")
        except OSError as exc:
            eprint(str(exc))
            return 1
        for k, v in env.items():
            print(shell_export(k, v, "bash"))
        return 0
    if cmd == "dump":
        shell = rest[0] if rest else "bash"
        output_env(shell, dict(os.environ), [])
        return 0
    if cmd == "exec":
        return exec_cmd(rest)
    if cmd == "hook":
        return hook(rest[0] if rest else "")
    if cmd == "stdlib":
        print(stdlib(), end="")
        return 0
    if cmd == "version":
        return version(rest)
    if cmd == "status":
        return status(rest)
    if cmd == "reload":
        rc = resolve_rc()
        if not rc:
            eprint(".envrc not found")
            return 1
        print(shell_export("DIRENV_WATCHES", "reload", "bash"))
        return 0
    if cmd == "prune":
        if allow_dir().exists():
            for f in allow_dir().iterdir():
                try:
                    if not Path(f.read_text().strip()).exists():
                        f.unlink()
                except OSError:
                    pass
        return 0
    if cmd == "log":
        if rest and rest[0] in ("--status", "-status"):
            eprint(" ".join(rest[1:]), error=False)
            return 0
        if rest and rest[0] in ("--error", "-error"):
            eprint(" ".join(rest[1:]), error=True)
            return 0
        eprint("invalid arguments")
        return 1
    if cmd == "fetchurl":
        return fetchurl(rest)
    if cmd == "edit":
        rc = resolve_rc(rest[0] if rest else None) or (Path.cwd() / ".envrc")
        editor = os.environ.get("EDITOR", "vi")
        code = subprocess.call([editor, str(rc)])
        if code == 0:
            return set_allowed(rc, True)
        return code
    eprint(f'command "{sys.argv[0]} {cmd}" not found')
    return 1


if __name__ == "__main__":
    sys.exit(main())
