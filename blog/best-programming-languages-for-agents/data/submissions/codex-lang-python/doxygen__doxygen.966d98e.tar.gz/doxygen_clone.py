#!/usr/bin/env python3
import html
import os
import re
import shutil
import sys
from pathlib import Path

VERSION = "1.17.0 (9135bd68ddc9ea65023d967c75048a7a86a5d495)"
COPYRIGHT = "Copyright Dimitri van Heesch 1997-2025"
ROOT = Path(__file__).resolve().parent
RES = ROOT / "resources"


def exe_name() -> str:
    return sys.argv[0] or "doxygen"


def read_res(name: str) -> str:
    return (RES / name).read_text(encoding="utf-8")


def write_target(path: str, data: str) -> None:
    if path == "-":
        sys.stdout.write(data)
    else:
        Path(path).write_text(data, encoding="utf-8")


def usage() -> str:
    e = exe_name()
    return f"""Doxygen version {VERSION}
{COPYRIGHT}

You can use Doxygen in a number of ways:

1) Use Doxygen to generate a template configuration file*:
    {e} [-s] -g [configName]

2) Use Doxygen to update an old configuration file*:
    {e} [-s] -u [configName]

3) Use Doxygen to generate documentation using an existing configuration file*:
    {e} [configName]

4) Use Doxygen to generate a template file controlling the layout of the
   generated documentation:
    {e} -l [layoutFileName]

    In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.
    If - is used for layoutFileName Doxygen will write to standard output.

5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.
    RTF:        {e} -w rtf styleSheetFile
    HTML:       {e} -w html headerFile footerFile styleSheetFile [configFile]
    LaTeX:      {e} -w latex headerFile footerFile styleSheetFile [configFile]

6) Use Doxygen to generate a rtf extensions file
    {e} -e rtf extensionsFile

    If - is used for extensionsFile Doxygen will write to standard output.

7) Use Doxygen to compare the used configuration file with the template configuration file
    {e} -x [configFile]

   Use Doxygen to compare the used configuration file with the template configuration file
   without replacing the environment variables or CMake type replacement variables
    {e} -x_noenv [configFile]

8) Use Doxygen to show a list of built-in emojis.
    {e} -f emoji outputFileName

    If - is used for outputFileName Doxygen will write to standard output.

*) If -s is specified the comments of the configuration items in the config file will be omitted.
   If configName is omitted 'Doxyfile' will be used as a default.
   If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.

If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.

-v print version string, -V print extended version information
-h,-? prints usage help information
{e} -d prints additional usage flags for debugging purposes
"""


def debug_usage() -> str:
    return """Developer parameters:
  -m          dump symbol map
  -b          making messages output unbuffered
  -c <file>   process input file as a comment block and produce HTML output
  -d <level>  enable a debug level, such as (multiple invocations of -d are possible):
\talias
\tcite
\tcommentcnv
\tcommentscan
\tentries
\textcmd
\tfilteroutput
\tformula
\tfortranfixed2free
\tlayout
\tlex
\tlex:code
\tlex:commentcnv
\tlex:commentscan
\tlex:configimpl
\tlex:constexp
\tlex:declinfo
\tlex:defargs
\tlex:doctokenizer
\tlex:fortrancode
\tlex:fortranscanner
\tlex:lexcode
\tlex:lexscanner
\tlex:pre
\tlex:pycode
\tlex:pyscanner
\tlex:scanner
\tlex:sqlcode
\tlex:vhdlcode
\tlex:xml
\tlex:xmlcode
\tmarkdown
\tnolineno
\tplantuml
\tpreprocessor
\tprinttree
\tqhp
\trtf
\tsections
\tstderr
\ttag
\ttime
"""


def parse_config_text(text: str) -> dict:
    cfg = {}
    current = None
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        cont = line.endswith("\\")
        if cont:
            line = line[:-1].rstrip()
        m = re.match(r"^([A-Za-z0-9_]+)\s*(\+?=)\s*(.*)$", line)
        if m:
            key, op, val = m.groups()
            val = val.strip()
            if op == "+=" and key in cfg:
                cfg[key] = (cfg[key] + " " + val).strip()
            else:
                cfg[key] = val
            current = key if cont else None
        elif current:
            cfg[current] = (cfg[current] + " " + line).strip()
            if not cont:
                current = None
    return cfg


def parse_config(path: str) -> dict:
    if path == "-":
        return parse_config_text(sys.stdin.read())
    p = Path(path)
    if not p.exists():
        sys.stderr.write(f"error: configuration file {path} not found!\n")
        sys.stdout.write(usage())
        raise SystemExit(1)
    return parse_config_text(p.read_text(encoding="utf-8", errors="replace"))


def truthy(v: str, default: bool = False) -> bool:
    if v is None or v == "":
        return default
    return v.strip().strip('"').upper() in {"YES", "TRUE", "1", "ON"}


def stripq(v: str) -> str:
    v = (v or "").strip()
    if len(v) >= 2 and v[0] == v[-1] == '"':
        return v[1:-1]
    return v


def split_words(v: str) -> list[str]:
    return re.findall(r'"([^"]+)"|(\S+)', v or "")


def config_words(v: str) -> list[str]:
    out = []
    for a, b in split_words(v):
        out.append(a or b)
    return out


def find_inputs(cfg: dict) -> list[Path]:
    vals = config_words(cfg.get("INPUT", ""))
    if not vals:
        vals = ["."]
    patterns = config_words(cfg.get("FILE_PATTERNS", "")) or ["*.c", "*.cc", "*.cpp", "*.h", "*.hpp", "*.py", "*.md"]
    recursive = truthy(cfg.get("RECURSIVE", "NO"))
    files = []
    for val in vals:
        p = Path(val)
        if p.is_file():
            files.append(p)
        elif p.is_dir():
            for pat in patterns:
                files.extend(p.rglob(pat) if recursive else p.glob(pat))
    seen = []
    for f in files:
        if f.exists() and f not in seen:
            seen.append(f)
    return seen


def extract_symbols(files: list[Path]) -> tuple[list[str], list[str]]:
    classes, funcs = [], []
    for f in files:
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for m in re.finditer(r"\b(?:class|struct|interface)\s+([A-Za-z_]\w*)", text):
            if m.group(1) not in classes:
                classes.append(m.group(1))
        for m in re.finditer(r"\b([A-Za-z_]\w*)\s*\([^;{}]*\)\s*(?:;|\{)", text):
            name = m.group(1)
            if name not in {"if", "for", "while", "switch", "return"} and name not in funcs:
                funcs.append(name)
    return classes, funcs


def html_page(title: str, body: str, project: str) -> str:
    title = html.escape(title)
    project = html.escape(project)
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"/>
<meta name="generator" content="Doxygen {VERSION}"/>
<title>{project}: {title}</title>
<link rel="stylesheet" href="doxygen.css"/>
</head><body>
<div id="top"><div id="titlearea"><h1>{project}</h1></div></div>
<div class="contents">
{body}
</div>
<hr class="footer"/><address class="footer"><small>Generated by Doxygen {VERSION}</small></address>
</body></html>
"""


def generate_docs(cfg: dict, config_name: str) -> int:
    quiet = truthy(cfg.get("QUIET", "NO"))
    project = stripq(cfg.get("PROJECT_NAME", "My Project")) or "My Project"
    out = Path(stripq(cfg.get("OUTPUT_DIRECTORY", "")) or ".")
    if not quiet:
        print(f"Doxygen version used: {VERSION}")
        if not out.exists() and out != Path("."):
            print(f"Notice: Output directory '{out}' does not exist. I have created it for you.")
        for msg in ["Searching for include files...", "Searching INPUT for files to process...", "Parsing files"]:
            print(msg)
    out.mkdir(parents=True, exist_ok=True)
    files = find_inputs(cfg)
    classes, funcs = extract_symbols(files)
    if not quiet:
        for f in files:
            print(f"Parsing file {f.resolve()}...")
        print("Generating output...")

    if truthy(cfg.get("GENERATE_HTML", "YES"), True):
        hdir = out / stripq(cfg.get("HTML_OUTPUT", "html") or "html")
        hdir.mkdir(parents=True, exist_ok=True)
        (hdir / "doxygen.css").write_text(read_res("html_style"), encoding="utf-8")
        (hdir / "tabs.css").write_text("/* tabs */\n", encoding="utf-8")
        (hdir / "dynsections.js").write_text("// generated by doxygen clone\n", encoding="utf-8")
        body = [f"<h2>{html.escape(project)} Documentation</h2>"]
        if classes:
            body.append("<h3>Classes</h3><ul>" + "".join(f'<li><a href="class{html.escape(c)}.html">{html.escape(c)}</a></li>' for c in classes) + "</ul>")
        if files:
            body.append("<h3>Files</h3><ul>" + "".join(f'<li><a href="{html.escape(file_html_name(f))}">{html.escape(str(f))}</a></li>' for f in files) + "</ul>")
        (hdir / "index.html").write_text(html_page("Main Page", "\n".join(body), project), encoding="utf-8")
        (hdir / "annotated.html").write_text(html_page("Data Structures", "<ul>" + "".join(f"<li>{html.escape(c)}</li>" for c in classes) + "</ul>", project), encoding="utf-8")
        (hdir / "classes.html").write_text(html_page("Class Index", "<ul>" + "".join(f"<li>{html.escape(c)}</li>" for c in classes) + "</ul>", project), encoding="utf-8")
        (hdir / "files.html").write_text(html_page("File List", "<ul>" + "".join(f"<li>{html.escape(str(f))}</li>" for f in files) + "</ul>", project), encoding="utf-8")
        (hdir / "functions.html").write_text(html_page("Functions", "<ul>" + "".join(f"<li>{html.escape(fn)}</li>" for fn in funcs) + "</ul>", project), encoding="utf-8")
        for c in classes:
            (hdir / f"class{c}.html").write_text(html_page(f"{c} Class Reference", f"<h2>{html.escape(c)} Class Reference</h2>", project), encoding="utf-8")
        for f in files:
            try:
                src = html.escape(f.read_text(encoding="utf-8", errors="replace"))
            except OSError:
                src = ""
            (hdir / file_html_name(f)).write_text(html_page(f"{f.name} File Reference", f"<pre>{src}</pre>", project), encoding="utf-8")

    if truthy(cfg.get("GENERATE_LATEX", "YES"), True):
        ldir = out / stripq(cfg.get("LATEX_OUTPUT", "latex") or "latex")
        ldir.mkdir(parents=True, exist_ok=True)
        (ldir / "refman.tex").write_text(f"\\documentclass{{book}}\n\\begin{{document}}\n\\chapter*{{{project}}}\nGenerated by Doxygen {VERSION}.\n\\end{{document}}\n", encoding="utf-8")
        (ldir / "doxygen.sty").write_text(read_res("latex_style"), encoding="utf-8")
        (ldir / "Makefile").write_text("all:\n\t@echo 'Run pdflatex refman.tex'\n", encoding="utf-8")

    if truthy(cfg.get("GENERATE_MAN", "NO")):
        mdir = out / stripq(cfg.get("MAN_OUTPUT", "man") or "man")
        mdir.mkdir(parents=True, exist_ok=True)
        (mdir / "index.3").write_text(f".TH {project.upper().replace(' ', '_')} 3\n.SH NAME\n{project} \\- generated documentation\n", encoding="utf-8")

    if not quiet:
        print("finished...")
    return 0


def file_html_name(p: Path) -> str:
    name = p.name
    repl = {"_": "__", ".": "_8"}
    out = "".join(repl.get(ch, ch) for ch in name)
    return out + ".html"


def generate_config(simple: bool, target: str) -> int:
    data = read_res("Doxyfile.simple" if simple else "Doxyfile.full")
    write_target(target, data)
    if target != "-":
        print(f"\n\nConfiguration file '{target}' created.\n")
        print("Now edit the configuration file and enter\n")
        print(f"  {exe_name() if Path(exe_name()).name != 'executable' else 'doxygen'}\n")
        print("to generate the documentation for your project\n")
    return 0


def update_config(simple: bool, target: str) -> int:
    if target == "-":
        _ = sys.stdin.read()
        sys.stdout.write(read_res("Doxyfile.simple" if simple else "Doxyfile.full"))
        return 0
    p = Path(target)
    if not p.exists():
        sys.stderr.write(f"error: configuration file {target} not found!\n")
        sys.stdout.write(usage())
        return 1
    old = p.with_suffix(p.suffix + ".bak") if p.suffix else Path(str(p) + ".bak")
    try:
        shutil.copyfile(p, old)
    except OSError:
        pass
    p.write_text(read_res("Doxyfile.simple" if simple else "Doxyfile.full"), encoding="utf-8")
    print(f"Configuration file '{target}' updated.")
    return 0


def compare_config(target: str) -> int:
    cfg = parse_config(target)
    tmpl = parse_config_text(read_res("Doxyfile.simple"))
    for key in sorted(cfg):
        if key in tmpl and cfg[key].strip() != tmpl[key].strip():
            print(f"{key:<24} = {cfg[key]}")
    return 0


def comment_to_html(path: str) -> int:
    text = Path(path).read_text(encoding="utf-8", errors="replace") if path != "-" else sys.stdin.read()
    sys.stdout.write(html_page("Comment", "<pre>" + html.escape(text) + "</pre>", "Doxygen"))
    return 0


def main(argv: list[str]) -> int:
    if not argv or argv[0] in {"-h", "--help", "-?"}:
        sys.stdout.write(usage())
        return 0
    if argv[0] == "-v":
        print(VERSION)
        return 0
    if argv[0] == "-V":
        print(VERSION)
        print("    with sqlite3 3.42.0.")
        return 0
    if argv[0] == "-d" and len(argv) == 1:
        sys.stdout.write(debug_usage())
        return 0
    if argv[0] == "-c" and len(argv) >= 2:
        return comment_to_html(argv[1])
    if argv[0] == "-m":
        return 0

    simple = False
    args = argv[:]
    if args and args[0] == "-s":
        simple = True
        args = args[1:]
    if args and args[0] == "-q":
        args = args[1:]
        if args and not args[0].startswith("-"):
            cfg = parse_config(args[0])
        else:
            cfg = parse_config("Doxyfile")
        cfg["QUIET"] = "YES"
        return generate_docs(cfg, args[0] if args else "Doxyfile")

    if args and args[0] == "-g":
        return generate_config(simple, args[1] if len(args) > 1 else "Doxyfile")
    if args and args[0] == "-u":
        return update_config(simple, args[1] if len(args) > 1 else "Doxyfile")
    if args and args[0] == "-l":
        write_target(args[1] if len(args) > 1 else "DoxygenLayout.xml", read_res("DoxygenLayout.xml"))
        return 0
    if args and args[0] == "-e":
        if len(args) >= 3 and args[1].lower() == "rtf":
            write_target(args[2], read_res("rtf_extensions"))
            return 0
    if args and args[0] == "-f":
        if len(args) >= 3 and args[1].lower() == "emoji":
            write_target(args[2], read_res("emojis.txt"))
            return 0
    if args and args[0] == "-w":
        if len(args) >= 3 and args[1].lower() == "rtf":
            write_target(args[2], read_res("rtf_style"))
            return 0
        if len(args) >= 5 and args[1].lower() == "html":
            write_target(args[2], read_res("html_header"))
            write_target(args[3], read_res("html_footer"))
            write_target(args[4], read_res("html_style"))
            return 0
        if len(args) >= 5 and args[1].lower() == "latex":
            write_target(args[2], read_res("latex_header"))
            write_target(args[3], read_res("latex_footer"))
            write_target(args[4], read_res("latex_style"))
            return 0
    if args and args[0] in {"-x", "-x_noenv"}:
        return compare_config(args[1] if len(args) > 1 else "Doxyfile")
    if args and args[0].startswith("-"):
        sys.stderr.write(f"error: Unknown option \"{args[0]}\"\n")
        sys.stdout.write(usage())
        return 1

    cfg_name = args[0] if args else "Doxyfile"
    cfg = parse_config(cfg_name)
    return generate_docs(cfg, cfg_name)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
