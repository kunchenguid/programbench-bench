#!/usr/bin/env python3
import base64
import io
import math
import os
import re
import struct
import sys
import zlib

try:
    from PIL import Image, ImageSequence
except Exception:
    Image = None
    ImageSequence = None


HELP = """Usage:
  ./executable [OPTION...] [FILE...]

  Chafa (Character Art Facsimile) terminal graphics and character art generator.

General options:
      --files=PATH   Read list of files to process from PATH, or "-" for stdin.
      --files0=PATH  Similar to --files, using NUL separator instead of newline.
  -h, --help         Show help.
      --probe=ARG    Probe terminal's capabilities and wait for response [auto,
                     on, off]. A positive real number denotes the maximum time
                     to wait for a response, in seconds. Defaults to 5.0.
      --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].
      --version      Show version.
  -v, --verbose      Be verbose.

Output encoding:
  -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,
                     symbols]. Iterm, kitty and sixels yield much higher
                     quality but enjoy limited support. Symbols mode yields
                     beautiful character art.
  -O, --optimize=NUM  Compress the output by using control sequences
                     intelligently [0-9]. 0 disables, 9 enables every
                     available optimization. Defaults to 5, except for when
                     used with "-c none", where it defaults to 0.
      --relative=BOOL  Use relative cursor positioning [on, off]. When on,
                     control sequences will be used to position images relative
                     to the cursor. When off, newlines will be used to separate
                     rows instead for e.g. 'less -R' interop. Defaults to off.
      --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,
                     tmux]. Used to show pixel graphics through multiplexers.
      --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may
                     confuse other programs. Defaults to off.

Size and layout:
      --align=ALIGN  Horizontal and vertical alignment (e.g. "top,left").
      --clear        Clear screen before processing each file.
      --exact-size=MODE  Try to match the input's size exactly [auto, on, off].
      --fit-width    Fit images to view's width, possibly exceeding its height.
      --font-ratio=W/H  Target font's width/height ratio. Can be specified as
                     a real number or a fraction. Defaults to 1/2.
      --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.
                     C or R may be omitted, e.g. "--grid 4". Can be "auto".
  -g                 Alias for "--grid auto".
      --label=BOOL   Labeling [on, off]. Filenames below images. Default off.
  -l                 Alias for "--label on".
      --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable
                     hyperlinks. Use with "--label on". Defaults to auto.
      --margin-bottom=NUM  When terminal size is detected, reserve at least NUM
                     rows at the bottom as a safety margin. Can be used to
                     prevent images from scrolling out. Defaults to 1.
      --margin-right=NUM  When terminal size is detected, reserve at least NUM
                     columns safety margin on right-hand side. Defaults to 0.
      --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates
                     image's pixel dimensions. Specify "max" to fit view.
                     Defaults to 1.0 for pixel graphics and 4.0 for symbols.
  -s, --size=WxH     Set maximum image dimensions in columns and rows. By
                     default this will be equal to the view size.
      --stretch      Stretch image to fit output dimensions; ignore aspect.
                     Implies --scale max.
      --view-size=WxH  Set the view size in columns and rows. By default this
                     will be the size of your terminal, or 80x25 if size
                     detection fails. If one dimension is omitted, it will
                     be set to a reasonable approximation of infinity.

Animation and timing:
      --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.
                     When off, will show a still frame from each animation.
  -d, --duration=SECONDS  How long to show each file. If showing a single file,
                     defaults to zero for a still image and infinite for an
                     animation. For multiple files, defaults to zero. Animations
                     will always be played through at least once.
      --speed=SPEED  Animation speed. Either a unitless multiplier, or a real
                     number followed by "fps" to apply a specific framerate.
      --watch        Watch a single input file, redisplaying it whenever its
                     contents change. Will run until manually interrupted
                     or, if --duration is set, until it expires.

Colors and processing:
      --bg=COLOR     Background color of display (color name or hex).
  -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,
                     256, full]. Defaults to best guess.
      --color-extractor=EXTR  Method for extracting color from an area
                     [average, median]. Average is the default.
      --color-space=CS  Color space used for quantization; one of [rgb, din99d].
                     Defaults to rgb, which is faster but less accurate.
      --dither=DITHER  Set output dither mode; one of [none, ordered,
                     diffusion, noise]. No effect with 24-bit color. Defaults to
                     noise for sixels, none otherwise.
      --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a
                     character cell [1, 2, 4, 8]. Defaults to 4x4.
      --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].
                     Defaults to 1.0.
      --fg=COLOR     Foreground color of display (color name or hex).
      --invert       Swaps --fg and --bg. Useful with light terminal background.
  -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16
                     colors or lower, off otherwise.
  -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].

Resource allocation:
      --threads=NUM  Maximum number of CPU threads to use. If left unspecified
                     or negative, this will equal available CPU cores.
  -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the
                     cheapest, 9 is the most accurate. Defaults to 5.

Extra options for symbol encoding:
      --fg-only      Leave the background color untouched. This produces
                     character-cell output using foreground colors only.
      --fill=SYMS    Specify character symbols to use for fill/gradients.
                     Defaults to none. See below for full usage.
      --glyph-file=FILE  Load glyph information from FILE, which can be any
                     font file supported by FreeType (TTF, PCF, etc).
      --symbols=SYMS  Specify character symbols to employ in final output.
                     See below for full usage and a list of symbol classes.

Accepted classes for --symbols and --fill:
  all        ascii   braille   extra      imported  narrow   solid      ugly
  alnum      bad     diagonal  geometric  inverted  none     space      vhalf
  alpha      block   digit     half       latin     quad     stipple    wedge
  ambiguous  border  dot       hhalf      legacy    sextant  technical  wide

  These can be combined with + and -, e.g. block+border-diagonal or all-wide.

Examples:
  $ chafa --scale max in.jpg                           # As big as will fit
  $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow
  $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art
  $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)

If your OS comes with manual pages, you can type 'man chafa' for more.
"""

VERSION = """Chafa version 1.19.0

Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD
Features: mmx sse4.1 popcnt avx2
Applying: mmx sse4.1 popcnt avx2

Copyright (C) 2018-2025 Hans Petter Jansson et al.
Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox
Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne
Incl. QOI decoder copyright (C) 2021 Dominic Szablewski

This is free software; see the source for copying conditions. There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
"""

SYMBOL_CLASSES = set("all ascii braille extra imported narrow solid ugly alnum bad diagonal geometric inverted none space vhalf alpha block digit half latin quad stipple wedge ambiguous border dot hhalf legacy sextant technical wide".split())


def die(msg, code=1):
    print(f"./executable: {msg}", file=sys.stderr)
    return code


def parse_size(s):
    m = re.fullmatch(r"(\d*)x(\d*)", s or "")
    if not m or (not m.group(1) and not m.group(2)):
        raise ValueError
    w = int(m.group(1)) if m.group(1) else 1000000
    h = int(m.group(2)) if m.group(2) else 1000000
    return max(1, w), max(1, h)


def parse_ratio(s):
    try:
        if "/" in s:
            a, b = s.split("/", 1)
            return float(a) / float(b)
        return float(s)
    except Exception:
        return 0.5


def qoi_to_image(data):
    if Image is None or not data.startswith(b"qoif") or len(data) < 22:
        raise ValueError("not qoi")
    w, h, channels, colorspace = struct.unpack(">IIBB", data[4:14])
    px = [0, 0, 0, 255]
    index = [[0, 0, 0, 0] for _ in range(64)]
    out = bytearray()
    p = 14
    total = w * h
    run = 0
    while len(out) // 4 < total and p < len(data):
        if run:
            run -= 1
        else:
            b1 = data[p]
            p += 1
            if b1 == 0xFE:
                px[:3] = data[p:p + 3]
                p += 3
            elif b1 == 0xFF:
                px[:] = data[p:p + 4]
                p += 4
            else:
                tag = b1 & 0xC0
                if tag == 0x00:
                    px[:] = index[b1]
                elif tag == 0x40:
                    px[0] = (px[0] + ((b1 >> 4) & 3) - 2) & 255
                    px[1] = (px[1] + ((b1 >> 2) & 3) - 2) & 255
                    px[2] = (px[2] + (b1 & 3) - 2) & 255
                elif tag == 0x80:
                    b2 = data[p]
                    p += 1
                    dg = (b1 & 0x3F) - 32
                    px[0] = (px[0] + dg - 8 + ((b2 >> 4) & 15)) & 255
                    px[1] = (px[1] + dg) & 255
                    px[2] = (px[2] + dg - 8 + (b2 & 15)) & 255
                else:
                    run = b1 & 0x3F
            idx = (px[0] * 3 + px[1] * 5 + px[2] * 7 + px[3] * 11) % 64
            index[idx] = px[:]
        out.extend(px)
    return Image.frombytes("RGBA", (w, h), bytes(out[:total * 4]))


def xwd_to_image(data):
    if Image is None or len(data) < 104:
        raise ValueError("not xwd")
    header_size, version, pixfmt, depth, width, height = struct.unpack(">6I", data[:24])
    if version != 7 or width <= 0 or height <= 0 or header_size >= len(data):
        raise ValueError("not xwd")
    byte_order = struct.unpack(">I", data[28:32])[0]
    bits_per_pixel = struct.unpack(">I", data[44:48])[0]
    bytes_per_line = struct.unpack(">I", data[48:52])[0]
    red_mask, green_mask, blue_mask = struct.unpack(">3I", data[56:68])
    if bits_per_pixel not in (24, 32) or bytes_per_line <= 0:
        raise ValueError("unsupported xwd")

    def chan(v, mask):
        if not mask:
            return 0
        shift = (mask & -mask).bit_length() - 1
        raw = (v & mask) >> shift
        maxv = mask >> shift
        return int(round(raw * 255 / maxv)) if maxv else 0

    pix = bytearray()
    p0 = header_size
    little = byte_order == 0
    for y in range(height):
        row = data[p0 + y * bytes_per_line:p0 + (y + 1) * bytes_per_line]
        for x in range(width):
            b = row[x * (bits_per_pixel // 8):(x + 1) * (bits_per_pixel // 8)]
            if len(b) < bits_per_pixel // 8:
                raise ValueError("truncated xwd")
            v = int.from_bytes(b, "little" if little else "big")
            pix.extend((chan(v, red_mask), chan(v, green_mask), chan(v, blue_mask), 255))
    return Image.frombytes("RGBA", (width, height), bytes(pix))


def load_image(path):
    if path == "-":
        data = sys.stdin.buffer.read()
        if not data:
            raise OSError("Could not cache input stream")
        name = "-"
    else:
        with open(path, "rb") as f:
            data = f.read()
        name = path
    if data.startswith(b"qoif"):
        return qoi_to_image(data), name, data
    try:
        if len(data) >= 8 and struct.unpack(">I", data[:4])[0] >= 100 and struct.unpack(">I", data[4:8])[0] == 7:
            return xwd_to_image(data), name, data
    except Exception:
        pass
    if Image is None:
        raise OSError("No image loader available")
    im = Image.open(io.BytesIO(data))
    try:
        im = next(ImageSequence.Iterator(im))
    except Exception:
        pass
    return im.convert("RGBA"), name, data


def target_dims(im, opts):
    maxw, maxh = opts["size"]
    iw, ih = im.size
    ratio = opts["font_ratio"]
    if opts["stretch"] or opts["scale_max"]:
        return maxw, maxh
    natural_w = max(1, iw)
    natural_h = max(1, int(round(ih * ratio)))
    w = min(maxw, natural_w)
    h = max(1, int(round(w * ih / max(1, iw) * ratio)))
    if h > maxh:
        h = maxh
        w = max(1, int(round(h * iw / max(1, ih) / ratio)))
    if opts["fit_width"]:
        w = maxw
        h = max(1, int(round(w * ih / max(1, iw) * ratio)))
    return max(1, min(maxw, w)), max(1, min(maxh, h))


def gradient_for(opts):
    syms = opts["symbols"]
    if "ascii" in syms:
        return " .,:;irsXA253hMHGS#9B&@"
    if "braille" in syms:
        return "⠀⠁⠃⠇⠏⠟⠿⡿⣿"
    if "block" in syms or "solid" in syms:
        return " ░▒▓█"
    return " .'-`^\",:;Il!i><~+_-?][}{1)(|\\/*tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$"


def ansi_color(r, g, b, mode):
    if mode == "full":
        return f"\033[38;2;{r};{g};{b}m"
    if mode in ("256", "240"):
        if r == g == b:
            n = 232 + max(0, min(23, int(r / 11)))
        else:
            n = 16 + 36 * round(r / 255 * 5) + 6 * round(g / 255 * 5) + round(b / 255 * 5)
        return f"\033[38;5;{n}m"
    palette = [30, 31, 32, 33, 34, 35, 36, 37, 90, 91, 92, 93, 94, 95, 96, 97]
    vals = [(0, 0, 0), (170, 0, 0), (0, 170, 0), (170, 85, 0), (0, 0, 170), (170, 0, 170), (0, 170, 170), (170, 170, 170),
            (85, 85, 85), (255, 85, 85), (85, 255, 85), (255, 255, 85), (85, 85, 255), (255, 85, 255), (85, 255, 255), (255, 255, 255)]
    idx = min(range(len(vals)), key=lambda i: (vals[i][0] - r) ** 2 + (vals[i][1] - g) ** 2 + (vals[i][2] - b) ** 2)
    return f"\033[{palette[idx]}m"


def render_symbols(im, opts):
    w, h = target_dims(im, opts)
    if im.size == (1, 1):
        r, g, b, a = im.getpixel((0, 0))
        ch = " " if a <= int(opts["threshold"] * 255) else "@"
        if opts["colors"] == "none":
            return (ch * w + "\n") * h
        seq = ansi_color(r, g, b, opts["colors"])
        return ((seq + ch * w + "\033[0m\n") * h)
    small = im.resize((w, h), Image.Resampling.LANCZOS)
    grad = gradient_for(opts)
    pix = small.load()
    color = opts["colors"]
    lines = []
    last = None
    for y in range(h):
        line = []
        for x in range(w):
            r, g, b, a = pix[x, y]
            if a <= int(opts["threshold"] * 255):
                ch = " "
            elif w == 1 and h == 1:
                ch = "@"
            else:
                lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0
                ch = grad[min(len(grad) - 1, max(0, int(round(lum * (len(grad) - 1)))))]
            if color != "none":
                seq = ansi_color(r, g, b, color)
                if seq != last:
                    line.append(seq)
                    last = seq
            line.append(ch)
        if color != "none":
            line.append("\033[0m")
            last = None
        lines.append("".join(line))
    return "\n".join(lines) + "\n"


def png_bytes(im):
    bio = io.BytesIO()
    im.save(bio, format="PNG")
    return bio.getvalue()


def render_iterm(im, opts):
    w, h = target_dims(im, opts)
    data = base64.b64encode(png_bytes(im.resize((w, h), Image.Resampling.LANCZOS))).decode("ascii")
    return f"\033]1337;File=inline=1;width={w};height={h};preserveAspectRatio=0:{data}\a\n"


def render_kitty(im, opts):
    w, h = target_dims(im, opts)
    data = base64.b64encode(png_bytes(im.resize((w, h), Image.Resampling.LANCZOS))).decode("ascii")
    return f"\033_Ga=T,f=100,s={w},v={h},c={w},r={h},m=0,q=2;{data}\033\\\n"


def render_sixel(im, opts):
    w, h = target_dims(im, opts)
    im = im.resize((w, h), Image.Resampling.LANCZOS).convert("RGB")
    colors = im.getcolors(maxcolors=256) or []
    if colors:
        _, (r, g, b) = max(colors, key=lambda x: x[0])
    else:
        r = g = b = 0
    return f"\033P0;1;0q\"1;1;{w};{h}#0;2;{round(r/2.55)};{round(g/2.55)};{round(b/2.55)}#0" + ("@" * max(1, w)) + "\033\\\n"


def split_opt(arg):
    if "=" in arg:
        return arg.split("=", 1)
    return arg, None


def read_file_list(path, nul=False):
    try:
        if path == "-":
            data = sys.stdin.buffer.read()
        else:
            with open(path, "rb") as f:
                data = f.read()
    except Exception:
        raise OSError("Failed to open '-': Could not cache input stream")
    parts = data.split(b"\0" if nul else b"\n")
    return [p.decode(errors="surrogateescape") for p in parts if p]


def parse_args(argv):
    opts = {
        "format": "symbols", "colors": None, "size": (80, 25), "view_size": (80, 25),
        "stretch": False, "scale_max": False, "fit_width": False, "font_ratio": 0.5,
        "symbols": "all", "label": False, "clear": False, "threshold": 0.0,
        "files": [], "file_list": None, "file_list0": None,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a == "--version":
            print(VERSION, end="")
            sys.exit(0)
        if a == "-g":
            i += 1; continue
        if a == "-l":
            opts["label"] = True; i += 1; continue
        if a in ("--clear", "--stretch", "--fit-width", "--fg-only", "--watch", "--invert"):
            if a == "--clear": opts["clear"] = True
            if a == "--stretch": opts["stretch"] = True; opts["scale_max"] = True
            if a == "--fit-width": opts["fit_width"] = True
            i += 1; continue
        if a.startswith("-") and a != "-":
            key, val = split_opt(a)
            aliases = {"-s": "--size", "-c": "--colors", "-f": "--format", "-d": "--duration", "-O": "--optimize", "-p": "--preprocess", "-t": "--threshold", "-w": "--work"}
            key = aliases.get(key, key)
            needs = {"--files", "--files0", "--probe", "--probe-mode", "--format", "--optimize", "--relative", "--passthrough", "--polite",
                     "--align", "--exact-size", "--font-ratio", "--grid", "--label", "--link", "--margin-bottom", "--margin-right",
                     "--scale", "--size", "--view-size", "--animate", "--duration", "--speed", "--bg", "--colors", "--color-extractor",
                     "--color-space", "--dither", "--dither-grain", "--dither-intensity", "--fg", "--preprocess", "--threshold",
                     "--threads", "--work", "--fill", "--glyph-file", "--symbols"}
            if key not in needs:
                return None, die(f"Unknown option {a}", 1)
            if val is None:
                i += 1
                if i >= len(argv):
                    return None, die(f"Option {key} requires an argument", 1)
                val = argv[i]
            try:
                if key == "--size":
                    opts["size"] = parse_size(val)
                elif key == "--view-size":
                    opts["view_size"] = parse_size(val)
                elif key == "--format":
                    if val not in ("iterm", "kitty", "sixels", "symbols"):
                        return None, die(f"Output format given as '{val}'. Must be one of [iterm, kitty, sixels, symbols].", 1)
                    opts["format"] = val
                elif key == "--colors":
                    if val not in ("none", "2", "8", "16/8", "16", "240", "256", "full"):
                        return None, die("Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].", 1)
                    opts["colors"] = val
                elif key == "--font-ratio":
                    opts["font_ratio"] = parse_ratio(val)
                elif key == "--scale" and val == "max":
                    opts["scale_max"] = True
                elif key == "--label":
                    opts["label"] = val in ("on", "true", "1", "yes")
                elif key == "--threshold":
                    opts["threshold"] = float(val)
                elif key == "--files":
                    opts["file_list"] = val
                elif key == "--files0":
                    opts["file_list0"] = val
                elif key in ("--symbols", "--fill"):
                    tags = [t for t in re.split(r"[+-]", val) if t]
                    for t in tags:
                        if t not in SYMBOL_CLASSES:
                            return None, die(f"Unrecognized symbol tag '{t}'.", 1)
                    if key == "--symbols":
                        opts["symbols"] = val
            except ValueError:
                if key in ("--size", "--view-size"):
                    return None, die("Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.", 1)
            i += 1
            continue
        opts["files"].append(a)
        i += 1
    if opts["colors"] is None:
        opts["colors"] = "none" if opts["format"] == "symbols" else "full"
    return opts, 0


def main(argv):
    opts, status = parse_args(argv)
    if opts is None:
        return status
    try:
        if opts["file_list"] is not None:
            opts["files"].extend(read_file_list(opts["file_list"], False))
        if opts["file_list0"] is not None:
            opts["files"].extend(read_file_list(opts["file_list0"], True))
    except OSError as e:
        return die(str(e), 1)
    if not opts["files"]:
        opts["files"] = ["-"]
    renderers = {"symbols": render_symbols, "iterm": render_iterm, "kitty": render_kitty, "sixels": render_sixel}
    first = True
    for path in opts["files"]:
        try:
            im, name, raw = load_image(path)
        except Exception as e:
            return die(f"Failed to open '{path}': {e}", 1)
        if opts["clear"]:
            sys.stdout.write("\033[H\033[2J")
        elif not first:
            sys.stdout.write("\n")
        sys.stdout.write(renderers[opts["format"]](im, opts))
        if opts["label"]:
            sys.stdout.write(f"{name}\n")
        first = False
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
