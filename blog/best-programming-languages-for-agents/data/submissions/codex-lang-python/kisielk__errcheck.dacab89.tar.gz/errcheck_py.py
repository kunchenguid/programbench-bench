#!/usr/bin/env python3
import argparse, json, os, re, subprocess, sys
from pathlib import Path

GO_TOOL = "/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.22.0.linux-amd64/bin"

STD_ERROR_FUNCS = {
    'os': {'Chdir','Chmod','Chown','Chtimes','Clearenv','CopyFS','Mkdir','MkdirAll','MkdirTemp','Remove','RemoveAll','Rename','Setenv','Symlink','Truncate','Unsetenv','WriteFile','ReadFile','Getwd','UserCacheDir','UserConfigDir','UserHomeDir','Create','CreateTemp','Open','OpenFile','NewFile','Pipe','Link','Readlink','Lchown','Exec','StartProcess'},
    'io': {'Copy','CopyBuffer','CopyN','ReadAll','ReadAtLeast','ReadFull','WriteString'},
    'fmt': {'Print','Printf','Println','Fprint','Fprintf','Fprintln','Sprint','Sprintf','Sprintln','Scan','Scanf','Scanln','Fscan','Fscanf','Fscanln','Sscan','Sscanf','Sscanln'},
    'strconv': {'Atoi','ParseBool','ParseFloat','ParseInt','ParseUint','Unquote','UnquoteChar'},
    'encoding/json': {'Marshal','MarshalIndent','Unmarshal','NewDecoder','NewEncoder'},
    'encoding/xml': {'Marshal','MarshalIndent','Unmarshal'},
    'encoding/binary': {'Read','Write','Decode','Encode'},
    'net/http': {'ListenAndServe','ListenAndServeTLS','Serve','ServeTLS','Get','Head','Post','PostForm','NewRequest','NewRequestWithContext','ReadRequest','ReadResponse'},
    'net': {'Dial','DialTimeout','Listen','ListenPacket','ResolveTCPAddr','ResolveUDPAddr','ResolveIPAddr','ResolveUnixAddr','Pipe','FileConn','FileListener','FilePacketConn'},
    'bufio': {'ReadBytes','ReadString','WriteTo','ReadFrom'},
    'bytes': {'ReadFrom'},
    'strings': {'WriteTo'},
    'regexp': {'Compile','CompilePOSIX'},
    'time': {'Parse','ParseDuration','LoadLocation'},
    'path/filepath': {'Walk','WalkDir','Abs','Rel','EvalSymlinks'},
    'archive/zip': {'OpenReader','NewReader'},
    'compress/gzip': {'NewReader'},
    'database/sql': {'Open'},
    'context': {'WithCancelCause'},
}
DEFAULT_EXCLUDES = {('fmt', n) for n in STD_ERROR_FUNCS['fmt'] if n.startswith(('Print','Fprint'))}

GENERATED_RE = re.compile(r'Code generated .* DO NOT EDIT\.', re.I)
FUNC_RE = re.compile(r'func\s+(?:\([^)]*\)\s*)?(\w+)\s*\([^)]*\)\s*([^\{\n]*(?:\([^{};]*\))?)')
IMPORT_BLOCK_RE = re.compile(r'import\s*\((.*?)\)', re.S)
IMPORT_LINE_RE = re.compile(r'^\s*import\s+(?:(\w+|\.|_)\s+)?"([^"]+)"', re.M)
IMPORT_IN_BLOCK_RE = re.compile(r'^\s*(?:(\w+|\.|_)\s+)?"([^"]+)"', re.M)
CALL_RE = re.compile(r'(?<![\w.])((?:[A-Za-z_]\w*\.)?[A-Za-z_]\w*)\s*\(')
ASSERT_RE = re.compile(r'\.\s*\([^)]*\)')

class ValueList(argparse.Action):
    def __call__(self, parser, ns, values, option_string=None):
        cur = getattr(ns, self.dest, None) or []
        cur.append(values)
        setattr(ns, self.dest, cur)

def usage(prog):
    return f"Usage of {prog}:\n" + """  -abspath
    	print absolute paths to files
  -asserts
    	if true, check for ignored type assertion results
  -blank
    	if true, check for errors assigned to blank identifier
  -exclude string
    	Path to a file containing a list of functions to exclude from checking
  -excludeonly
    	Use only excludes from -exclude file
  -ignore value
    	[deprecated] comma-separated list of pairs of the form pkg:regex
    	            the regex is used to ignore names within pkg.
  -ignoregenerated
    	if true, checking of files with generated code is disabled
  -ignorepkg string
    	comma-separated list of package paths to ignore
  -ignoretests
    	if true, checking of _test.go files is disabled
  -mod string
    	module download mode to use: readonly or vendor. See 'go help modules' for more.
  -tags value
    	comma or space-separated list of build tags to include
  -verbose
    	produce more verbose logging
"""

def parse_args(argv):
    p = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    for b in ['abspath','asserts','blank','excludeonly','ignoregenerated','ignoretests','verbose']:
        p.add_argument('-'+b, action='store_true')
    p.add_argument('-exclude', default='')
    p.add_argument('-ignore', action=ValueList, default=[])
    p.add_argument('-ignorepkg', default='')
    p.add_argument('-mod', default='')
    p.add_argument('-tags', action=ValueList, default=[])
    if any(a in ('-h','--help') for a in argv):
        sys.stderr.write(usage(sys.argv[0] if sys.argv[0] else './executable'))
        sys.exit(2)
    try:
        ns, rest = p.parse_known_args(argv)
    except SystemExit:
        sys.stderr.write(usage(sys.argv[0]))
        sys.exit(2)
    bad = [a for a in rest if a.startswith('-')]
    if bad:
        sys.stderr.write(f"flag provided but not defined: {bad[0].lstrip('-')}\n")
        sys.stderr.write(usage(sys.argv[0]))
        sys.exit(2)
    ns.packages = rest or ['.']
    return ns

def go_env():
    env = os.environ.copy()
    env['PATH'] = GO_TOOL + os.pathsep + env.get('PATH','')
    return env

def go_list(patterns, ns):
    cmd = ['go','list','-json','-deps']
    if ns.tags:
        cmd += ['-tags', ','.join(ns.tags)]
    if ns.mod:
        cmd += ['-mod', ns.mod]
    cmd += patterns
    try:
        cp = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=go_env(), timeout=30)
    except Exception as e:
        sys.stderr.write(f'error: failed to check packages: err: go command required, not found: {e}: stderr: \n')
        sys.exit(2)
    if cp.returncode != 0:
        msg = cp.stderr.strip() or cp.stdout.strip()
        sys.stderr.write(f'error: failed to check packages: {msg}\n')
        sys.exit(2)
    dec = json.JSONDecoder(); s = cp.stdout; i=0; out=[]
    while i < len(s):
        while i < len(s) and s[i].isspace(): i += 1
        if i >= len(s): break
        obj, j = dec.raw_decode(s, i); out.append(obj); i = j
    return out

def split_top(s, sep=','):
    res=[]; cur=''; depth=0; quote=None; esc=False
    for ch in s:
        if quote:
            cur += ch
            if esc: esc=False
            elif ch == '\\': esc=True
            elif ch == quote: quote=None
        else:
            if ch in '"`\'': quote=ch; cur+=ch
            elif ch in '([{': depth+=1; cur+=ch
            elif ch in ')]}': depth=max(0,depth-1); cur+=ch
            elif ch==sep and depth==0: res.append(cur.strip()); cur=''
            else: cur+=ch
    if cur.strip() or s.endswith(sep): res.append(cur.strip())
    return res

def strip_comments_preserve(src):
    out=[]; i=0; n=len(src); line=True
    while i<n:
        if src.startswith('//', i):
            j=src.find('\n', i); out.append(' '*(n-i if j<0 else j-i)); i=n if j<0 else j
        elif src.startswith('/*', i):
            j=src.find('*/', i+2); j=n-2 if j<0 else j
            seg=src[i:j+2]; out.append(''.join('\n' if c=='\n' else ' ' for c in seg)); i=j+2
        else:
            out.append(src[i]); i+=1
    return ''.join(out)

def imports(src):
    mp={}
    for block in IMPORT_BLOCK_RE.findall(src):
        for alias,path in IMPORT_IN_BLOCK_RE.findall(block):
            if alias in ('_', '.'): continue
            mp[alias or path.split('/')[-1]] = path
    for alias,path in IMPORT_LINE_RE.findall(src):
        if alias in ('_', '.'): continue
        mp[alias or path.split('/')[-1]] = path
    return mp

def returns_error(sig):
    return bool(re.search(r'\berror\b', sig))

def scan_funcs(src):
    clean=strip_comments_preserve(src)
    funcs=set()
    for m in FUNC_RE.finditer(clean):
        sig=m.group(2) or ''
        # extend to opening brace for multi-token result lists
        tail=clean[m.end(): clean.find('{', m.end()) if clean.find('{', m.end())!=-1 else m.end()+100]
        if returns_error(sig + tail): funcs.add(m.group(1))
    return funcs

def load_excludes(path):
    ex=set()
    if not path: return ex
    try:
        for line in Path(path).read_text().splitlines():
            line=line.strip()
            if not line or line.startswith('//'): continue
            line=re.sub(r'\([^)]*\)$','',line)
            if line.startswith('(*') or line.startswith('('):
                if ').' in line: line=line.split(').',1)[1]
            if '.' in line:
                pkg, name = line.rsplit('.',1); ex.add((pkg,name))
    except OSError as e:
        sys.stderr.write(f'Could not read exclude file: {e}\n'); sys.exit(2)
    return ex

def line_col(src, pos):
    line=src.count('\n',0,pos)+1
    last=src.rfind('\n',0,pos)
    return line, pos-last

def is_assignment_statement(line):
    return bool(re.search(r'(^|[^=!<>:])(:=|=)($|[^=])', line))

def stmt_start_col(raw, needle_start):
    return needle_start + 1

def check_file(path, pkg, pkg_funcs, all_funcs, ns, excludes, ignore_res):
    src=Path(path).read_text(errors='replace')
    if ns.ignoregenerated and GENERATED_RE.search(src[:1000]): return []
    clean=strip_comments_preserve(src)
    imp=imports(src)
    out=[]
    lines=src.splitlines()
    clean_lines=clean.splitlines()
    for idx, (raw, cl) in enumerate(zip(lines, clean_lines), start=1):
        s=cl.strip()
        if not s or s.startswith(('package ','import ','func ','type ','var ','const ','return ')): continue
        # simple one-line statements only; this covers most tests and real examples.
        assignment=is_assignment_statement(cl)
        if ns.asserts and assignment and ASSERT_RE.search(cl):
            lhs=cl.split(':=',1)[0] if ':=' in cl else cl.split('=',1)[0]
            names=[x.strip() for x in split_top(lhs)]
            if names and (len(names)==1 and names[0]=='_' or (ns.blank and '_' in names)):
                col=cl.find('_')+1 if '_' in cl else max(1, cl.find('.')+1)
                out.append((idx,col,raw.strip(),''))
        for m in CALL_RE.finditer(cl):
            q=m.group(1)
            if q in {'if','for','switch','select','return','func','make','new','append','cap','len','copy','delete','panic','recover','print','println','complex','real','imag','close'}:
                continue
            if m.start()>0 and cl[m.start()-1] in '.': continue
            parts=q.split('.')
            fullpkg=''; fname=parts[-1]; returns=False
            if len(parts)==1:
                returns = fname in pkg_funcs
                fullpkg = pkg.get('ImportPath','')
            else:
                alias=parts[0]; path=imp.get(alias, alias)
                fullpkg=path
                if alias in imp or path in STD_ERROR_FUNCS or path in all_funcs:
                    returns = fname in all_funcs.get(path,set()) or fname in STD_ERROR_FUNCS.get(path,set())
                else:
                    returns = fname in {'Close','Write','WriteString','Read','ReadAt','WriteAt','Seek','Sync','Flush','Commit','Rollback','Scan','Decode','Encode','Err','Wait','Kill','Signal'}
            if not returns: continue
            if (fullpkg,fname) in excludes or (parts[0] if len(parts)>1 else fullpkg, fname) in excludes: continue
            if fullpkg in ignore_res and ignore_res[fullpkg].match(fname): continue
            if assignment:
                lhs=cl.split(':=',1)[0] if ':=' in cl else cl.split('=',1)[0]
                names=[x.strip() for x in split_top(lhs)]
                if '_' not in names or not ns.blank: continue
                col=cl.find('_')+1
            else:
                # defer/go report at function name, selector name for qualified calls
                start=m.start(1)
                if '.' in q: start += q.rfind('.')+1
                col=start+1
            out.append((idx,col,raw.strip(), fullpkg+'.'+fname if ns.verbose and fullpkg else ''))
    return out

def main(argv):
    ns=parse_args(argv)
    excludes = set() if ns.excludeonly else set(DEFAULT_EXCLUDES)
    excludes |= load_excludes(ns.exclude)
    ignore_res={}
    for p in [x for x in ns.ignorepkg.split(',') if x]: ignore_res[p]=re.compile('.*')
    for item in ns.ignore or []:
        for part in split_top(item):
            if not part: continue
            if ':' in part: pkg, rgx = part.split(':',1)
            else: pkg, rgx = '', part
            if pkg == 'fmt':
                excludes = {x for x in excludes if x[0] != 'fmt'}
            try: ignore_res[pkg]=re.compile(rgx)
            except re.error: pass
    pkgs=go_list(ns.packages, ns)
    all_funcs={}
    pkg_sources={}
    for pkg in pkgs:
        files=[]
        for key in ('GoFiles','CgoFiles'):
            files += [os.path.join(pkg['Dir'], f) for f in pkg.get(key,[])]
        if not ns.ignoretests:
            files += [os.path.join(pkg['Dir'], f) for f in pkg.get('TestGoFiles',[])]
        pkg_sources[pkg.get('ImportPath','')]=files
        fs=set()
        for f in files:
            try: fs |= scan_funcs(Path(f).read_text(errors='replace'))
            except OSError: pass
        all_funcs[pkg.get('ImportPath','')]=fs
    findings=[]
    for pkg in [p for p in pkgs if not p.get('DepOnly')]:
        ip=pkg.get('ImportPath','')
        if ns.verbose: print('checking '+ip)
        for f in pkg_sources.get(ip,[]):
            if ns.ignoretests and f.endswith('_test.go'): continue
            for line,col,text,extra in check_file(f,pkg,all_funcs.get(ip,set()),all_funcs,ns,excludes,ignore_res):
                if extra.startswith(ip + '.'):
                    extra = ''
                disp=os.path.abspath(f) if ns.abspath else os.path.relpath(f, os.getcwd())
                findings.append((disp,line,col,text,extra))
    for disp,line,col,text,extra in findings:
        if extra:
            print(f'{disp}:{line}:{col}:\t{extra}\t{text}')
        else:
            print(f'{disp}:{line}:{col}:\t{text}')
    return 1 if findings else 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
