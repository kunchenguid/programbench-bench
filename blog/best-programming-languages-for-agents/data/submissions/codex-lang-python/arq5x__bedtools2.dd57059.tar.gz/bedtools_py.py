#!/usr/bin/env python3
import gzip
import math
import os
import random
import statistics
import sys
from collections import Counter, defaultdict

VERSION = "bedtools v2.31.1"


class Rec:
    __slots__ = ("f", "chrom", "start", "end", "line")
    def __init__(self, fields, line=None):
        self.f = fields
        self.chrom = fields[0]
        self.start = int(fields[1])
        self.end = int(fields[2])
        self.line = line if line is not None else "\t".join(fields)
    def out(self):
        return "\t".join(self.f)


def die(msg, code=1):
    sys.stderr.write(str(msg).rstrip() + "\n")
    raise SystemExit(code)


def is_header(line):
    return line.startswith(("#", "track", "browser")) or not line.strip()


def open_text(path):
    if path in (None, "-", "stdin", "STDIN"):
        for line in sys.stdin:
            yield line
    elif path.endswith(".gz"):
        with gzip.open(path, "rt") as fh:
            yield from fh
    else:
        with open(path) as fh:
            yield from fh


def read_recs(path, keep_headers=False):
    headers, recs = [], []
    for line in open_text(path):
        line = line.rstrip("\n")
        if is_header(line):
            if keep_headers and line.strip():
                headers.append(line)
            continue
        fields = line.split("\t") if "\t" in line else line.split()
        if len(fields) < 3:
            continue
        try:
            recs.append(Rec(fields, line))
        except ValueError:
            if keep_headers:
                headers.append(line)
    return (headers, recs) if keep_headers else recs


def read_recs_h(path, keep_headers=False):
    headers, recs = read_recs(path, True)
    return (headers if keep_headers else []), recs


def read_genome(path):
    g = []
    for line in open_text(path):
        if is_header(line):
            continue
        p = line.split()
        if len(p) >= 2:
            g.append((p[0], int(p[1])))
    return g


def arg_value(args, name, default=None):
    if name in args:
        i = args.index(name)
        if i + 1 < len(args):
            return args[i + 1]
    return default


def has(args, name):
    return name in args


def collect_b(args):
    if "-b" not in args:
        die("***** ERROR: -b option given, but no database file specified. *****")
    i = args.index("-b") + 1
    out = []
    while i < len(args) and not args[i].startswith("-"):
        out.append(args[i])
        i += 1
    return out


def strand_ok(a, b, same=False, opp=False):
    if not (same or opp):
        return True
    if len(a.f) < 6 or len(b.f) < 6:
        return False
    return (a.f[5] == b.f[5]) if same else (a.f[5] != b.f[5])


def overlap_len(a, b):
    if a.chrom != b.chrom:
        return 0
    return max(0, min(a.end, b.end) - max(a.start, b.start))


def passes(a, b, ov, f=1e-9, F=1e-9, recip=False, either=False):
    if ov <= 0:
        return False
    af = ov / max(1, a.end - a.start)
    bf = ov / max(1, b.end - b.start)
    if either:
        return af >= f or bf >= F
    if recip:
        return af >= f and bf >= f
    return af >= f and bf >= F


def null_b(n=4):
    return [".", "-1", "-1"] + ["."] * max(0, n - 3)


def fmt_num(x, prec=5):
    try:
        fx = float(x)
    except Exception:
        return "."
    if fx.is_integer():
        return str(int(fx))
    return (("%." + str(prec) + "f") % fx).rstrip("0").rstrip(".")


def summarize(vals, op, delim=",", prec=5):
    vals = [v for v in vals if v != ""]
    nums = []
    for v in vals:
        try:
            nums.append(float(v))
        except Exception:
            pass
    if op == "count":
        return str(len(vals))
    if op == "count_distinct":
        return str(len(set(vals)))
    if op in ("collapse", "concat"):
        return ("" if op == "concat" else delim).join(vals)
    if op in ("distinct", "distinct_only"):
        seen = []
        for v in vals:
            if v not in seen:
                seen.append(v)
        if op == "distinct_only":
            c = Counter(vals)
            seen = [v for v in seen if c[v] == 1]
        return delim.join(seen)
    if op == "distinct_sort_num":
        return delim.join(fmt_num(x, prec) for x in sorted(set(nums)))
    if op == "distinct_sort_num_desc":
        return delim.join(fmt_num(x, prec) for x in sorted(set(nums), reverse=True))
    if op == "first":
        return vals[0] if vals else "."
    if op == "last":
        return vals[-1] if vals else "."
    if op in ("freqasc", "freqdesc"):
        items = list(Counter(vals).items())
        items.sort(key=lambda kv: (kv[1], kv[0]), reverse=(op == "freqdesc"))
        return delim.join(f"{k}:{v}" for k, v in items)
    if not nums:
        return "."
    if op == "sum":
        return fmt_num(sum(nums), prec)
    if op == "min":
        return fmt_num(min(nums), prec)
    if op == "max":
        return fmt_num(max(nums), prec)
    if op == "absmin":
        return fmt_num(min(nums, key=abs), prec)
    if op == "absmax":
        return fmt_num(max(nums, key=abs), prec)
    if op == "mean":
        return fmt_num(sum(nums) / len(nums), prec)
    if op == "median":
        return fmt_num(statistics.median(nums), prec)
    if op in ("stdev", "sstdev"):
        return fmt_num(statistics.stdev(nums) if len(nums) > 1 else 0, prec)
    if op == "mode":
        c = Counter(vals)
        m = max(c.values())
        return sorted([v for v, n in c.items() if n == m])[0]
    if op == "antimode":
        c = Counter(vals)
        m = min(c.values())
        return sorted([v for v, n in c.items() if n == m])[0]
    return summarize(vals, "sum", delim, prec)


def print_lines(lines):
    if lines:
        sys.stdout.write("\n".join(lines) + "\n")


def cmd_intersect(args):
    headers, A = read_recs_h(arg_value(args, "-a"), has(args, "-header"))
    bs = collect_b(args)
    Bsets = [read_recs(p) for p in bs]
    B = [(idx + 1, p, b) for idx, s in enumerate(Bsets) for p in [bs[idx]] for b in s]
    same, opp = has(args, "-s"), has(args, "-S")
    f = float(arg_value(args, "-f", "1e-9")); F = float(arg_value(args, "-F", "1e-9"))
    names = []
    if "-names" in args:
        j = args.index("-names") + 1
        while j < len(args) and not args[j].startswith("-"):
            names.append(args[j]); j += 1
    maxb = max([len(b.f) for _, _, b in B], default=4)
    out = headers[:]
    for a in A:
        hits = []
        for fileid, path, b in B:
            ov = overlap_len(a, b)
            if passes(a, b, ov, f, F, has(args, "-r"), has(args, "-e")) and strand_ok(a, b, same, opp):
                hits.append((fileid, path, b, ov))
        if has(args, "-sortout"):
            hits.sort(key=lambda x: (x[2].chrom, x[2].start, x[2].end))
        if has(args, "-c"):
            out.append(a.out() + "\t" + str(len(hits)))
        elif has(args, "-C"):
            for i in range(1, len(bs) + 1):
                out.append(a.out() + "\t" + str(i) + "\t" + str(sum(1 for h in hits if h[0] == i)))
        elif has(args, "-u"):
            if hits:
                out.append(a.out())
        elif has(args, "-v"):
            if not hits:
                out.append(a.out())
        elif has(args, "-loj") or has(args, "-wao"):
            if hits:
                for fid, path, b, ov in hits:
                    extra = []
                    if len(bs) > 1:
                        extra = [path if has(args, "-filenames") else (names[fid-1] if fid-1 < len(names) else str(fid))]
                    row = a.f + extra + b.f
                    if has(args, "-wao"):
                        row += [str(ov)]
                    out.append("\t".join(row))
            else:
                row = a.f + null_b(maxb)
                if has(args, "-wao"):
                    row += ["0"]
                out.append("\t".join(row))
        else:
            for fid, path, b, ov in hits:
                tag = []
                if len(bs) > 1 and (has(args, "-wb") or has(args, "-wo")):
                    tag = [path if has(args, "-filenames") else (names[fid-1] if fid-1 < len(names) else str(fid))]
                if has(args, "-wo"):
                    out.append("\t".join(a.f + tag + b.f + [str(ov)]))
                elif has(args, "-wa") and has(args, "-wb"):
                    out.append("\t".join(a.f + tag + b.f))
                elif has(args, "-wa"):
                    out.append(a.out())
                elif has(args, "-wb"):
                    clipped = [a.chrom, str(max(a.start, b.start)), str(min(a.end, b.end))] + a.f[3:]
                    out.append("\t".join(clipped + tag + b.f))
                else:
                    clipped = [a.chrom, str(max(a.start, b.start)), str(min(a.end, b.end))] + a.f[3:]
                    out.append("\t".join(clipped))
    print_lines(out)


def cmd_sort(args):
    headers, recs = read_recs_h(arg_value(args, "-i"), has(args, "-header"))
    order = {}
    gf = arg_value(args, "-g") or arg_value(args, "-faidx")
    if gf:
        order = {c: i for i, (c, _) in enumerate(read_genome(gf))}
    def chromkey(r):
        return order.get(r.chrom, len(order) + 1), r.chrom
    if has(args, "-sizeD"):
        key = lambda r: (-(r.end - r.start), chromkey(r), r.start)
    elif has(args, "-sizeA"):
        key = lambda r: (r.end - r.start, chromkey(r), r.start)
    elif has(args, "-chrThenSizeD"):
        key = lambda r: (chromkey(r), -(r.end - r.start), r.start)
    elif has(args, "-chrThenSizeA"):
        key = lambda r: (chromkey(r), r.end - r.start, r.start)
    elif has(args, "-chrThenScoreD"):
        key = lambda r: (chromkey(r), -float(r.f[4] if len(r.f) > 4 else 0))
    elif has(args, "-chrThenScoreA"):
        key = lambda r: (chromkey(r), float(r.f[4] if len(r.f) > 4 else 0))
    else:
        key = lambda r: (chromkey(r), r.start, r.end)
    print_lines(headers + [r.out() for r in sorted(recs, key=key)])


def op_lists(cols, ops):
    if len(cols) == 1 and len(ops) > 1:
        cols = cols * len(ops)
    elif len(ops) == 1 and len(cols) > 1:
        ops = ops * len(cols)
    return cols, ops


def cmd_merge(args):
    recs = read_recs(arg_value(args, "-i"))
    d = int(arg_value(args, "-d", "0"))
    same = has(args, "-s")
    force_strand = arg_value(args, "-S")
    cols = [int(x) for x in arg_value(args, "-c", "").split(",") if x]
    ops = [x for x in arg_value(args, "-o", "sum").split(",") if x]
    cols, ops = op_lists(cols, ops)
    delim = arg_value(args, "-delim", ",")
    prec = int(arg_value(args, "-prec", "5"))
    out = []
    cur = None; group = []
    def flush():
        if not group:
            return
        row = [cur[0], str(cur[1]), str(cur[2])]
        for c, o in zip(cols, ops):
            row.append(summarize([g.f[c-1] for g in group if len(g.f) >= c], o, delim, prec))
        out.append("\t".join(row))
    for r in recs:
        if force_strand and (len(r.f) < 6 or r.f[5] != force_strand):
            continue
        if cur is None:
            cur = [r.chrom, r.start, r.end, r.f[5] if len(r.f) > 5 else None]; group = [r]; continue
        compatible = r.chrom == cur[0] and r.start <= cur[2] + d
        if same:
            compatible = compatible and (len(r.f) > 5 and r.f[5] == cur[3])
        if compatible:
            cur[2] = max(cur[2], r.end); group.append(r)
        else:
            flush(); cur = [r.chrom, r.start, r.end, r.f[5] if len(r.f) > 5 else None]; group = [r]
    flush()
    print_lines(out)


def merged_intervals(recs):
    recs = sorted(recs, key=lambda r: (r.chrom, r.start, r.end))
    out = []
    for r in recs:
        if not out or r.chrom != out[-1][0] or r.start > out[-1][2]:
            out.append([r.chrom, r.start, r.end])
        else:
            out[-1][2] = max(out[-1][2], r.end)
    return out


def cmd_complement(args):
    recs = read_recs(arg_value(args, "-i"))
    genome = read_genome(arg_value(args, "-g"))
    by = defaultdict(list)
    for c, s, e in merged_intervals(recs):
        by[c].append((s, e))
    out = []
    only = set(by) if has(args, "-L") else None
    for c, size in genome:
        if only is not None and c not in only:
            continue
        pos = 0
        for s, e in by.get(c, []):
            if s > pos:
                out.append(f"{c}\t{pos}\t{s}")
            pos = max(pos, e)
        if pos < size:
            out.append(f"{c}\t{pos}\t{size}")
    print_lines(out)


def cmd_subtract(args):
    A = read_recs(arg_value(args, "-a")); B = read_recs(collect_b(args)[0])
    same, opp = has(args, "-s"), has(args, "-S")
    f = float(arg_value(args, "-f", "1e-9")); F = float(arg_value(args, "-F", "1e-9"))
    out = []
    for a in A:
        ovs = []
        hit_any = False
        for b in B:
            ov = overlap_len(a, b)
            if passes(a, b, ov, f, F, has(args, "-r"), has(args, "-e")) and strand_ok(a, b, same, opp):
                hit_any = True; ovs.append((max(a.start, b.start), min(a.end, b.end)))
        if (has(args, "-A") or has(args, "-N")) and hit_any:
            continue
        pieces = [(a.start, a.end)]
        for s, e in sorted(ovs):
            new = []
            for ps, pe in pieces:
                if e <= ps or s >= pe:
                    new.append((ps, pe))
                else:
                    if ps < s: new.append((ps, s))
                    if e < pe: new.append((e, pe))
            pieces = new
        for s, e in pieces:
            if s < e:
                out.append("\t".join([a.chrom, str(s), str(e)] + a.f[3:]))
    print_lines(out)


def dist(a, b):
    if a.chrom != b.chrom:
        return None
    if overlap_len(a, b) > 0:
        return 0
    if b.end <= a.start:
        return a.start - b.end + 1
    return b.start - a.end + 1


def cmd_closest(args):
    A = read_recs(arg_value(args, "-a")); B = [b for p in collect_b(args) for b in read_recs(p)]
    k = int(arg_value(args, "-k", "1")); tie = arg_value(args, "-t", "all")
    out = []
    maxb = max([len(b.f) for b in B], default=4)
    for a in A:
        cand = []
        for idx, b in enumerate(B):
            if has(args, "-N") and len(a.f) > 3 and len(b.f) > 3 and a.f[3] == b.f[3]:
                continue
            if has(args, "-s") and not strand_ok(a, b, True, False): continue
            if has(args, "-S") and not strand_ok(a, b, False, True): continue
            d = dist(a, b)
            if d is None: continue
            if has(args, "-io") and d == 0: continue
            cand.append((d, idx, b))
        if not cand:
            row = a.f + null_b(maxb)
            if has(args, "-d") or "-D" in args: row.append("-1")
            out.append("\t".join(row)); continue
        cand.sort(key=lambda x: (x[0], x[1]))
        chosen = []
        for d, idx, b in cand:
            if len(chosen) < k or (tie == "all" and d == chosen[-1][0]):
                chosen.append((d, idx, b))
            else:
                break
        if tie == "first" and chosen:
            chosen = [chosen[0]]
        elif tie == "last" and chosen:
            md = chosen[0][0]; same = [x for x in chosen if x[0] == md]; chosen = [same[-1]]
        for d, idx, b in chosen:
            row = a.f + b.f
            if has(args, "-d") or "-D" in args:
                row.append(str(d))
            out.append("\t".join(row))
    print_lines(out)


def cmd_window(args):
    A = read_recs(arg_value(args, "-a")); B = read_recs(arg_value(args, "-b"))
    w = int(arg_value(args, "-w", "1000"))
    l = int(arg_value(args, "-l", str(w))); r = int(arg_value(args, "-r", str(w)))
    out = []
    for a in A:
        ll, rr = l, r
        if has(args, "-sw") and len(a.f) > 5 and a.f[5] == "-":
            ll, rr = rr, ll
        fake = Rec([a.chrom, str(max(0, a.start - ll)), str(a.end + rr)])
        hits = [b for b in B if overlap_len(fake, b) > 0 and strand_ok(a, b, has(args, "-sm"), has(args, "-Sm"))]
        if has(args, "-c"):
            out.append(a.out() + "\t" + str(len(hits)))
        elif has(args, "-u"):
            if hits: out.append(a.out())
        elif has(args, "-v"):
            if not hits: out.append(a.out())
        else:
            out += ["\t".join(a.f + b.f) for b in hits]
    print_lines(out)


def coverage_array(a, B):
    cov = [0] * max(0, a.end - a.start)
    hit_count = 0
    for b in B:
        ov = overlap_len(a, b)
        if ov > 0:
            hit_count += 1
            for i in range(max(a.start, b.start) - a.start, min(a.end, b.end) - a.start):
                cov[i] += 1
    return hit_count, cov


def cmd_coverage(args):
    A = read_recs(arg_value(args, "-a")); B = [b for p in collect_b(args) for b in read_recs(p)]
    out = []
    for a in A:
        n, cov = coverage_array(a, B)
        size = max(0, a.end - a.start)
        if has(args, "-counts"):
            out.append(a.out() + "\t" + str(n))
        elif has(args, "-d"):
            for i, depth in enumerate(cov, 1):
                out.append(a.out() + f"\t{i}\t{depth}")
        elif has(args, "-hist"):
            c = Counter(cov)
            for dep in sorted(c):
                out.append(a.out() + f"\t{dep}\t{c[dep]}\t{size}\t{c[dep]/size if size else 0:.7f}")
        else:
            covered = sum(1 for x in cov if x > 0)
            out.append(a.out() + f"\t{n}\t{covered}\t{size}\t{covered/size if size else 0:.7f}")
    print_lines(out)


def genome_segments(recs, genome=None):
    events = defaultdict(list)
    for r in recs:
        events[r.chrom].append((r.start, 1)); events[r.chrom].append((r.end, -1))
    chroms = [c for c, _ in genome] if genome else sorted(events)
    sizes = dict(genome or [])
    for c in chroms:
        pts = sorted(events.get(c, []))
        pos = 0; depth = 0
        for p, delta in pts:
            if p > pos:
                yield c, pos, p, depth
            depth += delta; pos = p
        if c in sizes and pos < sizes[c]:
            yield c, pos, sizes[c], depth


def cmd_genomecov(args):
    recs = read_recs(arg_value(args, "-i") or arg_value(args, "-ibam"))
    genome = read_genome(arg_value(args, "-g")) if arg_value(args, "-g") else None
    segs = list(genome_segments(recs, genome))
    if has(args, "-bg") or has(args, "-bga"):
        print_lines([f"{c}\t{s}\t{e}\t{d}" for c, s, e, d in segs if has(args, "-bga") or d > 0])
    else:
        hist = defaultdict(Counter); total = Counter()
        sizes = dict(genome or [])
        for c, s, e, d in segs:
            hist[c][d] += e - s; total[d] += e - s
        out = []
        for c in sorted(hist):
            sz = sizes.get(c, sum(hist[c].values()))
            for d in sorted(hist[c]):
                out.append(f"{c}\t{d}\t{hist[c][d]}\t{sz}\t{hist[c][d]/sz if sz else 0:.7g}")
        gsz = sum(sizes.values()) if sizes else sum(total.values())
        for d in sorted(total):
            out.append(f"genome\t{d}\t{total[d]}\t{gsz}\t{total[d]/gsz if gsz else 0:.7g}")
        print_lines(out)


def cmd_map(args):
    A = read_recs(arg_value(args, "-a")); B = read_recs(arg_value(args, "-b"))
    cols = [int(x) for x in arg_value(args, "-c", "5").split(",")]; ops = arg_value(args, "-o", "sum").split(",")
    cols, ops = op_lists(cols, ops); null = arg_value(args, "-null", ".")
    out = []
    for a in A:
        hits = [b for b in B if overlap_len(a, b) > 0]
        row = a.f[:]
        for c, o in zip(cols, ops):
            vals = [b.f[c-1] for b in hits if len(b.f) >= c]
            row.append(summarize(vals, o) if vals else null)
        out.append("\t".join(row))
    print_lines(out)


def cmd_groupby(args):
    inp = arg_value(args, "-i")
    rows = []
    for line in open_text(inp):
        line = line.rstrip("\n")
        if line: rows.append(line.split("\t") if "\t" in line else line.split())
    gcols = [int(x) for x in (arg_value(args, "-g") or arg_value(args, "-grp") or "1").split(",")]
    cols = [int(x) for x in (arg_value(args, "-c") or arg_value(args, "-opCols") or "2").split(",")]
    ops = (arg_value(args, "-o") or arg_value(args, "-ops") or "sum").split(",")
    cols, ops = op_lists(cols, ops); delim = arg_value(args, "-delim", ",")
    groups = []
    last = None
    for r in rows:
        key = tuple(r[i-1] for i in gcols)
        if key != last:
            groups.append((key, [])); last = key
        groups[-1][1].append(r)
    out = []
    for key, rs in groups:
        row = list(key)
        for c, o in zip(cols, ops):
            row.append(summarize([r[c-1] for r in rs if len(r) >= c], o, delim))
        out.append("\t".join(row))
    print_lines(out)


def cmd_slop(args):
    recs = read_recs(arg_value(args, "-i")); sizes = dict(read_genome(arg_value(args, "-g")))
    b = arg_value(args, "-b")
    l = float(arg_value(args, "-l", b or "0")); r = float(arg_value(args, "-r", b or "0"))
    out = []
    for x in recs:
        ll, rr = l, r
        if has(args, "-pct"):
            ll *= x.end - x.start; rr *= x.end - x.start
        if has(args, "-s") and len(x.f) > 5 and x.f[5] == "-":
            ll, rr = rr, ll
        s = max(0, x.start - int(ll)); e = min(sizes.get(x.chrom, x.end + int(rr)), x.end + int(rr))
        out.append("\t".join([x.chrom, str(s), str(e)] + x.f[3:]))
    print_lines(out)


def cmd_flank(args):
    recs = read_recs(arg_value(args, "-i")); sizes = dict(read_genome(arg_value(args, "-g")))
    b = arg_value(args, "-b")
    l = float(arg_value(args, "-l", b or "0")); r = float(arg_value(args, "-r", b or "0"))
    out = []
    for x in recs:
        ll, rr = l, r
        if has(args, "-pct"):
            ll *= x.end - x.start; rr *= x.end - x.start
        if has(args, "-s") and len(x.f) > 5 and x.f[5] == "-":
            ll, rr = rr, ll
        size = sizes.get(x.chrom, x.end + int(rr))
        left = (max(0, x.start - int(ll)), x.start)
        right = (x.end, min(size, x.end + int(rr)))
        for s, e in (left, right):
            if s < e:
                out.append("\t".join([x.chrom, str(s), str(e)] + x.f[3:]))
    print_lines(out)


def cmd_makewindows(args):
    src = []
    if arg_value(args, "-g"):
        src = [Rec([c, "0", str(sz), c]) for c, sz in read_genome(arg_value(args, "-g"))]
    else:
        src = read_recs(arg_value(args, "-b"))
    w = arg_value(args, "-w"); n = arg_value(args, "-n"); step = int(arg_value(args, "-s", w or "0"))
    idmode = arg_value(args, "-i")
    out = []
    for r in src:
        wins = []
        if w:
            ww = int(w); pos = r.start
            while pos < r.end:
                wins.append((pos, min(r.end, pos + ww))); pos += step or ww
        else:
            nn = int(n); length = r.end - r.start
            for i in range(nn):
                s = r.start + (length * i) // nn
                e = r.start + (length * (i + 1)) // nn
                wins.append((s, e))
        nums = list(range(1, len(wins) + 1))
        if has(args, "-reverse"):
            nums = list(reversed(nums))
        for (s, e), num in zip(wins, nums):
            row = [r.chrom, str(s), str(e)]
            if idmode == "src":
                row.append(r.f[3] if len(r.f) > 3 else r.chrom)
            elif idmode == "winnum":
                row.append(str(num))
            elif idmode == "srcwinnum":
                row.append((r.f[3] if len(r.f) > 3 else r.chrom) + "_" + str(num))
            out.append("\t".join(row))
    print_lines(out)


def cmd_spacing(args):
    recs = read_recs(arg_value(args, "-i"))
    out = []; last = None
    for r in recs:
        gap = "."
        if last and last.chrom == r.chrom:
            gap = "-1" if r.start < last.end else str(r.start - last.end)
        out.append(r.out() + "\t" + gap)
        if last is None or r.chrom != last.chrom or r.end > last.end:
            last = r
    print_lines(out)


def read_fasta(path, full=False):
    seqs = {}; name = None; chunks = []
    for line in open_text(path):
        line = line.rstrip("\n")
        if line.startswith(">"):
            if name is not None: seqs[name] = "".join(chunks)
            name = line[1:] if full else line[1:].split()[0]; chunks = []
        else:
            chunks.append(line.strip())
    if name is not None: seqs[name] = "".join(chunks)
    return seqs


def rc(seq, rna=False):
    tab = str.maketrans("ACGTUacgtu", "UGCAAugcaa" if rna else "TGCAAtgcaa")
    return seq.translate(tab)[::-1]


def cmd_getfasta(args):
    fa = read_fasta(arg_value(args, "-fi"), has(args, "-fullHeader")); recs = read_recs(arg_value(args, "-bed"))
    out = []
    for r in recs:
        seq = fa.get(r.chrom, "")[r.start:r.end]
        if has(args, "-s") and len(r.f) > 5 and r.f[5] == "-": seq = rc(seq, has(args, "-rna"))
        name = f"{r.chrom}:{r.start}-{r.end}"
        if has(args, "-nameOnly") and len(r.f) > 3: name = r.f[3]
        elif (has(args, "-name") or has(args, "-name+")) and len(r.f) > 3: name = f"{r.f[3]}::{r.chrom}:{r.start}-{r.end}"
        if has(args, "-s") and len(r.f) > 5 and not has(args, "-tab") and not has(args, "-bedOut"):
            name += f"({r.f[5]})"
        if has(args, "-tab"):
            out.append(f"{name}\t{seq}")
        elif has(args, "-bedOut"):
            out.append(r.out() + "\t" + seq)
        else:
            out.append(">" + name); out.append(seq)
    fo = arg_value(args, "-fo")
    if fo:
        with open(fo, "w") as fh: fh.write("\n".join(out) + ("\n" if out else ""))
    else:
        print_lines(out)


def cmd_nuc(args):
    fa = read_fasta(arg_value(args, "-fi"), has(args, "-fullHeader")); recs = read_recs(arg_value(args, "-bed"))
    pat = arg_value(args, "-pattern")
    out = []
    for r in recs:
        seq = fa.get(r.chrom, "")[r.start:r.end]
        if has(args, "-s") and len(r.f) > 5 and r.f[5] == "-": seq = rc(seq)
        u = seq.upper(); L = len(seq)
        counts = {b: u.count(b) for b in "ACGTN"}
        other = L - sum(counts.values())
        row = r.f + [f"{(counts['A']+counts['T'])/L if L else 0:.6f}", f"{(counts['G']+counts['C'])/L if L else 0:.6f}",
                     str(counts["A"]), str(counts["C"]), str(counts["G"]), str(counts["T"]), str(counts["N"]), str(other), str(L)]
        if has(args, "-seq"): row.append(seq)
        if pat is not None:
            hay, needle = (u, pat.upper()) if has(args, "-C") else (seq, pat)
            row.append(str(sum(1 for i in range(0, len(hay)-len(needle)+1) if hay[i:i+len(needle)] == needle)))
        out.append("\t".join(row))
    print_lines(out)


def cmd_sample(args):
    recs = [line.rstrip("\n") for line in open_text(arg_value(args, "-i")) if line.rstrip("\n")]
    n = int(arg_value(args, "-n", "1000000"))
    seed = arg_value(args, "-seed")
    rng = random.Random(int(seed)) if seed is not None else random
    if n >= len(recs):
        chosen = recs
    else:
        chosen = rng.sample(recs, n)
    print_lines(chosen)


def cmd_random(args):
    genome = read_genome(arg_value(args, "-g"))
    n = int(arg_value(args, "-n", "1000000")); l = int(arg_value(args, "-l", "100"))
    rng = random.Random(int(arg_value(args, "-seed"))) if arg_value(args, "-seed") else random
    total = sum(sz for _, sz in genome)
    out = []
    for _ in range(n):
        x = rng.randrange(total); acc = 0
        for c, sz in genome:
            if x < acc + sz:
                start = rng.randrange(max(1, sz - l + 1)); out.append(f"{c}\t{start}\t{start+l}"); break
            acc += sz
    print_lines(out)


def cmd_shuffle(args):
    recs = read_recs(arg_value(args, "-i")); genome = read_genome(arg_value(args, "-g")); sizes = dict(genome)
    rng = random.Random(int(arg_value(args, "-seed"))) if arg_value(args, "-seed") else random
    total = sum(sz for _, sz in genome); out = []
    for r in recs:
        length = r.end - r.start
        if has(args, "-chrom"):
            c = r.chrom; sz = sizes[c]
        else:
            x = rng.randrange(total); acc = 0; c = genome[0][0]; sz = genome[0][1]
            for cc, ss in genome:
                if x < acc + ss: c, sz = cc, ss; break
                acc += ss
        start = rng.randrange(max(1, sz - length + 1)); out.append("\t".join([c, str(start), str(start + length)] + r.f[3:]))
    print_lines(out)


def cmd_cluster(args):
    recs = read_recs(arg_value(args, "-i"))
    d = int(arg_value(args, "-d", "0"))
    same = has(args, "-s")
    out = []
    cid = 0
    cur_chrom = None; cur_end = -1; cur_strand = None
    for r in recs:
        st = r.f[5] if len(r.f) > 5 else None
        new = (r.chrom != cur_chrom) or (r.start > cur_end + d) or (same and st != cur_strand)
        if new:
            cid += 1; cur_chrom = r.chrom; cur_end = r.end; cur_strand = st
        else:
            cur_end = max(cur_end, r.end)
        out.append(r.out() + "\t" + str(cid))
    print_lines(out)


def bases_covered(triples):
    return sum(e - s for _, s, e in triples)


def cmd_jaccard(args):
    A = merged_intervals(read_recs(arg_value(args, "-a")))
    B = merged_intervals(read_recs(arg_value(args, "-b")))
    inter = 0; nint = 0
    byb = defaultdict(list)
    for c, s, e in B:
        byb[c].append((s, e))
    pieces = []
    for c, s, e in A:
        for bs, be in byb.get(c, []):
            ov = max(0, min(e, be) - max(s, bs))
            if ov:
                inter += ov; nint += 1; pieces.append([c, max(s, bs), min(e, be)])
    # Merge intersection pieces so multiply-covered bases are counted once.
    inter = bases_covered(merged_intervals([Rec([c, str(s), str(e)]) for c, s, e in pieces]))
    union = bases_covered(A) + bases_covered(B) - inter
    jac = inter / union if union else 0
    print("intersection\tunion\tjaccard\tn_intersections")
    print(f"{inter}\t{union}\t{jac:.6g}\t{nint}")


def cmd_shift(args):
    recs = read_recs(arg_value(args, "-i")); sizes = dict(read_genome(arg_value(args, "-g")))
    both = arg_value(args, "-s")
    plus = int(arg_value(args, "-p", both or "0")); minus = int(arg_value(args, "-m", both or str(plus)))
    out = []
    for r in recs:
        sh = minus if len(r.f) > 5 and r.f[5] == "-" else plus
        s = max(0, r.start + sh); e = max(0, r.end + sh)
        if r.chrom in sizes:
            e = min(sizes[r.chrom], e); s = min(s, e)
        out.append("\t".join([r.chrom, str(s), str(e)] + r.f[3:]))
    print_lines(out)


def cmd_expand(args):
    recs = read_recs(arg_value(args, "-i"))
    c = int(arg_value(args, "-c", "4"))
    delim = arg_value(args, "-delim", ",")
    out = []
    for r in recs:
        if len(r.f) < c:
            out.append(r.out()); continue
        for val in r.f[c-1].split(delim):
            row = r.f[:]; row[c-1] = val; out.append("\t".join(row))
    print_lines(out)


def cmd_bed12tobed6(args):
    recs = read_recs(arg_value(args, "-i"))
    out = []
    for r in recs:
        if len(r.f) < 12:
            continue
        sizes = [int(x) for x in r.f[10].rstrip(",").split(",") if x != ""]
        starts = [int(x) for x in r.f[11].rstrip(",").split(",") if x != ""]
        for i, (bs, rel) in enumerate(zip(sizes, starts), 1):
            s = r.start + rel; e = s + bs
            name = r.f[3] if len(r.f) > 3 else "."
            score = r.f[4] if len(r.f) > 4 else "."
            strand = r.f[5] if len(r.f) > 5 else "."
            out.append("\t".join([r.chrom, str(s), str(e), name, score, strand]))
    print_lines(out)


def help_main():
    sys.stdout.write("""bedtools is a powerful toolset for genome arithmetic.

Version:   b2e3657
Usage:     bedtools <subcommand> [options]

The bedtools sub-commands include:
    intersect window closest coverage map genomecov merge cluster complement
    shift subtract slop flank sort random shuffle sample spacing annotate
    multiinter unionbedg getfasta maskfasta nuc makewindows groupby
""")


CMDS = {
    "intersect": cmd_intersect, "intersectBed": cmd_intersect,
    "sort": cmd_sort, "sortBed": cmd_sort,
    "merge": cmd_merge, "mergeBed": cmd_merge,
    "complement": cmd_complement, "complementBed": cmd_complement,
    "subtract": cmd_subtract, "subtractBed": cmd_subtract,
    "closest": cmd_closest, "closestBed": cmd_closest,
    "window": cmd_window, "windowBed": cmd_window,
    "coverage": cmd_coverage, "coverageBed": cmd_coverage,
    "genomecov": cmd_genomecov, "genomeCoverageBed": cmd_genomecov,
    "map": cmd_map, "mapBed": cmd_map,
    "groupby": cmd_groupby, "groupBy": cmd_groupby,
    "slop": cmd_slop, "slopBed": cmd_slop,
    "flank": cmd_flank, "flankBed": cmd_flank,
    "makewindows": cmd_makewindows, "makeWindows": cmd_makewindows,
    "spacing": cmd_spacing,
    "getfasta": cmd_getfasta, "fastaFromBed": cmd_getfasta,
    "nuc": cmd_nuc, "nucBed": cmd_nuc,
    "sample": cmd_sample, "random": cmd_random, "shuffle": cmd_shuffle,
    "cluster": cmd_cluster, "clusterBed": cmd_cluster,
    "jaccard": cmd_jaccard,
    "shift": cmd_shift, "shiftBed": cmd_shift,
    "expand": cmd_expand,
    "bed12tobed6": cmd_bed12tobed6,
}


def main(argv):
    prog = os.path.basename(argv[0])
    args = argv[1:]
    if prog in CMDS:
        return CMDS[prog](args)
    if not args or args[0] in ("--help", "-h", "help"):
        help_main(); return
    if args[0] == "--version":
        print(VERSION); return
    if args[0] == "--contact":
        print("Please see https://github.com/arq5x/bedtools2 for support."); return
    cmd = args[0]
    if cmd in CMDS:
        if "-h" in args[1:] or "--help" in args[1:]:
            print(f"Tool:    bedtools {cmd}\nSummary: Python reimplementation for BED text operations.\n")
            return
        return CMDS[cmd](args[1:])
    die(f"error: unrecognized command: {cmd}")


if __name__ == "__main__":
    main(sys.argv)
