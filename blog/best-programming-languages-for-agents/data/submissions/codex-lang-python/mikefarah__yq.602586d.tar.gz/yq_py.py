#!/usr/bin/env python3
import argparse
import base64
import copy
import csv
import io
import json
import os
import re
import sys
import urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml


VERSION = "yq (https://github.com/mikefarah/yq/) version v4.52.5"


HELP = """yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) 
See https://mikefarah.gitbook.io/yq/ for detailed documentation and examples.

Usage:
  yq [flags]
  yq [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  eval        (default) Apply the expression to each document in each yaml file in sequence
  eval-all    Loads _all_ yaml documents of _all_ yaml files and runs expression once
  help        Help about any command

Flags:
  -C, --colors                            force print with colors
  -e, --exit-status                       set exit status if there are no matches or null or false is returned
      --expression string                 forcibly set the expression argument. Useful when yq argument detection thinks your expression is a file.
      --from-file string                  Load expression from specified file.
  -h, --help                              help for yq
  -I, --indent int                        sets indent level for output (default 2)
  -i, --inplace                           update the file in place of first file given.
  -p, --input-format string               parse format for input. (default "auto")
  -M, --no-colors                         force print with no colors
  -N, --no-doc                            Don't print document separators (---)
  -0, --nul-output                        Use NUL char to separate values.
  -n, --null-input                        Don't read input, simply evaluate the expression given.
  -o, --output-format string              output format type. (default "auto")
  -P, --prettyPrint                       pretty print
  -r, --unwrapScalar                      unwrap scalar (default true)
  -v, --verbose                           verbose mode
  -V, --version                           Print version information and quit
"""


class Dumper(yaml.SafeDumper):
    def increase_indent(self, flow=False, indentless=False):
        return super().increase_indent(flow, False)


def str_representer(dumper, data):
    # yq quotes strings that would otherwise be ambiguous YAML scalars.
    if data == "" or data.lower() in {"null", "true", "false", "yes", "no", "on", "off"}:
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style='"')
    if re.fullmatch(r"[-+]?\d+(\.\d+)?", data):
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style='"')
    return dumper.represent_scalar("tag:yaml.org,2002:str", data)


Dumper.add_representer(str, str_representer)


def norm_fmt(fmt):
    aliases = {
        None: "auto", "a": "auto", "y": "yaml", "ky": "yaml", "kyaml": "yaml",
        "j": "json", "p": "props", "properties": "props", "c": "csv", "t": "tsv",
        "x": "xml", "h": "hcl", "l": "lua", "i": "ini", "s": "shell",
    }
    return aliases.get(fmt, fmt)


def detect_fmt(path, explicit="auto"):
    explicit = norm_fmt(explicit)
    if explicit != "auto":
        return explicit
    if not path or path == "-":
        return "yaml"
    ext = Path(path).suffix.lower()
    return {
        ".json": "json", ".yaml": "yaml", ".yml": "yaml", ".xml": "xml",
        ".csv": "csv", ".tsv": "tsv", ".properties": "props", ".props": "props",
        ".toml": "toml", ".ini": "ini",
    }.get(ext, "yaml")


def scalar_from_string(s):
    t = s.strip()
    if t == "":
        return ""
    try:
        return yaml.safe_load(t)
    except Exception:
        return s


def parse_props(text):
    root = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("!"):
            continue
        if "=" in line:
            k, v = line.split("=", 1)
        elif ":" in line:
            k, v = line.split(":", 1)
        else:
            k, v = line, ""
        cur = root
        parts = [p.strip() for p in k.strip().split(".") if p.strip()]
        for p in parts[:-1]:
            cur = cur.setdefault(p, {})
        if parts:
            cur[parts[-1]] = v.strip()
    return root


def elem_to_obj(elem):
    children = list(elem)
    attrs = {"+@" + k: v for k, v in elem.attrib.items()}
    text = (elem.text or "").strip()
    if children:
        obj = {}
        for child in children:
            val = elem_to_obj(child)
            if child.tag in obj:
                if not isinstance(obj[child.tag], list):
                    obj[child.tag] = [obj[child.tag]]
                obj[child.tag].append(val)
            else:
                obj[child.tag] = val
        if text:
            obj["+content"] = text
        obj.update(attrs)
        return obj
    if attrs:
        if text:
            attrs["+content"] = text
        return attrs
    return text


def parse_data(text, fmt):
    fmt = norm_fmt(fmt)
    if fmt == "json":
        return json.loads(text) if text.strip() else None
    if fmt in {"yaml", "auto"}:
        return yaml.safe_load(text) if text.strip() else None
    if fmt == "csv" or fmt == "tsv":
        dialect = "excel-tab" if fmt == "tsv" else "excel"
        return [dict(row) for row in csv.DictReader(io.StringIO(text), dialect=dialect)]
    if fmt == "props" or fmt == "ini":
        return parse_props(text)
    if fmt == "xml":
        root = ET.fromstring(text)
        return {root.tag: elem_to_obj(root)}
    if fmt == "base64":
        return base64.b64decode(text.strip()).decode()
    if fmt == "uri":
        return urllib.parse.unquote(text)
    return yaml.safe_load(text) if text.strip() else None


def read_input(path, fmt):
    text = sys.stdin.read() if path == "-" else Path(path).read_text()
    return parse_data(text, fmt)


def read_documents(path, fmt):
    text = sys.stdin.read() if path == "-" else Path(path).read_text()
    if norm_fmt(fmt) in {"yaml", "auto"}:
        docs = list(yaml.safe_load_all(text))
        return docs if docs else [None]
    return [parse_data(text, fmt)]


def split_path(path):
    if path in {"", "."}:
        return []
    if path.startswith("."):
        path = path[1:]
    out, i = [], 0
    token = ""
    while i < len(path):
        c = path[i]
        if c == ".":
            if token:
                out.append(token); token = ""
            i += 1
        elif c == "[":
            if token:
                out.append(token); token = ""
            j = path.find("]", i)
            inner = path[i + 1:j]
            if inner == "":
                out.append("*")
            elif inner.startswith('"') or inner.startswith("'"):
                out.append(inner[1:-1])
            else:
                out.append(int(inner))
            i = j + 1
        else:
            token += c; i += 1
    if token:
        out.append(token)
    return out


def get_path(data, parts):
    cur = data
    for p in parts:
        if p == "*":
            if isinstance(cur, list):
                return cur
            if isinstance(cur, dict):
                return list(cur.values())
            return []
        if isinstance(p, int):
            if not isinstance(cur, list) or p >= len(cur):
                return None
            cur = cur[p]
        else:
            if not isinstance(cur, dict) or p not in cur:
                return None
            cur = cur[p]
    return cur


def ensure_container(parent, key, next_key):
    val = [] if isinstance(next_key, int) else {}
    if isinstance(parent, list):
        while len(parent) <= key:
            parent.append(None)
        if parent[key] is None:
            parent[key] = val
        return parent[key]
    if key not in parent or parent[key] is None:
        parent[key] = val
    return parent[key]


def set_path(data, parts, value):
    if data is None:
        data = [] if parts and isinstance(parts[0], int) else {}
    cur = data
    for i, p in enumerate(parts):
        last = i == len(parts) - 1
        if last:
            if isinstance(cur, list):
                while len(cur) <= p:
                    cur.append(None)
                cur[p] = value
            else:
                cur[p] = value
        else:
            cur = ensure_container(cur, p, parts[i + 1])
    return data


def deep_merge(a, b):
    if isinstance(a, dict) and isinstance(b, dict):
        res = copy.deepcopy(a)
        for k, v in b.items():
            res[k] = deep_merge(res[k], v) if k in res else copy.deepcopy(v)
        return res
    return copy.deepcopy(b)


def parse_literal(s):
    s = s.strip()
    m = re.fullmatch(r"strenv\(([^)]+)\)", s)
    if m:
        return os.environ.get(m.group(1), "")
    m = re.fullmatch(r"env\(([^)]+)\)", s)
    if m:
        return scalar_from_string(os.environ.get(m.group(1), ""))
    if s.startswith('"') and s.endswith('"') or s.startswith("'") and s.endswith("'"):
        return s[1:-1]
    if s == "{}":
        return {}
    if s == "[]":
        return []
    if s == "null":
        return None
    if s == "true":
        return True
    if s == "false":
        return False
    try:
        return json.loads(s)
    except Exception:
        return s


def eval_path_or_value(expr, data, ctx=None):
    expr = expr.strip()
    if expr in {"", "."}:
        return data
    if expr in {"fileIndex", "fi"} and ctx:
        return ctx.get("fileIndex", 0)
    if expr == "keys":
        return list(data.keys()) if isinstance(data, dict) else list(range(len(data))) if isinstance(data, list) else []
    if expr == "length":
        return len(data) if isinstance(data, (dict, list, str)) else 0
    if expr == "type":
        if isinstance(data, dict): return "!!map"
        if isinstance(data, list): return "!!seq"
        if isinstance(data, str): return "!!str"
        if isinstance(data, bool): return "!!bool"
        if isinstance(data, int): return "!!int"
        if isinstance(data, float): return "!!float"
        if data is None: return "!!null"
    m = re.fullmatch(r"has\([\"'](.+)[\"']\)", expr)
    if m:
        key = m.group(1)
        return key in data if isinstance(data, dict) else False
    m = re.fullmatch(r"load\([\"'](.+)[\"']\)", expr)
    if m:
        path = m.group(1)
        return read_input(path, detect_fmt(path))
    if expr.startswith("."):
        return get_path(data, split_path(expr))
    return parse_literal(expr)


def eval_select(expr, items, ctxs=None):
    m = re.fullmatch(r"select\((.+?)\s*==\s*(.+?)\)", expr.strip())
    if not m:
        return items
    left, right = m.group(1).strip(), parse_literal(m.group(2).strip())
    out, outctx = [], []
    for i, item in enumerate(items):
        ctx = (ctxs or [{}])[i] if ctxs else {}
        if eval_path_or_value(left, item, ctx) == right:
            out.append(item); outctx.append(ctx)
    return out if ctxs is None else (out, outctx)


def eval_expr(expr, data, all_mode=False, ctxs=None):
    expr = expr.strip()
    if expr == "":
        return data
    if "|" in expr and not expr.startswith("["):
        vals = data if isinstance(data, list) and all_mode else [data]
        cur_ctxs = ctxs or [{} for _ in vals]
        for part in [p.strip() for p in expr.split("|")]:
            if part.startswith("select("):
                vals, cur_ctxs = eval_select(part, vals, cur_ctxs)
            else:
                next_vals, next_ctxs = [], []
                for i, v in enumerate(vals):
                    got = eval_expr(part, v, False, [cur_ctxs[i]])
                    if part.endswith("[]") and isinstance(got, list):
                        next_vals.extend(got)
                        next_ctxs.extend([cur_ctxs[i]] * len(got))
                    else:
                        next_vals.append(got)
                        next_ctxs.append(cur_ctxs[i])
                vals, cur_ctxs = next_vals, next_ctxs
        return vals if len(vals) != 1 or all_mode else vals[0]
    m = re.fullmatch(r"\[(.+)\]", expr, re.S)
    if m:
        val = eval_expr(m.group(1), data, all_mode, ctxs)
        return val if isinstance(val, list) else [val]
    m = re.fullmatch(r"(.+?)\s*=\s*(.+)", expr, re.S)
    if m and m.group(1).strip().startswith("."):
        new = copy.deepcopy(data)
        return set_path(new, split_path(m.group(1).strip()), eval_path_or_value(m.group(2), data))
    m = re.fullmatch(r"\.\s+as\s+\$\w+\s+ireduce\s+\(\{\};\s*\.\s*\*\s*\$\w+\s*\)", expr, re.S)
    if m and isinstance(data, list):
        res = {}
        for item in data:
            res = deep_merge(res, item)
        return res
    m = re.fullmatch(r"(.+?)\s*\*\s*(.+)", expr, re.S)
    if m:
        left = eval_expr(m.group(1), data, all_mode, ctxs)
        right = eval_expr(m.group(2), data, all_mode, ctxs)
        if isinstance(left, list) and len(left) == 1:
            left = left[0]
        if isinstance(right, list) and len(right) == 1:
            right = right[0]
        return deep_merge(left, right)
    if expr.endswith("[]") and expr.startswith("."):
        val = get_path(data, split_path(expr[:-2]))
        return val if isinstance(val, list) else []
    if expr.startswith("select("):
        vals = data if isinstance(data, list) else [data]
        if ctxs:
            selected, _ = eval_select(expr, vals, ctxs)
            return selected
        return eval_select(expr, vals)
    return eval_path_or_value(expr, data, (ctxs or [{}])[0] if ctxs else None)


def flatten_props(data, prefix=""):
    rows = []
    if isinstance(data, dict):
        for k, v in data.items():
            rows.extend(flatten_props(v, f"{prefix}.{k}" if prefix else str(k)))
    elif isinstance(data, list):
        for i, v in enumerate(data):
            rows.extend(flatten_props(v, f"{prefix}.{i}" if prefix else str(i)))
    else:
        rows.append((prefix, "" if data is None else str(data).lower() if isinstance(data, bool) else str(data)))
    return rows


def to_xml_node(name, data):
    elem = ET.Element(name)
    if isinstance(data, dict):
        text = data.get("+content")
        for k, v in data.items():
            if k.startswith("+@"):
                elem.set(k[2:], str(v))
        for k, v in data.items():
            if k.startswith("+@") or k == "+content":
                continue
            if isinstance(v, list):
                for item in v:
                    elem.append(to_xml_node(k, item))
            else:
                elem.append(to_xml_node(k, v))
        if text is not None:
            elem.text = str(text)
    else:
        elem.text = "" if data is None else str(data)
    return elem


def emit_one(obj, fmt, unwrap=True, indent=2, nul=False):
    sep = "\0" if nul else "\n"
    if fmt == "json":
        return json.dumps(obj, indent=indent, ensure_ascii=False) + sep
    if fmt == "csv" or fmt == "tsv":
        if not isinstance(obj, list):
            obj = [obj]
        keys = []
        for row in obj:
            if isinstance(row, dict):
                for k in row:
                    if k not in keys:
                        keys.append(k)
        out = io.StringIO()
        writer = csv.DictWriter(out, fieldnames=keys, dialect="excel-tab" if fmt == "tsv" else "excel", lineterminator="\n")
        writer.writeheader()
        for row in obj:
            writer.writerow(row if isinstance(row, dict) else {"value": row})
        return out.getvalue()
    if fmt == "props":
        return "".join(f"{k} = {v}\n" for k, v in flatten_props(obj))
    if fmt == "shell":
        return "".join(f"{re.sub('[^A-Za-z0-9_]', '_', k)}={json.dumps(v)}\n" for k, v in flatten_props(obj))
    if fmt == "xml":
        if isinstance(obj, dict) and len(obj) == 1:
            k, v = next(iter(obj.items()))
            return ET.tostring(to_xml_node(k, v), encoding="unicode") + sep
        return ET.tostring(to_xml_node("root", obj), encoding="unicode") + sep
    if fmt == "base64":
        return base64.b64encode(str(obj).encode()).decode() + sep
    if fmt == "uri":
        return urllib.parse.quote(str(obj)) + sep
    if unwrap and not isinstance(obj, (dict, list)):
        if obj is None:
            return "null" + sep
        if isinstance(obj, bool):
            return ("true" if obj else "false") + sep
        return str(obj) + sep
    return yaml.dump(obj, Dumper=Dumper, default_flow_style=False, sort_keys=False, indent=indent, allow_unicode=True)


def choose_output_fmt(outfmt, infmt, first_file, stdin_used):
    outfmt = norm_fmt(outfmt)
    if outfmt != "auto":
        return outfmt
    if first_file and first_file != "-" and not stdin_used:
        return detect_fmt(first_file)
    return "yaml"


def parse_args(argv):
    cmd = "eval"
    if argv and argv[0] in {"eval", "e", "eval-all", "ea"}:
        cmd = "eval-all" if argv[0] in {"eval-all", "ea"} else "eval"
        argv = argv[1:]
    if argv and argv[0] == "help":
        print(HELP); sys.exit(0)
    if argv and argv[0] == "completion":
        print("# completion is not implemented by this reimplementation"); sys.exit(0)
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("-n", "--null-input", action="store_true")
    p.add_argument("-i", "--inplace", action="store_true")
    p.add_argument("-e", "--exit-status", action="store_true")
    p.add_argument("-P", "--prettyPrint", action="store_true")
    p.add_argument("-r", "--unwrapScalar", action="store_true", default=True)
    p.add_argument("-N", "--no-doc", action="store_true")
    p.add_argument("-0", "--nul-output", action="store_true")
    p.add_argument("-I", "--indent", type=int, default=2)
    p.add_argument("-p", "--input-format", default="auto")
    p.add_argument("-o", "--output-format", default="auto")
    p.add_argument("--expression")
    p.add_argument("--from-file")
    p.add_argument("rest", nargs="*")
    ns, _ = p.parse_known_args(argv)
    ns.cmd = cmd
    return ns


def main(argv=None):
    ns = parse_args(argv or sys.argv[1:])
    if ns.help:
        print(HELP); return 0
    if ns.version:
        print(VERSION); return 0
    expr = ns.expression
    if ns.from_file:
        expr = Path(ns.from_file).read_text()
    rest = list(ns.rest)
    if expr is None:
        if ns.null_input and rest:
            expr = rest.pop(0)
        elif rest and (rest[0].startswith(".") or rest[0].startswith("[") or "=" in rest[0] or rest[0].startswith("select") or "load(" in rest[0] or rest[0] in {"keys", "length", "type", "true", "false", "null"}):
            expr = rest.pop(0)
        else:
            expr = "."
    files = rest
    if ns.null_input:
        docs, ctxs = [None], [{"fileIndex": 0}]
        first_file = None
    else:
        if not files:
            files = ["-"]
        docs, ctxs = [], []
        for idx, f in enumerate(files):
            for doc in read_documents(f, detect_fmt(f, ns.input_format)):
                docs.append(doc); ctxs.append({"fileIndex": idx})
        first_file = files[0] if files else None
    if ns.cmd == "eval-all":
        result = eval_expr(expr, docs, True, ctxs)
        results = result if isinstance(result, list) and expr.startswith("select(") else [result]
    else:
        results = [eval_expr(expr, doc, False, [ctxs[i]]) for i, doc in enumerate(docs)]
    outfmt = choose_output_fmt(ns.output_format, ns.input_format, first_file, first_file == "-")
    if ns.inplace:
        if not first_file or first_file == "-":
            print("Error: write in place flag only applicable when giving an expression and at least one file", file=sys.stderr)
            return 1
        Path(first_file).write_text("".join(emit_one(r, detect_fmt(first_file), ns.unwrapScalar, ns.indent, False) for r in results))
        return 0
    output = "".join(emit_one(r, outfmt, ns.unwrapScalar and outfmt == "yaml", ns.indent, ns.nul_output) for r in results)
    sys.stdout.write(output)
    if ns.exit_status and (not results or any(r is None or r is False for r in results)):
        print("Error: no matches found", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
