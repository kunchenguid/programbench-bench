#!/usr/bin/env python3
import os
import random
import select
import shutil
import sys
import termios
import time
import tty


HELP = """Usage: executable [OPTIONS]

Options:
  -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]
  -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]
  -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]
  -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]
  -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]
  -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]
      --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
      --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
      --show-ortho        show keyboard in ortholinear format
      --nokb              pass this flag to disable the keyboard layout display.
      --cat               the most important flag. don't practice alone.
  -h, --help              Print help
"""

USAGE = "Usage: executable [OPTIONS]"
BOOL_FLAGS = {"--show-ortho": "show-ortho", "--nokb": "nokb", "--cat": "cat"}
VALUE_FLAGS = {
    "-n": ("n", "<2|3|4|w|file>"),
    "--n": ("n", "<2|3|4|w|file>"),
    "-t": ("top", "<1-200>"),
    "--top": ("top", "<1-200>"),
    "-c": ("combi", "<1-200>"),
    "--combi": ("combi", "<1-200>"),
    "-r": ("rep", "<number>"),
    "--rep": ("rep", "<number>"),
    "-w": ("wpm", "<number>"),
    "--wpm": ("wpm", "<number>"),
    "-a": ("acc", "<0-100>"),
    "--acc": ("acc", "<0-100>"),
    "--emu-in": ("emu_in", "<layout>"),
    "--emu-out": ("emu_out", "<layout>"),
}
CANONICAL_FLAG = {
    "-n": "--n",
    "-t": "--top",
    "-c": "--combi",
    "-r": "--rep",
    "-w": "--wpm",
    "-a": "--acc",
}

BIGRAMS = (
    "th he in er an re on at en nd ti es or te of ed is it al ar st to nt ng se ha as ou io le ve co me de hi ri ro ic ne ea ra ce li ch ll be ma si om ur ca el ta la ns di fo ho pe ec pr no ct us ac ot il tr ly nc et ut ss so rs un lo wa ge ie wh ee wi em ad ol rt po we na ul ni ts mo ow pa im mi ai sh ir su id os iv ia am fi ci vi pl ig tu ev ld ry mp fe bl ab gh"
).split()
TRIGRAMS = (
    "the and ing ion tio ent ati for her ter tha ere ate his con res ver all ons nce men ith ted ers pro thi wit are ess not ive was ect rea com eve per int est sta cti ica ist ear ain one our iti rat"
).split()
TETRAGRAMS = (
    "tion ther that with ment ions this here from ould ight have hich whic thes thin they atio ever ough were hing ance inte ound ting ence tive over ding pres nter comp able"
).split()
WORDS = (
    "the of and to in a is that for it as was with be by on not he i this are or his from at which but have an had they you were their one all we can her has there been if more when will would who so no"
).split()

LAYOUTS = {
    "qwerty": ("qwertyuiop", "asdfghjkl", "zxcvbnm"),
    "qwertz": ("qwertzuiop", "asdfghjkl", "yxcvbnm"),
    "azerty": ("azertyuiop", "qsdfghjklm", "wxcvbn"),
    "dvorak": ("',.pyfgcrl", "aoeuidhtns", ";qjkxbmwvz"),
    "colemak": ("qwfpgjluy", "arstdhneio", "zxcvbkm"),
    "colemakdh": ("qwfpbjluy", "arstgmneio", "zxcdvkh"),
}


class CliError(Exception):
    def __init__(self, msg, code=2, stdout=False):
        super().__init__(msg)
        self.code = code
        self.stdout = stdout


def clap_error(msg, usage=True):
    text = f"error: {msg}\n\n"
    if usage:
        text += f"{USAGE}\n\n"
    text += "For more information, try '--help'."
    raise CliError(text, 2)


def parse_int(flag, display, value):
    if value.startswith("-"):
        clap_error(f"unexpected argument '{value}' found")
    shown = CANONICAL_FLAG.get(flag, flag)
    try:
        return int(value, 10)
    except ValueError:
        raise CliError(
            f"error: invalid value '{value}' for '{shown} {display}': invalid digit found in string\n\n"
            "For more information, try '--help'.",
            2,
        )


def take_value(argv, i, flag, display):
    if i + 1 >= len(argv):
        shown = CANONICAL_FLAG.get(flag, flag)
        raise CliError(
            f"error: a value is required for '{shown} {display}' but none was supplied\n\n"
            "For more information, try '--help'.",
            2,
        )
    return argv[i + 1], i + 2


def parse_args(argv):
    if "-h" in argv or "--help" in argv:
        print(HELP, end="")
        raise SystemExit(0)

    cfg = {
        "n": "2",
        "top": 50,
        "combi": 2,
        "rep": 3,
        "wpm": 40,
        "acc": 94,
        "emu_in": "",
        "emu_out": "",
        "show-ortho": False,
        "nokb": False,
        "cat": False,
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg.startswith("--") and "=" in arg:
            flag, value = arg.split("=", 1)
            if flag in BOOL_FLAGS:
                raise CliError(
                    f"error: unexpected value '{value}' for '{flag}' found; no more were expected\n\n"
                    f"Usage: executable {flag}\n\nFor more information, try '--help'.",
                    2,
                )
            if flag not in VALUE_FLAGS:
                clap_error(f"unexpected argument '{arg}' found")
            key, display = VALUE_FLAGS[flag]
            i += 1
        elif len(arg) > 2 and arg[:2] in ("-n", "-t", "-c", "-r", "-w", "-a") and not arg.startswith("--"):
            flag = arg[:2]
            value = arg[3:] if arg[2:3] == "=" else arg[2:]
            key, display = VALUE_FLAGS[flag]
            i += 1
        elif arg in BOOL_FLAGS:
            cfg[BOOL_FLAGS[arg]] = True
            i += 1
            continue
        elif arg in VALUE_FLAGS:
            key, display = VALUE_FLAGS[arg]
            value, i = take_value(argv, i, arg, display)
            flag = arg
        else:
            clap_error(f"unexpected argument '{arg}' found")

        if key in {"top", "combi", "rep", "wpm", "acc"}:
            cfg[key] = parse_int(flag, display, value)
        else:
            cfg[key] = value

    for key in ("top", "combi", "rep", "wpm"):
        if not (1 <= cfg[key] <= 200):
            raise CliError(f"Invalid argument for {key}. Use a number between 1 and 200.", 1, True)
    if not (0 <= cfg["acc"] <= 100):
        raise CliError("Invalid argument for acc. Use a number between 0 and 100.", 1, True)
    if bool(cfg["emu_in"]) ^ bool(cfg["emu_out"]):
        raise CliError("You need to specify both emu_in and emu_out.", 1, True)

    if cfg["n"] not in ("2", "3", "4", "w"):
        if not os.path.exists(cfg["n"]):
            raise CliError(f"File not found: {cfg['n']}", 1, True)
    return cfg


def lesson_items(cfg):
    n = cfg["n"]
    if n == "2":
        pool = BIGRAMS
    elif n == "3":
        pool = TRIGRAMS
    elif n == "4":
        pool = TETRAGRAMS
    elif n == "w":
        pool = WORDS
    else:
        data = open(n, "r", encoding="utf-8", errors="ignore").read()
        pool = [x.strip() for x in data.replace("\n", ",").split(",") if x.strip()]
        if not pool:
            pool = WORDS
    top = min(cfg["top"], len(pool))
    choices = list(pool[:top])
    random.shuffle(choices)
    selected = choices[: max(1, min(cfg["combi"], len(choices)))]
    lesson = []
    for item in selected:
        lesson.extend([item] * max(1, cfg["rep"]))
    random.shuffle(lesson)
    return lesson


def print_non_tty_error():
    sys.stdout.write("\x1b[?1049h")
    sys.stdout.flush()
    sys.stderr.write('Error: Os { code: 6, kind: Uncategorized, message: "No such device or address" }\n')
    sys.stderr.flush()
    return 1


def draw(cfg, typed, target, start_time):
    cols, rows = shutil.get_terminal_size((80, 24))
    elapsed = max(0.001, time.monotonic() - start_time) if start_time else 0.0
    correct = sum(1 for a, b in zip(typed, target) if a == b)
    acc = 100 if not typed else int(round((correct / len(typed)) * 100))
    wpm = 0 if not start_time else int(round((correct / 5) / (elapsed / 60)))
    line = "".join(target)
    progress = len(typed)
    before = line[:progress]
    current = line[progress:progress + 1]
    after = line[progress + 1:]

    sys.stdout.write("\x1b[H\x1b[2J")
    sys.stdout.write("ngrrram\n\n")
    sys.stdout.write(f"wpm {wpm}/{cfg['wpm']}   acc {acc}%/{cfg['acc']}%   n {cfg['n']}   top {cfg['top']}\n\n")
    sys.stdout.write("Type the lesson. Press Esc, Ctrl-C or Ctrl-D to quit.\n\n")
    sys.stdout.write("\x1b[32m" + before[-cols:] + "\x1b[0m")
    if current:
        sys.stdout.write("\x1b[7m" + current + "\x1b[0m")
    sys.stdout.write(after[: max(0, cols - len(before[-cols:]) - 1)] + "\n\n")
    sys.stdout.write(" ".join(target)[: cols * 3] + "\n")
    if cfg["cat"]:
        sys.stdout.write("\n /\_/\\\\\n( o.o )\n > ^ <\n")
    if not cfg["nokb"]:
        rows_layout = LAYOUTS.get(cfg["emu_out"] or cfg["emu_in"] or "qwerty", LAYOUTS["qwerty"])
        sys.stdout.write("\n")
        for r in rows_layout:
            if cfg["show-ortho"]:
                sys.stdout.write(" ".join(r) + "\n")
            else:
                sys.stdout.write((" " * (2 if r == rows_layout[1] else 4 if r == rows_layout[2] else 0)) + " ".join(r) + "\n")
    sys.stdout.flush()


def run_tui(cfg):
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return print_non_tty_error()

    target = []
    for item in lesson_items(cfg):
        target.extend(list(item + " "))
    if target:
        target.pop()
    typed = []
    start_time = None
    old = termios.tcgetattr(sys.stdin.fileno())
    try:
        tty.setcbreak(sys.stdin.fileno())
        sys.stdout.write("\x1b[?1049h\x1b[?25l")
        while True:
            draw(cfg, typed, target, start_time)
            if len(typed) >= len(target):
                sys.stdout.write("\nLesson complete. Press any key for another lesson or Esc to quit.")
                sys.stdout.flush()
                ch = sys.stdin.read(1)
                if ch == "\x1b":
                    break
                target = []
                for item in lesson_items(cfg):
                    target.extend(list(item + " "))
                if target:
                    target.pop()
                typed = []
                start_time = None
                continue
            r, _, _ = select.select([sys.stdin], [], [], 0.5)
            if not r:
                continue
            ch = sys.stdin.read(1)
            if ch in ("\x03", "\x04", "\x1b"):
                break
            if ch in ("\x7f", "\b"):
                typed = typed[:-1]
            elif ch in ("\r", "\n", "\t"):
                pass
            elif ch:
                if start_time is None:
                    start_time = time.monotonic()
                typed.append(ch)
    finally:
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
        sys.stdout.write("\x1b[?25h\x1b[?1049l")
        sys.stdout.flush()
    return 0


def main():
    try:
        cfg = parse_args(sys.argv[1:])
    except CliError as e:
        stream = sys.stdout if e.stdout else sys.stderr
        stream.write(str(e) + "\n")
        return e.code
    return run_tui(cfg)


if __name__ == "__main__":
    raise SystemExit(main())
