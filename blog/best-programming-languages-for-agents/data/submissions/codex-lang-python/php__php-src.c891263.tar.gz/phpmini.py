#!/usr/bin/env python3
import hashlib, html, json, os, re, sys, time

VERSION = "8.6.0-dev"

HELP = """Usage: executable [options] [-f] <file> [--] [args...]
   executable [options] -r <code> [--] [args...]
   executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]
   executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]
   executable [options] -S <addr>:<port> [-t docroot] [router]
   executable [options] -- [args...]
   executable [options] -a

  -a               Run as interactive shell (requires readline extension)
  -c <path>|<file> Look for php.ini file in this directory
  -n               No configuration (ini) files will be used
  -d foo[=bar]     Define INI entry foo with value 'bar'
  -e               Generate extended information for debugger/profiler
  -f <file>        Parse and execute <file>.
  -h               This help
  -i               PHP information
  -l               Syntax check only (lint)
  -m               Show compiled in modules
  -r <code>        Run PHP <code> without using script tags <?..?>
  -B <begin_code>  Run PHP <begin_code> before processing input lines
  -R <code>        Run PHP <code> for every input line
  -F <file>        Parse and execute <file> for every input line
  -E <end_code>    Run PHP <end_code> after processing all input lines
  -H               Hide any passed arguments from external tools.
  -S <addr>:<port> Run with built-in web server.
  -t <docroot>     Specify document root <docroot> for built-in web server.
  -s               Output HTML syntax highlighted source.
  -v               Version number
  -w               Output source with stripped comments and whitespace.

  args...          Arguments passed to script. Use -- args when first argument
                   starts with - or script is read from stdin

  --ini            Show configuration file names
  --ini=diff       Show INI entries that differ from the built-in default

  --rf <name>      Show information about function <name>.
  --rc <name>      Show information about class <name>.
  --re <name>      Show information about extension <name>.
  --rz <name>      Show information about Zend extension <name>.
  --ri <name>      Show configuration for extension <name>.

  --repeat <count> Repeat script execution <count> times.
                   For internal purposes only.
"""

class PHPArray:
    def __init__(self, items=None):
        self.data = {}
        self.next = 0
        if items:
            for k, v in items:
                self.set(k, v)
    def set(self, k, v):
        if k is None:
            k = self.next
        if isinstance(k, float) and k.is_integer():
            k = int(k)
        self.data[k] = v
        if isinstance(k, int) and k >= self.next:
            self.next = k + 1
        return v
    def get(self, k, default=None):
        return self.data.get(k, default)
    def append(self, v):
        return self.set(None, v)
    def items(self):
        return list(self.data.items())
    def values(self):
        return list(self.data.values())
    def __len__(self):
        return len(self.data)

def php_array(items=None): return PHPArray(items or [])
def is_php_array(v): return isinstance(v, PHPArray)

def php_str(v):
    if v is None: return ""
    if v is True: return "1"
    if v is False: return ""
    if isinstance(v, PHPArray): return "Array"
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() else ("%s" % v)
    return str(v)

def php_bool(v):
    if v is None or v is False: return False
    if v == 0 or v == 0.0 or v == "" or v == "0": return False
    if isinstance(v, PHPArray) and len(v) == 0: return False
    return True

def php_eq(a,b): return php_str(a) == php_str(b) if isinstance(a,str) or isinstance(b,str) else a == b
def php_neq(a,b): return not php_eq(a,b)
def php_concat(*xs): return "".join(php_str(x) for x in xs)
def php_count(x): return len(x.data if isinstance(x, PHPArray) else x or [])
def php_len(x): return len(php_str(x))
def php_echo(*xs): sys.stdout.write("".join(php_str(x) for x in xs))
def php_print(x=""): sys.stdout.write(php_str(x)); return 1
def php_range(a,b):
    a=int(a); b=int(b); step=1 if b>=a else -1
    return PHPArray([(None, i) for i in range(a,b+step,step)])
def php_explode(sep,s,limit=None):
    parts = php_str(s).split(php_str(sep), int(limit)-1 if limit else -1)
    return PHPArray([(None,p) for p in parts])
def php_implode(sep, arr=None):
    if arr is None: sep, arr = "", sep
    vals = arr.values() if isinstance(arr, PHPArray) else list(arr)
    return php_str(sep).join(php_str(x) for x in vals)
def php_json(v):
    def conv(x):
        if isinstance(x, PHPArray):
            keys=list(x.data.keys())
            if keys == list(range(len(keys))): return [conv(x.data[i]) for i in keys]
            return {str(k): conv(v) for k,v in x.data.items()}
        return x
    return json.dumps(conv(v), separators=(",",":"))
def php_var_dump(*vals):
    for v in vals: sys.stdout.write(var_dump_text(v))
def var_dump_text(v, indent=0):
    sp="  "*indent
    if v is True: return sp+"bool(true)\n"
    if v is False: return sp+"bool(false)\n"
    if v is None: return sp+"NULL\n"
    if isinstance(v, int): return sp+f"int({v})\n"
    if isinstance(v, float): return sp+f"float({php_str(v)})\n"
    if isinstance(v, str): return sp+f'string({len(v)}) "{v}"\n'
    if isinstance(v, PHPArray):
        out=sp+f"array({len(v)}) {{\n"
        for k,x in v.items():
            key = f'"{k}"' if isinstance(k,str) else str(k)
            out += sp+f"  [{key}]=>\n" + var_dump_text(x, indent+1)
        return out+sp+"}\n"
    return sp+f"object({type(v).__name__})\n"
def php_print_r(v, ret=False):
    s=print_r_text(v)
    if ret: return s
    sys.stdout.write(s); return True
def print_r_text(v):
    if isinstance(v, PHPArray):
        out="Array\n(\n"
        for k,x in v.items(): out += f"    [{k}] => {php_str(x)}\n"
        return out+")\n"
    return php_str(v)
def php_var_export(v, ret=False):
    s=export_text(v)
    if ret: return s
    sys.stdout.write(s); return None
def export_text(v):
    if v is None: return "NULL"
    if v is True: return "true"
    if v is False: return "false"
    if isinstance(v, str): return repr(v).replace('"', '\\"')
    if isinstance(v, PHPArray):
        return "array (" + ", ".join(f"{export_text(k)} => {export_text(x)}" for k,x in v.items()) + ")"
    return php_str(v)

class Obj: pass

class Interpreter:
    def __init__(self, argv=None, filename=None):
        self.env = {}
        self.filename = filename or "Command line code"
        self.env.update({
            "PHP_VERSION": VERSION, "PHP_EOL": "\n", "DIRECTORY_SEPARATOR": "/", "__FILE__": self.filename,
            "argc": len(argv or []), "argv": PHPArray([(i,a) for i,a in enumerate(argv or [])]),
            "_SERVER": PHPArray([( "argv", PHPArray([(i,a) for i,a in enumerate(argv or [])]) ), ("argc", len(argv or []))]),
        })

    def run_template(self, text):
        if text.startswith("#!"):
            text = text[text.find("\n")+1:] if "\n" in text else ""
        pos=0
        for m in re.finditer(r"<\?(?:php|=)?", text, re.I):
            sys.stdout.write(text[pos:m.start()])
            close=text.find("?>", m.end())
            code=text[m.end():] if close < 0 else text[m.end():close]
            if text[m.start():m.end()].endswith("="): code="echo "+code
            self.run_code(code)
            pos=len(text) if close < 0 else close+2
        sys.stdout.write(text[pos:])

    def run_code(self, code):
        py = self.translate(code)
        ns = self.runtime()
        try:
            exec(py, ns, ns)
            self.env.update({k:v for k,v in ns.items() if not k.startswith("__")})
        except SystemExit:
            raise
        except Exception as e:
            sys.stderr.write(f"\nFatal error: {type(e).__name__}: {e} in {self.filename} on line 1\n")
            raise SystemExit(255)

    def runtime(self):
        ns = dict(self.env)
        ns.update({
            "PHPArray":PHPArray, "php_array":php_array, "php_echo":php_echo, "php_print":php_print,
            "Interpreter": Interpreter,
            "php_var_dump":php_var_dump, "var_dump":php_var_dump, "print_r":php_print_r, "var_export":php_var_export,
            "strlen":php_len, "count":php_count, "sizeof":php_count, "json_encode":php_json,
            "md5":lambda s: hashlib.md5(php_str(s).encode()).hexdigest(),
            "sha1":lambda s: hashlib.sha1(php_str(s).encode()).hexdigest(),
            "strtoupper":lambda s: php_str(s).upper(), "strtolower":lambda s: php_str(s).lower(),
            "trim":lambda s, chars=None: php_str(s).strip(chars), "ltrim":lambda s, chars=None: php_str(s).lstrip(chars),
            "rtrim":lambda s, chars=None: php_str(s).rstrip(chars), "explode":php_explode, "implode":php_implode,
            "join":php_implode, "substr":lambda s,a,l=None: php_str(s)[int(a): int(a)+(int(l) if l is not None else len(php_str(s)))],
            "str_replace":lambda a,b,s: php_str(s).replace(php_str(a),php_str(b)),
            "range":php_range, "array_keys":lambda a: PHPArray([(None,k) for k in a.data.keys()]),
            "array_values":lambda a: PHPArray([(None,v) for v in a.data.values()]),
            "in_array":lambda n,h: n in (h.values() if isinstance(h,PHPArray) else h),
            "isset":lambda *xs: all(x is not None for x in xs), "empty":lambda x=None: not php_bool(x),
            "time":lambda : int(time.time()), "date":lambda fmt,t=None: time.strftime(php_str(fmt).replace("Y","%Y").replace("m","%m").replace("d","%d").replace("H","%H").replace("i","%M").replace("s","%S"), time.gmtime(int(t or time.time()))),
            "php_bool":php_bool, "php_eq":php_eq, "php_neq":php_neq, "php_concat":php_concat, "php_str":php_str,
            "py_range": range,
        })
        return ns

    def translate(self, code):
        code = self.strip_comments(code)
        toks = self.statements(code)
        out=[]; indent=0
        for typ, txt in toks:
            if typ=="close":
                indent=max(0, indent-1); continue
            if typ=="else":
                indent=max(0, indent-1)
                line = "else:" if txt.strip()=="else" else "elif "+self.expr(txt.strip()[6:].strip()[1:-1])+":"
                out.append("    "*indent+line); indent+=1; continue
            if typ=="block":
                line=self.block_line(txt)
                out.append("    "*indent+line); indent+=1; continue
            line=self.stmt_line(txt)
            if line: out.append("    "*indent+line)
        return "\n".join(out)+"\n"

    def strip_comments(self, s):
        s=re.sub(r"/\*.*?\*/","",s,flags=re.S)
        s=re.sub(r"(?m)//.*$","",s)
        s=re.sub(r"(?m)#.*$","",s)
        return s

    def statements(self, s):
        res=[]; i=0; buf=""
        inq=None; esc=False; depth=0
        while i < len(s):
            c=s[i]
            if inq:
                buf+=c
                if esc: esc=False
                elif c=="\\": esc=True
                elif c==inq: inq=None
            elif c in "\"'":
                inq=c; buf+=c
            elif c in "([": depth+=1; buf+=c
            elif c in ")]": depth-=1; buf+=c
            elif c=="{" and depth==0:
                t=buf.strip(); buf=""
                if t: res.append(("block",t))
            elif c=="}" and depth==0:
                if buf.strip(): res.append(("stmt",buf.strip()))
                buf=""; res.append(("close","}"))
                j=i+1
                while j<len(s) and s[j].isspace(): j+=1
                if s.startswith("else",j):
                    k=j
                    while k<len(s) and s[k] != "{": k+=1
                    res.append(("else",s[j:k].strip()))
                    i=k
            elif c==";" and depth==0:
                if buf.strip(): res.append(("stmt",buf.strip()))
                buf=""
            else:
                buf+=c
            i+=1
        if buf.strip(): res.append(("stmt",buf.strip()))
        return res

    def block_line(self,t):
        if t.startswith("if"):
            return "if php_bool("+self.expr(t[t.find("(")+1:t.rfind(")")])+"):"
        if t.startswith("while"):
            return "while php_bool("+self.expr(t[t.find("(")+1:t.rfind(")")])+"):"
        if t.startswith("foreach"):
            inner=t[t.find("(")+1:t.rfind(")")]
            m=re.match(r"(.+)\s+as\s+(.+?)(?:\s*=>\s*(.+))?$", inner)
            arr=self.expr(m.group(1)); a=m.group(2).strip(); b=m.group(3).strip() if m.group(3) else None
            if b:
                return f"for {self.varname(a)}, {self.varname(b)} in ({arr}).items():"
            return f"for {self.varname(a)} in ({arr}).values():"
        if t.startswith("for"):
            inner=t[t.find("(")+1:t.rfind(")")]
            parts=self.split_top(inner,";")
            if len(parts) >= 3:
                mi=re.match(r"\s*\$(\w+)\s*=\s*(.+)\s*$", parts[0])
                mc=re.match(r"\s*\$(\w+)\s*(<|<=|>|>=)\s*(.+)\s*$", parts[1])
                mn=re.match(r"\s*\$(\w+)\s*(\+\+|--)\s*$", parts[2])
                if mi and mc and mn and mi.group(1)==mc.group(1)==mn.group(1):
                    var=mi.group(1); start=self.expr(mi.group(2)); end=self.expr(mc.group(3)); op=mc.group(2); step="-1" if mn.group(2)=="--" else "1"
                    if op=="<": stop=end
                    elif op=="<=": stop=f"({end})+1"
                    elif op==">": stop=end
                    else: stop=f"({end})-1"
                    return f"for {var} in py_range(int({start}), int({stop}), {step}):"
            init=self.stmt_line(parts[0]) if parts and parts[0].strip() else ""
            cond=self.expr(parts[1]) if len(parts)>1 and parts[1].strip() else "True"
            inc=self.stmt_line(parts[2]) if len(parts)>2 and parts[2].strip() else "pass"
            return f"\n{init}\nwhile php_bool({cond}):"
        if t.startswith("function"):
            m=re.match(r"function\s+(\w+)\s*\((.*?)\)",t)
            args=", ".join(self.varname(x.strip().split("=")[0]) for x in self.split_top(m.group(2),",") if x.strip())
            return f"def {m.group(1)}({args}):"
        return "if True:"

    def stmt_line(self,t):
        t=t.strip()
        if not t: return ""
        if t.startswith("echo "): return "php_echo("+",".join(self.expr(x) for x in self.split_top(t[5:],","))+")"
        if t.startswith("print "): return "php_print("+self.expr(t[6:])+")"
        if t.startswith("include ") or t.startswith("require "):
            return "Interpreter([], php_str("+self.expr(t.split(None,1)[1])+")).run_template(open(php_str("+self.expr(t.split(None,1)[1])+")).read())"
        if t.startswith("return"): return "return "+(self.expr(t[6:]) if t[6:].strip() else "None")
        if t.startswith("exit") or t.startswith("die"):
            inner=t[t.find("(")+1:t.rfind(")")] if "(" in t else t.split(None,1)[1] if " " in t else "0"
            return "raise SystemExit(int("+self.expr(inner)+") if "+self.expr(inner)+" is not None else 0)"
        m=re.match(r"(.+?)(\+\+|--)$", t)
        if m: return self.lvalue(m.group(1)) + (" += 1" if m.group(2)=="++" else " -= 1")
        m=re.match(r"(.+?)(\+=|-=|\.=|\*=|/=)\s*(.+)$", t)
        if m:
            op=m.group(2); lhs=self.lvalue(m.group(1)); rhs=self.expr(m.group(3))
            return lhs + (" = php_concat("+lhs+","+rhs+")" if op==".=" else f" {op[0]}= {rhs}")
        m=re.match(r"(.+?)=\s*(.+)$", t)
        if m and "==" not in t:
            if m.group(1).strip().endswith("[]"):
                return self.varname(m.group(1).strip()[:-2])+".append("+self.expr(m.group(2))+")"
            return self.lvalue(m.group(1))+" = "+self.expr(m.group(2))
        return self.expr(t)

    def lvalue(self,s):
        s=s.strip()
        s=re.sub(r"^\$", "", s)
        s=re.sub(r"\[(.*?)\]", lambda m: ".data["+self.expr(m.group(1))+"]", s)
        return s
    def varname(self,s): return s.strip().lstrip("$")

    def expr(self,e):
        e=e.strip()
        if e=="": return "None"
        if e.startswith("[") and e.endswith("]"): return self.array_expr(e[1:-1])
        if e.lower().startswith("array(") and e.endswith(")"): return self.array_expr(e[e.find("(")+1:-1])
        mcall = re.match(r"^([A-Za-z_]\w*)\s*\((.*)\)$", e, re.S)
        if mcall:
            args = ",".join(self.expr(x) for x in self.split_top(mcall.group(2), ",") if x.strip())
            return f"{mcall.group(1)}({args})"
        parts=self.split_top(e,".")
        if len(parts)>1: return "php_concat("+",".join(self.expr(p) for p in parts)+")"
        e=self.convert_strings(e)
        e=re.sub(r"\btrue\b","True",e,flags=re.I); e=re.sub(r"\bfalse\b","False",e,flags=re.I); e=re.sub(r"\bnull\b","None",e,flags=re.I)
        e=re.sub(r"===", "==", e); e=re.sub(r"!==", "!=", e)
        e=re.sub(r"(?<![=!<>])==(?![=])", "==", e)
        e=e.replace("&&"," and ").replace("||"," or ")
        e=re.sub(r"!\s*(?!=)", " not ", e)
        e=re.sub(r"\$(\w+)\s*\[(.*?)\]", lambda m: f"{m.group(1)}.get({self.expr(m.group(2))})", e)
        e=re.sub(r"\$(\w+)", r"\1", e)
        return e

    def array_expr(self,inner):
        items=[]
        for p in self.split_top(inner,","):
            if not p.strip(): continue
            kv=self.split_arrow(p)
            if kv: items.append("("+self.expr(kv[0])+","+self.expr(kv[1])+")")
            else: items.append("(None,"+self.expr(p)+")")
        return "php_array(["+",".join(items)+"])"

    def split_arrow(self,s):
        parts=self.split_top(s,"=>")
        return parts if len(parts)==2 else None

    def split_top(self,s,sep):
        res=[]; buf=""; depth=0; inq=None; esc=False; i=0
        while i<len(s):
            c=s[i]
            if inq:
                buf+=c
                if esc: esc=False
                elif c=="\\": esc=True
                elif c==inq: inq=None
            elif c in "\"'":
                inq=c; buf+=c
            elif c in "([{": depth+=1; buf+=c
            elif c in ")]}": depth-=1; buf+=c
            elif depth==0 and s.startswith(sep,i) and not (sep=="." and i>0 and i+1<len(s) and s[i-1].isdigit() and s[i+1].isdigit()):
                res.append(buf.strip()); buf=""; i+=len(sep)-1
            else: buf+=c
            i+=1
        res.append(buf.strip())
        return res

    def convert_strings(self,e):
        def repl(m):
            raw=m.group(0); quote=raw[0]; body=raw[1:-1]
            body=bytes(body, "utf-8").decode("unicode_escape")
            if quote == '"':
                def vr(mm): return "{php_str("+mm.group(1)+")}"
                body=re.sub(r"\$(\w+)", vr, body)
                return "f"+repr(body)
            return repr(body)
        return re.sub(r"'(?:\\.|[^'])*'|\"(?:\\.|[^\"])*\"", repl, e)

def version():
    print(f"PHP {VERSION} (cli) (built: Apr 17 2026 20:00:58) (NTS)")
    print("Copyright (c) The PHP Group")
    print("Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies")
    print("    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies")

def modules():
    print("[PHP Modules]\nCore\ndate\nhash\njson\nlexbor\npcre\nrandom\nReflection\nSPL\nstandard\nuri\nZend OPcache\n\n[Zend Modules]\nZend OPcache\n")

def phpinfo():
    print("phpinfo()\nPHP Version => 8.6.0-dev\n\nSystem => Linux")
    print("Build Date => Apr 17 2026 20:00:58")
    print("Configure Command =>  './configure'  '--disable-all' '--enable-cli' '--enable-debug=no'")
    print("Server API => Command Line Interface")
    print("Configuration File (php.ini) Path => /usr/local/lib")
    print("Loaded Configuration File => (none)")
    print("\nRegistered PHP Streams => php, file, glob, data, http, ftp")
    print("\nThis program makes use of the Zend Scripting Language Engine:\nZend Engine v4.6.0-dev, Copyright (c) Zend Technologies")

def ini():
    print('Configuration File (php.ini) Path: "/usr/local/lib"')
    print("Loaded Configuration File:         (none)")
    print("Scan for additional .ini files in: (none)")
    print("Additional .ini files parsed:      (none)")

def strip_php(src):
    return re.sub(r"<\?(?:php|=)?|\?>","",src,flags=re.I)

def highlight(src):
    print('<pre><code style="color: #000000">'+html.escape(src)+'</code></pre>')

def rf(name):
    print(f"Function [ <internal:Core> function {name} ] {{\n\n  - Parameters [0] {{\n  }}\n}}\n")

def main(argv):
    if len(argv)==1: return repl()
    args=argv[1:]; file=None; code=None; lint=False; show_strip=False; show_high=False; script_args=[]
    begin_code=None; repeat_code=None; end_code=None; repeat_file=None
    i=0
    while i<len(args):
        a=args[i]
        if a=="--": script_args=args[i+1:]; break
        if a in ("-h","--help"): print(HELP,end=""); return 0
        if a=="-v": version(); return 0
        if a=="-m": modules(); return 0
        if a=="-i": phpinfo(); return 0
        if a=="--ini": ini(); return 0
        if a.startswith("--ini="): return 0
        if a=="--rf": rf(args[i+1] if i+1<len(args) else ""); return 0
        if a in ("--rc","--re","--rz","--ri"):
            print(args[i+1] if i+1<len(args) else ""); return 0
        if a in ("-n","-e","-H"): i+=1; continue
        if a in ("-c","-d","--repeat"): i+=2; continue
        if a=="-l": lint=True; i+=1; continue
        if a=="-w": show_strip=True; i+=1; continue
        if a=="-s": show_high=True; i+=1; continue
        if a=="-r": code=args[i+1] if i+1<len(args) else ""; i+=2; continue
        if a=="-B": begin_code=args[i+1] if i+1<len(args) else ""; i+=2; continue
        if a=="-R": repeat_code=args[i+1] if i+1<len(args) else ""; i+=2; continue
        if a=="-E": end_code=args[i+1] if i+1<len(args) else ""; i+=2; continue
        if a=="-F": repeat_file=args[i+1] if i+1<len(args) else ""; i+=2; continue
        if a=="-f": file=args[i+1] if i+1<len(args) else None; i+=2; continue
        if a.startswith("-"):
            sys.stderr.write(f"Error in argument {i+1}, char 2: option not found {a[1:2]}\n"+HELP); return 1
        file=a; script_args=args[i+1:]; break
    if code is not None:
        if "<?" in code:
            sys.stderr.write('\nParse error: syntax error, unexpected token "<", expecting end of file in Command line code on line 1\n')
            return 255
        if code.strip() and not code.strip().endswith((";","}")):
            sys.stderr.write('\nParse error: syntax error, unexpected end of file, expecting "," or ";" in Command line code on line 1\n')
            return 255
        Interpreter([argv[0]]+script_args).run_code(code); return 0
    if repeat_code is not None or repeat_file is not None:
        interp=Interpreter([argv[0]]+script_args)
        if begin_code: interp.run_code(begin_code)
        body = open(repeat_file).read() if repeat_file else repeat_code
        for n,line in enumerate(sys.stdin, 1):
            interp.env["argn"]=line; interp.env["argi"]=n
            if repeat_file: interp.run_template(body)
            else: interp.run_code(body)
        if end_code: interp.run_code(end_code)
        return 0
    if not file:
        data=sys.stdin.read(); Interpreter([argv[0]]+script_args, "Standard input code").run_template(data); return 0
    if not os.path.exists(file):
        sys.stderr.write(f"Could not open input file: {file}\n"); return 1
    src=open(file,encoding="utf-8",errors="ignore").read()
    if lint: print(f"No syntax errors detected in {file}"); return 0
    if show_strip: print(strip_php(src), end="" if src.endswith("\n") else "\n"); return 0
    if show_high: highlight(src); return 0
    Interpreter([file]+script_args, file).run_template(src); return 0

def repl():
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv))
    except BrokenPipeError:
        pass
