#!/usr/bin/env python3
import html
import os
import sys
from dataclasses import dataclass, field
from typing import List, Optional
from urllib.parse import urljoin

from bs4 import BeautifulSoup, Comment, Doctype, NavigableString, Tag


HELP = """htmlq 0.4.0
Michael Maclean <michael@mgdm.net>
Runs CSS selectors on HTML

USAGE:
    executable [FLAGS] [OPTIONS] [--] [selector]...

FLAGS:
    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to
                               the value of --base, if supplied
    -h, --help                 Prints help information
    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace
    -p, --pretty               Pretty-print the serialised output
    -t, --text                 Output only the contents of text nodes inside selected elements
    -V, --version              Prints version information

OPTIONS:
    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements
    -b, --base <base>                   Use this URL as the base for links
    -f, --filename <FILE>               The input file. Defaults to stdin
    -o, --output <FILE>                 The output file. Defaults to stdout
    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple
                                        times

ARGS:
    <selector>...    The CSS expression to select [default: html]
"""


VERSION = "htmlq 0.4.0\n"
VOID_TAGS = {
    "area", "base", "br", "col", "embed", "hr", "img", "input",
    "link", "meta", "param", "source", "track", "wbr",
}
HEAD_TAGS = {"base", "basefont", "bgsound", "link", "meta", "title", "style"}
TABLE_SECTION_TAGS = {"tbody", "thead", "tfoot"}


@dataclass
class Config:
    text: bool = False
    pretty: bool = False
    ignore_ws: bool = False
    detect_base: bool = False
    attribute: Optional[str] = None
    base: Optional[str] = None
    filename: Optional[str] = None
    output: Optional[str] = None
    remove_nodes: List[str] = field(default_factory=list)
    selectors: List[str] = field(default_factory=list)


def usage_error(msg: str) -> int:
    sys.stderr.write(f"error: {msg}\n")
    return 1


def parse_args(argv: List[str]) -> Optional[Config]:
    cfg = Config()
    i = 0
    positional_only = False
    while i < len(argv):
        arg = argv[i]
        if positional_only:
            cfg.selectors.append(arg)
            i += 1
            continue
        if arg == "--":
            positional_only = True
            i += 1
        elif arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            raise SystemExit(0)
        elif arg in ("-V", "--version"):
            sys.stdout.write(VERSION)
            raise SystemExit(0)
        elif arg in ("-t", "--text"):
            cfg.text = True
            i += 1
        elif arg in ("-p", "--pretty"):
            cfg.pretty = True
            i += 1
        elif arg in ("-w", "--ignore-whitespace"):
            cfg.ignore_ws = True
            i += 1
        elif arg in ("-B", "--detect-base"):
            cfg.detect_base = True
            i += 1
        elif arg in ("-a", "--attribute", "-b", "--base", "-f", "--filename", "-o", "--output", "-r", "--remove-nodes"):
            if i + 1 >= len(argv):
                raise SystemExit(usage_error(f"The argument '{arg}' requires a value but none was supplied"))
            val = argv[i + 1]
            if arg in ("-a", "--attribute"):
                cfg.attribute = val
            elif arg in ("-b", "--base"):
                cfg.base = val
            elif arg in ("-f", "--filename"):
                cfg.filename = val
            elif arg in ("-o", "--output"):
                cfg.output = val
            else:
                cfg.remove_nodes.append(val)
            i += 2
        elif arg.startswith("--"):
            raise SystemExit(usage_error(f"Found argument '{arg}' which wasn't expected"))
        elif arg.startswith("-") and arg != "-":
            # Support simple short flag clusters such as -tw, which clap accepts for booleans.
            handled = True
            for ch in arg[1:]:
                if ch == "t":
                    cfg.text = True
                elif ch == "p":
                    cfg.pretty = True
                elif ch == "w":
                    cfg.ignore_ws = True
                elif ch == "B":
                    cfg.detect_base = True
                else:
                    handled = False
                    break
            if not handled:
                raise SystemExit(usage_error(f"Found argument '{arg}' which wasn't expected"))
            i += 1
        else:
            cfg.selectors.append(arg)
            i += 1
    return cfg


def load_html(cfg: Config) -> str:
    if cfg.filename:
        try:
            with open(cfg.filename, "r", encoding="utf-8") as f:
                return f.read()
        except OSError as e:
            sys.stderr.write(
                "\nthread 'main' (0) panicked at src/main.rs:196:37:\n"
                f"should have opened input file: {e}\n"
            )
            raise SystemExit(101)
    return sys.stdin.read()


def make_soup(data: str) -> BeautifulSoup:
    fragment = BeautifulSoup(data, "html.parser")
    if fragment.find("html") is not None:
        normalize_tree(fragment)
        return fragment

    soup = BeautifulSoup("<html><head></head><body></body></html>", "html.parser")
    head = soup.head
    body = soup.body
    for child in list(fragment.contents):
        if isinstance(child, Doctype):
            child.extract()
            continue
        if isinstance(child, Tag) and child.name in HEAD_TAGS:
            head.append(child.extract())
        else:
            body.append(child.extract())
    normalize_tree(soup)
    return soup


def normalize_tree(soup: BeautifulSoup) -> None:
    # Small HTML5-style repairs that matter for common command-line scraping.
    # BeautifulSoup's stdlib parser omits these, while htmlq's html5ever parser
    # inserts them before selector matching and serialization.
    for table in soup.find_all("table"):
        direct_rows = [
            child for child in list(table.contents)
            if isinstance(child, Tag) and child.name == "tr"
        ]
        if direct_rows:
            tbody = soup.new_tag("tbody")
            first = direct_rows[0]
            first.insert_before(tbody)
            for row in direct_rows:
                tbody.append(row.extract())

    for li in soup.find_all("li"):
        for nested in list(li.find_all("li", recursive=False)):
            li.insert_after(nested.extract())


def esc_text(value: str) -> str:
    return html.escape(value, quote=False)


def attr_value(value) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return " ".join(str(v) for v in value)
    return str(value)


def serialize_attrs(tag: Tag) -> str:
    parts = []
    for key in sorted(tag.attrs.keys()):
        value = attr_value(tag.attrs.get(key))
        parts.append(f'{key}="{html.escape(value, quote=True)}"')
    return (" " + " ".join(parts)) if parts else ""


def serialize(node) -> str:
    if isinstance(node, Doctype):
        return ""
    if isinstance(node, Comment):
        return f"<!--{node}-->"
    if isinstance(node, NavigableString):
        return esc_text(str(node))
    if not isinstance(node, Tag):
        return "".join(serialize(c) for c in getattr(node, "contents", []))
    name = node.name
    start = f"<{name}{serialize_attrs(node)}>"
    if name in VOID_TAGS:
        return start
    return start + "".join(serialize(c) for c in node.contents) + f"</{name}>"


def pretty_serialize(tag: Tag) -> str:
    raw = tag.prettify(formatter="html")
    raw = raw.replace("/>", ">")
    return "\n" + raw.rstrip("\n")


def node_texts(tag: Tag):
    for s in tag.descendants:
        if isinstance(s, NavigableString) and not isinstance(s, (Comment, Doctype)):
            yield str(s)


def detect_base_url(soup: BeautifulSoup, cfg: Config) -> Optional[str]:
    if cfg.detect_base:
        base_tag = soup.find("base")
        if base_tag and base_tag.has_attr("href"):
            return attr_value(base_tag.get("href"))
    return cfg.base


def run(argv: List[str]) -> int:
    cfg = parse_args(argv)
    data = load_html(cfg)
    soup = make_soup(data)

    for remove_selector in cfg.remove_nodes:
        try:
            for node in soup.select(remove_selector):
                node.decompose()
        except Exception:
            pass

    selector = " ".join(cfg.selectors) if cfg.selectors else "html"
    try:
        selected = soup.select(selector)
    except Exception:
        sys.stderr.write(
            "\nthread 'main' (0) panicked at src/main.rs:221:10:\n"
            "Failed to parse CSS selector: ()\n"
        )
        return 101

    base_url = detect_base_url(soup, cfg)
    out_parts: List[str] = []
    for tag in selected:
        if cfg.attribute:
            if isinstance(tag, Tag) and tag.has_attr(cfg.attribute):
                value = attr_value(tag.get(cfg.attribute))
                if cfg.attribute == "href" and base_url:
                    value = urljoin(base_url, value)
                out_parts.append(value + "\n")
        elif cfg.text:
            if cfg.ignore_ws:
                for text in node_texts(tag):
                    if text.strip():
                        out_parts.append(text + "\n")
                out_parts.append("\n")
            else:
                out_parts.append("".join(node_texts(tag)) + "\n")
        elif cfg.pretty:
            out_parts.append(pretty_serialize(tag) + "\n")
        else:
            out_parts.append(serialize(tag) + "\n")

    output = "".join(out_parts)
    if cfg.output:
        with open(cfg.output, "w", encoding="utf-8") as f:
            f.write(output)
    else:
        sys.stdout.write(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(run(sys.argv[1:]))
