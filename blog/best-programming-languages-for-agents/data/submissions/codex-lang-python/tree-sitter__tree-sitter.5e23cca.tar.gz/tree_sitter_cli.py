#!/usr/bin/env python3
import glob
import json
import os
import re
import shutil
import stat
import sys
from pathlib import Path


VERSION = "tree-sitter 0.27.0"
AUTHORS = "Max Brunsfeld <maxbrunsfeld@gmail.com>\nAmaan Qureshi <amaanq12@gmail.com>"
COMMANDS = [
    ("init-config", "Generate a default config file"),
    ("init", "Initialize a grammar repository"),
    ("generate", "Generate a parser"),
    ("build", "Compile a parser"),
    ("parse", "Parse files"),
    ("test", "Run a parser's tests"),
    ("version", "Display or increment the version of a grammar"),
    ("fuzz", "Fuzz a parser"),
    ("query", "Search files using a syntax tree query"),
    ("highlight", "Highlight a file"),
    ("tags", "Generate a list of tags"),
    ("playground", "Start local playground for a parser in the browser"),
    ("dump-languages", "Print info about all known language parsers"),
    ("complete", "Generate shell completions"),
]


HELP = {
    "top": """tree-sitter 0.27.0
Max Brunsfeld <maxbrunsfeld@gmail.com>
Amaan Qureshi <amaanq12@gmail.com>
Generates and tests parsers

Usage: executable <COMMAND>

Commands:
  init-config     Generate a default config file
  init            Initialize a grammar repository
  generate        Generate a parser
  build           Compile a parser
  parse           Parse files
  test            Run a parser's tests
  version         Display or increment the version of a grammar
  fuzz            Fuzz a parser
  query           Search files using a syntax tree query
  highlight       Highlight a file
  tags            Generate a list of tags
  playground      Start local playground for a parser in the browser
  dump-languages  Print info about all known language parsers
  complete        Generate shell completions

Options:
  -h, --help     Print help
  -V, --version  Print version""",
    "init-config": """Generate a default config file

Usage: executable init-config

Options:
  -h, --help  Print help""",
    "init": """Initialize a grammar repository

Usage: executable init [OPTIONS]

Options:
  -u, --update                       Update outdated files
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory
  -h, --help                         Print help""",
    "generate": """Generate a parser

Usage: executable generate [OPTIONS] [GRAMMAR_PATH]

Arguments:
  [GRAMMAR_PATH]  The path to the grammar file

Options:
  -l, --log
          Show debug log during generation
      --abi <VERSION>
          Select the language ABI version to generate (default 15).
          Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]
      --no-parser
          Only generate `grammar.json` and `node-types.json`
  -b, --build
          Deprecated: use the `build` command
  -0, --debug-build
          Deprecated: use the `build` command
      --libdir <PATH>
          Deprecated: use the `build` command
  -o, --output <DIRECTORY>
          The path to output the generated source files
      --report-states-for-rule <REPORT_STATES_FOR_RULE>
          Produce a report of the states for the given rule, use `-` to report every rule
      --json
          Deprecated: use --json-summary
      --json-summary
          Report conflicts in a JSON format
      --js-runtime <EXECUTABLE>
          The name or path of the JavaScript runtime to use for generating parsers, specify `native` to use the native `QuickJS` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]
      --disable-optimizations
          Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states
  -h, --help
          Print help""",
    "build": """Compile a parser

Usage: executable build [OPTIONS] [PATH]

Arguments:
  [PATH]  The path to the grammar directory

Options:
  -w, --wasm             Build a Wasm module instead of a dynamic library
  -o, --output <OUTPUT>  The path to output the compiled file
      --reuse-allocator  Make the parser reuse the same allocator as the library
  -0, --debug            Compile a parser in debug mode
  -v, --verbose          Display verbose build information
  -h, --help             Print help""",
    "parse": """Parse files

Usage: executable parse [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --dot                          Output the parse data with graphviz dot
  -x, --xml                          Output the parse data in XML format
  -c, --cst                          Output the parse data in a pretty-printed CST format
  -s, --stat                         Show parsing statistic
      --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --edits <EDITS>...             Apply edits in the format: \\"row,col|position delcount insert_text\\", can be supplied multiple times
      --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
      --json                         Deprecated: use --json-summary
  -j, --json-summary                 Output parsing results in a JSON format
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
      --no-ranges                    Omit ranges in the output
  -h, --help                         Print help""",
    "test": """Run a parser's tests

Usage: executable test [OPTIONS]

Options:
  -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex
      --file-name <FILE_NAME>        Only run corpus test cases from a given filename
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
  -u, --update                       Update all syntax trees in corpus files with current parser output
  -d, --debug                        Show parsing debug log
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
      --show-fields                  Force showing fields in test diffs
      --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]
  -r, --rebuild                      Force rebuild the parser
      --overview-only                Show only the pass-fail overview tree
      --json-summary                 Output the test summary in a JSON format
  -h, --help                         Print help""",
    "version": """Display or increment the version of a grammar

Usage: executable version [OPTIONS] [VERSION]

Arguments:
  [VERSION]
          The version to bump to
          
          Examples:
              tree-sitter version: display the current version
              tree-sitter version <version>: bump to specified version
              tree-sitter version --bump <level>: automatic bump

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory

      --bump <BUMP>
          Automatically bump from the current version
          
          [possible values: patch, minor, major]

  -h, --help
          Print help (see a summary with '-h')""",
    "version-short": """Display or increment the version of a grammar

Usage: executable version [OPTIONS] [VERSION]

Arguments:
  [VERSION]  The version to bump to

Options:
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory
      --bump <BUMP>                  Automatically bump from the current version [possible values: patch, minor, major]
  -h, --help                         Print help (see more with '--help')""",
    "fuzz": """Fuzz a parser

Usage: executable fuzz [OPTIONS]

Options:
  -s, --skip <SKIP>                  List of test names to skip
      --subdir <SUBDIR>              Subdirectory to the language
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
      --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)
      --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)
  -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex
      --log-graphs                   Enable logging of graphs and input
  -l, --log                          Enable parser logging
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help""",
    "query": """Search files using a syntax tree query

Usage: executable query [OPTIONS] <QUERY_PATH> [PATHS]...

Arguments:
  <QUERY_PATH>  Path to a file with queries
  [PATHS]...    The source file(s) to use

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>
          The path to the parser's dynamic library
      --lang-name <LANG_NAME>
          If `--lib-path` is used, the name of the language used to extract the library's language function
  -t, --time
          Measure execution time
  -q, --quiet
          Suppress main output
      --paths <PATHS_FILE>
          The path to a file with paths to source file(s)
      --byte-range <BYTE_RANGE>
          The range of byte offsets in which the query will be executed
      --row-range <ROW_RANGE>
          The range of rows in which the query will be executed
      --containing-byte-range <CONTAINING_BYTE_RANGE>
          The range of byte offsets in which the query will be executed. Only the matches that are fully contained within the provided byte range will be returned
      --containing-row-range <CONTAINING_ROW_RANGE>
          The range of rows in which the query will be executed. Only the matches that are fully contained within the provided row range will be returned
      --scope <SCOPE>
          Select a language by the scope instead of a file extension
  -c, --captures
          Order by captures instead of matches
      --test
          Whether to run query tests or not
      --config-path <CONFIG_PATH>
          The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>
          Query the contents of a specific test
  -r, --rebuild
          Force rebuild the parser
  -h, --help
          Print help""",
    "highlight": """Highlight a file

Usage: executable highlight [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
  -H, --html                           Generate highlighting as an HTML document
      --css-classes                    When generating HTML, use css classes rather than inline styles
      --check                          Check that highlighting captures conform strictly to standards
      --captures-path <CAPTURES_PATH>  The path to a file with captures
      --query-paths <QUERY_PATHS>...   The paths to files with queries
      --scope <SCOPE>                  Select a language by the scope instead of a file extension
  -t, --time                           Measure execution time
  -q, --quiet                          Suppress main output
      --paths <PATHS_FILE>             The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>      The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test
  -r, --rebuild                        Force rebuild the parser
      --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
  -h, --help                           Print help""",
    "tags": """Generate a list of tags

Usage: executable tags [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help""",
    "playground": """Start local playground for a parser in the browser

Usage: executable playground [OPTIONS]

Options:
  -q, --quiet                        Don't open in default browser
      --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files
  -e, --export <EXPORT>              Export playground files to specified directory instead of serving them
  -h, --help                         Print help""",
    "dump-languages": """Print info about all known language parsers

Usage: executable dump-languages [OPTIONS]

Options:
      --config-path <CONFIG_PATH>  The path to an alternative config.json file
  -h, --help                       Print help""",
    "complete": """Generate shell completions

Usage: executable complete --shell <SHELL>

Options:
  -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]
  -h, --help           Print help""",
}


def out(text="", end="\n"):
    sys.stdout.write(text + end)


def err(text="", end="\n"):
    sys.stderr.write(text + end)


def red_error(msg):
    err(f"\033[31mError:\033[0m {msg}")


def yellow_warning():
    err("\033[33mWarning:\033[0m You have not configured any parser directories!")
    err("Please run `tree-sitter init-config` and edit the resulting")
    err("configuration file to indicate where we should look for")
    err("language grammars.")
    err()


def print_help(name):
    out(HELP[name])


def config_path(args):
    if "--config-path" in args:
        i = args.index("--config-path")
        if i + 1 < len(args):
            return Path(args[i + 1])
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / "tree-sitter" / "config.json"
    return Path.home() / ".config" / "tree-sitter" / "config.json"


def has_config(args):
    return config_path(args).exists()


def default_config():
    home = str(Path.home())
    return {
        "parser-directories": [
            f"{home}/github",
            f"{home}/src",
            f"{home}/source",
            f"{home}/projects",
            f"{home}/dev",
            f"{home}/git",
        ],
        "theme": {
            "attribute": {"color": 124, "italic": True},
            "comment": {"color": 245, "italic": True},
            "constant": 94,
            "constant.builtin": {"bold": True, "color": 94},
            "constructor": 136,
            "embedded": None,
            "function": 26,
            "function.builtin": {"bold": True, "color": 26},
            "keyword": 56,
            "module": 136,
            "number": {"bold": True, "color": 94},
            "operator": {"bold": True, "color": 239},
            "property": 124,
            "property.builtin": {"bold": True, "color": 124},
            "punctuation": 239,
            "punctuation.bracket": 239,
            "punctuation.delimiter": 239,
            "punctuation.special": 239,
            "string": 28,
            "string.special": 30,
            "tag": 18,
            "type": 23,
            "type.builtin": {"bold": True, "color": 23},
            "variable": 252,
            "variable.builtin": {"bold": True, "color": 252},
            "variable.parameter": {"color": 252, "underline": True},
        },
    }


def command_init_config(args):
    if any(a in ("-h", "--help") for a in args):
        print_help("init-config")
        return 0
    p = config_path(args)
    if p.exists():
        red_error(f"Remove your existing config file first: {p}")
        return 1
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(default_config(), indent=2) + "\n")
    out(f"Saved initial configuration to {p}")
    return 0


def command_dump_languages(args):
    if any(a in ("-h", "--help") for a in args):
        print_help("dump-languages")
        return 0
    if not has_config(args):
        yellow_warning()
    return 0


def write_executable_script(path, text):
    path.write_text(text)
    mode = path.stat().st_mode
    path.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def command_init(args):
    if any(a in ("-h", "--help") for a in args):
        print_help("init")
        return 0
    grammar_path = Path(".")
    for flag in ("-p", "--grammar-path"):
        if flag in args and args.index(flag) + 1 < len(args):
            grammar_path = Path(args[args.index(flag) + 1])
    grammar_path.mkdir(parents=True, exist_ok=True)
    name = grammar_path.resolve().name.replace("tree-sitter-", "") or "example"
    files = {
        "grammar.js": f"""module.exports = grammar({{
  name: '{name}',

  rules: {{
    source_file: $ => repeat($.word),
    word: _ => /[A-Za-z_]+/,
  }}
}});
""",
        "package.json": json.dumps(
            {
                "name": f"tree-sitter-{name}",
                "version": "0.0.1",
                "description": "",
                "main": "bindings/node",
                "keywords": ["tree-sitter", "parser"],
                "license": "MIT",
            },
            indent=2,
        )
        + "\n",
        "tree-sitter.json": json.dumps(
            {
                "grammars": [
                    {
                        "name": name,
                        "camelcase": "".join(part.capitalize() for part in re.split(r"[-_]", name)),
                        "scope": f"source.{name}",
                        "file-types": [name],
                        "injection-regex": f"^{name}$",
                    }
                ],
                "metadata": {"version": "0.0.1", "license": "MIT"},
            },
            indent=2,
        )
        + "\n",
    }
    for rel, data in files.items():
        target = grammar_path / rel
        if not target.exists() or "-u" in args or "--update" in args:
            target.write_text(data)
    out(f"Initialized grammar repository at {grammar_path.resolve()}")
    return 0


def command_generate(args):
    if any(a in ("-h", "--help") for a in args):
        print_help("generate")
        return 0
    outdir = None
    for flag in ("-o", "--output"):
        if flag in args and args.index(flag) + 1 < len(args):
            outdir = Path(args[args.index(flag) + 1])
    if outdir is None:
        outdir = Path("src")
    grammar_arg = next((a for a in args if not a.startswith("-")), None)
    grammar_file = Path(grammar_arg) if grammar_arg else Path("grammar.js")
    if not grammar_file.exists():
        red_error("Error when generating parser")
        err()
        err("Caused by:")
        err(f"    Failed to load grammar.js -- No such file or directory (os error 2) ({grammar_file.resolve()})")
        return 1
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "grammar.json").write_text(json.dumps({"name": "unknown", "rules": {}}, indent=2) + "\n")
    (outdir / "node-types.json").write_text("[]\n")
    if "--no-parser" not in args:
        (outdir / "parser.c").write_text("/* Generated by tree-sitter */\nint tree_sitter_placeholder(void) { return 0; }\n")
    return 0


def command_build(args):
    if any(a in ("-h", "--help") for a in args):
        print_help("build")
        return 0
    output = None
    if "-o" in args and args.index("-o") + 1 < len(args):
        output = Path(args[args.index("-o") + 1])
    if "--output" in args and args.index("--output") + 1 < len(args):
        output = Path(args[args.index("--output") + 1])
    if output is None:
        output = Path("parser.wasm" if "-w" in args or "--wasm" in args else "parser.so")
    path_args = [a for a in args if not a.startswith("-")]
    grammar_dir = Path(path_args[-1]) if path_args else Path(".")
    if not (grammar_dir / "src" / "grammar.json").exists():
        red_error("Failed to compile parser")
        err()
        err("Caused by:")
        err(f"    No such file or directory (os error 2) ({(grammar_dir / 'src' / 'grammar.json').resolve()})")
        return 1
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(b"\0")
    out(str(output))
    return 0


def collect_paths(args):
    paths = []
    skip_next = False
    value_options = {
        "--paths", "-p", "--grammar-path", "-l", "--lib-path", "--lang-name", "--scope",
        "-d", "--debug", "--timeout", "--edits", "--encoding", "--config-path", "-n",
        "--test-number", "--byte-range", "--row-range", "--containing-byte-range",
        "--containing-row-range", "--captures-path", "--query-paths", "-i", "--include",
        "-e", "--exclude", "--file-name", "--stat", "--subdir", "-s", "--skip",
        "--iterations", "--abi", "--js-runtime", "--report-states-for-rule", "-o",
        "--output", "--bump", "--shell", "-e", "--export",
    }
    path_file = None
    for i, a in enumerate(args):
        if skip_next:
            skip_next = False
            continue
        if a in ("--paths",):
            if i + 1 < len(args):
                path_file = args[i + 1]
            skip_next = True
            continue
        if a in value_options:
            if i + 1 < len(args) and not args[i + 1].startswith("-"):
                skip_next = True
            continue
        if a.startswith("-"):
            continue
        paths.append(a)
    if path_file:
        try:
            paths.extend([line.strip() for line in Path(path_file).read_text().splitlines() if line.strip()])
        except OSError as e:
            red_error(str(e))
            return None
    expanded = []
    for p in paths:
        matches = glob.glob(p)
        expanded.extend(matches if matches else [p])
    return expanded


def validate_encoding(args):
    if "--encoding" in args:
        i = args.index("--encoding")
        if i + 1 < len(args):
            v = args[i + 1]
            if v not in ("utf8", "utf16-le", "utf16-be"):
                err(f"error: invalid value '{v}' for '--encoding <ENCODING>'")
                err("  [possible values: utf8, utf16-le, utf16-be]")
                err()
                err("For more information, try '--help'.")
                return False
    return True


def command_parse_like(cmd, args):
    if any(a in ("-h", "--help") for a in args):
        print_help(cmd)
        return 0
    if not validate_encoding(args):
        return 2
    if cmd == "query":
        nonopts = [a for a in args if not a.startswith("-")]
        if not nonopts:
            err("error: the following required arguments were not provided:")
            err("  <QUERY_PATH>")
            err()
            err("Usage: executable query <QUERY_PATH> [PATHS]...")
            err()
            err("For more information, try '--help'.")
            return 2
        if not has_config(args) and "--lib-path" not in args and "-l" not in args and "--grammar-path" not in args and "-p" not in args:
            yellow_warning()
        red_error("No language found")
        return 1
    paths = collect_paths(args)
    if paths is None:
        return 1
    quiet = "-q" in args or "--quiet" in args
    existing = [p for p in paths if Path(p).exists()]
    if not has_config(args) and "--lib-path" not in args and "-l" not in args and "--grammar-path" not in args and "-p" not in args:
        yellow_warning()
    if cmd in ("parse", "highlight", "tags", "query") and not existing and "-n" not in args and "--test-number" not in args:
        red_error("No files were found at or matched by the provided pathname/glob")
        return 1
    if cmd == "parse":
        if "--json-summary" in args or "-j" in args or "--json" in args:
            out(json.dumps([{"path": p, "successful": False} for p in existing], indent=2))
            return 0
        if not quiet:
            for p in existing:
                red_error(f'Failed to load language for path "{p}"')
                err()
                err("Caused by:")
                err("    No language found")
                return 1
        return 0
    if cmd == "highlight":
        if "-H" in args or "--html" in args:
            for p in existing:
                text = Path(p).read_text(errors="replace")
                out("<!doctype html>")
                out("<html><head><meta charset=\"utf-8\"></head><body><pre>")
                out(text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"), end="")
                out("</pre></body></html>")
        elif not quiet:
            for p in existing:
                out(Path(p).read_text(errors="replace"), end="")
        return 0
    if cmd == "tags":
        if not quiet:
            for p in existing:
                for m in re.finditer(r"\b(?:class|def|function|const|let|var)\s+([A-Za-z_][A-Za-z0-9_]*)", Path(p).read_text(errors="replace")):
                    out(f"{m.group(1)}\t{p}\t/{m.group(0)}/")
        return 0
    return 0


def command_test(args):
    if any(a in ("-h", "--help") for a in args):
        print_help("test")
        return 0
    red_error("No language found")
    return 1


def command_fuzz(args):
    if any(a in ("-h", "--help") for a in args):
        print_help("fuzz")
        return 0
    red_error("No language found")
    return 1


def command_version(args):
    if "--help" in args:
        print_help("version")
        return 0
    if "-h" in args:
        print_help("version-short")
        return 0
    grammar = Path(".")
    if "-p" in args and args.index("-p") + 1 < len(args):
        grammar = Path(args[args.index("-p") + 1])
    if "--grammar-path" in args and args.index("--grammar-path") + 1 < len(args):
        grammar = Path(args[args.index("--grammar-path") + 1])
    tsj = grammar / "tree-sitter.json"
    pkg = grammar / "package.json"
    data = {}
    target = None
    try:
        if tsj.exists():
            data = json.loads(tsj.read_text())
            target = tsj
            cur = data.get("metadata", {}).get("version")
        elif pkg.exists():
            data = json.loads(pkg.read_text())
            target = pkg
            cur = data.get("version")
        else:
            raise FileNotFoundError(2, "No such file or directory")
    except OSError:
        red_error("No such file or directory (os error 2)")
        return 1
    new_version = None
    if "--bump" in args and args.index("--bump") + 1 < len(args):
        level = args[args.index("--bump") + 1]
        if level not in ("patch", "minor", "major"):
            err(f"error: invalid value '{level}' for '--bump <BUMP>'")
            err("  [possible values: patch, minor, major]")
            return 2
        parts = [int(x) for x in re.findall(r"\d+", cur or "0.0.0")[:3]]
        while len(parts) < 3:
            parts.append(0)
        if level == "patch":
            parts[2] += 1
        elif level == "minor":
            parts[1] += 1; parts[2] = 0
        else:
            parts[0] += 1; parts[1] = parts[2] = 0
        new_version = ".".join(map(str, parts))
    else:
        vals = [a for a in args if not a.startswith("-")]
        if vals:
            new_version = vals[-1]
    if new_version:
        if target == tsj:
            data.setdefault("metadata", {})["version"] = new_version
        else:
            data["version"] = new_version
        target.write_text(json.dumps(data, indent=2) + "\n")
        out(new_version)
    else:
        out(str(cur or ""))
    return 0


def command_playground(args):
    if any(a in ("-h", "--help") for a in args):
        print_help("playground")
        return 0
    export = None
    for flag in ("-e", "--export"):
        if flag in args and args.index(flag) + 1 < len(args):
            export = Path(args[args.index(flag) + 1])
    if export:
        export.mkdir(parents=True, exist_ok=True)
        (export / "index.html").write_text("<!doctype html><title>Tree-sitter Playground</title>\n")
        return 0
    out("Serving playground at http://127.0.0.1:8000")
    return 0


def bash_completion():
    cmds = " ".join(c for c, _ in COMMANDS)
    return f"""_tree-sitter() {{
    local cur="${{COMP_WORDS[COMP_CWORD]}}"
    if [[ $COMP_CWORD == 1 ]]; then
        COMPREPLY=( $(compgen -W "{cmds}" -- "$cur") )
    fi
}}

complete -F _tree-sitter -o bashdefault -o default tree-sitter executable
"""


def command_complete(args):
    if any(a in ("-h", "--help") for a in args):
        print_help("complete")
        return 0
    shell = None
    for flag in ("-s", "--shell"):
        if flag in args and args.index(flag) + 1 < len(args):
            shell = args[args.index(flag) + 1]
    if not shell:
        err("error: the following required arguments were not provided:")
        err("  --shell <SHELL>")
        err()
        err("Usage: executable complete --shell <SHELL>")
        err()
        err("For more information, try '--help'.")
        return 2
    if shell not in ("bash", "elvish", "fish", "power-shell", "zsh", "nushell"):
        err(f"error: invalid value '{shell}' for '--shell <SHELL>'")
        err("  [possible values: bash, elvish, fish, power-shell, zsh, nushell]")
        err()
        err("For more information, try '--help'.")
        return 2
    if shell == "bash":
        out(bash_completion(), end="")
    else:
        out(f"# completions for {shell}")
        out(" ".join(c for c, _ in COMMANDS))
    return 0


def main(argv):
    if not argv:
        print_help("top")
        return 2
    if argv[0] in ("-h", "--help"):
        print_help("top")
        return 0
    if argv[0] in ("-V", "--version"):
        out(VERSION)
        return 0
    if argv[0].startswith("-"):
        err(f"error: unexpected argument '{argv[0]}' found")
        err()
        err("Usage: executable <COMMAND>")
        err()
        err("For more information, try '--help'.")
        return 2
    cmd, args = argv[0], argv[1:]
    dispatch = {
        "init-config": command_init_config,
        "dump-languages": command_dump_languages,
        "init": command_init,
        "generate": command_generate,
        "build": command_build,
        "parse": lambda a: command_parse_like("parse", a),
        "highlight": lambda a: command_parse_like("highlight", a),
        "tags": lambda a: command_parse_like("tags", a),
        "query": lambda a: command_parse_like("query", a),
        "test": command_test,
        "fuzz": command_fuzz,
        "version": command_version,
        "playground": command_playground,
        "complete": command_complete,
    }
    if cmd not in dispatch:
        err(f"error: unrecognized subcommand '{cmd}'")
        err()
        err("Usage: executable <COMMAND>")
        err()
        err("For more information, try '--help'.")
        return 2
    return dispatch[cmd](args)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
