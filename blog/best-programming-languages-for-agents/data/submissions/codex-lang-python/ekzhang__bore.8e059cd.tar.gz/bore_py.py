#!/usr/bin/env python3
import argparse
import asyncio
import json
import os
import signal
import socket
import sys
import time
import uuid

CONTROL_PORT = 7835
VERSION = "bore-cli 0.6.0"


def log(level, target, message, **fields):
    ts = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())
    suffix = "".join(f" {k}={v}" for k, v in fields.items())
    print(f"{ts} {level.upper()} {target}: {message}{suffix}", flush=True)


async def read_json(reader):
    line = await reader.readline()
    if not line:
        return None
    return json.loads(line.decode("utf-8"))


async def write_json(writer, obj):
    writer.write((json.dumps(obj, separators=(",", ":")) + "\n").encode("utf-8"))
    await writer.drain()


async def pipe_stream(src, dst):
    try:
        while True:
            data = await src.read(65536)
            if not data:
                break
            dst.write(data)
            await dst.drain()
    except (ConnectionError, OSError, asyncio.CancelledError):
        pass
    finally:
        try:
            dst.close()
            await dst.wait_closed()
        except Exception:
            pass


async def bidirectional(a_reader, a_writer, b_reader, b_writer):
    t1 = asyncio.create_task(pipe_stream(a_reader, b_writer))
    t2 = asyncio.create_task(pipe_stream(b_reader, a_writer))
    await asyncio.wait({t1, t2}, return_when=asyncio.FIRST_COMPLETED)
    for task in (t1, t2):
        task.cancel()
    await asyncio.gather(t1, t2, return_exceptions=True)


def split_host_port(value):
    if value.startswith("[") and "]" in value:
        host, _, rest = value[1:].partition("]")
        if rest.startswith(":"):
            return host, int(rest[1:])
        return host, CONTROL_PORT
    if value.count(":") == 1:
        host, port = value.rsplit(":", 1)
        if port.isdigit():
            return host, int(port)
    return value, CONTROL_PORT


class BoreServer:
    def __init__(self, args):
        self.min_port = args.min_port
        self.max_port = args.max_port
        self.secret = args.secret
        self.bind_addr = args.bind_addr
        self.bind_tunnels = args.bind_tunnels or args.bind_addr
        self.sessions = {}
        self.pending = {}
        self.tunnel_servers = {}

    async def start(self):
        server = await asyncio.start_server(self.handle_control, self.bind_addr, CONTROL_PORT)
        log("info", "bore_cli::server", "server listening", addr=self.bind_addr)
        async with server:
            await server.serve_forever()

    async def handle_control(self, reader, writer):
        peer = writer.get_extra_info("peername")
        log("info", "bore_cli::server", "incoming connection", addr=fmt_peer(peer))
        try:
            hello = await read_json(reader)
            if not hello:
                return
            if self.secret is not None and hello.get("secret") != self.secret:
                await write_json(writer, {"status": "error", "error": "authentication failed"})
                return
            cmd = hello.get("cmd")
            if cmd == "init":
                await self.init_session(hello, reader, writer)
                return
            if cmd == "data":
                await self.forward_data(hello, reader, writer)
                return
            await write_json(writer, {"status": "error", "error": "invalid command"})
        except Exception as exc:
            log("warn", "bore_cli::server", "connection exited with error", err=exc)
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    async def init_session(self, hello, reader, writer):
        requested = int(hello.get("port") or 0)
        port = await self.choose_port(requested)
        sid = uuid.uuid4().hex
        queue = asyncio.Queue()
        self.sessions[sid] = {"writer": writer, "port": port, "queue": queue}
        tunnel = await asyncio.start_server(
            lambda r, w, sid=sid: self.handle_tunnel_client(sid, r, w),
            self.bind_tunnels,
            port,
        )
        self.tunnel_servers[sid] = tunnel
        await write_json(writer, {"status": "ok", "port": port, "host": self.bind_tunnels, "session": sid})
        log("info", "bore_cli::server", "new client", host=self.bind_tunnels, port=port)
        try:
            await reader.read()
        finally:
            tunnel.close()
            await tunnel.wait_closed()
            self.sessions.pop(sid, None)
            self.tunnel_servers.pop(sid, None)
            log("info", "bore_cli::server", "connection exited")

    async def choose_port(self, requested):
        if requested:
            if requested < self.min_port or requested > self.max_port:
                raise RuntimeError(f"requested port {requested} outside allowed range")
            return requested
        for port in range(self.min_port, self.max_port + 1):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    s.bind((self.bind_tunnels, port))
                except OSError:
                    continue
                return port
        raise RuntimeError("no available ports")

    async def handle_tunnel_client(self, sid, reader, writer):
        session = self.sessions.get(sid)
        if not session:
            writer.close()
            return
        cid = str(uuid.uuid4())
        fut = asyncio.get_running_loop().create_future()
        self.pending[cid] = fut
        peer = writer.get_extra_info("peername")
        log("info", "bore_cli::server", "new connection", addr=fmt_peer(peer), port=session["port"])
        try:
            await write_json(session["writer"], {"cmd": "connect", "id": cid})
            data_reader, data_writer = await asyncio.wait_for(fut, timeout=10)
            await bidirectional(reader, writer, data_reader, data_writer)
        except Exception as exc:
            log("warn", "bore_cli::server", "connection exited with error", err=exc)
        finally:
            self.pending.pop(cid, None)
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    async def forward_data(self, hello, reader, writer):
        cid = hello.get("id")
        fut = self.pending.get(cid)
        if fut is None or fut.done():
            await write_json(writer, {"status": "error", "error": "unknown connection"})
            return
        await write_json(writer, {"status": "ok"})
        fut.set_result((reader, writer))
        await asyncio.Future()


class BoreClient:
    def __init__(self, args):
        self.local_host = args.local_host
        self.local_port = args.local_port
        self.remote_host, self.remote_control_port = split_host_port(args.to)
        self.remote_port = args.port
        self.secret = args.secret
        self.control_reader = None
        self.control_writer = None

    async def start(self):
        self.control_reader, self.control_writer = await asyncio.open_connection(
            self.remote_host, self.remote_control_port
        )
        await write_json(
            self.control_writer,
            {"cmd": "init", "port": self.remote_port, "secret": self.secret},
        )
        resp = await read_json(self.control_reader)
        if not resp or resp.get("status") != "ok":
            raise RuntimeError((resp or {}).get("error", "server rejected request"))
        port = resp["port"]
        host = self.remote_host
        log("info", "bore_cli::client", "connected to server", remote_port=port)
        log("info", "bore_cli::client", "listening at", addr=f"{host}:{port}")
        while True:
            msg = await read_json(self.control_reader)
            if not msg:
                break
            if msg.get("cmd") == "connect":
                asyncio.create_task(self.handle_proxy(msg["id"]))

    async def handle_proxy(self, cid):
        log("info", "bore_cli::client", "new connection", id=cid)
        try:
            local_reader, local_writer = await asyncio.open_connection(self.local_host, self.local_port)
            data_reader, data_writer = await asyncio.open_connection(self.remote_host, self.remote_control_port)
            await write_json(data_writer, {"cmd": "data", "id": cid, "secret": self.secret})
            resp = await read_json(data_reader)
            if not resp or resp.get("status") != "ok":
                raise RuntimeError((resp or {}).get("error", "server rejected data connection"))
            await bidirectional(local_reader, local_writer, data_reader, data_writer)
        except Exception as exc:
            log("warn", "bore_cli::client", "connection exited with error", err=exc)
        finally:
            log("info", "bore_cli::client", "connection exited", id=cid)


def fmt_peer(peer):
    if not peer:
        return ""
    if isinstance(peer, tuple):
        return f"{peer[0]}:{peer[1]}"
    return str(peer)


class Parser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        self.exit(2, f"error: {message}\n")


def build_parser():
    p = Parser(
        prog="executable",
        description="A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls.",
    )
    p.add_argument("-V", "--version", action="store_true", help="Print version")
    sub = p.add_subparsers(dest="command")

    local = sub.add_parser("local", help="Starts a local proxy to the remote server")
    local.add_argument("local_port", metavar="LOCAL_PORT", type=int, nargs="?", default=env_int("BORE_LOCAL_PORT"))
    local.add_argument("-l", "--local-host", default="localhost")
    local.add_argument("-t", "--to", default=os.environ.get("BORE_SERVER"))
    local.add_argument("-p", "--port", type=int, default=0)
    local.add_argument("-s", "--secret", default=os.environ.get("BORE_SECRET"))

    server = sub.add_parser("server", help="Runs the remote proxy server")
    server.add_argument("--min-port", type=int, default=env_int("BORE_MIN_PORT", 1024))
    server.add_argument("--max-port", type=int, default=env_int("BORE_MAX_PORT", 65535))
    server.add_argument("-s", "--secret", default=os.environ.get("BORE_SECRET"))
    server.add_argument("--bind-addr", default="0.0.0.0")
    server.add_argument("--bind-tunnels")
    return p


def env_int(name, default=None):
    value = os.environ.get(name)
    if value in (None, ""):
        return default
    return int(value)


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    if argv == ["--help"] or argv == ["-h"]:
        print("""A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls.

Usage: executable <COMMAND>

Commands:
  local   Starts a local proxy to the remote server
  server  Runs the remote proxy server
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version""")
        return 0
    if argv in (["local", "--help"], ["local", "-h"], ["help", "local"]):
        print("""Starts a local proxy to the remote server

Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>

Arguments:
  <LOCAL_PORT>  The local port to expose [env: BORE_LOCAL_PORT=]

Options:
  -l, --local-host <HOST>  The local host to expose [default: localhost]
  -t, --to <TO>            Address of the remote server to expose local ports to [env: BORE_SERVER=]
  -p, --port <PORT>        Optional port on the remote server to select [default: 0]
  -s, --secret <SECRET>    Optional secret for authentication [env: BORE_SECRET]
  -h, --help               Print help""")
        return 0
    if argv in (["server", "--help"], ["server", "-h"], ["help", "server"]):
        print("""Runs the remote proxy server

Usage: executable server [OPTIONS]

Options:
      --min-port <MIN_PORT>          Minimum accepted TCP port number [env: BORE_MIN_PORT=] [default: 1024]
      --max-port <MAX_PORT>          Maximum accepted TCP port number [env: BORE_MAX_PORT=] [default: 65535]
  -s, --secret <SECRET>              Optional secret for authentication [env: BORE_SECRET]
      --bind-addr <BIND_ADDR>        IP address to bind to, clients must reach this [default: 0.0.0.0]
      --bind-tunnels <BIND_TUNNELS>  IP address where tunnels will listen on, defaults to --bind-addr
  -h, --help                         Print help""")
        return 0
    if len(argv) == 1 and argv[0] not in ("local", "server", "--version", "-V"):
        print(f"error: unrecognized subcommand '{argv[0]}'\n", file=sys.stderr)
        print("Usage: executable <COMMAND>\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        return 2
    if argv and argv[0] == "help":
        argv = argv[1:] + ["--help"] if len(argv) > 1 else ["--help"]
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.version:
        print(VERSION)
        return 0
    if args.command == "local":
        if args.local_port is None:
            parser.error("the following required arguments were not provided: LOCAL_PORT")
        if args.to is None:
            parser.error("the following required arguments were not provided: --to <TO>")
        return run_async(BoreClient(args).start())
    if args.command == "server":
        return run_async(BoreServer(args).start())
    parser.print_help()
    return 0


def run_async(coro):
    try:
        asyncio.run(coro)
        return 0
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr, flush=True)
        return 1


if __name__ == "__main__":
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    raise SystemExit(main())
