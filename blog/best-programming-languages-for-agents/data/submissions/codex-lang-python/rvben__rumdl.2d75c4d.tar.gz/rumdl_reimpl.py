#!/usr/bin/env python3
import argparse, json, os, re, sys, fnmatch, difflib
from pathlib import Path

VERSION='rumdl 0.1.13'
RULES = [
('MD001','Heading levels should only increment by one level at a time','heading-increment','heading',True),
('MD003','Heading style','heading-style','heading',True),
('MD004','Use consistent style for unordered list markers','ul-style','list',True),
('MD005','List indentation should be consistent','list-indent','list',False),
('MD007','Unordered list indentation','ul-indent','list',True),
('MD009','Trailing spaces should be removed','no-trailing-spaces','whitespace',True),
('MD010','No tabs','no-hard-tabs','whitespace',True),
('MD011','Reversed link syntax','no-reversed-links','link',True),
('MD012','Multiple consecutive blank lines','no-multiple-blanks','other',True),
('MD013','Line length should not be excessive','line-length','whitespace',True),
('MD014','Commands in code blocks should show output','commands-show-output','code-block',False),
('MD018','No space after hash in heading','no-missing-space-atx','heading',True),
('MD019','Multiple spaces after hash in heading','no-multiple-space-atx','heading',True),
('MD020','No space inside hashes on closed heading','no-missing-space-closed-atx','heading',True),
('MD021','Multiple spaces inside hashes on closed heading','no-multiple-space-closed-atx','heading',True),
('MD022','Headings should be surrounded by blank lines','blanks-around-headings','heading',True),
('MD023','Headings must start at the beginning of the line','heading-start-left','heading',True),
('MD024','Multiple headings with the same content','no-duplicate-heading','heading',False),
('MD025','Multiple top-level headings in the same document','single-h1','heading',True),
('MD026','Trailing punctuation in heading','no-trailing-punctuation','heading',True),
('MD027','Multiple spaces after quote marker (>)','no-multiple-space-blockquote','blockquote',True),
('MD028','Blank line inside blockquote','no-blanks-blockquote','blockquote',False),
('MD029','Ordered list marker value','ol-prefix','list',True),
('MD030','Spaces after list markers should be consistent','list-marker-space','list',True),
('MD031','Fenced code blocks should be surrounded by blank lines','blanks-around-fences','code-block',True),
('MD032','Lists should be surrounded by blank lines','blanks-around-lists','list',True),
('MD033','Inline HTML is not allowed','no-inline-html','html',False),
('MD034','No bare URLs - wrap URLs in angle brackets','no-bare-urls','link',True),
('MD035','Horizontal rule style','hr-style','other',True),
('MD036','Emphasis should not be used instead of a heading','no-emphasis-as-heading','emphasis',False),
('MD037','Spaces inside emphasis markers','no-space-in-emphasis','other',True),
('MD038','Spaces inside code span elements','no-space-in-code','other',True),
('MD039','Spaces inside link text','no-space-in-links','link',True),
('MD040','Code blocks should have a language specified','fenced-code-language','code-block',True),
('MD041','First line in file should be a top level heading','first-line-h1','heading',False),
('MD042','No empty links','no-empty-links','link',False),
('MD043','Required heading structure','required-headings','heading',False),
('MD044','Proper names should have the correct capitalization','proper-names','other',False),
('MD045','Images should have alternate text (alt text)','no-alt-text','link',False),
('MD046','Code blocks should use a consistent style','code-block-style','code-block',True),
('MD047','Files should end with a single newline character','single-trailing-newline','other',True),
('MD048','Code fence style should be consistent','code-fence-style','code-block',True),
('MD049','Emphasis style should be consistent','emphasis-style','other',True),
('MD050','Strong emphasis style should be consistent','strong-style','other',True),
('MD051','Link fragments should reference valid headings','link-fragments','link',False),
('MD052','Reference links and images should use a reference that exists','reference-links-images','link',False),
('MD053','Link and image reference definitions should be needed','link-image-reference-definitions','link',True),
('MD054','Link and image style should be consistent','link-image-style','link',False),
('MD055','Table pipe style should be consistent','table-pipe-style','other',True),
('MD056','Table column count should be consistent','table-column-count','other',False),
('MD057','Relative links should point to existing files','no-missing-linked-files','link',False),
('MD058','Tables should be surrounded by blank lines','blanks-around-tables','other',True),
('MD059','Link text should be descriptive','descriptive-link-text','link',False),
('MD060','Table columns should be consistently aligned','table-format','other',True),
('MD061','Forbidden terms','forbidden-terms','other',False),
('MD062','Link destination should not have leading or trailing whitespace','no-space-in-link-dest','link',True),
('MD063','Heading capitalization','heading-capitalization','heading',True),
('MD064','Multiple consecutive spaces','no-multiple-spaces','whitespace',True),
('MD065','Horizontal rules should be surrounded by blank lines','blanks-around-hr','other',True),
('MD066','Footnote validation','footnote-reference-valid','other',False),
('MD067','Footnote definitions should appear in order of first reference','footnote-definition-order','other',False),
('MD068','Footnote definitions should not be empty','footnote-definition-not-empty','other',False),
('MD069','Duplicate list markers','no-duplicate-list-markers','list',True),
('MD070','Nested code fence collision - use longer fence to avoid premature closure','nested-code-fence','code-block',False),
('MD071','Blank line after frontmatter','blanks-after-frontmatter','other',True),
('MD072','Frontmatter keys should be sorted alphabetically','frontmatter-key-sort','front-matter',True),
('MD073','Table of Contents should match document headings','toc','other',False),
]
RULEMAP={r[0]:r for r in RULES}; NAME_TO_ID={r[2]:r[0] for r in RULES}; OPT_IN={'MD060','MD063','MD072','MD073'}
ALIASES={'single-title':'MD025'}
ERRORS={'MD001','MD011','MD024','MD025','MD042','MD045','MD051','MD057','MD066','MD068'}

def norm_rule(s):
    s=s.strip().upper().replace('_','-')
    if re.fullmatch(r'MD\d{1,3}',s): return 'MD'+s[2:].zfill(3)
    lo=s.lower(); return NAME_TO_ID.get(lo) or ALIASES.get(lo) or s

def split_rules(s):
    if not s: return []
    out=[]
    for x in re.split(r'[,\s]+',s):
        if x: out.append(norm_rule(x))
    return out

class Diag:
    def __init__(self,file,line,col,rule,msg,fixable=False):
        self.file=file; self.line=line; self.col=col; self.rule=rule; self.msg=msg; self.fixable=fixable
    def d(self):
        return {'file':self.file,'line':self.line,'column':self.col,'rule':self.rule,'message':self.msg,'severity':'error' if self.rule in ERRORS else 'warning','fixable':bool(self.fixable),'fix':None}

def is_blank(s): return s.strip()==''
def is_fence(s): return re.match(r'^[ \t]*(```+|~~~+)',s) is not None
def heading(line):
    m=re.match(r'^(#{1,6})(\s+|$)(.*?)(?:\s+#+\s*)?$',line.strip())
    if m: return (len(m.group(1)), m.group(3).strip())
    return None
def any_heading(line):
    return re.match(r'^\s*#{1,6}.*$',line) is not None
def list_item(line):
    return re.match(r'^(\s*)([-+*]|\d+[.)])\s+',line)
def hr(line): return re.match(r'^\s{0,3}([-*_])(?:\s*\1){2,}\s*$',line) is not None
def table_line(line): return '|' in line and not is_fence(line)
def slug(s):
    s=re.sub(r'<[^>]+>','',s.lower())
    s=re.sub(r'[^a-z0-9 _-]','',s).strip().replace(' ','-')
    s=re.sub(r'-+','-',s)
    return s

def line_offsets(text):
    offs=[]; p=0
    for line in text.splitlines(True): offs.append(p); p+=len(line)
    if not offs: offs=[0]
    return offs

def lint_text(text, filename='<stdin>', enabled=None, line_length=80):
    lines=text.splitlines(True)
    bare=[l[:-1] if l.endswith('\n') else l for l in lines]
    if text=='' or (not lines): bare=[]
    di=[]; in_code=False; fence_char=''; headings=[]; h1=0; prev_h=0; refs=set(); refdefs=set(); footrefs=[]; footdefs={}
    enabled = set(enabled) if enabled else set(r[0] for r in RULES) - OPT_IN
    def add(rule,i,col,msg=None,fix=True):
        if rule in enabled: di.append(Diag(filename,i+1,col,rule,msg or RULEMAP[rule][1],fix and RULEMAP[rule][4]))
    # MD047 raw newline
    if 'MD047' in enabled and text and not text.endswith('\n'):
        add('MD047',max(len(bare)-1,0),len(bare[-1])+1,'File should end with a single newline character',True)
    if 'MD041' in enabled:
        first=None
        for idx,l in enumerate(bare):
            if idx==0 and l.startswith('\ufeff'): l=l[1:]
            if l.strip()=='' or l.strip()=='---' or l.strip().startswith('<!--'): continue
            first=(idx,l); break
        if first and not re.match(r'^#\s+', first[1].lstrip()): add('MD041',first[0],1,'First line in file should be a level 1 heading',False)
    blank_run=0
    for i,l in enumerate(bare):
        raw=l
        # fence state later but many whitespace outside only
        if 'MD009' in enabled and re.search(r'[ \t]+$', raw) and not (re.search(r'  $',raw) and len(re.search(r'( +)$',raw).group(1))==2):
            n=len(raw)-len(raw.rstrip(' \t'))
            add('MD009',i,len(raw.rstrip(' \t'))+1,f'{n} trailing space{"s" if n != 1 else ""} found',True)
        if 'MD010' in enabled and '\t' in raw:
            col=raw.index('\t')+1; msg='Found leading tab, use 4 spaces instead' if raw.startswith('\t') else 'Found tab character, use spaces instead'; add('MD010',i,col,msg,True)
        if is_blank(raw):
            blank_run+=1
            if blank_run>1: add('MD012',i,1,'Multiple consecutive blank lines at end of file' if all(is_blank(x) for x in bare[i:]) else 'Multiple consecutive blank lines between content',True)
        else: blank_run=0
        m=re.match(r'^(\s*)(#{1,6})(.*)$',raw)
        if m and not in_code:
            if m.group(1): add('MD023',i,1,'Headings must start at the beginning of the line',True)
            rest=m.group(3)
            if rest and not rest.startswith(' '): add('MD018',i,len(m.group(1))+len(m.group(2))+1,f'No space after {m.group(2)} in heading',True)
            elif re.match(r'  +\S', rest): add('MD019',i,len(m.group(1))+len(m.group(2))+1,'Multiple spaces after hash in heading',True)
            h=heading(raw)
            if h:
                level,title=h; headings.append((level,title,i));
                if prev_h and level>prev_h+1: add('MD001',i,1,f'Expected heading level {prev_h+1}, but found heading level {level}',True)
                prev_h=level
                if level==1:
                    h1+=1
                    if h1>1: add('MD025',i,len(m.group(1))+1,'Multiple top-level headings (level 1) in the same document',True)
                if 'MD022' in enabled:
                    if i>0 and not is_blank(bare[i-1]): add('MD022',i,1,'Expected 1 blank line above heading',True)
                    if i+1<len(bare) and not is_blank(bare[i+1]): add('MD022',i,1,'Expected 1 blank line below heading',True)
                pm=re.search(r'([.,;:!?。，；：！？])$', title)
                if pm: add('MD026',i,len(raw.rstrip()),f"Heading '{title}' ends with punctuation '{pm.group(1)}'",True)
        if not in_code and len(raw)>line_length and not table_line(raw): add('MD013',i,line_length+1,f'Line length [{len(raw)}] exceeds {line_length} characters',True)
        if not in_code:
            if re.search(r'\]\s*\[', raw):
                pass
            for m2 in re.finditer(r'\(([^\)]+)\)\[([^\]]*)\]',raw): add('MD011',i,m2.start()+1,f'Reversed link syntax: use [{m2.group(2)}]({m2.group(1)}) instead',True)
            for m2 in re.finditer(r'!\[\]\([^\)]*\)',raw): add('MD045',i,m2.start()+1,'Image missing alt text (add description for accessibility: ![description](url))',True)
            for m2 in re.finditer(r'\[[^\]]*\]\(\s*\)',raw): add('MD042',i,m2.start()+1,f'Empty link found: {m2.group(0)}',False)
            for m2 in re.finditer(r'\[\s+[^\]]*\]|\[[^\]]*\s+\]',raw): add('MD039',i,m2.start()+1,'Spaces inside link text',True)
            for m2 in re.finditer(r'(?<![<\(])https?://[^\s)>]+',raw): add('MD034',i,m2.start()+1,'Bare URL used',True)
            hm=re.search(r'<[A-Za-z][^>]*>',raw)
            if hm: add('MD033',i,hm.start()+1,f'Inline HTML found: {hm.group(0)}',False)
            for m2 in re.finditer(r'`\s+[^`]*`|`[^`]*\s+`',raw): add('MD038',i,m2.start()+1,'Spaces inside code span elements',True)
            for m2 in re.finditer(r'(\*|_)\s+[^\1]+\s+\1',raw): add('MD037',i,m2.start()+1,'Spaces inside emphasis markers',True)
            if re.search(r'\S  +\S', raw) and not re.match(r'^\s*[-+*]\s+',raw): add('MD064',i,raw.find('  ')+1,'Multiple consecutive spaces',True)
            if re.match(r'^>  +\S',raw): add('MD027',i,2,'Multiple spaces after quote marker (>)',True)
            if re.match(r'^\s*[-+*]\s+[-+*]\s+',raw): add('MD069',i,raw.find(raw.strip()[2])+1,'Duplicate list marker',True)
            li=list_item(raw)
            if li:
                spaces=len(li.group(0))-len(li.group(1))-len(li.group(2))
                if spaces!=1: add('MD030',i,len(li.group(1))+len(li.group(2))+1,'Spaces after list markers should be consistent',True)
                if i>0 and not is_blank(bare[i-1]) and not list_item(bare[i-1]): add('MD032',i,1,'List should be preceded by blank line',True)
                if i+1<len(bare) and not is_blank(bare[i+1]) and not list_item(bare[i+1]) and not bare[i+1].startswith('  '): add('MD032',i,1,'List should be followed by blank line',True)
            if hr(raw):
                if 'MD065' in enabled:
                    if i>0 and not is_blank(bare[i-1]): add('MD065',i,1,'Horizontal rules should be surrounded by blank lines',True)
                    if i+1<len(bare) and not is_blank(bare[i+1]): add('MD065',i,1,'Horizontal rules should be surrounded by blank lines',True)
        if is_fence(raw):
            marker=re.match(r'^\s*(```+|~~~+)(.*)$',raw); info=marker.group(2).strip() if marker else ''
            if not in_code:
                if not info: add('MD040',i,1,f'Code block ({marker.group(1)}) missing language',True)
                if i>0 and not is_blank(bare[i-1]): add('MD031',i,1,'Fenced code blocks should be surrounded by blank lines',True)
                in_code=True; fence_char=marker.group(1)[0]
            else:
                if i+1<len(bare) and not is_blank(bare[i+1]): add('MD031',i,1,'Fenced code blocks should be surrounded by blank lines',True)
                in_code=False
        for m3 in re.finditer(r'\[\^([^\]]+)\]',raw): footrefs.append((m3.group(1),i,m3.start()+1))
        mdef=re.match(r'^\[\^([^\]]+)\]:\s*(.*)$',raw)
        if mdef:
            footdefs[mdef.group(1)]=(i,mdef.group(2))
            if not mdef.group(2).strip(): add('MD068',i,1,'Footnote definitions should not be empty',False)
        mrefdef=re.match(r'^\s*\[([^\]]+)\]:\s+',raw)
        if mrefdef: refdefs.add(mrefdef.group(1).lower())
        for mref in re.finditer(r'(?<!!)\[[^\]]+\]\[([^\]]*)\]',raw):
            if mref.group(1): refs.add((mref.group(1).lower(),i,mref.start()+1))
    # post checks
    seen={}
    for level,title,i in headings:
        key=(level, re.sub(r'\s+',' ',title.lower()))
        if key in seen: add('MD024',i,level+1,f"Duplicate heading: '{title}'.",False)
        seen[key]=i
    slugs={slug(t) for _,t,_ in headings}
    for i,l in enumerate(bare):
        for m in re.finditer(r'\[[^\]]+\]\(#([^\)]+)\)',l):
            if m.group(1) not in slugs: add('MD051',i,m.start()+1,'Link fragments should reference valid headings',False)
    for ref,i,c in refs:
        if ref not in refdefs: add('MD052',i,c,'Reference links and images should use a reference that exists',False)
    for name,i,c in footrefs:
        if name not in footdefs: add('MD066',i,c,'Undefined footnote reference',False)
    di.sort(key=lambda x:(x.file,x.line,x.col,x.rule))
    return di

def fix_text(text, enabled=None, line_length=80):
    lines=text.splitlines(True)
    out=[]; blank=0
    for line in lines:
        nl='\n' if line.endswith('\n') else ''
        s=line[:-1] if nl else line
        s=s.replace('\t','    ')
        s=re.sub(r'[ \t]+$','',s)
        s=re.sub(r'^(\s*#{1,6})(\S)',r'\1 \2',s)
        s=re.sub(r'^(\s*#{1,6}) {2,}',r'\1 ',s)
        s=re.sub(r'^(> ) {1,}',r'\1',s)
        s=re.sub(r'^\s*([-+*])\s+([-+*])\s+',r'\1 ',s)
        if s.strip()=='':
            blank+=1
            if blank>1: continue
        else: blank=0
        out.append(s+'\n')
    res=''.join(out).rstrip('\n')+'\n' if out else ''
    return res

def load_config(path=None):
    cfg={'disable':[],'enable':[],'line_length':80,'exclude':[]}
    p=None
    if path: p=Path(path)
    else:
        for cand in ['.rumdl.toml','rumdl.toml','pyproject.toml']:
            if Path(cand).exists(): p=Path(cand); break
    if not p or not p.exists(): return cfg,None
    txt=p.read_text(errors='ignore')
    def arr(key):
        m=re.search(r'(?m)^\s*'+re.escape(key)+r'\s*=\s*\[(.*?)\]',txt,re.S)
        if m: return re.findall(r'["\']([^"\']+)["\']',m.group(1))
        return []
    cfg['disable']=arr('disable'); cfg['enable']=arr('enable'); cfg['exclude']=arr('exclude')
    m=re.search(r'(?m)^\s*(?:line_length|line-length)\s*=\s*(\d+)',txt)
    if m: cfg['line_length']=int(m.group(1))
    return cfg,p

def collect_paths(paths, excludes):
    if not paths: paths=['.']
    files=[]
    for p in paths:
        if p=='-': return ['-']
        pp=Path(p)
        if pp.is_dir():
            for root,dirs,names in os.walk(pp):
                dirs[:] = [d for d in dirs if d not in {'.git','.rumdl_cache','node_modules'}]
                for n in names:
                    if n.lower().endswith(('.md','.markdown','.mdown','.mkd','.mkdn','.mdx','.qmd')):
                        f=str(Path(root)/n)
                        if any(fnmatch.fnmatch(f,pat) or fnmatch.fnmatch(n,pat) for pat in excludes): continue
                        files.append(f)
        elif pp.exists(): files.append(str(pp))
        else:
            print(f'Error: Path not found: {p}',file=sys.stderr); return []
    return sorted(dict.fromkeys(files))

def active_rules(args,cfg):
    allrules=set(r[0] for r in RULES)-OPT_IN
    en=split_rules(getattr(args,'enable','') or '') or [norm_rule(x) for x in cfg.get('enable',[])]
    if en: active=set(en)
    else: active=set(allrules)
    dis=split_rules(getattr(args,'disable','') or '')+[norm_rule(x) for x in cfg.get('disable',[])]
    dis+=split_rules(getattr(args,'extend_disable','') or '')
    active-=set(dis)
    active|=set(split_rules(getattr(args,'extend_enable','') or ''))
    return active

def output_diags(diags, fmt, quiet=False, stderr=False, checked_files=0):
    stream=sys.stderr if stderr else sys.stdout
    if fmt in ('json','json-lines'):
        if fmt=='json': print(json.dumps([d.d() for d in diags],indent=2),file=stream)
        else:
            for d in diags: print(json.dumps(d.d()),file=stream)
        return
    if not diags:
        if not quiet:
            print(f'Success: No issues found in {checked_files} file{"s" if checked_files != 1 else ""}',file=stream)
        return
    if fmt=='github':
        for d in diags: print(f'::{"error" if d.rule in ERRORS else "warning"} file={d.file},line={d.line},col={d.col}::{d.rule} {d.msg}',file=stream)
        return
    for d in diags:
        star=' [*]' if d.fixable else ''
        print(f'{d.file}:{d.line}:{d.col}: [{d.rule}] {d.msg}{star}',file=stream)
    if diags and not quiet:
        files=len(set(d.file for d in diags)); fix=sum(1 for d in diags if d.fixable)
        print(f'\nIssues: Found {len(diags)} issue{"s" if len(diags)!=1 else ""} in {files} file{"s" if files!=1 else ""}',file=stream)
        if fix: print(f'Run `rumdl fmt` to automatically fix {fix} of the {len(diags)} issues',file=stream)

def cmd_check(argv, fmt_alias=False):
    ap=argparse.ArgumentParser(prog='executable fmt' if fmt_alias else 'executable check', add_help=True)
    ap.add_argument('paths',nargs='*'); ap.add_argument('-f','--fix',action='store_true'); ap.add_argument('--diff',action='store_true'); ap.add_argument('--check',action='store_true')
    ap.add_argument('-l','--list-rules',action='store_true'); ap.add_argument('-d','--disable',default=''); ap.add_argument('-e','--enable',default=''); ap.add_argument('--rules',dest='enable',default='')
    ap.add_argument('--extend-enable',default=''); ap.add_argument('--extend-disable',default=''); ap.add_argument('--exclude',default=''); ap.add_argument('--no-exclude',action='store_true')
    ap.add_argument('--include',default=''); ap.add_argument('--respect-gitignore',nargs='?',const='true'); ap.add_argument('-v','--verbose',action='store_true'); ap.add_argument('--color',default='auto')
    ap.add_argument('--profile',action='store_true'); ap.add_argument('--config'); ap.add_argument('--statistics',action='store_true'); ap.add_argument('--no-config',action='store_true'); ap.add_argument('-q','--quiet',action='store_true')
    ap.add_argument('--isolated',action='store_true'); ap.add_argument('-o','--output',default='text'); ap.add_argument('--output-format',default=None); ap.add_argument('--show-full-path',action='store_true')
    ap.add_argument('--flavor'); ap.add_argument('--stdin',action='store_true'); ap.add_argument('--stdin-filename',default='<stdin>'); ap.add_argument('--stderr',action='store_true'); ap.add_argument('-s','--silent',action='store_true')
    ap.add_argument('-w','--watch',action='store_true'); ap.add_argument('--force-exclude',action='store_true'); ap.add_argument('--no-cache',action='store_true'); ap.add_argument('--cache-dir'); ap.add_argument('--fail-on',default='any')
    args=ap.parse_args(argv)
    if args.list_rules:
        list_rules(); return 0
    cfg,p=({'disable':[],'enable':[],'line_length':80,'exclude':[]},None) if (args.no_config or args.isolated) else load_config(args.config)
    enabled=active_rules(args,cfg); excludes=[] if args.no_exclude else cfg.get('exclude',[])+([x for x in args.exclude.split(',') if x] if args.exclude else [])
    files=['-'] if args.stdin or args.paths==['-'] else collect_paths(args.paths,excludes)
    all_di=[]; changed=[]
    for f in files:
        if f=='-': txt=sys.stdin.read(); name=args.stdin_filename
        else:
            try: txt=Path(f).read_text(errors='ignore')
            except Exception as e: print(f'Error reading {f}: {e}',file=sys.stderr); continue
            name=os.path.abspath(f) if args.show_full_path else os.path.relpath(f)
        ds=lint_text(txt,name,enabled,cfg.get('line_length',80)); all_di.extend(ds)
        if args.fix or fmt_alias or args.diff or args.check:
            fixed=fix_text(txt,enabled,cfg.get('line_length',80))
            if fixed!=txt:
                changed.append((f,txt,fixed))
                if (args.fix or fmt_alias) and f!='-': Path(f).write_text(fixed)
                elif (args.fix or fmt_alias) and f=='-': sys.stdout.write(fixed)
                elif args.diff:
                    sys.stdout.writelines(difflib.unified_diff(txt.splitlines(True),fixed.splitlines(True),fromfile=f,tofile=f))
    if args.silent: return status_for(all_di,args.fail_on, changed if args.check else None)
    fmt=args.output_format or args.output or 'text'
    if not (args.fix or fmt_alias) or args.check or args.diff:
        output_diags(all_di,fmt,args.quiet,args.stderr,len(files))
    if args.statistics and all_di:
        counts={}
        for d in all_di: counts[d.rule]=counts.get(d.rule,0)+1
        print('\nRule statistics:')
        for k in sorted(counts): print(f'  {k}: {counts[k]}')
    return status_for(all_di,args.fail_on, changed if args.check else None)

def status_for(diags, fail_on, changed=None):
    if changed is not None and changed: return 1
    if fail_on=='never': return 0
    if not diags: return 0
    if fail_on=='error': return 1 if any(d.rule in ERRORS for d in diags) else 0
    return 1

def list_rules(fixable=False,category=None):
    rs=[r for r in RULES if (not fixable or r[4]) and (not category or r[3]==category)]
    print('Available rules:')
    for r in rs: print(f'  {r[0]} - {r[1]}')
    print(f'\nTotal: {len(rs)} rules')

def cmd_rule(argv):
    ap=argparse.ArgumentParser(prog='executable rule')
    ap.add_argument('rule',nargs='?'); ap.add_argument('-o','--output-format',default='text'); ap.add_argument('-f','--fixable',action='store_true'); ap.add_argument('-c','--category'); ap.add_argument('--explain',action='store_true'); ap.add_argument('--list-categories',action='store_true'); ap.add_argument('--color',default='auto'); ap.add_argument('--config'); ap.add_argument('--no-config',action='store_true'); ap.add_argument('--isolated',action='store_true')
    args=ap.parse_args(argv)
    if args.list_categories:
        cats={}
        for r in RULES: cats[r[3]]=cats.get(r[3],0)+1
        print('Available categories:')
        for c in sorted(cats): print(f'  {c} ({cats[c]} rules)')
        return 0
    if args.rule:
        rid=norm_rule(args.rule)
        if rid not in RULEMAP: print(f'Rule not found: {args.rule}',file=sys.stderr); return 1
        r=RULEMAP[rid]
        obj={'name':r[2],'code':r[0],'description':r[1],'category':r[3],'fixable':r[4],'url':f'https://rumdl.dev/{r[0].lower()}/'}
        if args.output_format in ('json','json-lines'):
            print(json.dumps(obj,indent=None if args.output_format=='json-lines' else 2)); return 0
        print(f'{r[0]} - {r[1]}\n')
        print(f'Name: {r[2]}')
        if r[0]=='MD025': print('Aliases: single-title')
        print(f'Category: {r[3]}')
        print('Fix: Fix is always available.' if r[4] else 'Fix: Not available.')
        print(f'Documentation: https://rumdl.dev/{r[0].lower()}/')
        return 0
    if args.output_format in ('json','json-lines'):
        objs=[{'name':r[2],'code':r[0],'description':r[1],'category':r[3],'fixable':r[4]} for r in RULES if (not args.fixable or r[4]) and (not args.category or r[3]==args.category)]
        if args.output_format=='json': print(json.dumps(objs,indent=2))
        else:
            for o in objs: print(json.dumps(o))
    else: list_rules(args.fixable,args.category)
    return 0

def cmd_config(argv):
    if argv and argv[0]=='file':
        cfg,p=load_config(None); print(str(p.resolve()) if p else 'No configuration file found'); return 0 if p else 1
    if argv and argv[0]=='get':
        key=argv[1] if len(argv)>1 else ''; cfg,p=load_config(None)
        val={'global.line_length':cfg.get('line_length',80),'global.disable':cfg.get('disable',[]),'global.enable':cfg.get('enable',[])}.get(key,'')
        print(json.dumps(val) if isinstance(val,(list,dict)) else val); return 0
    fmt='toml'
    if '--output' in argv:
        i=argv.index('--output'); fmt=argv[i+1] if i+1<len(argv) else 'toml'
    cfg,p=load_config(None)
    if fmt=='json': print(json.dumps({'global':cfg},indent=2))
    else:
        print('[global]'); print(f'line_length = {cfg.get("line_length",80)}'); print('disable = '+json.dumps(cfg.get('disable',[]))); print('enable = '+json.dumps(cfg.get('enable',[])))
    return 0

def cmd_init(argv):
    py='--pyproject' in argv; path=Path('pyproject.toml' if py else '.rumdl.toml')
    if path.exists(): print(f'Configuration file already exists: {path}',file=sys.stderr); return 1
    txt='[tool.rumdl]\n' if py else '[global]\n'
    txt+='line_length = 80\nexclude = [".git", "node_modules"]\n\n[MD013]\nline_length = 80\n'
    path.write_text(txt); print(f'Created configuration file: {path}'); return 0

def top_help():
    print('A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)\n')
    print('Usage: executable [OPTIONS] <COMMAND>\n')
    print('Commands:\n  check        Lint Markdown files and print warnings/errors\n  fmt          Format Markdown files (alias for check --fix)\n  init         Initialize a new configuration file\n  rule         Show information about a rule or list all rules\n  explain      Explain a rule with detailed information and examples\n  config       Show configuration or query a specific key\n  server       Start the Language Server Protocol server\n  schema       Generate or check JSON schema for rumdl.toml\n  import       Import and convert markdownlint configuration files\n  vscode       Install the rumdl VS Code extension\n  completions  Generate shell completion scripts\n  clean        Clear the cache\n  version      Show version information\n  help         Print this message or the help of the given subcommand(s)\n')
    print('Options:\n      --color <COLOR>    Control colored output: auto, always, never [default: auto] [possible values: auto, always, never]\n      --config <CONFIG>  Path to configuration file\n      --no-config        Ignore all configuration files and use built-in defaults\n      --isolated         Ignore all configuration files (alias for --no-config)\n  -h, --help             Print help\n  -V, --version          Print version')

def main():
    argv=sys.argv[1:]
    # strip global options
    if not argv or argv[0] in ('-h','--help','help'):
        top_help(); return 0
    if argv[0] in ('-V','--version','version'):
        print(VERSION); return 0
    while argv and argv[0] in ('--color','--config'):
        argv=argv[2:]
    while argv and argv[0] in ('--no-config','--isolated'):
        argv=argv[1:]
    cmd=argv[0]; rest=argv[1:]
    if cmd=='check': return cmd_check(rest,False)
    if cmd=='fmt': return cmd_check(rest,True)
    if cmd=='rule' or cmd=='explain': return cmd_rule(rest)
    if cmd=='config': return cmd_config(rest)
    if cmd=='init': return cmd_init(rest)
    if cmd=='clean':
        import shutil; shutil.rmtree('.rumdl_cache',ignore_errors=True); print('Cache cleared'); return 0
    if cmd=='schema': print('{}'); return 0
    if cmd=='completions': return 0
    if cmd in ('server','vscode','import'):
        print(f'{cmd} command is not available in this reimplementation',file=sys.stderr); return 1
    print(f'error: unrecognized subcommand {cmd!r}',file=sys.stderr); return 2
if __name__=='__main__': sys.exit(main())
