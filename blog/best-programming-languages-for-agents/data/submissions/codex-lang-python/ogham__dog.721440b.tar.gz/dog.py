#!/usr/bin/env python3
import ipaddress
import json
import os
import random
import socket
import ssl
import struct
import sys
import time
import urllib.parse
import urllib.request


HELP = """dog \u25cf command-line DNS client

Usage:
  dog [OPTIONS] [--] <arguments>

Examples:
  dog example.net                          Query a domain using default settings
  dog example.net MX                       ...looking up MX records instead
  dog example.net MX @1.1.1.1              ...using a specific nameserver instead
  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP
  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments

Query options:
  <arguments>              Human-readable host names, nameservers, types, or classes
  -q, --query=HOST         Host name or domain name to query
  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)
  -n, --nameserver=ADDR    Address of the nameserver to send packets to
  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)

Sending options:
  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)
  --txid=NUMBER            Set the transaction ID to a specific value
  -Z=TWEAKS                Set uncommon protocol-level tweaks

Protocol options:
  -U, --udp                Use the DNS protocol over UDP
  -T, --tcp                Use the DNS protocol over TCP
  -S, --tls                Use the DNS-over-TLS protocol
  -H, --https              Use the DNS-over-HTTPS protocol

Output options:
  -1, --short              Short mode: display nothing but the first result
  -J, --json               Display the output as JSON
  --color, --colour=WHEN   When to colourise the output (always, automatic, never)
  --seconds                Do not format durations, display them as seconds
  --time                   Print how long the response took to arrive

Meta options:
  -?, --help               Print list of command-line options
  -v, --version            Print version information
"""

VERSION = """dog \u25cf command-line DNS client
v0.2.0-pre [d3a34280] built on 2026-04-17 (pre-release!)
mhttps://dns.lookup.dog/
"""

TYPE_NUM = {
    "A": 1, "NS": 2, "CNAME": 5, "SOA": 6, "PTR": 12, "HINFO": 13, "MX": 15,
    "TXT": 16, "AAAA": 28, "SRV": 33, "NAPTR": 35, "SSHFP": 44, "TLSA": 52,
    "CAA": 257, "OPT": 41, "ANY": 255, "AFSDB": 18, "IXFR": 251, "AXFR": 252,
}
NUM_TYPE = {v: k for k, v in TYPE_NUM.items()}
CLASS_NUM = {"IN": 1, "CH": 3, "HS": 4}
NUM_CLASS = {v: k for k, v in CLASS_NUM.items()}


class DogError(Exception):
    def __init__(self, phase, message, status=1):
        super().__init__(message)
        self.phase = phase
        self.message = message
        self.status = status


def invalid(message):
    print(f"dog: Invalid options: {message}", file=sys.stderr)
    raise SystemExit(3)


def get_value(argv, i, opt):
    if "=" in argv[i] and argv[i].startswith("--"):
        return argv[i].split("=", 1)[1], i
    if i + 1 >= len(argv):
        invalid(f"Option '{opt}' needs a value")
    return argv[i + 1], i + 1


def parse_args(argv):
    opts = {
        "domains": [], "types": [], "classes": [], "servers": [],
        "transport": "auto", "short": False, "json": False, "time": False,
        "seconds": False, "txid": None, "edns": "hide", "tweaks": [],
    }
    positionals = []
    i = 0
    stop = False
    while i < len(argv):
        a = argv[i]
        if not stop and a == "--":
            stop = True
        elif not stop and a in ("-?", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        elif not stop and a in ("-v", "--version"):
            print(VERSION, end="")
            raise SystemExit(0)
        elif not stop and (a == "-q" or a.startswith("--query")):
            v, i = get_value(argv, i, "--query")
            opts["domains"].append(v)
        elif not stop and (a == "-t" or a.startswith("--type")):
            v, i = get_value(argv, i, "--type")
            add_type(opts, v)
        elif not stop and (a == "-n" or a.startswith("--nameserver")):
            v, i = get_value(argv, i, "--nameserver")
            opts["servers"].append(v)
        elif not stop and a.startswith("--class"):
            v, i = get_value(argv, i, "--class")
            add_class(opts, v)
        elif not stop and a.startswith("--edns"):
            v, i = get_value(argv, i, "--edns")
            if v not in ("disable", "hide", "show"):
                invalid(f'Invalid EDNS setting "{v}"')
            opts["edns"] = v
        elif not stop and a.startswith("--txid"):
            v, i = get_value(argv, i, "--txid")
            try:
                n = int(v, 10)
            except ValueError:
                invalid(f'Invalid transaction ID "{v}"')
            if n < 0 or n > 65535:
                invalid(f'Invalid transaction ID "{v}"')
            opts["txid"] = n
        elif not stop and (a == "-Z" or a.startswith("-Z=")):
            if a == "-Z":
                v, i = get_value(argv, i, "-Z")
            else:
                v = a[3:]
            if not (v in ("aa", "ad", "cd") or v.startswith("bufsize=")):
                invalid(f'Invalid protocol tweak "{v}"')
            opts["tweaks"].append(v)
        elif not stop and a in ("-U", "--udp"):
            opts["transport"] = "udp"
        elif not stop and a in ("-T", "--tcp"):
            opts["transport"] = "tcp"
        elif not stop and a in ("-S", "--tls"):
            opts["transport"] = "tls"
        elif not stop and a in ("-H", "--https"):
            opts["transport"] = "https"
        elif not stop and a in ("-1", "--short"):
            opts["short"] = True
        elif not stop and a in ("-J", "--json"):
            opts["json"] = True
        elif not stop and a == "--seconds":
            opts["seconds"] = True
        elif not stop and a == "--time":
            opts["time"] = True
        elif not stop and (a.startswith("--color") or a.startswith("--colour")):
            if "=" in a:
                v = a.split("=", 1)[1]
            elif i + 1 < len(argv) and argv[i + 1] in ("always", "automatic", "never"):
                i += 1
                v = argv[i]
            else:
                v = "automatic"
            if v not in ("always", "automatic", "never"):
                invalid(f'Invalid colour setting "{v}"')
        elif not stop and a.startswith("-"):
            invalid(f"Unrecognized option: '{a.lstrip('-')}'")
        else:
            positionals.append(a)
        i += 1
    for p in positionals:
        if p.startswith("@"):
            opts["servers"].append(p[1:])
        elif p.upper() in TYPE_NUM:
            add_type(opts, p)
        elif p.upper() in CLASS_NUM:
            add_class(opts, p)
        else:
            opts["domains"].append(p)
    if not opts["domains"]:
        print(HELP, end="")
        raise SystemExit(3)
    if not opts["types"]:
        opts["types"].append("A")
    if not opts["classes"]:
        opts["classes"].append("IN")
    if not opts["servers"]:
        opts["servers"].append(default_resolver())
    return opts


def add_type(opts, v):
    u = v.upper()
    if u not in TYPE_NUM:
        invalid(f'Invalid query type "{v}"')
    opts["types"].append(u)


def add_class(opts, v):
    u = v.upper()
    if u not in CLASS_NUM:
        invalid(f'Invalid query class "{v}"')
    opts["classes"].append(u)


def default_resolver():
    try:
        with open("/etc/resolv.conf", "r", encoding="utf-8") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2 and parts[0] == "nameserver":
                    return parts[1]
    except OSError as e:
        raise DogError("system", str(e), 4)
    raise DogError("system", "No nameservers found", 4)


def split_host_port(server, default_port):
    if server.startswith("http://") or server.startswith("https://"):
        return server, default_port
    if server.startswith("["):
        host, _, rest = server[1:].partition("]")
        port = int(rest[1:]) if rest.startswith(":") else default_port
        return host, port
    if server.count(":") == 1:
        host, port = server.rsplit(":", 1)
        if port.isdigit():
            return host, int(port)
    return server, default_port


def encode_name(name):
    name = name.rstrip(".")
    out = bytearray()
    if name:
        for label in name.split("."):
            b = label.encode("idna")
            out.append(len(b))
            out.extend(b)
    out.append(0)
    return bytes(out)


def read_name(data, off, seen=None):
    if seen is None:
        seen = set()
    labels = []
    jumped = False
    end = off
    while True:
        if off >= len(data):
            raise DogError("protocol", "Malformed packet: name out of bounds")
        ln = data[off]
        if ln & 0xC0 == 0xC0:
            if off + 1 >= len(data):
                raise DogError("protocol", "Malformed packet: bad name pointer")
            ptr = ((ln & 0x3F) << 8) | data[off + 1]
            if ptr in seen:
                raise DogError("protocol", "Malformed packet: cyclic name")
            seen.add(ptr)
            if not jumped:
                end = off + 2
            off = ptr
            jumped = True
            continue
        if ln == 0:
            if not jumped:
                end = off + 1
            break
        off += 1
        raw = data[off:off + ln]
        try:
            labels.append(raw.decode("idna"))
        except UnicodeError:
            labels.append(raw.decode("ascii", "replace"))
        off += ln
    return ".".join(labels) + ".", end


def make_query(domain, typ, cls, opts):
    txid = opts["txid"] if opts["txid"] is not None else random.randrange(65536)
    flags = 0x0100
    if "aa" in opts["tweaks"]:
        flags |= 0x0400
    if "ad" in opts["tweaks"]:
        flags |= 0x0020
    if "cd" in opts["tweaks"]:
        flags |= 0x0010
    q = encode_name(domain) + struct.pack("!HH", TYPE_NUM[typ], CLASS_NUM[cls])
    additional = b""
    ar = 0
    if opts["edns"] != "disable":
        size = 4096
        for t in opts["tweaks"]:
            if t.startswith("bufsize="):
                try:
                    size = int(t.split("=", 1)[1])
                except ValueError:
                    pass
        additional = b"\0" + struct.pack("!HHIH", 41, size, 0, 0)
        ar = 1
    return struct.pack("!HHHHHH", txid, flags, 1, 0, 0, ar) + q + additional


def udp_query(server, packet, timeout=5.0):
    host, port = split_host_port(server, 53)
    s = socket.socket(socket.AF_INET6 if ":" in host else socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(timeout)
    try:
        s.sendto(packet, (host, port))
        data, _ = s.recvfrom(65535)
        return data
    except OSError as e:
        raise DogError("network", os_error(e))
    finally:
        s.close()


def tcp_query(server, packet, tls=False, timeout=5.0):
    host, port = split_host_port(server, 853 if tls else 53)
    try:
        raw = socket.create_connection((host, port), timeout=timeout)
        if tls:
            raw = ssl.create_default_context().wrap_socket(raw, server_hostname=host)
        raw.settimeout(timeout)
        raw.sendall(struct.pack("!H", len(packet)) + packet)
        hdr = recv_exact(raw, 2)
        n = struct.unpack("!H", hdr)[0]
        return recv_exact(raw, n)
    except OSError as e:
        raise DogError("network", os_error(e))
    finally:
        try:
            raw.close()
        except Exception:
            pass


def https_query(server, packet):
    url = server if server.startswith(("http://", "https://")) else "https://" + server + "/dns-query"
    req = urllib.request.Request(url, data=packet, headers={"Content-Type": "application/dns-message", "Accept": "application/dns-message"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.read()
    except Exception as e:
        raise DogError("network", str(e))


def recv_exact(sock, n):
    b = bytearray()
    while len(b) < n:
        chunk = sock.recv(n - len(b))
        if not chunk:
            raise OSError("unexpected EOF")
        b.extend(chunk)
    return bytes(b)


def os_error(e):
    if getattr(e, "errno", None):
        return f"{e.strerror} (os error {e.errno})"
    return str(e)


def parse_packet(data):
    if len(data) < 12:
        raise DogError("protocol", "Malformed packet: too short")
    _txid, flags, qd, an, ns, ar = struct.unpack("!HHHHHH", data[:12])
    off = 12
    queries = []
    for _ in range(qd):
        name, off = read_name(data, off)
        if off + 4 > len(data):
            raise DogError("protocol", "Malformed packet: question truncated")
        typ, cls = struct.unpack("!HH", data[off:off + 4])
        off += 4
        queries.append({"name": name, "class": NUM_CLASS.get(cls, str(cls)), "type": NUM_TYPE.get(typ, str(typ))})
    answers = []
    for section, count in (("answers", an), ("authorities", ns), ("additionals", ar)):
        arr = []
        for _ in range(count):
            rec, off = parse_record(data, off)
            arr.append(rec)
        answers.append(arr)
    return {"flags": flags, "queries": queries, "answers": answers[0], "authorities": answers[1], "additionals": answers[2]}


def parse_record(data, off):
    name, off = read_name(data, off)
    if off + 10 > len(data):
        raise DogError("protocol", "Malformed packet: record truncated")
    typ, cls, ttl, rdlen = struct.unpack("!HHIH", data[off:off + 10])
    off += 10
    rdoff = off
    rdata = data[off:off + rdlen]
    if len(rdata) != rdlen:
        raise DogError("protocol", f"Malformed packet: record length should be {rdlen}, got {len(rdata)}")
    off += rdlen
    tname = NUM_TYPE.get(typ, str(typ))
    rec = {"name": name, "class": NUM_CLASS.get(cls, str(cls)), "ttl": ttl, "type": tname}
    rec["data"] = decode_rdata(tname, data, rdoff, rdlen)
    return rec, off


def decode_rdata(t, packet, off, n):
    r = packet[off:off + n]
    try:
        if t == "A" and n == 4:
            return {"address": str(ipaddress.IPv4Address(r))}
        if t == "AAAA" and n == 16:
            return {"address": str(ipaddress.IPv6Address(r))}
        if t in ("NS", "CNAME", "PTR"):
            name, _ = read_name(packet, off)
            return {"name": name}
        if t == "MX" and n >= 3:
            pref = struct.unpack("!H", r[:2])[0]
            exch, _ = read_name(packet, off + 2)
            return {"preference": pref, "exchange": exch}
        if t == "TXT":
            texts = []
            p = 0
            while p < len(r):
                ln = r[p]; p += 1
                texts.append(r[p:p + ln].decode("utf-8", "replace"))
                p += ln
            return {"texts": texts}
        if t == "SOA":
            m, p = read_name(packet, off)
            rname, p = read_name(packet, p)
            vals = struct.unpack("!IIIII", packet[p:p + 20])
            return {"mname": m, "rname": rname, "serial": vals[0], "refresh": vals[1], "retry": vals[2], "expire": vals[3], "minimum": vals[4]}
        if t == "SRV" and n >= 7:
            pri, weight, port = struct.unpack("!HHH", r[:6])
            target, _ = read_name(packet, off + 6)
            return {"priority": pri, "weight": weight, "port": port, "target": target}
        if t == "CAA" and n >= 2:
            flags = r[0]
            taglen = r[1]
            tag = r[2:2 + taglen].decode("ascii", "replace")
            value = r[2 + taglen:].decode("utf-8", "replace")
            return {"flags": flags, "tag": tag, "value": value}
    except Exception:
        pass
    return {"bytes": list(r)}


def duration(n, seconds=False):
    if seconds:
        return f"{n}s"
    if n >= 3600:
        h = n // 3600; m = (n % 3600) // 60; s = n % 60
        return f"{h}h{m:02d}m{s:02d}s"
    if n >= 60:
        return f"{n // 60}m{n % 60:02d}s"
    return f"{n}s"


def data_text(rec):
    d = rec["data"]
    t = rec["type"]
    q = lambda s: '"' + s + '"'
    if "address" in d:
        return d["address"]
    if t in ("NS", "CNAME", "PTR") and "name" in d:
        return q(d["name"])
    if t == "MX" and "exchange" in d:
        return f'{d["preference"]} {q(d["exchange"])}'
    if t == "TXT" and "texts" in d:
        return ", ".join(q(x) for x in d["texts"])
    if t == "SOA" and "mname" in d:
        return f'{q(d["mname"])} {q(d["rname"])} {d["serial"]} {duration(d["refresh"])} {duration(d["retry"])} {duration(d["expire"])} {duration(d["minimum"])}'
    if t == "SRV" and "target" in d:
        return f'{d["priority"]} {d["weight"]} {q(d["target"])}:{d["port"]}'
    if t == "CAA" and "tag" in d:
        return f'{d["flags"]} {d["tag"]} "{d["value"]}"'
    if "bytes" in d:
        return " ".join(str(x) for x in d["bytes"])
    return str(d)


def render_text(responses, opts):
    rows = []
    for resp in responses:
        for rec in resp["answers"]:
            if rec["type"] == "OPT":
                continue
            rows.append((rec["type"], rec["name"], duration(rec["ttl"], opts["seconds"]), data_text(rec)))
    if opts["short"]:
        if rows:
            print(rows[0][3])
            return 0
        print("No results", file=sys.stderr)
        return 2
    if not rows:
        return 0
    w = max(len(r[0]) for r in rows)
    for typ, name, ttl, data in rows:
        print(f"{typ:>{w}} {name} {ttl}   {data}")
    return 0


def run_query(server, domain, typ, cls, opts):
    pkt = make_query(domain, typ, cls, opts)
    if opts["transport"] in ("udp", "auto"):
        data = udp_query(server, pkt)
        resp = parse_packet(data)
        if opts["transport"] == "auto" and resp["flags"] & 0x0200:
            data = tcp_query(server, pkt)
            resp = parse_packet(data)
        return resp
    if opts["transport"] == "tcp":
        return parse_packet(tcp_query(server, pkt))
    if opts["transport"] == "tls":
        return parse_packet(tcp_query(server, pkt, tls=True))
    return parse_packet(https_query(server, pkt))


def main(argv):
    opts = parse_args(argv)
    responses = []
    start = time.monotonic()
    try:
        for domain in opts["domains"]:
            for typ in opts["types"]:
                for cls in opts["classes"]:
                    for server in opts["servers"]:
                        responses.append(run_query(server, domain, typ, cls, opts))
        if opts["json"]:
            print(json.dumps({"responses": [{k: v for k, v in r.items() if k != "flags"} for r in responses]}, separators=(",", ":")))
            return 0
        return render_text(responses, opts)
    except DogError as e:
        if opts["time"]:
            elapsed = max(0, int(round((time.monotonic() - start) * 1000)))
            print(f"Ran in {elapsed}ms")
        if opts["json"]:
            print(json.dumps({"responses": []}, separators=(",", ":")))
            print(json.dumps({"error": True, "error_phase": e.phase, "error_message": e.message}, separators=(",", ":")), file=sys.stderr)
        else:
            print(f"Error [{e.phase}]: {e.message}", file=sys.stderr)
            if opts["short"]:
                print("No results", file=sys.stderr)
                return 2
        return e.status


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except KeyboardInterrupt:
        raise SystemExit(1)
