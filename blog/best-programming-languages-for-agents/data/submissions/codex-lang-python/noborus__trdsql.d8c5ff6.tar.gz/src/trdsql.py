#!/usr/bin/env python3
import argparse
import csv
import json
import os
import re
import sqlite3
import sys
import textwrap
from collections import OrderedDict


HELP = """trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.

Usage
\ttrdsql [OPTIONS] [SQL(SELECT...)]

Options:
  -A string           analyze the file but only suggest SQL.
  -a string           analyze the file and suggest SQL.
  -config string      configuration file location.
  -db string          specify db name of the setting.
  -dblist             display db information.
  -debug              debug print.
  -driver string      database driver.  [ mysql | postgres | sqlite3 | sqlite3_ext ]
  -dsn string         database driver specific data source name.
  -help               display usage information.
  -q string           read query from the specified file.
  -t string           read table name from the specified file.
  -version            display version information.

Input Formats:
  -icsv               CSV format for input.
  -ig                 guess format from extension. (default "true")
  -ijson              JSON format for input.
  -iltsv              LTSV format for input.
  -itbln              TBLN format for input.
  -itext              text format for input.
  -iwidth             width specification format for input.
  -iyaml              YAML format for input.

Input options:
  -id string          field delimiter for input. (default ",")
  -ih                 the first line is interpreted as column names(CSV only).
  -ijq string         jq expression string for input(JSON/JSONL only).
  -ilr int            limited number of rows to read. (default 0)
  -inull value        value(string) to convert to null on input.
  -inum               add row number column.
  -ir int             number of rows to preread. (default 1)
  -is int             skip header row. (default 0)

Output Formats:
  -oat                ASCII Table format for output.
  -ocsv               CSV format for output.
  -ojson              JSON format for output.
  -ojsonl             JSON lines format for output.
  -oltsv              LTSV format for output.
  -omd                Markdown format for output.
  -oraw               Raw format for output.
  -otbln              TBLN format for output.
  -ovf                Vertical format for output.
  -oyaml              YAML format for output.

Output options:
  -oaq                enclose all fields in quotes for output.
  -ocrlf              use CRLF for output. End each output line with '\\r\\n' instead of '\\n'.
  -od string          field delimiter for output. (default ",")
  -oh                 output column name as header.
  -onowrap            do not wrap long lines(at/md only).
  -onull value        value(string) to convert from null on output.
  -oq string          quote character for output. (default "\\"")
  -out string         output file name.
  -out-without-guess  output without guessing (when using -out).
  -oz string          output compression format. [ gz | bz2 | zstd | lz4 | xz ]

Examples:
  $ trdsql "SELECT c1,c2 FROM test.csv"
  $ trdsql -oltsv "SELECT c1,c2 FROM test.json::.items"
  $ cat test.csv | trdsql -icsv -oltsv "SELECT c1,c2 FROM -"
"""


def parse_args(argv):
    opts = {
        "ih": False, "oh": False, "iformat": None, "oformat": "csv",
        "id": ",", "od": ",", "oq": '"', "oaq": False, "ocrlf": False,
        "ijq": None, "q": None, "t": None, "out": None, "inull": None,
        "onull": "", "is": 0, "ilr": 0, "inum": False,
    }
    positional = []
    takes = {"-q": "q", "-t": "t", "-id": "id", "-od": "od", "-oq": "oq",
             "-ijq": "ijq", "-out": "out", "-inull": "inull", "-onull": "onull",
             "-is": "is", "-ilr": "ilr", "-ir": "ir", "-a": "analyze", "-A": "analyze",
             "-config": "config", "-db": "db", "-driver": "driver", "-dsn": "dsn",
             "-oz": "oz"}
    if not argv:
        print(HELP)
        sys.exit(0)
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-help", "--help"):
            print(HELP)
            sys.exit(0)
        if a in ("-version", "--version"):
            print("trdsql version devel")
            sys.exit(0)
        if a in ("-dblist", "-debug", "-ig", "-out-without-guess", "-onowrap"):
            i += 1; continue
        if a in ("-ih", "-oh", "-oaq", "-ocrlf", "-inum"):
            opts[a[1:]] = True; i += 1; continue
        if a in ("-icsv", "-iltsv", "-ijson", "-iyaml", "-itbln", "-itext", "-iwidth"):
            opts["iformat"] = a[2:]; i += 1; continue
        if a in ("-ocsv", "-oltsv", "-ojson", "-ojsonl", "-omd", "-oat", "-oraw", "-otbln", "-ovf", "-oyaml"):
            opts["oformat"] = a[2:]; i += 1; continue
        matched = False
        for flag, key in takes.items():
            if a == flag:
                if i + 1 >= len(argv): die(f"flag needs an argument: {flag}")
                val = argv[i + 1]; i += 2; matched = True
                opts[key] = int(val) if key in ("is", "ilr", "ir") else val
                break
            if a.startswith(flag + "="):
                val = a.split("=", 1)[1]; i += 1; matched = True
                opts[key] = int(val) if key in ("is", "ilr", "ir") else val
                break
        if matched:
            continue
        if a.startswith("-o") and len(a) > 2:
            opts["oformat"] = a[2:]; i += 1; continue
        if a.startswith("-"):
            print(f"flag provided but not defined: {a}", file=sys.stderr)
            print(HELP, file=sys.stderr)
            sys.exit(2)
        positional.append(a); i += 1
    for k in ("id", "od"):
        opts[k] = decode_delim(opts[k])
    return opts, " ".join(positional).strip()


def decode_delim(s):
    return {"\\t": "\t", "tab": "\t", "\\n": "\n", "\\r": "\r"}.get(s, s)


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def clean_name(s, used):
    s = re.sub(r"\W+", "_", str(s).strip()) or "c"
    if s[0].isdigit():
        s = "c" + s
    base, n = s, 1
    while s.lower() in used:
        n += 1; s = f"{base}_{n}"
    used.add(s.lower())
    return s


def guess_format(path, opts):
    if opts["iformat"]:
        return opts["iformat"]
    ext = os.path.splitext(path.split("::", 1)[0])[1].lower()
    return {" .csv": "csv"}.get(ext, {".csv": "csv", ".tsv": "csv", ".ltsv": "ltsv",
            ".json": "json", ".jsonl": "json", ".ndjson": "json", ".yaml": "yaml",
            ".yml": "yaml", ".tbln": "tbln", ".txt": "text"}.get(ext, "csv"))


def apply_jq(data, expr):
    if not expr:
        return data
    cur = data
    expr = expr.strip()
    if expr.startswith("."):
        parts = [p for p in expr[1:].split(".") if p]
        for p in parts:
            if isinstance(cur, dict):
                cur = cur.get(p, [])
            elif isinstance(cur, list) and p.isdigit():
                cur = cur[int(p)]
            else:
                return []
    return cur


def read_csv_file(path, opts):
    f = sys.stdin if path == "-" else open(path, newline="")
    try:
        rows = list(csv.reader(f, delimiter=opts["id"]))
    finally:
        if path != "-": f.close()
    rows = rows[opts["is"]:]
    if opts["ilr"]:
        rows = rows[:opts["ilr"] + (1 if opts["ih"] else 0)]
    if not rows:
        return [], []
    if opts["ih"]:
        used = set(); cols = [clean_name(c, used) for c in rows[0]]
        data = rows[1:]
    else:
        maxlen = max(len(r) for r in rows)
        cols = [f"c{i}" for i in range(1, maxlen + 1)]
        data = rows
    return cols, [pad_row(r, len(cols), opts) for r in data]


def pad_row(r, n, opts):
    out = list(r) + [""] * (n - len(r))
    out = out[:n]
    return [None if opts["inull"] is not None and v == opts["inull"] else v for v in out]


def read_ltsv_file(path, opts):
    lines = (sys.stdin.read().splitlines() if path == "-" else open(path).read().splitlines())
    if opts["is"]: lines = lines[opts["is"]:]
    if opts["ilr"]: lines = lines[:opts["ilr"]]
    recs = []
    keys = []
    for line in lines:
        od = OrderedDict()
        for part in line.split("\t"):
            if ":" in part:
                k, v = part.split(":", 1)
                if k not in keys: keys.append(k)
                od[k] = v
        if od: recs.append(od)
    return keys, [[r.get(k, "") for k in keys] for r in recs]


def flatten(obj, prefix=""):
    out = OrderedDict()
    if isinstance(obj, dict):
        for k in sorted(obj.keys()):
            v = obj[k]
            name = f"{prefix}_{k}" if prefix else str(k)
            if isinstance(v, (dict, list)):
                out[name] = json.dumps(v, separators=(",", ":"))
            else:
                out[name] = "" if v is None else str(v)
    else:
        out["c1"] = "" if obj is None else str(obj)
    return out


def read_json_file(path, opts, jq_expr=None):
    text = sys.stdin.read() if path == "-" else open(path).read()
    text = text.strip()
    if not text:
        return [], []
    try:
        data = json.loads(text)
    except Exception:
        data = [json.loads(line) for line in text.splitlines() if line.strip()]
    data = apply_jq(data, jq_expr or opts["ijq"])
    if isinstance(data, dict):
        if all(isinstance(v, list) for v in data.values()) and len(data) == 1:
            data = next(iter(data.values()))
        else:
            data = [data]
    if not isinstance(data, list):
        data = [data]
    if opts["ilr"]:
        data = data[:opts["ilr"]]
    recs = [flatten(x) for x in data]
    keys = []
    for r in recs:
        for k in r:
            if k not in keys: keys.append(k)
    return keys, [[r.get(k, "") for k in keys] for r in recs]


def read_yaml_file(path, opts):
    # Small YAML subset: enough for trdsql-style arrays of mappings.
    lines = (sys.stdin.read() if path == "-" else open(path).read()).splitlines()
    recs, cur = [], None
    for line in lines:
        s = line.strip()
        if not s or s.startswith("#"): continue
        if s.startswith("- "):
            if cur is not None: recs.append(cur)
            cur = OrderedDict()
            rest = s[2:]
            if ":" in rest:
                k, v = rest.split(":", 1); cur[k.strip()] = v.strip().strip('"\'')
        elif ":" in s:
            if cur is None: cur = OrderedDict()
            k, v = s.split(":", 1); cur[k.strip()] = v.strip().strip('"\'')
    if cur is not None: recs.append(cur)
    keys = []
    for r in recs:
        for k in r:
            if k not in keys: keys.append(k)
    return keys, [[r.get(k, "") for k in keys] for r in recs]


def read_text_file(path, opts):
    lines = sys.stdin.read().splitlines() if path == "-" else open(path).read().splitlines()
    if opts["is"]: lines = lines[opts["is"]:]
    if opts["ilr"]: lines = lines[:opts["ilr"]]
    return ["c1"], [[x] for x in lines]


def read_tbln_file(path, opts):
    rows = []
    cols = []
    for line in (sys.stdin.read() if path == "-" else open(path).read()).splitlines():
        s = line.strip()
        if not s or s.startswith(";"): continue
        if s.startswith("|") and s.endswith("|"):
            vals = [x.strip() for x in s.strip("|").split("|")]
            if not cols:
                cols = [f"c{i}" for i in range(1, len(vals) + 1)]
            rows.append(vals)
    return cols, rows


def read_table(pathspec, opts):
    path, jq = (pathspec.split("::", 1) + [None])[:2] if "::" in pathspec else (pathspec, None)
    fmt = guess_format(path, opts)
    if fmt == "ltsv": return read_ltsv_file(path, opts)
    if fmt == "json": return read_json_file(path, opts, jq)
    if fmt == "yaml": return read_yaml_file(path, opts)
    if fmt == "tbln": return read_tbln_file(path, opts)
    if fmt in ("text", "width"): return read_text_file(path, opts)
    return read_csv_file(path, opts)


def quote_ident(s):
    return '"' + s.replace('"', '""') + '"'


def create_table(conn, name, cols, rows, opts):
    if opts["inum"]:
        cols = ["rownum"] + cols
        rows = [[str(i + 1)] + list(r) for i, r in enumerate(rows)]
    if not cols:
        cols = ["c1"]
    used = set(); cols = [clean_name(c, used) for c in cols]
    conn.execute(f"CREATE TABLE {quote_ident(name)} ({','.join(quote_ident(c) + ' TEXT' for c in cols)})")
    if rows:
        ph = ",".join("?" for _ in cols)
        conn.executemany(f"INSERT INTO {quote_ident(name)} VALUES ({ph})", [pad_row(r, len(cols), opts) for r in rows])
    return cols


def find_sources(sql):
    pat = re.compile(r"(?i)\b(?:from|join)\s+((?:'[^']+'|\"[^\"]+\"|`[^`]+`|[^\s,;)]+))")
    out = []
    for m in pat.finditer(sql):
        tok = m.group(1).strip()
        raw = tok[1:-1] if tok[:1] in "'\"`" and tok[-1:] == tok[:1] else tok
        if raw.startswith("(") or raw.lower().startswith("select"):
            continue
        out.append((tok, raw))
    return out


def source_to_table(src, idx):
    base = os.path.basename(src.split("::", 1)[0])
    stem = os.path.splitext(base)[0] or "stdin"
    return clean_name(stem, set()) + (f"_{idx}" if idx else "")


def run_query(sql, opts):
    conn = sqlite3.connect(":memory:")
    replacements = []
    for idx, (tok, src) in enumerate(find_sources(sql)):
        tname = source_to_table(src, idx)
        cols, rows = read_table(src, opts)
        create_table(conn, tname, cols, rows, opts)
        replacements.append((tok, quote_ident(tname)))
    for old, new in sorted(replacements, key=lambda x: -len(x[0])):
        sql = sql.replace(old, new)
    cur = conn.execute(sql)
    cols = [d[0] for d in cur.description] if cur.description else []
    rows = [list(r) for r in cur.fetchall()]
    return cols, rows


def csv_text(cols, rows, opts):
    import io
    buf = io.StringIO()
    writer = csv.writer(buf, delimiter=opts["od"], quotechar=opts["oq"][:1] or '"',
                        lineterminator="\r\n" if opts["ocrlf"] else "\n",
                        quoting=csv.QUOTE_ALL if opts["oaq"] else csv.QUOTE_MINIMAL)
    if opts["oh"]:
        writer.writerow(cols)
    writer.writerows([[fmt(v, opts) for v in r] for r in rows])
    return buf.getvalue()


def fmt(v, opts):
    return opts["onull"] if v is None else str(v)


def out_json(cols, rows, pretty=True):
    arr = [OrderedDict((c, "" if v is None else str(v)) for c, v in zip(cols, r)) for r in rows]
    return json.dumps(arr, indent=2 if pretty else None, separators=None if pretty else (",", ":")) + "\n"


def out_jsonl(cols, rows):
    return "".join(json.dumps(OrderedDict((c, "" if v is None else str(v)) for c, v in zip(cols, r)), separators=(",", ":")) + "\n" for r in rows)


def out_ltsv(cols, rows, opts):
    return "".join("\t".join(f"{c}:{fmt(v, opts)}" for c, v in zip(cols, r)) + ("\r\n" if opts["ocrlf"] else "\n") for r in rows)


def out_yaml(cols, rows, opts):
    parts = []
    for r in rows:
        for i, (c, v) in enumerate(zip(cols, r)):
            prefix = "- " if i == 0 else "  "
            parts.append(f"{prefix}{c}: {fmt(v, opts)}")
    return "\n".join(parts) + ("\n" if parts else "")


def widths(cols, rows):
    return [max(len(str(c)), *(len(str("" if v is None else v)) for v in col)) for c, col in zip(cols, zip(*rows))] if cols else []


def out_md(cols, rows, opts):
    ws = widths(cols, rows)
    lines = ["| " + " | ".join(str(c).ljust(w) for c, w in zip(cols, ws)) + " |",
             "|" + "|".join("-" * (w + 2) for w in ws) + "|"]
    for r in rows:
        lines.append("| " + " | ".join(fmt(v, opts).rjust(w) if str(fmt(v, opts)).isdigit() else fmt(v, opts).ljust(w) for v, w in zip(r, ws)) + " |")
    return "\n".join(lines) + "\n"


def out_at(cols, rows, opts):
    ws = widths(cols, rows)
    border = "+" + "+".join("-" * (w + 2) for w in ws) + "+"
    lines = [border, "| " + " | ".join(str(c).ljust(w) for c, w in zip(cols, ws)) + " |", border]
    for r in rows:
        lines.append("| " + " | ".join(fmt(v, opts).rjust(w) if str(fmt(v, opts)).isdigit() else fmt(v, opts).ljust(w) for v, w in zip(r, ws)) + " |")
    lines.append(border)
    return "\n".join(lines) + "\n"


def out_tbln(cols, rows, opts):
    lines = ["; name: | " + " | ".join(cols) + " |",
             "; type: | " + " | ".join(["text"] * len(cols)) + " |"]
    lines += ["| " + " | ".join(fmt(v, opts) for v in r) + " |" for r in rows]
    return "\n".join(lines) + "\n"


def out_vf(cols, rows, opts):
    lines = []
    w = max([len(c) for c in cols] + [1])
    for n, r in enumerate(rows, 1):
        lines.append(f"---[{n:2d}]------------------------")
        for c, v in zip(cols, r):
            lines.append(f"{c.rjust(w)} | {fmt(v, opts)}")
    return "\n".join(lines) + ("\n" if lines else "")


def render(cols, rows, opts):
    f = opts["oformat"]
    if f == "json": return out_json(cols, rows)
    if f == "jsonl": return out_jsonl(cols, rows)
    if f == "ltsv": return out_ltsv(cols, rows, opts)
    if f == "yaml": return out_yaml(cols, rows, opts)
    if f == "md": return out_md(cols, rows, opts)
    if f == "at": return out_at(cols, rows, opts)
    if f == "tbln": return out_tbln(cols, rows, opts)
    if f == "vf": return out_vf(cols, rows, opts)
    return csv_text(cols, rows, opts)


def main(argv):
    opts, sql = parse_args(argv)
    try:
        if opts["q"]:
            sql = open(opts["q"]).read().strip()
        if opts["t"]:
            cols, rows = read_table(opts["t"], opts)
        else:
            if not sql:
                print(HELP); return 0
            cols, rows = run_query(sql, opts)
        text = render(cols, rows, opts)
        if opts["out"]:
            with open(opts["out"], "w", newline="") as f:
                f.write(text)
        else:
            sys.stdout.write(text)
        return 0
    except BrokenPipeError:
        return 0
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
