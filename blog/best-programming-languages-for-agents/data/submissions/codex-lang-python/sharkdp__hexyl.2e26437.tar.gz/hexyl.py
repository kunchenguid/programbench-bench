#!/usr/bin/env python3
import argparse
import os
import re
import shutil
import sys

VERSION = "hexyl 0.16.0"

CP437 = ''.join(chr(i) for i in range(256)).encode('latin1').decode('cp437', 'replace')
CP1047 = None

BRAILLE_SPECIAL = {0: "⋄", 9: "→", 10: "↵", 13: "←"}

ANSI = {
    "reset": "\033[0m",
    "offset": "\033[38;5;242m",
    "null": "\033[38;5;242m",
    "print": "\033[36m",
    "space": "\033[32m",
    "other": "\033[32m",
    "nonascii": "\033[33m",
}


def parse_num(text, block_size=512, allow_negative=True):
    s = str(text).strip()
    sign = 1
    if s.startswith("-"):
        if not allow_negative:
            raise ValueError(text)
        sign = -1
        s = s[1:]
    elif s.startswith("+"):
        s = s[1:]
    m = re.fullmatch(r"(0x[0-9a-fA-F]+|\d+)([a-zA-Z]*)", s)
    if not m:
        raise ValueError(text)
    n_s, unit = m.groups()
    n = int(n_s, 16) if n_s.lower().startswith("0x") else int(n_s, 10)
    u = unit.lower()
    mults = {
        "": 1, "b": 1,
        "kb": 1000, "mb": 1000 ** 2, "gb": 1000 ** 3, "tb": 1000 ** 4,
        "kib": 1024, "mib": 1024 ** 2, "gib": 1024 ** 3, "tib": 1024 ** 4,
        "block": block_size, "blocks": block_size,
    }
    if u in ("k", "m", "g", "t"):
        u += "b"
    if u not in mults:
        raise ValueError(text)
    return sign * n * mults[u]


def read_input(path, skip, length):
    if path:
        try:
            with open(path, "rb") as f:
                if skip < 0:
                    f.seek(0, os.SEEK_END)
                    size = f.tell()
                    f.seek(max(0, size + skip))
                else:
                    f.seek(skip)
                return f.read(length if length is not None else -1), os.path.getsize(path)
        except OSError as e:
            print(f"Error: {e.strerror} (os error {e.errno})", file=sys.stderr)
            sys.exit(1)
    data = sys.stdin.buffer.read()
    start = max(0, len(data) + skip) if skip < 0 else min(skip, len(data))
    data = data[start:]
    if length is not None:
        data = data[:length]
    return data, None


def char_for(b, table):
    if table == "ascii":
        return chr(b) if 32 <= b <= 126 else (" " if b == 32 else ".")
    if table == "codepage-437":
        return "⋄" if b == 0 else CP437[b]
    if table == "codepage-1047":
        try:
            return bytes([b]).decode("cp037")
        except Exception:
            return "."
    if table == "braille":
        if 32 <= b <= 126:
            return chr(b)
        if b in BRAILLE_SPECIAL:
            return BRAILLE_SPECIAL[b]
        return chr(0x2800 + b)
    if b == 0:
        return "⋄"
    if b == 32:
        return " "
    if b in (9, 10, 12, 13):
        return "_"
    if 33 <= b <= 126:
        return chr(b)
    if b < 128:
        return "•"
    return "×"


def color_kind(b):
    if b == 0:
        return "null"
    if b >= 128:
        return "nonascii"
    if 32 <= b <= 126 and b != 32:
        return "print"
    if b in (9, 10, 11, 12, 13, 32):
        return "space"
    return "other"


def maybe_color(s, b, use_color):
    if not use_color:
        return s
    return ANSI[color_kind(b)] + s + ANSI["reset"]


def byte_token(bs, base, group_size, endian, use_color):
    data = list(bs)
    if endian == "little" and group_size > 1:
        data = list(reversed(data))
    if base == "binary":
        parts = [format(b, "08b") for b in data]
    elif base == "octal":
        parts = [format(b, "03o") for b in data]
    elif base == "decimal":
        parts = [format(b, "03d") for b in data]
    else:
        parts = [format(b, "02x") for b in data]
    token = "".join(parts) if group_size > 1 and base == "hexadecimal" else " ".join(parts)
    if use_color and bs:
        return maybe_color(token, bs[0], True)
    return token


def panel_width(base, group_size):
    if base == "binary":
        return 73
    if base in ("octal", "decimal"):
        return 33
    if group_size == 1:
        return 25
    return {2: 21, 4: 19, 8: 17}.get(group_size, 25)


def format_hex_panel(chunk, base, group_size, endian, width, use_color):
    parts = []
    i = 0
    while i < len(chunk):
        grp = chunk[i:i + group_size]
        parts.append(byte_token(grp, base, group_size, endian, use_color))
        i += group_size
    s = " " + " ".join(parts)
    return s + " " * max(0, width - len(strip_ansi(s)))


def strip_ansi(s):
    return re.sub(r"\x1b\[[0-9;]*m", "", s)


def chars_panel(chunk, table, width, use_color):
    chars = [maybe_color(char_for(b, table), b, use_color) for b in chunk]
    s = "".join(chars)
    return s + " " * max(0, width - len(strip_ansi(s)))


def border_line(widths, style, pos=True, chars=True, base="hexadecimal"):
    if style == "none":
        return None
    if style == "ascii":
        tl, tr, h, v, cross = "+", "+", "-", "|", "+"
    else:
        tl, tr, h, v, cross = "┌", "┐", "─", "│", "┬"
    bot = False
    sep = cross
    return tl + sep.join(h * w for w in widths) + tr


def bottom_line(widths, style):
    if style == "none":
        return None
    if style == "ascii":
        return "+" + "+".join("-" * w for w in widths) + "+"
    return "└" + "┴".join("─" * w for w in widths) + "┘"


def row_line(cells, style, panels=1, has_pos=True, has_chars=True):
    if style == "none":
        return " " + " ".join(cells)
    if style == "ascii":
        return "|" + "|".join(cells) + "|"
    if style != "unicode":
        return " ".join(cells)
    out = "│"
    idx = 0
    if has_pos:
        out += cells[idx] + "│"
        idx += 1
    for p in range(panels):
        out += cells[idx]
        idx += 1
        out += "┊" if p != panels - 1 else "│"
    if has_chars:
        for p in range(panels):
            out += cells[idx]
            idx += 1
            out += "┊" if p != panels - 1 else "│"
    return out


def separator_char(style):
    return "|" if style == "ascii" else ("┊" if style == "unicode" else " ")


def choose_panels(args, base):
    if args.panels and args.panels != "auto":
        return max(1, int(args.panels))
    width = args.terminal_width or shutil.get_terminal_size((80, 20)).columns
    if args.panels == "auto" or args.terminal_width:
        per = panel_width(base, args.group_size) + (8 if not args.no_characters else 0) + 1
        avail = max(1, width - (10 if not args.no_position else 0))
        return max(1, min(8, avail // max(1, per)))
    return 1 if base in ("binary", "octal", "decimal") else 2


def render(data, args, display_offset=0, use_color=False):
    panels = choose_panels(args, args.base)
    row_bytes = panels * 8
    pwidth = panel_width(args.base, args.group_size)
    widths = []
    if not args.no_position:
        widths.append(8)
    widths.extend([pwidth] * panels)
    if not args.no_characters:
        widths.extend([8] * panels)
    top = border_line(widths, args.border)
    if top:
        print(top)
    prev = None
    squeezed = False
    rows = [data[i:i + row_bytes] for i in range(0, len(data), row_bytes)]
    if not rows and len(data) == 0:
        rows = []
    for idx, chunk in enumerate(rows):
        off = display_offset + idx * row_bytes
        if (not args.no_squeezing and prev is not None and len(chunk) == row_bytes
                and chunk == prev):
            if not squeezed:
                cells = []
                if not args.no_position:
                    cells.append("*" + " " * 7)
                cells.extend([" " * pwidth for _ in range(panels)])
                if not args.no_characters:
                    cells.extend([" " * 8 for _ in range(panels)])
                if panels > 1 and args.border != "none":
                    # row_line joins cells with full borders; internal split is enough.
                    pass
                print(row_line(cells, args.border, panels, not args.no_position, not args.no_characters))
                squeezed = True
            continue
        squeezed = False
        prev = chunk if len(chunk) == row_bytes else None
        cells = []
        if not args.no_position:
            pos = format(off & 0xffffffff, "08x")
            if use_color:
                pos = ANSI["offset"] + pos + ANSI["reset"]
            cells.append(pos)
        for p in range(panels):
            sub = chunk[p * 8:(p + 1) * 8]
            cells.append(format_hex_panel(sub, args.base, args.group_size, args.endianness, pwidth, use_color))
        if not args.no_characters:
            for p in range(panels):
                sub = chunk[p * 8:(p + 1) * 8]
                cells.append(chars_panel(sub, args.character_table, 8, use_color))
        print(row_line(cells, args.border, panels, not args.no_position, not args.no_characters))
    if squeezed and len(data) % row_bytes == 0:
        cells = []
        if not args.no_position:
            cells.append(format((display_offset + len(data)) & 0xffffffff, "08x"))
        cells.extend([" " * pwidth for _ in range(panels)])
        if not args.no_characters:
            cells.extend([" " * 8 for _ in range(panels)])
        print(row_line(cells, args.border, panels, not args.no_position, not args.no_characters))
    bot = bottom_line(widths, args.border)
    if bot:
        print(bot)


def include_output(data, path):
    name = "stdin" if not path else os.path.basename(path)
    name = re.sub(r"\W", "_", name)
    print(f"unsigned char {name}[] = {{")
    for i in range(0, len(data), 12):
        vals = [f"0x{b:02x}" for b in data[i:i + 12]]
        comma = "," if i + 12 < len(data) else ""
        print("  " + ", ".join(vals) + comma)
    print("};")
    print(f"unsigned int {name}_len = {len(data)};")


def print_color_table():
    print("┌────────────┬────────────────┐")
    print("│Byte Type   │Example         │")
    print("├────────────┼────────────────┤")
    for name, b in [("NULL", 0), ("ASCII", 65), ("Whitespace", 10), ("Other", 1), ("Non-ASCII", 255)]:
        print(f"│{name:<12}│{maybe_color(format(b, '02x'), b, True):<16}│")
    print("└────────────┴────────────────┘")


class Parser(argparse.ArgumentParser):
    def error(self, message):
        print(f"error: {message}", file=sys.stderr)
        self.print_usage(sys.stderr)
        sys.exit(2)


def build_parser():
    p = Parser(prog="executable", description="A command-line hex viewer", add_help=False)
    p.add_argument("file", nargs="?")
    p.add_argument("-n", "--length", "--bytes", "-c", "-l")
    p.add_argument("-s", "--skip", default="0")
    p.add_argument("--block-size", default="512")
    p.add_argument("-v", "--no-squeezing", action="store_true")
    p.add_argument("--color", choices=["always", "auto", "never", "force"], default="always")
    p.add_argument("--border", choices=["unicode", "ascii", "none"], default="unicode")
    p.add_argument("-p", "--plain", action="store_true")
    p.add_argument("--no-characters", action="store_true")
    p.add_argument("-C", "--characters", action="store_true")
    p.add_argument("--character-table", choices=["default", "ascii", "codepage-1047", "codepage-437", "braille"], default="default")
    p.add_argument("--color-scheme", choices=["default", "gradient"], default="default")
    p.add_argument("-P", "--no-position", action="store_true")
    p.add_argument("-o", "--display-offset", default="0")
    p.add_argument("--panels")
    p.add_argument("-g", "--group-size", "--groupsize", type=int, choices=[1, 2, 4, 8], default=1)
    p.add_argument("--endianness", "-e", nargs="?", const="little", choices=["little", "big"], default="big")
    p.add_argument("-b", "--base", choices=["binary", "octal", "decimal", "hexadecimal"], default="hexadecimal")
    p.add_argument("--terminal-width", type=int)
    p.add_argument("--print-color-table", action="store_true")
    p.add_argument("-i", "--include", action="store_true")
    p.add_argument("--completion", choices=["bash", "elvish", "fish", "powershell", "zsh"])
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    return p


HELP = """A command-line hex viewer

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]  The file to display. If no FILE argument is given, read from STDIN

Options:
  -n, --length <N>                Only read N bytes from the input
  -s, --skip <N>                  Skip the first N bytes of the input
      --block-size <SIZE>         Sets the size of the `block` unit to SIZE [default: 512]
  -v, --no-squeezing              Displays all input data
      --color <WHEN>              When to use colors [default: always]
      --border <STYLE>            Whether to draw a border [default: unicode]
  -p, --plain                     Display output with --no-characters, --no-position, --border=none, and --color=never
      --no-characters             Do not show the character panel on the right
  -C, --characters                Show the character panel on the right
      --character-table <FORMAT>  Defines how bytes are mapped to characters
      --color-scheme <FORMAT>     Defines the color scheme for the characters
  -P, --no-position               Whether to display the position panel on the left
  -o, --display-offset <N>        Add N bytes to the displayed file position
      --panels <N>                Sets the number of hex data panels to be displayed
  -g, --group-size <N>            Number of bytes/octets that should be grouped together
      --endianness <FORMAT>       Whether to print groups in little-endian or big-endian format
  -b, --base <B>                  Sets the base used for the bytes
      --terminal-width <N>        Sets the number of terminal columns to be displayed
      --print-color-table         Print a table showing how different types of bytes are colored
  -i, --include                   Output in C include file style
      --completion <SHELL>        Show shell completion for a certain shell
  -h, --help                      Print help (see more with '--help')
  -V, --version                   Print version
"""


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--help" in argv or "-h" in argv:
        print(HELP, end="")
        return 0
    p = build_parser()
    args = p.parse_args(argv)
    if args.version:
        print(VERSION)
        return 0
    if args.completion:
        print(f"# completion for {args.completion}")
        return 0
    if args.plain:
        args.no_characters = True
        args.no_position = True
        args.border = "none"
        args.color = "never"
    if args.characters:
        args.no_characters = False
    try:
        block = parse_num(args.block_size, 512, False)
        length = parse_num(args.length, block, False) if args.length is not None else None
        skip = parse_num(args.skip, block, True)
        disp = parse_num(args.display_offset, block, True)
    except ValueError as e:
        print(f"Error: invalid value '{e.args[0]}'", file=sys.stderr)
        return 2
    data, size = read_input(args.file, skip, length)
    if args.display_offset.startswith("-") and size is not None:
        disp = size + disp
    use_color = args.color in ("always", "force") and not (args.color != "force" and os.environ.get("NO_COLOR"))
    if args.print_color_table:
        print_color_table()
    elif args.include:
        include_output(data, args.file)
    else:
        render(data, args, disp + (skip if skip > 0 else 0), use_color)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
