#!/usr/bin/env python3
import re
import sys


USAGE = """Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:

OPTIONS:
  -interval duration
    \tWhen url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)
  -rows int
    \tLimits the height of the graph output.
  -steps int
    \tNumber of values to plot. (default 100)
  -url string
    \tURL to fetch every second. Read JSON objects from stdin if not specified.

FIELD_SPEC: [<option>[,<option>...]:]path
  option:
    - counter: Computes the difference with the last value. The value must increase monotonically.
    - marker: When the value is none-zero, a vertical line is drawn.
  path:
    JSON field path (eg: field.sub-field).
"""


FLAGS = {
    "interval": "duration",
    "rows": "int",
    "steps": "int",
    "url": "string",
}


def emit_usage(error=None, status=0):
    if error:
        sys.stderr.write(error + "\n")
    sys.stderr.write(USAGE)
    return status


def bad_flag_syntax(flag):
    return emit_usage(f"bad flag syntax: {flag}", 2)


def unknown_flag(name):
    return emit_usage(f"flag provided but not defined: -{name}", 2)


def parse_int(value, name):
    if not re.fullmatch(r"[+-]?\d+", value):
        raise ValueError
    return int(value, 10)


def parse_duration(value):
    # The reference accepts integer Go-style duration pieces such as 100ms,
    # 1s, 1m, and 1h2m3s, but rejects bare numbers and fractional values.
    if value == "":
        raise ValueError
    pattern = re.compile(r"[+-]?\d+(?:ns|us|µs|μs|ms|s|m|h)")
    pos = 0
    while pos < len(value):
        m = pattern.match(value, pos)
        if not m:
            raise ValueError
        pos = m.end()


def split_flag(token):
    if token == "-" or token == "--":
        return None, None, None, False
    if not token.startswith("-"):
        return None, None, None, False
    if token.startswith("---"):
        return None, None, None, True

    stripped = token[2:] if token.startswith("--") else token[1:]
    if stripped == "":
        return None, None, None, True
    if "=" in stripped:
        name, value = stripped.split("=", 1)
        has_value = True
    else:
        name, value, has_value = stripped, None, False
    return name, value, has_value, False


def parse_args(argv):
    i = 0
    while i < len(argv):
        token = argv[i]
        name, value, has_inline_value, syntax_error = split_flag(token)
        if syntax_error:
            return bad_flag_syntax(token)
        if name is None:
            break
        if name in ("h", "help"):
            return emit_usage(None, 0)
        kind = FLAGS.get(name)
        if kind is None:
            return unknown_flag(name.split("=", 1)[0])
        if not has_inline_value:
            i += 1
            if i >= len(argv):
                return emit_usage(f"flag needs an argument: -{name}", 2)
            value = argv[i]

        try:
            if kind == "int":
                parse_int(value, name)
            elif kind == "duration":
                parse_duration(value)
            else:
                # string flags accept any following token, including one
                # that begins with a dash.
                pass
        except ValueError:
            return emit_usage(f'invalid value "{value}" for flag -{name}: parse error', 2)
        i += 1
    return None


def main(argv):
    # The original probes terminal capabilities before doing any visible work.
    sys.stdout.write("\x1b[c")
    sys.stdout.flush()

    result = parse_args(argv)
    if result is not None:
        return result

    sys.stdout.write("jplot:  iTerm2, Kitty, or DRCS Sixel graphics required\n")
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
