#!/usr/bin/env python3
import sys, csv, argparse, re, os, random, math, statistics, collections, shutil

COMMANDS = [
('cat','Concatenate by row or column'),('count','Count records'),('fixlengths','Makes all records have same length'),('flatten','Show one field per line'),('fmt','Format CSV output (change field delimiter)'),('frequency','Show frequency tables'),('headers','Show header names'),('help','Show this usage message.'),('index','Create CSV index for faster access'),('input','Read CSV data with special quoting rules'),('join','Join CSV files'),('partition','Partition CSV data based on a column value'),('sample','Randomly sample CSV data'),('reverse','Reverse rows of CSV data'),('search','Search CSV data with regexes'),('select','Select columns from CSV'),('slice','Slice records from CSV'),('sort','Sort CSV data'),('split','Split CSV data into many files'),('stats','Compute basic statistics'),('table','Align CSV data into columns')]

HELP_TOP = """Usage:
    xsv <command> [<args>...]
    xsv [options]

Options:
    --list        List all commands available.
    -h, --help    Display this message
    <command> -h  Display the command help message
    --version     Print version info and exit

Commands:
""" + ''.join(f"    {c:<11} {d}\n" for c,d in COMMANDS if c!='help')

HELP = {}
HELP['count'] = """Prints a count of the number of records in the CSV data.\n\nUsage:\n    xsv count [options] [<input>]\n"""
HELP['headers'] = """Prints the fields of the first row in the CSV data.\n\nUsage:\n    xsv headers [options] [<input>...]\n"""
HELP['select'] = """Select columns from CSV data efficiently.\n\nUsage:\n    xsv select [options] [--] <selection> [<input>]\n"""
HELP['slice'] = """Returns the rows in the range specified (starting at 0, half-open interval).\n\nUsage:\n    xsv slice [options] [<input>]\n"""
HELP['sort'] = """Sorts CSV data lexicographically.\n\nUsage:\n    xsv sort [options] [<input>]\n"""

def top_help(): return HELP_TOP.rstrip()+"\n"

def die(msg, code=1):
    sys.stderr.write(str(msg).rstrip()+"\n"); sys.exit(code)

def add_common(p, output=False, noheaders=False):
    p.add_argument('-d','--delimiter', default=',')
    if output: p.add_argument('-o','--output')
    if noheaders: p.add_argument('-n','--no-headers', action='store_true')

def delim(s):
    if s == r'\t': return '\t'
    if len(s)!=1: die(f"Could not convert '{s}' to a single ASCII character.")
    return s

def open_in(path, newline=''):
    if not path or path == '-': return sys.stdin
    return open(path, newline=newline)

def open_out(path, newline=''):
    if not path or path == '-': return sys.stdout
    return open(path, 'w', newline=newline)

def read_rows(path=None, delimiter=',', quotechar='"', escapechar=None, quoting=csv.QUOTE_MINIMAL):
    f = open_in(path)
    try:
        return [r for r in csv.reader(f, delimiter=delim(delimiter), quotechar=quotechar, escapechar=escapechar, quoting=quoting)]
    finally:
        if f is not sys.stdin: f.close()

def write_rows(rows, path=None, delimiter=',', quotechar='"', escapechar=None, quote_all=False, lineterminator='\n'):
    f = open_out(path)
    try:
        w = csv.writer(f, delimiter=delim(delimiter), quotechar=quotechar, escapechar=escapechar,
                       quoting=csv.QUOTE_ALL if quote_all else csv.QUOTE_MINIMAL, lineterminator=lineterminator)
        w.writerows(rows)
    finally:
        if f is not sys.stdout: f.close()

def split_top(s):
    out=[]; cur=''; inq=False; i=0
    while i < len(s):
        ch=s[i]
        if ch=='"':
            if inq and i+1<len(s) and s[i+1]=='"': cur+='"'; i+=2; continue
            inq=not inq; i+=1; continue
        if ch==',' and not inq:
            out.append(cur); cur=''
        else: cur+=ch
        i+=1
    out.append(cur)
    return [x.strip() for x in out if x.strip()!='']

def name_index(tok, headers):
    m = re.fullmatch(r'(.+)\[(\d+)\]', tok)
    nth=1
    if m: tok,nth=m.group(1),int(m.group(2))
    if tok.isdigit(): return int(tok)-1
    hits=[i for i,h in enumerate(headers or []) if h==tok]
    if len(hits)>=nth: return hits[nth-1]
    die(f"Selector '{tok}' did not match any columns")

def parse_selection(sel, headers, ncols):
    negate = sel.startswith('!')
    if negate: sel=sel[1:]
    selected=[]
    for part in split_top(sel):
        if '-' in part and part != '-':
            a,b = part.split('-',1)
            start = 0 if a=='' else name_index(a, headers)
            end = ncols-1 if b=='' else name_index(b, headers)
            step = 1 if end>=start else -1
            selected.extend(range(start,end+step,step))
        else:
            selected.append(name_index(part, headers))
    if negate:
        banned=set(selected); return [i for i in range(ncols) if i not in banned]
    return selected

def maybe_help(argv, name):
    if '-h' in argv or '--help' in argv:
        print(HELP.get(name, f"Usage:\n    xsv {name} [options]")); sys.exit(0)

def cmd_count(argv):
    maybe_help(argv,'count'); p=argparse.ArgumentParser(add_help=False); add_common(p,noheaders=True); p.add_argument('input', nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); n=len(rows) if a.no_headers else max(0,len(rows)-1); print(n)

def cmd_headers(argv):
    maybe_help(argv,'headers'); p=argparse.ArgumentParser(add_help=False); p.add_argument('-j','--just-names',action='store_true'); p.add_argument('--intersect',action='store_true'); p.add_argument('-d','--delimiter',default=','); p.add_argument('inputs',nargs='*'); a=p.parse_args(argv)
    hs=[]
    for inp in (a.inputs or [None]):
        rows=read_rows(inp,a.delimiter); hs.append(rows[0] if rows else [])
    if a.intersect and hs:
        vals=[]
        for hrow in hs:
            for h in hrow:
                if h not in vals: vals.append(h)
        for h in vals: print(h)
    elif a.just_names or len(hs)>1:
        for hrow in hs:
            for h in hrow: print(h)
    else:
        for i,h in enumerate(hs[0],1): print(f"{i:<4}{h}")

def cmd_select(argv):
    maybe_help(argv,'select'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True,noheaders=True); p.add_argument('selection'); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); n=max([len(r) for r in rows], default=0); headers=None if a.no_headers or not rows else rows[0]
    idx=parse_selection(a.selection, headers, n)
    write_rows([[r[i] if i<len(r) else '' for i in idx] for r in rows], a.output)

def cmd_slice(argv):
    maybe_help(argv,'slice'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True,noheaders=True); p.add_argument('-s','--start',type=int); p.add_argument('-e','--end',type=int); p.add_argument('-l','--len',dest='length',type=int); p.add_argument('-i','--index',type=int); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); head=[]; data=rows
    if not a.no_headers and rows: head=[rows[0]]; data=rows[1:]
    st=0 if a.start is None else a.start
    if a.index is not None: st=a.index; en=st+1
    elif a.length is not None: en=st+a.length
    else: en=len(data) if a.end is None else a.end
    write_rows(head+data[st:en], a.output)

def cmd_reverse(argv):
    maybe_help(argv,'reverse'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True,noheaders=True); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); out=list(reversed(rows)) if a.no_headers or not rows else [rows[0]]+list(reversed(rows[1:])); write_rows(out,a.output)

def cmd_sort(argv):
    maybe_help(argv,'sort'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True,noheaders=True); p.add_argument('-s','--select'); p.add_argument('-N','--numeric',action='store_true'); p.add_argument('-R','--reverse',action='store_true'); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); head=[]; data=rows
    if not a.no_headers and rows: head=[rows[0]]; data=rows[1:]
    n=max([len(r) for r in rows], default=0); idx=parse_selection(a.select, head[0] if head else None, n) if a.select else list(range(n))
    def key(r):
        vals=[r[i] if i<len(r) else '' for i in idx]
        if a.numeric:
            return [float(x) if re.fullmatch(r'[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?',x or '') else math.inf for x in vals]
        return vals
    data.sort(key=key, reverse=a.reverse); write_rows(head+data,a.output)

def cmd_search(argv):
    maybe_help(argv,'search'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True,noheaders=True); p.add_argument('-i','--ignore-case',action='store_true'); p.add_argument('-s','--select'); p.add_argument('-v','--invert-match',action='store_true'); p.add_argument('regex'); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); head=[]; data=rows
    if not a.no_headers and rows: head=[rows[0]]; data=rows[1:]
    flags=re.I if a.ignore_case else 0; rg=re.compile(a.regex,flags)
    n=max([len(r) for r in rows], default=0); idx=parse_selection(a.select, head[0] if head else None, n) if a.select else list(range(n))
    out=head[:]
    for r in data:
        m=any(rg.search(r[i] if i<len(r) else '') for i in idx)
        if m ^ a.invert_match: out.append(r)
    write_rows(out,a.output)

def cmd_fmt(argv):
    maybe_help(argv,'fmt'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True); p.add_argument('-t','--out-delimiter',default=','); p.add_argument('--crlf',action='store_true'); p.add_argument('--ascii',action='store_true'); p.add_argument('--quote',default='"'); p.add_argument('--quote-always',action='store_true'); p.add_argument('--escape'); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); od='\x1f' if a.ascii else a.out_delimiter; lt='\r\n' if a.crlf or a.ascii else '\n'; write_rows(rows,a.output,od,a.quote,a.escape,a.quote_always,lt)

def cmd_input(argv):
    maybe_help(argv,'input'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True); p.add_argument('--quote',default='"'); p.add_argument('--escape'); p.add_argument('--no-quoting',action='store_true'); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter,a.quote,a.escape,csv.QUOTE_NONE if a.no_quoting else csv.QUOTE_MINIMAL); write_rows(rows,a.output)

def cmd_fixlengths(argv):
    maybe_help(argv,'fixlengths'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True); p.add_argument('-l','--length',type=int); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); L=a.length if a.length is not None else max([max(1,len([x for x in r if x!=''] if any(x!='' for x in r) else [''])) if False else len(r) for r in rows], default=0)
    write_rows([(r[:L]+['']*max(0,L-len(r))) for r in rows],a.output)

def cmd_flatten(argv):
    maybe_help(argv,'flatten'); p=argparse.ArgumentParser(add_help=False); add_common(p,noheaders=True); p.add_argument('-c','--condense',type=int); p.add_argument('-s','--separator',default='#'); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); headers=[]; data=rows
    if not a.no_headers and rows: headers=rows[0]; data=rows[1:]
    n=max([len(r) for r in rows], default=0); labels=headers if headers else [str(i) for i in range(n)]; width=max([len(x) for x in labels], default=0)
    if not headers:
        width += 1
    for ri,r in enumerate(data):
        for i in range(n):
            v=r[i] if i<len(r) else ''
            if a.condense is not None and len(v)>a.condense: v=v[:a.condense]
            print(f"{(labels[i] if i<len(labels) else str(i+1)):<{width}}  {v}")
        if a.separator and ri != len(data)-1: print(a.separator)

def cmd_table(argv):
    maybe_help(argv,'table'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True); p.add_argument('-w','--width',type=int,default=2); p.add_argument('-p','--pad',type=int,default=2); p.add_argument('-c','--condense',type=int); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); n=max([len(r) for r in rows], default=0)
    proc=[]
    for r in rows:
        rr=[]
        for i in range(n):
            v=r[i] if i<len(r) else ''
            if a.condense is not None and len(v)>a.condense: v=v[:a.condense]
            rr.append(v)
        proc.append(rr)
    widths=[max([a.width]+[len(r[i]) for r in proc]) for i in range(n)] if n else []
    f=open_out(a.output)
    try:
        for r in proc:
            line=(' '*a.pad).join((r[i].ljust(widths[i]) if i < n-1 else r[i]) for i in range(n))
            print(line, file=f)
    finally:
        if f is not sys.stdout: f.close()

def cmd_frequency(argv):
    maybe_help(argv,'frequency'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True,noheaders=True); p.add_argument('-s','--select'); p.add_argument('-l','--limit',type=int,default=10); p.add_argument('-a','--asc',action='store_true'); p.add_argument('--no-nulls',action='store_true'); p.add_argument('-j','--jobs'); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); head=[]; data=rows
    if not a.no_headers and rows: head=rows[0]; data=rows[1:]
    n=max([len(r) for r in rows], default=0); idx=parse_selection(a.select, head if head else None, n) if a.select else list(range(n)); out=[['field','value','count']]
    for i in idx:
        c=collections.Counter()
        for r in data:
            v=r[i] if i<len(r) else ''
            if v=='' and a.no_nulls: continue
            c[v]+=1
        items=list(c.items()); items.sort(key=lambda kv:(kv[1],kv[0]) if a.asc else (-kv[1],kv[0]))
        if a.limit: items=items[:a.limit]
        field=head[i] if head and i<len(head) else str(i+1)
        for v,cnt in items: out.append([field,'(NULL)' if v=='' else v,str(cnt)])
    write_rows(out,a.output)

def infer_type(vals):
    non=[v for v in vals if v!='']
    if not non: return 'NULL'
    try:
        for v in non: int(v)
        return 'Integer'
    except: pass
    try:
        for v in non: float(v)
        return 'Float'
    except: return 'Unicode'

def fmt_num(x): return str(int(x)) if isinstance(x,float) and x.is_integer() else str(x)

def cmd_stats(argv):
    maybe_help(argv,'stats'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True,noheaders=True); p.add_argument('-s','--select'); p.add_argument('--everything',action='store_true'); p.add_argument('--mode',action='store_true'); p.add_argument('--cardinality',action='store_true'); p.add_argument('--median',action='store_true'); p.add_argument('--nulls',action='store_true'); p.add_argument('-j','--jobs'); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); head=[]; data=rows
    if not a.no_headers and rows: head=rows[0]; data=rows[1:]
    n=max([len(r) for r in rows], default=0); idx=parse_selection(a.select, head if head else None, n) if a.select else list(range(n))
    extra=a.everything; cols=['field','type','sum','min','max','min_length','max_length','mean','stddev']
    show_med=extra or a.median; show_mode=extra or a.mode; show_card=extra or a.cardinality
    if show_med: cols.append('median')
    if show_mode: cols.append('mode')
    if show_card: cols.append('cardinality')
    out=[cols]
    for i in idx:
        vals=[r[i] if i<len(r) else '' for r in data]; typ=infer_type(vals); field=head[i] if head and i<len(head) else str(i+1)
        non=[v for v in vals if v!='']; pop=vals if a.nulls else non
        lengths=[len(v) for v in vals]
        row=[field,typ,'','','',str(min(lengths) if lengths else 0),str(max(lengths) if lengths else 0),'','']
        if typ in ('Integer','Float'):
            nums=[float(v) for v in pop if v!='']
            if nums:
                row[2]=fmt_num(sum(nums)); row[3]=fmt_num(min(nums)); row[4]=fmt_num(max(nums)); row[7]=str(sum(nums)/len(nums)); row[8]=str(statistics.pstdev(nums))
        else:
            if non: row[3]=min(non); row[4]=max(non)
        if show_med:
            row.append(str(statistics.median([float(v) for v in non])) if typ in ('Integer','Float') and non else '')
        if show_mode:
            c=collections.Counter(non); m='N/A'
            if c:
                mc=max(c.values()); modes=sorted([k for k,v in c.items() if v==mc])
                m=modes[0] if mc>1 else 'N/A'
            row.append(m)
        if show_card: row.append(str(len(set(vals))))
        out.append(row)
    write_rows(out,a.output)

def cmd_cat(argv):
    maybe_help(argv,'cat'); p=argparse.ArgumentParser(add_help=False); p.add_argument('-p','--pad',action='store_true'); add_common(p,output=True,noheaders=True); p.add_argument('mode',choices=['rows','columns']); p.add_argument('inputs',nargs='*'); a=p.parse_args(argv)
    tables=[read_rows(inp,a.delimiter) for inp in (a.inputs or [None])]
    out=[]
    if a.mode=='rows':
        for ti,t in enumerate(tables):
            out.extend(t if (a.no_headers or ti==0) else t[1:])
    else:
        maxlen=max(map(len,tables), default=0) if a.pad else min(map(len,tables), default=0)
        for r in range(maxlen):
            row=[]
            for t in tables: row.extend(t[r] if r<len(t) else ['']*(max([len(x) for x in t], default=0)))
            out.append(row)
    write_rows(out,a.output)

def cmd_join(argv):
    maybe_help(argv,'join'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True,noheaders=True); p.add_argument('--no-case',action='store_true'); p.add_argument('--left',action='store_true'); p.add_argument('--right',action='store_true'); p.add_argument('--full',action='store_true'); p.add_argument('--cross',action='store_true'); p.add_argument('--nulls',action='store_true'); p.add_argument('columns1'); p.add_argument('input1'); p.add_argument('columns2'); p.add_argument('input2'); a=p.parse_args(argv)
    r1=read_rows(a.input1,a.delimiter); r2=read_rows(a.input2,a.delimiter); h1=[]; h2=[]; d1=r1; d2=r2
    if not a.no_headers and r1 and r2: h1=r1[0]; h2=r2[0]; d1=r1[1:]; d2=r2[1:]
    n1=max([len(r) for r in r1], default=0); n2=max([len(r) for r in r2], default=0); i1=parse_selection(a.columns1,h1 if h1 else None,n1); i2=parse_selection(a.columns2,h2 if h2 else None,n2)
    def key(r,idx):
        vals=[(r[i] if i<len(r) else '').strip() for i in idx]
        if not a.nulls and any(v=='' for v in vals): return None
        return tuple(v.lower() for v in vals) if a.no_case else tuple(vals)
    out=[]
    if h1 or h2: out.append(h1+h2)
    if a.cross:
        for x in d1:
            for y in d2: out.append(x+y)
    else:
        mp=collections.defaultdict(list)
        for j,y in enumerate(d2):
            k=key(y,i2)
            if k is not None: mp[k].append((j,y))
        matched=set()
        for x in d1:
            k=key(x,i1); ys=mp.get(k,[]) if k is not None else []
            if ys:
                for j,y in ys: matched.add(j); out.append(x+y)
            elif a.left or a.full: out.append(x+['']*n2)
        if a.right or a.full:
            for j,y in enumerate(d2):
                if j not in matched: out.append(['']*n1+y)
    write_rows(out,a.output)

def sanitize(s):
    s=s[:255]; return re.sub(r'[^A-Za-z0-9._-]+','_',s) or '_'

def cmd_split(argv):
    maybe_help(argv,'split'); p=argparse.ArgumentParser(add_help=False); add_common(p,noheaders=True); p.add_argument('-s','--size',type=int,default=500); p.add_argument('-j','--jobs'); p.add_argument('--filename',default='{}.csv'); p.add_argument('outdir'); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    os.makedirs(a.outdir,exist_ok=True); rows=read_rows(a.input,a.delimiter); head=[]; data=rows
    if not a.no_headers and rows: head=[rows[0]]; data=rows[1:]
    for start in range(0,len(data),a.size): write_rows(head+data[start:start+a.size], os.path.join(a.outdir,a.filename.replace('{}',str(start))))

def cmd_partition(argv):
    maybe_help(argv,'partition'); p=argparse.ArgumentParser(add_help=False); add_common(p,noheaders=True); p.add_argument('--filename',default='{}.csv'); p.add_argument('-p','--prefix-length',type=int); p.add_argument('--drop',action='store_true'); p.add_argument('column'); p.add_argument('outdir'); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    os.makedirs(a.outdir,exist_ok=True); rows=read_rows(a.input,a.delimiter); head=[]; data=rows
    if not a.no_headers and rows: head=rows[0]; data=rows[1:]
    n=max([len(r) for r in rows], default=0); idx=parse_selection(a.column, head if head else None, n)[0]; groups=collections.defaultdict(list)
    for r in data:
        v=r[idx] if idx<len(r) else ''
        if a.prefix_length: v=v[:a.prefix_length]
        row=[x for j,x in enumerate(r) if not(a.drop and j==idx)]
        groups[sanitize(v)].append(row)
    hout=[x for j,x in enumerate(head) if not(a.drop and j==idx)] if head else []
    for val,rs in groups.items(): write_rows(([hout] if hout else [])+rs, os.path.join(a.outdir,a.filename.replace('{}',val)))

def cmd_sample(argv):
    maybe_help(argv,'sample'); p=argparse.ArgumentParser(add_help=False); add_common(p,output=True,noheaders=True); p.add_argument('--seed',type=int); p.add_argument('size',type=int); p.add_argument('input',nargs='?'); a=p.parse_args(argv)
    rows=read_rows(a.input,a.delimiter); head=[]; data=rows
    if not a.no_headers and rows: head=[rows[0]]; data=rows[1:]
    rnd=random.Random(a.seed); out=rnd.sample(data, min(a.size,len(data))) if a.size < len(data) else data[:]; write_rows(head+out,a.output)

def cmd_index(argv):
    maybe_help(argv,'index')
    # Compatibility placeholder: create the conventional sidecar so scripts proceed.
    args=[x for x in argv if not x.startswith('-')]
    if args:
        open(args[-1]+'.idx','wb').close()

def main():
    argv=sys.argv[1:]
    if not argv or argv[0] in ('-h','--help','help'):
        print(top_help(), end=''); return
    if argv[0]=='--list': print('Installed commands:'); [print(f"    {c:<11} {d}") for c,d in COMMANDS if c!='help']; return
    if argv[0]=='--version': print('0.13.0'); return
    cmd=argv[0].replace('-','_'); fn=globals().get('cmd_'+cmd)
    if not fn: die(f"Unrecognized command: {argv[0]}")
    fn(argv[1:])
if __name__=='__main__': main()
