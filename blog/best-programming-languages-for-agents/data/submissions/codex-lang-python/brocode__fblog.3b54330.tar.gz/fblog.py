#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone

BOLD = "\033[1m"
RESET = "\033[0m"
DIM = "\033[2m"
GREY = "\033[38;2;150;150;150m"
CYAN = "\033[36m"

DEFAULT_MESSAGE_KEYS = ["short_message", "msg", "message"]
DEFAULT_TIME_KEYS = ["timestamp", "time", "@timestamp"]
DEFAULT_LEVEL_KEYS = ["level", "severity", "log.level", "loglevel"]
DEFAULT_MAIN = "{{bold(fixed_size 19 fblog_timestamp)}} {{level_style (uppercase (fixed_size 5 fblog_level))}}:{{#if fblog_prefix}} {{bold(cyan fblog_prefix)}}{{/if}} {{fblog_message}}"
DEFAULT_ADD = "{{bold (color_rgb 150 150 150 (min_size 25 key))}}: {{value}}"
HELP_TEXT = """json log viewer

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]

Options:
  -a, --additional-value <additional-value>
          adds additional values
      --config-file <config-file>
          configuration file to load
  -m, --message-key <message-key>
          Adds an additional key to detect the message in the log entry. The first matching key will be assigned to `fblog_message`.
      --print-lua
          Prints lua init expressions. Used for fblog debugging.
  -t, --time-key <time-key>
          Adds an additional key to detect the time in the log entry. The first matching key will be assigned to `fblog_timestamp`.
  -l, --level-key <level-key>
          Adds an additional key to detect the level in the log entry. The first matching key will be assigned to `fblog_level`.
      --map-level <from=to>
          Rewrite the log level from one value to another.
  -d, --dump-all
          dumps all values
  -x, --excluded-value <excluded-value>
          Excludes values (--dump-all is enabled implicitly)
  -p, --with-prefix
          consider all text before opening curly brace as prefix
  -f, --filter <filter>
          lua expression to filter log entries. `message ~= nil and string.find(message, "text.*") ~= nil`
      --no-implicit-filter-return-statement
          if you pass a filter expression 'return' is automatically prepended. Pass this switch to disable the implicit return.
      --main-line-format <main-line-format>
          Formats the main fblog output. All log values can be used. fblog provides sanitized variables starting with `fblog_`.
      --additional-value-format <additional-value-format>
          Formats the additional value fblog output.
  -s, --substitute
          Enable substitution of placeholders in the log messages with their corresponding values from the context.
  -c, --context-key <context-key>
          Use this key as the source of substitutions for the message. Value can either be an array ({1}) or an object ({key}).
  -F, --placeholder-format <placeholder-format>
          The format that should be used for substituting values in the message, where the key is the literal word `key`. Example: [[key]] or ${key}.
  -h, --help
          Print help
  -V, --version
          Print version"""


def color(code, text):
    return f"\033[{code}m{text}{RESET}"


def level_style(level):
    s = fixed_size(str(level or "unknown").upper(), 5)
    raw = str(level or "").lower()
    if raw in ("trace",):
        c = "1;36"
    elif raw in ("debug",):
        c = "1;34"
    elif raw in ("info", "information"):
        c = "1;32"
    elif raw in ("warn", "warning"):
        c = "1;33" if raw == "warn" else "1;35"
    elif raw in ("error", "err"):
        c = "1;31"
    elif raw in ("fatal", "critical", "unknown") or True:
        c = "1;35"
    return color(c, s)


def raw_line(line):
    return color("1;38;2;255;135;22", "??? >") + " " + line


def fixed_size(s, n):
    s = "" if s is None else str(s)
    if len(s) > n:
        return s[:n]
    return s.rjust(n)


def min_size(s, n):
    s = "" if s is None else str(s)
    return s.rjust(n) if len(s) < n else s


def scalar(v, quoted=False, styled=False):
    if isinstance(v, bool):
        txt = "true" if v else "false"
        if styled:
            return color("1;32" if v else "1;31", txt)
        return txt
    if v is None:
        return "null"
    if isinstance(v, (int, float)):
        txt = str(v)
        return color("1;36", txt) if styled else txt
    if isinstance(v, str):
        if styled:
            return color("1;33", v)
        return json.dumps(v) if quoted else v
    if isinstance(v, list):
        if styled:
            return DIM + "[" + RESET + (DIM + ", " + RESET).join(scalar(x, styled=True) for x in v) + DIM + "]" + RESET
        return json.dumps(v, ensure_ascii=False, separators=(",", ":"))
    if isinstance(v, dict):
        if styled:
            bits = []
            for k in sorted(v):
                bits.append(color("35", k) + DIM + ": " + RESET + scalar(v[k], styled=True))
            return DIM + "{" + RESET + (DIM + ", " + RESET).join(bits) + DIM + "}" + RESET
        return json.dumps(v, ensure_ascii=False, separators=(",", ":"))
    return str(v)


def split_path(path):
    return [p.strip() for p in path.split(">")]


def get_path(obj, path):
    cur = obj
    for part in split_path(path):
        if not part:
            continue
        name = part.split("[", 1)[0]
        if name:
            cur = cur[name]
        indexes = re.findall(r"\[(\d+)\]", part)
        if indexes:
            for idx in indexes:
                cur = cur[int(idx)]
        else:
            if not name:
                cur = cur[part]
    return cur


def first_value(obj, keys):
    for k in keys:
        try:
            if isinstance(obj, dict) and k in obj:
                return obj[k], k
            if ">" in k:
                return get_path(obj, k), k
        except Exception:
            pass
    return None, None


def norm_time(v):
    if v is None:
        return ""
    s = str(v)
    if re.fullmatch(r"\d{13}", s):
        return datetime.fromtimestamp(int(s) / 1000, timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    if re.fullmatch(r"\d{10}", s):
        return datetime.fromtimestamp(int(s), timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    m = re.match(r"(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)", s)
    if m:
        return m.group(1)
    m = re.match(r"([A-Z][a-z]{2} [A-Z][a-z]{2} +\d+ \d\d:\d\d:\d\d)", s)
    if m:
        return m.group(1)
    return s


def parse_simple_toml(path):
    cfg = {}
    level_map = {}
    section = None
    try:
        lines = open(path, encoding="utf-8").read().splitlines()
    except OSError:
        return cfg, level_map
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            continue
        if "=" not in line:
            continue
        k, v = [x.strip() for x in line.split("=", 1)]
        if section == "level_map":
            level_map[k.strip('"')] = v.strip().strip('"')
            continue
        if v.startswith("["):
            cfg[k] = re.findall(r'"([^"]*)"', v)
        else:
            cfg[k] = v.strip('"')
    return cfg, level_map


def flatten(value, prefix=""):
    out = []
    if isinstance(value, dict):
        for k in sorted(value):
            p = k if not prefix else f"{prefix} > {k}"
            out.extend(flatten(value[k], p))
    elif isinstance(value, list):
        for i, item in enumerate(value):
            p = f"{prefix}[{i}]"
            out.extend(flatten(item, p))
    else:
        out.append((prefix, value))
    return out


def eval_filter(expr, env):
    if not expr:
        return True
    e = expr.strip()
    if e.startswith("return "):
        e = e[7:].strip()
    e = e.replace("nil", "None")
    m = re.fullmatch(r'([A-Za-z_][\w.]*)\s*([~!]?=)=\s*"([^"]*)"', e)
    if m:
        val = env.get(m.group(1))
        op = m.group(2)
        rhs = m.group(3)
        return (str(val) == rhs) if op == "=" else (str(val) != rhs)
    m = re.search(r'string\.find\(([^,]+),\s*"([^"]*)"', e)
    if m:
        val = env.get(m.group(1).strip())
        found = val is not None and re.search(m.group(2), str(val)) is not None
        if "~= nil" in e:
            return found
        if "== nil" in e:
            return not found
    return True


def render_template(tpl, env):
    if tpl == DEFAULT_MAIN:
        ts = BOLD + fixed_size(env.get("fblog_timestamp", ""), 19) + RESET
        lvl = level_style(env.get("fblog_level"))
        pref = ""
        if env.get("fblog_prefix"):
            pref = " " + BOLD + CYAN + str(env["fblog_prefix"]) + RESET + RESET
        return f"{ts} {lvl}:{pref} {env.get('fblog_message','')}"
    if tpl == DEFAULT_ADD:
        return BOLD + GREY + min_size(env.get("key", ""), 25) + RESET + RESET + ": " + str(env.get("value", ""))
    def repl(m):
        key = m.group(1).strip()
        return str(env.get(key, ""))
    return re.sub(r"\{\{\s*([A-Za-z_][\w.]*)\s*\}\}", repl, tpl)


def substitute(msg, ctx, fmt):
    if not isinstance(msg, str):
        return msg
    def repl(m):
        key = m.group(1)
        try:
            val = ctx[int(key)] if isinstance(ctx, list) and key.isdigit() else ctx[key]
        except Exception:
            if fmt == "{key}":
                return DIM + "{" + RESET + color("1;31", key) + DIM + "}" + RESET
            return m.group(0)
        return scalar(val, styled=True)
    pat = re.escape(fmt).replace("key", r"([^{}#$\[\]]+)")
    if fmt == "{key}":
        pat = r"\{([^{}]+)\}"
    return re.sub(pat, repl, msg)


def process_line(line, args, cfg):
    text = line.rstrip("\n")
    prefix = ""
    json_text = text
    if args.with_prefix and "{" in text:
        i = text.find("{")
        prefix, json_text = text[:i].rstrip(), text[i:]
    try:
        obj = json.loads(json_text)
        if not isinstance(obj, dict):
            raise ValueError()
    except Exception:
        return [raw_line(text)]

    msg, _ = first_value(obj, cfg["message_keys"])
    ts, _ = first_value(obj, cfg["time_keys"])
    lvl, _ = first_value(obj, cfg["level_keys"])
    lvl = str(lvl) if lvl is not None else "unknown"
    lvl = cfg["level_map"].get(lvl, lvl)
    msg = "" if msg is None else str(msg)
    if args.substitute:
        try:
            ctx = get_path(obj, args.context_key)
        except Exception:
            ctx = obj.get(args.context_key)
        msg = substitute(msg, ctx, args.placeholder_format)
    env = {k: v for k, v in obj.items() if isinstance(k, str)}
    env.update({
        "fblog_message": msg,
        "message": msg,
        "fblog_timestamp": norm_time(ts),
        "fblog_level": lvl,
        "fblog_prefix": prefix,
    })
    if not eval_filter(args.filter, env):
        return []
    lines = [render_template(args.main_line_format, env)]
    keys = list(args.additional_value)
    if args.dump_all or args.excluded_value:
        excluded = set(args.excluded_value)
        keys = [k for k, _ in flatten(obj) if k not in excluded]
    for key in keys:
        try:
            val = get_path(obj, key)
        except Exception:
            continue
        val_txt = scalar(val, quoted=isinstance(val, str) and key.rstrip().endswith("]"))
        lines.append(render_template(args.additional_value_format, {"key": key, "value": val_txt, **env}))
    return lines


def build_parser():
    p = argparse.ArgumentParser(description="json log viewer", prog="executable", formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument("input", nargs="?", default="-", help="Sets the input file to use, otherwise assumes stdin [default: -]")
    p.add_argument("-a", "--additional-value", action="append", default=[], metavar="additional-value", help="adds additional values")
    p.add_argument("--config-file", metavar="config-file", help="configuration file to load")
    p.add_argument("-m", "--message-key", action="append", default=[], metavar="message-key")
    p.add_argument("--print-lua", action="store_true")
    p.add_argument("-t", "--time-key", action="append", default=[], metavar="time-key")
    p.add_argument("-l", "--level-key", action="append", default=[], metavar="level-key")
    p.add_argument("--map-level", action="append", default=[], metavar="from=to")
    p.add_argument("-d", "--dump-all", action="store_true")
    p.add_argument("-x", "--excluded-value", action="append", default=[], metavar="excluded-value")
    p.add_argument("-p", "--with-prefix", action="store_true")
    p.add_argument("-f", "--filter", default=None, metavar="filter")
    p.add_argument("--no-implicit-filter-return-statement", action="store_true")
    p.add_argument("--main-line-format", default=None, metavar="main-line-format")
    p.add_argument("--additional-value-format", default=None, metavar="additional-value-format")
    p.add_argument("-s", "--substitute", action="store_true")
    p.add_argument("-c", "--context-key", default="context", metavar="context-key")
    p.add_argument("-F", "--placeholder-format", default="{key}", metavar="placeholder-format")
    p.add_argument("-V", "--version", action="store_true")
    return p


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "-h" in argv or "--help" in argv:
        print(HELP_TEXT)
        return 0
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.version:
        print("fblog 4.17.0")
        return 0
    if args.print_lua:
        return 0
    cfg0, lm0 = parse_simple_toml(args.config_file) if args.config_file else ({}, {})
    level_map = dict(lm0)
    for item in args.map_level:
        if "=" in item:
            k, v = item.split("=", 1)
            level_map[k] = v
    cfg = {
        "message_keys": cfg0.get("message_keys", DEFAULT_MESSAGE_KEYS) + args.message_key,
        "time_keys": cfg0.get("time_keys", DEFAULT_TIME_KEYS) + args.time_key,
        "level_keys": cfg0.get("level_keys", DEFAULT_LEVEL_KEYS) + args.level_key,
        "level_map": level_map,
    }
    args.main_line_format = args.main_line_format or cfg0.get("main_line_format", DEFAULT_MAIN)
    args.additional_value_format = args.additional_value_format or cfg0.get("additional_value_format", DEFAULT_ADD)
    if args.excluded_value:
        args.dump_all = True
    fh = sys.stdin if args.input == "-" else open(args.input, encoding="utf-8", errors="replace")
    with fh:
        for line in fh:
            for out in process_line(line, args, cfg):
                print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
