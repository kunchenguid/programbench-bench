#!/usr/bin/env python3
import os
import re
import shlex
import subprocess
import sys
import tempfile
from collections import OrderedDict

VERSION = "pier 0.1.6"

MAIN_HELP = """pier 0.1.6
Benjamin Scholtz, Isak Johansson
A simple script management CLI

USAGE:
    executable [FLAGS] [OPTIONS] <alias> [args]...
    executable [FLAGS] [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       
            Prints help information

    -V, --version    
            Prints version information

    -v, --verbose    
            The level of verbosity


OPTIONS:
    -c, --config-file <path>    
            Sets a custom config file.
            
            DEFAULT PATH is otherwise determined in this order:
            
            - $PIER_CONFIG_PATH (environment variable if set)
            
            - pier.toml (in the current directory)
            
            - $XDG_CONFIG_HOME/pier/config.toml
            
            - $XDG_CONFIG_HOME/pier/config
            
            - $XDG_CONFIG_HOME/pier.toml
            
            - $HOME/.pier.toml
            
            - $HOME/.pier
            
             [env: PIER_CONFIG_PATH=]

ARGS:
    <alias>      
            The alias or name for the script.

    <args>...    
            The positional arguments to send to script.


SUBCOMMANDS:
    add            Add a new script to config.
    config-init    alias: init - Add a config file.
    copy           alias: cp - Copy existing alias to the new one
    edit           Edit a script matching alias.
    help           Prints this message or the help of the given subcommand(s)
    list           alias: ls - List scripts
    move           alias: mv, rename - Move/rename existing alias to the new one
    remove         alias: rm - Remove a script matching alias.
    run            Run a script matching alias.
    show           Show a script matching alias."""

HELPS = {
    "add": """executable-add 0.1.6
Add a new script to config.

USAGE:
    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]

FLAGS:
    -f, --force      Allows to overwrite the existing script
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -a, --alias <alias>                The alias or name for the script.
    -d, --description <description>    The description for the script.
    -t, --tag <tags>...                Set which tags the script belongs to.

ARGS:
    <command>    The command/script content to be executed. If this argument is not found it will open your $EDITOR
                 for you to enter the script into.""",
    "config-init": """executable-config-init 0.1.6
alias: init - Add a config file.

USAGE:
    executable config-init

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
    "copy": """executable-copy 0.1.6
alias: cp - Copy existing alias to the new one

USAGE:
    executable copy <from-alias> <to-alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <from-alias>    The alias of the script that will be copied.
    <to-alias>      The new alias of the copy of the script.""",
    "edit": """executable-edit 0.1.6
Edit a script matching alias.

USAGE:
    executable edit <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.""",
    "list": """executable-list 0.1.6
alias: ls - List scripts

Display options are determined by priority in this order:

1. List only aliases

2. Show full command

3. Command display with (cli option)

4. Command display with (config option)

USAGE:
    executable list [FLAGS] [OPTIONS]

FLAGS:
    -l, --cmd_full        
            Display the full command.

    -h, --help            
            Prints help information

    -q, --list_aliases    
            Only displays aliases of the scripts.

    -V, --version         
            Prints version information


OPTIONS:
    -c, --cmd_width <cmd-width>    
            The max number of characters to display from the command.

    -t, --tag <tags>...            
            Filter based on tags.""",
    "move": """executable-move 0.1.6
alias: mv, rename - Move/rename existing alias to the new one

USAGE:
    executable move [FLAGS] <from-alias> <to-alias>

FLAGS:
    -f, --force      Allows to overwrite the existing script
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <from-alias>    The alias of the script that will be moved.
    <to-alias>      The new alias of the script.""",
    "remove": """executable-remove 0.1.6
alias: rm - Remove a script matching alias.

USAGE:
    executable remove <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.""",
    "run": """executable-run 0.1.6
Run a script matching alias.

USAGE:
    executable run <alias> [args]...

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>      The alias or name for the script.
    <args>...    The positional arguments to send to script.""",
    "show": """executable-show 0.1.6
Show a script matching alias.

USAGE:
    executable show <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.""",
}

ALIASES = {
    "init": "config-init", "ls": "list", "cp": "copy", "mv": "move",
    "rename": "move", "rm": "remove",
}
COMMANDS = {"add", "config-init", "copy", "edit", "list", "move", "remove", "run", "show", "help"} | set(ALIASES)


def die(msg, code=1):
    print(f"error: {msg}", file=sys.stderr)
    raise SystemExit(code)


def unquote(v):
    v = v.strip()
    if len(v) >= 2 and v[0] in "'\"" and v[-1] == v[0]:
        q = v[0]
        s = v[1:-1]
        if q == '"':
            return bytes(s, "utf-8").decode("unicode_escape")
        return s
    if v.lower() == "true":
        return True
    if v.lower() == "false":
        return False
    try:
        return int(v)
    except ValueError:
        return v


def quote(s):
    return "'" + str(s).replace("\\", "\\\\").replace("'", "\\'") + "'"


def parse_array(text):
    text = text.strip()
    if text.startswith("[") and text.endswith("]"):
        inner = text[1:-1].strip()
        if not inner:
            return []
        return [unquote(x.strip()) for x in re.split(r"\s*,\s*", inner) if x.strip()]
    return []


def load_config(path, must_exist=True):
    if not path or not os.path.exists(path):
        if must_exist:
            die("No default config file found. See help for more info.")
        return {"scripts": OrderedDict(), "default": {}}
    data = {"scripts": OrderedDict(), "default": {}}
    section = None
    pending_key = None
    pending = []
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if pending_key:
            if line.startswith("]"):
                section[pending_key] = pending
                pending_key = None
                pending = []
            else:
                val = line.rstrip(",")
                if val:
                    pending.append(unquote(val))
            continue
        if line.startswith("[") and line.endswith("]"):
            name = line[1:-1].strip()
            if name == "default":
                section = data["default"]
            elif name.startswith("scripts."):
                alias = name.split(".", 1)[1]
                data["scripts"].setdefault(alias, {})
                section = data["scripts"][alias]
            else:
                section = {}
            continue
        if section is None or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip(), v.strip()
        if v == "[":
            pending_key = k
            pending = []
        elif v.startswith("["):
            section[k] = parse_array(v)
        else:
            section[k] = unquote(v)
    return data


def save_config(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for alias, ent in data["scripts"].items():
            f.write(f"[scripts.{alias}]\n")
            if "command" in ent:
                f.write(f"command = {quote(ent.get('command', ''))}\n")
            if ent.get("description", None) not in (None, ""):
                f.write(f"description = {quote(ent.get('description', ''))}\n")
            tags = ent.get("tags") or []
            if tags:
                f.write("tags = [\n")
                for t in tags:
                    f.write(f"    {quote(t)},\n")
                f.write("]\n")
            f.write("\n")
        f.write("[default]\n")
        for k, v in data.get("default", {}).items():
            if isinstance(v, bool):
                f.write(f"{k} = {'true' if v else 'false'}\n")
            elif isinstance(v, int):
                f.write(f"{k} = {v}\n")
            elif isinstance(v, list):
                f.write(f"{k} = [{', '.join(quote(x) for x in v)}]\n")
            else:
                f.write(f"{k} = {quote(v)}\n")


def find_config(explicit=None, for_init=False):
    if explicit:
        return explicit
    env = os.environ.get("PIER_CONFIG_PATH")
    if env:
        return env
    cwd = os.path.join(os.getcwd(), "pier.toml")
    if os.path.exists(cwd) or for_init:
        return cwd
    xdg = os.environ.get("XDG_CONFIG_HOME")
    home = os.path.expanduser("~")
    candidates = []
    if xdg:
        candidates += [os.path.join(xdg, "pier", "config.toml"),
                       os.path.join(xdg, "pier", "config"),
                       os.path.join(xdg, "pier.toml")]
    candidates += [os.path.join(home, ".pier.toml"), os.path.join(home, ".pier")]
    for p in candidates:
        if os.path.exists(p):
            return p
    return None


def split_globals(argv):
    out = []
    cfg = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-c", "--config-file"):
            if i + 1 >= len(argv):
                die("The argument '--config-file <path>' requires a value but none was supplied", 1)
            cfg = argv[i + 1]
            i += 2
        elif a.startswith("--config-file="):
            cfg = a.split("=", 1)[1]
            i += 1
        elif a in ("-v", "--verbose"):
            i += 1
        else:
            out.extend(argv[i:])
            break
    return cfg, out


def script_or_empty(data, alias):
    scripts = data["scripts"]
    if alias not in scripts:
        if not scripts:
            die("No scripts exist. Would you like to add a new script?")
        die(f"AliasNotFound: No script found by alias {alias}")
    return scripts[alias]


def table(rows):
    headers = ["Alias", "Tags", "Command", "Description"]
    widths = [len(h) for h in headers]
    for r in rows:
        for i, val in enumerate(r):
            widths[i] = max(widths[i], len(val))
    def row(vals):
        return "⋮ " + " ⋮ ".join(str(vals[i]).ljust(widths[i]) for i in range(4)) + " ⋮"
    sep = "≖" * len(row(headers))
    print(sep)
    print(row(headers))
    print(sep)
    for r in rows:
        print(row(r))
    print(sep)


def cmd_config_init(cfg):
    path = find_config(cfg, for_init=True)
    data = {"scripts": OrderedDict([("hello-pier", {
        "command": "echo Hello, Pier!",
        "description": "This is an example command.",
    })]), "default": {}}
    save_config(path, data)
    print("Added hello-pier")


def cmd_add(cfg, argv):
    alias = desc = None
    tags = []
    force = False
    command_parts = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELPS["add"]); return
        if a in ("-V", "--version"):
            print("executable-add 0.1.6"); return
        if a in ("-f", "--force"):
            force = True; i += 1
        elif a in ("-a", "--alias"):
            alias = argv[i + 1] if i + 1 < len(argv) else None; i += 2
        elif a.startswith("--alias="):
            alias = a.split("=", 1)[1]; i += 1
        elif a in ("-d", "--description"):
            desc = argv[i + 1] if i + 1 < len(argv) else ""; i += 2
        elif a in ("-t", "--tag"):
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                tags.append(argv[i]); i += 1
        elif a == "--":
            command_parts = argv[i + 1:]; break
        else:
            command_parts = argv[i:]; break
    if not alias:
        die("The following required arguments were not provided:\n    --alias <alias>", 1)
    path = find_config(cfg)
    data = load_config(path)
    if alias in data["scripts"] and not force:
        die(f"AliasAlreadyExists: Script with alias {alias} already exists")
    command = " ".join(command_parts)
    if not command:
        command = edit_text("")
    data["scripts"][alias] = {"command": command}
    if desc:
        data["scripts"][alias]["description"] = desc
    if tags:
        data["scripts"][alias]["tags"] = tags
    save_config(path, data)
    print(f"Added {alias}")


def edit_text(initial):
    editor = os.environ.get("EDITOR", "vi")
    fd, name = tempfile.mkstemp(prefix="pier-edit-", text=True)
    os.close(fd)
    with open(name, "w", encoding="utf-8") as f:
        f.write(initial)
    try:
        res = subprocess.run([editor, name])
        if res.returncode != 0:
            die(f"EditorError: Failed when trying to get input from editor Failed to open `{editor}` as a text editor or editor was terminated with errors.")
        with open(name, "r", encoding="utf-8") as f:
            return f.read().rstrip("\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def cmd_list(cfg, argv):
    only_aliases = False
    full = False
    width = None
    tags = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELPS["list"]); return
        if a in ("-V", "--version"):
            print("executable-list 0.1.6"); return
        if a in ("-q", "--list_aliases"):
            only_aliases = True; i += 1
        elif a in ("-l", "--cmd_full"):
            full = True; i += 1
        elif a in ("-c", "--cmd_width"):
            width = int(argv[i + 1]); i += 2
        elif a in ("-t", "--tag"):
            i += 1
            while i < len(argv) and not argv[i].startswith("-"):
                tags.append(argv[i]); i += 1
        else:
            i += 1
    data = load_config(find_config(cfg))
    rows = []
    for alias, ent in data["scripts"].items():
        etags = ent.get("tags") or []
        if tags and not any(t in etags for t in tags):
            continue
        if only_aliases:
            print(alias)
            continue
        cmd = str(ent.get("command", ""))
        if not full:
            w = width if width is not None else data.get("default", {}).get("cmd_width")
            if isinstance(w, int) and w >= 0:
                cmd = cmd[:w]
        rows.append([alias, ",".join(etags), cmd, str(ent.get("description", ""))])
    if not only_aliases:
        table(rows)


def run_alias(cfg, alias, args):
    data = load_config(find_config(cfg))
    ent = script_or_empty(data, alias)
    cmd = str(ent.get("command", ""))
    res = subprocess.run(["/bin/sh", "-c", cmd, alias] + args)
    raise SystemExit(res.returncode)


def cmd_show(cfg, argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(HELPS["show"]); return
    if argv[0] in ("-V", "--version"):
        print("executable-show 0.1.6"); return
    data = load_config(find_config(cfg))
    print(script_or_empty(data, argv[0]).get("command", ""))


def cmd_remove(cfg, argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(HELPS["remove"]); return
    data = load_config(find_config(cfg))
    alias = argv[0]
    script_or_empty(data, alias)
    del data["scripts"][alias]
    save_config(find_config(cfg), data)
    print(f"Removed {alias}")


def cmd_copy_move(cfg, argv, move=False):
    cname = "move" if move else "copy"
    if not argv or argv[0] in ("-h", "--help"):
        print(HELPS[cname]); return
    force = False
    if move and argv and argv[0] in ("-f", "--force"):
        force = True
        argv = argv[1:]
    if len(argv) < 2:
        die(f"The following required arguments were not provided:\n    <from-alias>\n    <to-alias>", 1)
    src, dst = argv[0], argv[1]
    path = find_config(cfg)
    data = load_config(path)
    ent = script_or_empty(data, src)
    if dst in data["scripts"] and not force:
        die(f"AliasAlreadyExists: Script with alias {dst} already exists")
    data["scripts"][dst] = dict(ent)
    if move:
        del data["scripts"][src]
        print(f"Moved {src} to {dst}")
    else:
        print(f"Copied {src} to {dst}")
    save_config(path, data)


def cmd_edit(cfg, argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(HELPS["edit"]); return
    path = find_config(cfg)
    data = load_config(path)
    ent = script_or_empty(data, argv[0])
    ent["command"] = edit_text(str(ent.get("command", "")))
    save_config(path, data)
    print(f"Edited {argv[0]}")


def main(argv):
    cfg, argv = split_globals(argv)
    if not argv or argv[0] in ("-h", "--help"):
        print(MAIN_HELP); return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION); return 0
    if argv[0] == "help":
        key = ALIASES.get(argv[1], argv[1]) if len(argv) > 1 else None
        print(HELPS.get(key, MAIN_HELP))
        return 0
    cmd = ALIASES.get(argv[0], argv[0])
    rest = argv[1:]
    if cmd == "config-init":
        if rest and rest[0] in ("-h", "--help"):
            print(HELPS["config-init"]); return 0
        cmd_config_init(cfg)
    elif cmd == "add":
        cmd_add(cfg, rest)
    elif cmd == "list":
        cmd_list(cfg, rest)
    elif cmd == "show":
        cmd_show(cfg, rest)
    elif cmd == "remove":
        cmd_remove(cfg, rest)
    elif cmd == "copy":
        cmd_copy_move(cfg, rest, False)
    elif cmd == "move":
        cmd_copy_move(cfg, rest, True)
    elif cmd == "edit":
        cmd_edit(cfg, rest)
    elif cmd == "run":
        if not rest or rest[0] in ("-h", "--help"):
            print(HELPS["run"]); return 0
        run_alias(cfg, rest[0], rest[1:])
    else:
        run_alias(cfg, argv[0], argv[1:])
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(141)
