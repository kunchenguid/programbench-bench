#!/usr/bin/env python3
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

ZERO = "0001-01-01T00:00:00Z"
STATUSES = ("pending", "active", "paused", "resolved", "template")
COMMANDS = {
    "next", "add", "template", "log", "start", "note", "stop", "done", "context",
    "modify", "edit", "undo", "sync", "open", "git", "remove", "show-projects",
    "show-tags", "show-active", "show-paused", "show-open", "show-resolved",
    "show-templates", "show-unorganised", "bash-completion", "fish-completion",
    "zsh-completion", "powershell-completion", "help", "version",
}

HELP = """Usage: dstask [id...] <cmd> [task summary/filter]

Where [task summary] is text with tags/project/priority specified. Tags are
specified with + (or - for filtering) eg: +work. The project is specified with
a project:g prefix eg: project:dstask -- no quotes. Priorities run from P3
(low), P2 (default) to P1 (high) and P0 (critical). Text can also be specified
for a substring search of description and notes.

Cmd and IDs can be swapped, multiple IDs can be specified for batch
operations.

run "dstask help <cmd>" for command specific help.

Add -- to ignore the current context. / can be used when adding tasks to note
any words after.

Available commands:

next              : Show most important tasks (priority, creation date -- truncated and default)
add               : Add a task
template          : Add a task template
log               : Log a task (already resolved)
start             : Change task status to active
note              : Append to or edit note for a task
stop              : Change task status to pending
done              : Resolve a task
context           : Set global context for task list and new tasks (use "none" to set no context)
modify            : Change task attributes specified on command line
edit              : Edit task with text editor
undo              : Undo last n commits
sync              : Pull then push to git repository, automatic merge commit.
open              : Open all URLs found in summary/annotations
git               : Pass a command to git in the repository. Used for push/pull.
remove            : Remove a task (use to remove tasks added by mistake)
show-projects     : List projects with completion status
show-tags         : List tags in use
show-active       : Show tasks that have been started
show-paused       : Show tasks that have been started then stopped
show-open         : Show all non-resolved tasks (without truncation)
show-resolved     : Show resolved tasks
show-templates    : Show task templates
show-unorganised  : Show untagged tasks with no projects (global context)
bash-completion   : Print bash completion script to stdout
fish-completion   : Print fish completion script to stdout
zsh-completion    : Print zsh completion script to stdout
help              : Get help on any command or show this message
version           : Show dstask version information
"""

CMD_HELP = {
    "add": "Usage: dstask add [template:<id>] [task summary] [--]\nExample: dstask add Fix main web page 500 error +bug P1 project:website\n\nAdd a task, returning the git commit output which contains the task ID, used\nlater to reference the task.\n",
    "next": "Usage: dstask next [filter] [--]\nUsage: dstask [filter] [--]\nExample: dstask +work +bug --\n\nDisplay list of non-resolved tasks in the current context, most recent last,\noptional filter. It is the default command, so \"next\" is unnecessary.\n",
    "done": "Usage: dstask <id...> done [closing note]\nExample: dstask 15 done\nExample: dstask 15 done replaced some hardware\n\nResolve a task. Optional text may be added, which will be appended to the note.\n",
    "start": "Usage: dstask <id...> start\nUsage: dstask start [task summary] [--]\nExample: dstask 15 start\nExample: dstask start Fix main web page 500 error +bug P1 project:website\n",
    "stop": "Usage: dstask <id...> stop [text]\nExample: dstask 15 stop\nExample: dstask 15 stop replaced some hardware\n",
    "modify": "Usage: dstask <id...> modify <filter>\nUsage: dstask modify <filter>\nExample: dstask 34 modify -work +home project:workbench -project:website\n\nModifiable attributes: tags, project and priority.\n",
    "context": "Usage: dstask context <filter>\nExample: dstask context +work -bug\nExample: dstask context none\n\nSet a global filter consisting of a project, tags or antitags.\n",
    "note": "Usage: dstask note <id>\nUsage: dstask note <id> <text>\nExample task 13 note problem is faulty hardware\n\nEdit or append text to the markdown notes attached to a particular task.\n",
    "remove": "Usage: dstask remove <id...>\nExample: dstask 15 remove\n\nRemove a task.\n",
    "show-projects": "Usage: dstask show-projects\n\nShow a breakdown of projects with progress information\n",
    "show-resolved": "Usage: dstask resolved\n\nShow a report of last 1000 resolved tasks.\n",
}


def now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def repo():
    r = os.environ.get("DSTASK_GIT_REPO")
    if r:
        return Path(r).expanduser()
    home = Path.home()
    return home / ".dstask"


def ensure_repo(r):
    r.mkdir(parents=True, exist_ok=True)
    for s in STATUSES:
        (r / s).mkdir(exist_ok=True)
    if not (r / ".git").exists() and shutil.which("git"):
        subprocess.run(["git", "-C", str(r), "init"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)


def q(s):
    if s == "":
        return '""'
    if re.search(r'[:#\-\[\]\{\},&*!|>"%@`]|^\s|\s$|^(true|false|null|yes|no|on|off)$', s, re.I):
        return json.dumps(s)
    return s


def write_task(t):
    p = Path(t["_path"])
    p.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        f"summary: {q(t.get('summary',''))}",
        "notes: " + (json.dumps(t.get("notes", "")) if "\n" not in t.get("notes", "") else "|2-\n" + "\n".join("  " + x for x in t["notes"].splitlines())),
        "tags:",
    ]
    tags = t.get("tags", [])
    if tags:
        lines += [f"- {q(x)}" for x in tags]
    else:
        lines[-1] += " []"
    lines += [
        f"project: {q(t.get('project',''))}",
        f"priority: {t.get('priority','P2')}",
        'delegatedto: ""',
        "subtasks: []",
        "dependencies: []",
        f"created: {t.get('created', ZERO)}",
        f"resolved: {t.get('resolved', ZERO)}",
        f"due: {t.get('due', ZERO)}",
    ]
    if "id" in t:
        lines.append(f"id: {t['id']}")
    p.write_text("\n".join(lines) + "\n")


def unquote(v):
    v = v.strip()
    if v in ("", '""'):
        return ""
    if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
        try:
            return json.loads(v)
        except Exception:
            return v[1:-1]
    return v


def read_task(path, status):
    data = {"tags": [], "status": status, "_path": str(path), "uuid": path.stem}
    lines = path.read_text(errors="replace").splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line or line.startswith(" "):
            i += 1
            continue
        if ":" not in line:
            i += 1
            continue
        k, v = line.split(":", 1)
        v = v.strip()
        if k == "tags":
            tags = []
            if v == "[]":
                data["tags"] = []
            else:
                i += 1
                while i < len(lines) and lines[i].startswith("- "):
                    tags.append(unquote(lines[i][2:]))
                    i += 1
                data["tags"] = tags
                continue
        elif k == "notes" and v.startswith("|"):
            body = []
            i += 1
            while i < len(lines) and (lines[i].startswith(" ") or lines[i] == ""):
                body.append(lines[i][2:] if lines[i].startswith("  ") else lines[i])
                i += 1
            data["notes"] = "\n".join(body)
            continue
        elif k in ("summary", "notes", "project", "priority", "created", "resolved", "due"):
            data[k] = unquote(v)
        elif k == "id":
            try:
                data["id"] = int(v)
            except ValueError:
                pass
        i += 1
    for k, default in (("summary", ""), ("notes", ""), ("project", ""), ("priority", "P2"), ("created", ZERO), ("resolved", ZERO), ("due", ZERO)):
        data.setdefault(k, default)
    return data


def all_tasks(r):
    out = []
    for s in STATUSES:
        for p in sorted((r / s).glob("*.yml")):
            out.append(read_task(p, s))
    existing = [t for t in out if t["status"] != "resolved"]
    next_id = 1
    for t in sorted(existing, key=lambda x: (x.get("created", ""), x["uuid"])):
        if "id" not in t:
            t["id"] = next_id
        next_id = max(next_id, t["id"] + 1)
    for t in out:
        if t["status"] == "resolved" and "id" not in t:
            t["id"] = 0
    return out


def public(t):
    return {k: t.get(k) for k in ("uuid", "status", "id", "summary", "notes", "tags", "project", "priority", "created", "resolved", "due")}


def dump(items):
    json.dump(items, sys.stdout, indent=2)


def parse_attrs(words):
    attrs = {"tags_add": [], "tags_remove": [], "text": [], "project": None, "priority": None, "due": None, "note": []}
    target = attrs["text"]
    for w in words:
        if w == "/":
            target = attrs["note"]
        elif target is attrs["text"] and re.fullmatch(r"P[0-3]", w):
            attrs["priority"] = w
        elif target is attrs["text"] and w.startswith("priority:") and w.split(":", 1)[1] in ("P0", "P1", "P2", "P3"):
            attrs["priority"] = w.split(":", 1)[1]
        elif target is attrs["text"] and w.startswith("due:"):
            d = w.split(":", 1)[1]
            attrs["due"] = d + "T00:00:00Z" if re.fullmatch(r"\d{4}-\d{2}-\d{2}", d) else d
        elif target is attrs["text"] and w.startswith("project:"):
            attrs["project"] = w.split(":", 1)[1]
        elif target is attrs["text"] and w.startswith("-project:"):
            attrs["project"] = ""
        elif target is attrs["text"] and len(w) > 1 and w[0] == "+":
            attrs["tags_add"].append(w[1:])
        elif target is attrs["text"] and len(w) > 1 and w[0] == "-":
            attrs["tags_remove"].append(w[1:])
        else:
            target.append(w)
    return attrs


def context_words(r):
    env = os.environ.get("DSTASK_CONTEXT")
    if env is not None:
        return [] if env in ("", "none", "--") else env.split()
    p = r / "context"
    if p.exists():
        txt = p.read_text().strip()
        return [] if txt in ("", "none") else txt.split()
    return []


def apply_attrs(t, attrs):
    tags = list(t.get("tags", []))
    for x in attrs["tags_remove"]:
        tags = [y for y in tags if y != x]
    for x in attrs["tags_add"]:
        if x and x not in tags:
            tags.append(x)
    t["tags"] = tags
    if attrs["project"] is not None:
        t["project"] = attrs["project"]
    if attrs["priority"]:
        t["priority"] = attrs["priority"]
    if attrs["due"]:
        t["due"] = attrs["due"]


def matches(t, words):
    attrs = parse_attrs(words)
    for tag in attrs["tags_add"]:
        if tag not in t.get("tags", []):
            return False
    for tag in attrs["tags_remove"]:
        if tag in t.get("tags", []):
            return False
    if attrs["project"] is not None and t.get("project", "") != attrs["project"]:
        return False
    if attrs["priority"] and t.get("priority") != attrs["priority"]:
        return False
    text = " ".join(attrs["text"]).lower()
    if text and text not in (t.get("summary", "") + "\n" + t.get("notes", "")).lower():
        return False
    return True


def sorted_tasks(tasks):
    pr = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
    return sorted(tasks, key=lambda t: (pr.get(t.get("priority"), 2), t.get("created", "")))


def find_ids(tasks, ids):
    found = []
    for ident in ids:
        for t in tasks:
            if t.get("id") == ident and t["status"] != "resolved":
                found.append(t)
                break
    return found


def commit(r, msg):
    if not shutil.which("git") or not (r / ".git").exists():
        return
    subprocess.run(["git", "-C", str(r), "add", "-A"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    res = subprocess.run(["git", "-C", str(r), "commit", "-m", msg], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if res.stdout:
        sys.stdout.write("\033[38;5;245m" + res.stdout + "\033[0m")


def new_task(r, words, status="pending"):
    ignore = "--" in words
    words = [w for w in words if w != "--"]
    template_id = None
    kept = []
    for w in words:
        if w.startswith("template:") and w.split(":", 1)[1].isdigit():
            template_id = int(w.split(":", 1)[1])
        else:
            kept.append(w)
    words = kept
    base = parse_attrs([] if ignore else context_words(r))
    attrs = parse_attrs(words)
    tid = max([t.get("id", 0) for t in all_tasks(r) if t["status"] != "resolved"] + [0]) + 1
    src = None
    if template_id is not None:
        for cand in all_tasks(r):
            if cand.get("id") == template_id:
                src = cand
                break
    t = {
        "uuid": str(uuid.uuid4()), "status": status, "id": tid,
        "summary": " ".join(attrs["text"]) or (src or {}).get("summary", ""),
        "notes": " ".join(attrs["note"]) or (src or {}).get("notes", ""),
        "tags": list((src or {}).get("tags", [])), "project": (src or {}).get("project", ""),
        "priority": (src or {}).get("priority", "P2"), "created": now(),
        "resolved": now() if status == "resolved" else ZERO, "due": (src or {}).get("due", ZERO),
    }
    apply_attrs(t, base)
    apply_attrs(t, attrs)
    t["_path"] = str(r / status / (t["uuid"] + ".yml"))
    write_task(t)
    action = "Logged" if status == "resolved" else ("Added template" if status == "template" else "Added")
    print(f"{action} {t['id']}: {t['summary']}")
    commit(r, f"{action} {t['id']}: {t['summary']}")
    return t


def move_task(r, t, status):
    old = Path(t["_path"])
    t["status"] = status
    t["_path"] = str(r / status / (t["uuid"] + ".yml"))
    if status == "resolved":
        t["resolved"] = now()
        t["id"] = 0
    write_task(t)
    if old != Path(t["_path"]) and old.exists():
        old.unlink()


def main(argv):
    r = repo()
    ensure_repo(r)
    args = list(argv)
    if args and args[0] == "--help":
        args = []
    if args[:1] == ["help"]:
        print(CMD_HELP.get(args[1], HELP) if len(args) > 1 else HELP, end="" if len(args) > 1 else "\n")
        return 0
    if args[:1] == ["version"]:
        print("Version: Unknown\nGit commit: Unknown\nBuild date: Unknown")
        return 0
    if args and args[0] in ("bash-completion", "fish-completion", "zsh-completion", "powershell-completion"):
        print("")
        return 0
    if args[:1] == ["git"]:
        return subprocess.call(["git", "-C", str(r)] + args[1:])
    cmd = None
    ids = []
    rest = []
    for a in args:
        if cmd is None and a in COMMANDS:
            cmd = a
        elif cmd is None and a.isdigit():
            ids.append(int(a))
        else:
            rest.append(a)
    if cmd is None:
        cmd = "next"
        rest = [a for a in args if not a.isdigit()]
    tasks = all_tasks(r)
    if cmd == "next" and ids:
        for t in find_ids(tasks, ids):
            print(f"{t['id']}: {t['summary']}")
            if t.get("notes"):
                print(t["notes"])
        return 0
    if cmd == "context":
        if rest:
            txt = "" if rest[0] in ("none", "--") else " ".join(rest)
            (r / "context").write_text(txt)
            if txt:
                print(f"\033[33mActive context: {txt}\033[0m")
        else:
            print(" ".join(context_words(r)))
        return 0
    if cmd in ("add", "template", "log") or (cmd == "start" and not ids):
        status = "pending"
        if cmd == "template":
            status = "template"
        elif cmd == "log":
            status = "resolved"
        elif cmd == "start":
            status = "active"
        new_task(r, rest, status)
        return 0
    selected = find_ids(tasks, ids) if ids else []
    if cmd in ("done", "start", "stop", "modify", "note", "remove", "edit", "open"):
        if cmd == "note" and not selected and rest and rest[0].isdigit():
            selected = find_ids(tasks, [int(rest.pop(0))])
        if not selected and rest and rest[0].isdigit():
            selected = find_ids(tasks, [int(rest.pop(0))])
        for t in selected:
            if cmd == "done":
                if rest:
                    t["notes"] = t.get("notes", "") + "\n" + " ".join(rest)
                move_task(r, t, "resolved")
                print(f"Resolved {t['id']}: {t['summary']}")
                commit(r, f"Resolved {t['id']}: {t['summary']}")
            elif cmd == "start":
                move_task(r, t, "active")
                print(f"Started {t['id']}: {t['summary']}")
                commit(r, f"Started {t['id']}: {t['summary']}")
            elif cmd == "stop":
                if rest:
                    t["notes"] = t.get("notes", "") + "\n" + " ".join(rest)
                move_task(r, t, "paused")
                print(f"Stopped {t['id']}: {t['summary']}")
                commit(r, f"Stopped {t['id']}: {t['summary']}")
            elif cmd == "modify":
                apply_attrs(t, parse_attrs(rest))
                write_task(t)
                print(f"Modified {t['id']}: {t['summary']}")
                commit(r, f"Modified {t['id']}: {t['summary']}")
            elif cmd == "note":
                if rest:
                    t["notes"] = t.get("notes", "") + ("\n" if t.get("notes") else "") + " ".join(rest)
                    write_task(t)
                    commit(r, f"Noted {t['id']}: {t['summary']}")
                else:
                    print(f"{t['id']}: {t['summary']}\n{t.get('notes','')}")
            elif cmd == "remove":
                p = Path(t["_path"])
                if p.exists():
                    p.unlink()
                print(f"Removed: {t['id']}: {t['summary']}")
                commit(r, f"Removed: {t['id']}: {t['summary']}")
            elif cmd == "edit":
                print(json.dumps(public(t), indent=2))
            elif cmd == "open":
                urls = re.findall(r"https?://\\S+", t.get("summary", "") + "\n" + t.get("notes", ""))
                print("\n".join(urls))
        return 0
    ignore = "--" in rest
    filters = [x for x in rest if x != "--"]
    if not ignore and cmd not in ("show-unorganised",):
        filters = context_words(r) + filters
    if cmd in ("next", "show-open"):
        show = [t for t in tasks if t["status"] in ("pending", "active", "paused") and matches(t, filters)]
        dump([public(t) for t in sorted_tasks(show)])
    elif cmd == "show-active":
        dump([public(t) for t in sorted_tasks([t for t in tasks if t["status"] == "active" and matches(t, filters)])])
    elif cmd == "show-paused":
        dump([public(t) for t in sorted_tasks([t for t in tasks if t["status"] == "paused" and matches(t, filters)])])
    elif cmd == "show-resolved":
        dump([public(t) for t in sorted(tasks, key=lambda x: x.get("resolved", ""), reverse=True) if t["status"] == "resolved" and matches(t, filters)][:1000])
    elif cmd == "show-templates":
        dump([public(t) for t in sorted_tasks([t for t in tasks if t["status"] == "template" and matches(t, filters)])])
    elif cmd == "show-unorganised":
        dump([public(t) for t in sorted_tasks([t for t in tasks if t["status"] in ("pending", "active", "paused") and not t.get("tags") and not t.get("project")])])
    elif cmd == "show-tags":
        print("\n".join(sorted({tag for t in tasks if t["status"] != "resolved" for tag in t.get("tags", [])})))
    elif cmd == "show-projects":
        projects = {}
        for t in tasks:
            if not t.get("project"):
                continue
            p = projects.setdefault(t["project"], {"name": t["project"], "taskCount": 0, "resolvedCount": 0, "active": False, "created": t["created"], "resolved": ZERO, "priority": t["priority"]})
            p["taskCount"] += 1
            if t["status"] == "resolved":
                p["resolvedCount"] += 1
                p["resolved"] = max(p["resolved"], t.get("resolved", ZERO))
            if t["status"] == "active":
                p["active"] = True
            if t.get("created", "") < p["created"]:
                p["created"] = t["created"]
            if t.get("priority", "P2") < p["priority"]:
                p["priority"] = t["priority"]
        dump(list(projects.values()))
    elif cmd == "sync":
        subprocess.call(["git", "-C", str(r), "pull", "--no-edit"])
        subprocess.call(["git", "-C", str(r), "push"])
    elif cmd == "undo":
        n = rest[0] if rest else "1"
        return subprocess.call(["git", "-C", str(r), "reset", "--hard", f"HEAD~{n}"])
    else:
        print(HELP)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
