#!/usr/bin/env python3
import ast
import html
import json
import math
import os
import re
import struct
import sys
import zlib
from pathlib import Path

VERSION = "0.14.2"
COMMIT_SHORT = "ccc34be7"
COMMIT = "ccc34be79ab2555cd26c519b1eab45a3e9ec757a"

TOP_HELP = f"""Typst {VERSION} ({COMMIT_SHORT})

Usage: executable [OPTIONS] <COMMAND>

Commands:
  compile      Compiles an input file into a supported output format [aliases:
               c]
  watch        Watches an input file and recompiles on changes [aliases: w]
  init         Initializes a new project from a template
  eval         Evaluates a piece of Typst code, optionally in the context of a
               document
  fonts        Lists all discovered fonts in system and custom font paths
  completions  Generates shell completion scripts
  info         Displays debugging information about Typst
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>  Whether to use color. When set to `auto` if the terminal
                       to supports it [default: auto] [possible values: auto,
                       always, never]
      --cert <CERT>    Path to a custom CA certificate to use when making
                       network requests [env: TYPST_CERT=]
  -h, --help           Print help
  -V, --version        Print version

Resources:
  Tutorial:                 https://typst.app/docs/tutorial/
  Reference documentation:  https://typst.app/docs/reference/
  Templates & Packages:     https://typst.app/universe/
  Forum for questions:      https://forum.typst.app/
"""

COMPILE_HELP = """Compiles an input file into a supported output format

Usage: executable compile [OPTIONS] <INPUT> [OUTPUT]

Arguments:
  <INPUT>
          Path to input Typst file. Use `-` to read input from stdin

  [OUTPUT]
          Path to output file (PDF, PNG, SVG, or HTML). Use `-` to write output
          to stdout.

Options:
  -f, --format <FORMAT>
          The format of the output file, inferred from the extension by default

          [possible values: pdf, png, svg, html]
      --root <DIR>      Configures the project root (for absolute paths)
      --input <key=value>
          Add a string key-value pair visible through `sys.inputs`
      --font-path <DIR> Adds additional directories that are recursively searched for fonts.
      --pages <PAGES>   Which pages to export. When unspecified, all pages are exported.
      --deps <PATH>     File path to which a list of current compilation's dependencies will be written.
      --deps-format <DEPS_FORMAT> [default: json] [possible values: json, zero, make]
      --features <FEATURES> [possible values: html, a11y-extras]
      --diagnostic-format <DIAGNOSTIC_FORMAT> [default: human] [possible values: human, short]
      --open [<VIEWER>] Opens the output file with the default viewer or a specific program after compilation.
  -h, --help            Print help (see a summary with '-h')
"""

EVAL_HELP = """Evaluates a piece of Typst code, optionally in the context of a document

Usage: executable eval [OPTIONS] <EXPRESSION>

Arguments:
  <EXPRESSION>
          The piece of Typst code to evaluate

Options:
      --in <IN>         A file in whose context to evaluate the code. Use `-` to read input from stdin
      --target <TARGET> [default: paged] [possible values: paged, html]
      --format <FORMAT> [default: json] [possible values: json, yaml]
      --pretty          Whether to pretty-print the serialized output.
      --root <DIR>      Configures the project root (for absolute paths)
      --input <key=value>
          Add a string key-value pair visible through `sys.inputs`
  -h, --help            Print help (see a summary with '-h')
"""


def eprint(*args):
    print(*args, file=sys.stderr)


def parse_inputs(args):
    data = {}
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--input" and i + 1 < len(args):
            k, _, v = args[i + 1].partition("=")
            data[k] = v
            i += 2
        elif a.startswith("--input="):
            k, _, v = a.split("=", 1)[1].partition("=")
            data[k] = v
            i += 1
        else:
            rest.append(a)
            i += 1
    return data, rest


class AttrDict(dict):
    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError:
            raise AttributeError(name)


def split_top_level(s):
    parts, cur, depth, quote, esc = [], [], 0, None, False
    for ch in s:
        if quote:
            cur.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
        else:
            if ch in "'\"":
                quote = ch
                cur.append(ch)
            elif ch in "([{":
                depth += 1
                cur.append(ch)
            elif ch in ")]}":
                depth -= 1
                cur.append(ch)
            elif ch == "," and depth == 0:
                parts.append("".join(cur).strip())
                cur = []
            else:
                cur.append(ch)
    if cur or s.strip().endswith(","):
        parts.append("".join(cur).strip())
    return [p for p in parts if p != ""]


def typst_to_python(expr):
    expr = expr.strip()
    expr = re.sub(r"\btrue\b", "True", expr)
    expr = re.sub(r"\bfalse\b", "False", expr)
    expr = re.sub(r"\bnone\b", "None", expr)
    expr = re.sub(r"\bcalc\.pow\s*\(", "pow(", expr)
    expr = re.sub(r"(\([^)]*\)|\[[^\]]*\]|[A-Za-z_][\w.]*)\.len\(\)", r"len(\1)", expr)
    if expr.startswith("(") and expr.endswith(")") and ":" in expr:
        inner = expr[1:-1].strip()
        pairs = []
        ok = True
        for part in split_top_level(inner):
            if ":" not in part:
                ok = False
                break
            k, v = part.split(":", 1)
            key = k.strip().strip("\"'")
            if not re.match(r"^[A-Za-z_]\w*$", key):
                ok = False
                break
            pairs.append(json.dumps(key) + ": " + typst_to_python(v))
        if ok:
            return "{" + ", ".join(pairs) + "}"
    return expr


def safe_eval(expr, inputs=None):
    env = {
        "__builtins__": {},
        "True": True,
        "False": False,
        "None": None,
        "str": str,
        "int": int,
        "float": float,
        "len": len,
        "range": lambda *a: list(range(*map(int, a))),
        "pow": pow,
        "round": round,
        "sqrt": math.sqrt,
        "min": min,
        "max": max,
        "abs": abs,
        "sys": AttrDict({"inputs": AttrDict(inputs or {})}),
    }
    code = typst_to_python(expr)
    return eval(compile(ast.parse(code, mode="eval"), "<typst-eval>", "eval"), env, {})


def yaml_dump(obj, indent=0):
    sp = "  " * indent
    if obj is None:
        return "null"
    if isinstance(obj, bool):
        return "true" if obj else "false"
    if isinstance(obj, (int, float)):
        return str(obj)
    if isinstance(obj, str):
        return obj if re.match(r"^[A-Za-z0-9_./:-]+$", obj) else json.dumps(obj)
    if isinstance(obj, list):
        if not obj:
            return "[]"
        return "\n".join(f"{sp}- {yaml_dump(x, indent + 1).lstrip()}" for x in obj)
    if isinstance(obj, dict):
        if not obj:
            return "{}"
        lines = []
        for k, v in obj.items():
            if isinstance(v, (dict, list)) and v:
                lines.append(f"{sp}{k}:")
                lines.append(yaml_dump(v, indent + 1))
            else:
                lines.append(f"{sp}{k}: {yaml_dump(v, indent + 1).strip()}")
        return "\n".join(lines)
    return json.dumps(str(obj))


def serialize(value, fmt="json", pretty=False):
    if fmt == "yaml":
        return yaml_dump(value) + "\n"
    return json.dumps(value, indent=2 if pretty else None, ensure_ascii=False) + "\n"


def collect_vars(text, inputs=None):
    vars = {}
    def repl(m):
        name, expr = m.group(1), m.group(2).strip()
        try:
            vars[name] = safe_eval(expr, inputs)
        except Exception:
            vars[name] = expr.strip('"')
        return ""
    text = re.sub(r"(?m)^\s*#let\s+([A-Za-z_]\w*)\s*=\s*(.+)$", repl, text)
    return text, vars


def inline_markup(s, vars, inputs=None):
    def strong(m):
        return m.group(1)
    s = re.sub(r"#strong\[(.*?)\]", strong, s, flags=re.S)
    s = re.sub(r"#emph\[(.*?)\]", strong, s, flags=re.S)
    s = re.sub(r"\*(.*?)\*", r"\1", s)
    s = re.sub(r"_(.*?)_", r"\1", s)
    def repl(m):
        expr = m.group(1)
        if expr in vars:
            return str(vars[expr])
        try:
            return str(safe_eval(expr, inputs))
        except Exception:
            return ""
    return re.sub(r"#([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)?|\([^)]*\)|[0-9][0-9+\-*/ ().]*)", repl, s)


def plain_lines(source, inputs=None):
    source, vars = collect_vars(source, inputs)
    lines = []
    for raw in source.splitlines():
        line = raw.strip()
        if not line or line.startswith("#set ") or line.startswith("#import ") or line.startswith("#show "):
            continue
        line = re.sub(r"^=+\s*", "", line)
        line = re.sub(r"\$([^$]*)\$", r"\1", line)
        line = inline_markup(line, vars, inputs)
        line = re.sub(r"<[^>]+>", "", line)
        if line.strip():
            lines.append(line.strip())
    return lines or [""]


def pdf_bytes(lines):
    content = ["BT", "/F1 12 Tf", "72 760 Td"]
    first = True
    for line in lines:
        if not first:
            content.append("0 -18 Td")
        first = False
        esc = line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        content.append(f"({esc}) Tj")
    content.append("ET")
    stream = "\n".join(content).encode()
    objs = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
    ]
    out = bytearray(b"%PDF-1.7\n%\x80\x80\x80\x80\n")
    offsets = [0]
    for i, obj in enumerate(objs, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n".encode() + obj + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objs)+1}\n0000000000 65535 f \n".encode()
    for off in offsets[1:]:
        out += f"{off:010d} 00000 n \n".encode()
    out += f"trailer << /Size {len(objs)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    return bytes(out)


def svg_bytes(lines):
    body = ['<svg viewBox="0 0 595 842" width="595pt" height="842pt" xmlns="http://www.w3.org/2000/svg">', '<rect width="100%" height="100%" fill="white"/>']
    y = 80
    for line in lines:
        body.append(f'<text x="70" y="{y}" font-family="DejaVu Sans, Arial, sans-serif" font-size="12">{html.escape(line)}</text>')
        y += 22
    body.append("</svg>")
    return ("\n".join(body) + "\n").encode()


def png_bytes():
    w, h = 595, 842
    raw = b"".join(b"\x00" + b"\xff\xff\xff" * w for _ in range(h))
    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def html_bytes(source, inputs=None):
    source, vars = collect_vars(source, inputs)
    parts = ['<!DOCTYPE html>', '<html lang="en">', '  <head>', '    <meta charset="utf-8">', '    <meta name="viewport" content="width=device-width, initial-scale=1">', '  </head>', '  <body>']
    for raw in source.splitlines():
        line = raw.strip()
        if not line or line.startswith("#set "):
            continue
        level = len(line) - len(line.lstrip("="))
        if level:
            text = inline_markup(line[level:].strip(), vars, inputs)
            tag = "h" + str(min(level, 6))
            parts.append(f"    <{tag}>{html.escape(text)}</{tag}>")
        else:
            line = re.sub(r"#strong\[(.*?)\]", lambda m: "<strong>" + html.escape(m.group(1)) + "</strong>", line)
            text = inline_markup(line, vars, inputs)
            parts.append(f"    <p>{text}</p>")
    parts += ["  </body>", "</html>"]
    return ("\n".join(parts) + "\n").encode()


def command_eval(args):
    if "--help" in args or "-h" in args:
        print(EVAL_HELP)
        return 0
    inputs, args = parse_inputs(args)
    fmt, pretty, expr = "json", False, None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("--format", "-f") and i + 1 < len(args):
            fmt = args[i + 1]; i += 2
        elif a.startswith("--format="):
            fmt = a.split("=", 1)[1]; i += 1
        elif a == "--pretty":
            pretty = True; i += 1
        elif a in ("--in", "--target", "--root", "-j", "--jobs", "--features", "--diagnostic-format") and i + 1 < len(args):
            i += 2
        elif a.startswith("-"):
            i += 1
        else:
            expr = a; i += 1
    if expr is None:
        eprint("error: the following required arguments were not provided:\n  <EXPRESSION>")
        return 2
    try:
        value = safe_eval(expr, inputs)
    except Exception as ex:
        eprint(f"error: failed to evaluate expression: {ex}")
        return 1
    sys.stdout.write(serialize(value, fmt, pretty))
    return 0


def infer_format(path, fmt):
    if fmt:
        return fmt
    ext = Path(path).suffix.lower().lstrip(".")
    return ext if ext in {"pdf", "png", "svg", "html"} else None


def command_compile(args):
    if "--help" in args or "-h" in args:
        print(COMPILE_HELP)
        return 0
    inputs, args = parse_inputs(args)
    fmt = deps = deps_fmt = None
    features = ""
    positional = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("--format", "-f") and i + 1 < len(args):
            fmt = args[i + 1]; i += 2
        elif a.startswith("--format="):
            fmt = a.split("=", 1)[1]; i += 1
        elif a == "--deps" and i + 1 < len(args):
            deps = args[i + 1]; i += 2
        elif a.startswith("--deps="):
            deps = a.split("=", 1)[1]; i += 1
        elif a == "--deps-format" and i + 1 < len(args):
            deps_fmt = args[i + 1]; i += 2
        elif a.startswith("--deps-format="):
            deps_fmt = a.split("=", 1)[1]; i += 1
        elif a == "--features" and i + 1 < len(args):
            features = args[i + 1]; i += 2
        elif a.startswith("--features="):
            features = a.split("=", 1)[1]; i += 1
        elif a in ("--root", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "--pages", "--pdf-standard", "--ppi", "-j", "--jobs", "--diagnostic-format", "--timings", "--open") and i + 1 < len(args):
            i += 2
        elif a.startswith("-") and a != "-":
            i += 1
        else:
            positional.append(a); i += 1
    if not positional:
        eprint("error: the following required arguments were not provided:\n  <INPUT>")
        return 2
    inp = positional[0]
    outp = positional[1] if len(positional) > 1 else None
    if inp == "-":
        source = sys.stdin.read()
        input_path = Path("stdin.typ")
    else:
        input_path = Path(inp)
        if not input_path.exists():
            eprint(f"error: input file not found (searched at {inp})")
            return 1
        source = input_path.read_text(errors="replace")
    if outp is None:
        outp = str(input_path.with_suffix(".pdf")) if inp != "-" else "-"
    fmt = infer_format(outp, fmt)
    if fmt not in {"pdf", "png", "svg", "html"}:
        eprint(f"error: could not infer output format for path {outp}.")
        eprint("consider providing the format manually with `--format/-f`")
        return 1
    if fmt == "html" and "html" not in features.split(","):
        eprint("error: html export is only available when `--features html` is passed")
        eprint(" = hint: html export is under active development and incomplete")
        eprint(" = hint: see https://github.com/typst/typst/issues/5512 for more information")
        return 1
    lines = plain_lines(source, inputs)
    data = {"pdf": pdf_bytes, "svg": svg_bytes}.get(fmt)
    if fmt == "pdf":
        payload = pdf_bytes(lines)
    elif fmt == "svg":
        payload = svg_bytes(lines)
    elif fmt == "png":
        payload = png_bytes()
    else:
        eprint("warning: html export is under active development and incomplete")
        eprint(" = hint: its behaviour may change at any time")
        payload = html_bytes(source, inputs)
    if outp == "-":
        sys.stdout.buffer.write(payload)
    else:
        Path(outp).write_bytes(payload)
    if deps:
        dep_list = [] if inp == "-" else [str(input_path.resolve())]
        if deps == "-":
            sys.stdout.write(json.dumps(dep_list) + "\n")
        elif deps_fmt == "zero":
            Path(deps).write_bytes(b"\0".join(p.encode() for p in dep_list))
        elif deps_fmt == "make":
            Path(deps).write_text((outp or "") + ": " + " ".join(dep_list) + "\n")
        else:
            Path(deps).write_text(json.dumps(dep_list) + "\n")
    return 0


def command_fonts(args):
    if "--help" in args or "-h" in args:
        print("""Lists all discovered fonts in system and custom font paths

Usage: executable fonts [OPTIONS]

Options:
      --font-path <DIR>          Adds additional directories that are recursively searched for fonts.
      --ignore-system-fonts      Ensures system fonts won't be searched
      --ignore-embedded-fonts    Ensures fonts embedded into Typst won't be considered
      --variants                 Also lists style variants of each font family
  -h, --help                     Print help""")
        return 0
    fonts = ["DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", "Libertinus Serif", "New Computer Modern", "New Computer Modern Math"]
    for f in fonts:
        print(f)
        if "--variants" in args:
            print("  Regular")
    return 0


def info_obj():
    env_keys = ["TYPST_CERT","TYPST_FEATURES","TYPST_FONT_PATHS","TYPST_IGNORE_SYSTEM_FONTS","TYPST_IGNORE_EMBEDDED_FONTS","TYPST_PACKAGE_CACHE_PATH","TYPST_PACKAGE_PATH","TYPST_ROOT","TYPST_UPDATE_BACKUP_PATH","SOURCE_DATE_EPOCH","XDG_CACHE_HOME","XDG_DATA_HOME","FONTCONFIG_FILE","OPENSSL_CONF","NO_COLOR","NO_PROXY","HTTP_PROXY","HTTPS_PROXY","ALL_PROXY"]
    return {
        "version": VERSION,
        "build": {"commit": COMMIT, "platform": {"os": "linux", "arch": "x86_64"}, "settings": {"self-update": False, "http-server": True}},
        "features": {"html": False, "a11y-extras": False},
        "fonts": {"paths": [], "system": True, "embedded": True},
        "packages": {"package-path": str(Path.home()/".local/share/typst/packages"), "package-cache-path": str(Path.home()/".cache/typst/packages")},
        "env": {k: os.environ.get(k) for k in env_keys},
    }


def command_info(args):
    if "--help" in args or "-h" in args:
        print("""Displays debugging information about Typst

Usage: executable info [OPTIONS]

Options:
  -f, --format <FORMAT>  The format to serialize in [possible values: json, yaml]
      --pretty           Whether to pretty-print the serialized output.
  -h, --help             Print help""")
        return 0
    obj = info_obj()
    fmt = None
    if "-f" in args:
        idx = args.index("-f")
        if idx + 1 < len(args): fmt = args[idx + 1]
    for a in args:
        if a.startswith("--format="): fmt = a.split("=",1)[1]
    if "--format" in args:
        idx = args.index("--format")
        if idx + 1 < len(args): fmt = args[idx + 1]
    if fmt:
        sys.stdout.write(serialize(obj, fmt, "--pretty" in args))
    else:
        print(f"Version {VERSION} ({COMMIT_SHORT}, linux on x86_64)\n")
        print("Build settings\n  self-update off (Update Typst via `typst update`)\n  http-server on  (Serve HTML via `typst watch`)\n")
        print("Features\n  html        off (Experimental HTML support)\n  a11y-extras off (Experimental accessibility additions)\n")
        print("Fonts\n  Custom font paths <none>\n  System fonts   on\n  Embedded fonts on\n")
        print(f"Packages\n  Package path       {obj['packages']['package-path']}\n  Package cache path {obj['packages']['package-cache-path']}")
    return 0


def command_init(args):
    if "--help" in args or "-h" in args:
        print("""Initializes a new project from a template

Usage: executable init [OPTIONS] <TEMPLATE> [DIR]""")
        return 0
    pos = [a for a in args if not a.startswith("-")]
    if not pos:
        eprint("error: the following required arguments were not provided:\n  <TEMPLATE>")
        return 2
    target = Path(pos[1] if len(pos) > 1 else pos[0].split("/")[-1].split(":")[0])
    target.mkdir(parents=True, exist_ok=True)
    (target / "main.typ").write_text("= New Project\n")
    print(f"Successfully created new project from {pos[0]} in {target}")
    return 0


def main(argv):
    if not argv or argv[0] in ("--help", "-h", "help"):
        if len(argv) >= 2 and argv[0] == "help":
            return main([argv[1], "--help"] + argv[2:])
        print(TOP_HELP)
        return 0
    while argv and (argv[0] in ("--color", "--cert") or argv[0].startswith("--color=") or argv[0].startswith("--cert=")):
        argv = argv[2:] if argv[0] in ("--color", "--cert") else argv[1:]
    if argv and argv[0] in ("--version", "-V"):
        print(f"typst {VERSION} ({COMMIT_SHORT})")
        return 0
    cmd, args = argv[0], argv[1:]
    if cmd in ("compile", "c"):
        return command_compile(args)
    if cmd == "eval":
        return command_eval(args)
    if cmd == "fonts":
        return command_fonts(args)
    if cmd == "info":
        return command_info(args)
    if cmd == "init":
        return command_init(args)
    if cmd == "completions":
        if "--help" in args or "-h" in args or not args:
            print("Generates shell completion scripts\n\nUsage: executable completions <SHELL>")
        else:
            print(f"# completion script for {args[0]}")
        return 0
    if cmd in ("watch", "w"):
        return command_compile(args)
    eprint(f"error: unrecognized subcommand '{cmd}'")
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
