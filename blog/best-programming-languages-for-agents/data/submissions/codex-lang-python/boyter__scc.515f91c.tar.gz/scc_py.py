#!/usr/bin/env python3
import argparse
import csv
import fnmatch
import hashlib
import html
import json
import math
import os
import re
import stat
import sys
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Set, Tuple

VERSION = "3.7.0"
BORDER = "─" * 79
ASCII_BORDER = "-" * 79
SUB_BORDER = "-" * 79


LANG_EXT: Dict[str, Tuple[str, ...]] = {
    "ABAP": ("abap",),
    "ABNF": ("abnf",),
    "ActionScript": ("as",),
    "Ada": ("ada", "adb", "ads", "pad"),
    "Agda": ("agda",),
    "Android Interface Definition Language": ("aidl",),
    "Apex": ("apex", "trigger"),
    "AsciiDoc": ("adoc", "asciidoc"),
    "ASP": ("asa", "asp"),
    "ASP.NET": ("asax", "ascx", "asmx", "aspx", "master", "sitemap", "webinfo"),
    "Assembly": ("s", "asm"),
    "Astro": ("astro",),
    "Autoconf": ("in",),
    "AutoHotKey": ("ahk",),
    "Avro": ("avdl", "avpr", "avsc"),
    "AWK": ("awk",),
    "BASH": ("bash", "bash_login", "bash_logout", "bash_profile", "bashrc", ".bashrc", ".bash_profile", ".bash_login", ".bash_logout"),
    "Basic": ("bas",),
    "Batch": ("bat", "btm", "cmd"),
    "Bazel": ("bzl", "build.bazel", "build", "workspace"),
    "Bitbucket Pipeline": ("bitbucket-pipelines.yml",),
    "Blade template": ("blade.php",),
    "Boo": ("boo",),
    "Brainfuck": ("bf",),
    "C": ("c", "ec", "pgc"),
    "C Header": ("h",),
    "C Shell": ("csh",),
    "C#": ("cs",),
    "C++": ("cc", "cpp", "cxx", "c++", "pcc", "inl"),
    "C++ Header": ("hh", "hpp", "hxx", "h++"),
    "CMake": ("cmake", "cmakelists.txt"),
    "COBOL": ("cob", "cbl", "ccp", "cobol"),
    "CSS": ("css",),
    "CSV": ("csv",),
    "Clojure": ("clj", "cljs", "cljc"),
    "CoffeeScript": ("coffee",),
    "ColdFusion": ("cfm", "cfml", "cfc"),
    "Crystal": ("cr",),
    "D": ("d",),
    "Dart": ("dart",),
    "Dockerfile": ("dockerfile",),
    "Elixir": ("ex", "exs"),
    "Elm": ("elm",),
    "Emacs Lisp": ("el",),
    "Erlang": ("erl", "hrl"),
    "F#": ("fs", "fsi", "fsx"),
    "FORTRAN Legacy": ("f", "for", "ftn", "f77"),
    "FORTRAN Modern": ("f90", "f95", "f03", "f08"),
    "Fish": ("fish",),
    "Gherkin Specification": ("feature",),
    "Go": ("go",),
    "GraphQL": ("graphql", "gql"),
    "Groovy": ("groovy", "gsp", "gradle"),
    "HEX": ("hex",),
    "HTML": ("htm", "html", "xhtml"),
    "Handlebars": ("hbs", "handlebars", "mustache"),
    "Haskell": ("hs", "lhs"),
    "IDL": ("idl",),
    "INI": ("ini", "properties", "cfg", "conf", "editorconfig"),
    "Idris": ("idr", "lidr"),
    "JAI": ("jai",),
    "JSON": ("json", "jsonl", "geojson", "ipynb"),
    "Java": ("java",),
    "JavaScript": ("js", "jsx", "mjs", "cjs"),
    "Jinja": ("jinja", "jinja2",),
    "Julia": ("jl",),
    "Kotlin": ("kt", "kts"),
    "LESS": ("less",),
    "License": ("license", "licence", "copying", "copyright"),
    "Lisp": ("lisp", "lsp", "cl", "asd"),
    "Lua": ("lua",),
    "Makefile": ("makefile", "mk", "mak"),
    "Markdown": ("md", "markdown", "mdown", "mkd"),
    "Meson": ("meson.build", "meson_options.txt"),
    "Module-Definition": ("def",),
    "Nim": ("nim", "nims"),
    "Nix": ("nix",),
    "OCaml": ("ml", "mli"),
    "Objective C": ("m",),
    "Objective C++": ("mm",),
    "Org": ("org",),
    "PHP": ("php", "php3", "php4", "php5", "phtml"),
    "Pascal": ("pas", "pp", "inc"),
    "Perl": ("pl", "pm", "pod", "t"),
    "Plain Text": ("txt", "text"),
    "PowerShell": ("ps1", "psm1", "psd1"),
    "Prolog": ("pro", "plg"),
    "Protocol Buffers": ("proto",),
    "Puppet": ("pp",),
    "PureScript": ("purs",),
    "Python": ("py", "pyw", "pyi", "scons", "sconstruct", "sconscript"),
    "QML": ("qml",),
    "R": ("r", "R"),
    "R Markdown": ("rmd",),
    "Racket": ("rkt",),
    "Razor": ("cshtml", "vbhtml"),
    "ReStructuredText": ("rst",),
    "Ruby": ("rb", "rake", "gemspec", "ru"),
    "Rust": ("rs",),
    "SAS": ("sas",),
    "SCSS": ("scss",),
    "SVG": ("svg",),
    "Scala": ("scala", "sc"),
    "Scheme": ("scm", "ss"),
    "Shell": ("sh", "ksh", "zsh", "command"),
    "Smarty Template": ("tpl",),
    "Solidity": ("sol",),
    "SQL": ("sql",),
    "SRecode Template": ("srt",),
    "Swift": ("swift",),
    "Systemd": ("service", "socket", "device", "mount", "automount", "swap", "target", "path", "timer", "snapshot", "slice", "scope"),
    "TCL": ("tcl",),
    "TOML": ("toml",),
    "TaskPaper": ("taskpaper",),
    "TeX": ("tex", "sty", "cls"),
    "TypeScript": ("ts", "tsx"),
    "V": ("v",),
    "VHDL": ("vhdl", "vhd"),
    "Vim Script": ("vim",),
    "Visual Basic": ("vb", "vbs"),
    "Vue": ("vue",),
    "XML": ("xml", "xsd", "xsl", "xslt", "plist"),
    "Xtend": ("xtend",),
    "YAML": ("yaml", "yml"),
    "Zig": ("zig",),
    "m4": ("m4",),
}

EXT_LANG: Dict[str, str] = {}
for _lang, _exts in LANG_EXT.items():
    for _ext in _exts:
        EXT_LANG[_ext.lower()] = _lang

NAME_LANG = {
    "makefile": "Makefile",
    "gnumakefile": "Makefile",
    "cmakelists.txt": "CMake",
    "dockerfile": "Dockerfile",
    "license": "License",
    "licence": "License",
    "copying": "License",
    "copyright": "License",
    "readme": "Plain Text",
    "build": "Bazel",
    "workspace": "Bazel",
    "bitbucket-pipelines.yml": "Bitbucket Pipeline",
    ".bashrc": "BASH",
    ".bash_profile": "BASH",
    ".bash_login": "BASH",
    ".bash_logout": "BASH",
    ".gitignore": "gitignore",
    ".ignore": "gitignore",
    ".sccignore": "gitignore",
}

HASH_COMMENT = {"Python", "Ruby", "Perl", "Shell", "BASH", "R", "YAML", "TOML", "INI", "Makefile", "Dockerfile", "Nix", "Julia", "Crystal", "Elixir", "PowerShell", "TCL", "AWK"}
SLASH_COMMENT = {"C", "C Header", "C++", "C++ Header", "C#", "Java", "JavaScript", "TypeScript", "Go", "Rust", "Kotlin", "Swift", "Scala", "Dart", "PHP", "CSS", "SCSS", "LESS", "Objective C", "Objective C++", "SQL", "Solidity"}
HTML_COMMENT = {"HTML", "XML", "SVG", "Vue", "Markdown", "ASP", "ASP.NET"}
LUA_COMMENT = {"Lua"}
SQL_COMMENT = {"SQL"}

COMPLEXITY_WORDS = re.compile(r"\b(if|for|foreach|while|case|catch|except|elif|else\s+if|switch|when|guard|unless|&&|\|\|)\b|[?]")


@dataclass
class FileStat:
    name: str
    path: str
    language: str
    bytes: int = 0
    lines: int = 0
    code: int = 0
    comment: int = 0
    blank: int = 0
    complexity: int = 0
    uloc: int = 0
    max_chars: int = 0
    mean_chars: int = 0


@dataclass
class LangStat:
    name: str
    bytes: int = 0
    lines: int = 0
    code: int = 0
    comment: int = 0
    blank: int = 0
    complexity: int = 0
    count: int = 0
    files: List[FileStat] = field(default_factory=list)
    uloc: int = 0
    max_chars: int = 0
    mean_chars: int = 0


def comma(n: int) -> str:
    return f"{n:,}"


def split_csv_arg(values: Optional[List[str]]) -> Set[str]:
    out: Set[str] = set()
    if not values:
        return out
    for v in values:
        for p in str(v).split(","):
            p = p.strip()
            if p:
                out.add(p.lower().lstrip("."))
    return out


def parse_count_as(s: str) -> Dict[str, str]:
    mapping: Dict[str, str] = {}
    if not s:
        return mapping
    parts, cur, quote = [], "", None
    for ch in s:
        if ch in "'\"":
            quote = None if quote == ch else (ch if quote is None else quote)
            cur += ch
        elif ch == "," and quote is None:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    if cur:
        parts.append(cur)
    for p in parts:
        if ":" not in p:
            continue
        a, b = p.split(":", 1)
        a = a.strip().lower().lstrip(".")
        b = b.strip().strip("'\"")
        if not b:
            continue
        mapping[a] = EXT_LANG.get(b.lower().lstrip("."), b)
    return mapping


def parse_remap(s: str) -> List[Tuple[str, str]]:
    out = []
    if not s:
        return out
    for p in s.split(","):
        if ":" not in p:
            continue
        marker, lang = p.split(":", 1)
        out.append((marker.strip().strip("'\""), lang.strip().strip("'\"")))
    return out


def remap_language(path: str, rules: List[Tuple[str, str]]) -> Optional[str]:
    if not rules:
        return None
    try:
        text = open(path, "rb").read(8192).decode("utf-8", "ignore")
    except OSError:
        return None
    for marker, lang in rules:
        if marker and marker in text:
            return EXT_LANG.get(lang.lower().lstrip("."), lang)
    return None


def language_for(path: str, count_as: Dict[str, str]) -> Optional[str]:
    base = os.path.basename(path)
    low = base.lower()
    if low in NAME_LANG:
        return NAME_LANG[low]
    if "." in low:
        parts = low.split(".")
        for i in range(len(parts) - 1):
            compound = ".".join(parts[i:])
            if compound in count_as:
                return count_as[compound]
            if compound in EXT_LANG:
                return EXT_LANG[compound]
        ext = parts[-1]
        if ext in count_as:
            return count_as[ext]
        if ext in EXT_LANG:
            return EXT_LANG[ext]
    return None


def language_from_shebang(path: str) -> Optional[str]:
    try:
        with open(path, "rb") as f:
            first = f.readline(200).decode("utf-8", "ignore").lower()
    except OSError:
        return None
    if not first.startswith("#!"):
        return None
    if "python" in first:
        return "Python"
    if "ruby" in first:
        return "Ruby"
    if "perl" in first:
        return "Perl"
    if "node" in first or "deno" in first:
        return "JavaScript"
    if "bash" in first:
        return "BASH"
    if re.search(r"/(?:env\s+)?(?:sh|ksh|zsh|fish)\b", first):
        return "Shell"
    if "php" in first:
        return "PHP"
    return None


def strip_strings(line: str) -> str:
    res = []
    quote = None
    esc = False
    for ch in line:
        if quote:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
            res.append(" ")
        elif ch in ("'", '"', "`"):
            quote = ch
            res.append(" ")
        else:
            res.append(ch)
    return "".join(res)


def visible_code_without_comments(s: str, lang: str, in_block: bool) -> Tuple[str, bool, bool]:
    i, code, comment_seen = 0, [], False
    block_start, block_end = None, None
    line_tokens: List[str] = []
    if lang in SLASH_COMMENT:
        block_start, block_end = "/*", "*/"
        line_tokens.append("//")
    if lang in HASH_COMMENT:
        line_tokens.append("#")
    if lang in SQL_COMMENT:
        line_tokens.extend(["--"])
    if lang in LUA_COMMENT:
        line_tokens.append("--")
        block_start, block_end = "--[[", "]]"
    if lang in HTML_COMMENT:
        block_start, block_end = "<!--", "-->"

    while i < len(s):
        if in_block:
            comment_seen = True
            if block_end and s.startswith(block_end, i):
                in_block = False
                i += len(block_end)
            else:
                i += 1
            continue
        starts = []
        if block_start:
            starts.append(block_start)
        starts.extend(line_tokens)
        hit = None
        for tok in starts:
            if tok and s.startswith(tok, i):
                hit = tok
                break
        if hit:
            comment_seen = True
            if hit == block_start:
                in_block = True
                i += len(hit)
                continue
            break
        code.append(s[i])
        i += 1
    return "".join(code), in_block, comment_seen


def count_file(path: str, lang: str, relname: str, args) -> Optional[FileStat]:
    try:
        data = open(path, "rb").read()
    except OSError:
        return None
    if not args.binary and b"\x00" in data[:8192]:
        return None
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        try:
            text = data.decode("latin-1")
        except UnicodeDecodeError:
            return None
    lines = text.splitlines()
    if text and (text.endswith("\n") or text.endswith("\r")):
        pass
    fs = FileStat(os.path.basename(path), relname, lang, bytes=len(data), lines=len(lines))
    in_block = False
    in_py_triple: Optional[str] = None
    unique_lines: Set[str] = set()
    lengths: List[int] = []
    for raw in lines:
        lengths.append(len(raw))
        unique_lines.add(raw.strip())
        stripped = raw.strip()
        if stripped == "":
            fs.blank += 1
            continue
        line_for_complexity = strip_strings(raw)
        is_comment = False
        has_code = False
        if lang == "Python":
            s = raw
            if in_py_triple:
                is_comment = True
                idx = s.find(in_py_triple)
                if idx >= 0:
                    rest = s[idx + 3:]
                    in_py_triple = None
                    if rest.strip():
                        has_code = True
                if not has_code:
                    fs.comment += 1
                    continue
            no_str = strip_strings(s)
            code_part = s
            hashpos = no_str.find("#")
            if hashpos == 0 or (hashpos > 0 and s[:hashpos].strip() == ""):
                fs.comment += 1
                continue
            elif hashpos > 0:
                code_part = s[:hashpos]
            # Treat standalone triple-quoted strings as comments, matching scc for docstrings.
            stripped_code = code_part.strip()
            if stripped_code.startswith('"""') or stripped_code.startswith("'''"):
                q = stripped_code[:3]
                rest = stripped_code[3:]
                is_comment = True
                if q in rest:
                    after = rest.split(q, 1)[1]
                    has_code = bool(after.strip())
                else:
                    in_py_triple = q
                if not has_code:
                    fs.comment += 1
                    continue
            has_code = bool(code_part.strip())
        else:
            clean = strip_strings(raw)
            code_part, in_block, comment_seen = visible_code_without_comments(clean, lang, in_block)
            is_comment = comment_seen
            has_code = bool(code_part.strip())
            if is_comment and not has_code:
                fs.comment += 1
                continue
        if has_code:
            fs.code += 1
            if not args.no_complexity:
                fs.complexity += len(COMPLEXITY_WORDS.findall(line_for_complexity))
        elif is_comment:
            fs.comment += 1
        else:
            fs.code += 1
    fs.uloc = len(unique_lines) if args.uloc or args.dryness else 0
    fs.max_chars = max(lengths) if lengths else 0
    fs.mean_chars = int(sum(lengths) / len(lengths)) if lengths else 0
    return fs


def load_ignore_file(path: str) -> List[str]:
    pats = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    pats.append(line)
    except OSError:
        pass
    return pats


def ignored_by_patterns(rel: str, name: str, patterns: List[str]) -> bool:
    for pat in patterns:
        p = pat.strip()
        if not p:
            continue
        neg = p.startswith("!")
        if neg:
            p = p[1:]
        p = p.rstrip("/")
        matched = fnmatch.fnmatch(name, p) or fnmatch.fnmatch(rel, p) or rel.startswith(p + "/")
        if matched:
            return not neg
    return False


def discover(paths: List[str], args, count_as: Dict[str, str]) -> Tuple[List[Tuple[str, str, str]], List[str]]:
    include = split_csv_arg(args.include_ext)
    exclude = split_csv_arg(args.exclude_ext)
    exclude_files = set()
    for v in args.exclude_file or []:
        exclude_files.update(x.strip() for x in v.split(",") if x.strip())
    if not args.exclude_file_set:
        exclude_files.update(["package-lock.json", "Cargo.lock", "yarn.lock", "pubspec.lock", "Podfile.lock", "pnpm-lock.yaml"])
    exclude_dirs = set([".git", ".hg", ".svn"])
    for v in args.exclude_dir or []:
        for x in v.split(","):
            if x.strip():
                exclude_dirs.add(x.strip())
    regexes = [re.compile(x) for x in (args.not_match or [])]
    remap_unknown = parse_remap(args.remap_unknown)
    remap_all = parse_remap(args.remap_all)
    files, errors = [], []
    for root_arg in paths or ["."]:
        if not os.path.exists(root_arg):
            errors.append(f"file or directory could not be read: {root_arg}")
            continue
        if os.path.isfile(root_arg) or (os.path.islink(root_arg) and args.include_symlinks):
            lang = language_for(root_arg, count_as) or language_from_shebang(root_arg)
            if remap_all:
                lang = remap_language(root_arg, remap_all) or lang
            if not lang and remap_unknown:
                lang = remap_language(root_arg, remap_unknown)
            if lang:
                files.append((root_arg, os.path.basename(root_arg), lang))
            continue
        if not os.path.isdir(root_arg):
            continue
        base_abs = os.path.abspath(root_arg)
        inherited_ignore: List[str] = []
        for dirpath, dirnames, filenames in os.walk(root_arg, followlinks=args.include_symlinks):
            rel_dir = os.path.relpath(dirpath, root_arg)
            if rel_dir == ".":
                rel_dir = ""
            active_ignore = list(inherited_ignore)
            if not args.no_gitignore:
                active_ignore.extend(load_ignore_file(os.path.join(dirpath, ".gitignore")))
            if not args.no_ignore:
                active_ignore.extend(load_ignore_file(os.path.join(dirpath, ".ignore")))
            if not args.no_scc_ignore:
                active_ignore.extend(load_ignore_file(os.path.join(dirpath, ".sccignore")))
            keep_dirs = []
            for d in dirnames:
                rel = os.path.join(rel_dir, d) if rel_dir else d
                if d in exclude_dirs or ignored_by_patterns(rel, d, active_ignore) or any(r.search(rel) for r in regexes):
                    continue
                if os.path.islink(os.path.join(dirpath, d)) and not args.include_symlinks:
                    continue
                keep_dirs.append(d)
            dirnames[:] = sorted(keep_dirs)
            for name in sorted(filenames):
                full = os.path.join(dirpath, name)
                if os.path.islink(full) and not args.include_symlinks:
                    continue
                rel = os.path.relpath(full, base_abs)
                if name in exclude_files and not args.count_ignore:
                    continue
                if not args.count_ignore and name in {".gitignore", ".ignore", ".sccignore"}:
                    continue
                if ignored_by_patterns(rel, name, active_ignore) or any(r.search(rel) for r in regexes):
                    continue
                lang = language_for(full, count_as) or language_from_shebang(full)
                if remap_all:
                    lang = remap_language(full, remap_all) or lang
                if not lang and remap_unknown:
                    lang = remap_language(full, remap_unknown)
                if not lang:
                    continue
                ext = name.lower().split(".")[-1] if "." in name else name.lower()
                if include and ext not in include:
                    continue
                if exclude and ext in exclude:
                    continue
                files.append((full, rel, lang))
    return files, errors


def aggregate(file_stats: List[FileStat]) -> List[LangStat]:
    m: Dict[str, LangStat] = {}
    for fs in file_stats:
        st = m.setdefault(fs.language, LangStat(fs.language))
        st.bytes += fs.bytes
        st.lines += fs.lines
        st.code += fs.code
        st.comment += fs.comment
        st.blank += fs.blank
        st.complexity += fs.complexity
        st.count += 1
        st.files.append(fs)
        st.uloc += fs.uloc
        st.max_chars = max(st.max_chars, fs.max_chars)
    for st in m.values():
        if st.files:
            total_lines = sum(f.lines for f in st.files)
            st.mean_chars = int(sum(f.mean_chars * f.lines for f in st.files) / total_lines) if total_lines else 0
    return list(m.values())


def sort_stats(stats: List[LangStat], key: str) -> List[LangStat]:
    key = (key or "files").lower()
    if key == "name":
        return sorted(stats, key=lambda s: s.name.lower())
    attr = {"files": "count", "lines": "lines", "blanks": "blank", "blank": "blank", "code": "code", "comments": "comment", "comment": "comment", "complexity": "complexity"}.get(key, "count")
    return sorted(stats, key=lambda s: (-getattr(s, attr), s.name))


def make_total(stats: List[LangStat]) -> LangStat:
    t = LangStat("Total")
    all_lines: Set[str] = set()
    for s in stats:
        t.bytes += s.bytes
        t.lines += s.lines
        t.code += s.code
        t.comment += s.comment
        t.blank += s.blank
        t.complexity += s.complexity
        t.count += s.count
        t.uloc += s.uloc
        t.max_chars = max(t.max_chars, s.max_chars)
        for f in s.files:
            t.files.append(f)
    if t.files:
        total_lines = sum(f.lines for f in t.files)
        t.mean_chars = int(sum(f.mean_chars * f.lines for f in t.files) / total_lines) if total_lines else 0
    return t


def tabular(stats: List[LangStat], args) -> str:
    border = ASCII_BORDER if args.ci else BORDER
    cols = ["Language", "Files", "Lines", "Blanks", "Comments", "Code"]
    if not args.no_complexity:
        cols.append("Complexity")
    width = 79
    lines = [border]
    name_width = 25 if args.no_complexity else 17
    if args.no_complexity:
        header = f"{cols[0]:<{name_width}}{cols[1]:>8}{cols[2]:>12}{cols[3]:>11}{cols[4]:>12}{cols[5]:>11}"
    else:
        header = f"{cols[0]:<{name_width}}{cols[1]:>8}{cols[2]:>12}{cols[3]:>10}{cols[4]:>10}{cols[5]:>11}"
        header += f"{cols[6]:>11}"
    lines += [header, border]
    total_for_pct = make_total(stats)

    def row(name: str, count: Optional[int], st) -> str:
        display = name if len(name) <= name_width else name[: name_width - 1] + "…"
        out = f"{display:<{name_width}}"
        if count is None:
            out += " " * 8
        else:
            out += f"{comma(count):>8}"
        if args.no_complexity:
            out += f"{comma(st.lines):>12}{comma(st.blank):>11}{comma(st.comment):>12}{comma(st.code):>11}"
        else:
            out += f"{comma(st.lines):>12}{comma(st.blank):>10}{comma(st.comment):>10}{comma(st.code):>11}"
            out += f"{comma(st.complexity):>11}"
        return out

    for idx, st in enumerate(stats):
        more = idx < len(stats) - 1
        lines.append(row(st.name, st.count, st))
        if args.character:
            lines.append(f"{'MaxLine / MeanLine'}{st.max_chars:>7}{st.mean_chars:>12}")
            if more:
                lines.append(SUB_BORDER)
        if args.percent:
            def pct(a, b):
                return (a / b * 100.0) if b else 0.0
            lines.append(
                f"{'Percentage':<{name_width}}"
                f"{pct(st.count, total_for_pct.count):>7.1f}%"
                f"{pct(st.lines, total_for_pct.lines):>11.1f}%"
                f"{pct(st.blank, total_for_pct.blank):>9.1f}%"
                f"{pct(st.comment, total_for_pct.comment):>9.1f}%"
                f"{pct(st.code, total_for_pct.code):>10.1f}%"
                f"{pct(st.complexity, total_for_pct.complexity):>10.1f}%"
            )
            if more:
                lines.append(SUB_BORDER)
        if args.uloc or args.dryness:
            lines.append(f"{'(ULOC)':<{name_width}}{st.uloc:>20}")
            if more:
                lines.append(SUB_BORDER)
        if args.by_file:
            lines.append(border)
            for fs in sorted(st.files, key=lambda f: f.path):
                lines.append(row(fs.path, None, fs))
            lines.append(border)
    total = make_total(stats)
    if not lines or lines[-1] != border:
        lines.append(border)
    lines += [row("Total", total.count, total), border]
    if args.uloc or args.dryness:
        unique = len({ln.strip() for f in total.files for ln in open(f.path if os.path.exists(f.path) else os.path.join(".", f.path), "r", encoding="utf-8", errors="ignore").read().splitlines()})
        lines.append(f"{'Unique Lines of Code (ULOC)':<30}{unique:>10}")
        if args.dryness:
            dryness = (unique / total.lines) if total.lines else 0.0
            lines.append(f"{'DRYness %':<30}{dryness:>10.2f}")
        lines.append(border)
    if not args.no_cocomo and total.code:
        effort = 2.4 * ((total.code / 1000.0) ** 1.05) * args.eaf
        months = 2.5 * (effort ** 0.38)
        people = effort / months if months else 0
        cost = int(effort * args.avg_wage / 12.0 * args.overhead)
        typ = args.cocomo_project_type.split(",", 1)[0]
        lines.append(f"Estimated Cost to Develop ({typ}) {args.currency_symbol}{comma(cost)}")
        lines.append(f"Estimated Schedule Effort ({typ}) {months:.2f} months")
        lines.append(f"Estimated People Required ({typ}) {people:.2f}")
        lines.append(border)
    if not args.no_size:
        mb = total.bytes / 1000000.0
        lines.append(f"Processed {total.bytes} bytes, {mb:.3f} megabytes (SI)")
        lines.append(border)
    return "\n".join(lines) + "\n"


def json_obj(st: LangStat, include_files=False):
    files = []
    if include_files:
        for f in st.files:
            ext = os.path.basename(f.path).split(".")[-1] if "." in os.path.basename(f.path) else ""
            files.append({"Language": f.language, "PossibleLanguages": [f.language], "Filename": os.path.basename(f.path), "Extension": ext, "Location": f.path, "Symlocation": "", "Bytes": f.bytes, "Lines": f.lines, "Code": f.code, "Comment": f.comment, "Blank": f.blank, "Complexity": f.complexity, "WeightedComplexity": 0, "Hash": None, "Binary": False, "Minified": False, "Generated": False, "EndPoint": 0, "Uloc": f.uloc})
    return {"Name": st.name, "Bytes": st.bytes, "CodeBytes": 0, "Lines": st.lines, "Code": st.code, "Comment": st.comment, "Blank": st.blank, "Complexity": st.complexity, "Count": st.count, "WeightedComplexity": 0, "Files": files, "LineLength": None, "ULOC": st.uloc}


def emit_format(stats: List[LangStat], args, fmt: str) -> str:
    if fmt == "tabular" or fmt == "wide":
        return tabular(stats, args)
    if fmt == "json":
        return json.dumps([json_obj(s, args.by_file) for s in stats], separators=(",", ":"))
    if fmt == "json2":
        total = make_total(stats)
        effort = 2.4 * ((total.code / 1000.0) ** 1.05) if total.code else 0.0
        months = 2.5 * (effort ** 0.38) if effort else 0.0
        people = effort / months if months else 0.0
        cost = effort * 56286 / 12.0
        return json.dumps({"languageSummary": [json_obj(s, args.by_file) for s in stats], "estimatedCost": cost, "estimatedScheduleMonths": months, "estimatedPeople": people}, separators=(",", ":"))
    if fmt in ("csv", "csv-stream"):
        import io
        buf = io.StringIO()
        w = csv.writer(buf, lineterminator="\n")
        w.writerow(["Language", "Lines", "Code", "Comments", "Blanks", "Complexity", "Bytes", "Files", "ULOC"])
        for s in stats:
            w.writerow([s.name, s.lines, s.code, s.comment, s.blank, s.complexity, s.bytes, s.count, s.uloc])
        return buf.getvalue()
    if fmt == "cloc-yaml":
        out = []
        total = make_total(stats)
        out.append("---")
        for s in stats:
            out.append(f"{s.name}:")
            out.append(f"  nFiles: {s.count}")
            out.append(f"  blank: {s.blank}")
            out.append(f"  comment: {s.comment}")
            out.append(f"  code: {s.code}")
        out.append("SUM:")
        out.append(f"  blank: {total.blank}")
        out.append(f"  comment: {total.comment}")
        out.append(f"  code: {total.code}")
        out.append(f"  nFiles: {total.count}")
        return "\n".join(out) + "\n"
    if fmt in ("html", "html-table"):
        rows = "".join(f"<tr><td>{html.escape(s.name)}</td><td>{s.count}</td><td>{s.lines}</td><td>{s.blank}</td><td>{s.comment}</td><td>{s.code}</td><td>{s.complexity}</td></tr>" for s in stats)
        table = "<table><tr><th>Language</th><th>Files</th><th>Lines</th><th>Blanks</th><th>Comments</th><th>Code</th><th>Complexity</th></tr>" + rows + "</table>"
        return table if fmt == "html-table" else "<!doctype html><html><body>" + table + "</body></html>\n"
    if fmt in ("sql", "sql-insert"):
        rows = []
        if fmt == "sql":
            rows.append("CREATE TABLE t (Language TEXT, Lines INT, Code INT, Comments INT, Blanks INT, Complexity INT, Bytes INT, Files INT);")
        for s in stats:
            rows.append(f"INSERT INTO t VALUES ('{s.name.replace(chr(39), chr(39)*2)}',{s.lines},{s.code},{s.comment},{s.blank},{s.complexity},{s.bytes},{s.count});")
        return "\n".join(rows) + "\n"
    if fmt == "openmetrics":
        rows = []
        for s in stats:
            lab = s.name.replace("\\", "\\\\").replace('"', '\\"')
            rows.append(f'scc_code_lines{{language="{lab}"}} {s.code}')
            rows.append(f'scc_comment_lines{{language="{lab}"}} {s.comment}')
            rows.append(f'scc_files{{language="{lab}"}} {s.count}')
        return "\n".join(rows) + "\n"
    return tabular(stats, args)


def print_help():
    print(f"""Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.
Version {VERSION}
Ben Boyter <ben@boyter.org> + Contributors

Usage:
  scc [flags] [files or directories]

Flags:
      --avg-wage int                       average wage value used for basic COCOMO calculation (default 56286)
      --binary                             disable binary file detection
      --by-file                            display output for every file
  -m, --character                          calculate max and mean characters per line
      --ci                                 enable CI output settings where stdout is ASCII
      --cocomo-project-type string         change COCOMO model type [organic, semi-detached, embedded, "custom,1,1,1,1"] (default "organic")
      --count-as string                    count extension as language [e.g. jsp:htm,chead:"C Header" maps extension jsp to html and chead to C Header]
      --count-ignore                       set to allow .gitignore and .ignore files to be counted
      --currency-symbol string             set currency symbol (default "$")
      --debug                              enable debug output
  -a, --dryness                            calculate the DRYness of the project (implies --uloc)
      --exclude-dir strings                directories to exclude (default [.git,.hg,.svn])
  -x, --exclude-ext strings                ignore file extensions
  -n, --exclude-file strings               ignore files with matching names
  -f, --format string                      set output format [tabular, wide, json, json2, csv, csv-stream, cloc-yaml, html, html-table, sql, sql-insert, openmetrics] (default "tabular")
      --gen                                identify generated files
  -h, --help                               help for scc
  -i, --include-ext strings                limit to file extensions
      --include-symlinks                   if set will count symlink files
  -l, --languages                          print supported languages and extensions
      --large-byte-count int               number of bytes a file can contain before being removed from output (default 1000000)
      --large-line-count int               number of lines a file can contain before being removed from output (default 40000)
      --min                                identify minified files
      --no-cocomo                          remove COCOMO calculation output
  -c, --no-complexity                      skip calculation of code complexity
  -d, --no-duplicates                      remove duplicate files from stats and output
      --no-gitignore                       disables .gitignore file logic
      --no-ignore                          disables .ignore file logic
      --no-size                            remove size calculation output
  -o, --output string                      output filename (default stdout)
  -p, --percent                            include percentage values in output
  -s, --sort string                        column to sort by [files, name, lines, blanks, code, comments, complexity] (default "files")
  -u, --uloc                               calculate the number of unique lines of code (ULOC) for the project
  -v, --verbose                            verbose output
      --version                            version for scc
  -w, --wide                               wider output with additional statistics (implies --complexity)""")


def build_parser():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("paths", nargs="*")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("--version", action="store_true")
    p.add_argument("-l", "--languages", action="store_true")
    p.add_argument("--avg-wage", type=int, default=56286)
    p.add_argument("--binary", action="store_true")
    p.add_argument("--by-file", action="store_true")
    p.add_argument("-m", "--character", action="store_true")
    p.add_argument("--ci", action="store_true")
    p.add_argument("--cocomo-project-type", default="organic")
    p.add_argument("--cost-comparison", action="store_true")
    p.add_argument("--count-as", default="")
    p.add_argument("--count-ignore", action="store_true")
    p.add_argument("--currency-symbol", default="$")
    p.add_argument("--debug", action="store_true")
    p.add_argument("--directory-walker-job-workers", type=int, default=8)
    p.add_argument("-a", "--dryness", action="store_true")
    p.add_argument("--eaf", type=float, default=1.0)
    p.add_argument("--exclude-dir", action="append")
    p.add_argument("-x", "--exclude-ext", action="append")
    p.add_argument("-n", "--exclude-file", action="append")
    p.add_argument("--file-gc-count", type=int, default=10000)
    p.add_argument("--file-list-queue-size", type=int, default=8)
    p.add_argument("--file-process-job-workers", type=int, default=8)
    p.add_argument("--file-summary-job-queue-size", type=int, default=8)
    p.add_argument("-f", "--format", default="tabular")
    p.add_argument("--format-multi", default="")
    p.add_argument("--format-multi-line", action="store_true")
    p.add_argument("--gen", action="store_true")
    p.add_argument("--generated-markers", action="append")
    p.add_argument("--include-ext", "-i", action="append")
    p.add_argument("--include-symlinks", action="store_true")
    p.add_argument("--large-byte-count", type=int, default=1000000)
    p.add_argument("--large-line-count", type=int, default=40000)
    p.add_argument("--locomo", action="store_true")
    p.add_argument("--locomo-config", default="")
    p.add_argument("--locomo-cycles", type=float)
    p.add_argument("--locomo-input-price", type=float)
    p.add_argument("--locomo-output-price", type=float)
    p.add_argument("--locomo-preset", default="medium")
    p.add_argument("--locomo-review", type=float, default=0.01)
    p.add_argument("--locomo-tps", type=float)
    p.add_argument("--mcp", action="store_true")
    p.add_argument("--min", action="store_true")
    p.add_argument("-z", "--min-gen", action="store_true")
    p.add_argument("--min-gen-line-length", type=int, default=255)
    p.add_argument("--no-cocomo", action="store_true")
    p.add_argument("-c", "--no-complexity", action="store_true")
    p.add_argument("-d", "--no-duplicates", action="store_true")
    p.add_argument("--no-gen", action="store_true")
    p.add_argument("--no-gitignore", action="store_true")
    p.add_argument("--no-gitmodule", action="store_true")
    p.add_argument("--no-hborder", action="store_true")
    p.add_argument("--no-ignore", action="store_true")
    p.add_argument("--no-large", action="store_true")
    p.add_argument("--no-min", action="store_true")
    p.add_argument("--no-min-gen", action="store_true")
    p.add_argument("--no-scc-ignore", action="store_true")
    p.add_argument("--no-size", action="store_true")
    p.add_argument("-M", "--not-match", action="append")
    p.add_argument("-o", "--output", default="")
    p.add_argument("--overhead", type=float, default=2.4)
    p.add_argument("-p", "--percent", action="store_true")
    p.add_argument("--remap-all", default="")
    p.add_argument("--remap-unknown", default="")
    p.add_argument("--size-unit", default="si")
    p.add_argument("--size-unit-binary", action="store_true")
    p.add_argument("--size-unit-mixed", action="store_true")
    p.add_argument("--size-unit-xkcd", action="store_true")
    p.add_argument("--size-unit-si", action="store_true")
    p.add_argument("--sloccount-format", action="store_true")
    p.add_argument("-s", "--sort", default="files")
    p.add_argument("--sql-project", default="")
    p.add_argument("-t", "--trace", action="store_true")
    p.add_argument("-u", "--uloc", action="store_true")
    p.add_argument("-v", "--verbose", action="store_true")
    p.add_argument("-w", "--wide", action="store_true")
    return p


def main(argv=None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    parser = build_parser()
    args, unknown = parser.parse_known_args(argv)
    args.exclude_file_set = args.exclude_file is not None
    if args.help:
        print_help()
        return 0
    if args.version:
        print(f"scc version {VERSION}")
        return 0
    if args.languages:
        for lang in sorted(LANG_EXT, key=str.lower):
            print(f"{lang} ({','.join(LANG_EXT[lang])})")
        return 0
    if args.wide:
        args.format = "wide" if args.format == "tabular" else args.format
    if args.dryness:
        args.uloc = True
    count_as = parse_count_as(args.count_as)
    found, errors = discover(args.paths, args, count_as)
    if errors:
        for e in errors:
            print(e, file=sys.stderr)
        return 1
    file_stats: List[FileStat] = []
    seen_hashes: Set[str] = set()
    for full, rel, lang in found:
        if args.no_duplicates:
            try:
                h = hashlib.sha1(open(full, "rb").read()).hexdigest()
                if h in seen_hashes:
                    continue
                seen_hashes.add(h)
            except OSError:
                pass
        fs = count_file(full, lang, rel, args)
        if not fs:
            continue
        if args.no_large and (fs.lines > args.large_line_count or fs.bytes > args.large_byte_count):
            continue
        file_stats.append(fs)
    stats = sort_stats(aggregate(file_stats), args.sort)
    if args.format_multi:
        for spec in args.format_multi.split(","):
            if ":" in spec:
                fmt, dest = spec.split(":", 1)
            else:
                fmt, dest = spec, "stdout"
            out = emit_format(stats, args, fmt)
            if dest == "stdout":
                sys.stdout.write(out)
            else:
                with open(dest, "w", encoding="utf-8") as f:
                    f.write(out)
        return 0
    out = emit_format(stats, args, args.format)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(out)
    else:
        sys.stdout.write(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
