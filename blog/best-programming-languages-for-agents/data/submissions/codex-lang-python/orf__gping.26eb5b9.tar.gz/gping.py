#!/usr/bin/env python3
import os
import re
import shutil
import socket
import subprocess
import sys
import time


HELP = """Ping, but with a graph.

Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...

Arguments:
  [HOSTS_OR_COMMANDS]...  Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1

Options:
      --cmd
          Graph the execution time for a list of commands rather than pinging hosts
  -n, --watch-interval <WATCH_INTERVAL>
          Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5
  -b, --buffer <BUFFER>
          Determines the number of seconds to display in the graph [default: 30]
  -4
          Resolve ping targets to IPv4 address
  -6
          Resolve ping targets to IPv6 address
  -i, --interface <INTERFACE>
          Interface to use when pinging
  -s, --simple-graphics
          
      --vertical-margin <VERTICAL_MARGIN>
          Vertical margin around the graph (top and bottom) [default: 1]
      --horizontal-margin <HORIZONTAL_MARGIN>
          Horizontal margin around the graph (left and right) [default: 0]
  -c, --color <color>
          Assign color to a graph entry.
          
          This option can be defined more than once as a comma separated string, and the
          order which the colors are provided will be matched against the hosts or
          commands passed to gping.
          
          Hexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the
          following color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',
          'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',
          'light-blue', 'light-magenta', 'light-cyan', and 'white'
      --clear
          Clear the graph from the terminal after closing the program
      --ping-args [<PING_ARGS>...]
          Extra arguments to pass to `ping`. These are platform dependent
  -h, --help
          Print help
  -V, --version
          Print version
"""

VERSION_LONG = """gping 1.20.1
commit_hash: d67d2aeb
build_time: 2026-04-17 19:59:37 +00:00
build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu
"""

COLOR_NAMES = {
    "black", "red", "green", "yellow", "blue", "magenta", "cyan", "gray",
    "dark-gray", "light-red", "light-green", "light-yellow", "light-blue",
    "light-magenta", "light-cyan", "white",
}

AWS_RE = re.compile(r"^aws:([a-z]{2}-[a-z]+-\d+)$")


class ParseError(Exception):
    def __init__(self, message, usage=None, tip=None):
        self.message = message
        self.usage = usage
        self.tip = tip


def eprint(text=""):
    print(text, file=sys.stderr)


def parse_value(argv, i, flag, display):
    if i + 1 >= len(argv):
        raise ParseError(f"error: a value is required for '{display}' but none was supplied")
    val = argv[i + 1]
    if val.startswith("-"):
        raise ParseError(
            f"error: unexpected argument '{val}' found",
            usage="Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...",
            tip=f"  tip: to pass '{val}' as a value, use '-- {val}'",
        )
    return val, i + 2


def parse(argv):
    opts = {
        "cmd": False,
        "interval": None,
        "buffer": 30,
        "ipv4": False,
        "ipv6": False,
        "interface": None,
        "simple": False,
        "vertical_margin": 1,
        "horizontal_margin": 0,
        "colors": [],
        "clear": False,
        "ping_args": [],
        "targets": [],
    }
    i = 0
    positional_only = False
    while i < len(argv):
        arg = argv[i]
        if positional_only:
            opts["targets"].append(arg)
            i += 1
            continue
        if arg == "--":
            positional_only = True
            i += 1
        elif arg in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        elif arg == "--version":
            print(VERSION_LONG, end="")
            raise SystemExit(0)
        elif arg == "-V":
            print("gping 1.20.1")
            raise SystemExit(0)
        elif arg == "--cmd":
            opts["cmd"] = True
            i += 1
        elif arg in ("-n", "--watch-interval"):
            val, i = parse_value(argv, i, arg, "--watch-interval <WATCH_INTERVAL>")
            try:
                opts["interval"] = float(val)
            except ValueError:
                raise ParseError(f"error: invalid value '{val}' for '--watch-interval <WATCH_INTERVAL>': invalid float literal")
        elif arg in ("-b", "--buffer"):
            val, i = parse_value(argv, i, arg, "--buffer <BUFFER>")
            try:
                opts["buffer"] = int(val)
            except ValueError:
                raise ParseError(f"error: invalid value '{val}' for '--buffer <BUFFER>': invalid digit found in string")
        elif arg == "-4":
            opts["ipv4"] = True
            i += 1
        elif arg == "-6":
            opts["ipv6"] = True
            i += 1
        elif arg == "-46" or arg == "-64":
            raise ParseError(
                "error: the argument '-4' cannot be used with '-6'",
                usage="Usage: executable -4 <HOSTS_OR_COMMANDS>...",
            )
        elif arg in ("-i", "--interface"):
            val, i = parse_value(argv, i, arg, "--interface <INTERFACE>")
            opts["interface"] = val
        elif arg in ("-s", "--simple-graphics"):
            opts["simple"] = True
            i += 1
        elif arg == "--vertical-margin":
            val, i = parse_value(argv, i, arg, "--vertical-margin <VERTICAL_MARGIN>")
            try:
                opts["vertical_margin"] = int(val)
            except ValueError:
                raise ParseError(f"error: invalid value '{val}' for '--vertical-margin <VERTICAL_MARGIN>': invalid digit found in string")
        elif arg == "--horizontal-margin":
            val, i = parse_value(argv, i, arg, "--horizontal-margin <HORIZONTAL_MARGIN>")
            try:
                opts["horizontal_margin"] = int(val)
            except ValueError:
                raise ParseError(f"error: invalid value '{val}' for '--horizontal-margin <HORIZONTAL_MARGIN>': invalid digit found in string")
        elif arg in ("-c", "--color"):
            val, i = parse_value(argv, i, arg, "--color <color>")
            opts["colors"].extend([x for x in val.split(",") if x != ""])
        elif arg == "--clear":
            opts["clear"] = True
            i += 1
        elif arg == "--ping-args":
            opts["ping_args"].extend(argv[i + 1:])
            break
        elif arg.startswith("--ping-args="):
            opts["ping_args"].append(arg.split("=", 1)[1])
            i += 1
        elif arg.startswith("--"):
            raise ParseError(
                f"error: unexpected argument '{arg}' found",
                usage="Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...",
                tip=f"  tip: to pass '{arg}' as a value, use '-- {arg}'",
            )
        elif arg.startswith("-") and arg != "-":
            # Support compact -4/-6 combinations sufficiently for clap-like errors.
            if "4" in arg and "6" in arg:
                raise ParseError(
                    "error: the argument '-4' cannot be used with '-6'",
                    usage="Usage: executable -4 <HOSTS_OR_COMMANDS>...",
                )
            raise ParseError(
                f"error: unexpected argument '{arg}' found",
                usage="Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...",
                tip=f"  tip: to pass '{arg}' as a value, use '-- {arg}'",
            )
        else:
            opts["targets"].append(arg)
            i += 1
    if opts["ipv4"] and opts["ipv6"]:
        raise ParseError(
            "error: the argument '-4' cannot be used with '-6'",
            usage="Usage: executable -4 <HOSTS_OR_COMMANDS>...",
        )
    return opts


def print_parse_error(err):
    eprint(err.message)
    eprint()
    if err.tip:
        eprint(err.tip)
        eprint()
    if err.usage:
        eprint(err.usage)
        eprint()
    eprint("For more information, try '--help'.")


def valid_color(color):
    if color in COLOR_NAMES:
        return True
    return bool(re.fullmatch(r"#[0-9A-Fa-f]{6}", color))


def expand_host(host):
    m = AWS_RE.match(host)
    if m:
        return f"ec2.{m.group(1)}.amazonaws.com"
    return host


def resolve_or_error(host, family):
    expanded = expand_host(host)
    fam = socket.AF_UNSPEC
    if family == 4:
        fam = socket.AF_INET
    elif family == 6:
        fam = socket.AF_INET6
    try:
        socket.getaddrinfo(expanded, None, fam, socket.SOCK_STREAM)
    except socket.gaierror as exc:
        msg = exc.strerror or "failed to lookup address information"
        eprint(f"Error: Resolving {expanded}")
        eprint()
        eprint("Caused by:")
        eprint(f"    failed to lookup address information: {msg}")
        return False
    return True


def check_colors(opts):
    for color in opts["colors"][:len(opts["targets"])]:
        if not valid_color(color):
            eprint(f"Error: Invalid color code: `{color}`")
            eprint()
            eprint("Caused by:")
            eprint("    Failed to parse Colors")
            return False
    return True


def missing_target():
    eprint("Error: At least one host or command must be given (i.e gping google.com). Use --help for a full list of arguments.")
    return 1


def run_command_mode(opts):
    if not sys.stdout.isatty():
        eprint("Error: No such device or address (os error 6)")
        return 1
    interval = opts["interval"] if opts["interval"] is not None else 0.5
    print("gping command mode. Press Ctrl-C to stop.")
    try:
        while True:
            parts = []
            for command in opts["targets"]:
                start = time.perf_counter()
                subprocess.run(command, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                ms = (time.perf_counter() - start) * 1000
                parts.append(f"{command}: {ms:.1f} ms")
            print("\r" + " | ".join(parts), end="", flush=True)
            time.sleep(interval)
    except KeyboardInterrupt:
        if opts["clear"]:
            print("\r\033[2K", end="")
        else:
            print()
        return 0


def run_ping_mode(opts):
    family = 4 if opts["ipv4"] else 6 if opts["ipv6"] else None
    for host in opts["targets"]:
        if not resolve_or_error(host, family):
            return 1

    ping = shutil.which("ping")
    if not ping:
        eprint("Error: Could not detect ping. Stderr: []")
        eprint("Stdout: []")
        return 1

    if not sys.stdout.isatty():
        eprint("Error: No such device or address (os error 6)")
        return 1

    interval = opts["interval"] if opts["interval"] is not None else 0.2
    print("gping. Press Ctrl-C to stop.")
    try:
        while True:
            values = []
            for host in opts["targets"]:
                cmd = [ping, "-c", "1", "-W", "1"]
                if opts["ipv4"]:
                    cmd.append("-4")
                if opts["ipv6"]:
                    cmd.append("-6")
                if opts["interface"]:
                    cmd.extend(["-I", opts["interface"]])
                cmd.extend(opts["ping_args"])
                cmd.append(expand_host(host))
                start = time.perf_counter()
                proc = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                elapsed = (time.perf_counter() - start) * 1000
                values.append(f"{host}: {elapsed:.1f} ms" if proc.returncode == 0 else f"{host}: timeout")
            print("\r" + " | ".join(values), end="", flush=True)
            time.sleep(interval)
    except KeyboardInterrupt:
        if opts["clear"]:
            print("\r\033[2K", end="")
        else:
            print()
        return 0


def main(argv):
    try:
        opts = parse(argv)
    except ParseError as exc:
        print_parse_error(exc)
        return 2

    if not opts["targets"]:
        return missing_target()
    if not check_colors(opts):
        return 1
    if opts["cmd"]:
        return run_command_mode(opts)
    return run_ping_mode(opts)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
