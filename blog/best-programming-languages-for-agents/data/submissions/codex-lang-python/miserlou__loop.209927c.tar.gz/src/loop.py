#!/usr/bin/env python3
import os, sys, subprocess, time, re
from datetime import datetime, timezone

HELP = '''loop 0.6.1
Rich Jones <miserlou@gmail.com>
UNIX's missing `loop` command

USAGE:
    executable [FLAGS] [OPTIONS] [input]...

FLAGS:
    -D, --error-duration    Exit with timeout error code on duration
    -h, --help              Prints help information
    -l, --only-last         Only print the output of the last execution of the command
    -i, --stdin             Read from standard input
        --summary           Provide a summary
    -C, --until-changes     Keep going until the output changes
    -f, --until-fail        Keep going until the command exit status is non-zero
    -S, --until-same        Keep going until the output changes
    -s, --until-success     Keep going until the command exit status is zero
    -V, --version           Prints version information

OPTIONS:
    -b, --count-by <count_by>                Amount to increment the counter by [default: 1]
    -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]
        --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue
    -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)
    -n, --num <num>                          Number of iterations to execute
    -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]
    -c, --until-contains <until_contains>    Keep going until the output contains this string
    -r, --until-error <until_error>          Keep going until the command exit status is the value given
    -m, --until-match <until_match>          Keep going until the output matches this regular expression
    -t, --until-time <until_time>            Keep going until a future time, ex. "2018-04-20 04:20:00" (Times in UTC.)

ARGS:
    <input>...    The command to be looped
'''
VERSION = 'loop 0.6.1\n'

class Opts:
    def __init__(self):
        self.error_duration=False; self.only_last=False; self.stdin=False; self.summary=False
        self.until_changes=False; self.until_fail=False; self.until_same=False; self.until_success=False
        self.count_by=1; self.every='1us'; self.ffor=None; self.for_duration=None; self.num=None
        self.offset=0; self.until_contains=None; self.until_error=None; self.until_match=None; self.until_time=None
        self.input=[]

def err(msg, usage=False):
    sys.stderr.write(msg + '\n')
    if usage:
        sys.stderr.write('\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input]...\n\nFor more information try --help\n')
    return 1

def parse_number(s, optname):
    try:
        return int(float(s))
    except Exception:
        sys.stderr.write(f"error: Invalid value for '{optname}': invalid float literal\n")
        sys.exit(1)

def parse_args(argv):
    o=Opts(); i=0
    flags_noarg = {
        '-D':'error_duration','--error-duration':'error_duration','-l':'only_last','--only-last':'only_last',
        '-i':'stdin','--stdin':'stdin','--summary':'summary','-C':'until_changes','--until-changes':'until_changes',
        '-f':'until_fail','--until-fail':'until_fail','-S':'until_same','--until-same':'until_same',
        '-s':'until_success','--until-success':'until_success'
    }
    opts_arg = {
        '-b':('count_by','--count-by <count_by>'), '--count-by':('count_by','--count-by <count_by>'),
        '-e':('every','--every <every>'), '--every':('every','--every <every>'),
        '--for':('ffor','--for <ffor>'), '-d':('for_duration','--for-duration <for_duration>'), '--for-duration':('for_duration','--for-duration <for_duration>'),
        '-n':('num','--num <num>'), '--num':('num','--num <num>'),
        '-o':('offset','--offset <offset>'), '--offset':('offset','--offset <offset>'),
        '-c':('until_contains','--until-contains <until_contains>'), '--until-contains':('until_contains','--until-contains <until_contains>'),
        '-r':('until_error','--until-error <until_error>'), '--until-error':('until_error','--until-error <until_error>'),
        '-m':('until_match','--until-match <until_match>'), '--until-match':('until_match','--until-match <until_match>'),
        '-t':('until_time','--until-time <until_time>'), '--until-time':('until_time','--until-time <until_time>')
    }
    expanded=[]
    for tok in argv:
        if tok.startswith("-") and not tok.startswith("--") and len(tok) > 2:
            j=1; temp=[]; ok=True
            while j < len(tok):
                opt="-" + tok[j]
                if opt in flags_noarg or opt in ("-h","-V"):
                    temp.append(opt); j += 1
                elif opt in opts_arg:
                    temp.append(opt)
                    if j + 1 < len(tok):
                        temp.append(tok[j+1:])
                    j = len(tok)
                else:
                    ok=False; break
            if ok:
                expanded.extend(temp); continue
        expanded.append(tok)
    argv=expanded
    while i < len(argv):
        a=argv[i]
        if a.startswith("--") and "=" in a:
            name, val = a.split("=", 1)
            if name in opts_arg:
                argv = argv[:i] + [name, val] + argv[i+1:]
                a = argv[i]
        elif len(a) > 2 and a[:2] in opts_arg and not a.startswith("--"):
            argv = argv[:i] + [a[:2], a[2:]] + argv[i+1:]
            a = argv[i]
        if a == '--':
            o.input = argv[i+1:]; break
        if a in ('-h','--help'):
            sys.stdout.write(HELP); sys.exit(0)
        if a in ('-V','--version'):
            sys.stdout.write(VERSION); sys.exit(0)
        if a in flags_noarg:
            setattr(o, flags_noarg[a], True); i+=1; continue
        if a in opts_arg:
            if i+1 >= len(argv):
                sys.stderr.write(f"error: The argument '{a}' requires a value but none was supplied\n")
                sys.exit(1)
            attr, disp = opts_arg[a]; val=argv[i+1]
            if attr in ('count_by','num','offset','until_error'):
                val=parse_number(val, disp)
            setattr(o, attr, val); i+=2; continue
        if a.startswith('-'):
            sys.stderr.write(f"error: Found argument '{a}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input]...\n\nFor more information try --help\n")
            sys.exit(1)
        o.input = argv[i:]; break
    return o

def duration_seconds(s):
    if s is None: return None
    total=0.0; pos=0
    for m in re.finditer(r'(\d+(?:\.\d+)?)(h|ms|us|m|s)', str(s)):
        if m.start()!=pos: break
        n=float(m.group(1)); u=m.group(2); pos=m.end()
        total += n*3600 if u=='h' else n*60 if u=='m' else n if u=='s' else n/1000 if u=='ms' else n/1000000
    if pos != len(str(s)):
        try: return float(s)
        except Exception: return 0.0
    return total

def parse_until_time(s):
    if not s: return None
    for fmt in ('%Y-%m-%d %H:%M:%S','%Y-%m-%d %H:%M','%H:%M:%S','%H:%M'):
        try:
            dt=datetime.strptime(s, fmt)
            now=datetime.now(timezone.utc)
            if fmt.startswith('%H'):
                dt=dt.replace(year=now.year, month=now.month, day=now.day, tzinfo=timezone.utc)
            else:
                dt=dt.replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except Exception: pass
    return None

def emit(out):
    if not out: return
    if isinstance(out, bytes): out=out.decode(errors='replace')
    sys.stdout.write(out)
    if not out.endswith('\n'):
        sys.stdout.write('\n')
    sys.stdout.flush()

def main(argv):
    o=parse_args(argv)
    if not o.input:
        print('No command supplied, exiting.')
        return 0
    cmd=' '.join(o.input)
    items=None
    if o.stdin:
        items=sys.stdin.read().splitlines()
    elif o.ffor is not None:
        items=str(o.ffor).split(',')
    default_num = len(items) if items is not None else None
    max_runs = o.num if o.num is not None else default_num
    start=time.monotonic(); enddur=duration_seconds(o.for_duration); until_ts=parse_until_time(o.until_time)
    count=o.offset; runs=succ=fail=0; prev=None; last_out=''; interval=duration_seconds(o.every) or 0.0
    regex=re.compile(o.until_match) if o.until_match is not None else None
    while True:
        if max_runs is not None and runs >= max_runs: break
        if enddur is not None and time.monotonic()-start >= enddur: break
        if until_ts is not None and time.time() >= until_ts: break
        item=''
        if items is not None and items:
            item = items[runs] if runs < len(items) else items[-1]
        env=os.environ.copy(); env['COUNT']=str(count); env['ITEM']=item
        p=subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, text=True)
        out=p.stdout or ''
        last_out=out
        runs += 1
        if p.returncode == 0: succ += 1
        else: fail += 1
        if not o.only_last: emit(out)
        stop=False
        if o.until_success and p.returncode == 0: stop=True
        if o.until_fail and p.returncode != 0: stop=True
        if o.until_error is not None and p.returncode == o.until_error: stop=True
        if o.until_contains is not None and o.until_contains in out: stop=True
        if regex is not None and regex.search(out): stop=True
        if o.until_changes and prev is not None and out != prev: stop=True
        if o.until_same and prev is not None and out == prev: stop=True
        prev=out
        if stop: break
        count += o.count_by
        if interval > 0: time.sleep(interval)
    if o.only_last: emit(last_out)
    if o.summary:
        sys.stdout.write(f"Total runs:\t{runs}\nSuccesses:\t{succ}\nFailures:\t{fail}\n")
    if o.error_duration and enddur is not None and time.monotonic()-start >= enddur:
        return 124
    return 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
