#!/usr/bin/env python3
import fnmatch
import json
import os
import re
import sys
import xml.sax.saxutils as xml_escape
from dataclasses import dataclass
from pathlib import Path


BANNER = r"""
 _ __ _____   _(_)__  _____
| '__/ _ \ \ / / \ \ / / _ \
| | |  __/\ V /| |\ V /  __/
|_|  \___| \_/ |_| \_/ \___|

Example:
  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...
"""

USAGE = """Usage of ./executable:
  -config string
    \tpath to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)
  -exclude value
    \tlist of globs which specify files to be excluded (i.e. -exclude foo/...)
  -formatter string
    \tformatter to be used for the output (i.e. -formatter stylish)
  -max_open_files int
    \tmaximum number of open files at the same time
  -set_exit_status
    \tset exit status to 1 if any issues are found, overwrites errorCode and warningCode in config
  -version
    \tget revive version"""

VERSION = """Version:\ta75b67b
Commit:\t\ta75b67b73b9edb91dfc9f302dd108fa9d3ea5b05
Built\t\t2026-04-17 19:59 UTC by build.sh"""

GO_MISSING = 'initializing revive - getting lint rules: cannot configure rule: "var-naming": load std packages: err: go command required, not found: exec: "go": executable file not found in $PATH: stderr: '


@dataclass
class Failure:
    path: str
    line: int
    col: int
    rule: str
    msg: str
    severity: str = "warning"
    confidence: float = 1.0


def print_help(prefix=None, code=0):
    if prefix:
        print(BANNER)
        print(prefix)
    else:
        print(BANNER)
    print(USAGE)
    return code


def parse_args(argv):
    opts = {
        "config": None,
        "formatter": "default",
        "exclude": [],
        "set_exit_status": False,
        "version": False,
        "max_open_files": None,
    }
    args = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            raise SystemExit(print_help())
        if not a.startswith("-") or a == "-":
            args.extend(argv[i:])
            break
        name = a[1:]
        if name not in {"config", "exclude", "formatter", "max_open_files", "set_exit_status", "version"}:
            raise SystemExit(print_help(f"flag provided but not defined: {a}", 2))
        if name in {"set_exit_status", "version"}:
            opts[name] = True
            i += 1
            continue
        if i + 1 >= len(argv):
            raise SystemExit(print_help(f"flag needs an argument: {a}", 2))
        val = argv[i + 1]
        if name == "exclude":
            opts["exclude"].append(val)
        elif name == "max_open_files":
            try:
                opts[name] = int(val)
            except ValueError:
                raise SystemExit(print_help(f'invalid value "{val}" for flag -{name}: parse error', 2))
        else:
            opts[name] = val
        i += 2
    return opts, args


def load_config(path):
    if path:
        try:
            return parse_toml(Path(path).read_text()), True
        except Exception:
            print("cannot read the config file", file=sys.stderr)
            sys.exit(1)
    for p in [os.environ.get("XDG_CONFIG_HOME") and os.path.join(os.environ["XDG_CONFIG_HOME"], "revive.toml"),
              os.environ.get("HOME") and os.path.join(os.environ["HOME"], "revive.toml")]:
        if p and os.path.exists(p):
            try:
                return parse_toml(Path(p).read_text()), True
            except Exception:
                print("cannot read the config file", file=sys.stderr)
                sys.exit(1)
    return {}, False


def parse_toml(text):
    data = {}
    cur = data
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            cur = data
            for part in line[1:-1].split("."):
                cur = cur.setdefault(part.strip(), {})
            continue
        if "=" not in line:
            continue
        key, val = [x.strip() for x in line.split("=", 1)]
        cur[key] = parse_toml_value(val)
    return data


def parse_toml_value(val):
    if val.lower() == "true":
        return True
    if val.lower() == "false":
        return False
    if len(val) >= 2 and val[0] == val[-1] == '"':
        return val[1:-1]
    if val.startswith("[") and val.endswith("]"):
        inner = val[1:-1].strip()
        if not inner:
            return []
        return [parse_toml_value(x.strip()) for x in inner.split(",")]
    try:
        return int(val)
    except ValueError:
        try:
            return float(val)
        except ValueError:
            return val


def enabled_rules(conf, explicit):
    if not explicit:
        print(GO_MISSING)
        sys.exit(1)
    rule_table = conf.get("rule", {})
    rules = []
    severities = {}
    options = {}
    for name, body in rule_table.items():
        disabled = isinstance(body, dict) and bool(body.get("Disabled", body.get("disabled", False)))
        if not disabled:
            rules.append(name)
            if isinstance(body, dict):
                options[name] = body
            if isinstance(body, dict) and "severity" in body:
                severities[name] = str(body["severity"])
    return rules, severities, options


def rel(path):
    try:
        return os.path.relpath(path, os.getcwd())
    except ValueError:
        return path


def is_excluded(path, patterns):
    r = rel(path)
    for pat in patterns:
        p = pat.replace("...", "*")
        if fnmatch.fnmatch(r, p) or fnmatch.fnmatch(path, p) or fnmatch.fnmatch(os.path.basename(path), p):
            return True
    return False


def collect_files(args, excludes):
    if not args:
        args = ["."]
    files = []
    for arg in args:
        if arg.endswith("/..."):
            root = arg[:-4] or "."
            if not os.path.isdir(root):
                print(f"linting - getting packages: getting packages - resolving packages in dots: cannot find package \"{arg}\" in:\n\t{arg}", file=sys.stderr)
                sys.exit(1)
            for dp, dns, fns in os.walk(root):
                dns[:] = [d for d in dns if d not in {".git", "vendor"}]
                for fn in fns:
                    if fn.endswith(".go") and not fn.endswith("_test.go"):
                        p = os.path.join(dp, fn)
                        if not is_excluded(p, excludes):
                            files.append(p)
        elif os.path.isdir(arg):
            for fn in sorted(os.listdir(arg)):
                p = os.path.join(arg, fn)
                if os.path.isfile(p) and fn.endswith(".go") and not fn.endswith("_test.go") and not is_excluded(p, excludes):
                    files.append(p)
        elif os.path.isfile(arg):
            if arg.endswith(".go") and not is_excluded(arg, excludes):
                files.append(arg)
        else:
            print(f"linting - getting packages: getting packages - resolving packages in dots: cannot find package \"{arg}\" in:\n\t{arg}", file=sys.stderr)
            sys.exit(1)
    return sorted(dict.fromkeys(files))


def package_name(lines):
    for i, line in enumerate(lines, 1):
        m = re.match(r"\s*package\s+([A-Za-z_]\w*)", line)
        if m:
            return m.group(1), i
    return "", 1


def has_doc_for(lines, idx, name=None, package=False):
    j = idx - 2
    while j >= 0 and lines[j].strip() == "":
        return False
    if j < 0:
        return False
    s = lines[j].strip()
    if s.startswith("//"):
        text = s[2:].strip()
    elif s.startswith("/*"):
        text = s[2:].strip()
    else:
        return False
    if package:
        return text.startswith("Package ")
    if name:
        return text.startswith(name + " ")
    return bool(text)


def lint_file(path, rules, severities, options, package_context=None):
    text = Path(path).read_text(errors="replace")
    lines = text.splitlines()
    out = []
    suppress = suppression_checker(lines)
    rpath = rel(path)
    pkg, pkg_line = package_name(lines)
    if "package-comments" in rules:
        should_report = True
        if package_context is not None:
            should_report = package_context.get(pkg, {}).get("doc_file") == path
        if should_report and not has_doc_for(lines, pkg_line, package=True):
            out.append(Failure(rpath, pkg_line, 1, "package-comments", "should have a package comment", severities.get("package-comments", "warning")))
    if "blank-imports" in rules and pkg != "main":
        for i, line in enumerate(lines, 1):
            if re.search(r'import\s+_\s+"', line) or re.search(r'^\s*_\s+"', line):
                if not ("//" in line or (i > 1 and lines[i - 2].strip().startswith("//"))):
                    out.append(Failure(rpath, i, max(1, line.find("_") + 1), "blank-imports", "a blank import should be only in a main or test package, or have a comment justifying it", severities.get("blank-imports", "warning")))
    if "exported" in rules:
        pats = [
            (re.compile(r"^\s*func\s+(?:\([^)]*\)\s*)?([A-Z]\w*)\s*\("), "function"),
            (re.compile(r"^\s*type\s+([A-Z]\w*)\b"), "type"),
            (re.compile(r"^\s*var\s+([A-Z]\w*)\b"), "var"),
            (re.compile(r"^\s*const\s+([A-Z]\w*)\b"), "const"),
        ]
        for i, line in enumerate(lines, 1):
            for pat, kind in pats:
                m = pat.match(line)
                if m:
                    name = m.group(1)
                    if not has_doc_for(lines, i, name=name):
                        out.append(Failure(rpath, i, max(1, line.find(name) + 1), "exported", f"exported {kind} {name} should have comment or be unexported", severities.get("exported", "warning")))
    if "line-length-limit" in rules:
        limit = 80
        args = options.get("line-length-limit", {}).get("arguments", [])
        if args:
            try:
                limit = int(args[0])
            except Exception:
                pass
        for i, line in enumerate(lines, 1):
            if len(line) > limit:
                out.append(Failure(rpath, i, limit + 1, "line-length-limit", f"line is {len(line)} characters", severities.get("line-length-limit", "warning")))
    return [f for f in out if not suppress(f.line, f.rule)]


def suppression_checker(lines):
    disabled_all = set()
    disabled_rules = {}
    next_all = set()
    next_rules = {}
    line_all = set()
    line_rules = {}
    active_all = False
    active_rules = set()
    for i, line in enumerate(lines, 1):
        if active_all:
            disabled_all.add(i)
        for r in active_rules:
            disabled_rules.setdefault(i, set()).add(r)
        for m in re.finditer(r"revive:(disable-next-line|disable-line|disable|enable)(?::([A-Za-z0-9_-]+))?", line):
            cmd, rule = m.group(1), m.group(2)
            if cmd == "disable-next-line":
                if rule:
                    next_rules.setdefault(i + 1, set()).add(rule)
                else:
                    next_all.add(i + 1)
            elif cmd == "disable-line":
                if rule:
                    line_rules.setdefault(i, set()).add(rule)
                else:
                    line_all.add(i)
            elif cmd == "disable":
                if rule:
                    active_rules.add(rule)
                    disabled_rules.setdefault(i, set()).add(rule)
                else:
                    active_all = True
                    disabled_all.add(i)
            elif cmd == "enable":
                if rule:
                    active_rules.discard(rule)
                else:
                    active_all = False
                    active_rules.clear()

    def check(line, rule):
        return (line in disabled_all or line in next_all or line in line_all or
                rule in disabled_rules.get(line, set()) or
                rule in next_rules.get(line, set()) or
                rule in line_rules.get(line, set()))
    return check


def lint(files, rules, severities, options):
    ctx = {}
    for p in files:
        lines = Path(p).read_text(errors="replace").splitlines()
        pkg, pkg_line = package_name(lines)
        doc = has_doc_for(lines, pkg_line, package=True)
        entry = ctx.setdefault(pkg, {"doc": False, "doc_file": p})
        if doc:
            entry["doc"] = True
            entry["doc_file"] = p
        elif not entry["doc"]:
            entry["doc_file"] = min(entry["doc_file"], p)
    all_failures = []
    for p in files:
        all_failures.extend(lint_file(p, rules, severities, options, ctx))
    return all_failures


def format_output(fmt, failures):
    if fmt == "default":
        for f in failures:
            print(f"{f.path}:{f.line}:{f.col}: {f.msg}")
    elif fmt == "plain":
        for f in failures:
            print(f"{f.path}:{f.line}:{f.col}: {f.msg} https://revive.run/r#{f.rule}")
        if failures:
            print()
    elif fmt == "unix":
        for f in failures:
            print(f"{f.path}:{f.line}:{f.col}: [{f.rule}] {f.msg}")
        if failures:
            print()
    elif fmt == "json":
        if not failures:
            print("null")
        else:
            print(json.dumps([failure_dict(f) for f in failures], indent=2))
    elif fmt == "ndjson":
        for f in failures:
            print(json.dumps(failure_dict(f), separators=(",", ":")))
    elif fmt == "friendly":
        for f in failures:
            print(f"  ⚠  https://revive.run/r#{f.rule}  {f.msg}")
            print(f"  {f.path}:{f.line}:{f.col}\n")
        if failures:
            print(f"⚠ {len(failures)} problem (0 errors, {len(failures)} warning)\n")
            print("Warnings:")
            counts = {}
            for f in failures:
                counts[f.rule] = counts.get(f.rule, 0) + 1
            for rule, n in counts.items():
                print(f"  {n}  {rule}")
            print()
    elif fmt == "stylish":
        by_file = {}
        for f in failures:
            by_file.setdefault(f.path, []).append(f)
        for p, fs in by_file.items():
            print(p)
            for f in fs:
                print(f"  ({f.line}, {f.col})  https://revive.run/r#{f.rule}  {f.msg}")
            print()
        if failures:
            print(f"\n ✖ {len(failures)} problem (0 errors) ({len(failures)} warning)")
    elif fmt == "checkstyle":
        print("<?xml version='1.0' encoding='UTF-8'?>")
        print('<checkstyle version="5.0">')
        by_file = {}
        for f in failures:
            by_file.setdefault(f.path, []).append(f)
        for p, fs in by_file.items():
            print(f'    <file name="{xml_escape.escape(p)}">')
            for f in fs:
                msg = xml_escape.escape(f"{f.msg} (confidence 1)")
                print(f'      <error line="{f.line}" column="{f.col}" message="{msg}" severity="{f.severity}" source="revive/{f.rule}"/>')
            print("    </file>")
        print("</checkstyle>")
    elif fmt == "sarif":
        print(json.dumps({
            "runs": [{
                "results": [{
                    "locations": [{"physicalLocation": {"artifactLocation": {"uri": f.path}, "region": {"startColumn": f.col, "startLine": f.line}}}],
                    "message": {"text": f.msg},
                    "ruleId": f.rule,
                } for f in failures],
                "tool": {"driver": {"informationUri": "https://revive.run", "name": "revive", "rules": [
                    {"helpUri": f"https://revive.run/r#{r}", "id": r, "properties": {"severity": ""}}
                    for r in sorted({f.rule for f in failures})
                ]}},
            }],
            "version": "2.1.0",
        }, indent=2))
    else:
        print(f"formatting - getting formatter: unknown formatter {fmt}", file=sys.stderr)
        sys.exit(1)


def failure_dict(f):
    return {
        "Severity": f.severity,
        "Failure": f.msg,
        "RuleName": f.rule,
        "Category": "",
        "Position": {"Start": {"Filename": f.path, "Offset": 0, "Line": f.line, "Column": f.col}, "End": {"Filename": f.path, "Offset": 0, "Line": f.line, "Column": f.col}},
        "Confidence": 1,
    }


def main(argv):
    opts, args = parse_args(argv)
    if opts["version"]:
        print(VERSION)
        return 0
    conf, explicit = load_config(opts["config"])
    rules, severities, options = enabled_rules(conf, explicit)
    if "var-naming" in rules:
        print(GO_MISSING)
        return 1
    files = collect_files(args, opts["exclude"])
    failures = lint(files, rules, severities, options)
    format_output(opts["formatter"] or "default", failures)
    return 1 if (opts["set_exit_status"] and failures) else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
