#!/usr/bin/env python3
import json
import os
import re
import shlex
import signal
import subprocess
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime


VERSION = "hwatch 0.3.19"
DESC = "A modern alternative to the watch command, records the differences in execution results and can check this differences at after."
ANSI_GREY = "\033[38;5;240m"
ANSI_RESET = "\033[0m"


HELP = f"""{DESC}

Usage: executable [OPTIONS] [command]...

Arguments:
  [command]...  

Options:
  -b, --batch                         output execution results to stdout
  -B, --beep                          beep if command has a change result
      --border                        Surround each pane with a border frame
      --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.
      --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.
  -c, --color                         interpret ANSI color and style sequences
  -r, --reverse                       display text upside down.
  -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.
  -t, --no-title                      hide the UI on start. Use `t` to toggle it.
      --enable-summary-char           collect character-level diff count in summary.
  -N, --line-number                   show line number
      --no-help-banner                hide the "Display help with h key" message
      --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.
  -x, --exec                          Run the command directly, not through the shell. Much like the `-x` option of the watch command.
  -O, --diff-output-only              Display only the lines with differences during `line` diff and `word` diff.
  -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable ${{HWATCH_DATA}}.
  -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.
  -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {{COMMAND}}. [default: "sh -c"]
  -n, --interval <interval>           seconds to wait between updates [default: 2]
      --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run
  -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set `0` for unlimited recording. (default: 5000) [default: 5000]
      --tab-size <tab_size>           Specifying tab display size [default: 4]
  -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]
  -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]
  -K, --keymap <keymap>               Add keymap
  -h, --help                          Print help
  -V, --version                       Print version"""


@dataclass
class Opts:
    batch: bool = False
    beep: bool = False
    color: bool = False
    reverse: bool = False
    line_number: bool = False
    exec_direct: bool = False
    diff_output_only: bool = False
    logfile: str | None = None
    logfile_set: bool = False
    aftercommand: str | None = None
    shell: str = "sh -c"
    interval: float = 2.0
    limit: int = 5000
    tab_size: int = 4
    differences: str = "none"
    output: str = "output"
    keymap: list[str] = field(default_factory=list)
    command: list[str] = field(default_factory=list)


class CliError(Exception):
    def __init__(self, message: str, code: int = 2):
        super().__init__(message)
        self.code = code


def err(msg: str, usage: bool = False) -> None:
    print(msg, file=sys.stderr)
    if usage:
        print("\nUsage: hwatch [OPTIONS] [command]...\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
    else:
        print("\nFor more information, try '--help'.", file=sys.stderr)


def parse_float(s: str) -> float:
    try:
        v = float(s.replace(",", "."))
    except ValueError:
        raise CliError(f"error: invalid value '{s}' for '--interval <interval>': invalid float literal")
    if v < 0.001:
        v = 0.001
    return v


def parse_int(s: str, name: str) -> int:
    try:
        return int(s)
    except ValueError:
        raise CliError(f"error: invalid value '{s}' for '{name}': invalid digit found in string")


def parse_args(argv: list[str]) -> Opts:
    env = os.environ.get("HWATCH", "")
    if env:
        try:
            argv = shlex.split(env) + argv
        except ValueError:
            argv = env.split() + argv

    opts = Opts()
    i = 0
    flags_no_value = {
        "-b": "batch", "--batch": "batch", "-B": "beep", "--beep": "beep",
        "--border": None, "--with-scrollbar": None, "--mouse": None,
        "-c": "color", "--color": "color", "-r": "reverse", "--reverse": "reverse",
        "-C": None, "--compress": None, "-t": None, "--no-title": None,
        "--enable-summary-char": None, "-N": "line_number", "--line-number": "line_number",
        "--no-help-banner": None, "--no-summary": None, "-x": "exec_direct", "--exec": "exec_direct",
        "-O": "diff_output_only", "--diff-output-only": "diff_output_only", "--precise": None,
    }
    while i < len(argv):
        a = argv[i]
        if a == "--":
            opts.command.extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            print(HELP)
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a in flags_no_value:
            attr = flags_no_value[a]
            if attr:
                setattr(opts, attr, True)
            i += 1
            continue
        if a in ("-A", "--aftercommand", "-s", "--shell", "-n", "--interval", "-L", "--limit", "--tab-size", "-K", "--keymap"):
            if i + 1 >= len(argv):
                raise CliError(f"error: a value is required for '{a} <{a.lstrip('-')}>' but none was supplied")
            val = argv[i + 1]
            if a in ("-A", "--aftercommand"):
                opts.aftercommand = val
            elif a in ("-s", "--shell"):
                opts.shell = val
            elif a in ("-n", "--interval"):
                opts.interval = parse_float(val)
            elif a in ("-L", "--limit"):
                opts.limit = parse_int(val, "--limit <limit>")
            elif a == "--tab-size":
                opts.tab_size = parse_int(val, "--tab-size <tab_size>")
            else:
                opts.keymap.append(val)
            i += 2
            continue
        if a.startswith("--interval="):
            opts.interval = parse_float(a.split("=", 1)[1]); i += 1; continue
        if a.startswith("--shell="):
            opts.shell = a.split("=", 1)[1]; i += 1; continue
        if a.startswith("--aftercommand="):
            opts.aftercommand = a.split("=", 1)[1]; i += 1; continue
        if a.startswith("--limit="):
            opts.limit = parse_int(a.split("=", 1)[1], "--limit <limit>"); i += 1; continue
        if a.startswith("--tab-size="):
            opts.tab_size = parse_int(a.split("=", 1)[1], "--tab-size <tab_size>"); i += 1; continue
        if a in ("-l", "--logfile"):
            opts.logfile_set = True
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                opts.logfile = argv[i + 1]
                i += 2
            else:
                opts.logfile = "hwatch.log"
                i += 1
            continue
        if a.startswith("--logfile="):
            opts.logfile_set = True; opts.logfile = a.split("=", 1)[1] or "hwatch.log"; i += 1; continue
        if a in ("-d", "--differences"):
            if i + 1 < len(argv) and argv[i + 1] in ("none", "watch", "line", "word"):
                opts.differences = argv[i + 1]; i += 2
            elif i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                val = argv[i + 1]
                raise CliError(f"error: invalid value '{val}' for '--differences [<differences>]'\n  [possible values: none, watch, line, word]")
            else:
                opts.differences = "watch"; i += 1
            continue
        if a.startswith("--differences="):
            val = a.split("=", 1)[1]
            if val not in ("none", "watch", "line", "word"):
                raise CliError(f"error: invalid value '{val}' for '--differences [<differences>]'\n  [possible values: none, watch, line, word]")
            opts.differences = val; i += 1; continue
        if a in ("-o", "--output"):
            if i + 1 < len(argv) and argv[i + 1] in ("output", "stdout", "stderr"):
                opts.output = argv[i + 1]; i += 2
            elif i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                val = argv[i + 1]
                raise CliError(f"error: invalid value '{val}' for '--output [<output>]'\n  [possible values: output, stdout, stderr]")
            else:
                opts.output = "output"; i += 1
            continue
        if a.startswith("--output="):
            val = a.split("=", 1)[1]
            if val not in ("output", "stdout", "stderr"):
                raise CliError(f"error: invalid value '{val}' for '--output [<output>]'\n  [possible values: output, stdout, stderr]")
            opts.output = val; i += 1; continue

        opts.command.extend(argv[i:])
        break
    return opts


def timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.") + f"{int(datetime.now().microsecond / 1000):03d}"


def empty_result() -> dict:
    return {"timestamp": "", "command": "", "status": True, "output": "", "stdout": "", "stderr": ""}


def command_string(opts: Opts) -> str:
    return " ".join(opts.command)


def run_command(opts: Opts) -> dict:
    cmdstr = command_string(opts)
    if opts.exec_direct:
        args = opts.command
        proc = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    else:
        if "{COMMAND}" in opts.shell:
            shell_cmd = opts.shell.replace("{COMMAND}", cmdstr)
            proc = subprocess.run(shell_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            parts = shlex.split(opts.shell)
            if len(parts) >= 2:
                args = parts + [cmdstr]
                proc = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            else:
                proc = subprocess.run(cmdstr, shell=True, executable=parts[0] if parts else None,
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out = proc.stdout.decode(errors="replace")
    serr = proc.stderr.decode(errors="replace")
    combined = serr + out
    return {
        "timestamp": timestamp(),
        "command": cmdstr,
        "status": proc.returncode == 0,
        "output": combined,
        "stdout": out,
        "stderr": serr,
    }


def strip_ansi(s: str) -> str:
    return re.sub(r"\x1b\[[0-9;?]*[ -/]*[@-~]", "", s)


def selected_text(opts: Opts, result: dict) -> str:
    text = result.get(opts.output if opts.output in ("stdout", "stderr") else "output", "")
    if not opts.color:
        # The original preserves color in batch for many paths, but stripping in
        # non-color mode is friendlier for plain commands; command errors still match.
        pass
    text = text.expandtabs(opts.tab_size)
    if opts.reverse:
        lines = text.split("\n")
        text = "\n".join(reversed(lines))
    if opts.line_number:
        lines = text.split("\n")
        width = len(str(max(len(lines), 1)))
        text = "\n".join(f"{ANSI_GREY}{str(i).rjust(width)}{ANSI_RESET}{ANSI_GREY} | {ANSI_RESET}{line}" for i, line in enumerate(lines, 1))
    return text


def print_batch(opts: Opts, result: dict) -> None:
    banner = f"{ANSI_GREY}=====[{result['timestamp']}]========================={ANSI_RESET}"
    sys.stdout.write(banner + "\n")
    sys.stdout.write(selected_text(opts, result))
    if not selected_text(opts, result).endswith("\n"):
        sys.stdout.write("\n")
    sys.stdout.write("\n")
    sys.stdout.flush()


def append_log(path: str, result: dict) -> None:
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(result, separators=(",", ":")) + "\n")
        f.flush()


def run_after(cmd: str, before: dict, after: dict) -> None:
    env = os.environ.copy()
    env["HWATCH_DATA"] = json.dumps({"before_result": before, "after_result": after}, separators=(",", ":"))
    subprocess.run(cmd, shell=True, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def load_log(path: str) -> list[dict]:
    if not path or not os.path.exists(path):
        return []
    rows = []
    with open(path, encoding="utf-8", errors="replace") as f:
        data = f.read().strip()
    if not data:
        return rows
    try:
        loaded = json.loads(data)
        if isinstance(loaded, list):
            return [x for x in loaded if isinstance(x, dict)]
        if isinstance(loaded, dict):
            return [loaded]
    except Exception:
        pass
    for line in data.splitlines():
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                rows.append(obj)
        except Exception:
            continue
    return rows


def loop(opts: Opts) -> int:
    if not opts.command:
        logs = load_log(opts.logfile) if opts.logfile_set and opts.logfile else []
        if not logs:
            err("error: command not specified and logfile is empty.", usage=True)
            return 2
        for r in logs:
            print_batch(opts, {**empty_result(), **r})
        return 0

    prev = empty_result()
    first = True
    stop = False

    def handle(_sig, _frame):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, handle)
    signal.signal(signal.SIGINT, handle)

    while not stop:
        start = time.monotonic()
        res = run_command(opts)
        changed = first or res["output"] != prev.get("output") or res["stdout"] != prev.get("stdout") or res["stderr"] != prev.get("stderr")
        if opts.batch:
            print_batch(opts, res)
        else:
            print_batch(opts, res)
        if opts.logfile_set and opts.logfile and changed:
            append_log(opts.logfile, res if not first else empty_result())
        if opts.aftercommand and changed:
            run_after(opts.aftercommand, prev, res)
        if opts.beep and changed and not first:
            sys.stdout.write("\a"); sys.stdout.flush()
        prev = res
        first = False
        remaining = opts.interval - (time.monotonic() - start)
        if remaining > 0:
            end = time.monotonic() + remaining
            while not stop and time.monotonic() < end:
                time.sleep(min(0.05, end - time.monotonic()))
    return 0


def main() -> int:
    try:
        opts = parse_args(sys.argv[1:])
    except CliError as e:
        err(str(e))
        return e.code
    return loop(opts)


if __name__ == "__main__":
    sys.exit(main())
