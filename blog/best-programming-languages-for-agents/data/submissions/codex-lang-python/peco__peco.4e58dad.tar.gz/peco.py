#!/usr/bin/env python3
import json
import os
import re
import subprocess
import sys


HELP = """Usage: peco [options] [FILE]

Options:
  -h, --help            show this help message and exit
  --query               initial value for query
  --rcfile              path to the settings file
  --version             print the version and exit
  -b, --buffer-size     number of lines to keep in search buffer
  --null                expect NUL (\\0) as separator for target/output
  --initial-index       position of the initial index of the selection (0 base)
  --initial-filter      specify the default filter
  --prompt              specify the prompt string
  --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'
  --select-1            select first item and immediately exit if the input contains only 1 item
  --exit-0              exit immediately with status 1 if the input is empty
  --select-all          select all items and immediately exit
  --on-cancel           specify action on user cancel. 'success' or 'error'.
                        default is 'success'. This may change in future versions
  --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.
                        default is to use colors. This option is experimental
  --exec                execute command instead of finishing/terminating peco.
                        Please note that this command will receive selected line(s) from stdin,
                        and will be executed via '/bin/sh -c' or 'cmd /c'
  --print-query         print out the current query as first line of output
  --ansi                enable ANSI color code support
  --height              display height in lines or percentage (e.g. '10', '50%')
"""

VERSION = "peco version v0.5.11 (built with go1.25.0)"
FILTERS = {"IgnoreCase", "CaseSensitive", "SmartCase", "IRegexp", "Regexp", "Fuzzy"}
LAYOUTS = {"top-down", "bottom-up", "top-down-query-bottom"}
ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


class PecoError(Exception):
    pass


class UsageError(PecoError):
    def __init__(self, msg):
        super().__init__(msg)
        self.msg = msg


def usage_error(msg):
    sys.stderr.write(msg + "\n\n" + HELP)
    raise UsageError(
        "Error: failed to setup peco: failed to parse command line: "
        "failed to parse command line options: invalid command line options: " + msg
    )


def parse_args(argv):
    opts = {
        "query": "",
        "rcfile": None,
        "buffer_size": None,
        "null": False,
        "initial_index": 0,
        "initial_filter": "IgnoreCase",
        "prompt": "QUERY>",
        "layout": "top-down",
        "select_1": False,
        "exit_0": False,
        "select_all": False,
        "on_cancel": None,
        "selection_prefix": None,
        "exec": None,
        "print_query": False,
        "ansi": False,
        "height": None,
        "files": [],
    }
    need_arg = {
        "--query": "query",
        "--rcfile": "rcfile",
        "-b": "buffer_size",
        "--buffer-size": "buffer_size",
        "--initial-index": "initial_index",
        "--initial-filter": "initial_filter",
        "--prompt": "prompt",
        "--layout": "layout",
        "--on-cancel": "on_cancel",
        "--selection-prefix": "selection_prefix",
        "--exec": "exec",
        "--height": "height",
    }
    bools = {
        "--null": "null",
        "--select-1": "select_1",
        "--exit-0": "exit_0",
        "--select-all": "select_all",
        "--print-query": "print_query",
        "--ansi": "ansi",
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a == "--version":
            print(VERSION)
            raise SystemExit(0)
        if a in need_arg:
            if i + 1 >= len(argv):
                usage_error(f"expected argument for flag `{a.lstrip('-')}'")
            opts[need_arg[a]] = argv[i + 1]
            i += 2
            continue
        if a in bools:
            opts[bools[a]] = True
            i += 1
            continue
        if a.startswith("--") and "=" in a:
            name, val = a.split("=", 1)
            if name in bools:
                sys.stderr.write(f"bool flag `{name}' cannot have an argument\n\n" + HELP)
                raise SystemExit(1)
            if name in need_arg:
                opts[need_arg[name]] = val
                i += 1
                continue
        if a.startswith("-") and a != "-":
            usage_error(f"unknown flag `{a.lstrip('-')}'")
        opts["files"].append(a)
        i += 1
    return opts


def parse_config(opts):
    paths = []
    explicit = opts["rcfile"]
    if explicit:
        paths = [explicit]
    else:
        xdg = os.environ.get("XDG_CONFIG_HOME")
        home = os.environ.get("HOME", "")
        if xdg:
            paths += [os.path.join(xdg, "peco", "config.json"), os.path.join(xdg, "peco", "config.yaml")]
        if home:
            paths += [
                os.path.join(home, ".config", "peco", "config.json"),
                os.path.join(home, ".config", "peco", "config.yaml"),
            ]
        for d in os.environ.get("XDG_CONFIG_DIRS", "").split(":"):
            if d:
                paths += [os.path.join(d, "peco", "config.json"), os.path.join(d, "peco", "config.yaml")]
        if home:
            paths += [os.path.join(home, ".peco", "config.json"), os.path.join(home, ".peco", "config.yaml")]

    found = None
    for p in paths:
        if os.path.exists(p):
            found = p
            break
    if explicit and found is None:
        raise PecoError(
            f"Error: failed to setup peco: failed to setup configuration: failed to read config file: "
            f"failed to open file {explicit}: open {explicit}: no such file or directory"
        )
    if not found or not found.endswith(".json"):
        return
    try:
        with open(found, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception as e:
        raise PecoError(
            "Error: failed to setup peco: failed to setup configuration: failed to read config file: " + str(e)
        )
    mapping = {
        "Prompt": "prompt",
        "InitialFilter": "initial_filter",
        "OnCancel": "on_cancel",
        "ANSI": "ansi",
        "Height": "height",
        "SelectionPrefix": "selection_prefix",
    }
    for k, v in mapping.items():
        if k in cfg and not option_was_set(k, opts):
            opts[v] = cfg[k]


def option_was_set(_key, _opts):
    return False


def validate(opts):
    if opts["layout"] not in LAYOUTS:
        raise PecoError(
            "Error: failed to setup peco: failed to parse command line: failed to parse command line options: "
            f"invalid command line arguments: unknown layout: '{opts['layout']}'"
        )
    if opts["on_cancel"] is not None and opts["on_cancel"] not in ("success", "error"):
        raise PecoError(
            f"Error: failed to setup peco: failed to apply configuration: invalid --on-cancel value: "
            f"invalid OnCancel value \"{opts['on_cancel']}\": must be \"success\" or \"error\""
        )
    if opts["initial_filter"] not in FILTERS:
        raise PecoError(
            "Error: failed to setup peco: failed to apply configuration: failed to populate initial filter: "
            "failed to set filter: specified filter was not found"
        )
    if opts["height"] is not None:
        h = str(opts["height"])
        ok = h.isdigit() or (h.endswith("%") and h[:-1].isdigit())
        if not ok:
            raise PecoError(
                "Error: failed to setup peco: failed to apply configuration: failed to parse height specification: "
                f"invalid height specification: \"{h}\""
            )


def read_input(opts):
    data = b""
    if opts["files"]:
        chunks = []
        for p in opts["files"]:
            try:
                with open(p, "rb") as f:
                    chunks.append(f.read())
            except OSError as e:
                raise PecoError(
                    f"Error: failed to setup input source: failed to open file for input: open {p}: {e.strerror.lower()}"
                )
        data = b"".join(chunks)
    else:
        data = sys.stdin.buffer.read()
    if opts["null"]:
        raw_lines = data.splitlines()
        items = []
        for raw in raw_lines:
            if b"\0" in raw:
                disp, out = raw.split(b"\0", 1)
            else:
                disp, out = raw, raw
            items.append((disp, out))
        return items
    return [(line, line) for line in data.splitlines()]


def split_query(q):
    terms = []
    for tok in str(q).split():
        neg = False
        if tok.startswith("\\-"):
            tok = tok[1:]
        elif tok.startswith("-") and len(tok) > 1:
            neg = True
            tok = tok[1:]
        terms.append((neg, tok))
    return terms


def fuzzy_match(term, text, case_sensitive):
    if not case_sensitive:
        term = term.lower()
        text = text.lower()
    pos = 0
    for ch in term:
        idx = text.find(ch, pos)
        if idx < 0:
            return False
        pos = idx + 1
    return True


def line_matches(disp, opts):
    q = opts["query"]
    if not q:
        return True
    text = disp.decode("utf-8", "ignore")
    if opts["ansi"]:
        text = ANSI_RE.sub("", text)
    filt = opts["initial_filter"]
    smart_sensitive = any(c.isupper() for c in q)
    for neg, term in split_query(q):
        if term == "":
            continue
        matched = False
        try:
            if filt == "CaseSensitive":
                matched = term in text
            elif filt == "SmartCase":
                matched = term in text if smart_sensitive else term.lower() in text.lower()
            elif filt == "Regexp":
                matched = re.search(term, text) is not None
            elif filt == "IRegexp":
                matched = re.search(term, text, re.I) is not None
            elif filt == "Fuzzy":
                matched = fuzzy_match(term, text, smart_sensitive)
            else:
                matched = term.lower() in text.lower()
        except re.error:
            matched = False
        if neg and matched:
            return False
        if not neg and not matched:
            return False
    return True


def filtered(items, opts):
    return [it for it in items if line_matches(it[0], opts)]


def emit_lines(items, opts, include_query=False):
    out = sys.stdout.buffer
    if include_query:
        out.write(str(opts["query"]).encode() + b"\n")
    for _, val in items:
        out.write(val + b"\n")


def no_screen_error():
    raise PecoError("Error: failed to initialize screen: failed to create tcell screen: terminal entry not found: term not set")


def interactive(items, opts):
    # A small non-curses fallback for real terminals. It accepts an optional query
    # and emits the initially selected matching line.
    matches = filtered(items, opts)
    if not matches:
        return 1
    idx = int(opts.get("initial_index") or 0)
    if idx < 0:
        idx = 0
    if idx >= len(matches):
        idx = len(matches) - 1
    if opts["print_query"]:
        sys.stdout.buffer.write(str(opts["query"]).encode() + b"\n")
    sys.stdout.buffer.write(matches[idx][1] + b"\n")
    return 0


def main(argv):
    try:
        opts = parse_args(argv)
        parse_config(opts)
        validate(opts)
        items = read_input(opts)
        matches = filtered(items, opts)

        if opts["exit_0"] and len(items) == 0:
            return 1
        if opts["select_1"] and len(matches) == 1 and (not opts["query"] or not opts["print_query"]):
            emit_lines(matches, opts, include_query=opts["print_query"])
            return 0
        if opts["select_all"] and not opts["query"]:
            emit_lines(items, opts, include_query=opts["print_query"])
            return 0
        if opts["exec"] and matches:
            data = b"".join(v + b"\n" for _, v in matches[:1])
            subprocess.run(opts["exec"], input=data, shell=True)
            return 0
        if not os.environ.get("TERM"):
            no_screen_error()
        return interactive(items, opts)
    except UsageError as e:
        sys.stderr.write(e.msg + "\n")
        return 1
    except PecoError as e:
        sys.stderr.write(str(e) + "\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
