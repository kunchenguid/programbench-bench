import struct


OUT_LEN = 32
KEY_LEN = 32
BLOCK_LEN = 64
CHUNK_LEN = 1024

CHUNK_START = 1 << 0
CHUNK_END = 1 << 1
PARENT = 1 << 2
ROOT = 1 << 3
KEYED_HASH = 1 << 4
DERIVE_KEY_CONTEXT = 1 << 5
DERIVE_KEY_MATERIAL = 1 << 6

IV = [
    0x6A09E667,
    0xBB67AE85,
    0x3C6EF372,
    0xA54FF53A,
    0x510E527F,
    0x9B05688C,
    0x1F83D9AB,
    0x5BE0CD19,
]

MSG_SCHEDULE = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
    [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8],
    [3, 4, 10, 12, 13, 2, 7, 14, 6, 5, 9, 0, 11, 15, 8, 1],
    [10, 7, 12, 9, 14, 3, 13, 15, 4, 0, 11, 2, 5, 8, 1, 6],
    [12, 13, 9, 11, 15, 10, 14, 8, 7, 2, 5, 3, 0, 1, 6, 4],
    [9, 14, 11, 5, 8, 12, 15, 1, 13, 3, 0, 10, 2, 6, 4, 7],
    [11, 15, 5, 0, 1, 9, 8, 6, 14, 10, 2, 12, 3, 4, 7, 13],
]


def _u32(x):
    return x & 0xFFFFFFFF


def _rotr(x, n):
    return ((x >> n) | ((x << (32 - n)) & 0xFFFFFFFF)) & 0xFFFFFFFF


def _g(state, a, b, c, d, mx, my):
    state[a] = _u32(state[a] + state[b] + mx)
    state[d] = _rotr(state[d] ^ state[a], 16)
    state[c] = _u32(state[c] + state[d])
    state[b] = _rotr(state[b] ^ state[c], 12)
    state[a] = _u32(state[a] + state[b] + my)
    state[d] = _rotr(state[d] ^ state[a], 8)
    state[c] = _u32(state[c] + state[d])
    state[b] = _rotr(state[b] ^ state[c], 7)


def _round(state, msg, schedule):
    m = [msg[i] for i in schedule]
    _g(state, 0, 4, 8, 12, m[0], m[1])
    _g(state, 1, 5, 9, 13, m[2], m[3])
    _g(state, 2, 6, 10, 14, m[4], m[5])
    _g(state, 3, 7, 11, 15, m[6], m[7])
    _g(state, 0, 5, 10, 15, m[8], m[9])
    _g(state, 1, 6, 11, 12, m[10], m[11])
    _g(state, 2, 7, 8, 13, m[12], m[13])
    _g(state, 3, 4, 9, 14, m[14], m[15])


def _words_from_block(block):
    if len(block) < BLOCK_LEN:
        block = block + b"\0" * (BLOCK_LEN - len(block))
    return list(struct.unpack("<16I", block))


def _words_from_key(key):
    return list(struct.unpack("<8I", key))


def _words_to_bytes(words):
    return struct.pack("<%dI" % len(words), *[_u32(w) for w in words])


def compress(cv, block_words, counter, block_len, flags):
    state = [
        cv[0],
        cv[1],
        cv[2],
        cv[3],
        cv[4],
        cv[5],
        cv[6],
        cv[7],
        IV[0],
        IV[1],
        IV[2],
        IV[3],
        counter & 0xFFFFFFFF,
        (counter >> 32) & 0xFFFFFFFF,
        block_len,
        flags,
    ]
    for schedule in MSG_SCHEDULE:
        _round(state, block_words, schedule)
    return [state[i] ^ state[i + 8] for i in range(8)] + [
        state[i + 8] ^ cv[i] for i in range(8)
    ]


class Output:
    def __init__(self, input_cv, block_words, counter, block_len, flags):
        self.input_cv = input_cv
        self.block_words = block_words
        self.counter = counter
        self.block_len = block_len
        self.flags = flags

    def chaining_value(self):
        return compress(
            self.input_cv, self.block_words, self.counter, self.block_len, self.flags
        )[:8]

    def root_bytes(self, length, seek=0):
        out = bytearray()
        block_counter = seek // BLOCK_LEN
        skip = seek % BLOCK_LEN
        while len(out) < length:
            words = compress(
                self.input_cv,
                self.block_words,
                block_counter,
                self.block_len,
                self.flags | ROOT,
            )
            block = _words_to_bytes(words)
            if skip:
                block = block[skip:]
                skip = 0
            need = length - len(out)
            out.extend(block[:need])
            block_counter += 1
        return bytes(out)


def _chunk_output(chunk, key_words, chunk_counter, flags):
    cv = key_words[:]
    blocks = [chunk[i : i + BLOCK_LEN] for i in range(0, len(chunk), BLOCK_LEN)]
    if not blocks:
        blocks = [b""]
    for i, block in enumerate(blocks):
        block_flags = flags
        if i == 0:
            block_flags |= CHUNK_START
        if i == len(blocks) - 1:
            block_flags |= CHUNK_END
            return Output(
                cv, _words_from_block(block), chunk_counter, len(block), block_flags
            )
        cv = compress(cv, _words_from_block(block), chunk_counter, BLOCK_LEN, block_flags)[
            :8
        ]
    raise AssertionError("unreachable")


def _parent_output(left_cv, right_cv, key_words, flags):
    return Output(key_words, left_cv + right_cv, 0, BLOCK_LEN, flags | PARENT)


def _parent_cv(left_cv, right_cv, key_words, flags):
    return _parent_output(left_cv, right_cv, key_words, flags).chaining_value()


def _root_output(data, key_words, flags):
    chunks = [data[i : i + CHUNK_LEN] for i in range(0, len(data), CHUNK_LEN)]
    if not chunks:
        chunks = [b""]
    outputs = [
        _chunk_output(chunk, key_words, counter, flags)
        for counter, chunk in enumerate(chunks)
    ]
    if len(outputs) == 1:
        return outputs[0]
    cvs = [output.chaining_value() for output in outputs]

    def subtree_cv(items):
        if len(items) == 1:
            return items[0]
        split = 1 << ((len(items) - 1).bit_length() - 1)
        return _parent_cv(
            subtree_cv(items[:split]), subtree_cv(items[split:]), key_words, flags
        )

    split = 1 << ((len(cvs) - 1).bit_length() - 1)
    return _parent_output(
        subtree_cv(cvs[:split]), subtree_cv(cvs[split:]), key_words, flags
    )


def _blake3_with_flags(data, length=OUT_LEN, seek=0, flags=0):
    return _root_output(data, IV[:], flags).root_bytes(length, seek)


# Keep the public function simple while allowing derive-key setup above.
def blake3(data, length=OUT_LEN, seek=0, key=None, derive_context=None, _flags=None):
    if _flags is not None:
        return _blake3_with_flags(data, length, seek, _flags)
    if key is not None and derive_context is not None:
        raise ValueError("key and derive_context are mutually exclusive")
    if key is not None:
        if len(key) != KEY_LEN:
            raise ValueError("key must be 32 bytes")
        key_words = _words_from_key(key)
        flags = KEYED_HASH
    elif derive_context is not None:
        context_key = _blake3_with_flags(
            derive_context.encode(), KEY_LEN, 0, DERIVE_KEY_CONTEXT
        )
        key_words = _words_from_key(context_key)
        flags = DERIVE_KEY_MATERIAL
    else:
        key_words = IV[:]
        flags = 0
    return _root_output(data, key_words, flags).root_bytes(length, seek)
