#!/usr/bin/env python3
import argparse
import os
import re
import sys

from blake3_py import KEY_LEN, blake3


VERSION = "b3sum 1.8.4"


HELP = """Usage: executable [OPTIONS] [FILE]...

Arguments:
  [FILE]...
          Files to hash, or checkfiles to check

          When no file is given, or when - is given, read standard input.

Options:
      --keyed
          Use the keyed mode, reading the 32-byte key from stdin

      --derive-key <CONTEXT>
          Use the key derivation mode, with the given context string

          Cannot be used with --keyed.

  -l, --length <LEN>
          The number of output bytes, before hex encoding

          [default: 32]

      --seek <SEEK>
          The starting output byte offset, before hex encoding

          [default: 0]

      --num-threads <NUM>
          The maximum number of threads to use

          By default, this is the number of logical cores. If this flag is omitted, or if its value
          is 0, RAYON_NUM_THREADS is also respected.

      --no-mmap
          Disable memory mapping

          Currently this also disables multithreading.

      --no-names
          Omit filenames in the output

      --raw
          Write raw output bytes to stdout, rather than hex

          --no-names is implied. In this case, only a single input is allowed.

      --tag
          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]

  -c, --check
          Read BLAKE3 sums from the [FILE]s and check them

      --quiet
          Skip printing OK for each checked file

          Must be used with --check.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


class Parser(argparse.ArgumentParser):
    def error(self, message):
        sys.stderr.write(f"error: {message}\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        raise SystemExit(2)


def build_parser():
    parser = Parser(add_help=False, prog="executable")
    parser.add_argument("--keyed", action="store_true")
    parser.add_argument("--derive-key", metavar="CONTEXT")
    parser.add_argument("-l", "--length", type=parse_nonnegative, default=32)
    parser.add_argument("--seek", type=parse_nonnegative, default=0)
    parser.add_argument("--num-threads", type=parse_nonnegative)
    parser.add_argument("--no-mmap", action="store_true")
    parser.add_argument("--no-names", action="store_true")
    parser.add_argument("--raw", action="store_true")
    parser.add_argument("--tag", action="store_true")
    parser.add_argument("-c", "--check", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("files", nargs="*")
    return parser


def parse_nonnegative(s):
    try:
        value = int(s, 0)
    except ValueError:
        raise argparse.ArgumentTypeError(f"invalid value '{s}'")
    if value < 0:
        raise argparse.ArgumentTypeError(f"invalid value '{s}'")
    return value


def die(message, status=1):
    print(f"Error: {message}", file=sys.stderr)
    raise SystemExit(status)


def read_key():
    key = sys.stdin.buffer.read(KEY_LEN)
    if len(key) != KEY_LEN:
        die(f"expected 32 key bytes from stdin, found {len(key)}")
    return key


def read_input(path):
    if path == "-":
        return sys.stdin.buffer.read()
    with open(path, "rb") as f:
        return f.read()


def hash_bytes(data, args, key):
    return blake3(
        data,
        length=args.length,
        seek=args.seek,
        key=key,
        derive_context=args.derive_key,
    )


def print_hash(digest, name, args):
    if args.raw:
        sys.stdout.buffer.write(digest)
        return
    hex_digest = digest.hex()
    if args.no_names:
        print(hex_digest)
    elif args.tag:
        print(f"BLAKE3 ({name}) = {hex_digest}")
    else:
        escaped, escaped_name = escape_name(name)
        prefix = "\\" if escaped else ""
        print(f"{prefix}{hex_digest}  {escaped_name}")


def escape_name(name):
    escaped = "\\" in name or "\n" in name
    if escaped:
        return True, name.replace("\\", "\\\\").replace("\n", "\\n")
    return False, name


def unescape_name(name):
    out = []
    i = 0
    while i < len(name):
        if name[i] == "\\" and i + 1 < len(name):
            nxt = name[i + 1]
            if nxt == "n":
                out.append("\n")
            elif nxt == "\\":
                out.append("\\")
            else:
                out.append(nxt)
            i += 2
        else:
            out.append(name[i])
            i += 1
    return "".join(out)


def hash_mode(args):
    if args.raw and len(args.files or ["-"]) > 1:
        die("Only one filename can be provided when using --raw")
    key = read_key() if args.keyed else None
    files = args.files or ["-"]
    had_error = False
    for path in files:
        try:
            data = read_input(path)
            digest = hash_bytes(data, args, key)
            print_hash(digest, path, args)
        except OSError as e:
            print(f"executable: {path}: {e.strerror}", file=sys.stderr)
            had_error = True
    return 1 if had_error else 0


HEX_RE = re.compile(r"^[0-9a-fA-F]+$")
TAG_RE = re.compile(r"^BLAKE3 \((.*)\) = ([0-9a-fA-F]+)$")


def parse_check_line(line):
    line = line.rstrip("\n")
    escaped_line = False
    match = TAG_RE.match(line)
    if match:
        return match.group(2).lower(), match.group(1)
    if len(line) >= 3 and line[0] == "\\":
        line = line[1:]
        escaped_line = True
    parts = line.split(None, 1)
    if len(parts) != 2 or not HEX_RE.match(parts[0]):
        return None
    name = parts[1]
    if name.startswith("*") or name.startswith(" "):
        name = name[1:]
    if escaped_line:
        name = unescape_name(name)
    return parts[0].lower(), name


def iter_check_lines(files):
    if not files:
        for raw in sys.stdin:
            yield "-", raw
    else:
        for path in files:
            try:
                with open(path, "r", encoding="utf-8", errors="surrogateescape") as f:
                    for line in f:
                        yield path, line
            except OSError as e:
                print(f"executable: {path}: {e.strerror}", file=sys.stderr)
                yield path, None


def check_mode(args):
    if args.keyed:
        die("The --keyed flag cannot be used with --check")
    if args.derive_key is not None:
        die("The --derive-key flag cannot be used with --check")
    ok_count = 0
    failed_count = 0
    malformed = 0
    for checkfile, line in iter_check_lines(args.files):
        if line is None:
            failed_count += 1
            continue
        parsed = parse_check_line(line)
        if parsed is None:
            malformed += 1
            print(f"{prog()}: Invalid check line format", file=sys.stderr)
            continue
        expected, name = parsed
        try:
            actual = blake3(read_input(name), length=len(expected) // 2).hex()
            if actual.lower() == expected.lower():
                ok_count += 1
                if not args.quiet:
                    escaped, escaped_name = escape_name(name)
                    prefix = "\\" if escaped else ""
                    print(f"{prefix}{escaped_name}: OK")
            else:
                failed_count += 1
                escaped, escaped_name = escape_name(name)
                prefix = "\\" if escaped else ""
                print(f"{prefix}{escaped_name}: FAILED")
        except OSError as e:
            failed_count += 1
            print(f"{name}: FAILED open or read", file=sys.stderr)
            print(f"executable: {name}: {e.strerror}", file=sys.stderr)
    if malformed:
        failed_count += malformed
    if failed_count:
        print(
            f"{prog()}: WARNING: {failed_count} computed checksum did NOT match",
            file=sys.stderr,
        )
    return 1 if failed_count or malformed else 0


def prog():
    return os.path.basename(sys.argv[0]) or "executable"


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--help" in argv or "-h" in argv:
        sys.stdout.write(HELP)
        return 0
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        return 0
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.keyed and args.derive_key is not None:
        sys.stderr.write(
            "error: the argument '--keyed' cannot be used with '--derive-key <CONTEXT>'\n\n"
        )
        sys.stderr.write("Usage: executable --keyed <FILE>...\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        return 2
    if args.keyed and not args.files:
        sys.stderr.write(
            "error: the following required arguments were not provided:\n  <FILE>...\n\n"
        )
        sys.stderr.write("Usage: executable --keyed <FILE>...\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        return 2
    if args.quiet and not args.check:
        sys.stderr.write(
            "error: the following required arguments were not provided:\n  --check\n\n"
        )
        sys.stderr.write("Usage: executable --check --quiet <FILE>...\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        return 2
    if args.check:
        for flag_name, value, usage in [
            ("--length <LEN>", args.length != 32, "Usage: executable --check <FILE>..."),
            ("--seek <SEEK>", args.seek != 0, "Usage: executable --check <FILE>..."),
            ("--no-names", args.no_names, "Usage: executable --check <FILE>..."),
            ("--raw", args.raw, "Usage: executable --check <FILE>..."),
            ("--tag", args.tag, "Usage: executable --check <FILE>..."),
        ]:
            if value:
                sys.stderr.write(
                    f"error: the argument '--check' cannot be used with '{flag_name}'\n\n"
                )
                sys.stderr.write(f"{usage}\n\n")
                sys.stderr.write("For more information, try '--help'.\n")
                return 2
    if args.check:
        return check_mode(args)
    return hash_mode(args)


if __name__ == "__main__":
    raise SystemExit(main())
