#!/usr/bin/env python3
import argparse
import json
import os
import shlex
import subprocess
import sys
import time
from dataclasses import dataclass, field

VERSION = "1.14.0.git"


def err(msg, code=1):
    sys.stderr.write(f"ninja: {msg}\n")
    raise SystemExit(code)


def shell_quote(s):
    return shlex.quote(s)


class Scope:
    def __init__(self, parent=None):
        self.parent = parent
        self.vars = {}
        self.rules = {}
        self.pools = {}

    def get(self, name):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        return ""

    def get_rule(self, name):
        if name in self.rules:
            return self.rules[name]
        if self.parent:
            return self.parent.get_rule(name)
        return None


def expand(s, scope, extra=None, path=False):
    extra = extra or {}
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c != "$":
            out.append(c)
            i += 1
            continue
        i += 1
        if i >= len(s):
            out.append("$")
            break
        c = s[i]
        if c == "$":
            out.append("$")
            i += 1
        elif c == " ":
            out.append(" ")
            i += 1
        elif c == ":":
            out.append(":")
            i += 1
        elif c == "^":
            out.append("\n")
            i += 1
        elif c == "{":
            j = s.find("}", i + 1)
            if j < 0:
                out.append("${")
                i += 1
            else:
                name = s[i + 1:j]
                out.append(extra.get(name, scope.get(name)))
                i = j + 1
        else:
            j = i
            while j < len(s) and (s[j].isalnum() or s[j] in "_.-"):
                j += 1
            if j == i:
                out.append(c)
                i += 1
            else:
                name = s[i:j]
                out.append(extra.get(name, scope.get(name)))
                i = j
    return "".join(out)


def split_words(s):
    words, cur = [], []
    i = 0
    while i < len(s):
        c = s[i]
        if c in " \t\r\n":
            if cur:
                words.append("".join(cur))
                cur = []
            i += 1
        elif c == "$" and i + 1 < len(s):
            n = s[i + 1]
            if n == " ":
                cur.append(" ")
                i += 2
            elif n == ":":
                cur.append(":")
                i += 2
            elif n == "$":
                cur.append("$")
                i += 2
            else:
                cur.append(c)
                i += 1
        else:
            cur.append(c)
            i += 1
    if cur:
        words.append("".join(cur))
    return words


def logical_lines(text):
    raw = text.splitlines()
    result = []
    buf = ""
    start = 1
    for no, line in enumerate(raw, 1):
        if buf == "":
            start = no
        hashpos = line.find("#")
        if hashpos >= 0:
            line = line[:hashpos]
        if line.endswith("$"):
            buf += line[:-1]
            continue
        line2 = line.lstrip(" \t") if buf else line
        result.append((start, buf + line2))
        buf = ""
    if buf:
        result.append((start, buf))
    return result


@dataclass
class Rule:
    name: str
    bindings: dict
    scope: Scope


@dataclass
class Edge:
    explicit_outs: list
    implicit_outs: list
    rule_name: str
    explicit_ins: list
    implicit_ins: list
    order_only: list
    validations: list
    bindings: dict = field(default_factory=dict)
    scope: Scope = None

    @property
    def outs(self):
        return self.explicit_outs + self.implicit_outs

    @property
    def ins(self):
        return self.explicit_ins + self.implicit_ins + self.order_only


class Manifest:
    def __init__(self):
        self.root = Scope()
        self.edges = []
        self.out_to_edge = {}
        self.defaults = []
        self.build_file = "build.ninja"

    def parse_file(self, path, scope=None):
        scope = scope or self.root
        olddir = os.getcwd()
        path = os.path.normpath(path)
        base = os.path.dirname(path) or "."
        try:
            text = open(path, encoding="utf-8", errors="surrogateescape").read()
        except OSError as e:
            err(f"error opening build file '{path}': {e.strerror}")
        lines = logical_lines(text)
        i = 0
        while i < len(lines):
            no, line = lines[i]
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                i += 1
                continue
            if line[0].isspace():
                err(f"{path}:{no}: unexpected indent")
            if stripped.startswith("rule "):
                name = stripped.split(None, 1)[1].strip()
                bindings = {}
                i += 1
                while i < len(lines) and lines[i][1][:1].isspace():
                    _, sub = lines[i]
                    sub = sub.strip()
                    if sub and not sub.startswith("#"):
                        k, v = self.parse_binding(sub, scope, late=True)
                        bindings[k] = v
                    i += 1
                scope.rules[name] = Rule(name, bindings, scope)
                continue
            if stripped.startswith("pool "):
                name = stripped.split(None, 1)[1].strip()
                bindings = {}
                i += 1
                while i < len(lines) and lines[i][1][:1].isspace():
                    _, sub = lines[i]
                    sub = sub.strip()
                    if sub and not sub.startswith("#"):
                        k, v = self.parse_binding(sub, scope)
                        bindings[k] = v
                    i += 1
                scope.pools[name] = bindings
                continue
            if stripped.startswith("build "):
                edge = self.parse_build(stripped[6:], scope)
                i += 1
                while i < len(lines) and lines[i][1][:1].isspace():
                    _, sub = lines[i]
                    sub = sub.strip()
                    if sub and not sub.startswith("#"):
                        k, v = self.parse_binding(sub, scope)
                        edge.bindings[k] = v
                    i += 1
                self.edges.append(edge)
                for o in edge.outs:
                    if o in self.out_to_edge:
                        err(f"multiple rules generate {o}")
                    self.out_to_edge[o] = edge
                continue
            if stripped.startswith("default "):
                self.defaults.extend([expand(w, scope) for w in split_words(stripped[8:])])
                i += 1
                continue
            if stripped.startswith("include "):
                inc = expand(stripped[8:].strip(), scope)
                self.parse_file(os.path.join(base, inc), scope)
                i += 1
                continue
            if stripped.startswith("subninja "):
                inc = expand(stripped[9:].strip(), scope)
                self.parse_file(os.path.join(base, inc), Scope(scope))
                i += 1
                continue
            if "=" in stripped:
                k, v = self.parse_binding(stripped, scope)
                scope.vars[k] = v
                i += 1
                continue
            err(f"{path}:{no}: unknown target '{stripped}'")

    def parse_binding(self, line, scope, late=False):
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.lstrip(" \t")
        return k, (v if late else expand(v, scope))

    def parse_build(self, rest, scope):
        words = split_words(rest)
        outs, implicit_outs = [], []
        cur = outs
        i = 0
        while i < len(words):
            w = words[i]
            if w == "|":
                cur = implicit_outs
            elif w.endswith(":"):
                token = w[:-1]
                if token:
                    cur.append(token)
                i += 1
                break
            elif ":" in w:
                a, b = w.split(":", 1)
                if a:
                    cur.append(a)
                words.insert(i + 1, b)
                i += 1
                break
            else:
                cur.append(w)
            i += 1
        if i > len(words):
            err("expected ':' in build statement")
        if i >= len(words):
            err("expected build command name")
        rule = words[i]
        i += 1
        explicit, implicit, order, validations = [], [], [], []
        cur = explicit
        while i < len(words):
            w = words[i]
            if w == "|":
                cur = implicit
            elif w == "||":
                cur = order
            elif w == "|@":
                cur = validations
            else:
                cur.append(w)
            i += 1
        outs = [expand(w, scope) for w in outs]
        implicit_outs = [expand(w, scope) for w in implicit_outs]
        explicit = [expand(w, scope) for w in explicit]
        implicit = [expand(w, scope) for w in implicit]
        order = [expand(w, scope) for w in order]
        validations = [expand(w, scope) for w in validations]
        return Edge(outs, implicit_outs, rule, explicit, implicit, order, validations, {}, scope)


class Runner:
    def __init__(self, man, opts):
        self.man = man
        self.opts = opts
        self.log_path = os.path.join(man.root.get("builddir") or ".", ".ninja_log")
        self.deps_path = os.path.join(man.root.get("builddir") or ".", ".ninja_deps_py")
        self.log = self.read_log()
        self.deps = self.read_deps()
        self.visiting = set()
        self.plan = []
        self.planned = set()

    def read_log(self):
        try:
            data = open(self.log_path, encoding="utf-8").read()
        except OSError:
            return {}
        if data.startswith("# ninja log"):
            res = {}
            for line in data.splitlines()[1:]:
                parts = line.split("\t")
                if len(parts) >= 5:
                    res[parts[3]] = parts[4]
            return res
        try:
            return json.loads(data)
        except Exception:
            return {}

    def write_log(self, built):
        if not built:
            return
        os.makedirs(os.path.dirname(self.log_path) or ".", exist_ok=True)
        with open(self.log_path, "w", encoding="utf-8") as f:
            f.write("# ninja log v5\n")
            now = int(time.time() * 1000)
            for out, cmd in sorted(self.log.items()):
                f.write(f"{now}\t{now}\t0\t{out}\t{cmd}\n")

    def read_deps(self):
        try:
            return json.load(open(self.deps_path, encoding="utf-8"))
        except Exception:
            return {}

    def write_deps(self):
        if not self.deps:
            return
        os.makedirs(os.path.dirname(self.deps_path) or ".", exist_ok=True)
        with open(self.deps_path, "w", encoding="utf-8") as f:
            json.dump(self.deps, f)

    def parse_depfile(self, path):
        try:
            data = open(path, encoding="utf-8", errors="surrogateescape").read()
        except OSError:
            return []
        data = data.replace("\\\n", " ")
        words = []
        cur = []
        esc = False
        in_targets = True
        for c in data:
            if esc:
                cur.append(c)
                esc = False
            elif c == "\\":
                esc = True
            elif c == ":" and in_targets:
                cur = []
                in_targets = False
            elif c.isspace():
                if cur:
                    words.append("".join(cur))
                    cur = []
            else:
                cur.append(c)
        if cur:
            words.append("".join(cur))
        return words

    def edge_vars(self, edge, current=None):
        exp_in = self.flatten_phony(edge.explicit_ins)
        extra = {
            "in": " ".join(shell_quote(x) for x in exp_in),
            "in_newline": "\n".join(exp_in),
            "out": " ".join(shell_quote(x) for x in edge.explicit_outs),
        }
        for k, v in edge.bindings.items():
            if k != current:
                extra[k] = expand(v, edge.scope, extra)
        return extra

    def get_binding(self, edge, name):
        if name in edge.bindings:
            return expand(edge.bindings[name], edge.scope, self.edge_vars(edge, name))
        rule = edge.scope.get_rule(edge.rule_name)
        if rule and name in rule.bindings:
            extra = self.edge_vars(edge, name)
            return expand(rule.bindings[name], edge.scope, extra)
        return edge.scope.get(name)

    def flatten_phony(self, inputs):
        result = []
        for p in inputs:
            e = self.man.out_to_edge.get(p)
            if e and e.rule_name == "phony":
                result.extend(self.flatten_phony(e.explicit_ins))
            else:
                result.append(p)
        return result

    def command(self, edge):
        if edge.rule_name == "phony":
            return ""
        return self.get_binding(edge, "command")

    def mtime(self, p):
        try:
            return os.path.getmtime(p)
        except OSError:
            return None

    def is_dirty(self, edge):
        if edge.rule_name == "phony":
            return any(self.target_dirty(i) for i in edge.ins) or any(self.mtime(o) is None for o in edge.outs)
        out_times = [self.mtime(o) for o in edge.outs]
        if any(t is None for t in out_times):
            return True
        newest_in = 0
        extra_deps = []
        depfile = self.get_binding(edge, "depfile")
        if depfile and os.path.exists(depfile):
            extra_deps.extend(self.parse_depfile(depfile))
        for o in edge.outs:
            extra_deps.extend(self.deps.get(o, []))
        for p in edge.explicit_ins + edge.implicit_ins + extra_deps:
            self.target_dirty(p)
            mt = self.mtime(p)
            if mt is None and p not in self.man.out_to_edge:
                err(f"'{p}', needed by '{edge.explicit_outs[0]}', missing and no known rule to make it")
            newest_in = max(newest_in, mt or 0)
        if newest_in > min(out_times):
            return True
        cmd = self.command(edge)
        return self.log.get(edge.explicit_outs[0]) != cmd

    def target_dirty(self, target):
        edge = self.man.out_to_edge.get(target)
        if not edge:
            return self.mtime(target) is None
        self.visit(edge)
        return edge in self.plan

    def visit(self, edge):
        eid = id(edge)
        if eid in self.planned:
            return
        if eid in self.visiting:
            err("dependency cycle")
        self.visiting.add(eid)
        for p in edge.ins + edge.validations:
            dep = self.man.out_to_edge.get(p)
            if dep:
                self.visit(dep)
            elif p in edge.explicit_ins + edge.implicit_ins and self.mtime(p) is None and edge.rule_name != "phony":
                err(f"'{p}', needed by '{edge.explicit_outs[0]}', missing and no known rule to make it")
        self.visiting.remove(eid)
        if self.is_dirty(edge) and edge.rule_name != "phony":
            self.plan.append(edge)
        self.planned.add(eid)

    def build_targets(self, targets):
        if not targets:
            targets = self.man.defaults or self.root_targets()
        expanded = []
        for t in targets:
            if t.endswith("^"):
                src = t[:-1]
                found = None
                for e in self.man.edges:
                    if src in e.explicit_ins + e.implicit_ins:
                        found = e.explicit_outs[0]
                        break
                if found:
                    expanded.append(found)
                else:
                    expanded.append(t)
            else:
                expanded.append(t)
        for t in expanded:
            e = self.man.out_to_edge.get(t)
            if e:
                self.visit(e)
            elif self.mtime(t) is None:
                err(f"unknown target '{t}'")
        if not self.plan:
            print("ninja: no work to do.")
            return 0
        if self.opts.dry_run:
            for idx, e in enumerate(self.plan, 1):
                self.print_edge(idx, len(self.plan), e)
            return 0
        built = []
        for idx, e in enumerate(self.plan, 1):
            code = self.run_edge(idx, len(self.plan), e)
            if code != 0:
                return code
            built.extend(e.outs)
            cmd = self.command(e)
            for o in e.outs:
                self.log[o] = cmd
        self.write_log(built)
        return 0

    def root_targets(self):
        used = set()
        for e in self.man.edges:
            used.update(e.ins)
        return [e.explicit_outs[0] for e in self.man.edges if e.explicit_outs and e.explicit_outs[0] not in used]

    def status(self, idx, total):
        fmt = os.environ.get("NINJA_STATUS", "[%f/%t] ")
        return fmt.replace("%f", str(idx)).replace("%s", str(idx)).replace("%t", str(total)).replace("%r", "1").replace("%u", str(total - idx)).replace("%p", str(int(idx * 100 / total))).replace("%%", "%")

    def print_edge(self, idx, total, edge):
        cmd = self.command(edge)
        desc = self.get_binding(edge, "description")
        text = cmd if self.opts.verbose or not desc else desc
        if not self.opts.quiet:
            print(self.status(idx, total) + text)

    def run_edge(self, idx, total, edge):
        cmd = self.command(edge)
        rsp = self.get_binding(edge, "rspfile")
        if rsp:
            with open(rsp, "w", encoding="utf-8") as f:
                f.write(self.get_binding(edge, "rspfile_content"))
        for o in edge.outs:
            d = os.path.dirname(o)
            if d:
                os.makedirs(d, exist_ok=True)
        self.print_edge(idx, total, edge)
        p = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if p.returncode != 0:
            if not self.opts.verbose:
                print(cmd)
            if p.stdout:
                sys.stdout.write(p.stdout)
            return p.returncode
        if p.stdout:
            sys.stdout.write(p.stdout)
        depfile = self.get_binding(edge, "depfile")
        if depfile and os.path.exists(depfile):
            parsed = self.parse_depfile(depfile)
            for o in edge.outs:
                self.deps[o] = parsed
            self.write_deps()
            if self.get_binding(edge, "deps") and not self.opts.keepdepfile:
                try:
                    os.remove(depfile)
                except OSError:
                    pass
        if rsp and os.path.exists(rsp) and not self.opts.keeprsp:
            try:
                os.remove(rsp)
            except OSError:
                pass
        return 0


def load_manifest(buildfile):
    m = Manifest()
    m.build_file = buildfile
    m.parse_file(buildfile, m.root)
    m.root.rules.setdefault("phony", Rule("phony", {}, m.root))
    return m


def topo_edges(man, targets):
    r = Runner(man, argparse.Namespace(dry_run=True, verbose=False, quiet=True, keepdepfile=False, keeprsp=False))
    ordered = []
    seen = set()

    def visit_all(edge):
        if id(edge) in seen:
            return
        seen.add(id(edge))
        for p in edge.ins + edge.validations:
            dep = man.out_to_edge.get(p)
            if dep:
                visit_all(dep)
        if edge.rule_name != "phony":
            ordered.append(edge)

    for t in targets or man.defaults or r.root_targets():
        e = man.out_to_edge.get(t)
        if e:
            visit_all(e)
    return ordered


def tool_query(man, args):
    for target in args:
        e = man.out_to_edge.get(target)
        if not e:
            print(f"{target}:")
            print("  input: unknown")
            print("  outputs:")
            continue
        print(f"{target}:")
        print(f"  input: {e.rule_name}")
        for p in e.explicit_ins:
            print(f"    {p}")
        for p in e.implicit_ins:
            print(f"    | {p}")
        for p in e.order_only:
            print(f"    || {p}")
        print("  outputs:")
        for out, oe in sorted(man.out_to_edge.items()):
            if target in oe.explicit_ins + oe.implicit_ins + oe.order_only:
                print(f"    {out}")


def tool_targets(man, args):
    mode = args[0] if args else "depth"
    if mode == "all":
        for e in man.edges:
            for o in e.outs:
                print(o)
    elif mode == "rule" and len(args) > 1:
        for e in man.edges:
            if e.rule_name == args[1]:
                print(" ".join(e.outs))
    else:
        for e in man.edges:
            if e.explicit_outs:
                print(f"{e.explicit_outs[0]}: {e.rule_name}")


def tool_rules(man, args):
    names = set()
    def collect(s):
        if s.parent:
            collect(s.parent)
        names.update(s.rules.keys())
    collect(man.root)
    names.add("phony")
    for n in sorted(names):
        print(n)


def tool_commands(man, args):
    short = False
    targets = []
    for a in args:
        if a == "-s":
            short = True
        else:
            targets.append(a)
    edges = topo_edges(man, targets)
    if short and edges:
        edges = [edges[-1]]
    r = Runner(man, argparse.Namespace(dry_run=True, verbose=False, quiet=True, keepdepfile=False, keeprsp=False))
    for e in edges:
        cmd = r.command(e)
        if cmd:
            print(cmd)


def tool_inputs(man, args, multi=False):
    no_escape = "--no-shell-escape" in args
    targets = [a for a in args if not a.startswith("-")]
    seen = set()
    for e in topo_edges(man, targets):
        for p in e.explicit_ins:
            if p in man.out_to_edge:
                continue
            if multi:
                print(f"{e.explicit_outs[0]}\t{p}")
            elif p not in seen:
                seen.add(p)
                print(p if no_escape else shell_quote(p))


def tool_clean(man, args, opts):
    dry = opts.dry_run
    verbose = opts.verbose or dry
    rules = []
    if "-r" in args:
        idx = args.index("-r")
        rules = [a for a in args[idx + 1:] if not a.startswith("-")]
    targets = [a for a in args if not a.startswith("-")]
    outs = []
    if rules:
        for e in man.edges:
            if e.rule_name in rules:
                outs.extend(e.outs)
    elif targets:
        for e in topo_edges(man, targets):
            outs.extend(e.outs)
    else:
        for e in man.edges:
            if e.rule_name != "phony":
                outs.extend(e.outs)
    count = 0
    for p in sorted(set(outs)):
        if os.path.exists(p):
            count += 1
            if verbose:
                print(f"Remove {p}")
            if not dry:
                try:
                    os.remove(p)
                except OSError:
                    pass
    print(f"Cleaning... {count} files.")


def tool_compdb(man, args, targets_mode=False):
    expand_rsp = False
    vals = []
    for a in args:
        if a == "-x":
            expand_rsp = True
        else:
            vals.append(a)
    r = Runner(man, argparse.Namespace(dry_run=True, verbose=False, quiet=True, keepdepfile=False, keeprsp=False))
    rows = []
    edges = topo_edges(man, vals) if targets_mode else [e for e in man.edges if (not vals or e.rule_name in vals)]
    for e in edges:
        if not e.explicit_ins or not e.explicit_outs:
            continue
        cmd = r.command(e)
        if expand_rsp:
            rsp = r.get_binding(e, "rspfile")
            if rsp:
                cmd = cmd.replace("@" + rsp, r.get_binding(e, "rspfile_content"))
        rows.append({"directory": os.getcwd(), "command": cmd, "file": e.explicit_ins[0], "output": e.explicit_outs[0]})
    print(json.dumps(rows, indent=2))


def tool_graph(man, args):
    print('digraph ninja {')
    print('rankdir="LR"')
    print('node [fontsize=10, shape=box, height=0.25]')
    print('edge [fontsize=10]')
    edges = topo_edges(man, args) if args else man.edges
    for i, e in enumerate(edges):
        rid = f"rule{i}"
        for o in e.outs:
            print(f'"{o}" [label="{o}"]')
            print(f'"{rid}" -> "{o}"')
        print(f'"{rid}" [label="{e.rule_name}", shape=ellipse]')
        for p in e.explicit_ins + e.implicit_ins + e.order_only:
            print(f'"{p}" -> "{rid}" [arrowhead=none]')
            print(f'"{p}" [label="{p}"]')
    print('}')


def run_tool(name, man, args, opts):
    if name == "list":
        print("""ninja subtools:
     browse  browse dependency graph in a web browser
      clean  clean built files
   commands  list all commands required to rebuild given targets
     inputs  list all inputs required to rebuild given targets
multi-inputs  print one or more sets of inputs required to build targets
       deps  show dependencies stored in the deps log
missingdeps  check deps log dependencies on generated files
      graph  output graphviz dot file for targets
      query  show inputs/outputs for a path
    targets  list targets by their rule or depth in the DAG
     compdb  dump JSON compilation database to stdout
compdb-targets  dump JSON compilation database for a given list of targets to stdout
  recompact  recompacts ninja-internal data structures
     restat  restats all outputs in the build log
      rules  list all rules
  cleandead  clean built files that are no longer produced by the manifest""")
    elif name == "query":
        tool_query(man, args)
    elif name == "targets":
        tool_targets(man, args)
    elif name == "rules":
        tool_rules(man, args)
    elif name == "commands":
        tool_commands(man, args)
    elif name == "inputs":
        tool_inputs(man, args)
    elif name == "multi-inputs":
        tool_inputs(man, args, multi=True)
    elif name == "clean":
        tool_clean(man, args, opts)
    elif name == "compdb":
        tool_compdb(man, args)
    elif name == "compdb-targets":
        tool_compdb(man, args, targets_mode=True)
    elif name == "graph":
        tool_graph(man, args)
    elif name in ("deps", "missingdeps", "recompact", "restat", "cleandead"):
        return 0
    else:
        err(f"unknown tool '{name}'")
    return 0


def usage():
    return f"""usage: ninja [options] [targets...]

if targets are unspecified, builds the 'default' target (see manual).

options:
  --version      print ninja version ("{VERSION}")
  -v, --verbose  show all command lines while building
  --quiet        don't show progress status, just command output

  -C DIR   change to DIR before doing anything else
  -f FILE  specify input build file [default=build.ninja]

  -j N     run N jobs in parallel (0 means infinity) [default=6 on this system]
  -k N     keep going until N jobs fail (0 means infinity) [default=1]
  -l N     do not start new jobs if the load average is greater than N
  -n       dry run (don't run commands but act like they succeeded)

  -d MODE  enable debugging (use '-d list' to list modes)
  -t TOOL  run a subtool (use '-t list' to list subtools)
    terminates toplevel options; further flags are passed to the tool
  -w FLAG  adjust warnings (use '-w list' to list warnings)"""


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    buildfile = "build.ninja"
    chdir = None
    opts = argparse.Namespace(verbose=False, quiet=False, dry_run=False, keepdepfile=False, keeprsp=False)
    targets = []
    tool = None
    tool_args = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(usage())
            return 0
        if a == "--version":
            print(VERSION)
            return 0
        if a in ("-v", "--verbose"):
            opts.verbose = True
        elif a == "--quiet":
            opts.quiet = True
        elif a == "-n":
            opts.dry_run = True
            opts.verbose = opts.verbose or False
        elif a == "-C":
            i += 1; chdir = argv[i]
        elif a.startswith("-C") and len(a) > 2:
            chdir = a[2:]
        elif a == "-f":
            i += 1; buildfile = argv[i]
        elif a.startswith("-f") and len(a) > 2:
            buildfile = a[2:]
        elif a in ("-j", "-k", "-l"):
            i += 1
        elif a[:2] in ("-j", "-k", "-l") and len(a) > 2:
            pass
        elif a == "-d":
            i += 1
            if argv[i] == "list":
                print("""debugging modes:
  stats        print operation counts/timing info
  explain      explain what caused a command to execute
  keepdepfile  don't delete depfiles after they're read by ninja
  keeprsp      don't delete @response files on success
multiple modes can be enabled via -d FOO -d BAR""")
                return 0
            if argv[i] == "keepdepfile":
                opts.keepdepfile = True
            if argv[i] == "keeprsp":
                opts.keeprsp = True
        elif a == "-w":
            i += 1
            if argv[i] == "list":
                print("warning flags:\n  phonycycle={err,warn}  phony build statement references itself")
                return 0
        elif a == "-t":
            i += 1
            tool = argv[i] if i < len(argv) else "list"
            tool_args = argv[i + 1:]
            break
        elif a.startswith("-"):
            err(f"invalid option -- '{a}'")
        else:
            targets.append(a)
        i += 1
    if chdir:
        print(f"ninja: Entering directory `{chdir}'")
        os.chdir(chdir)
    if tool == "list":
        return run_tool("list", None, [], opts)
    man = load_manifest(buildfile)
    if tool:
        return run_tool(tool, man, tool_args, opts)
    return Runner(man, opts).build_targets(targets)


if __name__ == "__main__":
    raise SystemExit(main())
