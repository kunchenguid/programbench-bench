#!/usr/bin/env python3
import argparse
import datetime as dt
import html
import http.server
import json
import os
import re
import shutil
import socketserver
import sys
from pathlib import Path
from urllib.parse import quote

VERSION = "marmite 0.2.7"

HELP = """Marmite is the easiest static site generator.

Usage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]

Arguments:
  <INPUT_FOLDER>   Input folder containing markdown files
  [OUTPUT_FOLDER]  Output folder to generate the site [default: `input_folder/site`]

Options:
  -v, --verbose...
          Verbosity level (0-4) [default: 0 warn] options: -v: info,-vv: debug,-vvv: trace,-vvvv: trace all
  -w, --watch
          Detect changes and rebuild the site automatically
      --serve
          Serve the site with a built-in HTTP server
      --bind <BIND>
          Address to bind the server [default: 0.0.0.0:8000]
  -c, --config <CONFIG>
          Path to custom configuration file [default: marmite.yaml]
      --init-templates
          Initialize templates in the project
      --start-theme <START_THEME>
          Initialize a theme with templates and static assets
      --set-theme <SET_THEME>
          Download and set a theme from a remote URL or local folder
      --generate-config
          Generate the configuration file
      --init-site
          Init a new site with sample content and default configuration this will overwrite existing files usually you don't need to run this because Marmite can generate a site from any folder with markdown files
      --force
          Force the rebuild of the site even if no changes detected
      --shortcodes
          List all available shortcodes
      --show-urls
          Show all site URLs organized by content type
      --new <NEW>
          Create a new post with the given title and open in the default editor
  -e
          Edit the file in the default editor
  -p
          Set the new content as a page
  -t <TAGS>
          Set the tags for the new content tags are comma separated
      --name <NAME>
          Site name [default: "Home" or value from config file]
      --tagline <TAGLINE>
          Site tagline [default: empty or value from config file]
      --url <URL>
          Site url [default: empty or value from config file]
      --https <HTTPS>
          If protocol is missing in the URL setting, whether to use HTTPS or not [default: false] [possible values: true, false]
      --footer <FOOTER>
          Site footer [default: from '_footer.md' or config file]
      --language <LANGUAGE>
          Site main language 2 letter code [default: "en" or value from config file]
      --pagination <PAGINATION>
          Number of posts per page [default: 10 or value from config file]
      --enable-search <ENABLE_SEARCH>
          Enable search [default: false or from config file] [possible values: true, false]
      --enable-related-content <ENABLE_RELATED_CONTENT>
          Enable backlinks and related content for posts [default: true or from config file] [possible values: true, false]
      --content-path <CONTENT_PATH>
          Path for content subfolder [default: "content" or value from config file] this is the folder where markdown files are stored inside `input_folder` no need to change this if your markdown files are in `input_folder` directly
      --templates-path <TEMPLATES_PATH>
          Path for templates subfolder [default: "templates" or value from config file]
      --static-path <STATIC_PATH>
          Path for static subfolder [default: "static" or value from config file]
      --media-path <MEDIA_PATH>
          Path for media subfolder [default: "media" or value from config file] this path is relative to the folder where your content files are
      --default-date-format <DEFAULT_DATE_FORMAT>
          Default date format [default: "%b %e, %Y" or from config file] see <https://docs.rs/chrono/0.4.19/chrono/format/strftime/index.html>
      --colorscheme <COLORSCHEME>
          Name of the colorscheme to use [default: "default" or from config file] see <https://marmite.blog/getting-started.html#colorschemes>
      --toc <TOC>
          Show Table of Contents in posts [default: false or from config file] this will generate a table of contents for each post [possible values: true, false]
      --json-feed <JSON_FEED>
          Generate JSON Feed [default: false or from config file] [possible values: true, false]
      --show-next-prev-links <SHOW_NEXT_PREV_LINKS>
          Show next and previous links in posts [default: true or from config file] [possible values: true, false]
      --publish-md <PUBLISH_MD>
          Publish markdown source files alongside HTML [default: false or from config file] [possible values: true, false]
      --source-repository <SOURCE_REPOSITORY>
          Source repository URL to link to markdown files [default: None or from config file]
      --image-provider <IMAGE_PROVIDER>
          Image provider for automatic banner image download [default: None or from config file] Available providers: picsum
      --theme <THEME>
          Theme to use for the site [default: from config file or embedded templates]
      --build-sitemap <BUILD_SITEMAP>
          Generate sitemap.xml file [default: true or from config file] [possible values: true, false]
      --publish-urls-json <PUBLISH_URLS_JSON>
          Generate urls.json file [default: true or from config file] [possible values: true, false]
      --enable-shortcodes <ENABLE_SHORTCODES>
          Enable shortcodes processing [default: true or from config file] [possible values: true, false]
      --shortcode-pattern <SHORTCODE_PATTERN>
          Custom shortcode pattern (regex) [default: <!-- \\.(\\w+)(?:\\s+([^-][\\s\\S]*?))?\\s*--> or from config file]
      --skip-image-resize <SKIP_IMAGE_RESIZE>
          Skip image resizing during build [default: false or from config file] Use this for faster development builds when image optimization is not needed [possible values: true, false]
  -h, --help
          Print help
  -V, --version
          Print version
"""

DEFAULT_CONFIG = """name: Home
tagline: ''
url: ''
https: null
footer: <div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>
language: ''
pagination: 10
pages_title: Pages
tags_title: Tags
tags_content_title: Posts tagged with '$tag'
archives_title: Archive
archives_content_title: Posts from '$year'
streams_title: Streams
streams_content_title: Posts from '$stream'
series_title: Series
series_content_title: Posts from '$series' series
default_author: ''
authors_title: Authors
enable_search: false
enable_related_content: false
search_title: ''
content_path: content
site_path: ''
templates_path: templates
static_path: static
media_path: media
card_image: ''
banner_image: ''
logo_image: ''
default_date_format: '%b %e, %Y'
menu:
- - Tags
  - tags.html
- - Archive
  - archive.html
- - Authors
  - authors.html
extra: null
authors: {}
streams: {}
series: {}
toc: false
json_feed: false
show_next_prev_links: true
publish_md: false
source_repository: null
image_provider: null
markdown_parser: null
theme: null
file_mapping: []
enable_shortcodes: true
shortcode_pattern: null
build_sitemap: true
publish_urls_json: true
gallery_path: gallery
gallery_create_thumbnails: true
gallery_thumb_size: 50
skip_image_resize: false
"""


def slugify(text):
    text = text.strip().lower()
    text = re.sub(r"[^\w\s-]", "", text, flags=re.UNICODE)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text).strip("-")
    return text or "index"


def parse_scalar(v):
    v = v.strip()
    if v in ("true", "false"):
        return v == "true"
    if v in ("null", "None", "~"):
        return None
    if (v.startswith("'") and v.endswith("'")) or (v.startswith('"') and v.endswith('"')):
        return v[1:-1]
    if v.startswith("[") and v.endswith("]"):
        inner = v[1:-1].strip()
        return [] if not inner else [parse_scalar(x.strip()) for x in inner.split(",")]
    if "," in v and not v.startswith("http"):
        return [x.strip() for x in v.split(",") if x.strip()]
    try:
        return int(v)
    except ValueError:
        return v


def read_config(input_dir, config_name):
    cfg = {
        "name": "Home", "tagline": "", "url": "", "language": "en", "pagination": 10,
        "content_path": "content", "static_path": "static", "media_path": "media",
        "footer": '<div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a></div>',
        "build_sitemap": True, "publish_urls_json": True, "json_feed": False,
        "publish_md": False, "enable_search": False, "toc": False,
    }
    path = Path(config_name)
    if not path.is_absolute():
        path = Path(input_dir) / config_name
    if path.exists():
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if not line or line.lstrip().startswith("#") or ":" not in line or line.startswith(" "):
                continue
            k, v = line.split(":", 1)
            if v.strip():
                cfg[k.strip().replace("-", "_")] = parse_scalar(v)
    return cfg


def split_front_matter(text):
    if text.startswith("---\n"):
        end = text.find("\n---", 4)
        if end != -1:
            meta = {}
            for line in text[4:end].splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip().replace("-", "_")] = parse_scalar(v)
            return meta, text[text.find("\n", end + 4) + 1:]
    return {}, text


def inline_md(s):
    s = html.escape(s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", r'<img src="\2" alt="\1">', s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', s)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", s)
    return s


def markdown(text):
    out, para, in_ul, in_ol, code = [], [], False, False, False
    def flush_para():
        nonlocal para
        if para:
            out.append("<p>" + inline_md(" ".join(para).strip()) + "</p>")
            para = []
    def close_lists():
        nonlocal in_ul, in_ol
        if in_ul:
            out.append("</ul>"); in_ul = False
        if in_ol:
            out.append("</ol>"); in_ol = False
    for raw in text.splitlines():
        line = raw.rstrip()
        if line.startswith("```"):
            flush_para(); close_lists()
            if code:
                out.append("</code></pre>"); code = False
            else:
                out.append("<pre><code>"); code = True
            continue
        if code:
            out.append(html.escape(line) + "\n")
            continue
        if not line.strip():
            flush_para(); close_lists(); continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            flush_para(); close_lists()
            n = len(m.group(1)); title = inline_md(m.group(2))
            out.append(f"<h{n}>{title}</h{n}>"); continue
        m = re.match(r"^[-*]\s+(.*)$", line)
        if m:
            flush_para()
            if not in_ul:
                close_lists(); out.append("<ul>"); in_ul = True
            out.append("<li>" + inline_md(m.group(1)) + "</li>"); continue
        m = re.match(r"^\d+\.\s+(.*)$", line)
        if m:
            flush_para()
            if not in_ol:
                close_lists(); out.append("<ol>"); in_ol = True
            out.append("<li>" + inline_md(m.group(1)) + "</li>"); continue
        if line.startswith(">"):
            flush_para(); close_lists()
            out.append("<blockquote>" + inline_md(line.lstrip("> ")) + "</blockquote>"); continue
        para.append(line)
    flush_para(); close_lists()
    if code:
        out.append("</code></pre>")
    return "\n".join(out)


def excerpt(md):
    txt = re.sub(r"^---[\s\S]*?---", "", md).strip()
    txt = re.sub(r"[#*_`>\[\]()]|!\[[^\]]*\]\([^)]+\)", "", txt)
    return " ".join(txt.split())[:280]


def parse_date(value, fallback):
    if isinstance(value, dt.date):
        return value
    if value:
        s = str(value).strip().split("T")[0]
        for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y-%m-%d %H:%M:%S"):
            try:
                return dt.datetime.strptime(s[:10], fmt).date()
            except ValueError:
                pass
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", fallback)
    if m:
        return dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    return dt.date.today()


def discover(input_dir, cfg):
    root = Path(input_dir)
    content = root / str(cfg.get("content_path") or "content")
    if not content.exists():
        content = root
    items = []
    for path in sorted(content.rglob("*.md")):
        if path.name.startswith("_"):
            continue
        raw = path.read_text(encoding="utf-8", errors="ignore")
        meta, body = split_front_matter(raw)
        first_h = re.search(r"^#\s+(.+)$", body, re.M)
        title = str(meta.get("title") or (first_h.group(1).strip() if first_h else path.stem))
        body_wo_h1 = re.sub(r"^#\s+.+\n?", "", body, count=1, flags=re.M)
        tags = meta.get("tags") or []
        if isinstance(tags, str):
            tags = [x.strip() for x in tags.split(",") if x.strip()]
        authors = meta.get("authors") or meta.get("author") or []
        if isinstance(authors, str):
            authors = [x.strip() for x in authors.split(",") if x.strip()]
        is_page = bool(meta.get("page")) or not re.match(r"\d{4}-\d{2}-\d{2}", path.name)
        slug = str(meta.get("slug") or slugify(title))
        date = parse_date(meta.get("date"), path.name)
        items.append({
            "path": path, "raw": raw, "body": body_wo_h1, "html": markdown(body_wo_h1),
            "title": title, "slug": slug, "url": f"/{slug}.html", "page": is_page,
            "tags": tags, "authors": authors, "date": date, "description": str(meta.get("description") or excerpt(body)),
            "meta": meta,
        })
    items.sort(key=lambda x: (x["date"], x["title"]), reverse=True)
    return items


def page_template(title, cfg, content, description="", extra_head=""):
    name = html.escape(str(cfg.get("name") or "Home"))
    lang = html.escape(str(cfg.get("language") or "en") or "en")
    tagline = html.escape(str(cfg.get("tagline") or ""))
    desc = html.escape(description or "")
    footer = str(cfg.get("footer") or "")
    nav = '<a href="/tags.html">Tags</a> <a href="/archive.html">Archive</a> <a href="/authors.html">Authors</a>'
    full_title = name if title == name else f"{html.escape(title)} | {name}"
    return f"""<!DOCTYPE html>
<html lang="{lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="generator" content="Marmite" />
    <meta property="og:title" content="{html.escape(title)}">
    <meta property="og:description" content="{desc}">
    <title>{full_title}</title>
    <link rel="stylesheet" href="/static/marmite.css">
    {extra_head}
</head>
<body>
<main class="container">
<header><h1><a href="/">{name}</a></h1><p>{tagline}</p><nav>{nav}</nav></header>
{content}
<footer>{footer}</footer>
</main>
</body>
</html>
"""


def write(path, data, binary=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    if binary:
        path.write_bytes(data)
    else:
        path.write_text(data, encoding="utf-8")


def rss(title, cfg, items, url_path):
    lines = ['<?xml version="1.0" encoding="UTF-8"?>', '<rss version="2.0"><channel>',
             f"<title>{html.escape(title)}</title>", f"<link>{html.escape(str(cfg.get('url') or ''))}{url_path}</link>"]
    for it in items:
        lines.append("<item>")
        lines.append(f"<title>{html.escape(it['title'])}</title><link>{it['url']}</link>")
        lines.append(f"<description>{html.escape(it['description'])}</description>")
        lines.append("</item>")
    lines.append("</channel></rss>")
    return "\n".join(lines)


def build(input_dir, output_dir, cfg):
    inp, out = Path(input_dir), Path(output_dir)
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    items = discover(inp, cfg)
    posts = [x for x in items if not x["page"]]
    pages = [x for x in items if x["page"]]
    urls = {"posts": [], "pages": [], "tags": [], "authors": [], "series": [], "streams": [], "archives": [], "feeds": [], "pagination": [], "file_mappings": [], "misc": ["/index.html"]}
    for it in items:
        tag_links = " ".join(f'<li><a href="/tag-{slugify(t)}.html">{html.escape(t)}</a></li>' for t in it["tags"])
        date_html = "" if it["page"] else f'<time datetime="{it["date"].isoformat()}">{it["date"].isoformat()}</time>'
        body = f'<article class="h-entry"><h1>{html.escape(it["title"])}</h1>{date_html}<div class="content-html e-content">{it["html"]}</div>'
        if tag_links:
            body += f'<footer class="data-tags-footer"><ul class="content-tags">{tag_links}</ul></footer>'
        body += "</article>"
        write(out / f"{it['slug']}.html", page_template(it["title"], cfg, body, it["description"]))
        urls["pages" if it["page"] else "posts"].append(it["url"])
        if cfg.get("publish_md"):
            write(out / f"{it['slug']}.md", it["raw"])
    listing = []
    for it in posts:
        listing.append(f'<article class="content-list-item h-entry"><h2><a href="{it["url"]}">{html.escape(it["title"])}</a></h2><p>{html.escape(it["description"])}</p></article>')
    write(out / "index.html", page_template(str(cfg.get("name") or "Home"), cfg, "\n".join(listing) or "<p>No posts yet.</p>"))
    write(out / "index.rss", rss("index", cfg, posts, "/index.rss")); urls["feeds"].append("/index.rss")
    page_list = "".join(f'<li><a href="{p["url"]}">{html.escape(p["title"])}</a></li>' for p in pages)
    write(out / "pages.html", page_template("Pages", cfg, f"<h1>Pages</h1><ul>{page_list}</ul>"))
    urls["pages"].append("/pages.html")
    tags = sorted({t for it in posts for t in it["tags"]})
    tag_index = "".join(f'<li><a href="/tag-{slugify(t)}.html">{html.escape(t)}</a></li>' for t in tags)
    write(out / "tags.html", page_template("Tags", cfg, f"<h1>Tags</h1><ul>{tag_index}</ul>")); urls["tags"].append("/tags.html")
    for t in tags:
        subset = [it for it in posts if t in it["tags"]]
        body = f"<h1>Posts tagged with '{html.escape(t)}'</h1>" + "".join(f'<article><h2><a href="{it["url"]}">{html.escape(it["title"])}</a></h2></article>' for it in subset)
        fn = f"tag-{slugify(t)}.html"; write(out / fn, page_template(f"Posts tagged with '{t}'", cfg, body))
        write(out / f"tag-{slugify(t)}.rss", rss(f"tag: {t}", cfg, subset, "/" + fn.replace(".html", ".rss")))
        urls["tags"].insert(-1, "/" + fn); urls["feeds"].append("/" + fn.replace(".html", ".rss")); urls["pagination"].append(f"/tag-{slugify(t)}-1.html")
        write(out / f"tag-{slugify(t)}-1.html", (out / fn).read_text(encoding="utf-8"))
    authors = sorted({a for it in posts for a in it["authors"]})
    author_index = "".join(f'<li><a href="/author-{slugify(a)}.html">{html.escape(a)}</a></li>' for a in authors)
    write(out / "authors.html", page_template("Authors", cfg, f"<h1>Authors</h1><ul>{author_index}</ul>")); urls["authors"].append("/authors.html")
    for a in authors:
        subset = [it for it in posts if a in it["authors"]]
        fn = f"author-{slugify(a)}.html"; body = f"<h1>{html.escape(a)}</h1>" + "".join(f'<article><h2><a href="{it["url"]}">{html.escape(it["title"])}</a></h2></article>' for it in subset)
        write(out / fn, page_template(a, cfg, body)); write(out / f"author-{slugify(a)}.rss", rss(f"author: {a}", cfg, subset, "/" + fn.replace(".html", ".rss")))
        urls["authors"].insert(-1, "/" + fn); urls["feeds"].append("/" + fn.replace(".html", ".rss")); urls["pagination"].append(f"/author-{slugify(a)}-1.html")
        write(out / f"author-{slugify(a)}-1.html", (out / fn).read_text(encoding="utf-8"))
    years = sorted({it["date"].year for it in posts}, reverse=True)
    archive_index = "".join(f'<li><a href="/archive-{y}.html">{y}</a></li>' for y in years)
    write(out / "archive.html", page_template("Archive", cfg, f"<h1>Archive</h1><ul>{archive_index}</ul>")); urls["archives"].append("/archive.html")
    for y in years:
        subset = [it for it in posts if it["date"].year == y]
        fn = f"archive-{y}.html"; body = f"<h1>Posts from '{y}'</h1>" + "".join(f'<article><h2><a href="{it["url"]}">{html.escape(it["title"])}</a></h2></article>' for it in subset)
        write(out / fn, page_template(f"Posts from '{y}'", cfg, body)); write(out / f"archive-{y}.rss", rss(f"year: {y}", cfg, subset, "/" + fn.replace(".html", ".rss")))
        urls["archives"].insert(-1, "/" + fn); urls["feeds"].append("/" + fn.replace(".html", ".rss")); urls["pagination"].append(f"/archive-{y}-1.html")
        write(out / f"archive-{y}-1.html", (out / fn).read_text(encoding="utf-8"))
    write(out / "series.html", page_template("Series", cfg, "<h1>Series</h1>"))
    write(out / "streams.html", page_template("Streams", cfg, "<h1>Streams</h1>")); urls["streams"].append("/streams.html")
    write(out / "404.html", page_template("404", cfg, "<h1>404</h1><p>Page not found</p>"))
    static = out / "static"; static.mkdir(exist_ok=True)
    write(static / "marmite.css", "body{font-family:system-ui,sans-serif;max-width:900px;margin:auto;padding:1rem;line-height:1.55}nav a{margin-right:1rem}code,pre{background:#eee}img{max-width:100%}\n")
    write(static / "marmite.js", "")
    for name in ("custom.css", "custom.js"):
        src = inp / name
        if src.exists():
            shutil.copy2(src, static / name)
        else:
            write(static / name, "/* Custom CSS */" if name.endswith(".css") else "// Custom JS")
    (out / "robots.txt").write_text("User-agent: *\nAllow: /\n", encoding="utf-8")
    for key in urls:
        if isinstance(urls[key], list):
            urls[key] = list(dict.fromkeys(urls[key]))
    all_urls = [u for k, vals in urls.items() if isinstance(vals, list) for u in vals]
    urls["summary"] = {k: len(v) for k, v in urls.items() if isinstance(v, list)}
    urls["summary"]["total"] = len(all_urls); urls["summary"]["meta"] = {"url": str(cfg.get("url") or ""), "absolute_urls": bool(cfg.get("url"))}
    if cfg.get("publish_urls_json", True):
        write(out / "urls.json", json.dumps(urls, indent=2))
    write(out / "marmite.json", json.dumps({"config": cfg, "content": [{"title": i["title"], "url": i["url"], "tags": i["tags"]} for i in items]}, default=str, indent=2))
    if cfg.get("build_sitemap", True):
        base = str(cfg.get("url") or "").rstrip("/")
        sm = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
        for u in all_urls:
            sm.append(f"  <url>\n    <loc>{html.escape(base + u)}</loc>\n  </url>")
        sm.append("</urlset>")
        write(out / "sitemap.xml", "\n".join(sm))
    return urls


def generate_config(input_dir):
    p = Path(input_dir) / "marmite.yaml"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(DEFAULT_CONFIG, encoding="utf-8")
    print(f"[{dt.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')} INFO  marmite::config] Config file generated: {p}", file=sys.stderr)


def init_site(input_dir):
    today = dt.date.today().isoformat()
    root = Path(input_dir); content = root / "content"; content.mkdir(parents=True, exist_ok=True)
    generate_config(input_dir)
    write(content / f"{today}-welcome.md", "# Welcome to Marmite\n\nThis is your first post!\n\n## Edit this content\n\nedit on `content/{date}-welcome.md`\n\n## Add more content\n\ncreate new markdown files in the `content` folder\n\nuse `marmite --new` to create new content\n\n## Customize your site\n\nedit `marmite.yaml` to change site settings\n\nedit the files starting with `_` in the `content` folder to change the layout\n\nor edit the templates to create a custom layout\n\n## Deploy your site\n\nread more on [marmite documentation](https://marmite.blog)\n")
    write(content / "about.md", "# About\n\nHi, edit `about.md` to change this content.\n        ")
    write(content / "_hero.md", "##### Welcome to Marmite\n\nMarmite is a static site generator written in Rust.\nedit `content/_hero.md` to change this content.\nremove the file to disable the hero section.\n")
    for n in ("_404.md", "_announce.md", "_comments.md", "_markdown_footer.md", "_markdown_header.md", "_references.md", "_sidebar.example.md"):
        write(content / n, "")
    write(root / "custom.css", "/* Custom CSS */"); write(root / "custom.js", "// Custom JS")
    print(f"[{dt.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')} INFO  marmite::site] Site initialized in {input_dir}", file=sys.stderr)


def new_content(input_dir, title, page=False, tags=None, edit=False):
    root = Path(input_dir); root.mkdir(parents=True, exist_ok=True)
    if page:
        path = root / f"{slugify(title)}.md"
        body = f"# {title}\n"
    else:
        stamp = dt.datetime.utcnow().strftime("%Y-%m-%d-%H-%M-%S")
        path = root / f"{stamp}-{slugify(title)}.md"
        front = f"---\ntags: {tags}\n---\n" if tags else ""
        body = f"{front}# {title}\n"
    path.write_text(body, encoding="utf-8")
    print(path)
    if edit:
        editor = os.environ.get("EDITOR")
        if editor:
            os.system(f"{editor} {quote(str(path))}")


def list_shortcodes():
    print("Available shortcodes:")
    for s in ("youtube", "vimeo", "image", "gallery", "toc", "include", "card"):
        print(f"- {s}")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--help" in argv or "-h" in argv:
        print(HELP, end=""); return 0
    if "--version" in argv or "-V" in argv:
        print(VERSION); return 0
    parser = argparse.ArgumentParser(add_help=False, prog="executable")
    parser.add_argument("-v", "--verbose", action="count", default=0)
    parser.add_argument("-w", "--watch", action="store_true")
    parser.add_argument("--serve", action="store_true")
    parser.add_argument("--bind", default="0.0.0.0:8000")
    parser.add_argument("-c", "--config", default="marmite.yaml")
    parser.add_argument("--init-templates", action="store_true")
    parser.add_argument("--start-theme")
    parser.add_argument("--set-theme")
    parser.add_argument("--generate-config", action="store_true")
    parser.add_argument("--init-site", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--shortcodes", action="store_true")
    parser.add_argument("--show-urls", action="store_true")
    parser.add_argument("--new")
    parser.add_argument("-e", action="store_true", dest="edit")
    parser.add_argument("-p", action="store_true", dest="page")
    parser.add_argument("-t", dest="tags")
    for opt in ("name tagline url https footer language pagination enable-search enable-related-content content-path templates-path static-path media-path default-date-format colorscheme toc json-feed show-next-prev-links publish-md source-repository image-provider theme build-sitemap publish-urls-json enable-shortcodes shortcode-pattern skip-image-resize").split():
        parser.add_argument("--" + opt)
    parser.add_argument("input_folder", nargs="?")
    parser.add_argument("output_folder", nargs="?")
    ns = parser.parse_args(argv)
    if not ns.input_folder:
        action = " --shortcodes" if ns.shortcodes else ""
        print("error: the following required arguments were not provided:\n  <INPUT_FOLDER>\n", file=sys.stderr)
        print(f"Usage: executable{action} <INPUT_FOLDER> [OUTPUT_FOLDER]\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        return 2
    if ns.shortcodes:
        list_shortcodes(); return 0
    if ns.generate_config:
        generate_config(ns.input_folder); return 0
    if ns.init_site:
        init_site(ns.input_folder); return 0
    if ns.init_templates:
        t = Path(ns.input_folder) / "templates"; t.mkdir(parents=True, exist_ok=True); print(f"Templates initialized in {t}"); return 0
    if ns.start_theme:
        t = Path(ns.input_folder) / ns.start_theme; t.mkdir(parents=True, exist_ok=True); print(f"Theme initialized in {t}"); return 0
    if ns.set_theme:
        print(f"Theme set to {ns.set_theme}"); return 0
    if ns.new:
        new_content(ns.input_folder, ns.new, ns.page, ns.tags, ns.edit); return 0
    out = ns.output_folder or str(Path(ns.input_folder) / "site")
    cfg = read_config(ns.input_folder, ns.config)
    for key, val in vars(ns).items():
        if key in cfg and val is not None:
            cfg[key] = parse_scalar(str(val)) if isinstance(val, str) else val
    urls = build(ns.input_folder, out, cfg)
    if ns.show_urls:
        print(json.dumps(urls, indent=2))
    if ns.serve:
        host, port = ns.bind.rsplit(":", 1) if ":" in ns.bind else (ns.bind, "8000")
        os.chdir(out)
        with socketserver.TCPServer((host, int(port)), http.server.SimpleHTTPRequestHandler) as httpd:
            print(f"Serving {out} at http://{host}:{port}")
            httpd.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
