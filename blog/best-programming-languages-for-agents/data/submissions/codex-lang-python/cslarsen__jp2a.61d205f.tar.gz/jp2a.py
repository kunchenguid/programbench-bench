#!/usr/bin/env python3
import html as htmlmod
import math
import os
import shutil
import sys
import tempfile
import urllib.request
from dataclasses import dataclass
from io import BytesIO

try:
    from PIL import Image
except Exception as exc:
    sys.stderr.write(f"jp2a: could not import Pillow: {exc}\n")
    sys.exit(1)


VERSION = """jp2a 1.0.8
Copyright 2006-2016 Christian Stigen Larsen
Distributed under the GNU General Public License (GPL) v2.
"""

HELP = VERSION + """
Usage: jp2a [ options ] [ file(s) | URL(s) ]

Convert files or URLs from JPEG format to ASCII.

OPTIONS
  -                 Read images from standard input.
      --blue=N.N    Set RGB to grayscale conversion weight, default is 0.1145
  -b, --border      Print a border around the output image.
      --chars=...   Select character palette used to paint the image.
                    Leftmost character corresponds to black pixel, right-
                    most to white.  Minimum two characters must be specified.
      --clear       Clears screen before drawing each output image.
      --colors      Use ANSI colors in output.
  -d, --debug       Print additional debug information.
      --fill        When used with --color and/or --html, color each character's
                    background color.
  -x, --flipx       Flip image in X direction.
  -y, --flipy       Flip image in Y direction.
  -f, --term-fit    Use the largest image dimension that fits in your terminal
                    display with correct aspect ratio.
      --term-height Use terminal display height.
      --term-width  Use terminal display width.
  -z, --term-zoom   Use terminal display dimension for output.
      --grayscale   Convert image to grayscale when using --html or --colors
      --green=N.N   Set RGB to grayscale conversion weight, default is 0.5866
      --height=N    Set output height, calculate width from aspect ratio.
  -h, --help        Print program help.
      --html        Produce strict XHTML 1.0 output.
      --html-fill   Same as --fill (will be phased out)
      --html-fontsize=N   Set fontsize to N pt, default is 4.
      --html-no-bold      Do not use bold characters with HTML output
      --html-raw    Output raw HTML codes, i.e. without the <head> section etc.
      --html-title=...  Set HTML output title
  -i, --invert      Invert output image.  Use if your display has a dark
                    background.
      --background=dark   These are just mnemonics whether to use --invert
      --background=light  or not.  If your console has light characters on
                    a dark background, use --background=dark.
      --output=...  Write output to file.
      --red=N.N     Set RGB to grayscale conversion weight, default 0.2989f.
      --size=WxH    Set output width and height.
  -v, --verbose     Verbose output.
  -V, --version     Print program version.
      --width=N     Set output width, calculate height from ratio.

  The default mode is `jp2a --term-fit --background=dark'.
  See the man-page for jp2a for more detailed help text.

Project homepage on https://github.com/cslarsen/jp2a
Report bugs to <csl@csl.name>
"""


@dataclass
class Opts:
    width: int | None = None
    height: int | None = None
    size_set: bool = False
    chars: str = "   ...',;:clodxkO0KXNWM"
    invert: bool = False
    border: bool = False
    colors: bool = False
    fill: bool = False
    flipx: bool = False
    flipy: bool = False
    html: bool = False
    html_raw: bool = False
    html_no_bold: bool = False
    html_fontsize: int = 4
    html_title: str = "jp2a converted image"
    grayscale: bool = False
    clear: bool = False
    verbose: bool = False
    debug: bool = False
    output: str | None = None
    term_fit: bool = True
    term_width: bool = False
    term_height: bool = False
    term_zoom: bool = False
    red: float = 0.2989
    green: float = 0.5866
    blue: float = 0.1145


def die(msg: str, code: int = 1) -> int:
    sys.stderr.write(msg + "\n")
    return code


def parse_num(s: str) -> int:
    try:
        n = int(s)
    except Exception:
        raise ValueError
    if n <= 0:
        raise ValueError
    return n


def parse_args(argv: list[str]):
    opts = Opts()
    files: list[str] = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "-":
            files.append(a)
        elif a in ("-h", "--help"):
            sys.stdout.write(HELP)
            sys.exit(0)
        elif a in ("-V", "--version"):
            sys.stdout.write(VERSION)
            sys.exit(0)
        elif a in ("-b", "--border"):
            opts.border = True
        elif a in ("-i", "--invert"):
            opts.invert = True
        elif a in ("-x", "--flipx"):
            opts.flipx = True
        elif a in ("-y", "--flipy"):
            opts.flipy = True
        elif a in ("-f", "--term-fit"):
            opts.term_fit = True
        elif a in ("-z", "--term-zoom", "--zoom"):
            opts.term_zoom = True
            opts.term_fit = False
        elif a in ("-v", "--verbose"):
            opts.verbose = True
        elif a in ("-d", "--debug"):
            opts.debug = True
        elif a == "--clear":
            opts.clear = True
        elif a in ("--colors", "--color"):
            opts.colors = True
        elif a in ("--fill", "--html-fill"):
            opts.fill = True
        elif a == "--grayscale":
            opts.grayscale = True
        elif a == "--html":
            opts.html = True
        elif a == "--html-raw":
            opts.html = True
            opts.html_raw = True
        elif a == "--html-no-bold":
            opts.html_no_bold = True
        elif a == "--term-width":
            opts.term_width = True
            opts.term_fit = False
        elif a == "--term-height":
            opts.term_height = True
            opts.term_fit = False
        elif a.startswith("--size="):
            val = a.split("=", 1)[1]
            if "x" not in val:
                return None, None, die(f"Invalid size {val}")
            w, h = val.lower().split("x", 1)
            try:
                opts.width, opts.height = parse_num(w), parse_num(h)
            except ValueError:
                return None, None, die(f"Invalid size {val}")
            opts.size_set = True
            opts.term_fit = False
        elif a.startswith("--width="):
            try:
                opts.width = parse_num(a.split("=", 1)[1])
            except ValueError:
                return None, None, die(f"Invalid width {a.split('=',1)[1]}")
            opts.term_fit = False
        elif a.startswith("--height="):
            try:
                opts.height = parse_num(a.split("=", 1)[1])
            except ValueError:
                return None, None, die(f"Invalid height {a.split('=',1)[1]}")
            opts.term_fit = False
        elif a.startswith("--chars="):
            opts.chars = a.split("=", 1)[1]
            if len(opts.chars) < 2:
                return None, None, die("Minimum two characters must be specified")
        elif a.startswith("--background="):
            bg = a.split("=", 1)[1]
            if bg == "light":
                opts.invert = True
            elif bg == "dark":
                opts.invert = False
            else:
                return None, None, die(f"Invalid background {bg}")
        elif a.startswith("--output="):
            opts.output = a.split("=", 1)[1]
        elif a.startswith("--html-fontsize="):
            try:
                opts.html_fontsize = parse_num(a.split("=", 1)[1])
            except ValueError:
                return None, None, die("Invalid fontsize")
        elif a.startswith("--html-title="):
            opts.html_title = a.split("=", 1)[1]
        elif a.startswith("--red="):
            opts.red = float(a.split("=", 1)[1])
        elif a.startswith("--green="):
            opts.green = float(a.split("=", 1)[1])
        elif a.startswith("--blue="):
            opts.blue = float(a.split("=", 1)[1])
        elif a.startswith("-") and len(a) > 2 and not a.startswith("--"):
            for ch in a[1:]:
                if ch == "b": opts.border = True
                elif ch == "i": opts.invert = True
                elif ch == "x": opts.flipx = True
                elif ch == "y": opts.flipy = True
                elif ch == "f": opts.term_fit = True
                elif ch == "z": opts.term_zoom = True; opts.term_fit = False
                elif ch == "v": opts.verbose = True
                elif ch == "d": opts.debug = True
                elif ch == "h": sys.stdout.write(HELP); sys.exit(0)
                elif ch == "V": sys.stdout.write(VERSION); sys.exit(0)
                else:
                    return None, None, unknown("-" + ch)
        elif a.startswith("-"):
            return None, None, unknown(a)
        else:
            files.append(a)
        i += 1
    return opts, files, 0


def unknown(a: str) -> int:
    sys.stderr.write(f"Unknown option {a}\n\n")
    sys.stderr.write(HELP)
    return 1


def terminal_size():
    if "TERM" not in os.environ:
        raise OSError("Environment variable TERM not set.")
    sz = shutil.get_terminal_size((80, 25))
    return sz.columns, sz.lines


def output_dims(opts: Opts, sw: int, sh: int):
    if opts.term_zoom:
        tw, th = terminal_size()
        return max(1, tw), max(1, th)
    if opts.term_width:
        tw, _ = terminal_size()
        return max(1, tw), max(1, int(tw * sh / sw / 2.0))
    if opts.term_height:
        _, th = terminal_size()
        return max(1, int(th * sw / sh * 2.0)), max(1, th)
    if opts.width and opts.height:
        return opts.width, opts.height
    if opts.width:
        return opts.width, max(1, int(opts.width * sh / sw / 2.0))
    if opts.height:
        return max(1, int(opts.height * sw / sh * 2.0)), opts.height
    tw, th = terminal_size()
    by_w_h = int(tw * sh / sw / 2.0)
    if by_w_h <= th:
        return max(1, tw), max(1, by_w_h)
    return max(1, int(th * sw / sh * 2.0)), max(1, th)


def read_image(name: str):
    if name == "-":
        data = sys.stdin.buffer.read()
        return Image.open(BytesIO(data)).convert("RGB")
    if "://" in name:
        with urllib.request.urlopen(name, timeout=20) as r:
            return Image.open(BytesIO(r.read())).convert("RGB")
    return Image.open(name).convert("RGB")


def ansi_code(r, g, b):
    vals = [
        (0, 0, 0), (170, 0, 0), (0, 170, 0), (170, 85, 0),
        (0, 0, 170), (170, 0, 170), (0, 170, 170), (170, 170, 170),
    ]
    idx = min(range(8), key=lambda i: (r - vals[i][0]) ** 2 + (g - vals[i][1]) ** 2 + (b - vals[i][2]) ** 2)
    return 30 + idx


def convert_one(img: Image.Image, opts: Opts):
    sw, sh = img.size
    ow, oh = output_dims(opts, sw, sh)
    # libjpeg's scaled decode effectively averages source blocks for many of
    # jp2a's common down-sampling cases. BOX is the closest Pillow primitive.
    img = img.resize((ow, oh), Image.Resampling.BOX)
    if opts.flipx:
        img = img.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    if opts.flipy:
        img = img.transpose(Image.Transpose.FLIP_TOP_BOTTOM)

    pix = img.load()
    lines = []
    meta = []
    n = len(opts.chars)
    for y in range(oh):
        line = []
        metaline = []
        for x in range(ow):
            r, g, b = pix[x, y]
            lum = opts.red * r + opts.green * g + opts.blue * b
            if opts.invert:
                lum = 255 - lum
            idx = int(lum * n / 256.0)
            if idx < 0: idx = 0
            if idx >= n: idx = n - 1
            ch = opts.chars[idx]
            line.append(ch)
            if opts.grayscale:
                gv = max(0, min(255, int(lum + 0.5)))
                metaline.append((gv, gv, gv, ch))
            else:
                metaline.append((r, g, b, ch))
        lines.append("".join(line))
        meta.append(metaline)
    if opts.border:
        border = "+" + "-" * ow + "+"
        lines = [border] + ["|" + l + "|" for l in lines] + [border]
    return lines, meta


def render_text(lines, meta, opts: Opts):
    if not opts.colors:
        return "\n".join(lines) + "\n"
    out = []
    for y, line in enumerate(lines):
        if opts.border and (y == 0 or y == len(lines) - 1):
            out.append(line)
            continue
        body = line
        source_y = y - 1 if opts.border else y
        s = []
        for x, ch in enumerate(body):
            if opts.border and (x == 0 or x == len(body) - 1):
                s.append(ch)
                continue
            source_x = x - 1 if opts.border else x
            r, g, b, _ = meta[source_y][source_x]
            s.append(f"\033[{ansi_code(r,g,b)}m{ch}\033[0m")
        out.append("".join(s))
    return "\n".join(out) + "\n"


def render_html(lines, meta, opts: Opts):
    body_lines = []
    if opts.border:
        # The original applies plain borders in HTML too.
        body_lines.append(htmlmod.escape(lines[0]))
        visible = lines[1:-1]
    else:
        visible = lines
    for y, line in enumerate(visible):
        if not opts.colors:
            body_lines.append(htmlmod.escape(line))
            continue
        s = []
        for x, ch in enumerate(line):
            if opts.border and (x == 0 or x == len(line) - 1):
                s.append(htmlmod.escape(ch))
                continue
            sx = x - 1 if opts.border else x
            r, g, b, realch = meta[y][sx]
            txt = "&nbsp;" if realch == " " else htmlmod.escape(realch)
            if opts.fill:
                style = f"color:#{r:02x}{g:02x}{b:02x};background-color:#{r:02x}{g:02x}{b:02x};"
            else:
                style = f"color:#{r:02x}{g:02x}{b:02x};"
            s.append(f"<span style='{style}'>{txt}</span>")
        body_lines.append("".join(s) + "<br/>")
    if opts.border:
        body_lines.append(htmlmod.escape(lines[-1]))
    content = "\n".join(body_lines) + "\n"
    if opts.html_raw:
        return content
    bg = "white" if opts.invert else "black"
    fg = "black" if opts.invert else "white"
    color_line = "" if opts.colors else f"   color: {fg};\n"
    weight = "" if opts.html_no_bold else "   font-weight: bold;\n"
    return (
        "<?xml version='1.0' encoding='ISO-8859-1'?>\n"
        "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'  'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>\n"
        "<html xmlns='http://www.w3.org/1999/xhtml' lang='en' xml:lang='en'>\n"
        "<head>\n"
        f"<title>{htmlmod.escape(opts.html_title)}</title>\n"
        "<style type='text/css'>\n"
        "body {\n"
        f"background-color: {bg};\n"
        "}\n"
        ".ascii {\n"
        "   font-family: Courier;\n"
        f"{color_line}"
        f"   font-size:{opts.html_fontsize * 2}pt;\n"
        f"{weight}"
        "}\n"
        "</style>\n"
        "</head>\n"
        "<body>\n"
        "<div class='ascii'><pre>\n"
        f"{content}</pre>\n"
        "</div>\n"
        "</body>\n"
        "</html>\n"
    )


def main(argv: list[str]) -> int:
    parsed = parse_args(argv)
    if parsed[0] is None:
        return parsed[2]
    opts, files, _ = parsed
    if not files:
        return die("No files specified.")

    chunks = []
    ok = True
    for f in files:
        try:
            if opts.clear:
                chunks.append("\033[H\033[2J")
            if opts.verbose:
                sys.stderr.write(f"Reading {f}\n")
            img = read_image(f)
            lines, meta = convert_one(img, opts)
            chunks.append(render_html(lines, meta, opts) if opts.html else render_text(lines, meta, opts))
        except Exception as exc:
            sys.stderr.write(f"{f}: {exc}\n")
            ok = False
    result = "".join(chunks)
    if opts.output and opts.output != "-":
        with open(opts.output, "w", encoding="latin-1") as fh:
            fh.write(result)
    else:
        sys.stdout.write(result)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
