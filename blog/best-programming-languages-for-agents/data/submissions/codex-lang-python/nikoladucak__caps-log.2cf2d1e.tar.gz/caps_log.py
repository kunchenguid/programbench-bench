#!/usr/bin/env python3
import calendar
import datetime as _dt
import fnmatch
import hashlib
import os
import re
import sys
from pathlib import Path


VERSION = "commit-93cc85d16ab60ba8d646458fe0233778317b22a3"
DEFAULT_CONFIG = "/home/agent/.caps-log/config.ini"
DEFAULT_LOG_DIR = "/home/agent/.caps-log/day/"
DEFAULT_LOG_FORMAT = "d%y_%m_%d.md"

HELP = f"""Captain's Log (caps-log)! A CLI journalig tool.
Version: {VERSION}
Allowed options:
  -h [ --help ]         show this message
  -c [ --config ] arg   override the default config file path 
                        ({DEFAULT_CONFIG})
  --log-dir-path arg    path where log files are stored
  --log-name-format arg format in which log entry markdown files are saved
  --sunday-start        have the calendar display sunday as first day of the 
                        week
  --first-line-section  override the default behaviour of ignoring sections 
                        (lines starting with `#`) in the first line of a log 
                        entry file
  --password arg        password for encrypted log repositories or to be used 
                        with --encrypt/--decrypt
  --encrypt             apply encryption to all logs in log dir path (needs 
                        --password)
  --decrypt             apply decryption to all logs in log dir path (needs 
                        --password)
"""


class CapsError(Exception):
    pass


def error(message: str) -> int:
    print("Captain's log encountered an error: ")
    print(f" {message}")
    return 1


def parse_argv(argv):
    opts = {
        "config": DEFAULT_CONFIG,
        "log_dir_path": None,
        "log_name_format": None,
        "sunday_start": False,
        "first_line_section": False,
        "password": None,
        "encrypt": False,
        "decrypt": False,
        "help": False,
    }
    takes_arg = {
        "-c": ("config", "--config"),
        "--config": ("config", "--config"),
        "--log-dir-path": ("log_dir_path", "--log-dir-path"),
        "--log-name-format": ("log_name_format", "--log-name-format"),
        "--password": ("password", "--password"),
    }
    flags = {
        "-h": "help",
        "--help": "help",
        "--sunday-start": "sunday_start",
        "--first-line-section": "first_line_section",
        "--encrypt": "encrypt",
        "--decrypt": "decrypt",
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in flags:
            opts[flags[arg]] = True
            i += 1
        elif arg in takes_arg:
            key, long_name = takes_arg[arg]
            if i + 1 >= len(argv) or argv[i + 1].startswith("-"):
                raise CapsError(f"the required argument for option '{long_name}' is missing")
            opts[key] = argv[i + 1]
            i += 2
        elif arg.startswith("--"):
            raise CapsError(f"unrecognised option '{arg}'")
        elif arg.startswith("-"):
            raise CapsError(f"unrecognised option '{arg}'")
        else:
            raise CapsError(f"unrecognised option '{arg}'")
    return opts


def strip_inline_comment(value: str) -> str:
    if " #" in value:
        value = value.split(" #", 1)[0]
    return value.strip()


def read_config(path: str):
    cfg = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or line.startswith("["):
                    continue
                if "=" not in line:
                    continue
                key, value = line.split("=", 1)
                cfg[key.strip()] = strip_inline_comment(value)
    except OSError:
        raise CapsError(f"Failed to open file: {path}")
    return cfg


def truthy(value):
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def merge_config(opts, cfg):
    out = dict(opts)
    if out["log_dir_path"] is None:
        out["log_dir_path"] = cfg.get("log-dir-path", DEFAULT_LOG_DIR)
    if out["log_name_format"] is None:
        out["log_name_format"] = cfg.get("log-name-format", cfg.get("log-filename-format", DEFAULT_LOG_FORMAT))
    if not out["sunday_start"] and "sunday-start" in cfg:
        out["sunday_start"] = truthy(cfg["sunday-start"])
    if not out["first_line_section"] and "first-line-section" in cfg:
        out["first_line_section"] = truthy(cfg["first-line-section"])
    if out["password"] is None and "password" in cfg:
        out["password"] = cfg["password"]
    return out


def format_to_glob(fmt: str) -> str:
    mapping = {
        "%y": "[0-9][0-9]",
        "%Y": "[0-9][0-9][0-9][0-9]",
        "%m": "[0-9][0-9]",
        "%d": "[0-9][0-9]",
    }
    result = ""
    i = 0
    while i < len(fmt):
        part = fmt[i : i + 2]
        if part in mapping:
            result += mapping[part]
            i += 2
        else:
            result += fmt[i]
            i += 1
    return result


def derive_stream(password: str, n: int) -> bytes:
    seed = hashlib.sha256(password.encode("utf-8")).digest()
    out = bytearray()
    counter = 0
    while len(out) < n:
        out.extend(hashlib.sha256(seed + counter.to_bytes(4, "big")).digest())
        counter += 1
    return bytes(out[:n])


def xor_crypt(data: bytes, password: str) -> bytes:
    stream = derive_stream(password, len(data))
    return bytes(a ^ b for a, b in zip(data, stream))


def iter_log_files(log_dir: Path, fmt: str):
    pattern = format_to_glob(fmt)
    for child in sorted(log_dir.iterdir()):
        if child.is_file() and fnmatch.fnmatch(child.name, pattern):
            yield child


def apply_crypto(opts) -> int:
    print("Applying crypto...")
    log_dir = Path(opts["log_dir_path"])
    if not log_dir.exists() or not log_dir.is_dir():
        return error(f"filesystem error: directory iterator cannot open directory: No such file or directory [{log_dir}]")
    password = opts.get("password")
    if not password:
        return error("Password not provided")

    marker = log_dir / ".cle"
    encrypted = marker.exists()
    if opts["encrypt"]:
        if encrypted:
            return error("Log repo is already encrypted")
        for path in iter_log_files(log_dir, opts["log_name_format"]):
            data = path.read_bytes()
            path.write_bytes(b"CLE1" + xor_crypt(data, password))
        marker.write_bytes(os.urandom(18))
    else:
        if not encrypted:
            return error("Log repo is not encrypted")
        for path in iter_log_files(log_dir, opts["log_name_format"]):
            data = path.read_bytes()
            if data.startswith(b"CLE1"):
                path.write_bytes(xor_crypt(data[4:], password))
        try:
            marker.unlink()
        except FileNotFoundError:
            pass
    return 0


def parse_log_date(name: str):
    m = re.search(r"(\d{2,4})[_-](\d{2})[_-](\d{2})", name)
    if not m:
        return None
    y, mo, d = m.groups()
    year = int(y)
    if year < 100:
        year += 2000
    try:
        return _dt.date(year, int(mo), int(d))
    except ValueError:
        return None


def collect_logs(log_dir: Path, fmt: str):
    dates = []
    sections = set()
    tags = set()
    if log_dir.is_dir():
        for path in iter_log_files(log_dir, fmt):
            dt = parse_log_date(path.name)
            if dt:
                dates.append(dt)
            try:
                lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for line in lines:
                s = line.strip()
                if s.startswith("#"):
                    sections.add(s.lstrip("#").strip() or "<unnamed>")
                elif s.startswith("*"):
                    tag = s.lstrip("*").strip()
                    tag = tag.split(":", 1)[0].strip()
                    tags.add(tag or "<unnamed>")
    return dates, sorted(sections), sorted(tags)


def print_view(opts):
    today = _dt.date.today()
    log_dir = Path(opts["log_dir_path"])
    dates, sections, tags = collect_logs(log_dir, opts["log_name_format"])
    count = sum(1 for d in dates if d.year == today.year)
    print(f"Today is: {today.day:02d}. {today.month:02d}. {today.year}.  | There are {count} log entries for year {today.year}.")
    print("Sections")
    print("> <select none>")
    for item in sections[:12]:
        print(item)
    print("Tags")
    print("> <select none>")
    for item in tags[:12]:
        print(item)
    firstweekday = 6 if opts["sunday_start"] else 0
    cal = calendar.TextCalendar(firstweekday=firstweekday)
    print(cal.formatyear(today.year, w=2, l=1, c=6, m=3))
    print(f"log preview for {today.day:02d}. {today.month:02d}. {str(today.year)[2:]}.")
    return 0


def main(argv):
    try:
        opts = parse_argv(argv)
    except CapsError as e:
        return error(str(e))
    if opts["help"]:
        sys.stdout.write(HELP)
        return 0
    try:
        cfg = read_config(opts["config"])
        opts = merge_config(opts, cfg)
    except CapsError as e:
        return error(str(e))
    if opts["encrypt"] or opts["decrypt"]:
        return apply_crypto(opts)
    return print_view(opts)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
