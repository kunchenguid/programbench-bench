#!/usr/bin/env python3
import argparse
import datetime as _dt
import io
import os
import re
import shutil
import sys
import urllib.request

try:
    from PIL import Image, ImageOps
except Exception:
    Image = None

VERSION = "1.3.2"

BANNER = r"""   ___  _____  ____
  / _ \/  _/ |/_/ /____ ______ _      Made with love by Eliuk Blau
 / ___// /_>  </ __/ -_) __/  ' \ https://github.com/eliukblau/pixterm
/_/  /___/_/|_|\__/\__/_/ /_/_/_/                1.3.2
"""

HELP = BANNER + r"""
USAGE:

  executable [options] image/url

  Supported image formats: JPEG, PNG, GIF, BMP, TIFF, WebP.
  Supported URL protocols: HTTP, HTTPS.

OPTIONS:

  -credits
    	show some love to contributors <3
  -d mode
    	dithering mode:
    	   0 - no dithering (default)
    	   1 - with blocks
    	   2 - with chars
  -go
    	output Go code to 'fmt.Print()' the image
  -m color
    	matte color for transparency or background
    	(optional, hex format, default: 000000)
  -nobg
    	disable background color
    	(optional, only in dithering mode, ignores matte color)
  -s method
    	scale method:
    	   0 - resize (default)
    	   1 - fill
    	   2 - fit
  -tc columns
    	terminal columns (optional, >=2; when piping, default: 80)
  -tr rows
    	terminal rows (optional, >=2; when piping, default: 24)
  -version
    	show PIXterm version
  -help
	prints this message :D LOL
"""

CREDITS = BANNER + r"""
CONTRIBUTORS:

  > @disq - https://github.com/disq
      + Original code for image transparency support.

  > @timob - https://github.com/timob
      + Fix for ANSIpixel type: use 8bit color component for output.

  > @HongjiangHuang - https://github.com/HongjiangHuang
      + Original code for image download support.

  > @brutestack - https://github.com/brutestack
      + Color support for Windows (Command Prompt & PowerShell).
      + Original code for disable background color in dithering mode.
      + Original code for output Go code to 'fmt.Print()' the image.

  > @diamondburned - https://github.com/diamondburned
      + NewFromImage() & NewScaledFromImage() for ANSImage API.

  > @MichaelMure - https://github.com/MichaelMure
      + More conventional 'go.mod' file at repository.

  > @Calinou - https://github.com/Calinou
      + Use HTTPS URLs everywhere.
      + Other awesome contributions.

  > @danirod - https://github.com/danirod
  > @Xpktro - https://github.com/Xpktro
      + Moral support.
"""

BLOCKS = [" ", "░", "▒", "▓", "█"]
CHARS = [" ", ".", ":", "-", "=", "+", "*", "#", "%", "@", "&", "X"]


def perror(msg):
    now = _dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    print(f"[PIXTERM ERROR] {now} {msg}", file=sys.stderr)


def parse_args(argv):
    if not argv:
        print(HELP)
        raise SystemExit(2)
    if "-help" in argv or "--help" in argv:
        print(HELP)
        raise SystemExit(0)
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-version", action="store_true")
    p.add_argument("-credits", action="store_true")
    p.add_argument("-d", dest="dither", type=int, default=0)
    p.add_argument("-go", dest="gocode", action="store_true")
    p.add_argument("-m", dest="matte", default="000000")
    p.add_argument("-nobg", action="store_true")
    p.add_argument("-s", dest="scale", type=int, default=0)
    p.add_argument("-tr", dest="rows", type=int, default=None)
    p.add_argument("-tc", dest="cols", type=int, default=None)
    p.add_argument("image", nargs="?")
    try:
        ns = p.parse_args(argv)
    except SystemExit:
        print(HELP)
        raise SystemExit(2)
    if ns.version:
        print(VERSION)
        raise SystemExit(0)
    if ns.credits:
        print(CREDITS)
        raise SystemExit(0)
    if ns.image is None:
        print(HELP)
        raise SystemExit(2)
    if ns.dither not in (0, 1, 2) or ns.scale not in (0, 1, 2):
        print(HELP)
        raise SystemExit(2)
    if ns.rows is not None and ns.rows < 2:
        print(HELP)
        raise SystemExit(2)
    if ns.cols is not None and ns.cols < 2:
        print(HELP)
        raise SystemExit(2)
    return ns


def matte_color(s):
    if s.startswith("#"):
        s = s[1:]
    if not re.fullmatch(r"[0-9a-fA-F]{6}", s or ""):
        print(BANNER)
        perror(f"matte color : {s} is not a hex-color")
        raise SystemExit(2)
    return tuple(int(s[i:i+2], 16) for i in (0, 2, 4))


def load_image(path):
    if Image is None:
        raise RuntimeError("Pillow is required")
    try:
        if re.match(r"^https?://", path):
            with urllib.request.urlopen(path, timeout=20) as r:
                data = r.read()
            im = Image.open(io.BytesIO(data))
        else:
            im = Image.open(path)
        im.load()
        return im.convert("RGBA")
    except FileNotFoundError:
        print(BANNER)
        perror(f"open {path}: no such file or directory")
        raise SystemExit(1)
    except Exception as e:
        print(BANNER)
        perror(str(e))
        raise SystemExit(1)


def composite(im, matte):
    bg = Image.new("RGBA", im.size, matte + (255,))
    bg.alpha_composite(im)
    return bg.convert("RGB")


def term_size(rows, cols):
    if rows is None or cols is None:
        sz = shutil.get_terminal_size((80, 24))
        cols = cols or sz.columns
        rows = rows or sz.lines
    return rows, cols


def scaled(im, rows, cols, dither_mode, scale_method, matte):
    target_h = rows if dither_mode else rows * 2
    target_w = cols
    src = composite(im, matte)
    sw, sh = src.size
    if scale_method == 0:
        canvas = src.resize((target_w, target_h), Image.Resampling.LANCZOS)
    else:
        if scale_method == 1:
            factor = max(target_w / sw, target_h / sh)
        else:
            factor = min(target_w / sw, target_h / sh)
        nw = max(1, int(round(sw * factor)))
        nh = max(1, int(round(sh * factor)))
        r = src.resize((nw, nh), Image.Resampling.LANCZOS)
        canvas = Image.new("RGB", (target_w, target_h), matte)
        x = (target_w - nw) // 2
        y = (target_h - nh) // 2
        if scale_method == 1:
            crop = r.crop((-x, -y, -x + target_w, -y + target_h))
            canvas.paste(crop, (0, 0))
        else:
            canvas.paste(r, (x, y))
    return canvas


def esc_fg(c):
    return f"\033[38;2;{c[0]};{c[1]};{c[2]}m"


def esc_bg(c):
    return f"\033[48;2;{c[0]};{c[1]};{c[2]}m"


def lum(c):
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]


def render_plain(im):
    px = im.load()
    w, h = im.size
    out = []
    for y in range(0, h, 2):
        parts = []
        for x in range(w):
            top = px[x, y]
            bot = px[x, min(y + 1, h - 1)]
            parts.append(esc_bg(top) + esc_fg(bot) + "▄")
        out.append("".join(parts) + "\033[0m\n")
    return "".join(out)


def render_dither(im, mode, nobg, matte):
    px = im.load()
    w, h = im.size
    table = BLOCKS if mode == 1 else CHARS
    maxidx = len(table) - 1
    out = []
    # Simple Floyd-Steinberg on luminance while keeping true-color foregrounds.
    err = [[0.0] * (w + 2) for _ in range(h + 1)]
    for y in range(h):
        parts = []
        for x in range(w):
            c = px[x, y]
            v = max(0.0, min(255.0, lum(c) + err[y][x]))
            idx = int(round(v / 255.0 * maxidx))
            q = idx / maxidx * 255.0 if maxidx else 0.0
            e = v - q
            if x + 1 < w:
                err[y][x + 1] += e * 7 / 16
            if y + 1 < h:
                if x:
                    err[y + 1][x - 1] += e * 3 / 16
                err[y + 1][x] += e * 5 / 16
                if x + 1 < w:
                    err[y + 1][x + 1] += e * 1 / 16
            if not nobg:
                parts.append(esc_bg(matte))
            parts.append(esc_fg(c) + table[idx])
        out.append("".join(parts) + "\033[0m\n")
    return "".join(out)


def go_escape(s):
    return s.replace("\\", "\\\\").replace("\033", "\\033").replace("\n", "\\n").replace('"', '\\"')


def main(argv):
    ns = parse_args(argv)
    matte = matte_color(ns.matte)
    rows, cols = term_size(ns.rows, ns.cols)
    im = load_image(ns.image)
    canvas = scaled(im, rows, cols, ns.dither, ns.scale, matte)
    if ns.dither:
        text = render_dither(canvas, ns.dither, ns.nobg, matte)
    else:
        text = render_plain(canvas)
    if ns.gocode:
        for line in text.splitlines(True):
            print(f'fmt.Print("{go_escape(line)}")')
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main(sys.argv[1:])
