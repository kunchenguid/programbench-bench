#!/usr/bin/env python3
import html
import os
import stat
import struct
import sys
from dataclasses import dataclass

VERSION = "elfcat 0.1.10"
USAGE = "Usage: elfcat <filename>\nWrites <filename>.html to CWD."

ETYPES = {
    0: "No file type (NONE)",
    1: "Relocatable file (REL)",
    2: "Executable file (EXEC)",
    3: "Shared object file (DYN)",
    4: "Core file (CORE)",
}
MACHINES = {
    0: "No machine",
    2: "SPARC",
    3: "x86",
    8: "MIPS",
    20: "PowerPC",
    21: "PowerPC64",
    40: "ARM",
    42: "SuperH",
    50: "IA-64",
    62: "x86-64",
    183: "AArch64",
    243: "RISC-V",
}
ABIS = {
    0: "SysV",
    1: "HP-UX",
    2: "NetBSD",
    3: "Linux",
    6: "Solaris",
    7: "AIX",
    8: "IRIX",
    9: "FreeBSD",
    12: "OpenBSD",
}
PTYPES = {
    0: "NULL",
    1: "LOAD",
    2: "DYNAMIC",
    3: "INTERP",
    4: "NOTE",
    5: "SHLIB",
    6: "PHDR",
    7: "TLS",
    0x6474E550: "GNU_EH_FRAME (OS-specific)",
    0x6474E551: "GNU_STACK (OS-specific)",
    0x6474E552: "GNU_RELRO (OS-specific)",
    0x6474E553: "GNU_PROPERTY (OS-specific)",
}
STYPES = {
    0: "NULL",
    1: "PROGBITS",
    2: "SYMTAB",
    3: "STRTAB",
    4: "RELA",
    5: "HASH",
    6: "DYNAMIC",
    7: "NOTE",
    8: "NOBITS",
    9: "REL",
    10: "SHLIB",
    11: "DYNSYM",
    14: "INIT_ARRAY",
    15: "FINI_ARRAY",
    16: "PREINIT_ARRAY",
    17: "GROUP",
    18: "SYMTAB_SHNDX",
    0x6FFFFFF6: "GNU_HASH (OS-specific)",
    0x6FFFFFF7: "GNU_LIBLIST (OS-specific)",
    0x6FFFFFFE: "VERNEED (OS-specific)",
    0x6FFFFFFF: "VERSYM (OS-specific)",
}


@dataclass
class ProgramHeader:
    p_type: int
    p_flags: int
    p_offset: int
    p_vaddr: int
    p_paddr: int
    p_filesz: int
    p_memsz: int
    p_align: int


@dataclass
class SectionHeader:
    index: int
    sh_name: int
    sh_type: int
    sh_flags: int
    sh_addr: int
    sh_offset: int
    sh_size: int
    sh_link: int
    sh_info: int
    sh_addralign: int
    sh_entsize: int
    name: str = ""


@dataclass
class ELF:
    path: str
    data: bytes
    bits: int
    endian_name: str
    endian: str
    abi: int
    e_type: int
    e_machine: int
    e_entry: int
    e_phoff: int
    e_shoff: int
    e_flags: int
    e_ehsize: int
    e_phentsize: int
    e_phnum: int
    e_shentsize: int
    e_shnum: int
    e_shstrndx: int
    phdrs: list
    shdrs: list


def fail(msg):
    print(msg, file=sys.stderr)
    return 1


def usage(code):
    print(USAGE)
    return code


def fmt_size(n):
    if n < 1024:
        return f"{n} B"
    units = ["KiB", "MiB", "GiB", "TiB"]
    value = float(n)
    for unit in units:
        value /= 1024.0
        if value < 1024.0 or unit == units[-1]:
            s = f"{value:.1f}".rstrip("0").rstrip(".")
            return f"{s} {unit}"
    return f"{n} B"


def num(n, decimal_title=False):
    title = str(n) if decimal_title else hex(n)
    text = f"{hex(n)}" if decimal_title else str(n)
    return f"<span class='number' title='{html.escape(title)}'>{html.escape(text)}</span>"


def flags_p(v):
    s = ""
    if v & 4:
        s += "R"
    if v & 2:
        s += "W"
    if v & 1:
        s += "X"
    return s or "0"


def flags_s(v):
    parts = ""
    if v & 1:
        parts += "W"
    if v & 2:
        parts += "A"
    if v & 4:
        parts += "X"
    if v & 0x10:
        parts += "M"
    if v & 0x20:
        parts += "S"
    if v & 0x40:
        parts += "I"
    if v & 0x80:
        parts += "L"
    if v & 0x100:
        parts += "O"
    if v & 0x200:
        parts += "G"
    if v & 0x400:
        parts += "T"
    return parts or "0"


def type_name(mapping, value):
    return mapping.get(value, f"Unknown: {value}")


def read_cstr(blob, off):
    if off < 0 or off >= len(blob):
        return ""
    end = blob.find(b"\0", off)
    if end == -1:
        end = len(blob)
    try:
        return blob[off:end].decode("utf-8", "replace")
    except Exception:
        return ""


def parse_elf(path, data):
    if len(data) < 16:
        raise ValueError("file is smaller than ELF header's e_ident")
    if data[:4] != b"\x7fELF":
        raise ValueError("bad magic number")
    cls = data[4]
    enc = data[5]
    if cls == 1:
        bits = 32
    elif cls == 2:
        bits = 64
    else:
        raise ValueError(f"unknown ELF class {cls}")
    if enc == 1:
        endian = "<"
        endian_name = "Little endian"
    elif enc == 2:
        endian = ">"
        endian_name = "Big endian"
    else:
        raise ValueError(f"unknown ELF data encoding {enc}")
    min_header = 52 if bits == 32 else 64
    if len(data) < min_header:
        raise ValueError("file is smaller than ELF header")
    if bits == 64:
        vals = struct.unpack_from(endian + "HHIQQQIHHHHHH", data, 16)
        (e_type, e_machine, _version, e_entry, e_phoff, e_shoff, e_flags,
         e_ehsize, e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx) = vals
    else:
        vals = struct.unpack_from(endian + "HHIIIIIHHHHHH", data, 16)
        (e_type, e_machine, _version, e_entry, e_phoff, e_shoff, e_flags,
         e_ehsize, e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx) = vals
    phdrs = []
    for i in range(e_phnum):
        off = e_phoff + i * e_phentsize
        if off + e_phentsize > len(data):
            break
        if bits == 64:
            fields = struct.unpack_from(endian + "IIQQQQQQ", data, off)
            phdrs.append(ProgramHeader(*fields))
        else:
            p_type, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_flags, p_align = struct.unpack_from(endian + "IIIIIIII", data, off)
            phdrs.append(ProgramHeader(p_type, p_flags, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_align))
    shdrs = []
    for i in range(e_shnum):
        off = e_shoff + i * e_shentsize
        if off + e_shentsize > len(data):
            break
        if bits == 64:
            fields = struct.unpack_from(endian + "IIQQQQIIQQ", data, off)
        else:
            fields32 = struct.unpack_from(endian + "IIIIIIIIII", data, off)
            fields = fields32
        shdrs.append(SectionHeader(i, *fields))
    if 0 <= e_shstrndx < len(shdrs):
        names = shdrs[e_shstrndx]
        blob = data[names.sh_offset:names.sh_offset + names.sh_size]
        for sh in shdrs:
            sh.name = read_cstr(blob, sh.sh_name)
    return ELF(path, data, bits, endian_name, endian, data[7], e_type, e_machine, e_entry,
               e_phoff, e_shoff, e_flags, e_ehsize, e_phentsize, e_phnum,
               e_shentsize, e_shnum, e_shstrndx, phdrs, shdrs)


def ascii_dump(data):
    lines = []
    for i in range(0, len(data), 16):
        chunk = data[i:i + 16]
        lines.append("".join(chr(b) if 32 <= b < 127 else "." for b in chunk))
    return "\n".join(lines)


def hex_dump(data):
    lines = []
    for i in range(0, len(data), 16):
        chunk = data[i:i + 16]
        hx = " ".join(f"{b:02x}" for b in chunk)
        asc = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        lines.append(f"<tr><td class='off'>{i:x}</td><td class='hex'>{hx}</td><td class='ascii'>{html.escape(asc)}</td></tr>")
    return "\n".join(lines)


def offsets(data):
    return "\n".join(f"{i:x}" for i in range(0, len(data), 16))


def row(cls, label, value):
    return f"      <tr class='{cls}'> <td>{label}</td> <td>{value}</td> </tr>"


def program_table(i, ph):
    interp = ""
    if ph.p_type == 3:
        interp = "\n            <tr><td><br></td></tr>\n            <tr> <td>Interpreter:</td> <td class='interp_value'></td> </tr>"
    return f"""          <table class='conceal itable' id='info_phdr{i}'>
          <th colspan='2' class='phdr_itable'></th>
            <tr> <td>Type:</td> <td>{html.escape(type_name(PTYPES, ph.p_type))}</td> </tr>
            <tr> <td>Flags:</td> <td>{flags_p(ph.p_flags)}</td> </tr>
            <tr> <td>Offset in file:</td> <td>{num(ph.p_offset, True)}</td> </tr>
            <tr> <td>Size in file:</td> <td>{num(ph.p_filesz)}</td> </tr>
            <tr> <td>Vaddr in memory:</td> <td>{num(ph.p_vaddr, True)}</td> </tr>
            <tr> <td>Size in memory:</td> <td>{num(ph.p_memsz)}</td> </tr>
            <tr> <td>Alignment:</td> <td>{num(ph.p_align, True)}</td> </tr>{interp}
          </table>"""


def section_table(sh):
    return f"""          <table class='conceal itable' id='info_shdr{sh.index}'>
          <th colspan='2' class='shdr_itable'></th>
            <tr> <td>Index:</td> <td>{sh.index}</td> </tr>
            <tr> <td>Name:</td> <td>{html.escape(sh.name)}</td> </tr>
            <tr> <td>Type:</td> <td>{html.escape(type_name(STYPES, sh.sh_type))}</td> </tr>
            <tr> <td>Flags:</td> <td>{flags_s(sh.sh_flags)}</td> </tr>
            <tr> <td>Vaddr in memory:</td> <td>{num(sh.sh_addr, True)}</td> </tr>
            <tr> <td>Offset in file:</td> <td>{num(sh.sh_offset, True)}</td> </tr>
            <tr> <td>Size in file:</td> <td>{num(sh.sh_size)}</td> </tr>
            <tr> <td>Linked section:</td> <td>{sh.sh_link}</td> </tr>
            <tr> <td>Extra info:</td> <td>{num(sh.sh_info)}</td> </tr>
            <tr> <td>Alignment:</td> <td>{num(sh.sh_addralign, True)}</td> </tr>
            <tr> <td>Size of entries:</td> <td>{num(sh.sh_entsize)}</td> </tr>
          </table>"""


def segment_table(i, ph, data):
    extra = ""
    if ph.p_type == 3 and ph.p_filesz:
        interp = read_cstr(data[ph.p_offset:ph.p_offset + ph.p_filesz], 0)
        extra = f"\n            <tr><td><br></td></tr>\n            <tr> <td>Interpreter:</td> <td>{html.escape(interp)}</td> </tr>"
    return f"""          <table class='conceal itable' id='info_segment{i}'>
          <th colspan='2' class='segment_itable'></th>
            <tr> <td>Type:</td> <td>{html.escape(type_name(PTYPES, ph.p_type))}</td> </tr>
            <tr> <td>Size in file:</td> <td>{num(ph.p_filesz)}</td> </tr>
            <tr> <td>Size in memory:</td> <td>{num(ph.p_memsz)}</td> </tr>{extra}
          </table>"""


def render(elf):
    title = html.escape(os.path.basename(elf.path))
    file_path = html.escape(elf.path)
    size = len(elf.data)
    abi = ABIS.get(elf.abi, f"Unknown: {elf.abi}")
    class_name = "64-bit" if elf.bits == 64 else "32-bit"
    info = "\n".join([
        row("fileinfo_file_name", "File name:", file_path),
        row("fileinfo_file_size", "File size:", f"{fmt_size(size)} ({size} B)"),
        row("fileinfo_class", "Object class:", class_name),
        row("fileinfo_data", "Data encoding:", elf.endian_name),
        row("fileinfo_abi", "ABI:", html.escape(abi)),
        row("fileinfo_e_type", "Type:", html.escape(type_name(ETYPES, elf.e_type))),
        row("fileinfo_e_machine", "Architecture:", html.escape(MACHINES.get(elf.e_machine, f"Unknown: {elf.e_machine}"))),
        row("fileinfo_e_entry", "Entrypoint:", num(elf.e_entry, True)),
        row("fileinfo_ph", "Program headers:", f"<span title='{hex(elf.e_phnum)}' class='number fileinfo_e_phnum'>{elf.e_phnum}</span> * <span title='{hex(elf.e_phentsize)}' class='number fileinfo_e_phentsize'>{elf.e_phentsize}</span> @ <span title='{hex(elf.e_phoff)}' class='number fileinfo_e_phoff'>{elf.e_phoff}</span>"),
        row("fileinfo_sh", "Section headers:", f"<span title='{hex(elf.e_shnum)}' class='number fileinfo_e_shnum'>{elf.e_shnum}</span> * <span title='{hex(elf.e_shentsize)}' class='number fileinfo_e_shentsize'>{elf.e_shentsize}</span> @ <span title='{hex(elf.e_shoff)}' class='number fileinfo_e_shoff'>{elf.e_shoff}</span>"),
    ])
    ph_tables = "\n".join(program_table(i, ph) for i, ph in enumerate(elf.phdrs))
    sh_tables = "\n".join(section_table(sh) for sh in elf.shdrs)
    seg_tables = "\n".join(segment_table(i, ph, elf.data) for i, ph in enumerate(elf.phdrs))
    sections_summary = "\n".join(
        f"<tr><td>{sh.index}</td><td>{html.escape(sh.name)}</td><td>{html.escape(type_name(STYPES, sh.sh_type))}</td><td>{sh.sh_offset:x}</td><td>{sh.sh_size:x}</td></tr>"
        for sh in elf.shdrs
    )
    ph_summary = "\n".join(
        f"<tr><td>{i}</td><td>{html.escape(type_name(PTYPES, ph.p_type))}</td><td>{flags_p(ph.p_flags)}</td><td>{ph.p_offset:x}</td><td>{ph.p_filesz:x}</td><td>{ph.p_memsz:x}</td></tr>"
        for i, ph in enumerate(elf.phdrs)
    )
    connections = "\n".join([f"      connect('.bin_phdr{i} > .p_offset', '.bin_segment{i}');" for i in range(len(elf.phdrs))] +
                            [f"      connect('.bin_shdr{sh.index} > .sh_offset', '.bin_section{sh.index}');" for sh in elf.shdrs])
    return f"""<!doctype html>
<html>
  <head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=900, initial-scale=1'>
    <title>{title}</title>
    <style>
      html {{ font-family: monospace; }}
      #rightmenu {{ vertical-align: top; text-align: right; float: right; }}
      #credits {{ color: #ddd; text-decoration: none; margin-bottom: 0.5em; display: block; }}
      #credits:hover {{ color: #000; }}
      .right_hidden {{ text-align: left; display: none; }}
      .textbutton {{ color: #222; cursor: pointer; background: none; border: none; padding: 0; margin: 0; margin-bottom: 0.5em; }}
      .textbutton::before {{ content: "["; }} .textbutton::after {{ content: "]"; }}
      .legend_rect {{ float: left; margin-right: 0.4em; width: 3em; height: 1.5em; border: 1px solid rgba(0,0,0,.2); }}
      .ident {{ background: #ffd6a5; }} .ehdr {{ background: #caffbf; }} .phdr {{ background: #9bf6ff; }}
      .shdr {{ background: #bdb2ff; }} .segment {{ background: rgba(255, 173, 173, .5); }} .section {{ background: rgba(160, 196, 255, .5); }}
      .number {{ color: #0645ad; }}
      .conceal {{ display: none; }}
      table {{ border-collapse: collapse; }}
      td, th {{ padding: 0 0.7em 0 0; vertical-align: top; }}
      #dump td {{ white-space: pre; }}
      #offsets, #asciidump {{ display: none; }}
      .itable {{ margin-bottom: 1em; border-left: 0.3em solid #ddd; padding-left: 0.5em; }}
      .section_itable::before {{ content: "Section header"; }}
      .segment_itable::before {{ content: "Segment"; }}
      .phdr_itable::before {{ content: "Program header"; }}
      .shdr_itable::before {{ content: "Section header"; }}
    </style>
  </head>
  <body>
    <svg width='100%' height='100%'><defs><marker id='arrowhead' viewBox='0 0 10 10' refX='10' refY='5' markerWidth='10' markerHeight='10' orient='auto'><path d='M 0 0 L 10 5 L 0 10 z' /></marker></defs><g id='arrows' stroke='black' stroke-width='1' marker-end='url(#arrowhead)'></g></svg>
    <div id='rightmenu'>
      <a id='credits' href='https://github.com/rbakbashev/elfcat'>generated with elfcat 0.1.10</a>
      <button class='textbutton' id='settings_toggle'>Settings</button>
      <button class='textbutton' id='help_toggle'>Help</button>
      <div class='right_hidden' id='settings'><label for='arrow_opacity_range'>Arrow opacity:</label><input type='range' id='arrow_opacity_range' min='0' max='100' value='100'></div>
      <div class='right_hidden' id='help'>
        <p>The leftmost column shows offsets within the file. The middle column is the file dump. It has ELF structs, sections and segments highlighted. Some fields that reference areas in the file are clickable and connected with arrows. The rightmost column shows printable ASCII characters corresponding to the file bytes.</p>
        <p>Legend</p>
        <ul>
          <li><span class='legend_rect ident'></span>ELF Identification</li>
          <li><span class='legend_rect ehdr'></span>ELF Header</li>
          <li><span class='legend_rect phdr'></span>Program Header</li>
          <li><span class='legend_rect shdr'></span>Section Header</li>
          <li><span class='legend_rect segment'></span>Segment</li>
          <li><span class='legend_rect section'></span>Section</li>
          <li><span class='legend_rect segm_sect_legend'></span>Segment &amp; Section overlap</li>
        </ul>
      </div>
    </div>
    <table>
{info}
    </table>
    <div id='offsets'>{offsets(elf.data)}</div>
    <div id='asciidump'>{html.escape(ascii_dump(elf.data))}</div>
    <h2>Program headers</h2>
    <table id='program_headers'><tr><th>#</th><th>Type</th><th>Flags</th><th>Offset</th><th>File size</th><th>Mem size</th></tr>{ph_summary}</table>
    <h2>Section headers</h2>
    <table id='section_headers'><tr><th>#</th><th>Name</th><th>Type</th><th>Offset</th><th>Size</th></tr>{sections_summary}</table>
    <h2>Hexdump</h2>
    <table id='dump'>{hex_dump(elf.data)}</table>
    <table id='sticky_table' cellspacing='0'>
      <tr>
        <td id='desc'></td>
        <td class='infotables'>
{ph_tables}
{sh_tables}
        </td>
        <td class='infotables'>
{seg_tables}
        </td>
      </tr>
    </table>
    <script type='text/javascript'>
      const connections = [];
      function connect(a, b) {{ connections.push([a, b]); }}
      connect('.e_phoff', '.bin_phdr0');
      connect('.e_shoff', '.bin_shdr0');
{connections}
    </script>
    <script type='text/javascript'>
      function toggleVisibility(elem) {{ elem.style.display = (elem.style.display === "none" || elem.style.display === "") ? "block" : "none"; }}
      const settings = document.getElementById('settings');
      const help = document.getElementById('help');
      document.getElementById('settings_toggle').onclick = function() {{ toggleVisibility(settings); help.style.display = "none"; }}
      document.getElementById('help_toggle').onclick = function() {{ toggleVisibility(help); settings.style.display = "none"; }}
    </script>
  </body>
</html>
"""


def main(argv):
    if len(argv) == 2 and argv[1] in ("--help", "-h"):
        return usage(0)
    if len(argv) == 2 and argv[1] in ("--version", "-v"):
        print(VERSION)
        return 0
    if len(argv) != 2:
        return usage(1)
    path = argv[1]
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError as e:
        return fail(f"Failed to read file \"{path}\": {e.strerror} (os error {e.errno})")
    try:
        elf = parse_elf(path, data)
    except ValueError as e:
        return fail(f"Failed to parse ELF: {e}")
    out_name = os.path.basename(path) + ".html"
    with open(out_name, "w", encoding="utf-8") as f:
        f.write(render(elf))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
