#!/usr/bin/env python3
import base64
import fnmatch
import json
import os
import re
import stat
import sys
import time
from dataclasses import dataclass, field


VERSION = """ripgrep 14.1.1 (rev 719e15af5e)

features:-pcre2
simd(compile):+SSE2,-SSSE3,-AVX2
simd(runtime):+SSE2,+SSSE3,+AVX2"""

HELP = """ripgrep 14.1.1
Andrew Gallant <jamslam@gmail.com>

ripgrep (rg) recursively searches the current directory for a regex pattern.

USAGE:
    rg [OPTIONS] PATTERN [PATH ...]
    rg [OPTIONS] -e PATTERN ... [PATH ...]
    rg [OPTIONS] -f PATTERNFILE ... [PATH ...]

OPTIONS:
    -i, --ignore-case           Search case insensitively.
    -S, --smart-case            Smart case search.
    -F, --fixed-strings         Treat patterns as literals.
    -w, --word-regexp           Only show matches surrounded by word boundaries.
    -v, --invert-match          Invert matching.
    -n, --line-number           Show line numbers.
    -N, --no-line-number        Suppress line numbers.
    -H, --with-filename         Show file names.
    -I, --no-filename           Suppress file names.
    --column                    Show column numbers.
    -o, --only-matching         Print only matching portions.
    -c, --count                 Print count of matching lines.
    --count-matches             Print count of matches.
    -l, --files-with-matches    Print paths containing matches.
    --files-without-match       Print paths containing no matches.
    -A, --after-context NUM     Show NUM lines after each match.
    -B, --before-context NUM    Show NUM lines before each match.
    -C, --context NUM           Show NUM lines before and after each match.
    -m, --max-count NUM         Limit matches per file.
    -e PATTERN                  Add a pattern.
    -f FILE                     Read patterns from a file.
    -g, --glob GLOB             Include or exclude paths with a glob.
    -t, --type TYPE             Only search files matching TYPE.
    -T, --type-not TYPE         Do not search files matching TYPE.
    --files                     Print files that would be searched.
    --type-list                 Show supported file types.
    --json                      Emit JSON Lines.
    --stats                     Print search statistics.
    --hidden                    Search hidden files and directories.
    -u, --unrestricted          Reduce filtering; -uu also searches hidden files.
    --no-ignore                 Do not respect ignore files.
    -a, --text                  Search binary files as text.
    -q, --quiet                 Do not print matches.
    -V, --version               Print version.
    -h, --help                  Print help.
"""

TYPE_GLOBS = {
    "py": ["*.py", "SConstruct", "SConscript"],
    "python": ["*.py", "SConstruct", "SConscript"],
    "rs": ["*.rs"],
    "rust": ["*.rs"],
    "c": ["*.[chH]", "*.[chH].in"],
    "cpp": ["*.[ChH]", "*.[ch]pp", "*.cc", "*.hh", "*.cxx", "*.hxx", "*.inl"],
    "js": ["*.js", "*.jsx", "*.mjs", "*.cjs"],
    "javascript": ["*.js", "*.jsx", "*.mjs", "*.cjs"],
    "ts": ["*.ts", "*.tsx"],
    "go": ["*.go"],
    "java": ["*.java"],
    "json": ["*.json"],
    "toml": ["*.toml", "Cargo.lock"],
    "md": ["*.md", "*.markdown"],
    "markdown": ["*.md", "*.markdown"],
    "txt": ["*.txt"],
    "html": ["*.html", "*.htm"],
    "css": ["*.css", "*.scss"],
    "sh": ["*.sh", "*.bash", "*.zsh"],
    "yaml": ["*.yaml", "*.yml"],
    "yml": ["*.yaml", "*.yml"],
}


@dataclass
class Opts:
    patterns: list[str] = field(default_factory=list)
    pattern_files: list[str] = field(default_factory=list)
    paths: list[str] = field(default_factory=list)
    ignore_case: bool = False
    smart_case: bool = False
    fixed: bool = False
    word: bool = False
    line_regexp: bool = False
    invert: bool = False
    line_number: bool | None = None
    with_filename: bool | None = None
    column: bool = False
    only_matching: bool = False
    count: bool = False
    count_matches: bool = False
    files_with_matches: bool = False
    files_without_match: bool = False
    before: int = 0
    after: int = 0
    max_count: int | None = None
    globs: list[str] = field(default_factory=list)
    types: list[str] = field(default_factory=list)
    type_nots: list[str] = field(default_factory=list)
    files: bool = False
    type_list: bool = False
    json: bool = False
    stats: bool = False
    hidden: bool = False
    no_ignore: bool = False
    text: bool = False
    quiet: bool = False
    include_zero: bool = False
    trim: bool = False
    replace: str | None = None
    max_columns: int | None = None
    max_columns_preview: bool = False
    null: bool = False
    path_separator: str | None = None
    sort: str | None = None
    sort_reverse: bool = False
    no_messages: bool = False
    default_path: bool = False


def die(msg: str, code: int = 2) -> None:
    print(f"rg: {msg}", file=sys.stderr)
    raise SystemExit(code)


def generate(kind: str) -> None:
    if kind == "man":
        print(".TH RG 1")
        print(".SH NAME")
        print("rg \\- recursively search current directory for a regex pattern")
        print(".SH SYNOPSIS")
        print(".B rg")
        print("[OPTIONS] PATTERN [PATH ...]")
    elif kind.startswith("complete-"):
        shell = kind.split("-", 1)[1]
        print(f"# {shell} completion for rg")
    else:
        die(f"invalid value '{kind}' for '--generate <KIND>'")


def take_value(argv, i, opt):
    if i + 1 >= len(argv):
        die(f"The argument '{opt}' requires a value but none was supplied")
    return argv[i + 1], i + 1


def parse_num(s: str, name: str) -> int:
    try:
        n = int(s)
    except ValueError:
        die(f"invalid value '{s}' for '{name}': invalid digit found in string")
    if n < 0:
        die(f"invalid value '{s}' for '{name}': value must be non-negative")
    return n


def parse_args(argv: list[str]) -> Opts:
    o = Opts()
    positional = []
    pattern_expected = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if pattern_expected:
            positional.append(a)
            pattern_expected = False
            i += 1
            continue
        if a == "--":
            positional.extend(argv[i + 1 :])
            break
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a == "--pcre2-version":
            print("PCRE2 is not available in this build of ripgrep.", file=sys.stderr)
            raise SystemExit(2)
        if a in ("-P", "--pcre2"):
            print("PCRE2 is not available in this build of ripgrep.", file=sys.stderr)
            raise SystemExit(2)
        if a == "--generate":
            v, i = take_value(argv, i, a)
            generate(v)
            raise SystemExit(0)
        if a.startswith("--generate="):
            generate(a.split("=", 1)[1])
            raise SystemExit(0)
        if a in ("-i", "--ignore-case"):
            o.ignore_case = True
        elif a in ("-S", "--smart-case"):
            o.smart_case = True
        elif a in ("-F", "--fixed-strings"):
            o.fixed = True
        elif a in ("-w", "--word-regexp"):
            o.word = True
        elif a in ("-x", "--line-regexp"):
            o.line_regexp = True
        elif a in ("-s", "--case-sensitive"):
            o.ignore_case = False
            o.smart_case = False
        elif a in ("-v", "--invert-match"):
            o.invert = True
        elif a in ("-n", "--line-number"):
            o.line_number = True
        elif a in ("-N", "--no-line-number"):
            o.line_number = False
        elif a in ("-H", "--with-filename"):
            o.with_filename = True
        elif a in ("-I", "--no-filename", "--no-heading"):
            o.with_filename = False
        elif a == "--column":
            o.column = True
        elif a in ("-o", "--only-matching"):
            o.only_matching = True
        elif a in ("-c", "--count"):
            o.count = True
            o.count_matches = False
        elif a == "--count-matches":
            o.count_matches = True
            o.count = False
        elif a in ("-l", "--files-with-matches"):
            o.files_with_matches = True
            o.files_without_match = False
        elif a == "--files-without-match":
            o.files_without_match = True
            o.files_with_matches = False
        elif a in ("-A", "--after-context"):
            v, i = take_value(argv, i, a)
            o.after = parse_num(v, a)
        elif a.startswith("-A") and len(a) > 2:
            o.after = parse_num(a[2:], "-A")
        elif a.startswith("--after-context="):
            o.after = parse_num(a.split("=", 1)[1], "--after-context")
        elif a in ("-B", "--before-context"):
            v, i = take_value(argv, i, a)
            o.before = parse_num(v, a)
        elif a.startswith("-B") and len(a) > 2:
            o.before = parse_num(a[2:], "-B")
        elif a.startswith("--before-context="):
            o.before = parse_num(a.split("=", 1)[1], "--before-context")
        elif a in ("-C", "--context"):
            v, i = take_value(argv, i, a)
            o.before = o.after = parse_num(v, a)
        elif a.startswith("-C") and len(a) > 2:
            o.before = o.after = parse_num(a[2:], "-C")
        elif a.startswith("--context="):
            o.before = o.after = parse_num(a.split("=", 1)[1], "--context")
        elif a in ("-m", "--max-count"):
            v, i = take_value(argv, i, a)
            o.max_count = parse_num(v, a)
        elif a.startswith("-m") and len(a) > 2:
            o.max_count = parse_num(a[2:], "-m")
        elif a.startswith("--max-count="):
            o.max_count = parse_num(a.split("=", 1)[1], "--max-count")
        elif a in ("-M", "--max-columns"):
            v, i = take_value(argv, i, a)
            o.max_columns = parse_num(v, a)
        elif a.startswith("-M") and len(a) > 2:
            o.max_columns = parse_num(a[2:], "-M")
        elif a.startswith("--max-columns="):
            o.max_columns = parse_num(a.split("=", 1)[1], "--max-columns")
        elif a == "-e":
            v, i = take_value(argv, i, a)
            o.patterns.append(v)
        elif a.startswith("-e") and len(a) > 2:
            o.patterns.append(a[2:])
        elif a.startswith("--regexp="):
            o.patterns.append(a.split("=", 1)[1])
        elif a == "--regexp":
            v, i = take_value(argv, i, a)
            o.patterns.append(v)
        elif a == "-f" or a == "--file":
            v, i = take_value(argv, i, a)
            o.pattern_files.append(v)
        elif a.startswith("--file="):
            o.pattern_files.append(a.split("=", 1)[1])
        elif a in ("-g", "--glob"):
            v, i = take_value(argv, i, a)
            o.globs.append(v)
        elif a.startswith("-g") and len(a) > 2:
            o.globs.append(a[2:])
        elif a.startswith("--glob="):
            o.globs.append(a.split("=", 1)[1])
        elif a in ("-t", "--type"):
            v, i = take_value(argv, i, a)
            o.types.append(v)
        elif a.startswith("-t") and len(a) > 2:
            o.types.append(a[2:])
        elif a.startswith("--type="):
            o.types.append(a.split("=", 1)[1])
        elif a in ("-T", "--type-not"):
            v, i = take_value(argv, i, a)
            o.type_nots.append(v)
        elif a.startswith("-T") and len(a) > 2:
            o.type_nots.append(a[2:])
        elif a.startswith("--type-not="):
            o.type_nots.append(a.split("=", 1)[1])
        elif a == "--files":
            o.files = True
        elif a == "--type-list":
            o.type_list = True
        elif a == "--json":
            o.json = True
            o.stats = True
        elif a == "--stats":
            o.stats = True
        elif a == "--hidden":
            o.hidden = True
        elif a in ("-u", "--unrestricted"):
            o.no_ignore = True
        elif a == "-uu":
            o.no_ignore = True
            o.hidden = True
        elif a == "-uuu":
            o.no_ignore = True
            o.hidden = True
            o.text = True
        elif a == "--no-ignore":
            o.no_ignore = True
        elif a in ("-a", "--text"):
            o.text = True
        elif a in ("-q", "--quiet"):
            o.quiet = True
        elif a == "--include-zero":
            o.include_zero = True
        elif a == "--trim":
            o.trim = True
        elif a in ("-0", "--null"):
            o.null = True
        elif a in ("-r", "--replace"):
            v, i = take_value(argv, i, a)
            o.replace = v
        elif a.startswith("-r") and len(a) > 2:
            o.replace = a[2:]
        elif a.startswith("--replace="):
            o.replace = a.split("=", 1)[1]
        elif a.startswith("--path-separator="):
            o.path_separator = a.split("=", 1)[1] or None
        elif a == "--path-separator":
            v, i = take_value(argv, i, a)
            o.path_separator = v or None
        elif a == "--sort-files":
            o.sort = "path"
        elif a.startswith("--sort="):
            o.sort = a.split("=", 1)[1]
            o.sort_reverse = False
        elif a.startswith("--sortr="):
            o.sort = a.split("=", 1)[1]
            o.sort_reverse = True
        elif a == "--no-messages":
            o.no_messages = True
        elif a == "--color" or a == "--colors" or a == "--engine" or a == "-E" or a == "--encoding":
            _, i = take_value(argv, i, a)
        elif a.startswith("--color=") or a.startswith("--colors=") or a.startswith("--engine=") or a.startswith("--encoding="):
            pass
        elif a == "--max-columns-preview":
            o.max_columns_preview = True
        elif a in ("--no-config", "--no-heading", "--heading", "--no-json", "--no-stats", "--line-buffered", "--block-buffered", "--no-ignore-messages", "--messages", "--debug", "--trace", "--crlf", "--no-crlf", "--multiline", "-U", "--multiline-dotall", "--no-multiline-dotall", "--passthru", "--passthrough", "--pretty", "-p", "--no-ignore-parent", "--no-ignore-vcs", "--no-ignore-dot", "--no-ignore-global"):
            pass
        elif a in ("-L", "--follow"):
            pass
        elif a.startswith("--"):
            die(f"unrecognized flag {a}")
        elif a.startswith("-") and a != "-":
            # Support compact common switches, e.g. -inH.
            handled = True
            for ch in a[1:]:
                if ch == "i":
                    o.ignore_case = True
                elif ch == "n":
                    o.line_number = True
                elif ch == "H":
                    o.with_filename = True
                elif ch == "I":
                    o.with_filename = False
                elif ch == "F":
                    o.fixed = True
                elif ch == "w":
                    o.word = True
                elif ch == "x":
                    o.line_regexp = True
                elif ch == "v":
                    o.invert = True
                elif ch == "o":
                    o.only_matching = True
                elif ch == "c":
                    o.count = True
                    o.count_matches = False
                elif ch == "l":
                    o.files_with_matches = True
                elif ch == "q":
                    o.quiet = True
                else:
                    handled = False
                    break
            if not handled:
                positional.append(a)
        else:
            positional.append(a)
        i += 1

    if o.pattern_files:
        for pf in o.pattern_files:
            try:
                with open(pf, "r", encoding="utf-8", errors="replace") as f:
                    o.patterns.extend([line.rstrip("\n") for line in f])
            except OSError as e:
                die(f"{pf}: {e.strerror}")
    if not o.files and not o.type_list and not o.patterns:
        if positional:
            o.patterns.append(positional.pop(0))
        else:
            die("ripgrep requires at least one pattern to execute a search")
    o.default_path = not positional
    o.paths = positional or ([] if o.files else ["."])
    return o


def compile_regex(o: Opts):
    parts = []
    for p in o.patterns:
        p = re.escape(p) if o.fixed else p
        if o.word:
            p = r"\b(?:" + p + r")\b"
        if o.line_regexp:
            p = r"^(?:" + p + r")$"
        parts.append(p)
    pat = "|".join(f"(?:{p})" for p in parts) if parts else r"$^"
    flags = re.MULTILINE
    if o.ignore_case or (o.smart_case and not any(c.isupper() for c in "".join(o.patterns))):
        flags |= re.IGNORECASE
    try:
        return re.compile(pat, flags)
    except re.error as e:
        print("rg: regex parse error:", file=sys.stderr)
        print(f"    {pat}", file=sys.stderr)
        print(f"error: {e}", file=sys.stderr)
        raise SystemExit(2)


def load_ignores(root: str) -> list[str]:
    pats = []
    for name in (".rgignore", ".ignore", ".gitignore"):
        path = os.path.join(root, name)
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        pats.append(line)
        except OSError:
            pass
    return pats


def is_hidden_path(path: str) -> bool:
    return any(part.startswith(".") and part not in (".", "..") for part in path.split(os.sep))


def match_any_glob(path: str, patterns: list[str]) -> bool:
    base = os.path.basename(path)
    for pat in patterns:
        pat = pat.strip()
        if not pat:
            continue
        slashless = "/" not in pat
        if fnmatch.fnmatch(path, pat) or fnmatch.fnmatch(base, pat):
            return True
        if slashless and fnmatch.fnmatch(base, pat):
            return True
    return False


def ignored(path: str, ignores: list[str]) -> bool:
    base = os.path.basename(path)
    for pat in ignores:
        neg = pat.startswith("!")
        if neg:
            pat = pat[1:]
        dirpat = pat.endswith("/")
        if dirpat:
            pat = pat.rstrip("/")
        matched = fnmatch.fnmatch(path, pat) or fnmatch.fnmatch(base, pat)
        if not matched and "/" not in pat:
            matched = any(fnmatch.fnmatch(part, pat) for part in path.split(os.sep))
        if matched:
            return not neg
    return False


def type_matches(path: str, ty: str) -> bool:
    globs = TYPE_GLOBS.get(ty)
    if globs is None:
        return False
    return match_any_glob(path, globs)


def allowed_by_filters(rel: str, o: Opts) -> bool:
    for ty in o.types:
        if not type_matches(rel, ty):
            return False
    for ty in o.type_nots:
        if type_matches(rel, ty):
            return False
    positives = [g for g in o.globs if not g.startswith("!")]
    negatives = [g[1:] for g in o.globs if g.startswith("!")]
    if positives and not match_any_glob(rel, positives):
        return False
    if negatives and match_any_glob(rel, negatives):
        return False
    return True


def discover(paths: list[str], o: Opts) -> list[str]:
    files = []
    roots = paths or ["."]
    for p in roots:
        if p == "-":
            files.append("-")
            continue
        if os.path.isfile(p):
            rel = p
            if allowed_by_filters(rel, o):
                files.append(p)
            continue
        if not os.path.isdir(p):
            if not o.no_messages:
                print(f"rg: {p}: No such file or directory (os error 2)", file=sys.stderr)
            continue
        root_abs = os.path.abspath(p)
        root_ignores = [] if o.no_ignore else load_ignores(p)
        for dirpath, dirnames, filenames in os.walk(p):
            dirnames[:] = [d for d in dirnames if d != ".git"]
            rel_dir = os.path.relpath(dirpath, p)
            rel_dir = "" if rel_dir == "." else rel_dir
            keep_dirs = []
            for d in dirnames:
                rel = os.path.join(rel_dir, d) if rel_dir else d
                if not o.hidden and d.startswith("."):
                    continue
                if not o.no_ignore and ignored(rel, root_ignores):
                    continue
                keep_dirs.append(d)
            dirnames[:] = sorted(keep_dirs)
            for name in sorted(filenames):
                rel = os.path.join(rel_dir, name) if rel_dir else name
                if not o.hidden and name.startswith("."):
                    continue
                if not o.no_ignore and ignored(rel, root_ignores):
                    continue
                if not allowed_by_filters(rel, o):
                    continue
                files.append(os.path.join(p, rel))
    if o.sort == "path":
        files.sort(reverse=o.sort_reverse)
    return files


def read_file(path: str, o: Opts):
    if path == "-":
        data = sys.stdin.buffer.read()
    else:
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError as e:
            if not o.no_messages:
                print(f"rg: {path}: {e.strerror} (os error {e.errno})", file=sys.stderr)
            return None
    if not o.text and b"\x00" in data[:8192]:
        return None
    return data.decode("utf-8", errors="replace")


def out_path(path: str, o: Opts) -> str:
    if path == "-":
        s = "<stdin>"
    else:
        s = path
        if s.startswith("./") and o.default_path:
            s = s[2:]
    if o.path_separator:
        s = s.replace(os.sep, o.path_separator)
    return s


def write_path_line(path: str, o: Opts, suffix: str = ""):
    sep = "\0" if o.null else "\n"
    sys.stdout.write(out_path(path, o) + suffix + sep)


def replacement_text(m: re.Match, repl: str) -> str:
    out = []
    i = 0
    while i < len(repl):
        if repl[i] == "$":
            if i + 1 < len(repl) and repl[i + 1] == "$":
                out.append("$")
                i += 2
            elif i + 1 < len(repl) and repl[i + 1] == "{":
                j = repl.find("}", i + 2)
                if j != -1:
                    key = repl[i + 2 : j]
                    out.append(group_value(m, key))
                    i = j + 1
                else:
                    out.append("$")
                    i += 1
            else:
                j = i + 1
                while j < len(repl) and (repl[j].isalnum() or repl[j] == "_"):
                    j += 1
                key = repl[i + 1 : j]
                out.append(group_value(m, key) if key else "$")
                i = j
        else:
            out.append(repl[i])
            i += 1
    return "".join(out)


def group_value(m: re.Match, key: str) -> str:
    try:
        if key.isdigit():
            return m.group(int(key)) or ""
        return m.group(key) or ""
    except Exception:
        return ""


def json_data(s: str):
    try:
        s.encode("utf-8")
        return {"text": s}
    except UnicodeError:
        return {"bytes": base64.b64encode(s.encode("utf-8", errors="surrogateescape")).decode("ascii")}


def emit_json(obj):
    print(json.dumps(obj, separators=(",", ":")))


@dataclass
class SearchStats:
    searches: int = 0
    searches_with_match: int = 0
    matched_lines: int = 0
    matches: int = 0
    bytes_searched: int = 0


def line_matches(regex, line: str, o: Opts):
    ms = list(regex.finditer(line))
    ok = bool(ms)
    if o.invert:
        return (not ok), []
    return ok, ms


def format_prefix(path: str, lineno: int, col: int | None, show_file: bool, o: Opts, context=False) -> str:
    if context:
        sep = "-"
    else:
        sep = ":"
    parts = []
    if show_file:
        parts.append(out_path(path, o))
    if o.line_number:
        parts.append(str(lineno))
    if o.column and col is not None:
        parts.append(str(col))
    return (sep.join(parts) + sep) if parts else ""


def search_one(path: str, regex, o: Opts, show_file: bool, stats: SearchStats) -> bool:
    text = read_file(path, o)
    if text is None:
        return False
    stats.searches += 1
    stats.bytes_searched += len(text.encode("utf-8", errors="replace"))
    lines = text.splitlines(True)
    if text and not text.endswith(("\n", "\r")):
        pass
    records = []
    total_matches = 0
    matched_lines = 0
    for idx, line in enumerate(lines, 1):
        body = line[:-1] if line.endswith("\n") else line
        ok, ms = line_matches(regex, body, o)
        if ok:
            matched_lines += 1
            total_matches += max(1, len(ms)) if not o.invert else 1
            records.append((idx, line, ms))
            if o.max_count is not None and matched_lines >= o.max_count:
                break
    has_match = bool(records)
    if has_match:
        stats.searches_with_match += 1
        stats.matched_lines += matched_lines
        stats.matches += total_matches

    if o.quiet:
        return has_match
    if o.files_with_matches:
        if has_match:
            write_path_line(path, o)
        return has_match
    if o.files_without_match:
        if not has_match:
            write_path_line(path, o)
        return not has_match
    if o.count or o.count_matches or (o.count and o.only_matching):
        n = total_matches if (o.count_matches or o.only_matching) else matched_lines
        if n or o.include_zero:
            if show_file:
                sys.stdout.write(f"{out_path(path, o)}:{n}\n")
            else:
                sys.stdout.write(f"{n}\n")
        return has_match
    if o.json:
        if has_match:
            emit_json({"type": "begin", "data": {"path": json_data(out_path(path, o))}})
            offset = 0
            line_offsets = {}
            for i, line in enumerate(lines, 1):
                line_offsets[i] = offset
                offset += len(line.encode("utf-8", errors="replace"))
            for lineno, line, ms in records:
                subs = [{"match": json_data(m.group(0)), "start": m.start(), "end": m.end()} for m in ms]
                emit_json({"type": "match", "data": {"path": json_data(out_path(path, o)), "lines": json_data(line), "line_number": lineno, "absolute_offset": line_offsets.get(lineno, 0), "submatches": subs}})
            emit_json({"type": "end", "data": {"path": json_data(out_path(path, o)), "binary_offset": None, "stats": {"elapsed": {"secs": 0, "nanos": 0, "human": "0.000000s"}, "searches": 1, "searches_with_match": 1, "bytes_searched": len(text), "bytes_printed": 0, "matched_lines": matched_lines, "matches": total_matches}}})
        return has_match

    selected = set(lineno for lineno, _, _ in records)
    if o.before or o.after:
        for lineno, _, _ in records:
            for j in range(max(1, lineno - o.before), min(len(lines), lineno + o.after) + 1):
                selected.add(j)
        order = sorted(selected)
        match_map = {lineno: ms for lineno, _, ms in records}
        for lineno in order:
            line = lines[lineno - 1]
            body = line[:-1] if line.endswith("\n") else line
            context = lineno not in match_map
            content = body.lstrip(" \t") if o.trim else body
            sys.stdout.write(format_prefix(path, lineno, None, show_file, o, context=context) + content + "\n")
        return has_match

    for lineno, line, ms in records:
        body = line[:-1] if line.endswith("\n") else line
        if o.only_matching and not o.invert:
            for m in ms:
                val = replacement_text(m, o.replace) if o.replace is not None else m.group(0)
                col = m.start() + 1
                sys.stdout.write(format_prefix(path, lineno, col, show_file, o) + val + "\n")
        else:
            if o.replace is not None and not o.invert:
                body = regex.sub(lambda m: replacement_text(m, o.replace), body)
            if o.trim:
                body = body.lstrip(" \t")
            col = ms[0].start() + 1 if ms else None
            if o.max_columns and o.max_columns > 0 and len(body.encode("utf-8", errors="replace")) > o.max_columns:
                if o.max_columns_preview:
                    body = body[: o.max_columns]
                else:
                    count = len(ms) if ms else 1
                    body = f"[Omitted long line with {count} matches]"
            sys.stdout.write(format_prefix(path, lineno, col, show_file, o) + body + "\n")
    return has_match


def print_type_list():
    for ty in sorted(TYPE_GLOBS):
        print(f"{ty}: {', '.join(TYPE_GLOBS[ty])}")


def print_files(files: list[str], o: Opts):
    for f in files:
        write_path_line(f, o)


def print_stats(stats: SearchStats, start: float):
    elapsed = max(0.0, time.time() - start)
    print()
    print(f"{stats.matched_lines} matched lines")
    print(f"{stats.searches_with_match} files contained matches")
    print(f"{stats.searches} files searched")
    print(f"{stats.bytes_searched} bytes searched")
    print(f"{elapsed:.6f} seconds")


def main(argv: list[str]) -> int:
    start = time.time()
    o = parse_args(argv)
    if o.type_list:
        print_type_list()
        return 0
    files = discover(o.paths, o)
    if o.files:
        print_files(files, o)
        return 0
    if not files and o.paths == []:
        files = ["-"]
    # rg searches stdin when no explicit path and stdin is not a TTY.
    try:
        mode = os.fstat(0).st_mode
        stdin_pipe = stat.S_ISFIFO(mode) or stat.S_ISREG(mode)
    except OSError:
        stdin_pipe = False
    if o.paths == ["."] and stdin_pipe:
        files = ["-"]
    regex = compile_regex(o)
    if o.line_number is None:
        o.line_number = False
    show_file = o.with_filename
    if show_file is None:
        real_files = [f for f in files if f != "-"]
        searched_dir = files != ["-"] and any(p != "-" and os.path.isdir(p) for p in o.paths)
        show_file = len(files) > 1 or searched_dir or (len(real_files) == 1 and len(o.paths) > 1)
    stats = SearchStats()
    any_match = False
    for f in files:
        if search_one(f, regex, o, show_file, stats):
            any_match = True
            if o.quiet:
                return 0
    if o.json:
        emit_json({"type": "summary", "data": {"elapsed_total": {"secs": 0, "nanos": int((time.time() - start) * 1e9), "human": f"{time.time() - start:.6f}s"}, "stats": {"searches": stats.searches, "searches_with_match": stats.searches_with_match, "bytes_searched": stats.bytes_searched, "bytes_printed": 0, "matched_lines": stats.matched_lines, "matches": stats.matches}}})
    elif o.stats:
        print_stats(stats, start)
    return 0 if any_match else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
