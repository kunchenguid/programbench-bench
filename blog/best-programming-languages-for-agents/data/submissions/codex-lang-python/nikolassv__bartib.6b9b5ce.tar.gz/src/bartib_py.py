#!/usr/bin/env python3
import os
import re
import sys
import subprocess
from dataclasses import dataclass
from datetime import datetime, date, time, timedelta


VERSION = "bartib 1.1.0"
NB = "\u00a0"


@dataclass
class Activity:
    start: datetime
    end: datetime | None
    project: str
    desc: str
    line: int = 0
    raw: str = ""


def eprint(*args):
    print(*args, file=sys.stderr)


def now_minute() -> datetime:
    n = datetime.now()
    return n.replace(second=0, microsecond=0)


def parse_time_arg(s: str) -> time | None:
    if not re.fullmatch(r"\d{1,2}:\d{2}", s or ""):
        print(f'Can not parse "{s}" as time. Argument for -t/--time is ignored (input contains invalid characters)')
        return None
    h, m = map(int, s.split(":"))
    if h > 23 or m > 59:
        print(f'Can not parse "{s}" as time. Argument for -t/--time is ignored (input is out of range)')
        return None
    return time(h, m)


def command_time(value: str | None) -> datetime:
    n = now_minute()
    if value is None:
        return n
    t = parse_time_arg(value)
    if t is None:
        return n
    return datetime.combine(n.date(), t)


def parse_date(s: str) -> date | None:
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        return None


def fmt_dt(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M")


def esc(s: str) -> str:
    return s.replace("\\", "\\\\").replace("|", "\\|")


def unesc(s: str) -> str:
    out = []
    i = 0
    while i < len(s):
        if s[i] == "\\" and i + 1 < len(s):
            out.append(s[i + 1])
            i += 2
        else:
            out.append(s[i])
            i += 1
    return "".join(out)


def split_unescaped(line: str):
    parts, cur, escp = [], [], False
    for ch in line.rstrip("\n"):
        if escp:
            cur.append(ch)
            escp = False
        elif ch == "\\":
            escp = True
            cur.append(ch)
        elif ch == "|":
            parts.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    parts.append("".join(cur).strip())
    return parts


def parse_line(line: str, no: int):
    parts = split_unescaped(line)
    if len(parts) != 3:
        return None
    left, proj, desc = parts
    m = re.fullmatch(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2})(?: - (\d{4}-\d{2}-\d{2} \d{2}:\d{2}))?", left)
    if not m:
        return None
    try:
        start = datetime.strptime(m.group(1), "%Y-%m-%d %H:%M")
        end = datetime.strptime(m.group(2), "%Y-%m-%d %H:%M") if m.group(2) else None
    except Exception:
        return None
    return Activity(start, end, unesc(proj), unesc(desc), no, line.rstrip("\n"))


def read_raw(path: str, must_exist=True):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read().splitlines()
    except FileNotFoundError:
        if must_exist:
            eprint(f"Error: Could not read from file: {path}\n")
            eprint("Caused by:")
            eprint("    No such file or directory (os error 2)")
            sys.exit(1)
        return []


def read_activities(path: str, must_exist=True):
    lines = read_raw(path, must_exist)
    acts, bad = [], []
    for i, line in enumerate(lines, 1):
        if not line.strip():
            continue
        a = parse_line(line, i)
        if a is None:
            bad.append((i, line))
        else:
            acts.append(a)
    return lines, acts, bad


def write_activities(path: str, acts):
    with open(path, "w", encoding="utf-8") as f:
        for a in acts:
            if a.end:
                f.write(f"{fmt_dt(a.start)} - {fmt_dt(a.end)} | {esc(a.project)} | {esc(a.desc)}\n")
            else:
                f.write(f"{fmt_dt(a.start)} | {esc(a.project)} | {esc(a.desc)}\n")


def duration_minutes(a: Activity, rounded=None) -> int:
    st, en = a.start, a.end or now_minute()
    if rounded:
        st = round_dt(st, rounded)
        en = round_dt(en, rounded)
    return max(0, int((en - st).total_seconds() // 60))


def fmt_dur(mins: int) -> str:
    if mins <= 0:
        return "<1m"
    h, m = divmod(mins, 60)
    if h and m:
        return f"{h}h {m}m"
    if h:
        return f"{h}h"
    return f"{m}m"


def parse_round(s):
    if not s:
        return None
    m = re.fullmatch(r"(\d+)([mh])", s)
    if not m:
        return None
    n = int(m.group(1))
    return n * (60 if m.group(2) == "h" else 1)


def round_dt(dt, minutes):
    q = minutes * 60
    ts = int(dt.timestamp())
    return datetime.fromtimestamp(((ts + q // 2) // q) * q)


def pad(s, n):
    s = str(s)
    return s + (NB * max(0, n - len(s)))


def u(s):
    return f"\033[4m{s}\033[0m"


def b(s):
    return f"\033[1m{s}\033[0m"


def g(s):
    return f"\033[32m{s}\033[0m"


def print_table(acts, current=False, grouping=False, include_date=True, rounded=None):
    descw = max([len("Description")] + [len(a.desc) for a in acts])
    projw = max([len("Project")] + [len(a.project) for a in acts])
    if current:
        print()
        print(f"{u(pad('Started At',16))} {u('Description')} {u('Project')} {u('Duration')} ")
        for a in acts:
            print(f"{fmt_dt(a.start)} {pad(a.desc, descw)} {pad(a.project, projw)} {pad(fmt_dur(duration_minutes(a, rounded)),9)} ")
        return
    if grouping:
        print()
        print(f"{u('Started')} {u('Stopped')} {u('Description')} {u('Project')} {u('Duration')} ")
        by = {}
        for a in acts:
            by.setdefault(a.start.date(), []).append(a)
        for d in sorted(by):
            group = by[d]
            print()
            print(b(f"{d.isoformat()}\t{fmt_dur(sum(duration_minutes(x, rounded) for x in group))}"))
            for a in group:
                st = a.start.strftime("%H:%M")
                en = a.end.strftime("%H:%M") if a.end else "-"
                line = f"{pad(st,7)} {pad(en,7)} {pad(a.desc, descw)} {pad(a.project, projw)} {pad(fmt_dur(duration_minutes(a, rounded)),9)} "
                print(g(line) if a.end is None else line)
        return
    first = "Started".ljust(16) if include_date else "Started"
    print()
    print(f"{u(first.replace(' ', NB))} {u('Stopped')} {u('Description')} {u('Project')} {u('Duration')} ")
    for a in acts:
        st = fmt_dt(a.start) if include_date else a.start.strftime("%H:%M")
        en = a.end.strftime("%H:%M") if a.end else "-"
        line = f"{st} {pad(en,7)} {pad(a.desc, descw)} {pad(a.project, projw)} {pad(fmt_dur(duration_minutes(a, rounded)),9)} "
        print(g(line) if a.end is None else line)


def filtered(acts, opts):
    res = list(acts)
    today = now_minute().date()
    if opts.get("today"):
        res = [a for a in res if a.start.date() == today]
    if opts.get("yesterday"):
        res = [a for a in res if a.start.date() == today - timedelta(days=1)]
    if opts.get("date"):
        d = parse_date(opts["date"])
        if d:
            res = [a for a in res if a.start.date() == d]
    if opts.get("current_week") or opts.get("current-week"):
        start = today - timedelta(days=today.weekday())
        end = start + timedelta(days=6)
        res = [a for a in res if start <= a.start.date() <= end]
    if opts.get("last_week") or opts.get("last-week"):
        end = today - timedelta(days=today.weekday() + 1)
        start = end - timedelta(days=6)
        res = [a for a in res if start <= a.start.date() <= end]
    if opts.get("from"):
        d = parse_date(opts["from"])
        if d:
            res = [a for a in res if a.start.date() >= d]
    if opts.get("to"):
        d = parse_date(opts["to"])
        if d:
            res = [a for a in res if a.start.date() <= d]
    if opts.get("project"):
        res = [a for a in res if a.project == opts["project"]]
    if opts.get("number") is not None:
        try:
            n = int(opts["number"])
            res = res[-n:] if n >= 0 else []
        except Exception:
            pass
    return res


def parse_opts(args, specs):
    opts, pos = {}, []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            opts["help"] = True
            i += 1
        elif a in specs:
            key, takes = specs[a]
            if takes:
                if i + 1 >= len(args):
                    eprint(f"error: The argument '{a}' requires a value but none was supplied")
                    sys.exit(1)
                opts[key] = args[i + 1]
                i += 2
            else:
                opts[key] = True
                i += 1
        else:
            pos.append(a)
            i += 1
    return opts, pos


def main_help():
    print("""bartib 1.1.0
Nikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>
A simple timetracker

USAGE:
    executable [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]

SUBCOMMANDS:
    cancel      cancels all currently running activities
    change      changes the current activity
    check       checks file and reports parsing errors
    continue    continues a previous activity
    current     lists all currently running activities
    edit        opens the activity log in an editor
    help        Prints this message or the help of the given subcommand(s)
    last        displays the descriptions and projects of recent activities
    list        list recent activities
    projects    list all projects
    report      reports duration of tracked activities
    sanity      checks sanity of bartib log
    search      search for existing descriptions and projects
    start       starts a new activity
    status      shows current status and time reports for today, current week, and current month
    stop        stops all currently running activities

To get help for a specific subcommand, run `bartib [SUBCOMMAND] --help`.
To get started, view the `start` help with `bartib start --help`""")


HELP = {
"start": """executable-start 
starts a new activity

USAGE:
    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)""",
"stop": """executable-stop 
stops all currently running activities

USAGE:
    executable stop [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -t, --time <TIME>    the time for changing the activity status (HH:MM)""",
"cancel": """executable-cancel 
cancels all currently running activities

USAGE:
    executable cancel

FLAGS:
    -h, --help    Prints help information""",
"current": """executable-current 
lists all currently running activities

USAGE:
    executable current

FLAGS:
    -h, --help    Prints help information""",
"check": """executable-check 
checks file and reports parsing errors

USAGE:
    executable check

FLAGS:
    -h, --help    Prints help information""",
"change": """executable-change 
changes the current activity

USAGE:
    executable change [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)""",
"continue": """executable-continue 
continues a previous activity

USAGE:
    executable continue [OPTIONS] [NUMBER]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)

ARGS:
    <NUMBER>    the number of the activity to continue (see subcommand `last`) [default: 0]""",
"last": """executable-last 
displays the descriptions and projects of recent activities

USAGE:
    executable last [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -n, --number <NUMBER>    maximum number of lines to display [default: 10]""",
"list": """executable-list 
list recent activities

USAGE:
    executable list [FLAGS] [OPTIONS]

FLAGS:
        --current_week    show activities of the current week
    -h, --help            Prints help information
        --last_week       show activities of the last week
        --no_grouping     do not group activities by date in list
        --today           show activities of the current day
        --yesterday       show yesterdays' activities

OPTIONS:
    -d, --date <DATE>          show activities of a certain date only
        --from <FROM_DATE>     begin of date range (inclusive)
    -n, --number <NUMBER>      maximum number of activities to display
    -p, --project <PROJECT>    do list activities for this project only
        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or
                               hours. E.g. 15m or 4h
        --to <TO_DATE>         end of date range (inclusive)""",
"projects": """executable-projects 
list all projects

USAGE:
    executable projects [FLAGS]

FLAGS:
    -c, --current      prints currently running projects only
    -h, --help         Prints help information
    -n, --no-quotes    prints projects without quotes""",
"report": """executable-report 
reports duration of tracked activities

USAGE:
    executable report [FLAGS] [OPTIONS]

FLAGS:
        --current_week    show activities of the current week
    -h, --help            Prints help information
        --last_week       show activities of the last week
        --today           show activities of the current day
        --yesterday       show yesterdays' activities

OPTIONS:
    -d, --date <DATE>          show activities of a certain date only
        --from <FROM_DATE>     begin of date range (inclusive)
    -p, --project <PROJECT>    do report activities for this project only
        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or
                               hours. E.g. 15m or 4h
        --to <DATE>            end of date range (inclusive)""",
"sanity": """executable-sanity 
checks sanity of bartib log

USAGE:
    executable sanity

FLAGS:
    -h, --help    Prints help information""",
"search": """executable-search 
search for existing descriptions and projects

USAGE:
    executable search <SEARCH_TERM>

FLAGS:
    -h, --help    Prints help information

ARGS:
    <SEARCH_TERM>    the search term [default: '']""",
"status": """executable-status 
shows current status and time reports for today, current week, and current month

USAGE:
    executable status [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -p, --project <PROJECT>    show status for this project only""",
"edit": """executable-edit 
opens the activity log in an editor

USAGE:
    executable edit [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -e <editor>        the command to start your preferred text editor [env: EDITOR=]""",
}


def generic_help(cmd):
    if cmd in HELP:
        print(HELP[cmd])
    else:
        main_help()


def need_file(path):
    if not path:
        eprint("Error: Please specify a file with your activity log either as -f option or as BARTIB_FILE environment variable")
        sys.exit(1)
    return path


def cmd_start(path, opts):
    if not opts.get("description") or not opts.get("project"):
        eprint("error: The following required arguments were not provided:")
        if not opts.get("description"):
            eprint("    --description <DESCRIPTION>")
        if not opts.get("project"):
            eprint("    --project <PROJECT>")
        eprint("\nUSAGE:")
        eprint("    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>\n")
        eprint("For more information try --help")
        return 1
    _, acts, _ = read_activities(path, must_exist=False)
    t = command_time(opts.get("time"))
    a = Activity(t, None, opts["project"], opts["description"])
    acts.append(a)
    write_activities(path, acts)
    print(f'Started activity: "{a.desc}" ({a.project}) at {fmt_dt(a.start)}')
    return 0


def cmd_stop(path, opts):
    _, acts, _ = read_activities(path)
    t = command_time(opts.get("time"))
    changed = False
    for a in acts:
        if a.end is None:
            a.end = t
            changed = True
            print(f'Stopped activity: "{a.desc}" ({a.project}) started at {fmt_dt(a.start)} ({fmt_dur(duration_minutes(a))})')
    if changed:
        write_activities(path, acts)
    return 0


def cmd_cancel(path):
    _, acts, _ = read_activities(path)
    keep = []
    for a in acts:
        if a.end is None:
            print(f'Canceled activity: "{a.desc}" ({a.project}) started at {fmt_dt(a.start)}')
        else:
            keep.append(a)
    write_activities(path, keep)
    return 0


def cmd_change(path, opts):
    _, acts, _ = read_activities(path)
    t = command_time(opts.get("time"))
    changed = False
    for a in acts:
        if a.end is None:
            if opts.get("description"):
                a.desc = opts["description"]
            if opts.get("project"):
                a.project = opts["project"]
            a.start = t
            changed = True
            print(f'Changed activity: "{a.desc}" ({a.project}) started at {fmt_dt(a.start)}')
    if changed:
        write_activities(path, acts)
    return 0


def cmd_continue(path, opts, pos):
    _, acts, _ = read_activities(path)
    finished = [a for a in acts if a.end is not None]
    if not finished:
        return 0
    idx = int(pos[0]) if pos else 0
    rev = list(reversed(finished))
    if idx < 0 or idx >= len(rev):
        return 0
    old = rev[idx]
    desc = opts.get("description") or old.desc
    proj = opts.get("project") or old.project
    a = Activity(command_time(opts.get("time")), None, proj, desc)
    acts.append(a)
    write_activities(path, acts)
    print(f'Started activity: "{a.desc}" ({a.project}) at {fmt_dt(a.start)}')
    return 0


def cmd_last(path, opts, search=None):
    _, acts, _ = read_activities(path)
    unique = []
    seen = set()
    for recno, a in enumerate(reversed(acts)):
        key = (a.desc, a.project)
        if key not in seen and (search is None or search.lower() in (a.desc + " " + a.project).lower()):
            seen.add(key)
            unique.append((recno, a))
    n = int(opts.get("number", 10))
    unique = unique[:n]
    shown = list(reversed(unique))
    descw = max([len("Description")] + [len(a.desc) for _, a in shown])
    projw = max([len("Project")] + [len(a.project) for _, a in shown])
    print()
    print(f"{u(' #' + NB)} {u('Description')} {u('Project')} ")
    for recno, a in shown:
        print(f"[{recno}] {pad(a.desc, descw)} {pad(a.project, projw)} ")
    return 0


def cmd_projects(path, opts):
    _, acts, _ = read_activities(path)
    if opts.get("current"):
        acts = [a for a in acts if a.end is None]
    for p in sorted({a.project for a in acts}):
        print(p if opts.get("no_quotes") else f'"{p}"')
    return 0


def cmd_list(path, opts):
    _, acts, _ = read_activities(path)
    acts = filtered(acts, opts)
    rounded = parse_round(opts.get("round"))
    grouping = not opts.get("no_grouping") and not opts.get("date")
    include_date = not opts.get("date")
    print_table(acts, grouping=grouping, include_date=include_date, rounded=rounded)
    return 0


def cmd_report(path, opts):
    _, acts, _ = read_activities(path)
    acts = filtered(acts, opts)
    rounded = parse_round(opts.get("round"))
    projects = {}
    for a in acts:
        projects.setdefault(a.project, {}).setdefault(a.desc, 0)
        projects[a.project][a.desc] += duration_minutes(a, rounded)
    total = 0
    print()
    for p in sorted(projects):
        psum = sum(projects[p].values())
        total += psum
        print(b(f"{p}{'.' * max(0, 10-len(p))} {fmt_dur(psum)}"))
        for d in sorted(projects[p]):
            print(f"    {d}{'.' * max(0, 7-len(d))} {fmt_dur(projects[p][d])}")
        print()
    print(b(f"Total{'.' * 7} {fmt_dur(total)}"))
    print()
    return 0


def cmd_current(path):
    _, acts, _ = read_activities(path)
    cur = [a for a in acts if a.end is None]
    if not cur:
        print("No Activity is currently running")
    else:
        print_table(cur, current=True)
    return 0


def cmd_check(path):
    _, _, bad = read_activities(path)
    if not bad:
        print("All lines in the file have been successfully parsed as activities.")
    else:
        print(f"Found {len(bad)} line(s) with parsing errors\n")
        for no, line in bad:
            print(line)
            print(f"  -> could not parse activity (Line: {no})")
    return 0


def cmd_sanity(path):
    _, acts, _ = read_activities(path)
    any_bad = False
    for a in acts:
        if a.end and a.end < a.start:
            any_bad = True
            print("Activity has negative duration")
            print(f"{a.desc} (Started: {fmt_dt(a.start)}, Ended: {fmt_dt(a.end)}, Line: {a.line})\n")
        elif a.end is None and now_minute() < a.start:
            any_bad = True
            print("Activity has negative duration")
            print(f"{a.desc} (Started: {fmt_dt(a.start)}, Ended: --, Line: {a.line})\n")
    if not any_bad:
        print("All activities look sane.")
    return 0


def cmd_status(path, opts):
    print("Current activities:")
    cmd_current(path)
    base = {"project": opts.get("project")}
    print("\nToday:")
    cmd_report(path, {**base, "today": True})
    print("Current week:")
    cmd_report(path, {**base, "current_week": True})
    first = now_minute().date().replace(day=1).isoformat()
    print("Current month:")
    cmd_report(path, {**base, "from": first})
    return 0


def cmd_edit(path, opts):
    editor = opts.get("editor") or os.environ.get("EDITOR")
    if not editor:
        eprint("Error: No editor specified. Use -e or EDITOR.")
        return 1
    return subprocess.call([editor, path])


def main(argv):
    if not argv:
        main_help()
        return 1
    path = os.environ.get("BARTIB_FILE")
    args = list(argv)
    if args[0] in ("-h", "--help"):
        main_help()
        return 0
    if args[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    if args[0] == "-f":
        if len(args) < 2:
            eprint("error: The argument '-f <FILE>' requires a value but none was supplied")
            return 1
        path = args[1]
        args = args[2:]
    elif args[0].startswith("-f") and len(args[0]) > 2:
        path = args[0][2:]
        args = args[1:]
    if not args:
        main_help()
        return 1
    cmd, rest = args[0], args[1:]
    if cmd == "help":
        if rest:
            generic_help(rest[0])
        else:
            main_help()
        return 0
    specs = {
        "-d": ("description", True), "--description": ("description", True),
        "-p": ("project", True), "--project": ("project", True),
        "-t": ("time", True), "--time": ("time", True),
        "-n": ("number", True), "--number": ("number", True),
        "-c": ("current", False), "--current": ("current", False),
        "-e": ("editor", True), "--editor": ("editor", True),
        "--today": ("today", False), "--yesterday": ("yesterday", False),
        "--current_week": ("current_week", False), "--current-week": ("current_week", False),
        "--last_week": ("last_week", False), "--last-week": ("last_week", False),
        "--no_grouping": ("no_grouping", False), "--no-grouping": ("no_grouping", False),
        "--from": ("from", True), "--to": ("to", True),
        "--round": ("round", True), "--date": ("date", True),
        "-nq": ("no_quotes", False), "--no-quotes": ("no_quotes", False),
    }
    if cmd == "projects":
        specs["-n"] = ("no_quotes", False)
    opts, pos = parse_opts(rest, specs)
    if opts.get("help"):
        generic_help(cmd)
        return 0
    if cmd not in {"start"}:
        path = need_file(path)
    if cmd == "start":
        path = need_file(path)
        return cmd_start(path, opts)
    if cmd == "stop":
        return cmd_stop(path, opts)
    if cmd == "cancel":
        return cmd_cancel(path)
    if cmd == "change":
        return cmd_change(path, opts)
    if cmd == "continue":
        return cmd_continue(path, opts, pos)
    if cmd == "current":
        return cmd_current(path)
    if cmd == "check":
        return cmd_check(path)
    if cmd == "sanity":
        return cmd_sanity(path)
    if cmd == "last":
        return cmd_last(path, opts)
    if cmd == "search":
        return cmd_last(path, {"number": 10}, pos[0] if pos else "")
    if cmd == "projects":
        return cmd_projects(path, opts)
    if cmd == "list":
        return cmd_list(path, opts)
    if cmd == "report":
        return cmd_report(path, opts)
    if cmd == "status":
        return cmd_status(path, opts)
    if cmd == "edit":
        return cmd_edit(path, opts)
    eprint(f"error: Found argument '{cmd}' which wasn't expected, or isn't valid in this context")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
