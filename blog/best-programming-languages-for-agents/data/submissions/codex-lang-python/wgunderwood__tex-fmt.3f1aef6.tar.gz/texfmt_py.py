#!/usr/bin/env python3
import argparse
import os
import re
import sys
import textwrap
from dataclasses import dataclass, field

VERSION = "tex-fmt 0.5.6"
LISTS = {"itemize", "enumerate", "description", "inlineroman", "inventory"}
VERBATIMS = {"verbatim", "Verbatim", "lstlisting", "minted", "comment"}
NO_INDENT = {"document"}
EXTS = {".tex", ".bib", ".cls", ".sty"}


@dataclass
class Opts:
    check: bool = False
    print_: bool = False
    fail_on_change: bool = False
    recursive: bool = False
    wrap: bool = True
    wraplen: int = 80
    tabsize: int = 2
    usetabs: bool = False
    stdin: bool = False
    config: str | None = None
    noconfig: bool = False
    verbosity: str = "warn"
    lists: set[str] = field(default_factory=lambda: set(LISTS))
    verbatims: set[str] = field(default_factory=lambda: set(VERBATIMS))
    no_indent_envs: set[str] = field(default_factory=lambda: set(NO_INDENT))
    wrap_chars: list[str] = field(default_factory=list)
    files: list[str] = field(default_factory=list)

    @property
    def unit(self) -> str:
        if self.usetabs:
            return "\t" * self.tabsize
        return " " * self.tabsize


def help_text() -> str:
    return """tex-fmt 0.5.6

LaTeX formatter written in Rust

Usage: executable [OPTIONS] [files]...

Arguments:
  [files]...  List of files to be formatted

Options:
  -c, --check               Check formatting, do not modify files
  -p, --print               Print to stdout, do not modify files
  -f, --fail-on-change      Format files and return non-zero exit code if files are modified
  -n, --nowrap              Do not wrap long lines
  -l, --wraplen <N>         Line length for wrapping [default: 80]
  -t, --tabsize <N>         Number of characters to use as tab size [default: 2]
      --usetabs             Use tabs instead of spaces for indentation
  -s, --stdin               Process stdin as a single file, output to stdout
      --config <PATH>       Path to config file
      --noconfig            Do not read any config file
  -v, --verbose             Show info messages
  -q, --quiet               Hide warning messages
      --trace               Show trace messages
      --completion <SHELL>  Generate shell completion script [possible values: bash, elvish, fish, powershell, zsh]
      --man                 Generate man page
      --args                Print arguments passed to tex-fmt and exit
  -r, --recursive           Recursively search for files to format
  -h, --help                Print help
  -V, --version             Print version
"""


def parse_bool(s: str) -> bool:
    return s.strip().lower() in {"true", "1", "yes", "on"}


def parse_array(s: str) -> list[str]:
    return re.findall(r'"([^"]*)"', s)


def apply_config(opts: Opts) -> None:
    if opts.noconfig:
        return
    paths = []
    if opts.config:
        paths.append(opts.config)
    else:
        paths.append("tex-fmt.toml")
        try:
            top = os.popen("git rev-parse --show-toplevel 2>/dev/null").read().strip()
            if top:
                paths.append(os.path.join(top, "tex-fmt.toml"))
        except Exception:
            pass
        home = os.environ.get("HOME")
        if home:
            paths.append(os.path.join(home, ".config", "tex-fmt", "tex-fmt.toml"))
    seen = set()
    for path in paths:
        if not path or path in seen or not os.path.exists(path):
            seen.add(path)
            continue
        try:
            data = open(path, encoding="utf-8").read().splitlines()
        except OSError:
            continue
        for raw in data:
            line = raw.split("#", 1)[0].strip()
            if "=" not in line:
                continue
            key, val = [x.strip() for x in line.split("=", 1)]
            if key == "check":
                opts.check = parse_bool(val)
            elif key == "print":
                opts.print_ = parse_bool(val)
            elif key == "fail-on-change":
                opts.fail_on_change = parse_bool(val)
            elif key == "wrap":
                opts.wrap = parse_bool(val)
            elif key == "wraplen":
                opts.wraplen = int(val)
            elif key == "tabsize":
                opts.tabsize = int(val)
            elif key == "tabchar":
                opts.usetabs = "tab" in val
            elif key == "stdin":
                opts.stdin = parse_bool(val)
            elif key == "lists":
                opts.lists |= set(parse_array(val))
            elif key == "verbatims":
                opts.verbatims |= set(parse_array(val))
            elif key == "no-indent-envs":
                opts.no_indent_envs |= set(parse_array(val))
            elif key == "wrap-chars":
                opts.wrap_chars = parse_array(val)
            elif key == "verbosity":
                opts.verbosity = val.strip('"')
        break


def parse_args(argv: list[str]) -> tuple[Opts, str | None, str | None, bool]:
    if "--help" in argv or "-h" in argv:
        return Opts(), "help", None, False
    if "--version" in argv or "-V" in argv:
        return Opts(), "version", None, False
    if "--man" in argv:
        return Opts(), "man", None, False
    if "--completion" in argv:
        i = argv.index("--completion")
        shell = argv[i + 1] if i + 1 < len(argv) else ""
        return Opts(), "completion", shell, False

    opts = Opts()
    cli_set = set()
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-c", "--check"):
            opts.check = True; cli_set.add("check")
        elif a in ("-p", "--print"):
            opts.print_ = True; cli_set.add("print")
        elif a in ("-f", "--fail-on-change"):
            opts.fail_on_change = True; cli_set.add("fail")
        elif a in ("-r", "--recursive"):
            opts.recursive = True
        elif a in ("-n", "--nowrap"):
            opts.wrap = False; cli_set.add("wrap")
        elif a in ("-s", "--stdin"):
            opts.stdin = True; cli_set.add("stdin")
        elif a in ("-v", "--verbose"):
            opts.verbosity = "info"
        elif a in ("-q", "--quiet"):
            opts.verbosity = "error"
        elif a == "--trace":
            opts.verbosity = "trace"
        elif a == "--usetabs":
            opts.usetabs = True; cli_set.add("usetabs")
        elif a in ("-l", "--wraplen"):
            i += 1; opts.wraplen = int(argv[i]); cli_set.add("wraplen")
        elif a in ("-t", "--tabsize"):
            i += 1; opts.tabsize = int(argv[i]); cli_set.add("tabsize")
        elif a == "--config":
            i += 1; opts.config = argv[i]
        elif a == "--noconfig":
            opts.noconfig = True
        elif a == "--args":
            pass
        elif a.startswith("-"):
            sys.stderr.write(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] [files]...\n\nFor more information, try '--help'.\n")
            raise SystemExit(2)
        else:
            files.append(a)
        i += 1
    before = opts.__dict__.copy()
    apply_config(opts)
    # Re-apply command-line precedence for common flags by re-parsing once.
    for k, v in before.items():
        if k in {"files", "lists", "verbatims", "no_indent_envs", "wrap_chars"}:
            continue
    opts.files = files
    # Simple second pass is enough to restore scalar CLI overrides.
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-c", "--check"): opts.check = True
        elif a in ("-p", "--print"): opts.print_ = True
        elif a in ("-f", "--fail-on-change"): opts.fail_on_change = True
        elif a in ("-n", "--nowrap"): opts.wrap = False
        elif a in ("-s", "--stdin"): opts.stdin = True
        elif a == "--usetabs": opts.usetabs = True
        elif a in ("-l", "--wraplen"): i += 1; opts.wraplen = int(argv[i])
        elif a in ("-t", "--tabsize"): i += 1; opts.tabsize = int(argv[i])
        i += 1
    if opts.stdin:
        opts.print_ = True
        opts.fail_on_change = True
    return opts, "args" if "--args" in argv else None, None, False


def split_end(line: str) -> list[str]:
    m = re.search(r"(.+?)\s*(\\end\{[^}]+\})\s*$", line)
    if m and not m.group(1).lstrip().startswith("%"):
        return [m.group(1).rstrip(), m.group(2)]
    return [line]


def wrap_line(line: str, opts: Opts, cont_extra: int = 0) -> list[str]:
    if not opts.wrap or len(line.expandtabs(opts.tabsize)) <= opts.wraplen:
        return [line]
    stripped = line.lstrip(" \t")
    prefix = line[: len(line) - len(stripped)]
    if stripped.startswith("\\") or stripped.startswith("%") or not stripped:
        return [line]
    width = max(20, opts.wraplen - 10 if opts.wraplen >= 70 else opts.wraplen)
    subsequent = prefix + opts.unit * cont_extra
    return textwrap.wrap(
        stripped,
        width=width,
        initial_indent=prefix,
        subsequent_indent=subsequent,
        break_long_words=False,
        break_on_hyphens=False,
    ) or [line]


def count_braces(s: str) -> int:
    # Ignore escaped braces and comments; inline balanced command arguments cancel out naturally.
    s = re.split(r"(?<!\\)%", s, 1)[0]
    opens = len(re.findall(r"(?<!\\)[{\[(]", s))
    closes = len(re.findall(r"(?<!\\)[}\])]", s))
    return opens - closes


def format_text(src: str, opts: Opts) -> str:
    lines = src.splitlines()
    out: list[str] = []
    level = 0
    item_stack: list[int] = []
    verb_env: str | None = None
    off = False
    for raw in lines:
        if raw.endswith("% tex-fmt: skip"):
            out.append(raw.rstrip())
            continue
        stripped = raw.strip()
        if "% tex-fmt: off" in raw:
            off = True
            out.append(stripped if stripped.startswith("%") else raw.rstrip())
            continue
        if off:
            out.append(raw.rstrip())
            if "% tex-fmt: on" in raw:
                off = False
            continue
        if verb_env:
            out.append(raw.rstrip())
            if re.search(r"\\end\{" + re.escape(verb_env) + r"\}", stripped):
                verb_env = None
            continue
        if stripped == "":
            if out and out[-1] == "":
                continue
            out.append("")
            continue
        for part in split_end(stripped):
            stripped = part.strip()
            begin = re.match(r"\\begin\{([^}]+)\}", stripped)
            end = re.match(r"\\end\{([^}]+)\}", stripped)
            close_only = stripped[0] in "})]" or end or stripped in {"\\]", "\\)", "$$"} or stripped.startswith("\\right")
            if close_only:
                level = max(0, level - 1)
            this_level = level
            item_level = item_stack[-1] if item_stack else None
            if item_level is not None and not stripped.startswith("\\item") and not end:
                this_level = max(this_level, item_level + 1)
            if stripped.startswith("%"):
                line = opts.unit * this_level + stripped
            else:
                line = opts.unit * this_level + stripped
            cont_extra = 1 if stripped.startswith("\\item") or (item_level is not None and not stripped.startswith("\\")) else 0
            out.extend(wrap_line(line, opts, cont_extra))
            if end and end.group(1) in opts.lists:
                if item_stack:
                    item_stack.pop()
                level = item_stack[-1] if item_stack else this_level
            if begin:
                env = begin.group(1)
                level = max(level, this_level)
                if env in opts.verbatims:
                    verb_env = env
                if env not in opts.no_indent_envs and env not in opts.verbatims:
                    level += 1
                if env in opts.lists:
                    item_stack.append(level)
                continue
            if stripped in {"\\[", "\\("}:
                level += 1
            elif stripped == "$$":
                pass
            elif stripped.startswith("\\item"):
                if item_level is None:
                    item_stack.append(this_level)
                    item_level = this_level
                level = max(level, item_level)
            else:
                delta = count_braces(stripped)
                if delta > 0 and not (begin or stripped.startswith("\\item")):
                    level += delta
    return "\n".join(out) + ("\n" if src.endswith("\n") or lines else "")


def args_output(opts: Opts) -> str:
    wrapmin = max(0, opts.wraplen - 10)
    def b(x): return "true" if x else "false"
    lines = [
        "tex-fmt",
        f"  check:                   {b(opts.check)}",
        f"  print:                   {b(opts.print_)}",
        f"  fail-on-change:          {b(opts.fail_on_change or opts.print_)}",
        f"  wrap:                    {b(opts.wrap)}",
        f"  wraplen:                 {opts.wraplen}",
        f"  wrapmin:                 {wrapmin}",
        f"  tabsize:                 {opts.tabsize}",
        f"  tabchar:                 {'tab' if opts.usetabs else 'space'}",
        f"  stdin:                   {b(opts.stdin)}",
        f"  config:                  {'Some(' + opts.config + ')' if opts.config else 'None'}",
        f"  verbosity:               {opts.verbosity}",
    ]
    ordered_lists = [x for x in ["itemize", "enumerate", "description", "inlineroman", "inventory"] if x in opts.lists] + sorted(opts.lists - LISTS)
    ordered_verbs = [x for x in ["verbatim", "Verbatim", "lstlisting", "minted", "comment"] if x in opts.verbatims] + sorted(opts.verbatims - VERBATIMS)
    ordered_noindent = [x for x in ["document"] if x in opts.no_indent_envs] + sorted(opts.no_indent_envs - NO_INDENT)
    for title, vals in [("lists", ordered_lists), ("verbatims", ordered_verbs), ("no-indent-envs", ordered_noindent), ("wrap-chars", opts.wrap_chars)]:
        if vals:
            lines.append(f"  {title}:".ljust(27) + vals[0])
            for v in vals[1:]:
                lines.append(f"                           {v}")
        else:
            lines.append(f"  {title}:".ljust(28))
    if opts.files:
        lines.append(f"  files:                   {opts.files[0]}")
        for f in opts.files[1:]:
            lines.append(f"                           {f}")
    else:
        lines.append("  files:                   ")
    return "\n".join(lines) + "\n"


def discover(files: list[str]) -> list[str]:
    roots = files or ["."]
    found = []
    for root in roots:
        if os.path.isfile(root):
            if os.path.splitext(root)[1] in EXTS:
                found.append(root)
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in {".git", "target", "eval"}]
            for name in filenames:
                if os.path.splitext(name)[1] in EXTS:
                    found.append(os.path.join(dirpath, name))
    return sorted(found)


def process_file(path: str, opts: Opts) -> int:
    try:
        src = open(path, encoding="utf-8").read()
    except OSError:
        if opts.verbosity != "error":
            sys.stderr.write(f"ERROR: tex-fmt {path}: Could not open file. \n")
        return 1
    fmt = format_text(src, opts)
    changed = fmt != src
    if opts.check:
        if changed:
            if opts.verbosity != "error":
                sys.stderr.write(f"ERROR: tex-fmt {path}: Incorrect formatting. \n")
            return 1
        return 0
    if opts.print_:
        sys.stdout.write(fmt)
        return 0
    if changed:
        open(path, "w", encoding="utf-8").write(fmt)
        return 1 if opts.fail_on_change else 0
    return 0


def main(argv: list[str]) -> int:
    try:
        opts, mode, extra, _ = parse_args(argv)
    except SystemExit as e:
        return int(e.code)
    if mode == "help":
        sys.stdout.write(help_text())
        return 0
    if mode == "version":
        print(VERSION)
        return 0
    if mode == "man":
        sys.stdout.write(".TH tex-fmt 1\n.SH NAME\ntex-fmt \\- LaTeX formatter written in Rust\n")
        return 0
    if mode == "completion":
        sys.stdout.write(f"# completion for {extra or 'bash'}\n")
        return 0
    if mode == "args":
        sys.stdout.write(args_output(opts))
        return 0
    if opts.stdin:
        sys.stdout.write(format_text(sys.stdin.read(), opts))
        return 0
    files = discover(opts.files) if opts.recursive else opts.files
    if not files:
        if opts.verbosity != "error":
            sys.stderr.write("ERROR: tex-fmt : No files specified. Provide filenames, or pass --recursive or --stdin. \n")
        return 1
    code = 0
    for path in files:
        code = max(code, process_file(path, opts))
    return 1 if code else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
