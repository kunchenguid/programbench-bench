#!/usr/bin/env python3
import json
import os
import shutil
import sqlite3
import sys
from pathlib import Path

try:
    import tomllib
except Exception:  # pragma: no cover
    tomllib = None


VERSION = "tui-journal 0.16.1"

THEME_DEFAULTS = """[general.input_block_active]
fg = "LightYellow"
modifiers = ""

[general.input_block_invalid]
fg = "LightRed"
modifiers = ""

[general.input_corsur_active]
fg = "Black"
bg = "LightYellow"
modifiers = ""

[general.input_corsur_invalid]
fg = "Black"
bg = "LightRed"
modifiers = ""

[general.list_item_selected]
fg = "LightYellow"
modifiers = "BOLD"

[general.list_highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[general.list_highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = ""

[journals_list.block_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.block_inactive]
fg = "#AAAAC8"
modifiers = ""

[journals_list.block_multi_select]
fg = "Yellow"
modifiers = "BOLD | ITALIC"

[journals_list.highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = "BOLD"

[journals_list.highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = "BOLD"

[journals_list.title_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.title_inactive]
fg = "#AAAAC8"
modifiers = "BOLD"

[journals_list.title_selected]
fg = "Yellow"
modifiers = "BOLD"

[journals_list.date_priority]
fg = "LightBlue"
modifiers = ""

[journals_list.tags_default]
fg = "LightCyan"
modifiers = "DIM"

[editor.block_insert]
fg = "LightGreen"
modifiers = "BOLD"

[editor.block_visual]
fg = "Blue"
modifiers = "BOLD"

[editor.block_normal_active]
fg = "Reset"
modifiers = "BOLD"

[editor.block_normal_inactive]
fg = "#AAAAC8"
modifiers = ""

[editor.cursor_normal]
fg = "Black"
bg = "White"
modifiers = ""

[editor.cursor_insert]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[editor.cursor_visual]
fg = "Black"
bg = "Blue"
modifiers = ""

[editor.selection_style]
fg = "Black"
bg = "White"
modifiers = ""

[msgbox]
error = "LightRed"
warning = "Yellow"
info = "LightGreen"
question = "LightBlue"
"""


def home() -> str:
    return os.path.expanduser("~")


def default_config_dir() -> str:
    return os.path.join(home(), ".config", "tui-journal")


def default_log_path() -> str:
    return os.path.join(home(), ".cache", "tui-journal", "tui-journal.log")


def default_state_dir() -> str:
    return os.path.join(home(), ".local", "state", "tui-journal")


def default_data_dir() -> str:
    return os.path.join(home(), "tui-journal")


def ensure_log(path: str) -> None:
    try:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).touch(exist_ok=True)
    except Exception:
        pass


def root_help(prog: str) -> str:
    return f"""Tui app allows writing and managing journals/notes from within the terminal With different local back-ends

Usage: {prog} [OPTIONS] [COMMAND]

Commands:
  print-config     Print the current settings including the paths for the back-end files [aliases: pc]
  import-journals  Import journals from the given transfer JSON file to the current back-end file [aliases: imj]
  assign-priority  Assign priority for all the entries with empty priority field [aliases: ap]
  theme            Provides commands regarding changing themes and styles of the app [aliases: style]
  help             Print this message or the help of the given subcommand(s)

Options:
  -j, --json-file-path <FILE PATH>    Sets the entries Json file path and starts using it
  -s, --sqlite-file-path <FILE PATH>  Sets the entries sqlite file path and starts using it
  -b, --backend-type <BACKEND_TYPE>   Sets the backend type and starts using it [possible values: json, sqlite]
  -c, --config <DIR PATH>             Specifies the path for the configuration directory.
                                      Configuration files is considered as root for themes file too.
                                      It still accepts the path for configuration file for backward compatibility.
                                      (default path: {default_config_dir()})
  -v, --verbose...                    Increases logging verbosity each use for up to 3 times
  -l, --log <FILE PATH>               Specifies a file to use for logging
                                      (default file: {default_log_path()})
  -h, --help                          Print help
  -V, --version                       Print version"""


def theme_help(prog: str) -> str:
    return f"""Provides commands regarding changing themes and styles of the app

Usage: {prog} theme <COMMAND>

Commands:
  print-path      Prints the path to the user themes file [aliases: path]
  print-default   Dumps the styles with the default values to be used as a reference and base for user custom themes [aliases: default]
  write-defaults  Creates user custom themes file if doesn't exist then writes the default styles to it [aliases: write]
  help            Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help"""


SUB_HELP = {
    "print-config": ("Print the current settings including the paths for the back-end files", "print-config", "Options:\n  -h, --help  Print help"),
    "import-journals": ("Import journals from the given transfer JSON file to the current back-end file", "import-journals --path <FILE PATH>", "Options:\n  -p, --path <FILE PATH>  Path of the JSON file to import from\n  -h, --help              Print help"),
    "assign-priority": ("Assign priority for all the entries with empty priority field", "assign-priority <PRIORITY>", "Arguments:\n  <PRIORITY>  Priority value (Positive number)\n\nOptions:\n  -h, --help  Print help"),
    "theme print-path": ("Prints the path to the user themes file", "theme print-path", "Options:\n  -h, --help  Print help"),
    "theme print-default": ("Dumps the styles with the default values to be used as a reference and base for user custom themes", "theme print-default", "Options:\n  -h, --help  Print help"),
    "theme write-defaults": ("Creates user custom themes file if doesn't exist then writes the default styles to it", "theme write-defaults", "Options:\n  -h, --help  Print help"),
}


def sub_help(prog: str, key: str) -> str:
    desc, usage, rest = SUB_HELP[key]
    return f"{desc}\n\nUsage: {prog} {usage}\n\n{rest}"


def die(msg: str, code: int = 1) -> int:
    print(msg, file=sys.stderr)
    return code


def clap_error(msg: str, usage: str | None = None) -> int:
    print(f"error: {msg}", file=sys.stderr)
    if usage:
        print(file=sys.stderr)
        print(f"Usage: executable {usage}", file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def empty_config() -> dict:
    return {
        "backend_type": "Sqlite",
        "scroll_per_page": 5,
        "sync_os_clipboard": False,
        "history_limit": 10,
        "colored_tags": True,
        "datum_visibility": "show",
        "app_state_dir": default_state_dir(),
        "export": {"show_confirmation": True},
        "external_editor": {"auto_save": False, "temp_file_extension": "txt"},
        "json_backend": {"file_path": os.path.join(default_data_dir(), "entries.json")},
        "sqlite_backend": {"file_path": os.path.join(default_data_dir(), "entries.db")},
    }


def merge(dst: dict, src: dict) -> None:
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            merge(dst[k], v)
        else:
            dst[k] = v


def read_toml(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    try:
        if tomllib:
            with open(path, "rb") as f:
                return tomllib.load(f)
    except Exception:
        return {}
    return {}


def config_file_for(config_arg: str | None) -> tuple[str, str | None, bool]:
    if not config_arg:
        d = default_config_dir()
        return os.path.join(d, "config.toml"), d, False
    if os.path.isdir(config_arg):
        return os.path.join(config_arg, "config.toml"), config_arg, False
    if os.path.exists(config_arg):
        return config_arg, None, True
    return "", config_arg, False


def load_config(opts: dict) -> tuple[dict | None, int]:
    cfg_path, cfg_dir, legacy_file = config_file_for(opts.get("config"))
    if opts.get("config") and not cfg_path and cfg_dir:
        return None, die(f"Error: Provided custom directory doesn't exit. Path: {cfg_dir}")
    cfg = empty_config()
    merge(cfg, read_toml(cfg_path))
    if opts.get("json"):
        cfg["backend_type"] = "Json"
        cfg["json_backend"]["file_path"] = opts["json"]
    if opts.get("sqlite"):
        cfg["backend_type"] = "Sqlite"
        cfg["sqlite_backend"]["file_path"] = opts["sqlite"]
    if opts.get("backend"):
        cfg["backend_type"] = "Json" if opts["backend"] == "json" else "Sqlite"
    cfg["_config_dir"] = cfg_dir
    cfg["_legacy_file"] = legacy_file
    return cfg, 0


def fmt_bool(v: bool) -> str:
    return "true" if bool(v) else "false"


def print_config(cfg: dict) -> None:
    print(f'backend_type = "{cfg.get("backend_type", "Sqlite")}"')
    print(f'scroll_per_page = {cfg.get("scroll_per_page", 5)}')
    print(f"sync_os_clipboard = {fmt_bool(cfg.get('sync_os_clipboard', False))}")
    print(f"history_limit = {cfg.get('history_limit', 10)}")
    print(f"colored_tags = {fmt_bool(cfg.get('colored_tags', True))}")
    print(f'datum_visibility = "{cfg.get("datum_visibility", "show")}"')
    print(f'app_state_dir = "{cfg.get("app_state_dir", default_state_dir())}"')
    print()
    print("[export]")
    print(f"show_confirmation = {fmt_bool(cfg.get('export', {}).get('show_confirmation', True))}")
    print()
    print("[external_editor]")
    ee = cfg.get("external_editor", {})
    print(f"auto_save = {fmt_bool(ee.get('auto_save', False))}")
    print(f'temp_file_extension = "{ee.get("temp_file_extension", "txt")}"')
    print()
    print("[json_backend]")
    print(f'file_path = "{cfg.get("json_backend", {}).get("file_path", os.path.join(default_data_dir(), "entries.json"))}"')
    print()
    print("[sqlite_backend]")
    print(f'file_path = "{cfg.get("sqlite_backend", {}).get("file_path", os.path.join(default_data_dir(), "entries.db"))}"')


def theme_path(cfg: dict) -> str:
    if cfg.get("_legacy_file"):
        print("INFO: Custom config directory is ignored in themese because it's not a directory.")
        return os.path.join(default_config_dir(), "themes.toml")
    return os.path.join(cfg.get("_config_dir") or default_config_dir(), "themes.toml")


def read_entries(path: str):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return []
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for k in ("journals", "entries", "items"):
            if isinstance(data.get(k), list):
                return data[k]
    return []


def write_entries(path: str, entries) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)
        f.write("\n")


def import_journals(cfg: dict, src: str) -> int:
    incoming = read_entries(src)
    if cfg.get("backend_type") == "Sqlite":
        return sqlite_import(cfg["sqlite_backend"]["file_path"], incoming)
    dest = cfg["json_backend"]["file_path"]
    current = read_entries(dest)
    current.extend(incoming)
    write_entries(dest, current)
    print(f"Imported {len(incoming)} journals")
    return 0


def sqlite_import(path: str, entries) -> int:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path)
    try:
        con.execute(
            "CREATE TABLE IF NOT EXISTS journals (id TEXT PRIMARY KEY, data TEXT NOT NULL, priority INTEGER)"
        )
        for i, ent in enumerate(entries):
            jid = str(ent.get("id") or ent.get("uuid") or ent.get("created_at") or i)
            pr = ent.get("priority") if isinstance(ent, dict) else None
            con.execute(
                "INSERT OR REPLACE INTO journals(id, data, priority) VALUES(?, ?, ?)",
                (jid, json.dumps(ent, ensure_ascii=False), pr),
            )
        con.commit()
    finally:
        con.close()
    print(f"Imported {len(entries)} journals")
    return 0


def assign_priority(cfg: dict, priority: int) -> int:
    if cfg.get("backend_type") == "Sqlite":
        path = cfg["sqlite_backend"]["file_path"]
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(path)
        try:
            con.execute("CREATE TABLE IF NOT EXISTS journals (id TEXT PRIMARY KEY, data TEXT NOT NULL, priority INTEGER)")
            con.execute("UPDATE journals SET priority=? WHERE priority IS NULL", (priority,))
            count = con.total_changes
            con.commit()
        finally:
            con.close()
        print(f"Assigned priority {priority} to {count} journals")
        return 0
    path = cfg["json_backend"]["file_path"]
    entries = read_entries(path)
    count = 0
    for ent in entries:
        if isinstance(ent, dict) and (ent.get("priority") is None or ent.get("priority") == ""):
            ent["priority"] = priority
            count += 1
    write_entries(path, entries)
    print(f"Assigned priority {priority} to {count} journals")
    return 0


def parse_global(argv: list[str]) -> tuple[dict, list[str], int | None]:
    opts = {"json": None, "sqlite": None, "backend": None, "config": None, "log": default_log_path()}
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(root_help("executable"))
            return opts, [], 0
        if a in ("-V", "--version"):
            print(VERSION)
            return opts, [], 0
        if a in ("-v", "--verbose"):
            i += 1
            continue
        if a.startswith("-v") and set(a[1:]) == {"v"}:
            i += 1
            continue
        if a in ("-j", "--json-file-path", "-s", "--sqlite-file-path", "-b", "--backend-type", "-c", "--config", "-l", "--log"):
            if i + 1 >= len(argv):
                return opts, [], clap_error(f"a value is required for '{a} <FILE PATH>'")
            val = argv[i + 1]
            if a in ("-j", "--json-file-path"):
                opts["json"] = val
            elif a in ("-s", "--sqlite-file-path"):
                opts["sqlite"] = val
            elif a in ("-b", "--backend-type"):
                if val not in ("json", "sqlite"):
                    return opts, [], clap_error(f"invalid value '{val}' for '--backend-type <BACKEND_TYPE>'\n  [possible values: json, sqlite]", None)
                opts["backend"] = val
            elif a in ("-c", "--config"):
                opts["config"] = val
            elif a in ("-l", "--log"):
                opts["log"] = val
            i += 2
            continue
        rest = argv[i:]
        break
    ensure_log(opts["log"])
    return opts, rest, None


def main(argv: list[str]) -> int:
    opts, args, early = parse_global(argv)
    if early is not None:
        return early
    cfg, code = load_config(opts)
    if code:
        return code
    if not args:
        return die("Error: No such device or address (os error 6)")
    cmd = args[0]
    if cmd == "help":
        print(root_help("executable") if len(args) == 1 else sub_help("executable", args[1]))
        return 0
    if cmd in ("print-config", "pc"):
        if len(args) > 1 and args[1] in ("-h", "--help"):
            print(sub_help("executable", "print-config"))
            return 0
        print_config(cfg)
        return 0
    if cmd in ("theme", "style"):
        return handle_theme(cfg, args[1:])
    if cmd in ("import-journals", "imj"):
        return handle_import(cfg, args[1:])
    if cmd in ("assign-priority", "ap"):
        return handle_assign(cfg, args[1:])
    return clap_error(f"unrecognized subcommand '{cmd}'", "[OPTIONS] [COMMAND]")


def handle_theme(cfg: dict, args: list[str]) -> int:
    if not args or args[0] in ("-h", "--help", "help"):
        print(theme_help("executable"))
        return 0
    cmd = args[0]
    if cmd in ("print-path", "path"):
        if len(args) > 1 and args[1] in ("-h", "--help"):
            print(sub_help("executable", "theme print-path"))
        else:
            print(theme_path(cfg))
        return 0
    if cmd in ("print-default", "default"):
        if len(args) > 1 and args[1] in ("-h", "--help"):
            print(sub_help("executable", "theme print-default"))
        else:
            print(THEME_DEFAULTS, end="")
        return 0
    if cmd in ("write-defaults", "write"):
        if len(args) > 1 and args[1] in ("-h", "--help"):
            print(sub_help("executable", "theme write-defaults"))
            return 0
        path = theme_path(cfg)
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(THEME_DEFAULTS)
        except Exception as e:
            print("Error: Error while writing default themes to file", file=sys.stderr)
            print(file=sys.stderr)
            print("Caused by:", file=sys.stderr)
            print(f"    {e}", file=sys.stderr)
            return 1
        print(f"Default themes have been written to {path}")
        return 0
    return clap_error(f"unrecognized subcommand '{cmd}'", "theme <COMMAND>")


def handle_import(cfg: dict, args: list[str]) -> int:
    if args and args[0] in ("-h", "--help"):
        print(sub_help("executable", "import-journals"))
        return 0
    path = None
    i = 0
    while i < len(args):
        if args[i] in ("-p", "--path") and i + 1 < len(args):
            path = args[i + 1]
            i += 2
        else:
            i += 1
    if not path:
        return clap_error("the following required arguments were not provided:\n  --path <FILE PATH>", "import-journals --path <FILE PATH>")
    try:
        return import_journals(cfg, path)
    except Exception as e:
        return die(f"Error: {e}")


def handle_assign(cfg: dict, args: list[str]) -> int:
    if args and args[0] in ("-h", "--help"):
        print(sub_help("executable", "assign-priority"))
        return 0
    if not args:
        return clap_error("the following required arguments were not provided:\n  <PRIORITY>", "assign-priority <PRIORITY>")
    try:
        priority = int(args[0])
    except Exception:
        return clap_error(f"invalid value '{args[0]}' for '<PRIORITY>': invalid digit found in string")
    if priority < 0:
        return clap_error(f"invalid value '{args[0]}' for '<PRIORITY>': number would be negative")
    try:
        return assign_priority(cfg, priority)
    except Exception as e:
        return die(f"Error: {e}")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
