#!/usr/bin/env python3
import os
import sys
import shutil

HELP = """ov is a feature rich pager(such as more/less).
It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).

Usage:
  ov [flags] [FILE]...

Flags:
Short   Long                                    Purpose
  -l, --align                                   align the output columns for better readability
  -C, --alternate-rows                          alternately change the line color
      --caption string                          custom caption
  -i, --case-sensitive                          case-sensitive in search
  -d, --column-delimiter character              column delimiter character (default ",")
  -c, --column-mode                             column mode
      --column-rainbow                          column mode to rainbow
      --column-width                            column mode for width
      --completion string                       generate completion script [bash|zsh|fish|powershell]
      --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)
      --converter string                        converter [es|raw|align] (default "es")
      --debug                                   debug mode
      --disable-column-cycle                    disable column cycling
      --disable-mouse                           disable mouse support
  -e, --exec                                    command execution result instead of file
  -X, --exit-write                              output the current screen when exiting
  -a, --exit-write-after int                    number after the current lines when exiting
  -b, --exit-write-before int                   number before the current lines when exiting
      --filter string                           filter search pattern
  -A, --follow-all                              follow multiple files and show the most recently updated one
  -f, --follow-mode                             monitor file and display new content as it is written
      --follow-name                             follow mode to monitor by file name
      --follow-section                          section-by-section follow mode
      --force-screen                            display screen even when redirecting output
  -H, --header int                              number of header lines to be displayed constantly
  -Y, --header-column int                       number of columns to display as a vertical header
  -h, --help                                    help for ov
      --help-key                                display key bind information
      --hide-other-section                      hide other section
      --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default "10%")
      --incsearch[=true|false]                  incremental search (default true)
  -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']
  -n, --line-number                             line number mode
      --list-view-modes                         list available view modes defined in the configuration file
      --memory-limit int                        number of chunks to limit in memory (default -1)
      --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)
  -M, --multi-color strings                     comma separated words(regexp) to color .e.g. "ERROR,WARNING"
      --non-match-filter string                 filter non match search pattern
      --notify-eof int                          notify at the end of the file
      --pattern string                          search pattern
  -p, --plain                                   disable original decoration
  -F, --quit-if-one-screen                      quit if the output fits on one screen
  -r, --raw                                     raw escape sequences without processing
      --regexp-search                           regular expression search
      --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)
      --section-delimiter regexp                regexp for section delimiter .e.g. "^#"
      --section-header                          enable section-delimiter line as Header
      --section-header-num int                  number of section header lines (default 1)
      --section-start int                       section start position
      --set-terminal-title                      set terminal title
      --skip-extract                            skip extracting compressed files
      --skip-lines int                          skip the number of lines
      --smart-case-sensitive                    smart case-sensitive in search
      --status-line[=true|false]                status line (default true)
  -x, --tab-width int                           tab stop width (default 8)
  -v, --version                                 display version information
  -y, --vertical-header int                     number of characters to display as a vertical header
  -m, --view-mode string                        apply predefined settings for a specific mode
  -T, --watch seconds                           watch mode interval(seconds)
  -w, --wrap[=true|false]                       wrap mode (default true)
"""

HELP_KEY = """ov is a feature rich pager
 Key                            Action

\tGeneral
 [Escape], [q]                  * quit
 [ctrl+c]                       * cancel
 [Q]                            * output screen and quit
 [ctrl+q]                       * set output screen and quit
 [alt+shift+F8]                 * set output original screen and quit
 [ctrl+z]                       * suspend
 [alt+v]                        * edit current document
 [h], [ctrl+F1], [ctrl+alt+c]   * display help screen
 [ctrl+F2], [ctrl+alt+e]        * display log screen
 [ctrl+l]                       * screen sync
 [ctrl+f]                       * follow mode toggle
 [ctrl+a]                       * follow all mode toggle
 [ctrl+F8], [ctrl+alt+r]        * enable/disable mouse
 [S]                            * save buffer to file

\tMoving
 [Enter], [Down], [ctrl+n]      * forward by one line
 [Up], [ctrl+p]                 * backward by one line
 [Home]                         * go to top of document
 [End]                          * go to end of document
 [PageDown], [ctrl+v]           * forward by page
 [PageUp], [ctrl+b]             * backward by page
 [ctrl+d]                       * forward a half page
 [ctrl+u]                       * backward a half page
 [left]                         * scroll left
 [right]                        * scroll right
 [ctrl+left]                    * scroll left half screen
 [ctrl+right]                   * scroll right half screen
 [alt+left]                     * scroll left specified width
 [alt+right]                    * scroll right specified width
 [shift+Home]                   * go to beginning of line
 [shift+End]                    * go to end of line
 [g]                            * go to line(input number or `.n` or `n%` allowed)
 [,]                            * go to mark number(input number allowed)

\tSidebar
 [alt+h]                        * show/hide help in sidebar
 [alt+m]                        * show mark list in sidebar
 [alt+l]                        * show document list in sidebar
 [shift+Up]                     * scroll up in sidebar
 [shift+Down]                   * scroll down in sidebar
 [shift+Left]                   * scroll left in sidebar
 [shift+Right]                  * scroll right in sidebar

\tMove document
 []]                            * next document
 [[]                            * previous document
 [ctrl+k]                       * close current document
 [K]                            * close all filtered documents

\tMark position
 [m]                            * mark current position
 [M]                            * remove mark current position
 [ctrl+delete]                  * remove all mark
 [>]                            * move to next marked position
 [<]                            * move to previous marked position
 [*]                            * mark by pattern mode

\tSearch
 [/]                            * forward search mode
 [?]                            * backward search mode
 [n]                            * repeat forward search
 [N]                            * repeat backward search
 [&]                            * filter search mode

\tChange display
 [w], [W]                       * wrap/nowrap toggle
 [c]                            * column mode toggle
 [alt+o]                        * column width toggle
 [ctrl+r]                       * column rainbow toggle
 [C]                            * alternate rows of style toggle
 [G]                            * line number toggle
 [ctrl+e]                       * original decoration toggle(plain)
 [alt+f]                        * align columns
 [alt+r]                        * raw output
 [alt+shift+F9]                 * ruler toggle
 [ctrl+F10]                     * status line toggle
"""

FLAGS = [
    ("--align", "-l", False, "align the output columns for better readability"),
    ("--alternate-rows", "-C", False, "alternately change the line color"),
    ("--caption", None, True, "custom caption"),
    ("--case-sensitive", "-i", False, "case-sensitive in search"),
    ("--column-delimiter", "-d", True, "column delimiter `character`"),
    ("--column-mode", "-c", False, "column mode"),
    ("--column-rainbow", None, False, "column mode to rainbow"),
    ("--column-width", None, False, "column mode for width"),
    ("--completion", None, True, "generate completion script [bash|zsh|fish|powershell]"),
    ("--config", None, True, "config `file` (default is $XDG_CONFIG_HOME/ov/config.yaml)"),
    ("--converter", None, True, "converter [es|raw|align]"),
    ("--debug", None, False, "debug mode"),
    ("--disable-column-cycle", None, False, "disable column cycling"),
    ("--disable-mouse", None, False, "disable mouse support"),
    ("--exec", "-e", False, "command execution result instead of file"),
    ("--exit-write", "-X", False, "output the current screen when exiting"),
    ("--exit-write-after", "-a", True, "number after the current lines when exiting"),
    ("--exit-write-before", "-b", True, "number before the current lines when exiting"),
    ("--filter", None, True, "filter search pattern"),
    ("--follow-all", "-A", False, "follow multiple files and show the most recently updated one"),
    ("--follow-mode", "-f", False, "monitor file and display new content as it is written"),
    ("--follow-name", None, False, "follow mode to monitor by file name"),
    ("--follow-section", None, False, "section-by-section follow mode"),
    ("--force-screen", None, False, "display screen even when redirecting output"),
    ("--header", "-H", True, "number of header lines to be displayed constantly"),
    ("--header-column", "-Y", True, "number of columns to display as a vertical header"),
    ("--help", "-h", False, "help for ov"),
    ("--help-key", None, False, "display key bind information"),
    ("--hide-other-section", None, False, "hide other section"),
    ("--hscroll-width", None, True, "width to scroll horizontally `[int|int%|.int]`"),
    ("--incsearch", None, "bool", "incremental search"),
    ("--jump-target", "-j", True, "jump target `[int|int%|.int|'section']`"),
    ("--line-number", "-n", False, "line number mode"),
    ("--list-view-modes", None, False, "list available view modes defined in the configuration file"),
    ("--memory-limit", None, True, "number of chunks to limit in memory"),
    ("--memory-limit-file", None, True, "number of chunks to limit in memory for the file"),
    ("--multi-color", "-M", True, 'comma separated words(regexp) to color .e.g. "ERROR,WARNING"'),
    ("--non-match-filter", None, True, "filter non match search pattern"),
    ("--notify-eof", None, True, "notify at the end of the file"),
    ("--pattern", None, True, "search pattern"),
    ("--plain", "-p", False, "disable original decoration"),
    ("--quit-if-one-screen", "-F", False, "quit if the output fits on one screen"),
    ("--raw", "-r", False, "raw escape sequences without processing"),
    ("--regexp-search", None, False, "regular expression search"),
    ("--ruler", None, True, "display ruler (=0: none, =1: relative, =2: absolute)"),
    ("--section-delimiter", None, True, 'regexp for section delimiter .e.g. "^#"'),
    ("--section-header", None, False, "enable section-delimiter line as Header"),
    ("--section-header-num", None, True, "number of section header lines"),
    ("--section-start", None, True, "section start position"),
    ("--set-terminal-title", None, False, "set terminal title"),
    ("--skip-extract", None, False, "skip extracting compressed files"),
    ("--skip-lines", None, True, "skip the number of lines"),
    ("--smart-case-sensitive", None, False, "smart case-sensitive in search"),
    ("--status-line", None, "bool", "status line"),
    ("--tab-width", "-x", True, "tab stop width"),
    ("--version", "-v", False, "display version information"),
    ("--vertical-header", "-y", True, "number of characters to display as a vertical header"),
    ("--view-mode", "-m", True, "apply predefined settings for a specific mode"),
    ("--watch", "-T", True, "watch mode interval(seconds)"),
    ("--wrap", "-w", "bool", "wrap mode"),
]

LONG = {f[0]: f for f in FLAGS}
SHORT = {f[1]: f for f in FLAGS if f[1]}
INT_FLAGS = {"--header", "--header-column", "--exit-write-after", "--exit-write-before",
             "--memory-limit", "--memory-limit-file", "--notify-eof", "--ruler",
             "--section-header-num", "--section-start", "--skip-lines", "--tab-width",
             "--vertical-header"}

def eprint(s):
    sys.stderr.write(s + "\n")

def parse_bool(v, name):
    if v.lower() in ("1", "t", "true", "y", "yes"):
        return True
    if v.lower() in ("0", "f", "false", "n", "no"):
        return False
    eprint(f'Error: invalid argument "{v}" for "{name}" flag: strconv.ParseBool: parsing "{v}": invalid syntax')
    sys.exit(1)

def validate_int(flag, val, display):
    try:
        int(val, 10)
    except Exception:
        eprint(f'Error: invalid argument "{val}" for "{display}" flag: strconv.ParseInt: parsing "{val}": invalid syntax')
        sys.exit(1)

def parse(argv):
    opts = set()
    vals = {}
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            files.extend(argv[i+1:])
            break
        if a.startswith("--") and a != "--":
            name, eq, val = a.partition("=")
            if name not in LONG:
                eprint(f"Error: unknown flag: {name}")
                sys.exit(1)
            long, short, takes, _ = LONG[name]
            disp = f'"{long}"'
            if takes == "bool":
                if eq:
                    parse_bool(val, long)
                opts.add(long)
            elif takes:
                if not eq:
                    i += 1
                    if i >= len(argv):
                        eprint(f"Error: flag needs an argument: {long}")
                        sys.exit(1)
                    val = argv[i]
                vals[long] = val
                if long in INT_FLAGS:
                    shortpart = f"{short}, " if short else ""
                    validate_int(long, val, f"{shortpart}{long}")
            else:
                if eq:
                    eprint(f"Error: invalid argument: {a}")
                    sys.exit(1)
                opts.add(long)
            i += 1
            continue
        if a.startswith("-") and a != "-":
            name, eq, val = a.partition("=")
            if name not in SHORT:
                eprint(f"Error: unknown shorthand flag: '{name.lstrip('-')}' in {a}")
                sys.exit(1)
            long, short, takes, _ = SHORT[name]
            if takes == "bool":
                if eq:
                    parse_bool(val, long)
                opts.add(long)
            elif takes:
                if not eq:
                    i += 1
                    if i >= len(argv):
                        eprint(f"Error: flag needs an argument: {short}")
                        sys.exit(1)
                    val = argv[i]
                vals[long] = val
                if long in INT_FLAGS:
                    validate_int(long, val, f"{short}, {long}")
            else:
                if eq:
                    eprint(f"Error: invalid argument: {a}")
                    sys.exit(1)
                opts.add(long)
            i += 1
            continue
        files.append(a)
        i += 1
    return opts, vals, files

def completion_script(shell):
    if shell not in ("bash", "zsh", "fish", "powershell"):
        eprint("Error: requires one of the arguments bash/zsh/fish/powershell")
        return 1
    if shell == "bash":
        print("""# bash completion for ov                                   -*- shell-script -*-

__ov_debug()
{
    if [[ -n ${BASH_COMP_DEBUG_FILE:-} ]]; then
        echo "$*" >> "${BASH_COMP_DEBUG_FILE}"
    fi
}

__start_ov()
{
    local cur
    COMPREPLY=()
}

complete -o default -F __start_ov ov""")
    elif shell == "zsh":
        print("""#compdef ov
compdef _ov ov

# zsh completion for ov                                   -*- shell-script -*-

_ov()
{
    local -a completions
    completions=( '--help[help for ov]' '--version[display version information]' )
    _describe 'values' completions
}""")
    elif shell == "fish":
        for long, _, _, desc in FLAGS:
            print(f"complete -c ov -l {long[2:]} -d '{desc.replace(chr(39), '')}'")
    else:
        print("# powershell completion for ov")
    return 0

def do_complete(argv, desc=True):
    if not argv:
        eprint("Error: requires at least 1 arg(s), only received 0")
        return 1
    prefix = argv[-1]
    if prefix.startswith("--completion"):
        if desc:
            print("--completion\tgenerate completion script [bash|zsh|fish|powershell]")
        else:
            print("--completion")
        print(":4")
        if not desc:
            eprint("Completion ended with directive: ShellCompDirectiveNoFileComp")
        return 0
    for long, _, _, d in FLAGS:
        if long.startswith(prefix):
            print(f"{long}\t{d}" if desc else long)
    print(":4")
    if not desc:
        eprint("Completion ended with directive: ShellCompDirectiveNoFileComp")
    return 0

def copy_file(path):
    try:
        with open(path, "rb") as f:
            shutil.copyfileobj(f, sys.stdout.buffer)
        return 0
    except FileNotFoundError:
        eprint(f"Error: open {path}: no such file or directory")
        return 1
    except IsADirectoryError:
        eprint(f"Error: read {path}: is a directory")
        return 1
    except PermissionError:
        eprint(f"Error: open {path}: permission denied")
        return 1

def main():
    argv = sys.argv[1:]
    if argv and argv[0] == "__complete":
        return do_complete(argv[1:], True)
    if argv and argv[0] == "__completeNoDesc":
        return do_complete(argv[1:], False)
    opts, vals, files = parse(argv)
    if "--help" in opts:
        sys.stdout.write(HELP)
        return 0
    if "--version" in opts:
        print("ov version dev rev:HEAD")
        return 0
    if "--help-key" in opts:
        sys.stdout.write(HELP_KEY)
        return 0
    if "--completion" in vals:
        return completion_script(vals["--completion"])
    if "--list-view-modes" in opts:
        print("general")
        return 0
    if "--config" in vals and not os.path.exists(vals["--config"]):
        sys.stdout.write('failed to read config file: Unsupported Config Type ""\n')
    if files:
        rc = copy_file(files[0])
    else:
        shutil.copyfileobj(sys.stdin.buffer, sys.stdout.buffer)
        rc = 0
    if "--force-screen" in opts and not sys.stdin.isatty():
        sys.stdout.buffer.flush()
        eprint("Error: Screen.Init(): open /dev/tty: no such device or address")
        rc = 1
    return rc

if __name__ == "__main__":
    raise SystemExit(main())
