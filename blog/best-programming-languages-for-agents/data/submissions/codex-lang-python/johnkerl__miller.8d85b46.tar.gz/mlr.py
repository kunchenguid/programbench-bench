#!/usr/bin/env python3
import sys, csv, json, re, math, random, os
from collections import OrderedDict, defaultdict, Counter

VERSION = "mlr 6.16.0"

def infer(s, infer_none=False):
    if infer_none or s is None:
        return "" if s is None else s
    if isinstance(s, (int, float, bool)):
        return s
    if s == "":
        return ""
    if s == "true": return True
    if s == "false": return False
    if s == "null": return None
    try:
        if re.fullmatch(r'[+-]?\d+', s) and not (len(s) > 1 and s[0] == '0'):
            return int(s)
        if re.fullmatch(r'[+-]?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?', s):
            return float(s)
    except Exception:
        pass
    return s

def fmt(v):
    if v is None: return ""
    if isinstance(v, bool): return "true" if v else "false"
    return str(v)

def parse_dkvp(text, fs=",", ps="=", infer_none=False):
    out=[]
    for line in text.splitlines():
        if line == "": continue
        rec=OrderedDict()
        for idx, part in enumerate(line.split(fs), 1):
            if ps in part:
                k,v=part.split(ps,1)
            else:
                k,v=str(idx),part
            rec[k]=infer(v, infer_none)
        out.append(rec)
    return out

def parse_csvlike(text, delim=",", implicit=False, infer_none=False):
    rows=list(csv.reader(text.splitlines(), delimiter=delim))
    if not rows: return []
    if implicit:
        header=[str(i) for i in range(1, len(rows[0])+1)]
        data=rows
    else:
        header=rows[0]; data=rows[1:]
    out=[]
    for row in data:
        rec=OrderedDict()
        for i,v in enumerate(row):
            k=header[i] if i < len(header) else str(i+1)
            rec[k]=infer(v, infer_none)
        for k in header[len(row):]:
            rec[k]=""
        out.append(rec)
    return out

def parse_nidx(text, fs=None, infer_none=False):
    out=[]
    for line in text.splitlines():
        if line=="": continue
        parts=line.split() if fs is None else line.split(fs)
        out.append(OrderedDict((str(i+1), infer(v, infer_none)) for i,v in enumerate(parts)))
    return out

def parse_pprint(text, infer_none=False):
    lines=[l.rstrip("\n") for l in text.splitlines() if l.strip()]
    if not lines: return []
    header=lines[0].split()
    out=[]
    for line in lines[1:]:
        vals=line.split()
        out.append(OrderedDict((k, infer(vals[i] if i < len(vals) else "", infer_none)) for i,k in enumerate(header)))
    return out

def flatten(prefix, obj, rec):
    if isinstance(obj, dict):
        for k,v in obj.items():
            flatten(f"{prefix}.{k}" if prefix else str(k), v, rec)
    elif isinstance(obj, list):
        for i,v in enumerate(obj,1):
            flatten(f"{prefix}.{i}" if prefix else str(i), v, rec)
    else:
        rec[prefix]=obj

def parse_json_text(text, lines=False):
    out=[]
    vals=[]
    if lines:
        vals=[json.loads(l) for l in text.splitlines() if l.strip()]
    else:
        v=json.loads(text) if text.strip() else []
        vals=v if isinstance(v, list) else [v]
    for v in vals:
        rec=OrderedDict()
        if isinstance(v, dict):
            for k,val in v.items():
                if isinstance(val,(dict,list)): flatten(str(k), val, rec)
                else: rec[str(k)]=val
        else:
            rec["1"]=v
        out.append(rec)
    return out

def read_inputs(files, ifmt, opts):
    if opts.get("no_input"): return []
    if not files:
        text=sys.stdin.read()
        return parse_text(text, ifmt, opts)
    recs=[]
    for fn in files:
        with open(fn, newline="") as f:
            recs += parse_text(f.read(), ifmt, opts)
    return recs

def parse_text(text, ifmt, opts):
    if opts.get("skip_comments"):
        text="\n".join(l for l in text.splitlines() if not l.startswith("#")) + ("\n" if text.endswith("\n") else "")
    if ifmt=="csv": return parse_csvlike(text, ",", opts.get("implicit"), opts.get("infer_none"))
    if ifmt=="tsv": return parse_csvlike(text, "\t", opts.get("implicit"), opts.get("infer_none"))
    if ifmt=="json": return parse_json_text(text, False)
    if ifmt=="jsonl": return parse_json_text(text, True)
    if ifmt=="nidx": return parse_nidx(text, opts.get("ifs"), opts.get("infer_none"))
    if ifmt=="pprint": return parse_pprint(text, opts.get("infer_none"))
    return parse_dkvp(text, opts.get("ifs", ","), opts.get("ips", "="), opts.get("infer_none"))

def all_keys(records):
    keys=[]
    seen=set()
    for r in records:
        for k in r:
            if k not in seen:
                seen.add(k); keys.append(k)
    return keys

def write_records(records, ofmt, opts):
    if ofmt=="csv" or ofmt=="tsv":
        delim="," if ofmt=="csv" else "\t"
        keys=all_keys(records)
        w=csv.writer(sys.stdout, delimiter=delim, lineterminator="\n", quoting=csv.QUOTE_ALL if opts.get("quote_all") else csv.QUOTE_MINIMAL)
        if not opts.get("headerless_out"):
            w.writerow(keys)
        for r in records:
            w.writerow([fmt(r.get(k,"")) for k in keys])
    elif ofmt=="jsonl":
        for r in records:
            print(json.dumps({k:v for k,v in r.items()}, separators=(", ", ": ")))
    elif ofmt=="json":
        arr=[{k:v for k,v in r.items()} for r in records]
        if opts.get("no_jvstack"):
            print(json.dumps(arr, separators=(", ", ": ")))
        else:
            print("[")
            for idx,obj in enumerate(arr):
                lines=json.dumps(obj, indent=2).splitlines()
                if idx < len(arr)-1:
                    lines[-1] += ","
                print("\n".join(lines))
            print("]")
    elif ofmt=="nidx":
        for r in records:
            print(" ".join(fmt(v) for v in r.values()))
    elif ofmt=="pprint":
        keys=all_keys(records)
        widths={k:len(k) for k in keys}
        for r in records:
            for k in keys:
                widths[k]=max(widths[k], len(fmt(r.get(k,""))))
        if keys:
            print(" ".join(k.ljust(widths[k]) for k in keys).rstrip())
            for r in records:
                print(" ".join(fmt(r.get(k,"")).ljust(widths[k]) for k in keys).rstrip())
    else:
        ofs=opts.get("ofs", ","); ops=opts.get("ops", "=")
        for r in records:
            print(ofs.join(f"{k}{ops}{fmt(v)}" for k,v in r.items()))

def split_fields(s):
    return [x for x in s.split(",") if x!=""]

def verb_cat(records, args):
    name=None; groups=None
    i=0
    while i<len(args):
        if args[i]=="-n": name="n"; i+=1
        elif args[i]=="-N": name=args[i+1]; i+=2
        elif args[i]=="-g": groups=split_fields(args[i+1]); i+=2
        else: i+=1
    if name:
        counts=defaultdict(int); out=[]
        for n,r in enumerate(records,1):
            key=tuple(r.get(g,"") for g in groups) if groups else None
            counts[key]+=1
            nr=OrderedDict([(name, counts[key] if groups else n)])
            nr.update(r); out.append(nr)
        return out
    return records

def verb_cut(records,args):
    fields=[]; ordered=False; comp=False; regex=False
    i=0
    while i<len(args):
        if args[i]=="-f": fields=split_fields(args[i+1]); i+=2
        elif args[i]=="-o": ordered=True; i+=1
        elif args[i] in ("-x","--complement"): comp=True; i+=1
        elif args[i]=="-r": regex=True; i+=1
        else: i+=1
    out=[]
    for r in records:
        nr=OrderedDict()
        def match(k):
            return any(re.search(p,k) for p in fields) if regex else k in fields
        if comp:
            for k,v in r.items():
                if not match(k): nr[k]=v
        elif ordered:
            for k in fields:
                if k in r: nr[k]=r[k]
        else:
            for k,v in r.items():
                if match(k): nr[k]=v
        out.append(nr)
    return out

def num(v):
    try: return float(v)
    except Exception: return None

def verb_sort(records,args):
    specs=[]; move=False; i=0
    while i<len(args):
        a=args[i]
        if a=="-b": move=True; i+=1; continue
        if a in ("-f","-r","-c","-cr","-n","-nf","-nr","-t","-tr","-rt"):
            for f in split_fields(args[i+1]): specs.append((a,f))
            i+=2
        else: i+=1
    if not specs: return records
    def keypart(spec,r):
        flag,f=spec; v=r.get(f,"")
        if flag in ("-n","-nf","-nr"):
            x=num(v)
            return (x is None, x if x is not None else 0)
        s=fmt(v); return s.lower() if flag in ("-c","-cr") else s
    res=records[:]
    for spec in reversed(specs):
        rev=spec[0] in ("-r","-cr","-nr","-tr","-rt")
        res.sort(key=lambda r,sp=spec:keypart(sp,r), reverse=rev)
    if move:
        fields=[f for _,f in specs]
        out=[]
        for r in res:
            nr=OrderedDict()
            for f in fields:
                if f in r: nr[f]=r[f]
            for k,v in r.items():
                if k not in nr: nr[k]=v
            out.append(nr)
        res=out
    return res

def verb_head(records,args):
    n=10; groups=None; i=0
    while i<len(args):
        if args[i]=="-n": n=int(args[i+1]); i+=2
        elif args[i]=="-g": groups=split_fields(args[i+1]); i+=2
        else: i+=1
    if not groups: return records[:n]
    counts=defaultdict(int); out=[]
    for r in records:
        key=tuple(r.get(g,"") for g in groups); counts[key]+=1
        if counts[key]<=n: out.append(r)
    return out

def verb_tail(records,args):
    n=10; groups=None; i=0
    while i<len(args):
        if args[i]=="-n": n=int(args[i+1]); i+=2
        elif args[i]=="-g": groups=split_fields(args[i+1]); i+=2
        else: i+=1
    if not groups: return records[-n:]
    buckets=defaultdict(list)
    order=[]
    for r in records:
        key=tuple(r.get(g,"") for g in groups)
        if key not in buckets: order.append(key)
        buckets[key].append(r)
    out=[]
    for key in order: out += buckets[key][-n:]
    return out

def verb_count(records,args):
    groups=[]; oname="count"; onlyn=False; i=0
    while i<len(args):
        if args[i]=="-g": groups=split_fields(args[i+1]); i+=2
        elif args[i]=="-o": oname=args[i+1]; i+=2
        elif args[i]=="-n": onlyn=True; i+=2 if i+1<len(args) and not args[i+1].startswith("-") else 1
        else: i+=1
    if not groups:
        return [OrderedDict([(oname,len(records))])]
    counts=OrderedDict()
    vals={}
    for r in records:
        key=tuple(r.get(g,"") for g in groups)
        if key not in counts:
            counts[key]=0; vals[key]=[r.get(g,"") for g in groups]
        counts[key]+=1
    if onlyn: return [OrderedDict([(oname,len(counts))])]
    return [OrderedDict(list(zip(groups, vals[k]))+[(oname,c)]) for k,c in counts.items()]

def verb_stats1(records,args):
    accs=[]; fields=[]; groups=[]; i=0
    while i<len(args):
        if args[i]=="-a": accs=split_fields(args[i+1]); i+=2
        elif args[i]=="-f": fields=split_fields(args[i+1]); i+=2
        elif args[i]=="-g": groups=split_fields(args[i+1]); i+=2
        else: i+=1
    buckets=OrderedDict()
    for r in records:
        key=tuple(r.get(g,"") for g in groups)
        if key not in buckets: buckets[key]=[]
        buckets[key].append(r)
    out=[]
    for key,rs in buckets.items():
        nr=OrderedDict(zip(groups,key))
        for f in fields:
            vals=[r.get(f,"") for r in rs if f in r]
            nums=[float(v) for v in vals if num(v) is not None]
            for a in accs:
                name=f"{f}_{'p50' if a=='median' else a}"
                if a=="count": nr[name]=len(vals)
                elif a=="sum": nr[name]=sum(nums)
                elif a=="mean": nr[name]=sum(nums)/len(nums) if nums else ""
                elif a=="min": nr[name]=min(vals) if vals and not nums else (min(nums) if nums else "")
                elif a=="max": nr[name]=max(vals) if vals and not nums else (max(nums) if nums else "")
                elif a=="stddev":
                    m=sum(nums)/len(nums) if nums else 0; nr[name]=math.sqrt(sum((x-m)**2 for x in nums)/(len(nums)-1)) if len(nums)>1 else 0
                elif a=="var":
                    m=sum(nums)/len(nums) if nums else 0; nr[name]=sum((x-m)**2 for x in nums)/(len(nums)-1) if len(nums)>1 else 0
                elif a.startswith("p") or a=="median":
                    p=50 if a=="median" else float(a[1:]); ss=sorted(nums); idx=max(0, min(len(ss)-1, math.ceil(p/100*len(ss))-1)); nr[name]=ss[idx] if ss else ""
                elif a=="mode":
                    nr[name]=Counter(vals).most_common(1)[0][0] if vals else ""
                elif a=="distinct_count":
                    nr[name]=len(set(vals))
        out.append(nr)
    return out

def expr_to_py(expr):
    expr=expr.strip()
    expr=re.sub(r'\btrue\b','True',expr)
    expr=re.sub(r'\bfalse\b','False',expr)
    expr=expr.replace("&&"," and ").replace("||"," or ")
    expr=re.sub(r'\$(\w+)', r'get("\1")', expr)
    if "=~" in expr:
        left,pat=expr.split("=~",1)
        return f"(re.search({pat.strip()}, str({left.strip()})) is not None)"
    return expr

def eval_expr(expr,r):
    def get(k): return r.get(k,"")
    env={"get":get,"re":re,"math":math,"sqrt":math.sqrt,"log10":math.log10,"int":int,"float":float,"str":str,"len":len,"urand":random.random}
    try: return eval(expr_to_py(expr), {"__builtins__":{}}, env)
    except Exception: return False

def verb_filter(records,args):
    inv=False; exprs=[]; i=0
    while i<len(args):
        if args[i]=="-x": inv=True; i+=1
        elif args[i]=="-e": exprs.append(args[i+1]); i+=2
        elif not args[i].startswith("-"): exprs.append(args[i]); i+=1
        else: i+=1
    expr=";".join(exprs)
    return [r for r in records if bool(eval_expr(expr.split(";")[-1],r)) ^ inv]

def verb_put(records,args):
    exprs=[]; i=0
    while i<len(args):
        if args[i]=="-e": exprs.append(args[i+1]); i+=2
        elif not args[i].startswith("-"): exprs.append(args[i]); i+=1
        else: i+=1
    stmts=[]
    for e in exprs: stmts += [s.strip() for s in e.split(";") if s.strip()]
    out=[]
    for r in records:
        nr=OrderedDict(r)
        for st in stmts:
            m=re.match(r'\$(\w+)\s*([+\-*/]?=)\s*(.*)$', st)
            if not m: continue
            k,op,rhs=m.groups(); val=eval_expr(rhs,nr)
            if op=="=": nr[k]=val
            elif op=="+=": nr[k]=nr.get(k,0)+val
            elif op=="-=": nr[k]=nr.get(k,0)-val
            elif op=="*=": nr[k]=nr.get(k,0)*val
            elif op=="/=": nr[k]=nr.get(k,0)/val
        out.append(nr)
    return out

def verb_rename(records,args):
    pairs=[]; regex=False; i=0
    while i<len(args):
        if args[i]=="-r": regex=True; i+=1
        elif not args[i].startswith("-"):
            xs=split_fields(args[i]); pairs += list(zip(xs[0::2], xs[1::2])); i+=1
        else: i+=1
    out=[]
    for r in records:
        nr=OrderedDict()
        for k,v in r.items():
            nk=k
            for old,new in pairs:
                if regex and re.search(old,k): nk=re.sub(old,new,k)
                elif not regex and k==old: nk=new
            nr[nk]=v
        out.append(nr)
    return out

def verb_label(records,args):
    names=[]
    for a in args:
        if not a.startswith("-"): names += split_fields(a)
    out=[]
    for r in records:
        nr=OrderedDict()
        for idx,(k,v) in enumerate(r.items()):
            nr[names[idx] if idx < len(names) else k]=v
        out.append(nr)
    return out

def verb_tac(records,args):
    return list(reversed(records))

def verb_group_by(records,args):
    fields=[]; i=0
    while i<len(args):
        if args[i] in ("-f","-g"): fields=split_fields(args[i+1]); i+=2
        else: i+=1
    return sorted(records, key=lambda r: tuple(fmt(r.get(f,"")) for f in fields)) if fields else records

def verb_uniq(records,args):
    fields=[]; do_count=False; i=0
    while i<len(args):
        if args[i] in ("-f","-g"): fields=split_fields(args[i+1]); i+=2
        elif args[i] in ("-c","--count"): do_count=True; i+=1
        else: i+=1
    seen=OrderedDict()
    for r in records:
        key=tuple((f,r.get(f,"")) for f in (fields or list(r.keys())))
        if key not in seen: seen[key]=[r,0]
        seen[key][1]+=1
    out=[]
    for r,c in seen.values():
        nr=OrderedDict(r)
        if do_count: nr["count"]=c
        out.append(nr)
    return out

def verb_sort_within(records,args):
    return [OrderedDict(sorted(r.items(), key=lambda kv: kv[0])) for r in records]

def verb_clean_whitespace(records,args):
    out=[]
    for r in records:
        nr=OrderedDict()
        for k,v in r.items():
            nk=" ".join(str(k).strip().split())
            nv=" ".join(v.strip().split()) if isinstance(v,str) else v
            nr[nk]=nv
        out.append(nr)
    return out

def verb_fill_empty(records,args):
    fields=[]; value="N/A"; i=0
    while i<len(args):
        if args[i]=="-f": fields=split_fields(args[i+1]); i+=2
        elif args[i]=="-v": value=args[i+1]; i+=2
        else: i+=1
    out=[]
    for r in records:
        nr=OrderedDict(r)
        for f in (fields or list(nr.keys())):
            if nr.get(f,"")=="": nr[f]=value
        out.append(nr)
    return out

def verb_fill_down(records,args):
    fields=[]; i=0
    while i<len(args):
        if args[i]=="-f": fields=split_fields(args[i+1]); i+=2
        else: i+=1
    last={}; out=[]
    for r in records:
        nr=OrderedDict(r)
        for f in (fields or list(nr.keys())):
            if nr.get(f,"")=="" and f in last: nr[f]=last[f]
            elif nr.get(f,"")!="": last[f]=nr.get(f)
        out.append(nr)
    return out

def verb_remove_empty_columns(records,args):
    empty=set(all_keys(records))
    for r in records:
        for k,v in r.items():
            if v!="": empty.discard(k)
    return [OrderedDict((k,v) for k,v in r.items() if k not in empty) for r in records]

def verb_top(records,args):
    n=10; field=None; i=0
    while i<len(args):
        if args[i]=="-n": n=int(args[i+1]); i+=2
        elif args[i]=="-f": field=split_fields(args[i+1])[0]; i+=2
        else: i+=1
    if not field: return records[:n]
    return sorted(records, key=lambda r: num(r.get(field)) if num(r.get(field)) is not None else float("-inf"), reverse=True)[:n]

def simple_help(topic=None):
    if topic=="topics":
        print("Type 'mlr help {topic}' for any of the following:\nEssentials:\n  mlr help topics\n  mlr help basic-examples\n  mlr help file-formats\nVerbs:\n  mlr help list-verbs")
    elif topic=="list-verbs":
        print("\n".join("cat cut filter head label put rename sort stats1 tail count".split()))
    elif topic=="basic-examples":
        print("mlr --icsv --opprint cat example.csv\nmlr --icsv --opprint sort -f shape example.csv\nmlr --icsv --opprint cut -f flag,shape example.csv")
    else:
        print("Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}")

VERBS={"cat":verb_cat,"cut":verb_cut,"sort":verb_sort,"head":verb_head,"tail":verb_tail,"count":verb_count,"stats1":verb_stats1,"filter":verb_filter,"put":verb_put,"rename":verb_rename,"label":verb_label,"nothing":lambda r,a:[],
       "tac":verb_tac,"group-by":verb_group_by,"group-like":verb_group_by,"uniq":verb_uniq,"sort-within-records":verb_sort_within,
       "clean-whitespace":verb_clean_whitespace,"fill-empty":verb_fill_empty,"fill-down":verb_fill_down,
       "remove-empty-columns":verb_remove_empty_columns,"top":verb_top}

def parse_main(argv):
    if not argv or argv[0] in ("--help","-h"):
        simple_help(); return None
    if argv[0]=="-l":
        simple_help("list-verbs"); return None
    if argv[0]=="-g":
        simple_help("flags"); return None
    if argv[0] in ("--version","version"):
        print(VERSION if argv[0]=="--version" else "mlr version 6.16.0 for linux/amd64/go1.24.0"); return None
    if argv[0]=="help":
        simple_help(argv[1] if len(argv)>1 else None); return None
    ifmt=ofmt="dkvp"; opts={}; files_pre=[]; i=0
    conv=re.compile(r'^--([cdtjlpnxmy])2([cdtjlpnxmy])$')
    fmap={"c":"csv","t":"tsv","d":"dkvp","j":"json","l":"jsonl","n":"nidx","p":"pprint","x":"xtab","m":"pprint","y":"json"}
    while i<len(argv):
        a=argv[i]
        if a in VERBS: break
        m=conv.match(a)
        if m: ifmt=fmap[m.group(1)]; ofmt=fmap[m.group(2)]; i+=1
        elif a in ("--csv","-c","--c2c"): ifmt=ofmt="csv"; i+=1
        elif a in ("--tsv","-t","--t2t"): ifmt=ofmt="tsv"; i+=1
        elif a in ("--dkvp","--d2d"): ifmt=ofmt="dkvp"; i+=1
        elif a in ("--json","-j","--j2j"): ifmt=ofmt="json"; i+=1
        elif a in ("--jsonl","--l2l"): ifmt=ofmt="jsonl"; i+=1
        elif a in ("--nidx","--n2n"): ifmt=ofmt="nidx"; i+=1
        elif a in ("--pprint","--p2p"): ifmt=ofmt="pprint"; i+=1
        elif a=="-i": ifmt=argv[i+1]; i+=2
        elif a=="-o": ofmt=argv[i+1]; i+=2
        elif a=="--icsv": ifmt="csv"; i+=1
        elif a=="--itsv": ifmt="tsv"; i+=1
        elif a=="--idkvp": ifmt="dkvp"; i+=1
        elif a=="--ijson": ifmt="json"; i+=1
        elif a=="--ijsonl": ifmt="jsonl"; i+=1
        elif a=="--inidx": ifmt="nidx"; i+=1
        elif a=="--ocsv": ofmt="csv"; i+=1
        elif a=="--otsv": ofmt="tsv"; i+=1
        elif a=="--odkvp": ofmt="dkvp"; i+=1
        elif a=="--ojson": ofmt="json"; i+=1
        elif a=="--ojsonl": ofmt="jsonl"; i+=1
        elif a=="--onidx": ofmt="nidx"; i+=1
        elif a=="--opprint": ofmt="pprint"; i+=1
        elif a in ("--implicit-csv-header","--headerless-csv-input","--hi","-N"): opts["implicit"]=True; opts["headerless_out"]=True if a=="-N" else opts.get("headerless_out",False); i+=1
        elif a in ("--headerless-csv-output","--ho"): opts["headerless_out"]=True; i+=1
        elif a=="--quote-all": opts["quote_all"]=True; i+=1
        elif a in ("--infer-none","-S"): opts["infer_none"]=True; i+=1
        elif a=="--fs": opts["ifs"]=opts["ofs"]=decode_sep(argv[i+1]); i+=2
        elif a=="--ifs": opts["ifs"]=decode_sep(argv[i+1]); i+=2
        elif a=="--ofs": opts["ofs"]=decode_sep(argv[i+1]); i+=2
        elif a=="--ps": opts["ips"]=opts["ops"]=decode_sep(argv[i+1]); i+=2
        elif a=="--ips": opts["ips"]=decode_sep(argv[i+1]); i+=2
        elif a=="--ops": opts["ops"]=decode_sep(argv[i+1]); i+=2
        elif a=="--from": files_pre.append(argv[i+1]); i+=2
        elif a=="-n": opts["no_input"]=True; i+=1
        elif a in ("--skip-comments","--no-jvstack"): opts[a[2:].replace("-","_")]=True; i+=1
        else: i+=1
    return ifmt,ofmt,opts,files_pre,argv[i:]

def decode_sep(s):
    aliases={"tab":"\t","space":" ","comma":",","pipe":"|","semicolon":";","equals":"=","newline":"\n","lf":"\n"}
    return aliases.get(s, bytes(s,"utf-8").decode("unicode_escape"))

def split_pipeline(tokens):
    parts=[]; cur=[]
    for t in tokens:
        if t=="then": parts.append(cur); cur=[]
        else: cur.append(t)
    if cur: parts.append(cur)
    return parts

def main():
    parsed=parse_main(sys.argv[1:])
    if parsed is None: return
    ifmt,ofmt,opts,pre,rest=parsed
    if not rest:
        simple_help(); return
    pipe=split_pipeline(rest)
    files=[]; stages=[]
    for idx,p in enumerate(pipe):
        if not p: continue
        verb=p[0]; args=[]; j=1
        while j<len(p):
            if idx==len(pipe)-1 and os.path.exists(p[j]):
                files.append(p[j]); j+=1
            else:
                args.append(p[j]); j+=1
        stages.append((verb,args))
    records=read_inputs(pre+files, ifmt, opts)
    for verb,args in stages:
        if verb not in VERBS:
            sys.stderr.write(f"mlr: verb {verb} not implemented\n"); sys.exit(1)
        records=VERBS[verb](records,args)
    write_records(records, ofmt, opts)

if __name__=="__main__":
    main()
