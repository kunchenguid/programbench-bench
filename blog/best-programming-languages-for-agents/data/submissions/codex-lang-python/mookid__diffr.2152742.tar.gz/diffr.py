#!/usr/bin/env python3
import difflib
import re
import sys


RESET = "\033[0m"


HELP = """diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...
            Configure color settings for console ouput.

            There are four faces to customize:
            +----------------+--------------+----------------+
            |  line prefix   |      +       |       -        |
            +----------------+--------------+----------------+
            | common segment |    added     |    removed     |
            | unique segment | refine-added | refine-removed |
            +----------------+--------------+----------------+

            The customization allows
            - to change the foreground or background color;
            - to set or unset the attributes 'bold', 'intense', 'underline';
            - to clear all attributes.

            Customization is done passing a color_spec argument.
            This flag may be provided multiple times.

            The syntax is the following:

            color_spec = face-name + ':' + attributes
            attributes = attribute
                       | attribute + ':' + attributes
            attribute  = ('foreground' | 'background') + ':' + color
                       | (<empty> | 'no') + font-flag
                       | 'none'
            font-flag  = 'italic'
                       | 'bold'
                       | 'intense'
                       | 'underline'
            color      = 'none'
                       | [0-255]
                       | [0-255] + ',' + [0-255] + ',' + [0-255]
                       | ('black', 'blue', 'green', 'red',
                          'cyan', 'magenta', 'yellow', 'white')

            For example, the color_spec

                'refine-added:background:blue:bold'

            sets the color of unique added segments with
            a blue background, written with a bold font.

        --line-numbers <compact|aligned>
            Display line numbers. Style is optional.
            When style = 'compact', take as little width as possible.
            When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]

    -h, --help
            Prints help information

    -V, --version
            Prints version information
"""


COLOR_NAMES = {
    "black": 0,
    "red": 1,
    "green": 2,
    "yellow": 3,
    "blue": 4,
    "magenta": 5,
    "cyan": 6,
    "white": 7,
}


class Face:
    def __init__(self, parts=None):
        self.parts = parts or []

    def ansi(self):
        return "".join(self.parts)

    def clear(self):
        self.parts = []

    def add_flag(self, flag, on=True):
        codes = {
            "bold": ("1", "22"),
            "intense": ("1", "22"),
            "underline": ("4", "24"),
            "italic": ("3", "23"),
        }
        code = codes[flag][0 if on else 1]
        self.parts.append(f"\033[{code}m")

    def add_color(self, kind, color):
        if color == "none":
            self.parts.append("\033[39m" if kind == "foreground" else "\033[49m")
            return
        base = 30 if kind == "foreground" else 40
        if color in COLOR_NAMES:
            self.parts.append(f"\033[{base + COLOR_NAMES[color]}m")
            return
        if "," in color:
            vals = color.split(",")
            if len(vals) != 3:
                color_error(color)
            try:
                rgb = [int(v) for v in vals]
            except ValueError:
                color_error(color)
            if any(v < 0 or v > 255 for v in rgb):
                color_error(color)
            self.parts.append(f"\033[{38 if kind == 'foreground' else 48};2;{rgb[0]};{rgb[1]};{rgb[2]}m")
            return
        try:
            n = int(color, 0)
        except ValueError:
            color_error(color)
        if not 0 <= n <= 255:
            sys.stderr.write(
                "unexpected color value: unrecognized ansi256 color number, should be '[0-255]' (or a hex number), but is '%s'\n"
                % color
            )
            raise SystemExit(255)
        self.parts.append(f"\033[{38 if kind == 'foreground' else 48};5;{n}m")


def color_error(color):
    sys.stderr.write(f"unexpected color value: '{color}'\n")
    raise SystemExit(255)


def default_faces():
    return {
        "added": Face(["\033[32m"]),
        "removed": Face(["\033[31m"]),
        "refine-added": Face(["\033[1m", "\033[38;2;255;255;255m", "\033[42m"]),
        "refine-removed": Face(["\033[1m", "\033[38;2;255;255;255m", "\033[41m"]),
    }


def apply_color_spec(faces, spec):
    face, sep, rest = spec.partition(":")
    if not sep or face not in faces:
        sys.stderr.write(
            "unexpected face name: got '%s', expected added|refine-added|removed|refine-removed\n"
            % face
        )
        raise SystemExit(255)
    faces[face].clear()
    toks = rest.split(":") if rest else []
    i = 0
    while i < len(toks):
        tok = toks[i]
        if tok == "none":
            faces[face].clear()
            i += 1
        elif tok in ("foreground", "background"):
            if i + 1 >= len(toks):
                color_error("")
            faces[face].add_color(tok, toks[i + 1])
            i += 2
        else:
            on = True
            flag = tok
            if flag.startswith("no"):
                on = False
                flag = flag[2:]
            if flag not in ("italic", "bold", "intense", "underline"):
                sys.stderr.write(f"unexpected color attribute: '{tok}'\n")
                raise SystemExit(255)
            if on:
                faces[face].add_flag(flag, on)
            i += 1


def parse_args(argv):
    faces = default_faces()
    line_numbers = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            sys.stdout.write("diffr 0.1.5\n")
            raise SystemExit(0)
        if arg == "--colors":
            i += 1
            if i >= len(argv):
                sys.stderr.write("The argument '--colors <COLOR_SPEC>...' requires a value but none was supplied\n")
                raise SystemExit(1)
            while i < len(argv) and not argv[i].startswith("-"):
                apply_color_spec(faces, argv[i])
                i += 1
            continue
        if arg.startswith("--colors="):
            apply_color_spec(faces, arg.split("=", 1)[1])
            i += 1
            continue
        if arg == "--line-numbers":
            line_numbers = "compact"
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                line_numbers = argv[i + 1]
                i += 1
            if line_numbers not in ("compact", "aligned", "fixed"):
                sys.stderr.write(
                    "unexpected line number style: got '%s', expected aligned|compact|fixed\n" % line_numbers
                )
                raise SystemExit(255)
            i += 1
            continue
        if arg.startswith("--line-numbers="):
            line_numbers = arg.split("=", 1)[1]
            if line_numbers not in ("compact", "aligned", "fixed"):
                sys.stderr.write(
                    "unexpected line number style: got '%s', expected aligned|compact|fixed\n" % line_numbers
                )
                raise SystemExit(255)
            i += 1
            continue
        sys.stderr.write("Found argument '%s' which wasn't expected, or isn't valid in this context\n" % arg)
        raise SystemExit(1)
    return faces, line_numbers


HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")


def style(face, text):
    return RESET + face.ansi() + text + RESET


def tokenize(s):
    return re.findall(r"\w+|\W+", s, re.UNICODE)


def split_refined(old, new):
    a = tokenize(old)
    b = tokenize(new)
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    old_parts = []
    new_parts = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        old_txt = "".join(a[i1:i2])
        new_txt = "".join(b[j1:j2])
        if tag == "equal":
            old_parts.append(("common", old_txt))
            new_parts.append(("common", new_txt))
        else:
            if old_txt:
                old_parts.append(("refine", old_txt))
            if new_txt:
                new_parts.append(("refine", new_txt))
    return old_parts, new_parts


def render_changed(prefix, content, parts, faces):
    base = faces["removed"] if prefix == "-" else faces["added"]
    ref = faces["refine-removed"] if prefix == "-" else faces["refine-added"]
    paired = parts is not None
    if parts is None:
        parts = [("refine", content)]
    out = RESET + base.ansi() + prefix + RESET
    for kind, txt in parts:
        if not txt:
            continue
        out += style(base if kind == "common" else ref, txt)
    if not paired or (parts and parts[-1][0] != "common"):
        out += style(base, "")
    return out


def parse_hunk(line):
    m = HUNK_RE.match(line)
    if not m:
        return None
    old = int(m.group(1))
    new = int(m.group(3))
    return old, new


def number_prefix(kind, old_no, new_no, style_name, colored_face=None):
    if style_name is None:
        return ""
    if kind == "context":
        text = f"{old_no:3d}" if old_no == new_no else f"{old_no} {new_no}"
    elif kind == "removed":
        text = f"{old_no:<3d}"
    elif kind == "added":
        text = f"{new_no:>3d}"
    else:
        text = ""
    if colored_face is not None:
        text = RESET + colored_face.ansi() + text + RESET
    if style_name == "aligned":
        text += "\t"
    return text


def render_plain(line):
    return RESET + line + RESET


def process(lines, faces, line_numbers):
    out = []
    old_no = None
    new_no = None
    i = 0
    while i < len(lines):
        line = lines[i]
        h = parse_hunk(line)
        if h:
            old_no, new_no = h
            out.append(render_plain(line))
            i += 1
            continue
        if line.startswith("-") and not line.startswith("---"):
            minus = []
            plus = []
            while i < len(lines) and lines[i].startswith("-") and not lines[i].startswith("---"):
                minus.append(lines[i][1:])
                i += 1
            j = i
            while j < len(lines) and lines[j].startswith("+") and not lines[j].startswith("+++"):
                plus.append(lines[j][1:])
                j += 1
            paired = len(minus) == 1 and len(plus) == 1
            old_parts = new_parts = None
            if paired:
                old_parts, new_parts = split_refined(minus[0], plus[0])
            for idx, txt in enumerate(minus):
                prefix = number_prefix("removed", old_no or 0, new_no or 0, line_numbers, faces["removed"])
                parts = old_parts if paired and idx == 0 else None
                out.append(prefix + render_changed("-", txt, parts, faces))
                if old_no is not None:
                    old_no += 1
            for idx, txt in enumerate(plus):
                prefix = number_prefix("added", old_no or 0, new_no or 0, line_numbers, faces["added"])
                parts = new_parts if paired and idx == 0 else None
                out.append(prefix + render_changed("+", txt, parts, faces))
                if new_no is not None:
                    new_no += 1
            i = j
            continue
        if line.startswith("+") and not line.startswith("+++"):
            txt = line[1:]
            prefix = number_prefix("added", old_no or 0, new_no or 0, line_numbers, faces["added"])
            out.append(prefix + render_changed("+", txt, None, faces))
            if new_no is not None:
                new_no += 1
            i += 1
            continue
        if line.startswith(" ") and old_no is not None and new_no is not None:
            prefix = number_prefix("context", old_no, new_no, line_numbers, None)
            out.append(prefix + render_plain(line))
            old_no += 1
            new_no += 1
            i += 1
            continue
        out.append(render_plain(line))
        i += 1
    return "\n".join(out) + ("\n" if lines else "")


def main():
    faces, line_numbers = parse_args(sys.argv[1:])
    data = sys.stdin.read()
    had_final_nl = data.endswith("\n")
    lines = data.splitlines()
    result = process(lines, faces, line_numbers)
    if not had_final_nl and result.endswith("\n"):
        result = result[:-1]
    sys.stdout.write(result)


if __name__ == "__main__":
    main()
