#!/usr/bin/env python3
import math
import os
import sys


VERSION = "hx 0.7.0"
FORMATS = {"o", "x", "X", "b"}
ARRAYS = {"r", "c", "g", "p", "k", "j", "s", "f"}


HELP = """Futuristic take on hexdump, made in Rust.


Usage: executable [OPTIONS] [INPUTFILE]

Arguments:
  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin

Options:
  -c, --cols <columns>        Set column length
  -l, --len <len>             Set <len> bytes to read
  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]
  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]
  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]
  -u, --func <func_length>    Set function wave length
  -p, --places <func_places>  Set function wave output decimal places
  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]
  -h, --help                  Print help
  -V, --version               Print version
"""


class CliError(Exception):
    def __init__(self, message, code=2):
        self.message = message
        self.code = code


def parse_int(value, short, long):
    try:
        if value.startswith("-"):
            raise ValueError
        return int(value, 10)
    except ValueError:
        print(f"{short}, --{long} <integer> expected. ParseIntError {{ kind: InvalidDigit }}", file=sys.stderr)
        print("error: invalid digit found in string", file=sys.stderr)
        sys.exit(1)


def need_value(argv, i, opt):
    if i + 1 >= len(argv):
        raise CliError(f"error: a value is required for '{opt}' but none was supplied\n\nFor more information, try '--help'.")
    return argv[i + 1]


def invalid_value(opt, meta, value, possible):
    vals = ", ".join(possible)
    raise CliError(
        f"error: invalid value '{value}' for '{opt} <{meta}>'\n"
        f"  [possible values: {vals}]\n\n"
        "For more information, try '--help'."
    )


def usage_error(arg):
    tip = ""
    if arg.startswith("-"):
        tip = f"\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'"
    raise CliError(
        f"error: unexpected argument '{arg}' found"
        f"{tip}\n\n"
        "Usage: executable [OPTIONS] [INPUTFILE]\n\n"
        "For more information, try '--help'."
    )


def parse(argv):
    opts = {
        "cols": 10,
        "length": 0,
        "format": "x",
        "color": "1",
        "array": None,
        "func": None,
        "places": 4,
        "prefix": "1",
        "input": None,
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if arg == "--":
            rest = argv[i + 1 :]
            if len(rest) > 1:
                usage_error(rest[1])
            if rest:
                if opts["input"] is not None:
                    usage_error(rest[0])
                opts["input"] = rest[0]
            break
        if arg in ("-c", "--cols"):
            val = need_value(argv, i, arg)
            opts["cols"] = parse_int(val, "-c", "cols")
            i += 2
            continue
        if arg in ("-l", "--len"):
            val = need_value(argv, i, arg)
            opts["length"] = parse_int(val, "-l", "len")
            i += 2
            continue
        if arg in ("-u", "--func"):
            val = need_value(argv, i, arg)
            opts["func"] = parse_int(val, "-u", "func")
            i += 2
            continue
        if arg in ("-p", "--places"):
            val = need_value(argv, i, arg)
            opts["places"] = parse_int(val, "-p", "places")
            i += 2
            continue
        if arg in ("-f", "--format"):
            val = need_value(argv, i, arg)
            if val not in FORMATS:
                invalid_value("--format", "format", val, ["o", "x", "X", "b"])
            opts["format"] = val
            i += 2
            continue
        if arg in ("-t", "--color"):
            val = need_value(argv, i, arg)
            if val not in {"0", "1"}:
                invalid_value("--color", "color", val, ["0", "1"])
            opts["color"] = val
            i += 2
            continue
        if arg in ("-r", "--prefix"):
            val = need_value(argv, i, arg)
            if val not in {"0", "1"}:
                invalid_value("--prefix", "prefix", val, ["0", "1"])
            opts["prefix"] = val
            i += 2
            continue
        if arg in ("-a", "--array"):
            val = need_value(argv, i, arg)
            if val not in ARRAYS:
                invalid_value("--array", "array_format", val, ["r", "c", "g", "p", "k", "j", "s", "f"])
            opts["array"] = val
            i += 2
            continue
        if arg.startswith("-"):
            usage_error(arg)
        if opts["input"] is not None:
            usage_error(arg)
        opts["input"] = arg
        i += 1
    if opts["cols"] == 0:
        opts["cols"] = 1
    return opts


def read_data(path, limit):
    try:
        if path is None:
            data = sys.stdin.buffer.read()
        else:
            with open(path, "rb") as f:
                data = f.read()
    except OSError as e:
        print(f"error: {e.strerror} (os error {e.errno})", file=sys.stderr)
        sys.exit(1)
    if limit:
        return data[:limit]
    return data


def byte_token(b, fmt, prefix=True):
    if fmt == "x":
        s = f"{b:02x}"
        return ("0x" if prefix else "") + s
    if fmt == "X":
        s = f"{b:02X}"
        return ("0x" if prefix else "") + s
    if fmt == "o":
        s = f"{b:04o}"
        return ("0o" if prefix else "") + s
    if fmt == "b":
        s = f"{b:08b}"
        return ("0b" if prefix else "") + s
    return f"{b:02x}"


def printable(b):
    return chr(b) if 32 <= b <= 126 else "."


def hexdump(data, cols, fmt, prefix):
    token_width = len(byte_token(0, fmt, prefix))
    field_width = cols * token_width + max(cols - 1, 0)
    nlines = (len(data) + cols - 1) // cols
    if len(data) == 0 or len(data) % cols == 0:
        nlines += 1
    for line in range(nlines):
        off = line * cols
        chunk = data[off : off + cols]
        if not chunk:
            print(f"0x{off:06x}: " + (" " * (cols * 5)))
            continue
        hexpart = " ".join(byte_token(b, fmt, prefix) for b in chunk)
        text = "".join(printable(b) for b in chunk)
        pad = " " * (field_width - len(hexpart) + 1)
        print(f"0x{off:06x}: {hexpart}{pad}{text}")
    print(f"   bytes: {len(data)}")


def array_token(b, lang):
    if lang == "f":
        return f"0x{b:02x}uy"
    return f"0x{b:02x}"


def array_lines(data, cols, lang):
    sep = "; " if lang == "f" else ", "
    out = []
    for i in range(0, len(data), cols):
        chunk = data[i : i + cols]
        pieces = [array_token(b, lang) for b in chunk]
        line = sep.join(pieces)
        if lang == "g":
            line += ", "
        elif i + cols < len(data):
            line += sep
        out.append("    " + line)
    if not out:
        out.append("    ")
    elif len(data) % cols == 0:
        out.append("    ")
    return out


def array_dump(data, cols, lang):
    n = len(data)
    if lang == "r":
        print(f"let ARRAY: [u8; {n}] = [")
        print("\n".join(array_lines(data, cols, lang)))
        print("];")
    elif lang == "c":
        print(f"unsigned char ARRAY[{n}] = {{")
        print("\n".join(array_lines(data, cols, lang)))
        print("};")
    elif lang == "g":
        print(f"a := [{n}]byte{{")
        print("\n".join(array_lines(data, cols, lang)))
        print("}")
    elif lang == "p":
        print("a = [")
        print("\n".join(array_lines(data, cols, lang)))
        print("]")
    elif lang == "k":
        print("val a = byteArrayOf(")
        print("\n".join(array_lines(data, cols, lang)))
        print(")")
    elif lang == "j":
        print("byte[] a = new byte[]{")
        print("\n".join(array_lines(data, cols, lang)))
        print("};")
    elif lang == "s":
        print("let a: [UInt8] = [")
        print("\n".join(array_lines(data, cols, lang)))
        print("]")
    elif lang == "f":
        print("let a = [|")
        print("\n".join(array_lines(data, cols, lang)))
        print("|]")


def func_wave(length, places):
    vals = [f"{math.sin(i * math.pi / (2 * length)):.{places}f}" for i in range(length)] if length else []
    print(",".join(vals) + ("," if vals else ""))


def main(argv):
    try:
        opts = parse(argv)
    except CliError as e:
        print(e.message, file=sys.stderr)
        return e.code
    if opts["func"] is not None:
        func_wave(opts["func"], opts["places"])
        return 0
    data = read_data(opts["input"], opts["length"])
    if opts["array"]:
        array_dump(data, opts["cols"], opts["array"])
    else:
        hexdump(data, opts["cols"], opts["format"], opts["prefix"] == "1")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
