#!/usr/bin/env python3
import os
import re
import sys
import subprocess
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

RESET = "\033[0m"
COLOR = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "lightblack": 90, "lightred": 91, "lightgreen": 92, "lightyellow": 93, "lightblue": 94, "lightmagenta": 95, "lightcyan": 96, "lightwhite": 97,
    "brightblack": 90, "brightred": 91, "brightgreen": 92, "brightyellow": 93, "brightblue": 94, "brightmagenta": 95, "brightcyan": 96, "brightwhite": 97,
    "gray": 90, "grey": 90,
}
ATTR = {
    "bold": 1, "faint": 2, "italic": 3, "underline": 4, "blinkslow": 5, "blinkrapid": 6,
    "inverse": 7, "conceal": 8, "crossout": 9, "frame": 51, "encircle": 52, "overline": 53,
}

@dataclass
class Style:
    hide: bool = False
    attrs: Dict[str, bool] = field(default_factory=dict)
    foreground: Optional[str] = None
    background: Optional[str] = None

    def prefix(self) -> str:
        codes: List[str] = []
        fg = ansi_color(self.foreground, False)
        bg = ansi_color(self.background, True)
        if fg:
            codes.append(fg)
        if bg:
            codes.append(bg)
        for key, code in ATTR.items():
            if self.attrs.get(key):
                codes.append(str(code))
        return "".join(f"\033[{c}m" for c in codes)


def ansi_color(value: Optional[str], bg: bool) -> Optional[str]:
    if not value:
        return None
    v = str(value).strip().strip('"\'').lower()
    if v in COLOR:
        code = COLOR[v]
        if bg:
            code += 10
        return str(code)
    m = re.match(r"#?([0-9a-f]{6})$", v)
    if m:
        hx = m.group(1)
        nums = [int(hx[i:i+2], 16) for i in (0, 2, 4)]
        return ("48" if bg else "38") + ";2;" + ";".join(map(str, nums))
    m = re.match(r"rgb\(([^,]+),([^,]+),([^\)]+)\)", v)
    if m:
        nums = []
        for part in m.groups():
            p = part.strip()
            nums.append(int(p, 16) if p.lower().startswith("0x") else int(p))
        return ("48" if bg else "38") + ";2;" + ";".join(map(str, nums))
    return None


def default_config():
    def st(fg=None, bold=False, hide=False):
        s = Style(hide=hide, foreground=fg)
        if bold:
            s.attrs["bold"] = True
        return s
    return {
        "labelType": "long",
        "coverThreshold": 50.0,
        "leaveTestPrefix": False,
        "removals": [],
        "styles": {
            "build": st("yellow", True),
            "start": st("lightBlack"),
            "pass": st("green"),
            "fail": st("red", True),
            "skip": st("lightBlack"),
            "passPackage": st("green"),
            "failPackage": st("red", True),
            "covered": st("green"),
            "uncovered": st("yellow", True),
            "file": st("cyan"),
            "line": st("magenta"),
        },
    }

STYLE_KEYS = {
    "buildStyle": "build", "startStyle": "start", "passStyle": "pass", "failStyle": "fail", "skipStyle": "skip",
    "passPackageStyle": "passPackage", "failPackageStyle": "failPackage", "coveredStyle": "covered", "uncoveredStyle": "uncovered",
    "fileStyle": "file", "lineStyle": "line",
}


def parse_scalar(s: str):
    s = s.strip()
    if not s:
        return ""
    if s[0:1] in ('"', "'") and s[-1:] == s[0]:
        return s[1:-1]
    low = s.lower()
    if low == "true":
        return True
    if low == "false":
        return False
    try:
        if "." in s:
            return float(s)
        return int(s)
    except ValueError:
        return s


def load_config() -> dict:
    cfg = default_config()
    cwd = os.getcwd()
    paths = []
    names = [".richstyle", ".richstyle.yaml", ".richstyle.yml"]
    roots = [cwd]
    if os.environ.get("RICHGO_LOCAL") != "1":
        for env in ("GOPATH", "GOROOT", "HOME"):
            val = os.environ.get(env)
            if val:
                roots.append(val)
    for root in roots:
        for n in names:
            paths.append(os.path.join(root, n))
    for p in paths:
        if os.path.exists(p):
            apply_config_file(cfg, p)
            break
    return cfg


def apply_config_file(cfg: dict, path: str) -> None:
    current_style = None
    in_removals = False
    try:
        lines = open(path, encoding="utf-8").read().splitlines()
    except OSError:
        return
    for raw in lines:
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        if line.startswith("  -") and in_removals:
            cfg["removals"].append(str(parse_scalar(line.split("-", 1)[1].strip())))
            continue
        if not raw.startswith((" ", "\t")):
            in_removals = False
            current_style = None
            if ":" not in line:
                continue
            k, v = line.split(":", 1)
            key = k.strip()
            val = v.strip()
            if key in STYLE_KEYS:
                current_style = STYLE_KEYS[key]
                if val.startswith("{") and val.endswith("}"):
                    for part in val[1:-1].split(","):
                        if ":" in part:
                            sk, sv = part.split(":", 1)
                            set_style(cfg["styles"][current_style], sk.strip(), parse_scalar(sv))
            elif key == "removals":
                in_removals = True
            elif key == "labelType":
                cfg["labelType"] = str(parse_scalar(val)).lower()
            elif key == "coverThreshold":
                try:
                    cfg["coverThreshold"] = float(parse_scalar(val))
                except Exception:
                    pass
            elif key == "leaveTestPrefix":
                cfg["leaveTestPrefix"] = bool(parse_scalar(val))
        elif current_style and ":" in line:
            k, v = line.strip().split(":", 1)
            set_style(cfg["styles"][current_style], k.strip(), parse_scalar(v))


def set_style(style: Style, key: str, val) -> None:
    lk = key.lower()
    if lk == "hide":
        style.hide = bool(val)
    elif lk == "foreground":
        style.foreground = str(val)
    elif lk == "background":
        style.background = str(val)
    elif lk in ATTR:
        style.attrs[lk] = bool(val)


def label(kind: str, label_type: str) -> str:
    if label_type == "none":
        return ""
    if label_type == "short":
        return {"build": "!! ", "start": ">  ", "pass": "o  ", "fail": "x  ", "skip": "-  ", "cover": "%  ", "blank": "   "}.get(kind, "   ")
    text = {"build": "BUILD", "start": "START", "pass": "PASS", "fail": "FAIL", "skip": "SKIP", "cover": "COVER", "blank": ""}.get(kind, kind.upper())
    return f"{text:<5}| " if text else "     | "


def clean_test_name(name: str, leave: bool) -> str:
    name = name.strip()
    depth = name.count("/")
    if not leave:
        name = re.sub(r"(^|/)Test", r"\1", name)
    return "  " * depth + name


def style_text(text: str, style: Style, colorize: bool) -> str:
    if not colorize:
        return text
    return style.prefix() + text + RESET


def format_file_line(rest: str, base_style: Style, cfg: dict, colorize: bool, prefix: str) -> Optional[str]:
    m = re.match(r"(\s*)([^\s:]+\.go)(:\d+(?::\d+)?)(:.*)$", rest)
    if not m:
        return None
    indent, file, line, msg = m.groups()
    if not colorize:
        return prefix + indent + file + line + msg
    outer = base_style.prefix()
    lead = outer
    if colorize and base_style is cfg["styles"].get("build"):
        lead = RESET + outer
    fs = cfg["styles"]["file"].prefix()
    ls = cfg["styles"]["line"].prefix()
    return lead + prefix + indent + fs + file + RESET + ls + line + RESET + outer + msg + RESET


def format_line(line: str, cfg: dict, colorize: bool) -> Optional[str]:
    for pat in cfg["removals"]:
        try:
            if re.search(pat, line):
                return None
        except re.error:
            pass
    lt = cfg["labelType"]
    styles = cfg["styles"]
    m = re.match(r"^=== RUN\s+(.*)$", line)
    if m:
        text = label("start", lt) + clean_test_name(m.group(1), cfg["leaveTestPrefix"])
        return None if styles["start"].hide else style_text(text, styles["start"], colorize)
    m = re.match(r"^--- (PASS|FAIL|SKIP):\s+(.*)$", line)
    if m:
        kind = m.group(1).lower()
        text = label(kind, lt) + clean_test_name(m.group(2), cfg["leaveTestPrefix"])
        return None if styles[kind].hide else style_text(text, styles[kind], colorize)
    if line == "PASS":
        return None if colorize else line
    if line == "FAIL":
        return None if colorize else line
    if line.startswith("ok  \t"):
        rest = line[5:]
        pkg = rest.split("\t", 1)[0]
        text = label("pass", lt) + pkg + " "
        return None if styles["passPackage"].hide else style_text(text, styles["passPackage"], colorize)
    if line.startswith("?   \t"):
        rest = line[5:]
        text = label("skip", lt) + rest
        return None if styles["skip"].hide else style_text(text, styles["skip"], colorize)
    if line.startswith("FAIL\t"):
        text = label("fail", lt) + line[4:]
        return None if styles["failPackage"].hide else style_text(text, styles["failPackage"], colorize)
    m = re.match(r"^coverage:\s+([0-9.]+)% of statements", line)
    if m:
        pct = float(m.group(1))
        filled = max(0, min(10, int(pct / 10)))
        bar = "#" * filled + "_" * (10 - filled)
        style = styles["covered"] if pct >= cfg["coverThreshold"] else styles["uncovered"]
        text = label("cover", lt) + f"{pct:.1f}% [{bar}]"
        return None if style.hide else style_text(text, style, colorize)
    if line.startswith("# "):
        text = label("build", lt) + line[2:]
        if styles["build"].hide:
            return None
        if colorize:
            return styles["build"].prefix() + text
        return text
    if re.match(r"^\s+[^\s:]+\.go:\d+", line):
        pref = label("blank", lt)
        res = format_file_line(line, styles["fail"], cfg, colorize, pref)
        if res is not None:
            return res
    if re.match(r"^[^\s:]+\.go:\d+", line):
        pref = label("blank", lt)
        res = format_file_line(line, styles["build"], cfg, colorize, pref)
        if res is not None:
            return None if styles["build"].hide else res
    return line


def color_enabled() -> bool:
    v = os.environ.get("RICHGO_FORCE_COLOR")
    if v and v != "0":
        return True
    if os.environ.get("NO_COLOR"):
        return False
    return sys.stdout.isatty()


def testfilter() -> int:
    cfg = load_config()
    colorize = color_enabled()
    for raw in sys.stdin:
        line = raw.rstrip("\n")
        if not colorize:
            print(line)
            continue
        out = format_line(line, cfg, colorize)
        if out is not None:
            print(out)
    return 0


def run_go(args: List[str]) -> int:
    try:
        proc = subprocess.Popen(["go"] + args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    except FileNotFoundError:
        sys.stderr.write('panic: exec: "go": executable file not found in $PATH\n\n')
        sys.stderr.write('goroutine 1 [running]:\nmain.main()\n\t/workspace/main.go:74 +0x465\n')
        return 2
    cfg = load_config()
    colorize = color_enabled()
    assert proc.stdout is not None
    for raw in proc.stdout:
        out = format_line(raw.rstrip("\n"), cfg, colorize)
        if out is not None:
            print(out)
    return proc.wait()


def main() -> int:
    args = sys.argv[1:]
    if args and args[0] == "testfilter":
        return testfilter()
    if args and args[0] in ("-h", "--help"):
        return run_go(args)
    if args and args[0] == "version":
        return run_go(args)
    return run_go(args)

if __name__ == "__main__":
    raise SystemExit(main())
