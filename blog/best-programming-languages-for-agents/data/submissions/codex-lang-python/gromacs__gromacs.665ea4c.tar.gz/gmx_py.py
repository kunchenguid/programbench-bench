#!/usr/bin/env python3
import os
import sys
import textwrap

VERSION = "2027.0-dev-20260414-24ac8ab-unknown"
SHA1 = "24ac8abecd15814143951f211394c29bdfc42e13"
DATA_PREFIX = "/usr/local/gromacs"

COMMANDS = [
    ("anaeig", "Analyze eigenvectors/normal modes"),
    ("analyze", "Analyze data sets"),
    ("angle", "Calculate distributions and correlations for angles and dihedrals"),
    ("awh", "Extract data from an accelerated weight histogram (AWH) run"),
    ("bar", "Calculate free energy difference estimates through Bennett's acceptance ratio"),
    ("bundle", "Analyze bundles of axes, e.g., helices"),
    ("check", "Check and compare files"),
    ("chi", "Calculate everything you want to know about chi and other dihedrals"),
    ("cluster", "Cluster structures"),
    ("clustsize", "Calculate size distributions of atomic clusters"),
    ("confrms", "Fit two structures and calculates the RMSD"),
    ("convert-tpr", "Make a modified run-input file"),
    ("convert-trj", "Converts between different trajectory types"),
    ("covar", "Calculate and diagonalize the covariance matrix"),
    ("current", "Calculate dielectric constants and current autocorrelation function"),
    ("density", "Calculate the density of the system"),
    ("densmap", "Calculate 2D planar or axial-radial density maps"),
    ("densorder", "Calculate surface fluctuations"),
    ("dielectric", "Calculate frequency dependent dielectric constants"),
    ("dipoles", "Compute the total dipole plus fluctuations"),
    ("disre", "Analyze distance restraints"),
    ("distance", "Calculate distances between pairs of positions"),
    ("dos", "Analyze density of states and properties based on that"),
    ("dssp", "Calculate protein secondary structure via DSSP algorithm"),
    ("dump", "Make binary files human readable"),
    ("dyecoupl", "Extract dye dynamics from trajectories"),
    ("editconf", "Convert and manipulates structure files"),
    ("eneconv", "Convert energy files"),
    ("enemat", "Extract an energy matrix from an energy file"),
    ("energy", "Writes energies to xvg files and display averages"),
    ("extract-cluster", "Allows extracting frames corresponding to clusters from trajectory"),
    ("filter", "Frequency filter trajectories, useful for making smooth movies"),
    ("freevolume", "Calculate free volume"),
    ("gangle", "Calculate angles"),
    ("genconf", "Multiply a conformation in 'random' orientations"),
    ("genion", "Generate monoatomic ions on energetically favorable positions"),
    ("genrestr", "Generate position restraints or distance restraints for index groups"),
    ("grompp", "Make a run input file"),
    ("gyrate", "Calculate radius of gyration of a molecule"),
    ("gyrate-legacy", "Calculate the radius of gyration"),
    ("h2order", "Compute the orientation of water molecules"),
    ("hbond", "Compute and analyze hydrogen bonds."),
    ("hbond-legacy", "Compute and analyze hydrogen bonds"),
    ("helix", "Calculate basic properties of alpha helices"),
    ("helixorient", "Calculate local pitch/bending/rotation/orientation inside helices"),
    ("help", "Print help information"),
    ("hydorder", "Compute tetrahedrality parameters around a given atom"),
    ("insert-molecules", "Insert molecules into existing vacancies"),
    ("lie", "Estimate free energy from linear combinations"),
    ("make_edi", "Generate input files for essential dynamics sampling"),
    ("make_ndx", "Make index files"),
    ("mdmat", "Calculate residue contact maps"),
    ("mdrun", "Perform a simulation, do a normal mode analysis or an energy minimization"),
    ("mindist", "Calculate the minimum distance between two groups"),
    ("mk_angndx", "Generate index files for 'gmx angle'"),
    ("msd", "Compute mean squared displacements"),
    ("nmeig", "Diagonalize the Hessian for normal mode analysis"),
    ("nmens", "Generate an ensemble of structures from the normal modes"),
    ("nmr", "Analyze nuclear magnetic resonance properties from an energy file"),
    ("nmtraj", "Generate a virtual oscillating trajectory from an eigenvector"),
    ("nonbonded-benchmark", "Benchmarking tool for the non-bonded pair kernels."),
    ("order", "Compute the order parameter per atom for carbon tails"),
    ("pairdist", "Calculate pairwise distances between groups of positions"),
    ("pdb2gmx", "Convert coordinate files to topology and FF-compliant coordinate files"),
    ("pme_error", "Estimate the error of using PME with a given input file"),
    ("polystat", "Calculate static properties of polymers"),
    ("potential", "Calculate the electrostatic potential across the box"),
    ("principal", "Calculate principal axes of inertia for a group of atoms"),
    ("rama", "Compute Ramachandran plots"),
    ("rdf", "Calculate radial distribution functions"),
    ("report-methods", "Write short summary about the simulation setup to a text file and/or to the standard output."),
    ("rms", "Calculate RMSDs with a reference structure and RMSD matrices"),
    ("rmsdist", "Calculate atom pair distances averaged with power -2, -3 or -6"),
    ("rmsf", "Calculate atomic fluctuations"),
    ("rotacf", "Calculate the rotational correlation function for molecules"),
    ("rotmat", "Plot the rotation matrix for fitting to a reference structure"),
    ("saltbr", "Compute salt bridges"),
    ("sans-legacy", "Compute small angle neutron scattering spectra"),
    ("sasa", "Compute solvent accessible surface area"),
    ("saxs-legacy", "Compute small angle X-ray scattering spectra"),
    ("scattering", "Calculate small angle scattering profiles for SANS or SAXS"),
    ("select", "Print general information about selections"),
    ("sham", "Compute free energies or other histograms from histograms"),
    ("sigeps", "Convert c6/12 or c6/cn combinations to and from sigma/epsilon"),
    ("solvate", "Solvate a system"),
    ("sorient", "Analyze solvent orientation around solutes"),
    ("spatial", "Calculate the spatial distribution function"),
    ("spol", "Analyze solvent dipole orientation and polarization around solutes"),
    ("tcaf", "Calculate viscosities of liquids"),
    ("traj", "Plot x, v, f, box, temperature and rotational energy from trajectories"),
    ("trajectory", "Print coordinates, velocities, and/or forces for selections"),
    ("trjcat", "Concatenate trajectory files"),
    ("trjconv", "Convert and manipulates trajectory files"),
    ("trjorder", "Order molecules according to their distance to a group"),
    ("tune_pme", "Time mdrun as a function of PME ranks to optimize settings"),
    ("vanhove", "Compute Van Hove displacement and correlation functions"),
    ("velacc", "Calculate velocity autocorrelation functions"),
    ("wham", "Perform weighted histogram analysis after umbrella sampling"),
    ("wheel", "Plot helical wheels"),
    ("x2top", "Generate a primitive topology from coordinates"),
    ("xpm2ps", "Convert XPM (XPixelMap) matrices to postscript or XPM"),
]
CMD_DESCRIPTIONS = dict(COMMANDS)
COMMAND_SET = set(CMD_DESCRIPTIONS)

SYNOPSIS = """SYNOPSIS

gmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]
    [-[no]backup]

OPTIONS

Other options:

 -[no]h                     (no)
           Print help and quit
 -[no]quiet                 (no)
           Do not print common startup info or quotes
 -[no]version               (no)
           Print extended version information and quit
 -[no]copyright             (no)
           Print copyright information on startup
 -nice   <int>              (19)
           Set the nicelevel (default depends on command)
 -[no]backup                (yes)
           Write backups if output files exist

Additional help is available on the following topics:
    commands    List of available commands
    selections  Selection syntax and usage
To access the help, use 'gmx help <topic>'.
For help on a command, use 'gmx help <command>'."""

VERSION_TEXT = f"""GROMACS version:     {VERSION}
GIT SHA1 hash:       {SHA1}
Branched from:       unknown
Precision:           mixed
Memory model:        64 bit
MPI library:         thread_mpi
MPI version:         built in
OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)
GPU support:         disabled
SIMD instructions:   None
CPU FFT library:     fftw-3.3.10
GPU FFT library:     none
Multi-GPU FFT:       none
RDTSCP:              enabled
TNG support:         enabled
Hwloc support:       disabled
Tracing support:     disabled
Colvars support:     enabled (version 2025-10-13)
CP2K support:        disabled
Torch support:       disabled
Plumed support:      enabled
C compiler:          /usr/bin/cc GNU 11.4.0
C compiler flags:    -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wno-unused -Wunused-value -Wunused-parameter -Wextra -Wno-sign-compare -Wpointer-arith -Wpedantic -Wundef -Werror=stringop-truncation -Wshadow -Wno-missing-field-initializers -O3 -DNDEBUG
C++ compiler:        /usr/bin/c++ GNU 11.4.0
C++ compiler flags:  -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wextra -Wpointer-arith -Wmissing-declarations -Wpedantic -Wundef -Wstringop-truncation -Wshadow -Wno-missing-field-initializers -Wno-stringop-truncation -Wno-cast-function-type-strict SHELL:-fopenmp -O3 -DNDEBUG
BLAS library:        Internal
LAPACK library:      Internal
"""

GENERIC_OPTIONS = """OPTIONS

Other options:

 -[no]h                     (no)
           Print help and quit
 -nice   <int>              (19)
           Set the nicelevel
 -[no]backup                (yes)
           Write backups if output files exist"""

HELP_PAGES = {
    "mdrun": """SYNOPSIS

gmx mdrun [-s [<.tpr>]] [-cpi [<.cpt>]] [-table [<.xvg>]] [-tablep [<.xvg>]]
          [-tableb [<.xvg> [...]]] [-rerun [<.xtc/.trr/...>]] [-ei [<.edi>]]
          [-multidir [<dir> [...]]] [-awh [<.xvg>]] [-plumed [<.dat>]]
          [-membed [<.dat>]] [-mp [<.top>]] [-mn [<.ndx>]]
          [-o [<.trr/.cpt/...>]] [-x [<.xtc/.tng>]] [-cpo [<.cpt>]]
          [-c [<.gro/.g96/...>]] [-e [<.edr>]] [-g [<.log>]] [-dhdl [<.xvg>]]
          [-deffnm <string>] [-nt <int>] [-ntmpi <int>] [-ntomp <int>]
          [-[no]v] [-pforce <real>] [-[no]reprod] [-cpt <real>]
          [-[no]cpnum] [-[no]append] [-nsteps <int>] [-maxh <real>]

DESCRIPTION

gmx mdrun is the main computational chemistry engine within GROMACS.
Obviously, it performs Molecular Dynamics simulations, but it can also perform
Stochastic Dynamics, Energy Minimization, test particle insertion or
(re)calculation of energies. Normal mode analysis is another option.

The mdrun program reads the run input file (-s). mdrun produces at least four
output files: a log file (-g), a trajectory file (-o), a structure file (-c),
and an energy file (-e). Optionally coordinates can be written to a compressed
trajectory file (-x).

OPTIONS

Options to specify input files:

 -s      [<.tpr>]           (topol.tpr)
           Portable xdr run input file
 -cpi    [<.cpt>]           (state.cpt)      (Opt.)
           Checkpoint file
 -rerun  [<.xtc/.trr/...>]  (rerun.xtc)      (Opt.)
           Trajectory: xtc trr cpt gro g96 pdb tng h5md

Options to specify output files:

 -o      [<.trr/.cpt/...>]  (traj.trr)
           Full precision trajectory: trr cpt tng h5md
 -x      [<.xtc/.tng>]      (traj_comp.xtc)  (Opt.)
           Compressed trajectory (tng format or portable xdr format)
 -c      [<.gro/.g96/...>]  (confout.gro)
           Structure file: gro g96 pdb brk ent esp
 -e      [<.edr>]           (ener.edr)
           Energy file
 -g      [<.log>]           (md.log)
           Log file

Other options:

 -deffnm <string>
           Set the default filename for all file options
 -nt     <int>              (0)
           Total number of threads to start
 -[no]v                     (no)
           Be loud and noisy
 -nsteps <int>              (-2)
           Run this number of steps, overrides .mdp file option""",
    "grompp": """SYNOPSIS

gmx grompp [-f [<.mdp>]] [-c [<.gro/.g96/...>]] [-r [<.gro/.g96/...>]]
           [-rb [<.gro/.g96/...>]] [-n [<.ndx>]] [-p [<.top>]]
           [-t [<.trr/.cpt/...>]] [-e [<.edr>]] [-po [<.mdp>]]
           [-pp [<.top>]] [-o [<.tpr>]] [-[no]v] [-time <real>]
           [-[no]rmvsbds] [-maxwarn <int>] [-[no]zero] [-[no]renum]

DESCRIPTION

gmx grompp (the gromacs preprocessor) reads a molecular topology file, checks
the validity of the file, expands the topology from a molecular description to
an atomic description, reads parameters for gmx mdrun, and produces a binary
run input file.

OPTIONS

Options to specify input files:

 -f      [<.mdp>]           (grompp.mdp)
           grompp input file with MD parameters
 -c      [<.gro/.g96/...>]  (conf.gro)
           Structure file: gro g96 pdb brk ent esp tpr
 -n      [<.ndx>]           (index.ndx)      (Opt.)
           Index file
 -p      [<.top>]           (topol.top)
           Topology file

Options to specify output files:

 -po     [<.mdp>]           (mdout.mdp)
           grompp input file with MD parameters
 -pp     [<.top>]           (processed.top)  (Opt.)
           Topology file
 -o      [<.tpr>]           (topol.tpr)
           Portable xdr run input file

Other options:

 -[no]v                     (no)
           Be loud and noisy
 -time   <real>             (-1)
           Take frame at or first after this time.
 -maxwarn <int>             (0)
           Number of allowed warnings during input processing""",
    "pdb2gmx": """SYNOPSIS

gmx pdb2gmx [-f [<.gro/.g96/...>]] [-o [<.gro/.g96/...>]] [-p [<.top>]]
            [-i [<.itp>]] [-n [<.ndx>]] [-q [<.gro/.g96/...>]]
            [-chainsep <enum>] [-merge <enum>] [-ff <string>] [-water <enum>]
            [-[no]inter] [-[no]ss] [-[no]ter] [-[no]lys] [-[no]arg]
            [-[no]asp] [-[no]glu] [-[no]gln] [-[no]his] [-[no]ignh]

DESCRIPTION

gmx pdb2gmx reads a .pdb (or .gro) file, reads database files, adds hydrogens
to the molecules and generates coordinates and a topology in GROMACS format.

OPTIONS

Options to specify input files:

 -f      [<.gro/.g96/...>]  (protein.pdb)
           Structure file: gro g96 pdb brk ent esp tpr

Options to specify output files:

 -o      [<.gro/.g96/...>]  (conf.gro)
           Structure file: gro g96 pdb brk ent esp
 -p      [<.top>]           (topol.top)
           Topology file
 -i      [<.itp>]           (posre.itp)
           Include file for topology

Other options:

 -chainsep <enum>           (id_or_ter)
           Condition in PDB files when a new chain should be started
 -merge  <enum>             (no)
           Merge multiple chains into a single [moleculetype]
 -ff     <string>           (select)
           Force field, interactive by default. Use -h for information.
 -water  <enum>             (select)
           Water model to use""",
}

REQUIRED_ERRORS = {
    "mdrun": """Invalid input values
  In option s
    Required option was not provided, and the default file 'topol' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .tpr""",
    "grompp": """Invalid input values
  In option c
    Required option was not provided, and the default file 'conf' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .gro, .g96, .pdb, .brk, .ent, .esp, .tpr
  In option f
    Required option was not provided, and the default file 'grompp' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .mdp
  In option p
    Required option was not provided, and the default file 'topol' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .top""",
    "pdb2gmx": """Invalid input values
  In option f
    Required option was not provided, and the default file 'protein' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
      .gro, .g96, .pdb, .brk, .ent, .esp, .tpr""",
}


def exe_label():
    return os.path.basename(sys.argv[0]) or "executable"


def command_line(args):
    return "  " + " ".join([exe_label()] + args)


def banner(title, args, quiet=False, copyright=False):
    if quiet:
        return
    if copyright:
        print(f"       :-) GROMACS - {title}, {VERSION} (-:\n")
        return
    print(f"       :-) GROMACS - {title}, {VERSION} (-:\n")
    invoked = sys.argv[0]
    if os.path.isabs(invoked):
        path = invoked
    elif os.sep in invoked:
        path = os.path.join(os.getcwd(), invoked)
    else:
        path = os.path.abspath(invoked)
    print(f"Executable:   {path}")
    print(f"Data prefix:  {DATA_PREFIX}")
    print(f"Working dir:  {os.getcwd()}")
    print("Command line:")
    print(command_line(args))
    print()


def quote(quiet=False):
    if not quiet:
        print('\nGROMACS reminds you: "You ONLY have to do the coding ..." (Anton Jansen, to core developer, on implementing new features)\n')


def fatal(program, message, args, quiet=False, source="src/gromacs/commandline/cmdlineparser.cpp", line=271, func="void gmx::CommandLineParser::parse(int*, char**)"):
    banner(program, args, quiet)
    print("-------------------------------------------------------")
    print(f"Program:     {program}, version {VERSION}")
    print(f"Source file: {source} (line {line})")
    print(f"Function:    {func}\n")
    print("Error in user input:")
    print(message)
    print()
    print("For more information and tips for troubleshooting, please check the GROMACS")
    print("website at https://manual.gromacs.org/current/user-guide/run-time-errors.html")
    print("-------------------------------------------------------")
    return 1


def common_help():
    print(SYNOPSIS)


def version():
    print(VERSION_TEXT)


def copyright_text(args, quiet=False):
    banner(exe_label(), args, quiet=False, copyright=True)
    print("""Copyright 1991-2027 The GROMACS Authors.
GROMACS is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License
as published by the Free Software Foundation; either version 2.1
of the License, or (at your option) any later version.

                         Current GROMACS contributors:
       Mark Abraham           Andrey Alekseenko           Brian Andrews
        Paul Bauer              Cathrine Bergh              Hugh Bird
      Eliane Briand               Ania Brown                Yiqi Chen
      Mahesh Doijade            Giacomo Fiorin          Stefan Fleischmann
      Sergey Gorelov         Gilles Gouaillardet            Alan Gray

                  Coordinated by the GROMACS project leaders:
                           Berk Hess and Erik Lindahl
""")


def commands_help():
    print("LIST OF AVAILABLE COMMANDS\n")
    print("Usage: gmx [<options>] <command> [<args>]\n")
    print("Available commands:")
    for name, desc in COMMANDS:
        if len(desc) <= 58:
            print(f"    {name:<20} {desc}")
        else:
            wrapped = textwrap.wrap(desc, 58)
            print(f"    {name:<20} {wrapped[0]}")
            for line in wrapped[1:]:
                print(f"                         {line}")
    print("For help on a command, use 'gmx help <command>'.")


def selections_help(topic=None):
    if topic:
        print(f"SELECTION {topic.upper()}\n")
        print("This help topic describes part of the GROMACS selection language.")
        print("Selections are used to select atoms, residues, molecules, or positions for analysis.")
        return
    print("""SELECTION SYNTAX AND USAGE

Selections are used to select atoms/molecules/residues for analysis. In
contrast to traditional index files, selections can be dynamic, i.e., select
different atoms for different trajectory frames. Each selection evaluates to a
set of positions.

Available subtopics:
    arithmetic   Arithmetic expressions in selections
    cmdline      Specifying selections from command line
    evaluation   Selection evaluation and optimization
    examples     Selection examples
    keywords     Selection keywords
    limitations  Selection limitations
    positions    Specifying positions in selections
    syntax       Selection syntax""")


def generic_command_help(cmd):
    desc = CMD_DESCRIPTIONS.get(cmd, "GROMACS command")
    print(f"SYNOPSIS\n\ngmx {cmd} [-h] [<options>]\n")
    print("DESCRIPTION\n")
    print(textwrap.fill(f"gmx {cmd}: {desc}.", width=78))
    print()
    print(GENERIC_OPTIONS)


def command_help(cmd):
    print(HELP_PAGES.get(cmd, ""))
    if cmd not in HELP_PAGES:
        generic_command_help(cmd)


def option_has_value(args, i):
    return i + 1 < len(args) and not args[i + 1].startswith("-")


def parse_global(args):
    quiet = "-quiet" in args
    i = 0
    while i < len(args):
        a = args[i]
        if a == "-nice":
            if not option_has_value(args, i):
                return quiet, fatal(exe_label(), "Invalid command-line options\n  In command-line option -nice\n    Too few (valid) values", args, quiet)
            i += 2
            continue
        if a.startswith("--"):
            return quiet, fatal(exe_label(), f"Invalid command-line options\n    Unknown command-line option {a}", args, quiet)
        i += 1
    return quiet, None


def missing_file(name):
    return not os.path.exists(name)


def command_run(cmd, args, quiet):
    if any(a in ("-h", "-help") for a in args):
        banner(f"gmx {cmd}", [cmd] + args, quiet)
        command_help(cmd)
        return 0
    for a in args:
        if a.startswith("--"):
            return fatal(f"gmx {cmd}", f"Invalid command-line options\n    Unknown command-line option {a}", [cmd] + args, quiet)
    if cmd == "editconf":
        return run_editconf(args, quiet)
    if cmd == "make_ndx":
        return run_make_ndx(args, quiet)
    if cmd == "check":
        return run_check(args, quiet)
    if cmd in REQUIRED_ERRORS and not any(a in args for a in ("-s", "-f", "-c", "-p")):
        return fatal(f"gmx {cmd}", REQUIRED_ERRORS[cmd], [cmd] + args, quiet,
                     source="src/gromacs/options/options.cpp", line=184,
                     func="void gmx::internal::OptionSectionImpl::finish()")
    return fatal(f"gmx {cmd}",
                 "This lightweight reimplementation supports command-line help, version information,\n"
                 "and parser diagnostics, but does not perform molecular simulation or analysis.",
                 [cmd] + args, quiet,
                 source="src/gromacs/commandline/cmdlinemodulemanager.cpp", line=389,
                 func="gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)")


def opt_value(args, opt, default=None):
    if opt in args:
        i = args.index(opt)
        if i + 1 < len(args):
            return args[i + 1]
    return default


def parse_pdb_atoms(path):
    atoms = []
    with open(path, "r", errors="replace") as fh:
        for line in fh:
            if line.startswith(("ATOM  ", "HETATM")):
                try:
                    serial = int(line[6:11])
                except ValueError:
                    serial = len(atoms) + 1
                name = line[12:16].strip() or "X"
                resn = line[17:20].strip() or "MOL"
                try:
                    resi = int(line[22:26])
                except ValueError:
                    resi = 1
                try:
                    x = float(line[30:38]) / 10.0
                    y = float(line[38:46]) / 10.0
                    z = float(line[46:54]) / 10.0
                except ValueError:
                    x = y = z = 0.0
                atoms.append((resi, resn, name, serial, x, y, z))
    return atoms


def parse_gro_atoms(path):
    atoms = []
    with open(path, "r", errors="replace") as fh:
        lines = fh.readlines()
    for line in lines[2:-1]:
        if len(line) < 44:
            continue
        try:
            resi = int(line[0:5])
            resn = line[5:10].strip() or "MOL"
            name = line[10:15].strip() or "X"
            serial = int(line[15:20])
            x = float(line[20:28])
            y = float(line[28:36])
            z = float(line[36:44])
            atoms.append((resi, resn, name, serial, x, y, z))
        except ValueError:
            pass
    return atoms


def read_atoms(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".gro":
        return parse_gro_atoms(path)
    return parse_pdb_atoms(path)


def write_gro(path, atoms):
    with open(path, "w") as fh:
        fh.write("Generated by gmx editconf\n")
        fh.write(f"{len(atoms):5d}\n")
        for idx, (resi, resn, name, serial, x, y, z) in enumerate(atoms, 1):
            fh.write(f"{resi % 100000:5d}{resn[:5]:<5}{name[:5]:>5}{idx % 100000:5d}{x:8.3f}{y:8.3f}{z:8.3f}\n")
        fh.write("   0.00000   0.00000   0.00000\n")


def write_pdb(path, atoms):
    with open(path, "w") as fh:
        for idx, (resi, resn, name, serial, x, y, z) in enumerate(atoms, 1):
            fh.write(f"ATOM  {idx:5d} {name[:4]:<4} {resn[:3]:>3} A{resi:4d}    {x*10:8.3f}{y*10:8.3f}{z*10:8.3f}  1.00  0.00           {name[0].upper():>2}\n")
        fh.write("END\n")


def run_editconf(args, quiet):
    inp = opt_value(args, "-f")
    out = opt_value(args, "-o", "out.gro")
    if not inp:
        return fatal("gmx editconf", "Invalid input values\n  In option f\n    Required option was not provided, and the default file 'conf' does not\n    exist or is not accessible.", ["editconf"] + args, quiet,
                     source="src/gromacs/options/options.cpp", line=184,
                     func="void gmx::internal::OptionSectionImpl::finish()")
    if not os.path.exists(inp):
        return fatal("gmx editconf", f"File input/output error:\nFile '{inp}' does not exist or is not accessible.", ["editconf"] + args, quiet,
                     source="src/gromacs/utility/futil.cpp", line=521,
                     func="FILE* gmx_ffopen(const std::filesystem::path&, const char*)")
    atoms = read_atoms(inp)
    if os.path.splitext(out)[1].lower() == ".pdb":
        write_pdb(out, atoms)
    else:
        write_gro(out, atoms)
    if not quiet:
        print(f"Read {len(atoms)} atoms")
        print(f"Writing coordinate file {out}")
    return 0


def run_make_ndx(args, quiet):
    inp = opt_value(args, "-f")
    out = opt_value(args, "-o", "index.ndx")
    atoms = read_atoms(inp) if inp and os.path.exists(inp) else []
    n = len(atoms)
    with open(out, "w") as fh:
        fh.write("[ System ]\n")
        nums = list(range(1, n + 1))
        for i in range(0, len(nums), 15):
            fh.write(" " + " ".join(str(x) for x in nums[i:i + 15]) + "\n")
    if not quiet:
        print(f"Created index file {out}")
    return 0


def run_check(args, quiet):
    inp = opt_value(args, "-f") or opt_value(args, "-f1")
    if not inp or not os.path.exists(inp):
        return fatal("gmx check", "Invalid input values\n  In option f\n    File was not provided or is not accessible.", ["check"] + args, quiet,
                     source="src/gromacs/options/options.cpp", line=184,
                     func="void gmx::internal::OptionSectionImpl::finish()")
    size = os.path.getsize(inp)
    print(f"Checking file {inp}")
    print(f"File size: {size} bytes")
    print("Item        #frames Timestep (ps)")
    print("Step             0")
    return 0


def main():
    args = sys.argv[1:]
    quiet, early = parse_global(args)
    if early is not None:
        return early

    if "-version" in args:
        banner(exe_label(), args, quiet=False)
        version()
        return 0

    if "-copyright" in args:
        copyright_text(args, quiet)

    if not args or "-h" in args or "-help" in args or "-copyright" in args:
        if "-copyright" not in args:
            banner(exe_label(), args, quiet)
            quote(quiet)
        common_help()
        return 0

    if args[0] in ("-quiet", "-noquiet", "-backup", "-nobackup") and len(args) == 1:
        common_help()
        return 0

    cmd_index = 0
    while cmd_index < len(args) and args[cmd_index].startswith("-"):
        if args[cmd_index] == "-nice":
            cmd_index += 2
        else:
            cmd_index += 1
    if cmd_index >= len(args):
        banner(exe_label(), args, quiet)
        quote(quiet)
        common_help()
        return 0

    cmd = args[cmd_index]
    rest = args[cmd_index + 1:]
    if cmd == "help":
        banner("gmx help", args, quiet)
        topic = rest[0] if rest else None
        subtopic = rest[1] if len(rest) > 1 else None
        if topic == "commands":
            commands_help()
        elif topic == "selections":
            selections_help(subtopic)
        elif topic in COMMAND_SET:
            command_help(topic)
        elif topic is None:
            quote(quiet)
            common_help()
        else:
            print(f"No help available for '{topic}'.")
            return 1
        return 0

    if cmd not in COMMAND_SET:
        return fatal(exe_label(), f"'{cmd}' is not a GROMACS command.", args, quiet,
                     source="src/gromacs/commandline/cmdlinemodulemanager.cpp", line=389,
                     func="gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)")

    return command_run(cmd, rest, quiet)


if __name__ == "__main__":
    sys.exit(main())
