#!/usr/bin/env python3
import argparse
import fnmatch
import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path


VERSION = "tokei 14.0.0 compiled with serialization support: json"


LANGS = {
    "py": ("Python", "#", None, None),
    "pyw": ("Python", "#", None, None),
    "rs": ("Rust", "//", "/*", "*/"),
    "js": ("JavaScript", "//", "/*", "*/"),
    "jsx": ("JSX", "//", "/*", "*/"),
    "ts": ("TypeScript", "//", "/*", "*/"),
    "tsx": ("TSX", "//", "/*", "*/"),
    "c": ("C", "//", "/*", "*/"),
    "h": ("C Header", "//", "/*", "*/"),
    "cc": ("C++", "//", "/*", "*/"),
    "cpp": ("C++", "//", "/*", "*/"),
    "cxx": ("C++", "//", "/*", "*/"),
    "hpp": ("C++ Header", "//", "/*", "*/"),
    "hh": ("C++ Header", "//", "/*", "*/"),
    "java": ("Java", "//", "/*", "*/"),
    "go": ("Go", "//", "/*", "*/"),
    "cs": ("C#", "//", "/*", "*/"),
    "css": ("CSS", None, "/*", "*/"),
    "scss": ("Sass", "//", "/*", "*/"),
    "sass": ("Sass", "//", "/*", "*/"),
    "html": ("HTML", None, "<!--", "-->"),
    "htm": ("HTML", None, "<!--", "-->"),
    "xml": ("XML", None, "<!--", "-->"),
    "svg": ("SVG", None, "<!--", "-->"),
    "sh": ("Shell", "#", None, None),
    "bash": ("BASH", "#", None, None),
    "zsh": ("Zsh", "#", None, None),
    "fish": ("Fish", "#", None, None),
    "rb": ("Ruby", "#", None, None),
    "pl": ("Perl", "#", None, None),
    "pm": ("Perl", "#", None, None),
    "r": ("R", "#", None, None),
    "R": ("R", "#", None, None),
    "lua": ("Lua", "--", "--[[", "]]"),
    "hs": ("Haskell", "--", "{-", "-}"),
    "sql": ("SQL", "--", "/*", "*/"),
    "php": ("PHP", "//", "/*", "*/"),
    "swift": ("Swift", "//", "/*", "*/"),
    "kt": ("Kotlin", "//", "/*", "*/"),
    "kts": ("Kotlin", "//", "/*", "*/"),
    "scala": ("Scala", "//", "/*", "*/"),
    "dart": ("Dart", "//", "/*", "*/"),
    "ex": ("Elixir", "#", None, None),
    "exs": ("Elixir", "#", None, None),
    "erl": ("Erlang", "%", None, None),
    "hrl": ("Erlang", "%", None, None),
    "clj": ("Clojure", ";", None, None),
    "vim": ("Vim script", '"', None, None),
    "md": ("Markdown", None, None, None),
    "markdown": ("Markdown", None, None, None),
    "json": ("JSON", None, None, None),
    "toml": ("TOML", "#", None, None),
    "yaml": ("YAML", "#", None, None),
    "yml": ("YAML", "#", None, None),
    "ini": ("INI", ";", None, None),
    "cfg": ("INI", ";", None, None),
    "makefile": ("Makefile", "#", None, None),
    "mk": ("Makefile", "#", None, None),
    "cmake": ("CMake", "#", None, None),
    "dockerfile": ("Dockerfile", "#", None, None),
}

SPECIAL_NAMES = {
    "Makefile": ("Makefile", "#", None, None),
    "makefile": ("Makefile", "#", None, None),
    "Dockerfile": ("Dockerfile", "#", None, None),
    "dockerfile": ("Dockerfile", "#", None, None),
    "CMakeLists.txt": ("CMake", "#", None, None),
}

LANGUAGE_LIST = [
    ("ABNF", "abnf"), ("AWK", "awk"), ("ABAP", "abap"), ("ActionScript", "as"),
    ("Ada", "ada, adb, ads, pad"), ("Agda", "agda"), ("Alex", "x"),
    ("Alloy", "als"), ("APL", "apl, aplf, apls"), ("Arduino C++", "ino"),
    ("AsciiDoc", "adoc, asciidoc"), ("Assembly", "asm"), ("BASH", "bash"),
    ("Batch", "bat, btm, cmd"), ("C", "c, ec, pgc"), ("C Header", "h"),
    ("CMake", "cmake"), ("C#", "cs, csx"), ("C Shell", "csh"),
    ("C++", "cc, cpp, cxx, c++, pcc, tpp"), ("C++ Header", "hh, hpp, hxx, inl, ipp"),
    ("CSS", "css"), ("Dart", "dart"), ("Dockerfile", "dockerfile, dockerignore"),
    ("Elixir", "ex, exs"), ("Erlang", "erl, hrl"), ("Go", "go"),
    ("Haskell", "hs"), ("HTML", "html, htm"), ("Java", "java"),
    ("JavaScript", "js, mjs, cjs"), ("JSON", "json"), ("JSX", "jsx"),
    ("Kotlin", "kt, kts"), ("Lua", "lua"), ("Makefile", "makefile, mk"),
    ("Markdown", "md, markdown"), ("Perl", "pl, pm"), ("PHP", "php"),
    ("Python", "py, pyw"), ("R", "r, R"), ("Ruby", "rb"), ("Rust", "rs"),
    ("Sass", "sass, scss"), ("Scala", "scala"), ("Shell", "sh"),
    ("SQL", "sql"), ("SVG", "svg"), ("Swift", "swift"), ("TOML", "toml"),
    ("TSX", "tsx"), ("TypeScript", "ts"), ("Vim script", "vim"),
    ("XML", "xml"), ("YAML", "yaml, yml"), ("Zsh", "zsh"),
]


@dataclass
class Stats:
    blanks: int = 0
    code: int = 0
    comments: int = 0
    reports: list = field(default_factory=list)
    children: dict = field(default_factory=dict)

    @property
    def lines(self):
        return self.blanks + self.code + self.comments

    @property
    def files(self):
        return len(self.reports)

    def add_report(self, path, st):
        self.blanks += st.blanks
        self.code += st.code
        self.comments += st.comments
        self.reports.append({"name": path, "stats": st})


def split_lines(text):
    if text == "":
        return []
    return text.splitlines()


def strip_strings_for_comment_scan(line):
    out = []
    quote = None
    esc = False
    for ch in line:
        if quote:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
            out.append(" ")
        elif ch in ("'", '"', "`"):
            quote = ch
            out.append(" ")
        else:
            out.append(ch)
    return "".join(out)


def count_plain(text):
    st = Stats()
    for line in split_lines(text):
        if line.strip():
            st.code += 1
        else:
            st.blanks += 1
    return st


def count_line_comment(text, marker):
    st = Stats()
    for line in split_lines(text):
        s = line.strip()
        if not s:
            st.blanks += 1
        elif s.startswith(marker):
            st.comments += 1
        else:
            st.code += 1
    return st


def count_c_like(text, line_marker="//", block_start="/*", block_end="*/"):
    st = Stats()
    in_block = False
    for line in split_lines(text):
        raw = line.rstrip("\n")
        if raw.strip() == "":
            st.blanks += 1
            continue
        i = 0
        has_code = False
        has_comment = False
        scan = strip_strings_for_comment_scan(raw)
        while i < len(scan):
            if in_block:
                has_comment = True
                end = scan.find(block_end, i)
                if end == -1:
                    i = len(scan)
                else:
                    i = end + len(block_end)
                    in_block = False
                continue
            bs = scan.find(block_start, i) if block_start else -1
            ls = scan.find(line_marker, i) if line_marker else -1
            poss = [(p, "block") for p in [bs] if p >= 0] + [(p, "line") for p in [ls] if p >= 0]
            if not poss:
                if raw[i:].strip():
                    has_code = True
                break
            p, kind = min(poss)
            if raw[i:p].strip():
                has_code = True
            has_comment = True
            if kind == "line":
                break
            end = scan.find(block_end, p + len(block_start))
            if end == -1:
                in_block = True
                break
            i = end + len(block_end)
        if has_code:
            st.code += 1
        elif has_comment:
            st.comments += 1
        else:
            st.blanks += 1
    return st


def count_markdown(text):
    st = Stats()
    in_fence = False
    fence_lang = ""
    buf = []
    for line in split_lines(text):
        s = line.strip()
        if s.startswith("```") or s.startswith("~~~"):
            st.comments += 1
            if in_fence:
                if fence_lang and buf:
                    lang = lang_from_fence(fence_lang)
                    if lang:
                        child = count_by_language("\n".join(buf), lang)
                        reps = st.children.setdefault(lang[0], [])
                        if reps:
                            agg = reps[0]["stats"]
                            agg.blanks += child.blanks
                            agg.code += child.code
                            agg.comments += child.comments
                        else:
                            st.children[lang[0]].append({"name": "", "stats": child})
                in_fence = False
                buf = []
                fence_lang = ""
            else:
                in_fence = True
                fence_lang = s[3:].strip().split()[0] if len(s) > 3 else ""
        elif in_fence:
            buf.append(line)
            if not lang_from_fence(fence_lang):
                if s:
                    st.comments += 1
                else:
                    st.blanks += 1
        elif s:
            st.comments += 1
        else:
            st.blanks += 1
    return st


def lang_from_fence(f):
    f = f.lower()
    aliases = {"shell": "sh", "bash": "bash", "sh": "sh", "rust": "rs", "rs": "rs",
               "json": "json", "python": "py", "py": "py", "javascript": "js", "js": "js",
               "typescript": "ts", "ts": "ts", "toml": "toml", "yaml": "yaml", "yml": "yml"}
    ext = aliases.get(f)
    return LANGS.get(ext) if ext else None


def count_by_language(text, langinfo):
    name, line, block_start, block_end = langinfo
    if name == "Markdown":
        return count_markdown(text)
    if name in ("JSON",):
        return count_plain(text)
    if block_start:
        return count_c_like(text, line, block_start, block_end)
    if line:
        return count_line_comment(text, line)
    return count_plain(text)


def detect_language(path):
    base = os.path.basename(path)
    if base in SPECIAL_NAMES:
        return SPECIAL_NAMES[base]
    ext = base.rsplit(".", 1)[-1] if "." in base else ""
    if ext in LANGS:
        return LANGS[ext]
    lower = ext.lower()
    return LANGS.get(lower)


def read_ignore_file(path):
    pats = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    pats.append(line)
    except OSError:
        pass
    return pats


def ignored(rel, name, patterns):
    for pat in patterns:
        p = pat.rstrip("/")
        if not p:
            continue
        if fnmatch.fnmatch(name, p) or fnmatch.fnmatch(rel, p) or fnmatch.fnmatch(rel, p + "/*"):
            return True
    return False


def iter_files(inputs, include_hidden, no_ignore, excludes):
    patterns = list(excludes or [])
    roots = inputs or ["."]
    for root in roots:
        rootp = Path(root)
        if rootp.is_file():
            rel = str(rootp)
            if include_hidden or not any(part.startswith(".") for part in rootp.parts):
                if not ignored(rel, rootp.name, patterns):
                    yield str(rootp)
            continue
        if not rootp.exists():
            print(f"Error: {root}: No such file or directory (os error 2)", file=sys.stderr)
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dpath = Path(dirpath)
            local_patterns = []
            if not no_ignore:
                local_patterns += read_ignore_file(dpath / ".tokeignore")
                local_patterns += read_ignore_file(dpath / ".ignore")
                local_patterns += read_ignore_file(dpath / ".gitignore")
            all_patterns = patterns + local_patterns
            keep_dirs = []
            for d in dirnames:
                rel = os.path.relpath(os.path.join(dirpath, d), root)
                if (not include_hidden and d.startswith(".")) or ignored(rel, d, all_patterns):
                    continue
                keep_dirs.append(d)
            dirnames[:] = keep_dirs
            for f in filenames:
                rel = os.path.relpath(os.path.join(dirpath, f), root)
                if (not include_hidden and f.startswith(".")) or ignored(rel, f, all_patterns):
                    continue
                yield os.path.join(dirpath, f)


def analyze(paths, args):
    langs = {}
    verbose = args.verbose or 0
    type_filter = None
    if args.types:
        type_filter = {x.strip() for x in args.types.split(",") if x.strip()}
    for path in iter_files(paths, args.hidden, args.no_ignore or args.no_ignore_dot or args.no_ignore_vcs, args.exclude):
        langinfo = detect_language(path)
        if not langinfo:
            if verbose >= 1:
                ext = os.path.basename(path).rsplit(".", 1)[-1] if "." in os.path.basename(path) else os.path.basename(path)
                print(f"[2026-06-01T00:00:00Z WARN  tokei::language::language_type] Unknown extension: {ext}", file=sys.stderr)
            continue
        lname = langinfo[0]
        if type_filter and lname not in type_filter:
            continue
        try:
            data = Path(path).read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        st = count_by_language(data, langinfo)
        langs.setdefault(lname, Stats()).add_report(path, st)
        for child_name, reps in st.children.items():
            langs[lname].children.setdefault(child_name, []).extend(reps)
    return langs


def sort_items(langs, args):
    items = list(langs.items())
    keyname = args.sort or args.rsort
    reverse = bool(args.rsort)
    if keyname:
        def key(item):
            name, st = item
            if keyname == "files":
                val = st.files
            elif keyname == "lines":
                val = st.lines
            else:
                val = getattr(st, keyname)
            return (val, name)
        return sorted(items, key=key, reverse=reverse)
    return sorted(items, key=lambda x: x[0])


def fmt_num(n, style):
    s = str(n)
    if style == "commas":
        return f"{n:,}"
    if style == "underscores":
        return f"{n:_}"
    if style == "dots":
        return f"{n:,}".replace(",", ".")
    return s


def print_table(langs, args):
    width = int(args.columns) if args.columns else 81
    top = "━" * width
    sep = "─" * width
    print(top)
    print(f" {'Language':<18}{'Files':>8}{'Lines':>13}{'Code':>13}{'Comments':>13}{'Blanks':>13}")
    print(top)
    total = Stats()
    for name, st in sort_items(langs, args):
        child_blanks = sum(r["stats"].blanks for reps in st.children.values() for r in reps)
        child_code = sum(r["stats"].code for reps in st.children.values() for r in reps)
        child_comments = sum(r["stats"].comments for reps in st.children.values() for r in reps)
        child_lines = child_blanks + child_code + child_comments
        print(f" {name:<18}{fmt_num(st.files,args.num_format):>8}{fmt_num(st.lines,args.num_format):>13}{fmt_num(st.code,args.num_format):>13}{fmt_num(st.comments,args.num_format):>13}{fmt_num(st.blanks,args.num_format):>13}")
        if st.children and not args.compact:
            for cname, reps in sorted(st.children.items()):
                cst = Stats()
                for r in reps:
                    rs = r["stats"]
                    cst.blanks += rs.blanks; cst.code += rs.code; cst.comments += rs.comments
                print(f" |- {cname:<15}{len(reps):>8}{fmt_num(cst.lines,args.num_format):>13}{fmt_num(cst.code,args.num_format):>13}{fmt_num(cst.comments,args.num_format):>13}{fmt_num(cst.blanks,args.num_format):>13}")
            print(f" {'(Total)':<26}{fmt_num(st.lines + child_lines,args.num_format):>13}{fmt_num(st.code + child_code,args.num_format):>13}{fmt_num(st.comments + child_comments,args.num_format):>13}{fmt_num(st.blanks + child_blanks,args.num_format):>13}")
        if args.files:
            print(sep)
            for rep in sorted(st.reports, key=lambda r: r["name"]):
                rs = rep["stats"]
                print(f" {rep['name']:<26}{fmt_num(rs.lines,args.num_format):>13}{fmt_num(rs.code,args.num_format):>13}{fmt_num(rs.comments,args.num_format):>13}{fmt_num(rs.blanks,args.num_format):>13}")
            print(sep)
        total.blanks += st.blanks + child_blanks
        total.code += st.code + child_code
        total.comments += st.comments + child_comments
        total.reports.extend(st.reports)
    print(top)
    print(f" {'Total':<18}{fmt_num(len(total.reports),args.num_format):>8}{fmt_num(total.lines,args.num_format):>13}{fmt_num(total.code,args.num_format):>13}{fmt_num(total.comments,args.num_format):>13}{fmt_num(total.blanks,args.num_format):>13}")
    print(top)


def stats_json(st):
    return {"blanks": st.blanks, "code": st.code, "comments": st.comments, "blobs": {}}


def output_json(langs):
    obj = {}
    total = Stats()
    children = {}
    for name, st in sorted(langs.items()):
        child_blanks = sum(r["stats"].blanks for reps in st.children.values() for r in reps)
        child_code = sum(r["stats"].code for reps in st.children.values() for r in reps)
        child_comments = sum(r["stats"].comments for reps in st.children.values() for r in reps)
        reports = [{"stats": stats_json(r["stats"]), "name": r["name"]} for r in st.reports]
        child_obj = {}
        for cname, reps in st.children.items():
            child_obj[cname] = [{"stats": stats_json(r["stats"]), "name": r.get("name", "")} for r in reps]
        obj[name] = {"blanks": st.blanks, "code": st.code, "comments": st.comments,
                     "reports": reports, "children": child_obj, "inaccurate": False}
        total.blanks += st.blanks + child_blanks; total.code += st.code + child_code; total.comments += st.comments + child_comments
        children[name] = reports
    obj["Total"] = {"blanks": total.blanks, "code": total.code, "comments": total.comments,
                    "reports": [], "children": children, "inaccurate": False}
    print(json.dumps(obj, separators=(",", ":")))


def print_stream(langs, mode):
    rows = []
    for name, st in sorted(langs.items()):
        for rep in sorted(st.reports, key=lambda r: r["name"]):
            rs = rep["stats"]
            rows.append((name, rep["name"], rs.lines, rs.code, rs.comments, rs.blanks))
    if mode == "json":
        for row in rows:
            print(json.dumps({"language": row[0], "path": row[1], "lines": row[2], "code": row[3], "comments": row[4], "blanks": row[5]}, separators=(",", ":")))
    else:
        print("# language                                        path                                          lines         code       comments      blanks   ")
        print("########## ################################################################################ ############ ############ ############ ############")
        for lang, path, lines, code, comments, blanks in rows:
            print(f"{lang:>10} {path:<80} {lines:>12} {code:>12} {comments:>12} {blanks:>12}")


def print_languages():
    width = 72
    print("━" * width)
    print(f"┃ {'Language':<37}{'Extensions':<31}┃")
    print("┃" + "━" * (width - 2) + "┃")
    for name, exts in LANGUAGE_LIST:
        e = exts if len(exts) <= 30 else exts[:27] + "..."
        print(f"┃ {name:<37}{e:<31}┃")
    print("━" * width)


def make_parser():
    p = argparse.ArgumentParser(prog="executable", description="Count your code, quickly.", add_help=False)
    p.add_argument("-c", "--columns")
    p.add_argument("-e", "--exclude", action="append", default=[])
    p.add_argument("-f", "--files", action="store_true")
    p.add_argument("-i", "--input", dest="file_input")
    p.add_argument("--hidden", action="store_true")
    p.add_argument("-l", "--languages", action="store_true")
    p.add_argument("--no-ignore", action="store_true")
    p.add_argument("--no-ignore-parent", action="store_true")
    p.add_argument("--no-ignore-dot", action="store_true")
    p.add_argument("--no-ignore-vcs", action="store_true")
    p.add_argument("-o", "--output")
    p.add_argument("--streaming", choices=["simple", "json"])
    p.add_argument("-s", "--sort", choices=["files", "lines", "blanks", "code", "comments"])
    p.add_argument("-r", "--rsort", choices=["files", "lines", "blanks", "code", "comments"])
    p.add_argument("-t", "--types", "--type")
    p.add_argument("-C", "--compact", action="store_true")
    p.add_argument("-n", "--num-format", dest="num_format", default="plain", choices=["commas", "dots", "plain", "underscores"])
    p.add_argument("-v", "--verbose", action="count", default=0)
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("input", nargs="*")
    return p


HELP = """Count your code, quickly.
Support this project on GitHub Sponsors: https://github.com/sponsors/XAMPPRocky

Usage: executable [OPTIONS] [input]...

Arguments:
  [input]...  The path(s) to the file or directory to be counted. (default current directory)

Options:
  -c, --columns <columns>              Sets a strict column width of the output, only available for terminal output.
  -e, --exclude <exclude>              Ignore all files & directories matching the pattern.
  -f, --files                          Will print out statistics on individual files.
  -i, --input <file_input>             Gives statistics from a previous tokei run.
      --hidden                         Count hidden files.
  -l, --languages                      Prints out supported languages and their extensions.
      --no-ignore                      Don't respect ignore files (.gitignore, .ignore, etc.).
  -o, --output <output>                Outputs Tokei in a specific format.
      --streaming <streaming>          [possible values: simple, json]
  -s, --sort <sort>                    [possible values: files, lines, blanks, code, comments]
  -r, --rsort <rsort>                  [possible values: files, lines, blanks, code, comments]
  -t, --types <types>                  Filters output by language type, separated by a comma.
  -C, --compact                        Do not print statistics about embedded languages.
  -n, --num-format <num_format_style>  [possible values: commas, dots, plain, underscores]
  -v, --verbose...                     Set log output level
  -h, --help                           Print help
  -V, --version                        Print version"""


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--help" in argv or "-h" in argv:
        print(HELP)
        return 0
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        return 0
    args = make_parser().parse_args(argv)
    if args.languages:
        print_languages()
        return 0
    if args.output and args.output != "json":
        print(f"error: invalid value '{args.output}' for '--output <output>': This version of tokei was compiled without any '{args.output}' serialization support, to enable serialization, reinstall tokei with the features flag.\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    langs = analyze(args.input, args)
    if args.output == "json":
        output_json(langs)
    elif args.streaming:
        print_stream(langs, args.streaming)
    else:
        print_table(langs, args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
