#!/usr/bin/env python3
import argparse
import base64
import hashlib
import json
import os
import re
import sys

VERSION = "lightningcss 1.0.0-alpha.70"
HELP = """lightningcss 1.0.0-alpha.70
Devon Govett <devongovett@gmail.com>
A CSS parser, transformer, and minifier

USAGE:
    executable [OPTIONS] [INPUT_FILE]...

ARGS:
    <INPUT_FILE>...    Target CSS file (default: stdin)

OPTIONS:
        --browserslist
            

        --bundle
            

        --css-modules [<CSS_MODULES>]
            Enable CSS modules in output. If no filename is provided, <output_file>.json will be
            used. If no --output-file is specified, code and exports will be printed to stdout as
            JSON

        --css-modules-dashed-idents
            

        --css-modules-pattern <CSS_MODULES_PATTERN>
            

        --custom-media
            Enable parsing custom media queries

    -d, --output-dir <OUTPUT_DIR>
            Destination directory to output into

        --error-recovery
            

    -h, --help
            Print help information

    -m, --minify
            Minify the output

    -o, --output-file <OUTPUT_FILE>
            Destination file for the output

        --sourcemap
            Enable sourcemap, at <output_file>.map

    -t, --targets <TARGETS>
            

    -V, --version
            Print version information
"""

NAMED = {
    "black": "#000",
    "white": "#fff",
    "blue": "#00f",
    "yellow": "#ff0",
    "fuchsia": "#f0f",
    "magenta": "#f0f",
    "cyan": "#0ff",
    "aqua": "#0ff",
}

def eprint(s):
    sys.stderr.write(s + "\n")

def short_hash(path):
    h = hashlib.sha256(os.path.abspath(path).encode()).digest()
    return base64.urlsafe_b64encode(h)[:6].decode().replace("-", "_")

def strip_comments(css):
    kept = []
    def repl(m):
        txt = m.group(0)
        if txt.startswith("/*!"):
            kept.append(txt)
        return ""
    css = re.sub(r"/\*[\s\S]*?\*/", repl, css)
    return kept, css

def split_selector(sel):
    return re.sub(r"\s+", " ", sel.strip())

def find_matching(s, i):
    depth = 0
    quote = None
    esc = False
    for j in range(i, len(s)):
        c = s[j]
        if quote:
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == quote:
                quote = None
        elif c in "'\"":
            quote = c
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return j
    return -1

def top_level_items(css):
    items = []
    i = 0
    n = len(css)
    while i < n:
        while i < n and css[i].isspace():
            i += 1
        if i >= n:
            break
        if css.startswith("@charset", i):
            j = css.find(";", i)
            i = n if j < 0 else j + 1
            continue
        if css.startswith("@import", i):
            j = css.find(";", i)
            if j < 0:
                break
            imp = css[i:j + 1].strip()
            imp = re.sub(r"@import\s+url\((['\"]?)(.*?)\1\)", r'@import "\2"', imp)
            items.append(("import", imp))
            i = j + 1
            continue
        b = css.find("{", i)
        semi = css.find(";", i)
        if b < 0:
            tail = css[i:].strip()
            if tail:
                items.append(("raw", tail))
            break
        if semi >= 0 and semi < b:
            raw = css[i:semi + 1].strip()
            if raw:
                items.append(("raw", raw))
            i = semi + 1
            continue
        end = find_matching(css, b)
        if end < 0:
            raise ValueError("Unexpected end of input")
        head = split_selector(css[i:b])
        body = css[b + 1:end]
        if head.startswith("@media") or head.startswith("@supports") or head.startswith("@layer") or head.startswith("@container"):
            items.append(("atrule", head, top_level_items(body)))
        elif head.startswith("@keyframes") or head.startswith("@-"):
            items.append(("keyframes", head, parse_rule_body(body, in_keyframes=True)))
        else:
            items.append(("rule", head, parse_rule_body(body)))
        i = end + 1
    return items

def parse_rule_body(body, in_keyframes=False):
    parts = []
    i = 0
    n = len(body)
    while i < n:
        while i < n and body[i].isspace():
            i += 1
        if i >= n:
            break
        b = body.find("{", i)
        semi = body.find(";", i)
        if b >= 0 and (semi < 0 or b < semi):
            end = find_matching(body, b)
            if end < 0:
                raise ValueError("Unexpected end of input")
            sel = split_selector(body[i:b])
            parts.append(("nested", sel, parse_rule_body(body[b + 1:end], in_keyframes=in_keyframes)))
            i = end + 1
        else:
            if semi < 0:
                frag = body[i:].strip()
                i = n
            else:
                frag = body[i:semi].strip()
                i = semi + 1
            if not frag or ":" not in frag:
                continue
            prop, val = frag.split(":", 1)
            parts.append(("decl", prop.strip(), val.strip()))
    return parts

def compress_box(vals):
    p = vals.split()
    if len(p) == 4:
        if p[0] == p[2] and p[1] == p[3]:
            p = [p[0]] if p[0] == p[1] else [p[0], p[1]]
        elif p[1] == p[3]:
            p = p[:3]
    if len(p) == 3 and p[0] == p[2]:
        p = p[:2]
    if len(p) == 2 and p[0] == p[1]:
        p = p[:1]
    return " ".join(p)

def hex_short(h):
    h = h.lower()
    if len(h) == 7 and h[1] == h[2] and h[3] == h[4] and h[5] == h[6]:
        return "#" + h[1] + h[3] + h[5]
    if len(h) == 9 and h[1] == h[2] and h[3] == h[4] and h[5] == h[6] and h[7] == h[8]:
        return "#" + h[1] + h[3] + h[5] + h[7]
    return h

def rgb_repl(m):
    nums = [x.strip() for x in re.split(r"[,/ ]+", m.group(1).strip()) if x.strip()]
    if len(nums) < 3:
        return m.group(0)
    try:
        r, g, b = [max(0, min(255, int(float(x.rstrip("%")) * (2.55 if x.endswith("%") else 1)))) for x in nums[:3]]
        if len(nums) >= 4:
            a = nums[3]
            av = float(a.rstrip("%")) / (100 if a.endswith("%") else 1)
            return hex_short("#%02x%02x%02x%02x" % (r, g, b, round(max(0, min(1, av)) * 255)))
        return color_name_or_hex(hex_short("#%02x%02x%02x" % (r, g, b)))
    except Exception:
        return m.group(0)

def color_name_or_hex(h):
    rev = {"#f00": "red", "#008000": "green", "#0f0": "lime", "#0000ff": "#00f", "#00f": "#00f", "#fff": "#fff", "#000": "#000"}
    return rev.get(h.lower(), h.lower())

def normalize_value(prop, val, minify=False):
    v = val.strip()
    v = re.sub(r"\s+", " ", v)
    v = re.sub(r"\b0(?:\.0+)?(px|em|rem|%|vh|vw|ms|s|deg|turn|rad)\b", "0", v)
    v = re.sub(r"(?i)#([0-9a-f]{6}|[0-9a-f]{8})\b", lambda m: hex_short("#" + m.group(1)), v)
    v = re.sub(r"(?i)\brgba?\(([^()]*)\)", rgb_repl, v)
    for name, hx in NAMED.items():
        if len(hx) <= len(name):
            v = re.sub(r"\b" + re.escape(name) + r"\b", hx, v, flags=re.I)
    v = v.replace("inline flex", "inline-flex").replace("block flow", "block")
    if prop in ("margin", "padding", "border-width", "border-radius"):
        v = compress_box(v)
    if minify:
        if prop == "font-weight":
            v = re.sub(r"\bbold\b", "700", v)
            v = re.sub(r"\bnormal\b", "400", v)
        v = re.sub(r"\s*([(),*/+-])\s*", r"\1", v)
    if prop == "animation":
        # Lightning normalizes simple animation-name duration order.
        bits = v.split()
        if len(bits) == 2 and re.match(r"^[\w-]+$", bits[0]) and re.match(r"^[\d.]+m?s$", bits[1]):
            v = bits[1] + " " + bits[0]
    return v

def normalize_prop(prop):
    return prop.strip().lower()

def format_decls(parts, level, minify, exports=None):
    out = []
    indent = "  " * level
    for part in parts:
        if part[0] == "decl":
            _, prop, val = part
            prop = normalize_prop(prop)
            if prop == "composes":
                continue
            val = normalize_value(prop, val, minify)
            out.append(f"{prop}:{val}" if minify else f"{indent}  {prop}: {val};")
        elif part[0] == "nested":
            _, sel, body = part
            if minify:
                out.append(f"{sel}{{{minify_decls(body)}}}")
            else:
                if out:
                    out.append("")
                out.append(f"{indent}  {sel} {{")
                out.extend(format_decls(body, level + 1, minify))
                out.append(f"{indent}  }}")
    return out

def minify_decls(parts):
    out = []
    pending_decl = False
    for part in parts:
        if part[0] == "decl":
            prop = normalize_prop(part[1])
            if prop == "composes":
                continue
            val = normalize_value(prop, part[2], True)
            if pending_decl:
                out.append(";")
            out.append(f"{prop}:{val}")
            pending_decl = True
        elif part[0] == "nested":
            out.append(f"{part[1]}{{{minify_decls(part[2])}}}")
            pending_decl = False
    return "".join(out)

def render_items(items, minify=False, level=0):
    chunks = []
    indent = "  " * level
    for item in items:
        typ = item[0]
        if typ == "comment":
            chunks.append(item[1] if minify else indent + item[1])
        elif typ == "import":
            chunks.append(item[1] if minify else indent + item[1])
        elif typ == "raw":
            chunks.append(item[1])
        elif typ == "rule":
            _, sel, body = item
            if minify:
                chunks.append(sel.replace(", ", ",") + "{" + minify_decls(body) + "}")
            else:
                lines = [f"{indent}{sel} {{"]
                lines.extend(format_decls(body, level, False))
                lines.append(f"{indent}}}")
                chunks.append("\n".join(lines))
        elif typ == "atrule":
            _, head, children = item
            if minify:
                h = re.sub(r"\s*([<>=:])\s*", r"\1", head)
                chunks.append(h + "{" + render_items(children, True, level + 1) + "}")
            else:
                inner = render_items(children, False, level + 1).rstrip("\n")
                if inner:
                    chunks.append(f"{indent}{head} {{\n{inner}\n{indent}}}")
                else:
                    chunks.append(f"{indent}{head} {{\n{indent}}}")
        elif typ == "keyframes":
            _, head, frames = item
            if minify:
                body = []
                for fr in frames:
                    if fr[0] == "nested":
                        name = "0%" if fr[1] == "from" else fr[1]
                        body.append(name + "{" + minify_decls(fr[2]) + "}")
                chunks.append(head + "{" + "".join(body) + "}")
            else:
                lines = [f"{indent}{head} {{"]
                first = True
                for fr in frames:
                    if fr[0] == "nested":
                        if not first:
                            lines.append("")
                        first = False
                        lines.append(f"{indent}  {fr[1]} {{")
                        lines.extend(format_decls(fr[2], level + 1, False))
                        lines.append(f"{indent}  }}")
                lines.append(f"{indent}}}")
                chunks.append("\n".join(lines))
    if minify:
        return "".join(chunks)
    return "\n\n".join(chunks) + ("\n" if chunks else "")

def bundle_imports(css, base):
    def repl(m):
        name = m.group(2)
        path = os.path.join(base, name)
        try:
            with open(path, encoding="utf-8") as f:
                return f.read()
        except OSError:
            return m.group(0)
    return re.sub(r'@import\s+(url\()?["\']([^"\']+)["\']\)?\s*;', repl, css)

def module_transform(css, filename, pattern=None, dashed=False):
    stem = os.path.splitext(os.path.basename(filename or "stdin"))[0].replace(".", "-")
    h = short_hash(filename or "stdin")
    def scoped(local):
        if pattern:
            return pattern.replace("[name]", stem).replace("[local]", local).replace("[hash]", h)
        return f"{h}_{local}"
    exports = {}
    for m in re.finditer(r"(?<![\w-])\.([_a-zA-Z][\w-]*)|#([_a-zA-Z][\w-]*)", css):
        local = m.group(1) or m.group(2)
        exports.setdefault(local, {"name": scoped(local), "composes": [], "isReferenced": False})
    for m in re.finditer(r"@keyframes\s+([_a-zA-Z][\w-]*)", css):
        local = m.group(1)
        exports.setdefault(local, {"name": scoped(local), "composes": [], "isReferenced": True})
    for m in re.finditer(r"composes\s*:\s*([_a-zA-Z][\w-]*)", css):
        local = m.group(1)
        # Attach to the nearest preceding class.
        prev = list(re.finditer(r"\.([_a-zA-Z][\w-]*)[^{]*\{[^{}]*$", css[:m.start()]))
        if prev:
            owner = prev[-1].group(1)
            exports.setdefault(owner, {"name": scoped(owner), "composes": [], "isReferenced": False})
            exports[owner]["composes"].append({"type": "local", "name": scoped(local)})
    def repl_sel(m):
        sig, local = m.group(1), m.group(2)
        if local in exports:
            return sig + exports[local]["name"]
        return m.group(0)
    css = re.sub(r"([.#])([_a-zA-Z][\w-]*)", repl_sel, css)
    css = re.sub(r":global\(([^)]*)\)", r"\1", css)
    for local, obj in exports.items():
        css = re.sub(r"(@keyframes\s+)" + re.escape(local) + r"\b", r"\1" + obj["name"], css)
        css = re.sub(r"\b" + re.escape(local) + r"\b", obj["name"], css) if obj["isReferenced"] else css
    if dashed:
        for m in re.finditer(r"--([_a-zA-Z][\w-]*)", css):
            local = "--" + m.group(1)
            if local not in exports:
                exports[local] = {"name": "--" + scoped(m.group(1)), "composes": [], "isReferenced": True}
        for local, obj in sorted(exports.items(), key=lambda x: -len(x[0])):
            if local.startswith("--"):
                css = css.replace(local, obj["name"])
    return css, dict(sorted(exports.items()))

def transform(css, filename=None, minify=False, bundle=False, css_modules=False, pattern=None, dashed=False):
    if bundle and filename:
        css = bundle_imports(css, os.path.dirname(os.path.abspath(filename)))
    if css_modules:
        css, exports = module_transform(css, filename or "stdin", pattern, dashed)
    else:
        exports = None
    kept, rest = strip_comments(css)
    try:
        items = [("comment", c) for c in kept] + top_level_items(rest)
        code = render_items(items, minify)
        if minify:
            code = re.sub(r"(/\*![\s\S]*?\*/)(?=@)", r"\1\n", code)
        else:
            code = re.sub(r"(/\*![\s\S]*?\*/)\n\n(?=@)", r"\1\n", code)
    except ValueError:
        raise
    if css_modules:
        return code, exports
    return code, None

def write_sourcemap(out_path, source_name, source_content):
    mp = {"version": 3, "mappings": "AAAA", "sources": [source_name], "sourcesContent": [source_content], "names": []}
    with open(out_path + ".map", "w", encoding="utf-8") as f:
        json.dump(mp, f, separators=(",", ":"))

def parse_args(argv):
    if any(a in ("-h", "--help") for a in argv):
        print(HELP, end="")
        raise SystemExit(0)
    if any(a in ("-V", "--version") for a in argv):
        print(VERSION)
        raise SystemExit(0)
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-m", "--minify", action="store_true")
    p.add_argument("-o", "--output-file")
    p.add_argument("-d", "--output-dir")
    p.add_argument("--sourcemap", action="store_true")
    p.add_argument("--bundle", action="store_true")
    p.add_argument("--custom-media", action="store_true")
    p.add_argument("--error-recovery", action="store_true")
    p.add_argument("--browserslist", action="store_true")
    p.add_argument("-t", "--targets")
    p.add_argument("--css-modules", nargs="?", const="")
    p.add_argument("--css-modules-pattern")
    p.add_argument("--css-modules-dashed-idents", action="store_true")
    p.add_argument("inputs", nargs="*")
    try:
        return p.parse_args(argv)
    except SystemExit as ex:
        raise SystemExit(ex.code)

def main(argv):
    args = parse_args(argv)
    inputs = args.inputs
    if len(inputs) > 1 and not args.output_dir:
        print("Cannot output to stdout with multiple inputs. Use --output-dir instead.")
        return 1
    if not inputs:
        source = sys.stdin.read()
        try:
            code, exports = transform(source, "stdin", args.minify, args.bundle, args.css_modules is not None, args.css_modules_pattern, args.css_modules_dashed_idents)
        except ValueError:
            if args.error_recovery:
                print("Unexpected end of input at stdin:0:0")
                return 0
            eprint("Unexpected end of input")
            return 101
        if args.css_modules is not None and not args.output_file:
            print(json.dumps({"code": code, "exports": exports}, separators=(",", ":")))
        elif args.output_file:
            with open(args.output_file, "w", encoding="utf-8") as f:
                f.write(code)
        else:
            sys.stdout.write(code + "\n")
        return 0
    for inp in inputs:
        try:
            with open(inp, encoding="utf-8") as f:
                source = f.read()
        except OSError:
            eprint('Error: Os { code: 2, kind: NotFound, message: "No such file or directory" }')
            return 1
        try:
            code, exports = transform(source, inp, args.minify, args.bundle, args.css_modules is not None, args.css_modules_pattern, args.css_modules_dashed_idents)
        except ValueError:
            if args.error_recovery:
                code, exports = "", {}
            else:
                eprint("Unexpected end of input")
                return 101
        out_path = args.output_file
        if args.output_dir:
            out_path = os.path.join(args.output_dir, os.path.basename(inp))
        if args.css_modules is not None and not out_path:
            print(json.dumps({"code": code, "exports": exports}, separators=(",", ":")))
            continue
        if out_path:
            os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(code)
            if args.css_modules is not None:
                mod_path = args.css_modules or os.path.splitext(out_path)[0] + ".json"
                with open(mod_path, "w", encoding="utf-8") as f:
                    json.dump(exports, f, separators=(",", ":"))
            if args.sourcemap:
                with open(out_path, "a", encoding="utf-8") as f:
                    f.write("\n/*# sourceMappingURL=" + os.path.basename(out_path) + ".map */\n")
                write_sourcemap(out_path, os.path.basename(inp), source)
        else:
            sys.stdout.write(code + "\n")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
