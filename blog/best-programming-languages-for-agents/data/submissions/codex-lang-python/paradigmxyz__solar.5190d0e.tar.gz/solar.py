#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys

VERSION = "0.1.8"
VERSION_LONG = """solar Version: 0.1.8
Commit SHA: 8f228ae9f0bd90ad4ec81fb1ef4fbba29748b8d5
Build Timestamp: 2026-04-17T19:59:51.519973035Z
Build Features: mimalloc,tracing
Build Profile: release"""

EVM_VALUES = "homestead tangerineWhistle spuriousDragon byzantium constantinople petersburg istanbul berlin london paris shanghai cancun prague osaka".split()

ROUND = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A, 0x8000000080008000,
    0x000000000000808B, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
    0x000000000000008A, 0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089, 0x8000000000008003,
    0x8000000000008002, 0x8000000000000080, 0x000000000000800A, 0x800000008000000A,
    0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]
ROT = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
]


def rol(x, n):
    return ((x << n) | (x >> (64 - n))) & ((1 << 64) - 1)


def keccak256(data: bytes) -> bytes:
    rate = 136
    state = [0] * 25
    padded = bytearray(data)
    padded.append(1)
    while len(padded) % rate != rate - 1:
        padded.append(0)
    padded.append(0x80)
    for off in range(0, len(padded), rate):
        block = padded[off:off + rate]
        for i in range(rate // 8):
            state[i] ^= int.from_bytes(block[i * 8:(i + 1) * 8], "little")
        keccak_f(state)
    out = bytearray()
    while len(out) < 32:
        for i in range(rate // 8):
            out.extend(state[i].to_bytes(8, "little"))
        if len(out) < 32:
            keccak_f(state)
    return bytes(out[:32])


def keccak_f(a):
    mask = (1 << 64) - 1
    for rc in ROUND:
        c = [a[x] ^ a[x + 5] ^ a[x + 10] ^ a[x + 15] ^ a[x + 20] for x in range(5)]
        d = [c[(x - 1) % 5] ^ rol(c[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                a[x + 5 * y] ^= d[x]
        b = [0] * 25
        for x in range(5):
            for y in range(5):
                b[y + 5 * ((2 * x + 3 * y) % 5)] = rol(a[x + 5 * y], ROT[x][y])
        for x in range(5):
            for y in range(5):
                a[x + 5 * y] = b[x + 5 * y] ^ ((~b[(x + 1) % 5 + 5 * y]) & b[(x + 2) % 5 + 5 * y])
                a[x + 5 * y] &= mask
        a[0] ^= rc


def strip_comments(src):
    src = re.sub(r"/\*.*?\*/", "", src, flags=re.S)
    src = re.sub(r"//.*", "", src)
    return src


def find_matching(s, start, open_ch="{", close_ch="}"):
    depth = 0
    for i in range(start, len(s)):
        if s[i] == open_ch:
            depth += 1
        elif s[i] == close_ch:
            depth -= 1
            if depth == 0:
                return i
    return -1


def split_top(s, sep=","):
    out, cur, depth = [], [], 0
    for ch in s:
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        if ch == sep and depth == 0:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    tail = "".join(cur).strip()
    if tail:
        out.append(tail)
    return out


def top_level_statements(body):
    items, start, depth = [], 0, 0
    i = 0
    while i < len(body):
        ch = body[i]
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                items.append(body[start:i + 1].strip())
                start = i + 1
        elif ch == ";" and depth == 0:
            items.append(body[start:i + 1].strip())
            start = i + 1
        i += 1
    return [x for x in items if x]


def canon_type(t, contract, structs, enums):
    t = " ".join(t.replace("\n", " ").split())
    for q in [" calldata", " memory", " storage"]:
        t = t.replace(q, "")
    t = t.replace(" payable", " payable")
    arr = ""
    m = re.search(r"((?:\[[^\]]*\])*)$", t)
    if m:
        arr = m.group(1)
        base = t[:len(t) - len(arr)].strip()
    else:
        base = t.strip()
    internal = base + arr
    base_no_payable = base.replace(" payable", "")
    if base_no_payable == "uint":
        typ = "uint256" + arr
        internal = "uint256" + arr
    elif base_no_payable == "int":
        typ = "int256" + arr
        internal = "int256" + arr
    elif base_no_payable in enums:
        typ = "uint8"
        internal = f"enum {contract}.{base_no_payable}" + arr
    elif base_no_payable in structs:
        typ = "tuple" + arr
        internal = f"struct {contract}.{base_no_payable}" + arr
    elif base_no_payable == "address":
        typ = "address" + arr
    else:
        typ = base_no_payable + arr
    return typ, internal, base_no_payable


def parse_param(p, contract, structs, enums, event=False):
    p = " ".join(p.strip().split())
    indexed = bool(re.search(r"\bindexed\b", p))
    p = re.sub(r"\b(indexed|memory|calldata|storage)\b", "", p).strip()
    toks = p.split()
    if not toks:
        return None
    name = ""
    if len(toks) > 1 and re.match(r"^[A-Za-z_]\w*$", toks[-1]) and toks[-1] not in {"payable"}:
        name = toks[-1]
        typ_s = " ".join(toks[:-1])
    else:
        typ_s = " ".join(toks)
    typ, internal, base = canon_type(typ_s, contract, structs, enums)
    d = {"name": name, "type": typ, "internalType": internal}
    if event:
        d["indexed"] = indexed
    if base in structs:
        d["components"] = [component(c, contract, structs, enums) for c in structs[base]]
    return d


def component(field, contract, structs, enums):
    return parse_param(field, contract, structs, enums, False)


def parse_params(s, contract, structs, enums, event=False):
    if not s.strip():
        return []
    return [p for p in (parse_param(x, contract, structs, enums, event) for x in split_top(s)) if p]


def signature_type(param):
    typ = param["type"]
    if typ.startswith("tuple"):
        inner = ",".join(signature_type(c) for c in param.get("components", []))
        suffix = typ[len("tuple"):]
        return f"({inner}){suffix}"
    return typ


def parse_contract(name, body):
    clean = body
    structs = {}
    for m in re.finditer(r"\bstruct\s+([A-Za-z_]\w*)\s*\{", clean):
        end = find_matching(clean, m.end() - 1)
        fields = []
        if end != -1:
            for f in clean[m.end():end].split(";"):
                f = f.strip()
                if f:
                    fields.append(f)
        structs[m.group(1)] = fields
    enums = set(re.findall(r"\benum\s+([A-Za-z_]\w*)\s*\{", clean))
    abi = []
    funcs = []
    for st in top_level_statements(clean):
        head = st.split("{", 1)[0].rstrip(";").strip()
        if not head:
            continue
        if head.startswith("constructor"):
            m = re.match(r"constructor\s*\((.*)\)(.*)$", head, re.S)
            if m:
                ent = {"type": "constructor", "inputs": parse_params(m.group(1), name, structs, enums),
                       "stateMutability": "payable" if re.search(r"\bpayable\b", m.group(2)) else "nonpayable"}
                abi.append(ent)
        elif head.startswith("event "):
            m = re.match(r"event\s+([A-Za-z_]\w*)\s*\((.*)\)(.*)$", head, re.S)
            if m:
                abi.append({"type": "event", "name": m.group(1),
                            "inputs": parse_params(m.group(2), name, structs, enums, True),
                            "anonymous": bool(re.search(r"\banonymous\b", m.group(3)))})
        elif head.startswith("error "):
            m = re.match(r"error\s+([A-Za-z_]\w*)\s*\((.*)\)", head, re.S)
            if m:
                abi.append({"type": "error", "name": m.group(1),
                            "inputs": parse_params(m.group(2), name, structs, enums)})
        elif head.startswith("fallback"):
            sm = "payable" if re.search(r"\bpayable\b", head) else "nonpayable"
            abi.append({"type": "fallback", "stateMutability": sm})
        elif head.startswith("receive"):
            abi.append({"type": "receive", "stateMutability": "payable"})
        elif head.startswith("function "):
            m = re.match(r"function\s+([A-Za-z_]\w*)\s*\((.*?)\)(.*)$", head, re.S)
            if not m:
                continue
            tail = m.group(3)
            if not re.search(r"\b(public|external)\b", tail):
                continue
            outs = []
            rm = re.search(r"\breturns\s*\((.*)\)", tail, re.S)
            if rm:
                outs = parse_params(rm.group(1), name, structs, enums)
            sm = "payable" if re.search(r"\bpayable\b", tail) else "pure" if re.search(r"\bpure\b", tail) else "view" if re.search(r"\bview\b", tail) else "nonpayable"
            funcs.append({"type": "function", "name": m.group(1), "inputs": parse_params(m.group(2), name, structs, enums),
                          "outputs": outs, "stateMutability": sm})
        else:
            if " public " in f" {head} " and not head.startswith(("struct ", "enum ", "using ")):
                left = re.sub(r"=.*", "", head).strip()
                toks = left.split()
                if toks and re.match(r"^[A-Za-z_]\w*$", toks[-1]):
                    vname = toks[-1]
                    typ_s = " ".join(t for t in toks[:-1] if t not in {"public", "constant", "immutable", "override"})
                    out = parse_param(typ_s, name, structs, enums) if typ_s else None
                    if out:
                        out["name"] = ""
                        funcs.append({"type": "function", "name": vname, "inputs": [], "outputs": [out], "stateMutability": "view"})
    def key(e):
        order = {"constructor": 0, "error": 1, "event": 2, "fallback": 3, "function": 4, "receive": 5}
        return (order.get(e["type"], 9), e.get("name", ""))
    abi.extend(funcs)
    abi.sort(key=key)
    return abi


def parse_source(label, src):
    src = strip_comments(src)
    contracts = {}
    pat = re.compile(r"\b(?:abstract\s+)?(?:contract|interface|library)\s+([A-Za-z_]\w*)[^{;]*\{")
    pos = 0
    while True:
        m = pat.search(src, pos)
        if not m:
            break
        end = find_matching(src, m.end() - 1)
        if end == -1:
            break
        name = m.group(1)
        contracts[f"{label}:{name}"] = parse_contract(name, src[m.end():end])
        pos = end + 1
    return dict(sorted(contracts.items()))


def make_output(files, emits):
    contracts = {}
    for label, src in files:
        for key, abi in parse_source(label, src).items():
            obj = {}
            if "abi" in emits:
                obj["abi"] = abi
            if "hashes" in emits:
                hashes = {}
                for e in abi:
                    if e.get("type") == "function":
                        sig = e["name"] + "(" + ",".join(signature_type(p) for p in e.get("inputs", [])) + ")"
                        hashes[sig] = keccak256(sig.encode()).hex()[:8]
                obj["hashes"] = dict(sorted(hashes.items()))
            contracts[key] = obj
    contracts = dict(sorted(contracts.items()))
    out = {}
    if contracts:
        out["contracts"] = contracts
    out["version"] = VERSION
    return out


def add_imports(files, include_paths):
    seen = {label for label, _ in files if label != "<stdin>"}
    idx = 0
    include_paths = include_paths or []
    while idx < len(files):
        label, src = files[idx]
        idx += 1
        base = os.getcwd() if label == "<stdin>" else os.path.dirname(label) or "."
        for imp in re.findall(r'\bimport\s+(?:(?:[^"\']+)\s+from\s+)?["\']([^"\']+)["\']', src):
            candidates = [os.path.join(base, imp)] + [os.path.join(p, imp) for p in include_paths]
            for cand in candidates:
                if os.path.exists(cand):
                    norm = os.path.normpath(cand)
                    if norm not in seen:
                        seen.add(norm)
                        with open(norm, "r", encoding="utf-8") as f:
                            files.append((norm, f.read()))
                    break
    return files


def eprint(msg):
    print(msg, file=sys.stderr)


def main(argv):
    if "--version" in argv or "-V" in argv:
        print(VERSION_LONG if "--version" in argv else "solar 0.1.8-dev (8f228ae 2026-04-17T19:59:51.519973035Z)")
        return 0
    if "-Zhelp" in argv or ("-Z" in argv and argv[argv.index("-Z") + 1:argv.index("-Z") + 2] == ["help"]):
        eprint("error: List of all unstable flags.\nWARNING: these are completely unstable, and may change at any time!\n")
        print("Options:\n      -Zui-testing\n          Enables UI testing mode\n\n      -Zhelp\n          Print help\n\nUsage: solar [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.")
        return 0
    p = argparse.ArgumentParser(prog="executable", description="Blazingly fast Solidity compiler", add_help=False)
    p.add_argument("input", nargs="*")
    p.add_argument("-j", "--threads", "--jobs", type=int, default=4)
    p.add_argument("--evm-version", choices=EVM_VALUES, default="prague")
    p.add_argument("--stop-after", choices=["parsing", "lowering", "analysis"])
    p.add_argument("--out-dir")
    p.add_argument("--emit")
    p.add_argument("-Z", dest="z", action="append")
    p.add_argument("--base-path")
    p.add_argument("-I", "--include-path", action="append")
    p.add_argument("--allow-paths")
    p.add_argument("--color", choices=["auto", "always", "never"], default="auto")
    p.add_argument("-v", "--verbose", action="store_true")
    p.add_argument("--pretty-json", action="store_true")
    p.add_argument("--pretty-json-err", action="store_true")
    p.add_argument("--error-format", choices=["human", "json", "rustc-json"], default="human")
    p.add_argument("--error-format-human", choices=["ascii", "unicode", "short"], default="unicode")
    p.add_argument("--diagnostic-width")
    p.add_argument("--no-warnings", action="store_true")
    p.add_argument("-h", "--help", action="store_true")
    try:
        ns = p.parse_args(argv)
    except SystemExit as ex:
        return int(ex.code)
    if ns.help:
        print("""Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Files to compile, or import remappings

Options:
  -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]
      --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]
      --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: parsing, lowering, analysis]
      --out-dir <OUT_DIR>          Directory to write output files
      --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]
  -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version""")
        return 0
    emits = []
    if ns.emit:
        for x in ns.emit.split(","):
            if x not in ("abi", "hashes"):
                eprint(f"error: invalid value '{x}' for '--emit <EMIT>'\n  [possible values: abi, hashes]\n\nFor more information, try '--help'.")
                return 2
            emits.append(x)
    files = []
    errors = 0
    for inp in ns.input:
        if "=" in inp and not os.path.exists(inp):
            continue
        if inp == "-":
            files.append(("<stdin>", sys.stdin.read()))
        elif os.path.exists(inp):
            with open(inp, "r", encoding="utf-8") as f:
                files.append((inp, f.read()))
        else:
            errors += 1
            if ns.error_format == "json":
                print(json.dumps({"sourceLocation": None, "secondarySourceLocations": [], "type": "Exception", "component": "general", "severity": "error", "errorCode": None, "message": f"file {inp} not found", "formattedMessage": f"error: file {inp} not found\n\n"}))
            elif ns.error_format == "rustc-json":
                print(json.dumps({"$message_type": "diagnostic", "message": f"file {inp} not found", "code": None, "level": "error", "spans": [], "children": [], "rendered": f"error: file {inp} not found\n\n"}))
            else:
                eprint(f"error: file {inp} not found\n")
    if errors:
        msg = f"aborting due to {errors} previous error" + ("" if errors == 1 else "s")
        if ns.error_format == "json":
            print(json.dumps({"sourceLocation": None, "secondarySourceLocations": [], "type": "Exception", "component": "general", "severity": "error", "errorCode": None, "message": msg, "formattedMessage": f"error: {msg}\n\n"}))
        elif ns.error_format == "rustc-json":
            print(json.dumps({"$message_type": "diagnostic", "message": msg, "code": None, "level": "error", "spans": [], "children": [], "rendered": f"error: {msg}\n\n"}))
        else:
            eprint(f"error: {msg}\n")
        return 1
    files = add_imports(files, ns.include_path)
    if not emits:
        return 0
    out = make_output(files, emits)
    text = json.dumps(out, indent=2 if ns.pretty_json else None, separators=None if ns.pretty_json else (",", ":"))
    if ns.out_dir:
        path = os.path.join(ns.out_dir, "combined.json")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
        except OSError as ex:
            eprint(f"error: failed to write to output: {ex.strerror} (os error {ex.errno})\n\nerror: aborting due to 1 previous error\n")
            return 1
    else:
        print(text, end="")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
