#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys


HELP = """Usage: ./executable [options]

Options:
    -d, --default TEXT  text inserted into the textfield on startup
    -o, --out-file FILE write final command to file
        --in-file FILE  read initial command from file
        --config-reference 
                        print out the default configuration file
    -r, --raw-mode      keep linebreaks in finished command when closing
        --no-isolation  disable isolation. This will run the commands directly
                        on your system, without protection. Take care.
    -h, --help          print this help menu
"""


CONFIG = """
#  ____  _
# |  _ \\(_)_ __  _ __       .________.
# | |_) | | '_ \\| '__|      |________|
# |  __/| | |_) | |          |_    -|
# |_|   |_| .__/|_|     xX  xXx___x_|
#         |_|
#
# A commandline utility by
# Leon Kowarschick

# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.
# finish_hook = "xclip -selection clipboard -in"

# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.
paranoid_history_mode_default = false

autoeval_mode_default = true

history_size = 500
cmdlist_always_show_preview = false
cmd_timeout_millis = 2000

highlighting_enabled = true

eval_environment = ["bash", "-c"]

# Snippets can be used to quickly insert common bits of shell
# use || (two pipes) where you want your cursor to be after insertion
[snippets]
s = " | sed -r 's/||//g'"

[help_viewers]
'm' = "man ??"
'h' = "?? --help | less"

[output_viewers]
'l' = "less"
"""


class UsageError(Exception):
    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


def usage_error(message: str) -> int:
    print(f"./executable: {message}", file=sys.stderr)
    return 1


def parse_args(argv):
    opts = {
        "default": None,
        "out_file": None,
        "in_file": None,
        "config_reference": False,
        "raw_mode": False,
        "no_isolation": False,
        "help": False,
    }

    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            i += 1
            continue
        if arg in ("-h", "--help"):
            opts["help"] = True
        elif arg in ("-r", "--raw-mode"):
            opts["raw_mode"] = True
        elif arg == "--config-reference":
            opts["config_reference"] = True
        elif arg == "--no-isolation":
            opts["no_isolation"] = True
        elif arg in ("-d", "--default", "-o", "--out-file", "--in-file"):
            if i + 1 >= len(argv):
                name = arg[2:] if arg.startswith("--") else arg[1:]
                raise UsageError(f"Argument to option '{name}' missing")
            val = argv[i + 1]
            if arg in ("-d", "--default"):
                opts["default"] = val
            elif arg in ("-o", "--out-file"):
                opts["out_file"] = val
            else:
                opts["in_file"] = val
            i += 1
        elif arg.startswith("--default="):
            opts["default"] = arg.split("=", 1)[1]
        elif arg.startswith("--out-file="):
            opts["out_file"] = arg.split("=", 1)[1]
        elif arg.startswith("--in-file="):
            opts["in_file"] = arg.split("=", 1)[1]
        elif arg.startswith("--raw-mode="):
            raise UsageError("Option 'raw-mode' does not take an argument")
        elif arg.startswith("--no-isolation="):
            raise UsageError("Option 'no-isolation' does not take an argument")
        elif arg.startswith("--config-reference="):
            raise UsageError("Option 'config-reference' does not take an argument")
        elif arg.startswith("--"):
            raise UsageError(f"Unrecognized option: '{arg[2:]}'")
        elif arg.startswith("-") and len(arg) > 1:
            # The reference parser reports the first unknown short name.
            raise UsageError(f"Unrecognized option: '{arg[1]}'")
        i += 1
    return opts


def read_initial(opts) -> str:
    if opts["in_file"] is not None:
        with open(opts["in_file"], "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    return opts["default"] or ""


def finish_command(cmd: str, opts) -> int:
    if not opts["raw_mode"]:
        cmd = cmd.replace("\r\n", " ").replace("\n", " ").replace("\r", " ")
    if opts["out_file"]:
        with open(opts["out_file"], "w", encoding="utf-8") as f:
            f.write(cmd)
    return 0


def run_command(cmd: str) -> str:
    if not cmd.strip():
        return ""
    try:
        proc = subprocess.run(
            ["bash", "-c", cmd],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=2,
        )
        return proc.stdout
    except subprocess.TimeoutExpired:
        return "Command timed out\n"
    except Exception as exc:
        return f"{exc}\n"


def simple_interactive(initial: str, opts) -> int:
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        print("\033[?1049hError: No such device or address (os error 6)")
        return 1

    cmd = initial
    output = run_command(cmd)
    sys.stdout.write("\033[?1049h")
    sys.stdout.write("┌ Command [Autoeval] ─────────────────────────────────────────────┐\r\n")
    sys.stdout.write("│" + cmd + "\r\n")
    sys.stdout.write("└────────────────────────────────────────────────────────────────┘\r\n")
    sys.stdout.write("┌ Output ─────────────────────────────────────────────────────────┐\r\n")
    if output:
        sys.stdout.write(output)
    sys.stdout.write("\r\n")
    sys.stdout.flush()

    try:
        while True:
            line = sys.stdin.readline()
            if line == "":
                break
            stripped = line.rstrip("\r\n")
            if stripped in (":q", ":quit", "quit", "exit"):
                break
            cmd = stripped
            output = run_command(cmd)
            if output:
                sys.stdout.write(output)
                sys.stdout.flush()
    except KeyboardInterrupt:
        pass
    finally:
        sys.stdout.write("\033[?1049l")
        sys.stdout.flush()
    return finish_command(cmd, opts)


def main(argv) -> int:
    try:
        opts = parse_args(argv)
    except UsageError as exc:
        return usage_error(exc.message)

    if opts["help"]:
        sys.stdout.write(HELP)
        return 0
    if opts["config_reference"]:
        sys.stdout.write(CONFIG)
        return 0

    try:
        initial = read_initial(opts)
    except OSError as exc:
        print(f"Error: {exc.strerror} (os error {exc.errno})", file=sys.stderr)
        return 1

    if not opts["no_isolation"] and shutil.which("bwrap") is None:
        print(
            "bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode",
            file=sys.stderr,
        )
        return 1

    return simple_interactive(initial, opts)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
