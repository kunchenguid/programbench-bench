#!/usr/bin/env python3
import json
import re
import sys


VERSION = "tuc 1.3.0"
HELP = """tuc 1.3.0
Cut text (or bytes) where a delimiter matches, then keep the desired parts.

USAGE:
    tuc [FLAGS] [OPTIONS] < input
    tuc [FLAGS] [OPTIONS] filepath

FLAGS:
    -g, --greedy-delimiter        Match consecutive delimiters as if it was one
    -p, --compress-delimiter      Print only the first delimiter of a sequence
    -s, --only-delimited          Print only lines containing the delimiter
    -V, --version                 Print version information
    -z, --zero-terminated         Line delimiter is NUL (\\0), not LF (\\n)
    -h, --help                    Print this help and exit
    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
    -j, --(no-)join               Print selected parts with delimiter in between
    --json                        Print fields as a JSON array of strings
    --no-mmap                     Disable memory mapping

OPTIONS:
    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.
    -b, --bytes <bounds>          Same as --fields, but it keeps bytes
    -c, --characters <bounds>     Same as --fields, but it keeps characters
    -l, --lines <bounds>          Same as --fields, but it keeps lines
    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text
                                  [default: \\t]
    -e, --regex <some regex>      Use a regular expression as delimiter
    -r, --replace-delimiter <new> Replace the delimiter with the provided text.
                                  Implies --join
    -t, --trim <type>             Trim the delimiter (greedy). Valid values are
                                  (l|L)eft, (r|R)ight, (b|B)oth
        --fallback-oob <fallback> Generic fallback output for any field that
                                  cannot be found (oob stands for out of bound).
    -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.
"""


class TucError(Exception):
    pass


def parse_args(argv):
    opts = {
        "mode": "fields",
        "bounds": "1:",
        "delimiter": "\t",
        "regex": None,
        "greedy": False,
        "compress": False,
        "only_delimited": False,
        "zero": False,
        "complement": False,
        "join": False,
        "join_set": False,
        "replace": None,
        "json": False,
        "fallback": None,
        "trim": None,
        "file": None,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        inline_value = None
        if a.startswith("--") and "=" in a:
            a, inline_value = a.split("=", 1)
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a in ("-g", "--greedy-delimiter"):
            opts["greedy"] = True
        elif a in ("-p", "--compress-delimiter"):
            opts["compress"] = True
        elif a in ("-s", "--only-delimited"):
            opts["only_delimited"] = True
        elif a in ("-z", "--zero-terminated"):
            opts["zero"] = True
        elif a in ("-m", "--complement"):
            opts["complement"] = True
        elif a in ("-j", "--join"):
            opts["join"] = True
            opts["join_set"] = True
        elif a == "--no-join":
            opts["join"] = False
            opts["join_set"] = True
        elif a == "--json":
            opts["json"] = True
        elif a == "--no-mmap":
            pass
        elif a in ("-f", "--fields", "-b", "--bytes", "-c", "--characters", "-l", "--lines",
                   "-d", "--delimiter", "-e", "--regex", "-r", "--replace-delimiter",
                   "-t", "--trim", "--fallback-oob", "-M", "--fixed-memory"):
            if inline_value is None:
                i += 1
                if i >= len(argv):
                    raise TucError(f"error: The argument '{a}' requires a value but none was supplied")
                v = argv[i]
            else:
                v = inline_value
            if a in ("-f", "--fields"):
                opts["mode"], opts["bounds"] = "fields", v
            elif a in ("-b", "--bytes"):
                opts["mode"], opts["bounds"] = "bytes", v
            elif a in ("-c", "--characters"):
                opts["mode"], opts["bounds"] = "chars", v
            elif a in ("-l", "--lines"):
                opts["mode"], opts["bounds"] = "lines", v
                if not opts["join_set"]:
                    opts["join"] = True
            elif a in ("-d", "--delimiter"):
                opts["delimiter"] = v
            elif a in ("-e", "--regex"):
                opts["regex"] = v
            elif a in ("-r", "--replace-delimiter"):
                opts["replace"] = v
                opts["join"] = True
            elif a in ("-t", "--trim"):
                opts["trim"] = v
            elif a == "--fallback-oob":
                opts["fallback"] = v
            else:
                pass
        elif a.startswith("-") and a not in ("-",):
            raise TucError(f"error: Found argument '{a}' which wasn't expected")
        else:
            if opts["file"] is not None:
                raise TucError(f"error: Found argument '{a}' which wasn't expected")
            opts["file"] = a
        i += 1
    return opts


def parse_int(s, whole):
    try:
        n = int(s)
    except ValueError:
        raise TucError(f"failed to parse '{whole}': Not a number `{s}`")
    if n == 0:
        raise TucError(f"failed to parse '{whole}': Zero is not a valid field")
    return n


def parse_piece(piece):
    fallback = None
    if "=" in piece and "{" not in piece:
        piece, fallback = piece.split("=", 1)
    whole = piece if fallback is None else piece + "=" + fallback
    if ":" in piece:
        left, right = piece.split(":", 1)
        lraw = parse_int(left, whole) if left else None
        rraw = parse_int(right, whole) if right else None
        if lraw is not None and rraw is not None and lraw > rraw:
            raise TucError(f"failed to parse '{whole}': Field left value cannot be greater than right value")
        return ("range", lraw, rraw, fallback)
    return ("one", parse_int(piece, whole), fallback)


def parse_bounds(bounds):
    if "{" in bounds or "}" in bounds:
        return ("format", bounds)
    if bounds == "":
        raise TucError("failed to parse '': Not a number ``")
    return ("list", [parse_piece(p) for p in bounds.split(",") if p != ""])


def resolve_index(raw, n):
    if raw is None:
        return None
    return raw if raw > 0 else n + raw + 1


def token_split(text, opts):
    delim = opts["delimiter"]
    if opts["regex"]:
        pattern = opts["regex"]
        fields, delims, pos = [], [], 0
        for m in re.finditer(pattern, text):
            fields.append(text[pos:m.start()])
            delims.append(m.group(0))
            pos = m.end()
        fields.append(text[pos:])
        return fields, delims
    if delim == "":
        return [text], []
    if opts["compress"]:
        text = re.sub("(?:%s)+" % re.escape(delim), delim, text)
    if opts["greedy"]:
        fields, delims, pos = [], [], 0
        pattern = "(?:%s)+" % re.escape(delim)
        for m in re.finditer(pattern, text):
            fields.append(text[pos:m.start()])
            delims.append(m.group(0))
            pos = m.end()
        fields.append(text[pos:])
        return fields, delims
    parts = text.split(delim)
    return parts, [delim] * (len(parts) - 1)


def selected_from_parts(fields, delims, spec, opts):
    n = len(fields)
    items = []
    missing = []
    for p in spec[1]:
        if p[0] == "one":
            idx = resolve_index(p[1], n)
            if 1 <= idx <= n:
                items.append(("field", idx, fields[idx - 1]))
            else:
                fb = p[2] if p[2] is not None else opts["fallback"]
                if fb is None:
                    missing.append(idx)
                else:
                    items.append(("field", idx, fb))
        else:
            start = resolve_index(p[1], n) if p[1] is not None else 1
            end = resolve_index(p[2], n) if p[2] is not None else n
            start = max(1, start)
            end = min(n, end)
            if start <= end:
                seg_text = fields[start - 1]
                for k in range(start, end):
                    seg_text += (delims[k - 1] if k - 1 < len(delims) else opts["delimiter"]) + fields[k]
                items.append(("range", (start, end), seg_text))
    if missing:
        raise TucError(f"Error: Out of bounds: {missing[0]}")
    if opts["complement"]:
        excluded = set()
        for item in items:
            if item[0] == "field" and 1 <= item[1] <= n:
                excluded.add(item[1])
            elif item[0] == "range":
                excluded.update(range(item[1][0], item[1][1] + 1))
        items = [("field", i, fields[i - 1]) for i in range(1, n + 1) if i not in excluded]
    return items


def render_items(items, opts, line_sep="\n"):
    vals = []
    if opts["json"]:
        for item in items:
            if item[0] == "range":
                # Ranges are arrays of their fields in JSON mode.
                # The caller expands ranges before reaching here when needed.
                vals.append(item[2])
            else:
                vals.append(item[2])
        return json.dumps(vals, ensure_ascii=False, separators=(",", ":")) + line_sep
    if opts["join"]:
        sep = opts["replace"] if opts["replace"] is not None else opts["delimiter"]
        return sep.join(item[2] for item in items) + line_sep
    return "".join(item[2] for item in items) + line_sep


def expand_json_items(items, fields):
    out = []
    for item in items:
        if item[0] == "range":
            a, b = item[1]
            out.extend(("field", i, fields[i - 1]) for i in range(a, b + 1))
        else:
            out.append(item)
    return out


def render_format(fmt, fields, opts, line_sep):
    out, i = [], 0
    while i < len(fmt):
        ch = fmt[i]
        if ch == "{" and i + 1 < len(fmt) and fmt[i + 1] == "{":
            out.append("{")
            i += 2
        elif ch == "}" and i + 1 < len(fmt) and fmt[i + 1] == "}":
            out.append("}")
            i += 2
        elif ch == "{":
            j = fmt.find("}", i + 1)
            if j < 0:
                raise TucError(f"failed to parse '{fmt}': Unclosed formatter")
            inner = fmt[i + 1:j]
            piece = parse_piece(inner)
            sub = ("list", [piece])
            items = selected_from_parts(fields, [], sub, opts)
            out.append(items[0][2] if items else "")
            i = j + 1
        else:
            out.append(ch)
            i += 1
    return "".join(out) + line_sep


def process_fields(data, opts):
    sep = "\0" if opts["zero"] else "\n"
    chunks = data.split(sep)
    trailing = chunks and chunks[-1] == ""
    if trailing:
        chunks = chunks[:-1]
    spec = parse_bounds(opts["bounds"])
    out = []
    for line in chunks:
        fields, delims = token_split(line, opts)
        if opts["only_delimited"] and not delims:
            continue
        if spec[0] == "format":
            out.append(render_format(spec[1], fields, opts, sep))
        else:
            items = selected_from_parts(fields, delims, spec, opts)
            if opts["json"]:
                items = expand_json_items(items, fields)
            out.append(render_items(items, opts, sep))
    return "".join(out)


def process_units(data, opts, units):
    spec = parse_bounds(opts["bounds"])
    if units == "bytes":
        arr = list(data.encode("utf-8", "surrogateescape"))
        vals = [bytes([b]).decode("latin1") for b in arr]
        line_sep = ""
    elif units == "chars":
        sep = "\0" if opts["zero"] else "\n"
        chunks = data.split(sep)
        if chunks and chunks[-1] == "":
            chunks = chunks[:-1]
        return "".join(process_unit_list(list(ch), spec, opts, sep) for ch in chunks)
    else:
        sep = "\0" if opts["zero"] else "\n"
        chunks = data.split(sep)
        if chunks and chunks[-1] == "":
            chunks = chunks[:-1]
        return process_unit_list(chunks, spec, opts, sep)
    return process_unit_list(vals, spec, opts, line_sep).encode("latin1").decode("latin1")


def process_unit_list(vals, spec, opts, line_sep):
    fields = vals
    unit_delim = "\0" if opts["mode"] == "lines" and opts["zero"] else "\n" if opts["mode"] == "lines" else ""
    items = selected_from_parts(fields, [unit_delim] * max(0, len(fields) - 1), spec, opts)
    if opts["json"]:
        items = expand_json_items(items, fields)
        return render_items(items, opts, line_sep or "\n")
    if opts["mode"] == "lines":
        sep = "\0" if opts["zero"] else "\n"
        return sep.join(item[2] for item in items) + sep
    if opts["join"]:
        return render_items(items, opts, line_sep)
    return "".join(item[2] for item in items) + line_sep


def read_input(opts):
    if opts["file"]:
        with open(opts["file"], "rb") as f:
            raw = f.read()
    else:
        raw = sys.stdin.buffer.read()
    return raw.decode("utf-8", "surrogateescape")


def main(argv):
    try:
        opts = parse_args(argv)
        data = read_input(opts)
        if opts["mode"] == "fields":
            sys.stdout.write(process_fields(data, opts))
        elif opts["mode"] == "bytes":
            sys.stdout.buffer.write(process_units(data, opts, "bytes").encode("latin1"))
        elif opts["mode"] == "chars":
            sys.stdout.write(process_units(data, opts, "chars"))
        else:
            sys.stdout.write(process_units(data, opts, "lines"))
        return 0
    except BrokenPipeError:
        return 0
    except TucError as e:
        print(str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
