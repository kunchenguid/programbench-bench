#!/usr/bin/env python3
import argparse
import fnmatch
import json
import os
import re
import stat
import sys
from dataclasses import dataclass, field
from pathlib import Path


VERSION = "ast-grep 0.42.1"

LANG_EXTS = {
    "python": [".py"], "py": [".py"],
    "javascript": [".js", ".jsx", ".mjs", ".cjs"], "js": [".js", ".jsx", ".mjs", ".cjs"],
    "typescript": [".ts"], "ts": [".ts"],
    "tsx": [".tsx"], "jsx": [".jsx"],
    "rust": [".rs"], "rs": [".rs"],
    "go": [".go"], "java": [".java"],
    "c": [".c", ".h"], "cpp": [".cc", ".cpp", ".cxx", ".hpp", ".hh"],
    "json": [".json"], "yaml": [".yml", ".yaml"], "yml": [".yml", ".yaml"],
    "html": [".html", ".htm"], "css": [".css"],
    "ruby": [".rb"], "rb": [".rb"],
    "php": [".php"], "swift": [".swift"],
    "kotlin": [".kt", ".kts"], "scala": [".scala"],
    "bash": [".sh", ".bash"], "sh": [".sh", ".bash"],
    "lua": [".lua"], "dart": [".dart"],
}

LANG_NAMES = {
    "py": "Python", "python": "Python", "js": "JavaScript", "javascript": "JavaScript",
    "ts": "TypeScript", "typescript": "TypeScript", "tsx": "Tsx", "rust": "Rust",
    "go": "Go", "java": "Java", "c": "C", "cpp": "Cpp", "json": "Json",
    "yaml": "Yaml", "yml": "Yaml", "html": "Html", "css": "Css",
}


@dataclass
class Match:
    file: str
    text: str
    start: int
    end: int
    content: str
    lang: str
    meta: dict = field(default_factory=dict)
    rule_id: str = ""
    message: str = ""
    severity: str = "hint"
    fix: str | None = None

    @property
    def start_line(self):
        return self.content.count("\n", 0, self.start)

    @property
    def start_col(self):
        last = self.content.rfind("\n", 0, self.start)
        return self.start if last < 0 else self.start - last - 1

    @property
    def end_line(self):
        return self.content.count("\n", 0, self.end)

    @property
    def end_col(self):
        last = self.content.rfind("\n", 0, self.end)
        return self.end if last < 0 else self.end - last - 1

    @property
    def line_no1(self):
        return self.start_line + 1

    @property
    def line_text(self):
        lines = self.content.splitlines()
        return lines[self.start_line] if 0 <= self.start_line < len(lines) else self.text

    def json_obj(self):
        single = {}
        for k, (txt, s, e) in self.meta.items():
            single[k] = {
                "text": txt,
                "range": {
                    "byteOffset": {"start": s, "end": e},
                    "start": {"line": self.content.count("\n", 0, s), "column": s - (self.content.rfind("\n", 0, s) + 1)},
                    "end": {"line": self.content.count("\n", 0, e), "column": e - (self.content.rfind("\n", 0, e) + 1)},
                },
            }
        obj = {
            "text": self.text,
            "range": {
                "byteOffset": {"start": self.start, "end": self.end},
                "start": {"line": self.start_line, "column": self.start_col},
                "end": {"line": self.end_line, "column": self.end_col},
            },
            "file": self.file,
            "lines": "\n".join(self.content.splitlines()[self.start_line:self.end_line + 1]) or self.text,
            "charCount": {"leading": 0, "trailing": 0},
            "language": LANG_NAMES.get((self.lang or "").lower(), (self.lang or "").capitalize()),
            "metaVariables": {"single": single, "multi": {}, "transformed": {}},
        }
        if self.rule_id:
            obj.update({"ruleId": self.rule_id, "severity": self.severity, "message": self.message})
        return obj


def top_help():
    return """Search and Rewrite code at large scale using AST pattern.

Usage: executable [OPTIONS] <COMMAND>

Commands:
  run          Run one time search or rewrite in command line. (default command)
  scan         Scan and rewrite code by configuration
  test         Test ast-grep rules
  new          Create new ast-grep project or items like rules/tests
  lsp          Start language server
  completions  Generate shell completion script
  help         Print this message or the help of the given subcommand(s)

Options:
  -c, --config <CONFIG_FILE>  Path to ast-grep root config, default is sgconfig.yml
  -h, --help                  Print help (see a summary with '-h')
  -V, --version               Print version"""


def run_help():
    return """Run one time search or rewrite in command line. (default command)

Usage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]...

Options:
  -p, --pattern <PATTERN>     AST pattern to match
  -r, --rewrite <FIX>         String to replace the matched AST node
  -l, --lang <LANG>           The language of the pattern
      --stdin                 Enable search code from StdIn.
  -U, --update-all            Apply all rewrite without confirmation if true
      --files-with-matches    Print only the paths with at least one match
      --json[=<STYLE>]        Output matches in structured JSON
  -A, --after <NUM>           Show NUM lines after each match
  -B, --before <NUM>          Show NUM lines before each match
  -C, --context <NUM>         Show NUM lines around each match
      --heading <WHEN>        Controls whether to print the file name as heading
  -h, --help                  Print help"""


def scan_help():
    return """Scan and rewrite code by configuration

Usage: executable scan [OPTIONS] [PATHS]...

Options:
  -r, --rule <RULE_FILE>      Scan the codebase with the single rule
      --inline-rules <RULE_TEXT>  Scan with a rule defined by text
      --format <FORMAT>      Supported formats: github, sarif
      --report-style <STYLE> Possible values: rich, medium, short
      --json[=<STYLE>]       Output matches in structured JSON
  -U, --update-all           Apply all rewrite without confirmation if true
  -h, --help                 Print help"""


def split_args(argv):
    if not argv:
        return "run", []
    if argv[0] in ("-h", "--help"):
        print(top_help()); sys.exit(0)
    if argv[0] in ("-V", "--version"):
        print(VERSION); sys.exit(0)
    if argv[0] == "help":
        if len(argv) > 1:
            argv = [argv[1], "--help"]
        else:
            print(top_help()); sys.exit(0)
    i = 0
    prefix = []
    while i < len(argv):
        a = argv[i]
        if a in {"-c", "--config"} and i + 1 < len(argv):
            prefix.extend([a, argv[i + 1]])
            i += 2
            continue
        if a.startswith("--config="):
            prefix.append(a)
            i += 1
            continue
        break
    if i and i < len(argv) and argv[i] in {"run", "scan", "test", "new", "lsp", "completions"}:
        return argv[i], prefix + argv[i + 1:]
    if argv[0] in {"run", "scan", "test", "new", "lsp", "completions"}:
        return argv[0], argv[1:]
    return "run", argv


def pattern_to_regex(pattern):
    out = []
    i = 0
    seen = set()
    while i < len(pattern):
        c = pattern[i]
        if c == "$":
            j = i + 1
            if j < len(pattern) and pattern[j] == "$":
                j += 1
                while j < len(pattern) and (pattern[j].isupper() or pattern[j].isdigit() or pattern[j] == "_"):
                    j += 1
                name = pattern[i + 2:j] or f"M{i}"
                atom = r"[\s\S]*?"
            else:
                while j < len(pattern) and (pattern[j].isupper() or pattern[j].isdigit() or pattern[j] == "_"):
                    j += 1
                name = pattern[i + 1:j]
                if not name:
                    out.append(re.escape(c)); i += 1; continue
                atom = r"[^,\n;(){}\[\]]+?"
            if name in seen:
                out.append(r"(?P=" + name + ")")
            else:
                out.append(r"(?P<" + name + ">" + atom + ")")
                seen.add(name)
            i = j
        elif c.isspace():
            while i < len(pattern) and pattern[i].isspace():
                i += 1
            out.append(r"\s+")
        else:
            out.append(re.escape(c))
            i += 1
    return re.compile("".join(out), re.MULTILINE)


def iter_files(paths, lang=None, follow=False, globs=None, no_hidden=False):
    if not paths:
        paths = ["."]
    exts = LANG_EXTS.get((lang or "").lower())
    for p in paths:
        path = Path(p)
        if not path.exists():
            print(f"ERROR: {p}: No such file or directory (os error 2)", file=sys.stderr)
            continue
        if path.is_file():
            candidates = [path]
        else:
            candidates = []
            for root, dirs, files in os.walk(path, followlinks=follow):
                if not no_hidden:
                    dirs[:] = [d for d in dirs if not d.startswith(".")]
                for f in files:
                    if not no_hidden and f.startswith("."):
                        continue
                    candidates.append(Path(root) / f)
        for f in sorted(candidates):
            if exts and f.suffix not in exts:
                continue
            rel = str(f)
            if rel.startswith("./"):
                rel = rel[2:]
            if globs and not apply_globs(rel, globs):
                continue
            try:
                data = f.read_text(errors="replace")
            except Exception:
                continue
            yield rel, data


def apply_globs(path, globs):
    state = True
    for g in globs:
        neg = g.startswith("!")
        pat = g[1:] if neg else g
        if fnmatch.fnmatch(path, pat) or fnmatch.fnmatch(Path(path).name, pat):
            state = not neg
    return state


def find_matches(content, file, pattern, lang, rule_id="", message="", severity="hint", fix=None):
    rx = pattern_to_regex(pattern)
    matches = []
    for m in rx.finditer(content):
        if m.start() == m.end():
            continue
        meta = {}
        for name, val in m.groupdict().items():
            if val is None:
                continue
            s, e = m.span(name)
            meta[name] = (val.strip(), s, e)
        matches.append(Match(file, m.group(0), m.start(), m.end(), content, lang, meta, rule_id, message, severity, fix))
    return matches


def replacement(template, match):
    s = template
    for name, (val, _, _) in match.meta.items():
        s = s.replace("$$$" + name, val).replace("$" + name, val)
    return s


def parse_run(argv):
    if any(a in ("-h", "--help") for a in argv):
        print(run_help()); sys.exit(0)
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("paths", nargs="*")
    p.add_argument("-p", "--pattern")
    p.add_argument("-r", "--rewrite")
    p.add_argument("-l", "--lang")
    p.add_argument("--stdin", action="store_true")
    p.add_argument("-U", "--update-all", action="store_true")
    p.add_argument("--files-with-matches", action="store_true")
    p.add_argument("--json", nargs="?", const="pretty", choices=["pretty", "stream", "compact"])
    p.add_argument("--color", default="auto")
    p.add_argument("--heading", default="auto")
    p.add_argument("-A", "--after", type=int, default=0)
    p.add_argument("-B", "--before", type=int, default=0)
    p.add_argument("-C", "--context", type=int)
    p.add_argument("--globs", action="append")
    p.add_argument("--follow", action="store_true")
    p.add_argument("--no-ignore", action="append", default=[])
    p.add_argument("-j", "--threads")
    p.add_argument("-c", "--config")
    p.add_argument("--selector")
    p.add_argument("--strictness")
    p.add_argument("--debug-query", nargs="?", const="pattern")
    p.add_argument("--inspect")
    p.add_argument("-i", "--interactive", action="store_true")
    args, _ = p.parse_known_args(argv)
    if not args.pattern:
        print("error: the following required arguments were not provided:\n  --pattern <PATTERN>", file=sys.stderr)
        return 2
    if args.debug_query:
        print(args.pattern)
        return 0
    if args.context is not None:
        args.before = args.after = args.context
    if args.stdin:
        content = sys.stdin.read()
        matches = find_matches(content, "STDIN", args.pattern, args.lang or "")
        return output_matches(matches, args, {"STDIN": content})
    files = list(iter_files(args.paths or ["."], args.lang, args.follow, args.globs, "hidden" in args.no_ignore))
    if any(not Path(p).exists() for p in (args.paths or []) if p != "-"):
        return 1
    all_matches = []
    contents = {}
    for file, content in files:
        contents[file] = content
        all_matches.extend(find_matches(content, file, args.pattern, args.lang or guess_lang(file)))
    if args.rewrite and args.update_all:
        by_file = {}
        for m in all_matches:
            by_file.setdefault(m.file, []).append(m)
        changed = 0
        for file, ms in by_file.items():
            content = contents[file]
            for m in reversed(ms):
                content = content[:m.start] + replacement(args.rewrite, m) + content[m.end:]
                changed += 1
            Path(file).write_text(content)
        print(f"Applied {changed} change" + ("" if changed == 1 else "s"))
        return 0 if changed else 1
    if args.rewrite:
        print_diff_preview(all_matches, args.rewrite, contents)
        return 0 if all_matches else 1
    return output_matches(all_matches, args, contents)


def guess_lang(file):
    suffix = Path(file).suffix
    for lang, exts in LANG_EXTS.items():
        if suffix in exts:
            return lang
    return ""


def output_matches(matches, args, contents):
    if args.files_with_matches:
        for f in sorted({m.file for m in matches}):
            print(f)
        return 0 if matches else 1
    if args.json:
        objs = [m.json_obj() for m in matches]
        if args.json == "stream":
            for o in objs:
                print(json.dumps(o, separators=(",", ":")))
        elif args.json == "compact":
            print(json.dumps(objs, separators=(",", ":")))
        else:
            print(json.dumps(objs, indent=2))
        return 0 if matches else 1
    heading = args.heading == "always"
    for m in matches:
        lines = contents[m.file].splitlines()
        lo = max(0, m.start_line - getattr(args, "before", 0))
        hi = min(len(lines) - 1, m.start_line + getattr(args, "after", 0))
        if heading:
            print(m.file)
            for n in range(lo, hi + 1):
                print(f"{n + 1}\u2502{lines[n]}")
            print()
        else:
            for n in range(lo, hi + 1):
                print(f"{m.file}:{n + 1}:{lines[n]}")
    return 0 if matches else 1


def print_diff_preview(matches, rewrite, contents):
    for file in sorted({m.file for m in matches}):
        ms = [m for m in matches if m.file == file]
        print(file)
        lines = contents[file].splitlines()
        print(f"@@ -0,{len(lines)} +0,{len(lines)} @@")
        hit_lines = {m.start_line: replacement(rewrite, m) for m in ms}
        width = len(str(len(lines)))
        for i, line in enumerate(lines):
            if i in hit_lines:
                print(f"{i+1:>{width}}  \u2502-{line}")
                print(f"{'':>{width}}{i+1:>{width}}\u2502+{hit_lines[i]}")
            else:
                print(f"{i+1:>{width}} {i+1:>{width}}\u2502 {line}")


def parse_simple_yaml(text):
    docs = [d for d in re.split(r"^---\s*$", text, flags=re.MULTILINE) if d.strip()]
    rules = []
    for doc in docs:
        data = {}
        current = None
        subcurrent = None
        for raw in doc.splitlines():
            if not raw.strip() or raw.lstrip().startswith("#"):
                continue
            indent = len(raw) - len(raw.lstrip())
            line = raw.strip()
            if line.startswith("- ") and current == "rule":
                line = line[2:].strip()
            if ":" in line:
                k, v = line.split(":", 1)
                k = k.strip()
                v = v.strip().strip("'\"")
                if indent == 0:
                    current = k
                    subcurrent = None
                    data[k] = v if v else {}
                elif current == "rule" and k in {"pattern", "regex", "kind", "inside", "has", "any", "all", "matches"} and v:
                    data.setdefault("rule", {})[k] = v
                    subcurrent = k
                elif current == "rule" and k in {"pattern", "inside", "has"} and not v:
                    data.setdefault("rule", {})[k] = {}
                    subcurrent = k
                elif current == "rule" and subcurrent and k in {"context", "selector"}:
                    obj = data.setdefault("rule", {}).setdefault(subcurrent, {})
                    if isinstance(obj, dict):
                        obj[k] = v
                elif current in {"constraints", "utils"}:
                    pass
        rule = data.get("rule")
        pattern = None
        if isinstance(rule, dict):
            pattern = rule.get("pattern")
            if isinstance(pattern, dict):
                pattern = pattern.get("context")
            if not pattern and "any" in rule:
                pattern = rule.get("any")
                if isinstance(pattern, dict):
                    pattern = pattern.get("pattern")
        elif isinstance(rule, str):
            pattern = rule
        if pattern:
            data["pattern"] = pattern
            rules.append(data)
    return rules


def parse_scan(argv):
    if any(a in ("-h", "--help") for a in argv):
        print(scan_help()); sys.exit(0)
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("paths", nargs="*")
    p.add_argument("-r", "--rule")
    p.add_argument("--inline-rules")
    p.add_argument("--json", nargs="?", const="pretty", choices=["pretty", "stream", "compact"])
    p.add_argument("--format")
    p.add_argument("--report-style", default="rich")
    p.add_argument("-U", "--update-all", action="store_true")
    p.add_argument("--files-with-matches", action="store_true")
    p.add_argument("-c", "--config", default="sgconfig.yml")
    p.add_argument("--globs", action="append")
    p.add_argument("--follow", action="store_true")
    p.add_argument("--max-results", type=int)
    args, _ = p.parse_known_args(argv)
    texts = []
    if args.inline_rules:
        texts.append(args.inline_rules)
    elif args.rule:
        texts.append(Path(args.rule).read_text())
    else:
        cfg = Path(args.config)
        rule_dirs = ["rules"]
        if cfg.exists():
            text = cfg.read_text()
            m = re.search(r"ruleDirs:\s*\n((?:\s*-\s*.+\n?)+)", text)
            if m:
                rule_dirs = [x.strip().lstrip("-").strip() for x in m.group(1).splitlines()]
        for d in rule_dirs:
            for f in Path(d).glob("*.yml"):
                texts.append(f.read_text())
            for f in Path(d).glob("*.yaml"):
                texts.append(f.read_text())
    rules = []
    for t in texts:
        rules.extend(parse_simple_yaml(t))
    all_matches = []
    contents = {}
    for rule in rules:
        lang = rule.get("language", "")
        for file, content in iter_files(args.paths or ["."], lang, args.follow, args.globs):
            contents[file] = content
            all_matches.extend(find_matches(content, file, rule["pattern"], lang, rule.get("id", ""), rule.get("message", ""), rule.get("severity", "hint"), rule.get("fix")))
            if args.max_results and len(all_matches) >= args.max_results:
                all_matches = all_matches[:args.max_results]
                break
    if args.format == "sarif":
        print(json.dumps({"version": "2.1.0", "runs": [{"results": [{"ruleId": m.rule_id, "message": {"text": m.message}, "locations": []} for m in all_matches]}]}))
        return 0 if all_matches else 1
    if args.format == "github":
        for m in all_matches:
            sev = "error" if m.severity == "error" else "warning"
            print(f"::{sev} file={m.file},line={m.line_no1}::{m.message or m.rule_id}")
        return 0 if all_matches else 1
    return output_matches(all_matches, args, contents)


def do_new(argv):
    if any(a in ("-h", "--help") for a in argv):
        print("Create new ast-grep project or items like rules/tests\n\nUsage: executable new [OPTIONS] [NAME] [COMMAND]")
        return 0
    name = next((a for a in argv if not a.startswith("-") and a not in {"project", "rule", "test", "util"}), "")
    cmd = next((a for a in argv if a in {"project", "rule", "test", "util"}), "project")
    if cmd == "project":
        Path("sgconfig.yml").write_text("ruleDirs:\n  - rules\n")
        Path("rules").mkdir(exist_ok=True)
        print("Created ast-grep project")
    elif cmd in {"rule", "util"} and name:
        Path("rules").mkdir(exist_ok=True)
        Path("rules", f"{name}.yml").write_text(f"id: {name}\nlanguage: Python\nrule:\n  pattern: TODO\nmessage: TODO\nseverity: hint\n")
        print(f"Created rule {name}")
    elif cmd == "test":
        Path("rule-tests").mkdir(exist_ok=True)
        print("Created test")
    return 0


def main():
    cmd, argv = split_args(sys.argv[1:])
    if cmd == "run":
        return parse_run(argv)
    if cmd == "scan":
        return parse_scan(argv)
    if cmd == "test":
        if any(a in ("-h", "--help") for a in argv):
            print("Test ast-grep rules\n\nUsage: executable test [OPTIONS]")
            return 0
        print("No tests found")
        return 0
    if cmd == "new":
        return do_new(argv)
    if cmd == "lsp":
        if any(a in ("-h", "--help") for a in argv):
            print("Start language server\n\nUsage: executable lsp [OPTIONS]")
            return 0
        return 0
    if cmd == "completions":
        if any(a in ("-h", "--help") for a in argv):
            print("Generate shell completion script\n\nUsage: executable completions [OPTIONS] [SHELL]")
            return 0
        print("# completion script")
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
