#!/usr/bin/env python3
import base64
import ctypes
import os
import shutil
import sys


HELP = """Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.
"""


class BrotliError(Exception):
    pass


libenc = ctypes.CDLL("libbrotlienc.so.1")
libdec = ctypes.CDLL("libbrotlidec.so.1")

c_size_p = ctypes.POINTER(ctypes.c_size_t)
c_void_p_p = ctypes.POINTER(ctypes.c_void_p)

libenc.BrotliEncoderCreateInstance.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
libenc.BrotliEncoderCreateInstance.restype = ctypes.c_void_p
libenc.BrotliEncoderDestroyInstance.argtypes = [ctypes.c_void_p]
libenc.BrotliEncoderSetParameter.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_uint32]
libenc.BrotliEncoderSetParameter.restype = ctypes.c_int
libenc.BrotliEncoderCompressStream.argtypes = [
    ctypes.c_void_p,
    ctypes.c_int,
    c_size_p,
    c_void_p_p,
    c_size_p,
    c_void_p_p,
    c_size_p,
]
libenc.BrotliEncoderCompressStream.restype = ctypes.c_int
libenc.BrotliEncoderIsFinished.argtypes = [ctypes.c_void_p]
libenc.BrotliEncoderIsFinished.restype = ctypes.c_int
libenc.BrotliEncoderMaxCompressedSize.argtypes = [ctypes.c_size_t]
libenc.BrotliEncoderMaxCompressedSize.restype = ctypes.c_size_t
libenc.BrotliEncoderCompress.argtypes = [
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_size_t, ctypes.c_void_p,
    c_size_p, ctypes.c_void_p,
]
libenc.BrotliEncoderCompress.restype = ctypes.c_int
if hasattr(libenc, "BrotliEncoderSetCustomDictionary"):
    libenc.BrotliEncoderSetCustomDictionary.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p]

libdec.BrotliDecoderCreateInstance.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
libdec.BrotliDecoderCreateInstance.restype = ctypes.c_void_p
libdec.BrotliDecoderDestroyInstance.argtypes = [ctypes.c_void_p]
libdec.BrotliDecoderDecompressStream.argtypes = [
    ctypes.c_void_p,
    c_size_p,
    c_void_p_p,
    c_size_p,
    c_void_p_p,
    c_size_p,
]
libdec.BrotliDecoderDecompressStream.restype = ctypes.c_int
if hasattr(libdec, "BrotliDecoderSetCustomDictionary"):
    libdec.BrotliDecoderSetCustomDictionary.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p]


def _buf(data):
    return ctypes.create_string_buffer(data, len(data) if data else 1)


def compress_data(data, quality=11, lgwin=24, dictionary=b"", comment=b"", large_window=None):
    if not dictionary and not comment and large_window is None:
        inbuf = _buf(data)
        max_size = libenc.BrotliEncoderMaxCompressedSize(len(data))
        if max_size == 0:
            max_size = len(data) + 1024
        outbuf = ctypes.create_string_buffer(max_size)
        encoded_size = ctypes.c_size_t(max_size)
        ok = libenc.BrotliEncoderCompress(
            int(quality), int(lgwin), 0, len(data), ctypes.cast(inbuf, ctypes.c_void_p),
            ctypes.byref(encoded_size), ctypes.cast(outbuf, ctypes.c_void_p)
        )
        if not ok:
            raise BrotliError("encoder failed")
        return outbuf.raw[:encoded_size.value]

    state = libenc.BrotliEncoderCreateInstance(None, None, None)
    if not state:
        raise BrotliError("encoder init failed")
    keepalive = []
    try:
        libenc.BrotliEncoderSetParameter(state, 1, int(quality))
        if large_window is not None:
            libenc.BrotliEncoderSetParameter(state, 6, 1)
            if large_window:
                libenc.BrotliEncoderSetParameter(state, 2, int(large_window))
        elif lgwin:
            libenc.BrotliEncoderSetParameter(state, 2, int(lgwin))
        libenc.BrotliEncoderSetParameter(state, 5, len(data))
        if dictionary and hasattr(libenc, "BrotliEncoderSetCustomDictionary"):
            dbuf = _buf(dictionary)
            keepalive.append(dbuf)
            libenc.BrotliEncoderSetCustomDictionary(state, len(dictionary), ctypes.cast(dbuf, ctypes.c_void_p))

        out_parts = []

        def run(op, payload):
            inbuf = _buf(payload)
            next_in = ctypes.c_void_p(ctypes.addressof(inbuf))
            avail_in = ctypes.c_size_t(len(payload))
            keepalive.append(inbuf)
            while True:
                outbuf = ctypes.create_string_buffer(65536)
                next_out = ctypes.c_void_p(ctypes.addressof(outbuf))
                avail_out = ctypes.c_size_t(len(outbuf))
                total = ctypes.c_size_t(0)
                ok = libenc.BrotliEncoderCompressStream(
                    state,
                    op,
                    ctypes.byref(avail_in),
                    ctypes.byref(next_in),
                    ctypes.byref(avail_out),
                    ctypes.byref(next_out),
                    ctypes.byref(total),
                )
                if not ok:
                    raise BrotliError("encoder failed")
                produced = len(outbuf) - avail_out.value
                if produced:
                    out_parts.append(outbuf.raw[:produced])
                if avail_in.value == 0 and produced == 0:
                    break
                if avail_in.value == 0 and op != 2:
                    break

        if comment:
            run(3, comment)
        run(2, data)
        while not libenc.BrotliEncoderIsFinished(state):
            run(2, b"")
        return b"".join(out_parts)
    finally:
        libenc.BrotliEncoderDestroyInstance(state)


def decompress_one(data, dictionary=b""):
    state = libdec.BrotliDecoderCreateInstance(None, None, None)
    if not state:
        raise BrotliError("decoder init failed")
    keepalive = []
    try:
        if dictionary and hasattr(libdec, "BrotliDecoderSetCustomDictionary"):
            dbuf = _buf(dictionary)
            keepalive.append(dbuf)
            libdec.BrotliDecoderSetCustomDictionary(state, len(dictionary), ctypes.cast(dbuf, ctypes.c_void_p))
        inbuf = _buf(data)
        next_in = ctypes.c_void_p(ctypes.addressof(inbuf))
        avail_in = ctypes.c_size_t(len(data))
        out_parts = []
        while True:
            outbuf = ctypes.create_string_buffer(65536)
            next_out = ctypes.c_void_p(ctypes.addressof(outbuf))
            avail_out = ctypes.c_size_t(len(outbuf))
            total = ctypes.c_size_t(0)
            res = libdec.BrotliDecoderDecompressStream(
                state,
                ctypes.byref(avail_in),
                ctypes.byref(next_in),
                ctypes.byref(avail_out),
                ctypes.byref(next_out),
                ctypes.byref(total),
            )
            produced = len(outbuf) - avail_out.value
            if produced:
                out_parts.append(outbuf.raw[:produced])
            if res == 1:
                consumed = len(data) - avail_in.value
                return b"".join(out_parts), consumed
            if res == 0:
                raise BrotliError("corrupt input")
            if res == 2 and avail_in.value == 0:
                raise BrotliError("corrupt input")
    finally:
        libdec.BrotliDecoderDestroyInstance(state)


def decompress_data(data, concatenated=False, dictionary=b"", expected_comment=None):
    # The decoder library skips metadata blocks. For comment checking, recognize
    # the short metadata encoding emitted by this tool and the reference binary.
    if expected_comment is not None and expected_comment not in data[:128]:
        raise BrotliError("corrupt input")
    chunks = []
    pos = 0
    while pos < len(data) or (pos == 0 and not data):
        out, used = decompress_one(data[pos:], dictionary)
        chunks.append(out)
        pos += used
        if pos == len(data):
            break
        if not concatenated:
            raise BrotliError("corrupt input")
        if used == 0:
            raise BrotliError("corrupt input")
    return b"".join(chunks)


def die(msg, usage=False):
    sys.stderr.write(msg + "\n")
    if usage:
        sys.stderr.write(HELP)
    return 1


def parse_num(name, value, lo, hi):
    try:
        n = int(value, 10)
    except ValueError:
        raise ValueError(f"error parsing {name} value [{value}]")
    if n < lo or n > hi:
        raise ValueError(f"error parsing {name} value [{value}]")
    return n


def parse_args(argv):
    opts = {
        "stdout": False, "decompress": False, "force": False, "rm": False,
        "copy_stat": True, "output": None, "quality": 11, "test": False,
        "verbose": 0, "lgwin": 0, "large_window": None, "comment": None,
        "dictionary": None, "concatenated": False, "suffix": ".br", "squash": False,
    }
    files = []
    i = 0
    after_dashdash = False
    while i < len(argv):
        a = argv[i]
        if after_dashdash or a == "-" or not a.startswith("-"):
            files.append(a)
            i += 1
            continue
        if a == "--":
            after_dashdash = True
            i += 1
            continue
        if a == "--help":
            print(HELP, end="")
            raise SystemExit(0)
        if a == "--version":
            print("brotli 1.2.0")
            raise SystemExit(0)
        if a.startswith("--"):
            name, eq, val = a[2:].partition("=")
            noarg = {
                "stdout": ("stdout", True), "decompress": ("decompress", True),
                "force": ("force", True), "rm": ("rm", True), "keep": ("rm", False),
                "no-copy-stat": ("copy_stat", False), "test": ("test", True),
                "verbose": ("verbose", None), "concatenated": ("concatenated", True),
                "best": ("quality", 11), "squash": ("squash", True),
            }
            needarg = {
                "output": "output", "quality": "quality", "lgwin": "lgwin",
                "large_window": "large_window", "comment": "comment",
                "dictionary": "dictionary", "suffix": "suffix",
            }
            if name in noarg:
                if eq:
                    return None, None, die(f"must pass the parameter as --{name} value", True)
                key, value = noarg[name]
                if key == "verbose":
                    opts[key] += 1
                else:
                    opts[key] = value
            elif name in needarg:
                if not eq:
                    return None, None, die(f"must pass the parameter as --{name}=value", True)
                if name == "quality":
                    opts["quality"] = parse_num("quality", val, 0, 11)
                elif name == "lgwin":
                    opts["lgwin"] = parse_num("lgwin", val, 0, 24)
                elif name == "large_window":
                    opts["large_window"] = parse_num("large_window", val, 0, 30)
                elif name == "comment":
                    try:
                        decoded = base64.b64decode(val, validate=True)
                    except Exception:
                        raise ValueError(f"error parsing comment value [{val}]")
                    if len(decoded) > 80:
                        raise ValueError(f"error parsing comment value [{val}]")
                    opts["comment"] = decoded
                else:
                    opts[needarg[name]] = val
            else:
                return None, None, die(f"must pass the parameter as --{name}=value", True)
            i += 1
            continue

        j = 1
        while j < len(a):
            ch = a[j]
            if ch.isdigit():
                opts["quality"] = int(ch)
                j += 1
            elif ch in "cdfjnktvKZs":
                if ch == "c":
                    opts["stdout"] = True
                elif ch == "d":
                    opts["decompress"] = True
                elif ch == "f":
                    opts["force"] = True
                elif ch == "j":
                    opts["rm"] = True
                elif ch == "k":
                    opts["rm"] = False
                elif ch == "n":
                    opts["copy_stat"] = False
                elif ch == "t":
                    opts["test"] = True
                elif ch == "v":
                    opts["verbose"] += 1
                elif ch == "K":
                    opts["concatenated"] = True
                elif ch == "Z":
                    opts["quality"] = 11
                elif ch == "s":
                    opts["squash"] = True
                j += 1
            elif ch in "oqwCDS":
                rest = a[j + 1:]
                if rest:
                    val = rest
                    j = len(a)
                else:
                    i += 1
                    if i >= len(argv):
                        raise ValueError(f"expected parameter for -{ch}")
                    val = argv[i]
                    j = len(a)
                if ch == "o":
                    opts["output"] = val
                elif ch == "q":
                    opts["quality"] = parse_num("quality", val, 0, 11)
                elif ch == "w":
                    opts["lgwin"] = parse_num("lgwin", val, 0, 24)
                elif ch == "C":
                    opts["comment"] = base64.b64decode(val, validate=True)
                    if len(opts["comment"]) > 80:
                        raise ValueError(f"error parsing comment value [{val}]")
                elif ch == "D":
                    opts["dictionary"] = val
                elif ch == "S":
                    opts["suffix"] = val
            elif ch == "h":
                print(HELP, end="")
                raise SystemExit(0)
            elif ch == "V":
                print("brotli 1.2.0")
                raise SystemExit(0)
            else:
                raise ValueError(f"invalid option [-{ch}]")
        i += 1
    if opts["test"]:
        opts["decompress"] = True
        opts["stdout"] = True
    return opts, files, 0


def read_input(name):
    if name == "-":
        return sys.stdin.buffer.read()
    with open(name, "rb") as f:
        return f.read()


def output_name(name, opts):
    if opts["output"]:
        return opts["output"]
    if opts["decompress"]:
        suf = opts["suffix"]
        if not name.endswith(suf):
            raise BrotliError(f"empty output file name for [{name}] input file")
        return name[:-len(suf)]
    return name + opts["suffix"]


def write_output(path, data, src, opts):
    if path == "-":
        sys.stdout.buffer.write(data)
        return
    if os.path.exists(path) and not opts["force"]:
        raise BrotliError(f"failed to open output file [{path}]: File exists")
    with open(path, "wb") as f:
        f.write(data)
    if opts["copy_stat"] and src != "-":
        try:
            shutil.copystat(src, path)
        except OSError:
            pass


def main(argv):
    try:
        opts, files, status = parse_args(argv)
        if status:
            return status
    except SystemExit as e:
        return int(e.code)
    except Exception as e:
        return die(str(e), True)

    if not files:
        files = ["-"]
    if opts["output"] and len(files) != 1:
        return die("can not use -o with multiple input files")
    dictionary = b""
    if opts["dictionary"]:
        try:
            with open(opts["dictionary"], "rb") as f:
                dictionary = f.read()
        except OSError as e:
            return die(f"failed to open dictionary [{opts['dictionary']}]: {e.strerror}")

    rc = 0
    for name in files:
        try:
            data = read_input(name)
            if opts["decompress"]:
                out = decompress_data(data, opts["concatenated"], dictionary, opts["comment"])
            else:
                out = compress_data(data, opts["quality"], opts["lgwin"], dictionary, opts["comment"] or b"", opts["large_window"])
            if opts["test"]:
                continue
            if opts["stdout"] or name == "-":
                sys.stdout.buffer.write(out)
            else:
                dst = output_name(name, opts)
                if opts["squash"] and len(out) > os.path.getsize(name):
                    if os.path.exists(dst) and opts["force"]:
                        os.unlink(dst)
                    continue
                write_output(dst, out, name, opts)
                if opts["rm"]:
                    try:
                        os.unlink(name)
                    except OSError:
                        pass
        except BrokenPipeError:
            return 1
        except Exception as e:
            msg = str(e)
            if msg == "corrupt input":
                msg = f"corrupt input [{name}]"
            sys.stderr.write(msg + "\n")
            rc = 1
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
