#!/usr/bin/env python3
import base64
import os
import shutil
import sys


HELP = """Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.
"""


class BitWriter:
    def __init__(self):
        self.out = bytearray()
        self.bit = 0

    def write(self, value, count):
        for i in range(count):
            if self.bit == 0:
                self.out.append(0)
            if (value >> i) & 1:
                self.out[-1] |= 1 << self.bit
            self.bit = (self.bit + 1) & 7

    def align(self):
        if self.bit:
            self.write(0, 8 - self.bit)


class BitReader:
    def __init__(self, data):
        self.data = data
        self.pos = 0

    def read(self, count):
        v = 0
        for i in range(count):
            byte = self.pos >> 3
            if byte >= len(self.data):
                raise ValueError("unexpected end of input")
            if (self.data[byte] >> (self.pos & 7)) & 1:
                v |= 1 << i
            self.pos += 1
        return v

    def align(self):
        if self.pos & 7:
            self.pos += 8 - (self.pos & 7)

    def read_bytes(self, n):
        self.align()
        byte = self.pos >> 3
        end = byte + n
        if end > len(self.data):
            raise ValueError("unexpected end of input")
        self.pos = end << 3
        return self.data[byte:end]


def compress_stored(data):
    if not data:
        return b"\x3f"
    bw = BitWriter()
    bw.write(0x0F, 4)  # RFC window-bits encoding used by the reference CLI.
    start = 0
    while start < len(data):
        chunk = data[start:start + 65536]
        start += len(chunk)
        bw.write(0, 1)          # ISLAST = false
        bw.write(0, 2)          # MNIBBLES = 4
        bw.write(len(chunk) - 1, 16)
        bw.write(1, 1)          # ISUNCOMPRESSED = true
        bw.align()
        bw.out.extend(chunk)
    bw.write(1, 1)              # final empty meta-block
    bw.write(1, 1)
    return bytes(bw.out)


def read_wbits(br):
    first = br.read(1)
    if first == 0:
        return 16
    n = br.read(3)
    if n:
        return 17 + n
    n = br.read(3)
    if n:
        return 8 + n
    return 17


def decompress_stored(data, concatenated=False):
    outputs = []
    offset = 0
    while offset < len(data):
        br = BitReader(data[offset:])
        read_wbits(br)
        out = bytearray()
        while True:
            is_last = br.read(1)
            if is_last:
                if br.read(1):
                    break
                raise ValueError("compressed final meta-block is not supported")
            mnibbles = br.read(2)
            if mnibbles == 3:
                raise ValueError("metadata blocks are not supported")
            nbits = {0: 16, 1: 20, 2: 24}[mnibbles]
            length = br.read(nbits) + 1
            uncompressed = br.read(1)
            if not uncompressed:
                raise ValueError("compressed meta-block is not supported")
            out.extend(br.read_bytes(length))
        br.align()
        outputs.append(bytes(out))
        used = (br.pos + 7) // 8
        offset += used
        if not concatenated:
            break
        while offset < len(data) and data[offset] == 0:
            offset += 1
    if offset < len(data) and not concatenated:
        # Match the usual strict decoder default.
        raise ValueError("trailing input")
    return b"".join(outputs)


def err(msg, show_help=False):
    sys.stderr.write(msg + "\n")
    if show_help:
        sys.stderr.write(HELP)
    return 1


def parse_args(argv):
    opts = {
        "stdout": False, "decompress": False, "force": False, "rm": False,
        "copy_stat": True, "output": None, "test": False, "verbose": 0,
        "suffix": ".br", "concatenated": False, "comment": None,
    }
    files = []
    i = 0
    end_opts = False
    need_value = {"-o": "output", "--output": "output", "-q": "quality",
                  "--quality": "quality", "-w": "lgwin", "--lgwin": "lgwin",
                  "--large_window": "large_window", "-S": "suffix",
                  "--suffix": "suffix", "-C": "comment", "--comment": "comment",
                  "-D": "dictionary", "--dictionary": "dictionary"}
    while i < len(argv):
        a = argv[i]
        if end_opts or a == "-" or not a.startswith("-"):
            files.append(a)
            i += 1
            continue
        if a == "--":
            end_opts = True
            i += 1
            continue
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print("brotli 1.2.0")
            raise SystemExit(0)
        if a.startswith("--"):
            name, eq, val = a.partition("=")
            if name in need_value:
                if not eq:
                    if i + 1 >= len(argv):
                        return None, err(f"expected parameter for {name}", True)
                    val = argv[i + 1]
                    i += 1
                opts[need_value[name]] = val
            elif eq:
                return None, err(f"must pass the parameter as {name}=value", True)
            elif name == "--stdout":
                opts["stdout"] = True
            elif name == "--decompress":
                opts["decompress"] = True
            elif name == "--force":
                opts["force"] = True
            elif name == "--rm":
                opts["rm"] = True
            elif name == "--keep":
                opts["rm"] = False
            elif name == "--no-copy-stat":
                opts["copy_stat"] = False
            elif name == "--test":
                opts["test"] = True
                opts["decompress"] = True
                opts["stdout"] = True
            elif name == "--verbose":
                opts["verbose"] += 1
            elif name == "--best":
                opts["quality"] = "11"
            elif name == "--concatenated":
                opts["concatenated"] = True
            else:
                return None, err(f"must pass the parameter as {name}=value", True)
            i += 1
            continue
        j = 1
        while j < len(a):
            c = a[j]
            opt = "-" + c
            if c.isdigit():
                opts["quality"] = c
            elif opt in ("-c",):
                opts["stdout"] = True
            elif opt == "-d":
                opts["decompress"] = True
            elif opt == "-f":
                opts["force"] = True
            elif opt == "-j":
                opts["rm"] = True
            elif opt == "-s":
                opts["squash"] = True
            elif opt == "-k":
                opts["rm"] = False
            elif opt == "-n":
                opts["copy_stat"] = False
            elif opt == "-t":
                opts["test"] = True
                opts["decompress"] = True
                opts["stdout"] = True
            elif opt == "-v":
                opts["verbose"] += 1
            elif opt == "-Z":
                opts["quality"] = "11"
            elif opt == "-K":
                opts["concatenated"] = True
            elif opt in need_value:
                if j + 1 < len(a):
                    val = a[j + 1:]
                    j = len(a)
                else:
                    if i + 1 >= len(argv):
                        return None, err(f"expected parameter for {opt}", True)
                    val = argv[i + 1]
                    i += 1
                opts[need_value[opt]] = val
                break
            else:
                return None, err(f"invalid option -- {c}", True)
            j += 1
        i += 1
    if opts.get("comment") is not None:
        try:
            if len(base64.b64decode(opts["comment"], validate=True)) > 80:
                return None, err("comment must be no longer than 80 bytes")
        except Exception:
            return None, err("invalid base64 comment")
    return (opts, files), 0


def transform(data, opts):
    if opts["decompress"]:
        return decompress_stored(data, opts["concatenated"])
    return compress_stored(data)


def out_name(path, opts):
    suf = opts["suffix"]
    if opts["decompress"]:
        if path.endswith(suf):
            return path[:-len(suf)]
        return path + ".out"
    return path + suf


def main(argv):
    parsed, status = parse_args(argv)
    if status:
        return status
    opts, files = parsed
    if opts["output"] and (opts["stdout"] or len(files) != 1):
        return err("write to standard output already set (-o)", True)
    if not files:
        files = ["-"]
    rc = 0
    for path in files:
        try:
            if path == "-":
                data = sys.stdin.buffer.read()
                result = transform(data, opts)
                if not opts["test"]:
                    sys.stdout.buffer.write(result)
                continue
            with open(path, "rb") as f:
                data = f.read()
            result = transform(data, opts)
            if opts["test"]:
                continue
            if opts["stdout"]:
                sys.stdout.buffer.write(result)
            else:
                dest = opts["output"] or out_name(path, opts)
                if os.path.exists(dest) and not opts["force"]:
                    raise FileExistsError(f"output file exists: {dest}")
                with open(dest, "wb") as f:
                    f.write(result)
                if opts["copy_stat"]:
                    try:
                        shutil.copystat(path, dest)
                    except OSError:
                        pass
                if opts["rm"]:
                    os.unlink(path)
        except Exception as e:
            sys.stderr.write((f"corrupt input [{path}]" if opts["decompress"] else str(e)) + "\n")
            rc = 1
    return rc


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
