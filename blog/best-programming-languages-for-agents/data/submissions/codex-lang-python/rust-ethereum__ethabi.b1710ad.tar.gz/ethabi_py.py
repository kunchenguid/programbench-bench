#!/usr/bin/env python3
import json
import re
import sys


VERSION = "18.0.0"
MASK64 = (1 << 64) - 1
RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A,
    0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
    0x8000000080008081, 0x8000000000008009, 0x000000000000008A,
    0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089,
    0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
    0x000000000000800A, 0x800000008000000A, 0x8000000080008081,
    0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]
ROT = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
]


class AbiError(Exception):
    pass


def rol(x, n):
    return ((x << n) | (x >> (64 - n))) & MASK64 if n else x


def keccak256(data):
    rate = 136
    st = [0] * 25
    padded = data + b"\x01"
    padded += b"\x00" * ((rate - 1 - len(padded) % rate) % rate)
    padded += b"\x80"
    for off in range(0, len(padded), rate):
        block = padded[off:off + rate]
        for i in range(rate // 8):
            st[i] ^= int.from_bytes(block[i * 8:(i + 1) * 8], "little")
        for rnd in range(24):
            c = [st[x] ^ st[x + 5] ^ st[x + 10] ^ st[x + 15] ^ st[x + 20] for x in range(5)]
            d = [c[(x - 1) % 5] ^ rol(c[(x + 1) % 5], 1) for x in range(5)]
            for x in range(5):
                for y in range(5):
                    st[x + 5 * y] ^= d[x]
            b = [0] * 25
            for x in range(5):
                for y in range(5):
                    b[y + 5 * ((2 * x + 3 * y) % 5)] = rol(st[x + 5 * y], ROT[x][y])
            for x in range(5):
                for y in range(5):
                    st[x + 5 * y] = b[x + 5 * y] ^ ((~b[(x + 1) % 5 + 5 * y]) & b[(x + 2) % 5 + 5 * y])
                    st[x + 5 * y] &= MASK64
            st[0] ^= RC[rnd]
    out = b"".join(x.to_bytes(8, "little") for x in st)
    return out[:32]


def clean_hex(s):
    s = str(s)
    if s.startswith(("0x", "0X")):
        s = s[2:]
    if len(s) % 2:
        raise AbiError("Hex parsing error: Odd number of digits")
    try:
        return bytes.fromhex(s)
    except ValueError:
        raise AbiError("Invalid data")


def word(n):
    return int(n).to_bytes(32, "big", signed=False)


def zpad_right(b):
    return b + b"\x00" * ((32 - len(b) % 32) % 32)


class Type:
    def __init__(self, base, sub=None, arr=None, size=None, comps=None):
        self.base, self.sub, self.arr, self.size, self.comps = base, sub, arr, size, comps or []

    def canonical(self):
        if self.base == "array":
            suffix = "[]" if self.arr is None else "[%d]" % self.arr
            return self.sub.canonical() + suffix
        if self.base == "tuple":
            s = "(" + ",".join(c.canonical() for c in self.comps) + ")"
        elif self.size is not None and self.base in ("uint", "int", "bytes"):
            s = self.base + str(self.size)
        else:
            s = self.base
        return s

    def dynamic(self):
        if self.base in ("string", "bytes") and self.size is None:
            return True
        if self.base == "array":
            return self.arr is None or self.sub.dynamic()
        if self.base == "tuple":
            return any(c.dynamic() for c in self.comps)
        return False


def parse_type(s, components=None):
    dims = []
    while s.endswith("]"):
        i = s.rfind("[")
        dim = s[i + 1:-1]
        dims.append(None if dim == "" else int(dim))
        s = s[:i]
    if s == "tuple":
        t = Type("tuple", comps=[parse_type(c["type"], c.get("components")) for c in (components or [])])
    elif s.startswith("uint"):
        t = Type("uint", size=int(s[4:] or "256"))
    elif s.startswith("int"):
        t = Type("int", size=int(s[3:] or "256"))
    elif s.startswith("bytes") and s != "bytes":
        t = Type("bytes", size=int(s[5:]))
    else:
        t = Type(s)
    for d in reversed(dims):
        t = Type("array", sub=t, arr=d)
    return t


def split_list(s):
    s = s.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    if not s:
        return []
    parts, cur, depth = [], [], 0
    quote = None
    for ch in s:
        if quote:
            cur.append(ch)
            if ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch
            cur.append(ch)
        elif ch == "[":
            depth += 1
            cur.append(ch)
        elif ch == "]":
            depth -= 1
            cur.append(ch)
        elif ch == "," and depth == 0:
            parts.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    parts.append("".join(cur).strip())
    return parts


def parse_value(t, s, lenient=False):
    if t.base == "array":
        vals = split_list(s)
        if t.arr is not None and len(vals) != t.arr:
            raise AbiError("Invalid data")
        return [parse_value(t.sub, v, lenient) for v in vals]
    if t.base == "tuple":
        vals = split_list(s)
        if len(vals) != len(t.comps):
            raise AbiError("Invalid data")
        return [parse_value(c, v, lenient) for c, v in zip(t.comps, vals)]
    if t.base in ("uint", "int"):
        return int(s, 10) if lenient else int.from_bytes(clean_hex(s), "big")
    if t.base == "bool":
        return str(s).lower() in ("1", "true")
    if t.base == "address":
        b = clean_hex(s)
        if len(b) > 20:
            raise AbiError("Invalid data")
        return b.rjust(20, b"\x00")
    if t.base == "string":
        return str(s).encode()
    if t.base == "bytes" and t.size is None:
        return clean_hex(s)
    if t.base == "bytes":
        b = clean_hex(s)
        if len(b) != t.size:
            raise AbiError("Invalid data")
        return b
    raise AbiError("Invalid type")


def encode_single(t, v):
    if t.base == "uint":
        if v < 0 or v >= 1 << t.size:
            raise AbiError("Invalid data")
        return word(v)
    if t.base == "int":
        if v < 0:
            v = (1 << 256) + v
        return word(v)
    if t.base == "bool":
        return word(1 if v else 0)
    if t.base == "address":
        return b"\x00" * 12 + v
    if t.base == "bytes" and t.size is not None:
        return v + b"\x00" * (32 - len(v))
    if t.base == "string" or (t.base == "bytes" and t.size is None):
        return word(len(v)) + zpad_right(v)
    if t.base == "array":
        if t.arr is None:
            return word(len(v)) + encode_tuple([t.sub] * len(v), v)
        return encode_tuple([t.sub] * len(v), v)
    if t.base == "tuple":
        return encode_tuple(t.comps, v)
    raise AbiError("Invalid type")


def encode_tuple(types, vals):
    head_size = 32 * len(types)
    heads, tails = [], []
    offset = head_size
    for t, v in zip(types, vals):
        enc = encode_single(t, v)
        if t.dynamic():
            heads.append(word(offset))
            tails.append(enc)
            offset += len(enc)
        else:
            heads.append(enc)
    return b"".join(heads + tails)


def decode_int(chunk, signed=False):
    n = int.from_bytes(chunk, "big")
    if signed and n >= (1 << 255):
        n -= 1 << 256
    return n


def decode_single(t, data, pos):
    if pos + 32 > len(data):
        raise AbiError("Invalid data")
    if t.dynamic():
        return decode_at(t, data, decode_int(data[pos:pos + 32]))
    return decode_at(t, data, pos)


def decode_array_element(t, data, base, slot):
    if t.dynamic():
        return decode_at(t, data, base + decode_int(data[slot:slot + 32]))
    return decode_at(t, data, slot)


def decode_at(t, data, pos):
    chunk = data[pos:pos + 32]
    if len(chunk) < 32:
        raise AbiError("Invalid data")
    if t.base == "uint":
        return decode_int(chunk)
    if t.base == "int":
        return decode_int(chunk, True)
    if t.base == "bool":
        return decode_int(chunk) != 0
    if t.base == "address":
        return chunk[-20:]
    if t.base == "bytes" and t.size is not None:
        return chunk[:t.size]
    if t.base in ("string", "bytes"):
        ln = decode_int(chunk)
        raw = data[pos + 32:pos + 32 + ln]
        return raw.decode(errors="replace") if t.base == "string" else raw
    if t.base == "array":
        if t.arr is None:
            ln = decode_int(chunk)
            start = pos + 32
            base = start
        else:
            ln = t.arr
            start = pos
            base = start
        return [decode_array_element(t.sub, data, base, start + 32 * i) for i in range(ln)]
    if t.base == "tuple":
        return [decode_single(c, data, pos + 32 * i) for i, c in enumerate(t.comps)]
    raise AbiError("Invalid type")


def format_value(t, v):
    if t.base == "array":
        return "[" + ",".join(format_value(t.sub, x) for x in v) + "]"
    if t.base == "tuple":
        return "(" + ",".join(format_value(c, x) for c, x in zip(t.comps, v)) + ")"
    if t.base == "bool":
        return "true" if v else "false"
    if t.base == "address":
        return v.hex()
    if t.base == "bytes":
        return v.hex()
    return str(v)


def sig(item, kind):
    inputs = item.get("inputs", []) if kind != "function_outputs" else item.get("outputs", [])
    return item.get("name", "") + "(" + ",".join(parse_type(x["type"], x.get("components")).canonical() for x in inputs) + ")"


def load_abi(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def choose(abi, kind, name):
    matches = [x for x in abi if x.get("type") == kind]
    for x in matches:
        if sig(x, kind) == name or x.get("name") == name:
            return x
    raise AbiError("Invalid name")


def output_decoded(types, values):
    for t, v in zip(types, values):
        print(t.canonical(), format_value(t, v))


def parse_flags(args, pairs=False):
    flags, rest, values, types = {"lenient": False}, [], [], []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-l", "--lenient"):
            flags["lenient"] = True
            i += 1
        elif a == "-v":
            values.append((args[i + 1], args[i + 2]))
            i += 3
        elif a == "-p":
            values.append(args[i + 1])
            i += 2
        elif a == "-t":
            types.append(args[i + 1])
            i += 2
        elif a == "--help" or a == "-h":
            help_main()
            return None
        else:
            rest.append(a)
            i += 1
    return flags, rest, values, types


def help_main():
    print(f"ethabi-cli {VERSION}\nEthereum ABI coder\n\nUSAGE:\n    executable <SUBCOMMAND>")


HELPS = {
    (): f"""ethabi-cli {VERSION}
Ethereum ABI coder

USAGE:
    executable <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    decode    Decode ABI call result
    encode    Encode ABI call
    help      Prints this message or the help of the given subcommand(s)""",
    ("encode",): f"""executable-encode {VERSION}
Encode ABI call

USAGE:
    executable encode <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    function    Load function from JSON ABI file
    help        Prints this message or the help of the given subcommand(s)
    params      Specify types of input params inline""",
    ("decode",): f"""executable-decode {VERSION}
Decode ABI call result

USAGE:
    executable decode <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    function    Load function from JSON ABI file
    help        Prints this message or the help of the given subcommand(s)
    log         Decode event log
    params      Specify types of input params inline""",
    ("encode", "params"): f"""executable-encode-params {VERSION}
Specify types of input params inline

USAGE:
    executable encode params [FLAGS] [OPTIONS]

FLAGS:
    -h, --help       
            Prints help information

    -l, --lenient    
            Allow short representation of input params (numbers are in decimal form)

    -V, --version    
            Prints version information


OPTIONS:
    -v <type-or-param> <type-or-param>        
            Pairs of types directly followed by params in the form:
            
            -v <type1> <param1> -v <type2> <param2> ...""",
    ("encode", "function"): f"""executable-encode-function {VERSION}
Load function from JSON ABI file

USAGE:
    executable encode function [FLAGS] [OPTIONS] <abi-path> <function-name-or-signature>

FLAGS:
    -h, --help       Prints help information
    -l, --lenient    Allow short representation of input params
    -V, --version    Prints version information

OPTIONS:
    -p <params>...        

ARGS:
    <abi-path>                      
    <function-name-or-signature>    """,
    ("decode", "params"): f"""executable-decode-params {VERSION}
Specify types of input params inline

USAGE:
    executable decode params [OPTIONS] <data>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -t <type>...        

ARGS:
    <data>    """,
    ("decode", "function"): f"""executable-decode-function {VERSION}
Load function from JSON ABI file

USAGE:
    executable decode function <abi-path> <function-name-or-signature> <data>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <abi-path>                      
    <function-name-or-signature>    
    <data>                          """,
    ("decode", "log"): f"""executable-decode-log {VERSION}
Decode event log

USAGE:
    executable decode log [OPTIONS] <abi-path> <event-name-or-signature> <data>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -l <topic>...        

ARGS:
    <abi-path>                   
    <event-name-or-signature>    
    <data>                       """,
}


def maybe_help(argv):
    if argv and argv[-1] in ("-h", "--help", "help"):
        key = tuple(x for x in argv[:-1] if x != "help")
        print(HELPS.get(key, HELPS[()]))
        return True
    return False


def main(argv):
    try:
        if not argv or argv[0] in ("-h", "--help", "help"):
            print(HELPS[()])
            return 0
        if maybe_help(argv):
            return 0
        if argv[0] in ("-V", "--version"):
            print(f"ethabi-cli {VERSION}")
            return 0
        if argv[:2] == ["encode", "params"]:
            parsed = parse_flags(argv[2:])
            if not parsed:
                return 0
            flags, _, pairs, _ = parsed
            types = [parse_type(a) for a, _ in pairs]
            vals = [parse_value(t, b, flags["lenient"]) for t, (_, b) in zip(types, pairs)]
            print(encode_tuple(types, vals).hex())
            return 0
        if argv[:2] == ["decode", "params"]:
            parsed = parse_flags(argv[2:])
            if not parsed:
                return 0
            _, rest, _, type_names = parsed
            types = [parse_type(x) for x in type_names]
            data = clean_hex(rest[0])
            output_decoded(types, [decode_single(t, data, i * 32) for i, t in enumerate(types)])
            return 0
        if argv[:2] == ["encode", "function"]:
            parsed = parse_flags(argv[2:])
            if not parsed:
                return 0
            flags, rest, params, _ = parsed
            item = choose(load_abi(rest[0]), "function", rest[1])
            types = [parse_type(x["type"], x.get("components")) for x in item.get("inputs", [])]
            vals = [parse_value(t, p, flags["lenient"]) for t, p in zip(types, params)]
            selector = keccak256(sig(item, "function").encode())[:4]
            print((selector + encode_tuple(types, vals)).hex())
            return 0
        if argv[:2] == ["decode", "function"]:
            abi = load_abi(argv[2])
            item = choose(abi, "function", argv[3])
            data = clean_hex(argv[4])
            if len(data) >= 4 and data[:4] == keccak256(sig(item, "function").encode())[:4]:
                data = data[4:]
            types = [parse_type(x["type"], x.get("components")) for x in item.get("outputs", [])]
            output_decoded(types, [decode_single(t, data, i * 32) for i, t in enumerate(types)])
            return 0
        if argv[:2] == ["decode", "log"]:
            parsed = parse_flags(argv[2:])
            if not parsed:
                return 0
            _, rest, topics, _ = parsed
            item = choose(load_abi(rest[0]), "event", rest[1])
            inputs = item.get("inputs", [])
            data = clean_hex(rest[2])
            topic_bytes = [clean_hex(t) for t in topics]
            if not item.get("anonymous", False) and topic_bytes:
                topic_bytes = topic_bytes[1:]
            data_types, data_positions = [], []
            indexed = []
            for inp in inputs:
                t = parse_type(inp["type"], inp.get("components"))
                if inp.get("indexed"):
                    indexed.append(t)
                else:
                    data_positions.append(t)
                    data_types.append(t)
            out = []
            ti = di = 0
            for inp in inputs:
                t = parse_type(inp["type"], inp.get("components"))
                if inp.get("indexed"):
                    b = topic_bytes[ti]
                    ti += 1
                    out.append(decode_at(t, b.rjust(32, b"\x00"), 0) if not t.dynamic() else b)
                else:
                    out.append(decode_single(t, data, di * 32))
                    di += 1
            output_decoded([parse_type(x["type"], x.get("components")) for x in inputs], out)
            return 0
        if len(argv) >= 2 and argv[1] in ("-h", "--help", "help"):
            help_main()
            return 0
        raise AbiError("Invalid command")
    except Exception as e:
        msg = str(e) or e.__class__.__name__
        print(f"Error: {msg}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
