#!/usr/bin/env python3
import os, sys, stat, fnmatch

HELP = """Usage: ./executable [options] <path> [<path>..]

Options:
    -d, --depth [DEPTH] show directories up to depth N (def 1)
    -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)
    -s, --summary       equivalent to -da, or -d1 -a1M
    -u, --usage         report real disk usage instead of file size
    -b, --bytes         print sizes in bytes
    -f, --files-only    skip directories for a fast local overview
    -x, --exclude NAME  exclude matching files or directories
    -H, --no-hidden     exclude hidden files
    -A, --ascii         ASCII characters only, no colors
    -h, --help          show help
    -v, --version       print version number"""

class Node:
    __slots__ = ('name','path','size','children','is_dir')
    def __init__(self,name,path,size=0,is_dir=False):
        self.name=name; self.path=path; self.size=size; self.children=[]; self.is_dir=is_dir

def parse_num(s):
    if s is None: return None
    mult=1
    if s and s[-1].upper() in 'KMG':
        ch=s[-1].upper(); s=s[:-1]
        mult={'K':1024,'M':1024**2,'G':1024**3}[ch]
    try:
        return int(s)*mult
    except Exception:
        return None

def parse_args(argv):
    opts={'depth':None,'aggr':0,'usage':False,'bytes':False,'files_only':False,'hidden':True,'ascii':False,'excludes':[]}
    paths=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a in ('--help','-h'):
            print(HELP); sys.exit(0)
        if a in ('--version','-v'):
            print('dutree version 0.2.18'); sys.exit(0)
        if a in ('-s','--summary'):
            opts['depth']=1; opts['aggr']=1024**2; i+=1; continue
        if a in ('-u','--usage'):
            opts['usage']=True; i+=1; continue
        if a in ('-b','--bytes'):
            opts['bytes']=True; i+=1; continue
        if a in ('-f','--files-only'):
            opts['files_only']=True; i+=1; continue
        if a in ('-H','--no-hidden'):
            opts['hidden']=False; i+=1; continue
        if a in ('-A','--ascii'):
            opts['ascii']=True; i+=1; continue
        if a in ('-x','--exclude'):
            if i+1>=len(argv):
                print("option 'exclude' requires an argument", file=sys.stderr); sys.exit(1)
            opts['excludes'].append(argv[i+1]); i+=2; continue
        if a.startswith('--exclude='):
            opts['excludes'].append(a.split('=',1)[1]); i+=1; continue
        if a in ('-d','--depth'):
            val=None
            if i+1 < len(argv):
                val=parse_num(argv[i+1])
                i+=1
            opts['depth']=1 if val is None else val; i+=1; continue
        if a.startswith('--depth='):
            n=parse_num(a.split('=',1)[1]); opts['depth']=1 if n is None else n; i+=1; continue
        if a.startswith('-d') and len(a)>2:
            tail=a[2:]
            if tail == 'a':
                opts['depth']=1; opts['aggr']=1024**2
            else:
                n=parse_num(tail); opts['depth']=1 if n is None else n
            i+=1; continue
        if a in ('-a','--aggr'):
            val=None
            if i+1 < len(argv):
                val=parse_num(argv[i+1])
                if val is None:
                    print("invalid argument '%s'" % argv[i+1]); sys.exit(0)
                i+=1
            opts['aggr']=1024**2 if val is None else val; i+=1; continue
        if a.startswith('--aggr='):
            n=parse_num(a.split('=',1)[1])
            if n is None:
                print("invalid argument '%s'" % a.split('=',1)[1]); sys.exit(0)
            opts['aggr']=n; i+=1; continue
        if a.startswith('-a') and len(a)>2:
            n=parse_num(a[2:])
            if n is None:
                print("invalid argument '%s'" % a[2:]); sys.exit(0)
            opts['aggr']=n; i+=1; continue
        if a.startswith('-') and a != '-':
            print(HELP); print("Unrecognized option: '%s'" % a.lstrip('-')); sys.exit(1)
        paths.append(a); i+=1
    if not paths: paths=['.']
    return opts, paths

def excluded(name, opts):
    if not opts['hidden'] and name.startswith('.'):
        return True
    for p in opts['excludes']:
        if name == p or fnmatch.fnmatch(name,p):
            return True
    return False

def own_size(st, usage):
    return int(st.st_blocks)*512 if usage else int(st.st_size)

def build(path, opts):
    try: st=os.lstat(path)
    except OSError: return None
    stripped = path.rstrip('/')
    name=os.path.basename(stripped)
    if not name or name in ('.', '..'):
        name=os.path.basename(os.path.abspath(path))
    isdir=stat.S_ISDIR(st.st_mode)
    n=Node(name,path,own_size(st,opts['usage']),isdir)
    if isdir:
        try: entries=list(os.scandir(path))
        except OSError: entries=[]
        for e in entries:
            if excluded(e.name, opts):
                continue
            try:
                est=os.lstat(e.path)
            except OSError:
                continue
            if opts['files_only'] and stat.S_ISDIR(est.st_mode):
                continue
            c=build(e.path, opts)
            if c:
                n.children.append(c); n.size += c.size
    return n

def aggregate(node, threshold):
    for c in node.children:
        aggregate(c, threshold)
    if threshold is None or threshold <= 0 or not node.children:
        return
    keep=[]; agg=0
    for c in node.children:
        if c.size < threshold:
            agg += c.size
        else:
            keep.append(c)
    if agg:
        keep.append(Node('<aggregated>','',agg,False))
    node.children=keep

def sort_tree(node):
    node.children.sort(key=lambda c: -c.size)
    for c in node.children:
        sort_tree(c)

def fmt_size(n, bytes_mode=False):
    if bytes_mode:
        return f"{n} B"
    units=['B','KiB','MiB','GiB','TiB']; x=float(n); u=0
    while x >= 1024 and u < len(units)-1:
        x/=1024.0; u+=1
    if u==0:
        return f"{int(n)} B"
    return f"{x:.2f} {units[u]}"

def trunc_name(name):
    return name if len(name) <= 20 else name[:20]

def bar(size, maxsize, ascii_mode):
    ch = '#' if ascii_mode else '█'
    if maxsize <= 0:
        return ' '*32
    cnt = int((size * 32) / maxsize)
    if cnt > 32:
        cnt = 32
    if cnt < 2:
        cnt = 0
    return ' '*(32-cnt) + ch*cnt

def print_node(root, opts):
    print(f"[ {root.name} {fmt_size(root.size, opts['bytes'])} ]")
    def rec(node, prefix, rel_depth, inherited_bar=None):
        kids=node.children
        if opts['depth'] is not None and rel_depth >= opts['depth']:
            kids=[]
        if not kids:
            return
        maxs=max([k.size for k in kids] or [0])
        for idx,c in enumerate(kids):
            last = idx == len(kids)-1
            branch = '└─ ' if last else '├─ '
            pct = int((c.size*100)//node.size) if node.size else 0
            name_width = max(1, 26 - len(prefix) - len(branch))
            name = trunc_name(c.name)
            if len(name) > name_width:
                name = name[:name_width]
            line_bar = bar(c.size,maxs,opts['ascii']) if inherited_bar is None else inherited_bar
            line = prefix + branch + f"{name:<{name_width}}" + "│ " + line_bar + "│" + f" {pct:3d}%" + f"{fmt_size(c.size, opts['bytes']):>14}"
            print(line)
            rec(c, prefix + ('   ' if last else '│  '), rel_depth+1, line_bar)
    rec(root,'',-1 if root.name == '<collection>' else 0)

def main(argv):
    opts, paths = parse_args(argv)
    roots=[]
    for p in paths:
        if not os.path.exists(p):
            print(f"path {p} doesn't exist")
            continue
        base=os.path.basename(p.rstrip('/')) or p
        if excluded(base, opts):
            continue
        n=build(p, opts)
        if n:
            roots.append(n)
    if not roots:
        return 0
    if len(roots)==1:
        root=roots[0]
    else:
        root=Node('<collection>','',sum(r.size for r in roots),False); root.children=roots
    aggregate(root, opts['aggr'])
    sort_tree(root)
    print_node(root, opts)
    return 0
if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
