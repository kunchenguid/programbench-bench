#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
import warnings
from pathlib import Path
from urllib.parse import quote

warnings.filterwarnings("ignore", category=DeprecationWarning)

import jsonschema
from jsonschema import FormatChecker
from jsonschema.exceptions import SchemaError, ValidationError
from jsonschema.validators import RefResolver


VERSION = "0.41.0"
VALID_DRAFTS = {"4", "6", "7", "2019", "2020"}
VALID_OUTPUTS = {"text", "flag", "list", "hierarchical"}


def eprint(text):
    print(text, file=sys.stderr)


def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        raise RuntimeError("No such file or directory (os error 2)")
    except PermissionError:
        raise RuntimeError("Permission denied (os error 13)")
    except json.JSONDecodeError as exc:
        msg = exc.msg
        if msg == "Expecting property name enclosed in double quotes":
            msg = "key must be a string"
        elif msg == "Expecting value":
            msg = "expected value"
        elif msg == "Expecting ':' delimiter":
            msg = "expected `:`"
        elif msg == "Expecting ',' delimiter":
            msg = "expected `,` or `}`"
        raise RuntimeError(f"{msg} at line {exc.lineno} column {exc.colno}")


def validator_class(schema, draft):
    if draft == "4":
        return jsonschema.Draft4Validator
    if draft == "6":
        return jsonschema.Draft6Validator
    if draft == "7":
        return jsonschema.Draft7Validator
    if draft == "2019":
        return jsonschema.Draft201909Validator
    if draft == "2020":
        return jsonschema.Draft202012Validator
    return jsonschema.validators.validator_for(schema, default=jsonschema.Draft202012Validator)


def to_json_value(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def quote_strings(message):
    # The Rust CLI prints JSON strings with double quotes in validation messages,
    # while python-jsonschema generally uses repr() with single quotes.
    def repl(match):
        inner = match.group(1)
        if inner in {"anyOf", "oneOf", "allOf"}:
            return "'" + inner + "'"
        return '"' + inner.replace('"', '\\"') + '"'

    return re.sub(r"'([^']*)'", repl, message)


def human_join(values):
    rendered = [to_json_value(v) for v in values]
    if len(rendered) == 1:
        return rendered[0]
    if len(rendered) == 2:
        return f"{rendered[0]} or {rendered[1]}"
    return ", ".join(rendered[:-1]) + f", or {rendered[-1]}"


def error_message(error):
    v = error.validator
    inst = error.instance
    val = error.validator_value
    if v == "type":
        types = val if isinstance(val, list) else [val]
        return f"{to_json_value(inst)} is not of type {human_join(types)}"
    if v == "enum":
        return f"{to_json_value(inst)} is not one of {human_join(val)}"
    if v == "const":
        return f"{to_json_value(val)} was expected"
    if v == "minimum":
        return f"{to_json_value(inst)} is less than the minimum of {to_json_value(val)}"
    if v == "maximum":
        return f"{to_json_value(inst)} is greater than the maximum of {to_json_value(val)}"
    if v == "exclusiveMinimum":
        return f"{to_json_value(inst)} is less than or equal to the minimum of {to_json_value(val)}"
    if v == "exclusiveMaximum":
        return f"{to_json_value(inst)} is greater than or equal to the maximum of {to_json_value(val)}"
    if v == "multipleOf":
        return f"{to_json_value(inst)} is not a multiple of {to_json_value(val)}"
    if v == "minLength":
        return f"{to_json_value(inst)} is shorter than {val} characters"
    if v == "maxLength":
        return f"{to_json_value(inst)} is longer than {val} characters"
    if v == "pattern":
        return f"{to_json_value(inst)} does not match {to_json_value(val)}"
    if v == "required":
        missing = next((x for x in val if isinstance(inst, dict) and x not in inst), val[0] if val else "")
        return f"{to_json_value(missing)} is a required property"
    if v == "additionalProperties":
        return error.message
    if v == "uniqueItems":
        return f"{to_json_value(inst)} has non-unique elements"
    if v == "format":
        return f"{to_json_value(inst)} is not a {to_json_value(val)}"
    if v in {"anyOf", "oneOf", "allOf"} and "any of the given schemas" in error.message:
        return f"{to_json_value(inst)} is not valid under any of the schemas listed in the '{v}' keyword"
    return quote_strings(error.message)


def ptr(parts):
    if not parts:
        return ""
    return "/" + "/".join(str(p).replace("~", "~0").replace("/", "~1") for p in parts)


def schema_uri(path):
    return Path(path).resolve().as_uri() + "#"


def schema_location(base, schema_path):
    p = ptr(schema_path)
    return base + p if p else base


def sort_errors(errors):
    def key(e):
        ip = list(e.absolute_path)
        # The reference prints nested instance failures before object-level
        # additionalProperties failures.
        empty_instance = 1 if not ip else 0
        return (empty_instance, ip, list(e.absolute_schema_path), e.validator)

    return sorted(errors, key=key)


def parent_schema_paths(schema, error):
    path = list(error.absolute_schema_path)
    out = []
    for i in range(1, len(path)):
        prefix = path[:i]
        node = schema
        ok = True
        for part in prefix:
            try:
                node = node[part]
            except Exception:
                ok = False
                break
        if ok and isinstance(node, dict):
            out.append(prefix)
    return out


def make_detail(valid, base, evaluation_path="", instance_path="", errors=None):
    d = {
        "evaluationPath": evaluation_path,
        "instanceLocation": instance_path,
        "schemaLocation": schema_location(base, evaluation_path.strip("/").split("/") if evaluation_path else []),
        "valid": valid,
    }
    if errors:
        d["errors"] = errors
    return d


def detail_for_error(error, base):
    ep = ptr(error.absolute_schema_path)
    ip = ptr(error.absolute_path)
    return make_detail(False, base, ep, ip, {error.validator: error_message(error)})


def list_report(schema, base, valid, errors):
    details = [make_detail(valid, base)]
    seen = {("", "")}
    if isinstance(schema, dict) and "type" in schema:
        details.append(make_detail(True, base, "/type", ""))
        seen.add(("/type", ""))
    for err in sort_errors(errors):
        for sp in parent_schema_paths(schema, err):
            if sp == ["properties"]:
                continue
            ep = ptr(sp)
            ip = ptr(err.absolute_path)
            key = (ep, ip)
            if key not in seen:
                details.append(make_detail(False, base, ep, ip))
                seen.add(key)
        d = detail_for_error(err, base)
        key = (d["evaluationPath"], d["instanceLocation"])
        if key not in seen:
            details.append(d)
            seen.add(key)
        else:
            details.append(d)
    return {"details": details, "valid": valid}


def hierarchical_report(base, valid, errors):
    root = make_detail(valid, base)
    if errors:
        root["details"] = [detail_for_error(e, base) for e in sort_errors(errors)]
    return root


def output_json(style, schema_path, instance_path, payload):
    result = {"output": style, "payload": payload, "schema": schema_path}
    if instance_path is not None:
        result = {"instance": instance_path, **result}
    print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))


def validate_schema(schema, cls):
    try:
        cls.check_schema(schema)
        return None
    except SchemaError as exc:
        return error_message(exc)


def parse_args(argv):
    if "-v" in argv or "--version" in argv:
        print(f"Version: {VERSION}")
        raise SystemExit(0)
    if "-h" in argv or "--help" in argv:
        print("""Usage: executable [OPTIONS] [SCHEMA]

Arguments:
  [SCHEMA]  The JSON Schema to validate with (i.e. schema.json)

Options:
  -i, --instance <INSTANCES>       A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)
  -d, --draft <DRAFT>              Enforce a specific JSON Schema draft [possible values: 4, 6, 7, 2019, 2020]
      --assert-format              Turn ON format validation
      --no-assert-format           Turn OFF format validation
      --output <OUTPUT>            Select output style: text (default), flag, list, hierarchical [default: text] [possible values: text, flag, list, hierarchical]
  -v, --version                    Show program's version number and exit
      --errors-only                Only show validation errors
      --connect-timeout <SECONDS>  Timeout for establishing connections (in seconds)
      --timeout <SECONDS>          Total timeout for HTTP requests (in seconds)
  -k, --insecure                   Skip TLS certificate verification (dangerous!)
      --cacert <FILE>              Path to a custom CA certificate file (PEM format)
  -h, --help                       Print help""")
        raise SystemExit(0)

    p = argparse.ArgumentParser(add_help=False, prog="executable")
    p.add_argument("-i", "--instance", action="append", dest="instances")
    p.add_argument("-d", "--draft")
    p.add_argument("--assert-format", action="store_true", dest="assert_format")
    p.add_argument("--no-assert-format", action="store_true", dest="no_assert_format")
    p.add_argument("--output", default="text")
    p.add_argument("--errors-only", action="store_true")
    p.add_argument("--connect-timeout")
    p.add_argument("--timeout")
    p.add_argument("-k", "--insecure", action="store_true")
    p.add_argument("--cacert")
    p.add_argument("schema", nargs="?")
    ns, extra = p.parse_known_args(argv)
    if extra:
        eprint(f"error: unexpected argument '{extra[0]}'")
        raise SystemExit(2)
    if ns.draft is not None and ns.draft not in VALID_DRAFTS:
        eprint(f"error: invalid value '{ns.draft}' for '--draft <DRAFT>'")
        eprint("  [possible values: 4, 6, 7, 2019, 2020]\n")
        eprint("For more information, try '--help'.")
        raise SystemExit(2)
    if ns.output not in VALID_OUTPUTS:
        eprint(f"error: invalid value '{ns.output}' for '--output <OUTPUT>'")
        eprint("  [possible values: text, flag, list, hierarchical]\n")
        eprint("For more information, try '--help'.")
        raise SystemExit(2)
    if ns.schema is None:
        eprint("error: the following required arguments were not provided:")
        eprint("  <SCHEMA>\n")
        usage = "Usage: executable"
        if ns.instances:
            usage += " --instance <INSTANCES>"
        usage += " <SCHEMA>"
        eprint(usage + "\n")
        eprint("For more information, try '--help'.")
        raise SystemExit(2)
    return ns


def main(argv):
    ns = parse_args(argv)
    try:
        schema = load_json(ns.schema)
    except RuntimeError as exc:
        eprint(f"Error: {exc}")
        return 1

    cls = validator_class(schema, ns.draft)
    schema_error = validate_schema(schema, cls)
    if schema_error:
        print(f"Schema is invalid. Error: {schema_error}")
        return 1

    format_checker = FormatChecker() if ns.assert_format and not ns.no_assert_format else None
    resolver = RefResolver(base_uri=schema_uri(ns.schema), referrer=schema)
    validator = cls(schema, format_checker=format_checker, resolver=resolver)
    style = ns.output

    if not ns.instances:
        if style == "text":
            print("Schema is valid")
        else:
            base = cls.META_SCHEMA.get("$id", "https://json-schema.org/draft/2020-12/schema")
            if not base.endswith("#"):
                base += "#"
            payload = {"valid": True}
            if style == "flag":
                pass
            elif style == "list":
                payload = {"details": [make_detail(True, base)], "valid": True}
            elif style == "hierarchical":
                payload = make_detail(True, base)
            output_json(style, ns.schema, None, payload)
        return 0

    any_invalid = False
    for instance_path in ns.instances:
        try:
            instance = load_json(instance_path)
        except RuntimeError as exc:
            eprint(f"Error: {exc}")
            return 1
        errors = list(validator.iter_errors(instance))
        valid = not errors
        any_invalid = any_invalid or not valid
        if style == "text":
            if valid:
                if not ns.errors_only:
                    print(f"{instance_path} - VALID")
            else:
                print(f"{instance_path} - INVALID. Errors:")
                for idx, err in enumerate(sort_errors(errors), 1):
                    print(f"{idx}. {error_message(err)}")
        else:
            if ns.errors_only and valid:
                continue
            if style == "flag":
                payload = {"valid": valid}
            elif style == "list":
                payload = list_report(schema, schema_uri(ns.schema), valid, errors)
            else:
                payload = hierarchical_report(schema_uri(ns.schema), valid, errors)
            output_json(style, ns.schema, instance_path, payload)
    return 1 if any_invalid else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
