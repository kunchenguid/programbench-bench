#!/usr/bin/env python3
import os
import re
import sys


HELP = """Shellharden: The corrective bash syntax highlighter.

Usage:
\tshellharden [options] [files]
\tcat files | shellharden [options] ''

Shellharden is a syntax highlighter and a tool to semi-automate the rewriting
of scripts to ShellCheck conformance, mainly focused on quoting.

The default mode of operation is like `cat`, but with syntax highlighting in
foreground colors and suggestive changes in background colors.

Options:
\t--suggest         Output a colored diff suggesting changes.
\t--syntax          Output syntax highlighting with ANSI colors.
\t--syntax-suggest  Diff with syntax highlighting (default mode).
\t--transform       Output suggested changes.
\t--check           No output; exit with 2 if changes are suggested.
\t--replace         Replace file contents with suggested changes.
\t--                Don't treat further arguments as options.
\t-h|--help         Show help text.
\t--version         Show version.

The changes suggested by Shellharden inhibits word splitting and indirect
pathname expansion. This will make your script ShellCheck compliant in terms of
quoting. Whether your script will work afterwards is a different question:
If your script was using those features on purpose, it obviously won't anymore!

Every script is possible to write without using word splitting or indirect
pathname expansion, but it may involve doing things differently.
See the accompanying file how_to_do_things_safely_in_bash.md or online:
https://github.com/anordal/shellharden/blob/master/how_to_do_things_safely_in_bash.md

"""

IDENT0 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_"
IDENT = IDENT0 + "0123456789"
SEP = set(" \t\r\n;|&()<>")


def matching(s, start, open_ch="(", close_ch=")"):
    depth = 1
    i = start
    single = double = False
    while i < len(s):
        c = s[i]
        if c == "\\":
            i += 2
            continue
        if single:
            if c == "'":
                single = False
            i += 1
            continue
        if c == "'":
            single = True
            i += 1
            continue
        if c == '"' and not single:
            double = not double
            i += 1
            continue
        if not double or open_ch == "(":
            if c == open_ch:
                depth += 1
            elif c == close_ch:
                depth -= 1
                if depth == 0:
                    return i
        i += 1
    return -1


def word_start(out):
    i = len(out) - 1
    while i >= 0 and out[i] not in SEP:
        i -= 1
    return i + 1


def in_assignment(out):
    w = "".join(out[word_start(out):])
    if not w or w.startswith(("-", "$")):
        return False
    eq = w.find("=")
    return eq > 0 and re.match(r"^[A-Za-z_][A-Za-z0-9_]*(\[[^]]+\])?$", w[:eq]) is not None


def last_word(out):
    w = "".join(out[:]).rstrip()
    if not w:
        return ""
    m = re.search(r"([^ \t;|&()<>]+)$", w)
    return m.group(1) if m else ""


def previous_word(out):
    w = "".join(out).rstrip()
    parts = re.findall(r"[^ \t;|&()<>]+", w)
    return parts[-1] if parts else ""


def simple_braced(body):
    return re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", body) is not None


def quote_expansion(raw, body, next_ch, for_in=False):
    if raw == "$*":
        return '"$@"'
    if raw == "$@":
        return '"$@"'
    if raw.startswith("${") and raw.endswith("}"):
        b = body
        if b.endswith("[*]"):
            b = b[:-3] + "[@]"
            return '"${' + b + '}"'
        if b.endswith("[@]"):
            return '"${' + b + '}"'
        if re.match(r"^[0-9]+$", b):
            return '"${' + b + '}"' if len(b) > 1 else '"$' + b + '"'
        if for_in and simple_braced(b):
            return '"${' + b + '[@]}"'
        if simple_braced(b):
            if next_ch and next_ch in IDENT:
                return '"${' + b + '}"'
            return '"$' + b + '"'
        return '"${' + b + '}"'
    name = body
    if for_in and re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", name):
        return '"${' + name + '[@]}"'
    return '"$' + name + '"'


def transform_double(s, i):
    out = ['"']
    i += 1
    while i < len(s):
        c = s[i]
        if c == "\\" and i + 1 < len(s):
            out.append(s[i:i+2])
            i += 2
            continue
        if c == '"':
            out.append('"')
            return "".join(out), i + 1
        if c == "$":
            parsed = parse_expansion(s, i, quoted=True, for_in=False)
            if parsed:
                text, ni = parsed
                out.append(text)
                i = ni
                continue
        out.append(c)
        i += 1
    return "".join(out), i


def parse_expansion(s, i, quoted=False, for_in=False):
    if i + 1 >= len(s):
        return None
    n = s[i + 1]
    if n == "(":
        if i + 2 < len(s) and s[i + 2] == "(":
            end = matching(s, i + 3)
            if end >= 0 and end + 1 < len(s) and s[end + 1] == ")":
                return s[i:end+2], end + 2
            return None
        end = matching(s, i + 2)
        if end < 0:
            return None
        inner = transform_text(s[i + 2:end])
        raw = "$(" + inner + ")"
        return (raw if quoted else '"' + raw + '"'), end + 1
    if n == "{":
        end = s.find("}", i + 2)
        if end < 0:
            return None
        body = s[i + 2:end]
        raw = s[i:end + 1]
        if body.startswith("#"):
            return raw, end + 1
        if quoted:
            if simple_braced(body):
                nxt = s[end + 1] if end + 1 < len(s) else ""
                return ("${" + body + "}" if nxt and nxt in IDENT else "$" + body), end + 1
            if body.endswith("[*]"):
                return "${" + body[:-3] + "[@]}", end + 1
            return raw, end + 1
        nxt = s[end + 1] if end + 1 < len(s) else ""
        return quote_expansion(raw, body, nxt, for_in), end + 1
    if n in "?$!#-":
        return s[i:i+2], i + 2
    if n in "*@":
        return ("$@" if quoted else '"$@"'), i + 2
    if n.isdigit():
        j = i + 2
        while j < len(s) and s[j].isdigit():
            j += 1
        raw = s[i:j]
        if quoted:
            return raw, j
        name = raw[1:]
        return ('"${' + name + '}"' if len(name) > 1 else '"$' + name + '"'), j
    if n in IDENT0:
        j = i + 2
        while j < len(s) and s[j] in IDENT:
            j += 1
        raw = s[i:j]
        if quoted:
            return raw, j
        return quote_expansion(raw, raw[1:], s[j] if j < len(s) else "", for_in), j
    return None


def transform_text(s):
    out = []
    i = 0
    in_case_head = False
    in_case_pattern = False
    while i < len(s):
        c = s[i]
        if s.startswith("[[", i):
            end = s.find("]]", i + 2)
            if end >= 0:
                out.append(s[i:end+2])
                i = end + 2
                continue
        if s.startswith("case ", i) and (i == 0 or s[i-1] in "\n;"):
            in_case_head = True
        if in_case_head and s.startswith(" in", i):
            in_case_head = False
            in_case_pattern = True
        if in_case_pattern and c == ")":
            in_case_pattern = False
        if c == "'":
            end = s.find("'", i + 1)
            if end < 0:
                out.append(s[i:])
                break
            out.append(s[i:end+1])
            i = end + 1
            continue
        if c == '"':
            text, i = transform_double(s, i)
            out.append(text)
            continue
        if c == "\\" and i + 1 < len(s):
            out.append(s[i:i+2])
            i += 2
            continue
        if c == "`":
            end = s.find("`", i + 1)
            if end >= 0:
                inner = transform_text(s[i + 1:end])
                raw = "$(" + inner + ")"
                out.append(raw if in_assignment(out) or in_case_head else '"' + raw + '"')
                i = end + 1
                continue
        if c == "$" and not in_case_head and not in_case_pattern and not in_assignment(out):
            parsed = parse_expansion(s, i, quoted=False, for_in=(previous_word(out) == "in"))
            if parsed:
                text, i = parsed
                out.append(text)
                continue
        out.append(c)
        i += 1
    return "".join(out)


def syntax_color(text):
    # A lightweight highlighter compatible with the documented mode. It is not
    # byte-for-byte identical to upstream, but keeps shell comments and quoted
    # strings visually distinct for interactive use.
    text = re.sub(r"(^|\n)(#![^\n]*)", lambda m: m.group(1) + "\033[0;1;3;38;2;120;144;96m" + m.group(2) + "\033[m", text)
    text = re.sub(r"(\$[{]?[A-Za-z_@*0-9#!?$-][A-Za-z0-9_@*#\[\]-]*}?)", "\033[0;38;2;63;127;207m" + r"\1" + "\033[m", text)
    return text


def suggest_color(original, transformed, syntax=False):
    if original == transformed:
        return syntax_color(original) if syntax else original
    # Mark inserted double quotes/braces with the same background colors used by
    # Shellharden. This intentionally favors readable suggestions over a full
    # terminal diff engine.
    colored = transformed.replace('"', '\033[0;42m"\033[m')
    return syntax_color(colored) if syntax else colored


def read_inputs(files):
    if not files:
        return []
    data = []
    for path in files:
        if path == "":
            data.append(("", sys.stdin.read()))
        else:
            with open(path, "r", encoding="utf-8", errors="surrogateescape") as f:
                data.append((path, f.read()))
    return data


def main(argv):
    mode = "syntax-suggest"
    files = []
    parsing = True
    for arg in argv:
        if parsing and arg == "--":
            parsing = False
        elif parsing and arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            return 0
        elif parsing and arg == "--version":
            print("4.3.1")
            return 0
        elif parsing and arg in ("--suggest", "--syntax", "--syntax-suggest", "--transform", "--check", "--replace"):
            mode = arg[2:]
        elif parsing and arg.startswith("-"):
            sys.stderr.write(f"{arg}: No such option.\n")
            return 3
        else:
            files.append(arg)

    try:
        inputs = read_inputs(files)
    except OSError:
        return 1
    if not inputs:
        return 0

    if mode == "replace":
        status = 0
        for path, text in inputs:
            new = transform_text(text)
            if path:
                with open(path, "w", encoding="utf-8", errors="surrogateescape") as f:
                    f.write(new)
            elif new != text:
                status = 2
        return status

    changed = False
    chunks = []
    for _path, text in inputs:
        new = transform_text(text)
        changed = changed or (new != text)
        if mode == "check":
            continue
        if mode == "transform":
            chunks.append(new)
        elif mode == "syntax":
            chunks.append(syntax_color(text))
        elif mode == "suggest":
            chunks.append(suggest_color(text, new, syntax=False))
        else:
            chunks.append(suggest_color(text, new, syntax=True))
    if mode == "check":
        return 2 if changed else 0
    sys.stdout.write("".join(chunks))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
