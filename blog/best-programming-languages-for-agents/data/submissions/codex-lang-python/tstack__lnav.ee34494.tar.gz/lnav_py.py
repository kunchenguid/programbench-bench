#!/usr/bin/env python3
import datetime as _dt
import gzip
import json
import os
import re
import stat
import sys
from pathlib import Path

VERSION = "lnav 0.14.0-07efb63"

HELP = """usage: ./executable [options] [logfile1 logfile2 ...]

A log file viewer for the terminal that indexes log messages to
make it easier to navigate through files quickly.

Key Bindings
  ?    View/leave the online help text.
  q    Quit the program.

Options
  -h         Print this message, then exit.
  -H         Display the internal help text.

  -I dir     An additional configuration directory.
  -W         Print warnings related to lnav's configuration.
  -u         Update formats installed from git repositories.
  -d file    Write debug messages to the given file.
  -V         Print version information.

  -S,--since Only index log content since this time.
  -U,--until Only index log content until this time.
  -r         Recursively load files from the given directory hierarchies.
  -R         Load older rotated log files as well.
  -c cmd     Execute a command after the files have been loaded.
  -f file    Execute the commands in the given file.
  -e cmd     Execute a shell command-line.
  -t         Treat data piped into standard in as a log file.
  -n         Run without the curses UI. (headless mode)
  -N         Do not open the default syslog file if no files are given.
  -q         Do not print informational messages.

Optional arguments
  logfileN   The log files, directories, or remote paths to view.
             If a directory is given, all of the files in the
             directory will be loaded.

Management-Mode Options
  -i         Install the given format files and exit.  Pass 'extra'
             to install the default set of third-party formats.
  -m         Switch to the management command-line mode.  This mode
             is used to work with lnav's configuration.

Examples
 • To load and follow the syslog file:
     $ lnav                                  

 • To load all of the files in /var/log:
     $ lnav /var/log                         

 • To watch the output of make:
     $ lnav -e 'make -j4'                    

Paths
 • This binary:
    🧭 /workspace/executable
 • Format files are read from:
    📂 /etc/lnav
    📂 /usr/etc/lnav
 • Configuration, session, and format files are stored in:
    📂 /home/agent/.config/lnav

 • Local copies of remote files, files extracted from
   archives, execution output, and so on are stored in:
    📂 /tmp/lnav-user-1000-work

Documentation: https://docs.lnav.org
Contact
  💬 https://github.com/tstack/lnav/discussions
  📫 lnav@googlegroups.com
Version: lnav 0.14.0-07efb63
"""


class UsageError(Exception):
    def __init__(self, reason, code=109):
        super().__init__(reason)
        self.reason = reason
        self.code = code


def eprint(msg=""):
    print(msg, file=sys.stderr)


def parse_args(argv):
    opts = {
        "headless": False,
        "quiet": False,
        "timestamp_stdin": False,
        "no_default": False,
        "recursive": False,
        "rotated": False,
        "check": False,
        "management": False,
        "install": False,
        "commands": [],
        "exec_cmds": [],
        "files": [],
        "since": None,
        "until": None,
        "debug": None,
        "configs": [],
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a == "-H":
            opts["show_internal_help"] = True
        elif a == "-n":
            opts["headless"] = True
        elif a == "-q":
            opts["quiet"] = True
        elif a == "-t":
            opts["timestamp_stdin"] = True
        elif a == "-N":
            opts["no_default"] = True
        elif a == "-r":
            opts["recursive"] = True
        elif a == "-R":
            opts["rotated"] = True
        elif a == "-C":
            opts["check"] = True
        elif a == "-m":
            opts["management"] = True
        elif a == "-W":
            opts["warnings"] = True
        elif a == "-u":
            opts["update"] = True
        elif a in ("-I", "-d", "-c", "-f", "-e", "-S", "--since", "-U", "--until"):
            if i + 1 >= len(argv):
                label = {
                    "-I": "-I: 1 required TEXT:DIR missing",
                    "-d": "-d: 1 required FILE missing",
                    "-c": "-c: 1 required COMMAND missing",
                    "-f": "-f: 1 required FILE missing",
                    "-e": "-e: 1 required SHELL-CMD missing",
                    "-S": "-S: 1 required TIME missing",
                    "--since": "--since: 1 required TIME missing",
                    "-U": "-U: 1 required TIME missing",
                    "--until": "--until: 1 required TIME missing",
                }[a]
                raise UsageError(label, 114)
            val = argv[i + 1]
            i += 1
            if a == "-I":
                opts["configs"].append(val)
            elif a == "-d":
                opts["debug"] = val
            elif a == "-c":
                opts["commands"].append(val)
            elif a == "-f":
                opts["commands"].extend(read_command_file(val))
            elif a == "-e":
                opts["exec_cmds"].append(val)
            elif a in ("-S", "--since"):
                opts["since"] = val
            else:
                opts["until"] = val
        elif a == "-i":
            opts["install"] = True
        elif a.startswith("-"):
            raise UsageError(f"The following argument was not expected: {a}", 109)
        else:
            opts["files"].append(a)
        i += 1
    return opts


def read_command_file(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return [line.rstrip("\n") for line in f if line.strip()]
    except OSError as exc:
        eprint(f"  error: unable to open file: {path}")
        eprint(f" reason: {exc.strerror}")
        raise SystemExit(1)


def tty_error():
    eprint("  error: unable to display interactive text UI")
    eprint(" reason: stdout is not a TTY")
    eprint(" = help: pass the -n option to run lnav in headless mode or don't redirect stdout")


def command_errors(commands):
    for cmd in commands:
        text = cmd.strip()
        if not text or text in (":quit", "q", "quit"):
            continue
        if text.startswith(":"):
            eprint(f"  error: unknown command: “{text[1:]}”")
        else:
            eprint(f"  error: unknown command: “{text}”")


def iter_paths(paths, recursive=False, rotated=False):
    result = []
    for name in paths:
        p = Path(name)
        if p.is_dir():
            walker = p.rglob("*") if recursive else p.iterdir()
            for child in sorted(walker, key=lambda x: str(x)):
                if child.is_file():
                    result.append(child)
        elif p.exists():
            result.append(p)
        else:
            eprint(f"  error: unable to open file: {name}")
            eprint(" reason: No such file or directory")
            raise SystemExit(1)
        if rotated and p.exists():
            matches = sorted(p.parent.glob(p.name + ".*"))
            if not matches:
                full = str((Path.cwd() / p).resolve()) if not p.is_absolute() else str(p)
                eprint(f"  error: unable to open file: {full}.*")
                eprint(f" reason: failed to find path of “{full}.*”")
                eprint(" |        reason: No such file or directory")
                raise SystemExit(1)
            result.extend(m for m in matches if m.is_file())
    return result


def open_text(path):
    if str(path).endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return open(path, "r", encoding="utf-8", errors="replace")


def journal_time(obj):
    val = obj.get("__REALTIME_TIMESTAMP")
    if val is None:
        return None
    try:
        micros = int(val)
        dt = _dt.datetime.fromtimestamp(micros / 1_000_000, tz=_dt.timezone.utc)
        return dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    except Exception:
        return None


def level_name(raw):
    if raw is None:
        return "-"
    s = str(raw).lower()
    prio = {"0": "FATAL", "1": "ALERT", "2": "CRITICAL", "3": "ERROR", "4": "WARNING", "5": "NOTICE", "6": "INFO", "7": "DEBUG"}
    if s in prio:
        return prio[s]
    if s in ("warn", "warning"):
        return "WARNING"
    if s in ("err", "error"):
        return "ERROR"
    if s in ("info", "notice", "debug", "trace", "fatal", "critical", "alert"):
        return s.upper()
    return str(raw).upper()


def json_log_line(line):
    try:
        obj = json.loads(line)
    except Exception:
        return None
    if not isinstance(obj, dict):
        return None
    if "MESSAGE" in obj or "__REALTIME_TIMESTAMP" in obj:
        ts = journal_time(obj) or obj.get("_SOURCE_REALTIME_TIMESTAMP") or obj.get("time") or "-"
        lvl = level_name(obj.get("PRIORITY") or obj.get("level"))
        ident = obj.get("SYSLOG_IDENTIFIER") or "-"
        pid = obj.get("_PID")
        app = f"{ident}[{pid}]" if pid and ident != "-" else ident
        return f"{ts} - - {app} {lvl} {obj.get('MESSAGE', '-')}"
    if "time" in obj and "level" in obj:
        ts = str(obj.get("time"))
        if "T" not in ts and not ts[:4].isdigit():
            return f"[offset: 0] {line}"
        lvl = level_name(obj.get("level"))
        app = str(obj.get("app") or obj.get("logger") or obj.get("name") or "-")
        msg = obj.get("message", obj.get("msg", "-"))
        return f"[{lvl}] {ts} - -         {app:<12} {msg}"
    return None


def parse_time_value(value):
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%b %d %H:%M:%S"):
        try:
            dt = _dt.datetime.strptime(text[: len(_dt.datetime.now().strftime(fmt))], fmt)
            if fmt.startswith("%b"):
                dt = dt.replace(year=_dt.datetime.now().year)
            return dt.replace(tzinfo=_dt.timezone.utc)
        except Exception:
            pass
    try:
        dt = _dt.datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=_dt.timezone.utc)
        return dt.astimezone(_dt.timezone.utc)
    except Exception:
        return None


def line_time(line):
    try:
        obj = json.loads(line)
        if isinstance(obj, dict):
            jt = journal_time(obj)
            val = jt or obj.get("time") or obj.get("timestamp") or obj.get("@timestamp")
            return parse_time_value(val)
    except Exception:
        pass
    m = re.match(r"(\d{4}-\d\d-\d\d[ T]\d\d:\d\d:\d\d(?:\.\d+)?(?:Z|[+-]\d\d:?\d\d)?)", line)
    if m:
        return parse_time_value(m.group(1))
    m = re.match(r"([A-Z][a-z]{2}\s+\d{1,2}\s+\d\d:\d\d:\d\d)", line)
    if m:
        return parse_time_value(m.group(1))
    return None


def in_time_range(ts, since, until):
    if ts is None:
        return True
    if since is not None and ts <= since:
        return False
    if until is not None and ts > until:
        return False
    return True


def emit_lines(lines, from_file=False, since=None, until=None):
    first = True
    current_ts = None
    for raw in lines:
        line = raw.rstrip("\n")
        ts = line_time(line)
        if ts is not None:
            current_ts = ts
        if not in_time_range(current_ts, since, until):
            first = False
            continue
        rendered = json_log_line(line)
        if rendered is not None:
            print(rendered)
        else:
            print(line)
            if from_file and first and line and not line.lstrip().startswith("{"):
                print("▌ Line 0 metadata")
                print("   Invalid log message: line at offset 0 is not a JSON-line")
        first = False


def run_exec(cmd):
    import subprocess
    proc = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if proc.stdout:
        sys.stdout.write(proc.stdout)
    return proc.returncode


def timestamp_stdin():
    for line in sys.stdin:
        now = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f%z")
        print(f"{now} {line.rstrip()}")


def main(argv):
    try:
        opts = parse_args(argv)
    except UsageError as exc:
        eprint("  error: invalid command-line arguments")
        eprint(f" reason: {exc.reason}")
        return exc.code

    if opts.get("management"):
        eprint("  error: expecting an operation to perform")
        eprint(" = help: the available operations are:")
        eprint("          • apps: manage lnav apps")
        eprint("          • config: perform operations on the lnav configuration")
        eprint("          • format: perform operations on log file formats")
        eprint("          • piper: perform operations on piper storage")
        eprint("          • regex101: create and edit log message regular expressions using regex101.com")
        eprint("          • crash: manage crash logs")
        return 1

    if opts.get("check"):
        return 0

    if opts.get("install"):
        for path in opts["files"]:
            try:
                json.load(open(path, encoding="utf-8"))
            except Exception as exc:
                eprint(f"  error: unable to open configuration file: {path}")
                eprint(f" reason: JSON parsing failed -- {exc}")
                return 1
        return 0

    if opts.get("debug"):
        try:
            Path(opts["debug"]).write_text("", encoding="utf-8")
            os.chmod(opts["debug"], stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP)
        except OSError:
            pass

    if opts.get("show_internal_help") and not opts["headless"]:
        tty_error()
        return 1

    for cmd in opts["exec_cmds"]:
        run_exec(cmd)

    command_errors(opts["commands"])

    if opts["quiet"]:
        return 0

    if opts["timestamp_stdin"]:
        timestamp_stdin()
        return 0

    status = 0
    since = parse_time_value(opts.get("since"))
    until = parse_time_value(opts.get("until"))
    if opts["files"]:
        paths = iter_paths(opts["files"], opts["recursive"], opts["rotated"])
        for path in paths:
            try:
                with open_text(path) as f:
                    emit_lines(f, from_file=True, since=since, until=until)
            except OSError as exc:
                eprint(f"  error: unable to open file: {path}")
                eprint(f" reason: {exc.strerror}")
                status = 1
    elif not sys.stdin.isatty():
        emit_lines(sys.stdin, from_file=False, since=since, until=until)
    elif not opts["headless"] and not opts.get("no_default"):
        tty_error()
        status = 1

    if not opts["headless"] and not sys.stdout.isatty():
        tty_error()
        status = 1
    return status


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
