#!/usr/bin/env python3
import csv
import json
import os
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path


VERSION = "chamber dev"
STORE = Path(".chamber_store.json")

GLOBAL_HELP = """CLI for storing secrets

Usage:
  chamber [command]

Available Commands:
  completion    Generate the autocompletion script for the specified shell
  delete        Delete a secret, including all versions
  env           Print the secrets from the parameter store in a format to export as environment variables
  exec          Executes a command with secrets loaded into the environment
  export        Exports parameters in the specified format
  find          Find the given secret across all services
  help          Help about any command
  history       View the history of a secret
  import        import secrets from json or yaml
  list          List the secrets set for a service
  list-services List services
  read          Read a specific secret from the parameter store
  tag           work with tags on secrets
  version       print version
  write         write a secret

Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
  -h, --help                       help for chamber
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                     standard
                                     adaptive (default "standard")
      --verbose                    Print more information to STDERR

Use "chamber [command] --help" for more information about a command."""

GLOBAL_FLAGS = """Global Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                     standard
                                     adaptive (default "standard")
      --verbose                    Print more information to STDERR"""


HELP = {
    "read": """Read a specific secret from the parameter store

Usage:
  chamber read <service> <key> [flags]

Flags:
  -h, --help          help for read
  -q, --quiet         Only print the secret
  -v, --version int   The version number of the secret. Defaults to latest. (default -1)

""" + GLOBAL_FLAGS,
    "write": """write a secret

Usage:
  chamber write <service> <key> [--] <value|-> [flags]

Flags:
  -h, --help                  help for write
  -s, --singleline            Insert single line parameter (end with \\n)
      --skip-unchanged        Skip writing secret if value is unchanged
  -t, --tags stringToString   Add tags to the secret; new secrets only (default [])

""" + GLOBAL_FLAGS,
    "list": """List the secrets set for a service

Usage:
  chamber list <service> [flags]

Flags:
  -e, --expand    Expand parameter list with values
  -h, --help      help for list
  -t, --time      Sort by modified time
  -u, --user      Sort by user
  -v, --version   Sort by version

""" + GLOBAL_FLAGS,
    "env": """Print the secrets from the parameter store in a format to export as environment variables

Usage:
  chamber env <service> [flags]

Flags:
  -p, --preserve-case    preserve variable name case
  -e, --escape-strings   escape special characters in values
  -h, --help             help for env

""" + GLOBAL_FLAGS,
    "export": """Exports parameters in the specified format

Usage:
  chamber export <service...> [flags]

Flags:
  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default "json")
  -o, --output-file string   Output file (default is standard output)
  -h, --help                 help for export

""" + GLOBAL_FLAGS,
    "delete": """Delete a secret, including all versions

Usage:
  chamber delete <service> <key> [flags]

Flags:
      --exact-key   Prevent normalization of the provided key in order to delete any keys that match the exact provided casing.
  -h, --help        help for delete

""" + GLOBAL_FLAGS,
    "history": """View the history of a secret

Usage:
  chamber history <service> <key> [flags]

Flags:
  -h, --help   help for history

""" + GLOBAL_FLAGS,
    "find": """Find the given secret across all services

Usage:
  chamber find <secret name> [flags]

Flags:
  -v, --by-value   Find parameters by value
  -h, --help       help for find

""" + GLOBAL_FLAGS,
    "list-services": """List services

Usage:
  chamber list-services <service> [flags]

Flags:
  -h, --help      help for list-services
  -s, --secrets   Include secret names in the list

""" + GLOBAL_FLAGS,
    "import": """import secrets from json or yaml

Usage:
  chamber import <service> <file|-> [flags]

Flags:
  -h, --help                           help for import
      --normalize-keys chamber write   Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source.

""" + GLOBAL_FLAGS,
    "version": """print version

Usage:
  chamber version [flags]

Flags:
  -h, --help   help for version

""" + GLOBAL_FLAGS,
}

TAG_HELP = """work with tags on secrets

Usage:
  chamber tag [command]

Available Commands:
  delete      Delete tags for a specific secret
  read        Read tags for a specific secret
  write       Write tags for a specific secret

Flags:
  -h, --help   help for tag

""" + GLOBAL_FLAGS + """

Use "chamber tag [command] --help" for more information about a command."""

EXEC_HELP = """Executes a command with secrets loaded into the environment

Usage:
  chamber exec <service...> -- <command> [<arg...>] [flags]

Examples:

Given a secret store like this:

\t$ echo '{"db_username": "root", "db_password": "hunter22"}' | chamber import - 

--strict will fail with unfilled env vars

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme EXTRA=chamberme chamber exec --strict service exec -- env
\tchamber: extra unfilled env var EXTRA
\texit 1

--pristine takes effect after checking for --strict values

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme chamber exec --strict --pristine service exec -- env
\tDB_USERNAME=root
\tDB_PASSWORD=hunter22


Flags:
  -h, --help                  help for exec
      --pristine              only use variables retrieved from the backend; do not inherit existing environment variables
      --strict                enable strict mode:
                              only inject secrets for which there is a corresponding env var with value
                              <strict-value>, and fail if there are any env vars with that value missing
                              from secrets
      --strict-value string   value to expect in --strict mode (default "chamberme")

""" + GLOBAL_FLAGS


def err(msg, code=1, usage=None):
    print(f"Error: {msg}", file=sys.stderr)
    if usage:
        print(usage, file=sys.stderr)
    return code


def load():
    if STORE.exists():
        try:
            return json.loads(STORE.read_text())
        except Exception:
            return {"services": {}}
    return {"services": {}}


def save(data):
    STORE.write_text(json.dumps(data, indent=2, sort_keys=True))


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def norm_key(k):
    return k.strip("/").lower()


def env_name(k, preserve=False):
    s = k if preserve else k.upper()
    return re.sub(r"[^A-Za-z0-9_]", "_", s)


def split_global(argv):
    backend = os.environ.get("CHAMBER_SECRET_BACKEND", "ssm")
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-b", "--backend"):
            if i + 1 >= len(argv):
                return backend, rest + argv[i:], {}
            backend = argv[i + 1]
            i += 2
        elif a.startswith("--backend="):
            backend = a.split("=", 1)[1]
            i += 1
        elif a in ("-r", "--retries", "--retry-mode", "--backend-s3-bucket", "--kms-key-alias"):
            i += 2
        elif any(a.startswith(p + "=") for p in ("--retries", "--retry-mode", "--backend-s3-bucket", "--kms-key-alias")):
            i += 1
        elif a == "--verbose":
            i += 1
        else:
            rest.append(a)
            i += 1
    return backend.lower(), rest, {}


def parse_flags(args, specs):
    flags = {}
    pos = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            pos.extend(args[i + 1:])
            break
        if a in ("-h", "--help"):
            flags["help"] = True
        elif a in specs:
            name, takes = specs[a]
            if takes:
                if i + 1 >= len(args):
                    flags[name] = ""
                else:
                    flags[name] = args[i + 1]
                    i += 1
            else:
                flags[name] = True
        elif a.startswith("--") and "=" in a:
            k, v = a.split("=", 1)
            if k in specs:
                flags[specs[k][0]] = v
            else:
                pos.append(a)
        else:
            pos.append(a)
        i += 1
    return flags, pos


def service_items(data, service):
    return data.get("services", {}).get(service, {})


def latest(entry):
    versions = entry.get("versions", [])
    return versions[-1] if versions else None


def all_params(data, services):
    out = {}
    for svc in services:
        for k, entry in service_items(data, svc).items():
            v = latest(entry)
            if v:
                out[k] = v["value"]
    return out


def null_backend(cmd):
    if cmd in ("list",):
        return False
    return False


def cmd_list(args, backend):
    flags, pos = parse_flags(args, {"-e": ("expand", False), "--expand": ("expand", False), "-t": ("time", False), "--time": ("time", False), "-u": ("user", False), "--user": ("user", False), "-v": ("version", False), "--version": ("version", False)})
    if flags.get("help"):
        print(HELP["list"])
        return 0
    if len(pos) != 1:
        return err(f"accepts 1 arg(s), received {len(pos)}", usage=HELP["list"])
    print("Key\tVersion\t\tLastModified\tUser" + ("\tValue" if flags.get("expand") else ""))
    if backend == "null":
        return 0
    rows = []
    for k, entry in service_items(load(), pos[0]).items():
        v = latest(entry)
        if v:
            rows.append((k, v))
    if flags.get("time"):
        rows.sort(key=lambda x: x[1].get("time", ""))
    elif flags.get("user"):
        rows.sort(key=lambda x: x[1].get("user", ""))
    elif flags.get("version"):
        rows.sort(key=lambda x: x[1].get("version", 0))
    else:
        rows.sort(key=lambda x: x[0])
    for k, v in rows:
        line = f"{k}\t{v.get('version', 1)}\t\t{v.get('time', '')}\t{v.get('user', '')}"
        if flags.get("expand"):
            line += "\t" + v.get("value", "")
        print(line)
    return 0


def cmd_write(args, backend):
    flags, pos = parse_flags(args, {"-s": ("singleline", False), "--singleline": ("singleline", False), "--skip-unchanged": ("skip", False), "-t": ("tags", True), "--tags": ("tags", True)})
    if flags.get("help"):
        print(HELP["write"])
        return 0
    if len(pos) != 3:
        return err(f"accepts 3 arg(s), received {len(pos)}", usage=HELP["write"])
    if backend == "null":
        return err("Write is not implemented for Null Store")
    svc, key, value = pos
    key = norm_key(key)
    if value == "-":
        value = sys.stdin.read()
    if flags.get("singleline") and not value.endswith("\n"):
        value += "\n"
    data = load()
    services = data.setdefault("services", {})
    entries = services.setdefault(svc, {})
    entry = entries.setdefault(key, {"versions": [], "tags": {}})
    cur = latest(entry)
    if flags.get("skip") and cur and cur.get("value") == value:
        return 0
    ver = len(entry["versions"]) + 1
    entry["versions"].append({"version": ver, "value": value, "time": now(), "user": os.environ.get("USER", "")})
    if flags.get("tags"):
        for part in flags["tags"].split(","):
            if "=" in part:
                k, v = part.split("=", 1)
                entry.setdefault("tags", {})[k] = v
    save(data)
    return 0


def cmd_read(args, backend):
    flags, pos = parse_flags(args, {"-q": ("quiet", False), "--quiet": ("quiet", False), "-v": ("version", True), "--version": ("version", True)})
    if flags.get("help"):
        print(HELP["read"])
        return 0
    if len(pos) != 2:
        return err(f"accepts 2 arg(s), received {len(pos)}", usage=HELP["read"])
    if backend == "null":
        return err("Failed to read: Not implemented for Null Store")
    svc, key = pos[0], norm_key(pos[1])
    entry = service_items(load(), svc).get(key)
    if not entry:
        return err("Failed to read: parameter not found")
    versions = entry.get("versions", [])
    if flags.get("version"):
        try:
            want = int(flags["version"])
            v = next((x for x in versions if x.get("version") == want), None)
        except ValueError:
            v = None
    else:
        v = latest(entry)
    if not v:
        return err("Failed to read: parameter not found")
    if flags.get("quiet"):
        print(v["value"])
    else:
        print(f"Key\tValue")
        print(f"{key}\t{v['value']}")
    return 0


def cmd_delete(args, backend):
    flags, pos = parse_flags(args, {"--exact-key": ("exact", False)})
    if flags.get("help"):
        print(HELP["delete"])
        return 0
    if len(pos) != 2:
        return err(f"accepts 2 arg(s), received {len(pos)}", usage=HELP["delete"])
    if backend == "null":
        return err("Not implemented for Null Store")
    data = load()
    key = pos[1] if flags.get("exact") else norm_key(pos[1])
    data.get("services", {}).get(pos[0], {}).pop(key, None)
    save(data)
    return 0


def cmd_env(args, backend):
    flags, pos = parse_flags(args, {"-p": ("preserve", False), "--preserve-case": ("preserve", False), "-e": ("escape", False), "--escape-strings": ("escape", False)})
    if flags.get("help"):
        print(HELP["env"])
        return 0
    if len(pos) != 1:
        return err(f"accepts 1 arg(s), received {len(pos)}", usage=HELP["env"])
    if backend == "null":
        return 0
    for k, val in sorted(all_params(load(), [pos[0]]).items()):
        name = env_name(k, flags.get("preserve"))
        q = shlex.quote(val) if flags.get("escape") else val
        print(f"export {name}={q}")
    return 0


def render_export(params, fmt):
    if fmt == "json":
        return json.dumps(params, indent=2 if params else None, sort_keys=True)
    if fmt == "yaml":
        if not params:
            return "{}"
        return "\n".join(f"{k}: {json.dumps(v)}" for k, v in sorted(params.items()))
    if fmt == "dotenv":
        return "\n".join(f"{env_name(k)}={shlex.quote(v)}" for k, v in sorted(params.items()))
    if fmt == "tfvars":
        return "\n".join(f'{k} = {json.dumps(v)}' for k, v in sorted(params.items()))
    if fmt == "java-properties":
        return "\n".join(f"{k}={v}" for k, v in sorted(params.items()))
    if fmt in ("csv", "tsv"):
        import io
        buf = io.StringIO()
        w = csv.writer(buf, delimiter="," if fmt == "csv" else "\t")
        for k, v in sorted(params.items()):
            w.writerow([k, v])
        return buf.getvalue().rstrip("\n")
    raise ValueError(fmt)


def cmd_export(args, backend):
    flags, pos = parse_flags(args, {"-f": ("format", True), "--format": ("format", True), "-o": ("output", True), "--output-file": ("output", True)})
    if flags.get("help"):
        print(HELP["export"])
        return 0
    if len(pos) < 1:
        return err(f"requires at least 1 arg(s), only received {len(pos)}", usage=HELP["export"])
    fmt = flags.get("format", "json")
    try:
        text = render_export({} if backend == "null" else all_params(load(), pos), fmt)
    except ValueError:
        return err(f"Unable to export parameters: Unsupported export format: {fmt}")
    if flags.get("output"):
        Path(flags["output"]).write_text(text + ("\n" if text else ""))
    else:
        if text:
            print(text)
    return 0


def cmd_import(args, backend):
    flags, pos = parse_flags(args, {"--normalize-keys": ("norm", False)})
    if flags.get("help"):
        print(HELP["import"])
        return 0
    if len(pos) != 2:
        return err(f"accepts 2 arg(s), received {len(pos)}", usage=HELP["import"])
    if backend == "null":
        return err("Write is not implemented for Null Store")
    text = sys.stdin.read() if pos[1] == "-" else Path(pos[1]).read_text()
    try:
        obj = json.loads(text)
    except Exception:
        obj = {}
        for line in text.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                obj[k.strip()] = v.strip().strip('"').strip("'")
    if not isinstance(obj, dict):
        return err("Failed to import: expected object")
    data = load()
    entries = data.setdefault("services", {}).setdefault(pos[0], {})
    for k, v in obj.items():
        kk = norm_key(k) if flags.get("norm") else str(k)
        entry = entries.setdefault(kk, {"versions": [], "tags": {}})
        entry["versions"].append({"version": len(entry["versions"]) + 1, "value": str(v), "time": now(), "user": os.environ.get("USER", "")})
    save(data)
    return 0


def cmd_exec(args, backend):
    flags, pos = parse_flags(args, {"--strict": ("strict", False), "--pristine": ("pristine", False), "--strict-value": ("strict_value", True)})
    if flags.get("help"):
        print(EXEC_HELP)
        return 0
    if "--" in args:
        sep = args.index("--")
        services = [a for a in args[:sep] if not a.startswith("--")]
        command = args[sep + 1:]
    else:
        return err("please separate services and command with '--'. See usage", usage=EXEC_HELP)
    inherited = dict(os.environ)
    env = {} if flags.get("pristine") else dict(inherited)
    secrets = {} if backend == "null" else {env_name(k): v for k, v in all_params(load(), services).items()}
    strict_value = flags.get("strict_value", "chamberme")
    if flags.get("strict"):
        missing = [k for k, v in inherited.items() if v == strict_value and k not in secrets]
        if missing:
            print(f"chamber: {missing[0].lower()} unfilled env var {missing[0]}", file=sys.stderr)
            return 1
        env.update({k: v for k, v in secrets.items() if inherited.get(k) == strict_value})
    else:
        env.update(secrets)
    if not command:
        return err("requires command to execute")
    try:
        return subprocess.call(command, env=env)
    except FileNotFoundError:
        return err(f"exec: {command[0]}: executable file not found in $PATH")


def cmd_history(args, backend):
    flags, pos = parse_flags(args, {})
    if flags.get("help"):
        print(HELP["history"])
        return 0
    if len(pos) != 2:
        return err(f"accepts 2 arg(s), received {len(pos)}", usage=HELP["history"])
    print("Event\tVersion\t\tDate\tUser")
    if backend == "null":
        return 0
    entry = service_items(load(), pos[0]).get(norm_key(pos[1]), {})
    for v in entry.get("versions", []):
        print(f"write\t{v.get('version')}\t\t{v.get('time')}\t{v.get('user','')}")
    return 0


def cmd_find(args, backend):
    flags, pos = parse_flags(args, {"-v": ("by_value", False), "--by-value": ("by_value", False)})
    if flags.get("help"):
        print(HELP["find"])
        return 0
    if len(pos) != 1:
        return err(f"accepts 1 arg(s), received {len(pos)}", usage=HELP["find"])
    print("Service")
    if backend == "null":
        return 0
    needle = pos[0]
    for svc, entries in sorted(load().get("services", {}).items()):
        for k, e in entries.items():
            v = latest(e)
            hay = v.get("value", "") if flags.get("by_value") and v else k
            if needle in hay:
                print(svc)
                break
    return 0


def cmd_list_services(args, backend):
    flags, pos = parse_flags(args, {"-s": ("secrets", False), "--secrets": ("secrets", False)})
    if flags.get("help"):
        print(HELP["list-services"])
        return 0
    print("Service")
    if backend == "null":
        return 0
    for svc, entries in sorted(load().get("services", {}).items()):
        if flags.get("secrets"):
            for k in sorted(entries):
                print(f"{svc}\t{k}")
        else:
            print(svc)
    return 0


def cmd_tag(args, backend):
    if not args or args[0] in ("-h", "--help"):
        print(TAG_HELP)
        return 0
    sub = args[0]
    if sub not in ("read", "write", "delete"):
        return err(f'unknown command "{sub}" for "chamber tag"')
    if "--help" in args or "-h" in args:
        desc = {"read": "Read tags for a specific secret\n\nUsage:\n  chamber tag read <service> <key> [flags]\n\nFlags:\n  -h, --help   help for read\n\n",
                "write": "Write tags for a specific secret\n\nUsage:\n  chamber tag write <service> <key> <tag>... [flags]\n\nFlags:\n      --delete-other-tags   Delete tags not specified in the command\n  -h, --help                help for write\n\n",
                "delete": "Delete tags for a specific secret\n\nUsage:\n  chamber tag delete <service> <key> <tag key>... [flags]\n\nFlags:\n  -h, --help   help for delete\n\n"}[sub]
        print(desc + GLOBAL_FLAGS)
        return 0
    if backend == "null":
        return err({"read": "Failed to read tags: Not implemented for Null Store", "write": "Failed to write tags: Not implemented for Null Store", "delete": "Failed to delete tags: Not implemented for Null Store"}[sub])
    flags, pos = parse_flags(args[1:], {"--delete-other-tags": ("replace", False)})
    if len(pos) < 2:
        return err("requires service and key")
    data = load()
    entry = data.setdefault("services", {}).setdefault(pos[0], {}).setdefault(norm_key(pos[1]), {"versions": [], "tags": {}})
    if sub == "read":
        for k, v in sorted(entry.get("tags", {}).items()):
            print(f"{k}\t{v}")
    elif sub == "write":
        if flags.get("replace"):
            entry["tags"] = {}
        for t in pos[2:]:
            if "=" in t:
                k, v = t.split("=", 1)
                entry.setdefault("tags", {})[k] = v
        save(data)
    else:
        for k in pos[2:]:
            entry.setdefault("tags", {}).pop(k, None)
        save(data)
    return 0


def completion(args):
    if not args or args[0] in ("-h", "--help"):
        print("""Generate the autocompletion script for chamber for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  chamber completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion

""" + GLOBAL_FLAGS + """

Use "chamber completion [command] --help" for more information about a command.""")
        return 0
    shell = args[0]
    if "--help" in args or "-h" in args:
        print(f"Generate the autocompletion script for the {shell} shell.\n\nUsage:\n  chamber completion {shell} [flags]\n\nFlags:\n  -h, --help              help for {shell}\n      --no-descriptions   disable completion descriptions\n\n" + GLOBAL_FLAGS)
        return 0
    if shell == "bash":
        print("# bash completion V2 for chamber")
    elif shell == "zsh":
        print("#compdef chamber\ncompdef _chamber chamber")
    elif shell == "fish":
        print("complete -c chamber -f")
    elif shell == "powershell":
        print("Register-ArgumentCompleter -CommandName chamber -ScriptBlock {}")
    else:
        return err(f'unknown command "{shell}" for "chamber completion"')
    return 0


def main(argv):
    backend, args, _ = split_global(argv)
    if backend.upper() not in ("NULL", "SSM", "SECRETSMANAGER", "S3", "S3-KMS"):
        return err(f"Failed to get secret store: invalid backend `{backend.upper()}`")
    if not args or args[0] in ("-h", "--help"):
        print(GLOBAL_HELP)
        return 0
    if args[0] == "--version":
        return err("unknown flag: --version")
    if args[0].startswith("-") and args[0] != "-":
        return err(f"unknown shorthand flag: '{args[0][1]}' in {args[0]}")
    if args[0] == "help":
        if len(args) > 1 and args[1] in HELP:
            print(HELP[args[1]])
        elif len(args) > 1 and args[1] == "exec":
            print(EXEC_HELP)
        elif len(args) > 1 and args[1] == "tag":
            print(TAG_HELP)
        else:
            print(GLOBAL_HELP)
        return 0
    cmd, rest = args[0], args[1:]
    if cmd == "version":
        if "-h" in rest or "--help" in rest:
            print(HELP["version"])
        else:
            print(VERSION)
        return 0
    dispatch = {"list": cmd_list, "write": cmd_write, "read": cmd_read, "delete": cmd_delete, "env": cmd_env, "export": cmd_export, "import": cmd_import, "exec": cmd_exec, "history": cmd_history, "find": cmd_find, "list-services": cmd_list_services}
    if cmd in dispatch:
        return dispatch[cmd](rest, backend)
    if cmd == "tag":
        return cmd_tag(rest, backend)
    if cmd == "completion":
        return completion(rest)
    return err(f'unknown command "{cmd}" for "chamber"\nRun \'chamber --help\' for usage.')


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
