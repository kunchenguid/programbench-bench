#!/usr/bin/env python3
import argparse
import glob
import html
import os
import sys


VERSION = "svgbob 0.7.6"

HELP = """svgbob 0.7.6
SvgBobRus is an ascii to svg converter

USAGE:
    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -s               parse an inline string
    -V, --version    Prints version information

OPTIONS:
        --background <background>        backdrop background will be filled with this color (default: 'white')
        --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')
        --font-family <font-family>      text will be rendered with this font (default: 'arial')
        --font-size <font-size>          text will be rendered with this font size (default: 14)
    -o, --output <output>                where to write svg output [default: STDOUT]
        --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor
                                         (default: 1)
        --stroke-color <stroke-color>    stroke color for all lines (default: 'black')
        --stroke-width <stroke-width>    stroke width for all lines (default: 2)

ARGS:
    <input>    svgbob text file or inline string to parse [default: STDIN]

SUBCOMMANDS:
    build    Batch convert files to svg.
    help     Prints this message or the help of the given subcommand(s)
"""

BUILD_HELP = """executable-build 0.0.1
Batch convert files to svg.

USAGE:
    executable build [OPTIONS]

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -i, --input <input>      set input file pattern like: *.bob or dir/*.bob
    -o, --outdir <outdir>    set dir of svg files
"""


def fmt_num(n):
    if isinstance(n, float) and n.is_integer():
        return str(int(n))
    return str(n)


class Opts:
    def __init__(self, ns):
        self.background = ns.background
        self.fill = ns.fill_color
        self.stroke = ns.stroke_color
        self.font_family = ns.font_family
        self.font_size = ns.font_size
        self.stroke_width = ns.stroke_width
        self.scale = ns.scale


def style(opts):
    return f""".svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {{
  stroke: {opts.stroke};
  stroke-width: {opts.stroke_width};
  stroke-opacity: 1;
  fill-opacity: 1;
  stroke-linecap: round;
  stroke-linejoin: miter;
}}

.svgbob text {{
  white-space: pre;
  fill: {opts.stroke};
  font-family: {opts.font_family};
  font-size: {opts.font_size}px;
}}

.svgbob rect.backdrop {{
  stroke: none;
  fill: {opts.background};
}}

.svgbob .broken {{
  stroke-dasharray: 8;
}}

.svgbob .filled {{
  fill: {opts.fill};
}}

.svgbob .bg_filled {{
  fill: {opts.background};
  stroke-width: 1;
}}

.svgbob .nofill {{
  fill: {opts.background};
}}

.svgbob .end_marked_arrow {{
  marker-end: url(#arrow);
}}

.svgbob .start_marked_arrow {{
  marker-start: url(#arrow);
}}

.svgbob .end_marked_diamond {{
  marker-end: url(#diamond);
}}

.svgbob .start_marked_diamond {{
  marker-start: url(#diamond);
}}

.svgbob .end_marked_circle {{
  marker-end: url(#circle);
}}

.svgbob .start_marked_circle {{
  marker-start: url(#circle);
}}

.svgbob .end_marked_open_circle {{
  marker-end: url(#open_circle);
}}

.svgbob .start_marked_open_circle {{
  marker-start: url(#open_circle);
}}

.svgbob .end_marked_big_open_circle {{
  marker-end: url(#big_open_circle);
}}

.svgbob .start_marked_big_open_circle {{
  marker-start: url(#big_open_circle);
}}

"""


DEFS = """  <defs>
    <marker id="arrow" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,0 0,4 4,2 0,0"></polygon>
    </marker>
    <marker id="diamond" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,2 2,0 4,2 2,4 0,2"></polygon>
    </marker>
    <marker id="circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="filled"></circle>
    </marker>
    <marker id="open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="bg_filled"></circle>
    </marker>
    <marker id="big_open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="3" class="bg_filled"></circle>
    </marker>
  </defs>"""


def split_lines(src):
    lines = src.splitlines()
    if not lines:
        lines = [""]
    return [line.rstrip() for line in lines]


def get(grid, r, c):
    if 0 <= r < len(grid) and 0 <= c < len(grid[r]):
        return grid[r][c]
    return " "


def occupied_set(rows, cols):
    return [[False for _ in range(cols)] for _ in range(rows)]


def mark(occ, r1, c1, r2, c2):
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            if 0 <= r < len(occ) and 0 <= c < len(occ[r]):
                occ[r][c] = True


def mark_rect_border(occ, r1, c1, r2, c2):
    for c in range(c1, c2 + 1):
        if 0 <= r1 < len(occ) and 0 <= c < len(occ[r1]):
            occ[r1][c] = True
        if 0 <= r2 < len(occ) and 0 <= c < len(occ[r2]):
            occ[r2][c] = True
    for r in range(r1, r2 + 1):
        if 0 <= r < len(occ):
            if 0 <= c1 < len(occ[r]):
                occ[r][c1] = True
            if 0 <= c2 < len(occ[r]):
                occ[r][c2] = True


def sx(x, s):
    return fmt_num(x * s)


def line_el(x1, y1, x2, y2, cls, s, indent="  "):
    return f'{indent}<line x1="{sx(x1, s)}" y1="{sx(y1, s)}" x2="{sx(x2, s)}" y2="{sx(y2, s)}" class="{cls}"></line>'


def arrow_poly(direction, x, y, s):
    if direction == ">":
        pts = [(x - 8, y - 4), (x, y), (x - 8, y + 4)]
    else:
        pts = [(x + 8, y - 4), (x, y), (x + 8, y + 4)]
    return "  <polygon points=\"" + " ".join(f"{sx(a, s)},{sx(b, s)}" for a, b in pts) + "\" class=\"filled\"></polygon>"


def detect_rects(lines, occ, s):
    out = []
    rows = len(lines)
    for r1 in range(rows):
        line = lines[r1]
        for c1, ch in enumerate(line):
            if ch not in "+.":
                continue
            for c2 in range(c1 + 2, len(line)):
                if get(lines, r1, c2) not in ("+", "."):
                    continue
                if not all(get(lines, r1, c) in "-=." for c in range(c1 + 1, c2)):
                    continue
                for r2 in range(r1 + 2, rows):
                    b1 = get(lines, r2, c1)
                    b2 = get(lines, r2, c2)
                    if b1 not in ("+", "`") or b2 not in ("+", "`"):
                        continue
                    if not all(get(lines, r2, c) in "-=.`" for c in range(c1 + 1, c2)):
                        continue
                    if all(get(lines, r, c1) == "|" and get(lines, r, c2) == "|" for r in range(r1 + 1, r2)):
                        x = c1 * 8 + 4
                        y = r1 * 16 + 8
                        w = (c2 - c1) * 8
                        h = (r2 - r1) * 16
                        out.append((r1, c1, f'  <rect x="{sx(x, s)}" y="{sx(y, s)}" width="{sx(w, s)}" height="{sx(h, s)}" class="solid nofill" rx="0"></rect>'))
                        mark_rect_border(occ, r1, c1, r2, c2)
                        break
    return out


def render_body(lines, opts):
    rows = max(1, len(lines))
    cols = max([len(x) for x in lines] + [1])
    occ = occupied_set(rows, cols)
    elems = []
    elems += detect_rects(lines, occ, opts.scale)

    # Horizontal strokes and arrowheads.
    for r, line in enumerate(lines):
        c = 0
        while c < len(line):
            if occ[r][c]:
                c += 1
                continue
            if line[c] in "-=":
                start = c
                while c < len(line) and line[c] in "-=" and not occ[r][c]:
                    c += 1
                end = c - 1
                y = r * 16 + 8
                cls = "solid" if line[start] == "-" else "broken"
                x1 = start * 8
                if get(lines, r, start - 1) == "o":
                    x1 = (start + 1) * 8
                    elems.append((r, start - 1, line_el(x1, y, (start - 1) * 8 + 4, y, cls + " end_marked_open_circle", opts.scale)))
                    occ[r][start - 1] = True
                elems.append((r, start, line_el(x1, y, (end + 1) * 8, y, cls, opts.scale)))
                mark(occ, r, start, r, end)
            else:
                c += 1

    # Vertical strokes.
    for c in range(cols):
        r = 0
        while r < rows:
            if get(lines, r, c) == "|" and not occ[r][c]:
                start = r
                while r < rows and get(lines, r, c) == "|" and not occ[r][c]:
                    r += 1
                end = r - 1
                y1 = start * 16
                y2 = (end + 1) * 16
                if get(lines, start - 1, c) in "+.": y1 = (start - 1) * 16 + 8
                if get(lines, end + 1, c) in "+`": y2 = (end + 1) * 16 + 8
                elems.append((start, c, line_el(c * 8 + 4, y1, c * 8 + 4, y2, "solid", opts.scale)))
                mark(occ, start, c, end, c)
            else:
                r += 1

    # Diagonal strokes.
    for r, line in enumerate(lines):
        for c, ch in enumerate(line):
            if occ[r][c] or ch not in "/\\":
                continue
            if ch == "/":
                elems.append((r, c, line_el(c * 8 + 8, r * 16, c * 8, r * 16 + 16, "solid", opts.scale, "    ")))
            else:
                elems.append((r, c, line_el(c * 8, r * 16, c * 8 + 8, r * 16 + 16, "solid", opts.scale, "    ")))
            occ[r][c] = True

    # Arrow heads and open circles, handled after lines so text does not claim them.
    for r, line in enumerate(lines):
        for c, ch in enumerate(line):
            if occ[r][c]:
                continue
            y = r * 16 + 8
            if ch in "<>" and (get(lines, r, c - 1) in "-=" or get(lines, r, c + 1) in "-="):
                tip = (c + 1) * 8 if ch == ">" else c * 8
                elems.append((r, c, arrow_poly(ch, tip, y, opts.scale)))
                occ[r][c] = True
            elif ch == "o" and (get(lines, r, c - 1) in "-=|" or get(lines, r, c + 1) in "-=|"):
                elems.append((r, c, f'  <circle cx="{sx(c * 8 + 4, opts.scale)}" cy="{sx(y, opts.scale)}" r="{sx(3, opts.scale)}" class="bg_filled"></circle>'))
                occ[r][c] = True

    # Text runs.
    for r, line in enumerate(lines):
        c = 0
        while c < len(line):
            while c < len(line) and (occ[r][c] or line[c] == " "):
                c += 1
            if c >= len(line):
                break
            start = c
            buf = []
            while c < len(line) and not occ[r][c] and line[c] != " ":
                buf.append(line[c])
                c += 1
            text = html.escape("".join(buf), quote=False)
            elems.append((r, start, f'  <text x="{sx(start * 8 + 2, opts.scale)}" y="{sx(r * 16 + 12, opts.scale)}" >{text}</text>'))

    elems.sort(key=lambda x: (x[0], x[1]))
    return [x[2] for x in elems]


def render(src, opts):
    lines = split_lines(src)
    cols = max([len(x) for x in lines] + [1])
    rows = max(1, len(lines))
    width = (cols + 1) * 8 * opts.scale
    height = (rows + 1) * 16 * opts.scale
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{fmt_num(width)}" height="{fmt_num(height)}" class="svgbob">',
        f"  <style>{style(opts)}</style>",
        DEFS,
        f'  <rect class="backdrop" x="0" y="0" width="{fmt_num(width)}" height="{fmt_num(height)}"></rect>',
    ]
    parts.extend(render_body(lines, opts))
    parts.append("</svg>")
    return "\n".join(parts) + "\n"


def add_common(parser):
    parser.add_argument("--background", default="white")
    parser.add_argument("--fill-color", default="black")
    parser.add_argument("--font-family", default="Iosevka Fixed, monospace")
    parser.add_argument("--font-size", default="14")
    parser.add_argument("-o", "--output", default=None)
    parser.add_argument("--scale", default="1")
    parser.add_argument("--stroke-color", default="black")
    parser.add_argument("--stroke-width", default="2")
    parser.add_argument("-s", action="store_true", dest="inline")
    parser.add_argument("input", nargs="?")


def parse_args(argv):
    if len(argv) > 1 and argv[1] in ("help", "--help", "-h"):
        print(HELP, end="")
        raise SystemExit(0)
    if len(argv) > 1 and argv[1] == "build":
        if any(x in ("--help", "-h") for x in argv[2:]):
            print(BUILD_HELP, end="")
            raise SystemExit(0)
        p = argparse.ArgumentParser(prog="executable build", description="Batch convert files to svg.")
        p.add_argument("-i", "--input")
        p.add_argument("-o", "--outdir")
        p.add_argument("-V", "--version", action="store_true")
        ns = p.parse_args(argv[2:])
        ns.command = "build"
        return ns
    p = argparse.ArgumentParser(prog="executable", description="SvgBobRus is an ascii to svg converter")
    p.add_argument("-V", "--version", action="store_true")
    add_common(p)
    ns = p.parse_args(argv[1:])
    ns.command = "main"
    return ns


def read_input(ns):
    if ns.input is None:
        return sys.stdin.read()
    if ns.inline:
        return ns.input
    with open(ns.input, "r", encoding="utf-8") as f:
        return f.read()


def main(argv=None):
    argv = argv or sys.argv
    ns = parse_args(argv)
    if getattr(ns, "version", False):
        print(VERSION if ns.command == "main" else "executable-build 0.0.1")
        return 0
    if ns.command == "build":
        pattern = ns.input or "*.bob"
        outdir = ns.outdir or "."
        os.makedirs(outdir, exist_ok=True)
        dummy = argparse.Namespace(background="white", fill_color="black", stroke_color="black",
                                   font_family="Iosevka Fixed, monospace", font_size="14",
                                   stroke_width="2", scale=1)
        opts = Opts(dummy)
        for path in glob.glob(pattern):
            with open(path, "r", encoding="utf-8") as f:
                svg = render(f.read(), opts)
            name = os.path.splitext(os.path.basename(path))[0] + ".svg"
            target = os.path.join(outdir, name)
            with open(target, "w", encoding="utf-8") as f:
                f.write(svg.rstrip("\n"))
            print(f"{path} => {target}")
        return 0
    opts = Opts(ns)
    try:
        opts.scale = float(opts.scale)
        if opts.scale.is_integer():
            opts.scale = int(opts.scale)
    except Exception:
        opts.scale = 1
    out = render(read_input(ns), opts)
    if ns.output:
        with open(ns.output, "w", encoding="utf-8") as f:
            f.write(out.rstrip("\n"))
    else:
        sys.stdout.write(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
