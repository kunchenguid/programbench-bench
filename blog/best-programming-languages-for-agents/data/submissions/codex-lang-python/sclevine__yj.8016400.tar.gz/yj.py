#!/usr/bin/env python3
import argparse
import datetime as _dt
import html
import json
import math
import re
import sys

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None

HELP = """Usage: ./executable [-][ytjcrneikhv]

Convert between YAML, TOML, JSON, and HCL.
Preserves map order.

-x[x]  Convert using stdin. Valid options:
          -yj, -y = YAML to JSON (default)
          -yy     = YAML to YAML
          -yt     = YAML to TOML
          -yc     = YAML to HCL
          -tj, -t = TOML to JSON
          -ty     = TOML to YAML
          -tt     = TOML to TOML
          -tc     = TOML to HCL
          -jj     = JSON to JSON
          -jy, -r = JSON to YAML
          -jt     = JSON to TOML
          -jc     = JSON to HCL
          -cy     = HCL to YAML
          -ct     = HCL to TOML
          -cj, -c = HCL to JSON
          -cc     = HCL to HCL
-n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)
-e     Escape HTML (JSON out only)
-i     Indent output (JSON or TOML out only)
-k     Attempt to parse keys as objects or numeric types (YAML out only)
-h     Show this help message
-v     Show version"""


class Dumper(yaml.SafeDumper if yaml else object):
    def increase_indent(self, flow=False, indentless=False):
        return super().increase_indent(flow, False)


if yaml:
    def _repr_str(dumper, data):
        ambiguous = re.fullmatch(r"[-+]?\d+(?:\.\d+)?", data) or data in {
            "y", "Y", "yes", "Yes", "YES", "n", "N", "no", "No", "NO",
            "true", "True", "TRUE", "false", "False", "FALSE",
            "on", "On", "ON", "off", "Off", "OFF", "null", "Null", "NULL", "~",
        }
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style='"' if ambiguous else None)

    def _repr_dt(dumper, data):
        if isinstance(data, _dt.date) and not isinstance(data, _dt.datetime):
            data = _dt.datetime(data.year, data.month, data.day)
        if data.tzinfo is None:
            s = data.strftime("%Y-%m-%dT%H:%M:%SZ")
        else:
            s = data.isoformat().replace("+00:00", "Z")
        return dumper.represent_scalar("tag:yaml.org,2002:str", s, style=None)

    def _repr_odict(dumper, data):
        return dumper.represent_dict(data.items())

    Dumper.add_representer(_dt.date, _repr_dt)
    Dumper.add_representer(_dt.datetime, _repr_dt)
    Dumper.add_representer(str, _repr_str)


def parse_flags(argv):
    chars = []
    for a in argv:
        if a.startswith("-"):
            chars.extend(list(a.lstrip("-")))
        else:
            chars.extend(list(a))
    allowed = set("ytjcrneikhv")
    bad = [c for c in chars if c not in allowed]
    show_help = "h" in chars or not chars and False
    if "v" in chars and not bad and "h" not in chars:
        print("v0.0.0")
        sys.exit(0)
    if show_help:
        print(HELP)
        if bad:
            print()
            print("Error: invalid flags specified: " + " ".join(bad))
            sys.exit(1)
        sys.exit(0)
    if bad:
        print(HELP, file=sys.stderr)
        print(file=sys.stderr)
        print("Error: invalid flags specified: " + " ".join(bad), file=sys.stderr)
        sys.exit(1)
    conv = [c for c in chars if c in "ytjcr"]
    if not conv:
        inf, outf = "y", "j"
    elif len(conv) == 1:
        c = conv[0]
        if c == "r":
            inf, outf = "j", "y"
        else:
            inf, outf = c, "j"
    else:
        inf, outf = conv[0], conv[1]
        if inf == "r":
            inf = "j"
        if outf == "r":
            outf = "y"
    return inf, outf, set(chars)


def convert_specials(obj, stringify=True):
    if isinstance(obj, dict):
        return {k: convert_specials(v, stringify) for k, v in obj.items()}
    if isinstance(obj, list):
        return [convert_specials(v, stringify) for v in obj]
    if isinstance(obj, float) and (math.isinf(obj) or math.isnan(obj)):
        if stringify:
            if math.isnan(obj):
                return "NaN"
            return "Infinity" if obj > 0 else "-Infinity"
        if math.isnan(obj):
            return None
        return sys.float_info.max if obj > 0 else -sys.float_info.max
    return obj


def stringify_dates(obj):
    if isinstance(obj, dict):
        return {k: stringify_dates(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [stringify_dates(v) for v in obj]
    if isinstance(obj, _dt.datetime):
        return obj.strftime("%Y-%m-%dT%H:%M:%SZ") if obj.tzinfo is None else obj.isoformat().replace("+00:00", "Z")
    if isinstance(obj, _dt.date):
        return _dt.datetime(obj.year, obj.month, obj.day).strftime("%Y-%m-%dT%H:%M:%SZ")
    return obj


def parse_input(fmt, text):
    if fmt == "j":
        return json.loads(text)
    if fmt == "y":
        return yaml.safe_load(text) if text.strip() else None
    if fmt == "t":
        return parse_toml(text)
    if fmt == "c":
        return HCLParser(text).parse()
    raise ValueError(fmt)


def json_dumps(obj, indent=False, escape_html=False):
    obj = stringify_dates(obj)
    s = json.dumps(obj, ensure_ascii=False, separators=(",", ":") if not indent else None, indent=2 if indent else None)
    if escape_html:
        s = s.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    return s


def yaml_dumps(obj, parse_keys=False):
    def amb(s):
        return re.fullmatch(r"[-+]?\d+(?:\.\d+)?", s) or s in {
            "y", "Y", "yes", "Yes", "YES", "n", "N", "no", "No", "NO",
            "true", "True", "TRUE", "false", "False", "FALSE",
            "on", "On", "ON", "off", "Off", "OFF", "null", "Null", "NULL", "~",
        }

    def scalar(v):
        if isinstance(v, bool):
            return "true" if v else "false"
        if v is None:
            return "null"
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return toml_val(v)
        if isinstance(v, (_dt.datetime, _dt.date)):
            return toml_val(v)
        s = str(v)
        return json.dumps(s, ensure_ascii=False) if amb(s) or "\n" in s else s

    def key(k):
        if not isinstance(k, str):
            return scalar(k)
        if parse_keys and (re.fullmatch(r"[-+]?\d+(?:\.\d+)?", k) or k in ("true", "false", "null", "~")):
            return k
        return json.dumps(k, ensure_ascii=False) if amb(k) else k

    def emit(v, ind=0):
        sp = " " * ind
        lines = []
        if isinstance(v, dict):
            for k, val in v.items():
                kk = key(k)
                if isinstance(val, dict):
                    lines.append(f"{sp}{kk}:")
                    lines.extend(emit(val, ind + 2))
                elif isinstance(val, list):
                    lines.append(f"{sp}{kk}:")
                    lines.extend(emit(val, ind + 2))
                else:
                    lines.append(f"{sp}{kk}: {scalar(val)}")
        elif isinstance(v, list):
            for item in v:
                if isinstance(item, (dict, list)):
                    if isinstance(item, dict) and item:
                        first = True
                        for k, val in item.items():
                            kk = key(k)
                            if first:
                                if isinstance(val, (dict, list)):
                                    lines.append(f"{sp}- {kk}:")
                                    lines.extend(emit(val, ind + 4))
                                else:
                                    lines.append(f"{sp}- {kk}: {scalar(val)}")
                                first = False
                            else:
                                if isinstance(val, (dict, list)):
                                    lines.append(f"{sp}  {kk}:")
                                    lines.extend(emit(val, ind + 4))
                                else:
                                    lines.append(f"{sp}  {kk}: {scalar(val)}")
                    else:
                        lines.append(f"{sp}-")
                        lines.extend(emit(item, ind + 2))
                else:
                    lines.append(f"{sp}- {scalar(item)}")
        else:
            lines.append(f"{sp}{scalar(v)}")
        return lines

    return "\n".join(emit(obj))


def toml_key(k):
    s = str(k)
    if re.fullmatch(r"[A-Za-z0-9_-]+", s):
        return s
    return json.dumps(s, ensure_ascii=False)


def toml_val(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int) and not isinstance(v, bool):
        return str(v)
    if isinstance(v, float):
        if math.isnan(v):
            return "nan"
        if math.isinf(v):
            return "inf" if v > 0 else "-inf"
        return repr(v)
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False)
    if isinstance(v, _dt.datetime):
        return v.strftime("%Y-%m-%dT%H:%M:%SZ") if v.tzinfo is None else v.isoformat().replace("+00:00", "Z")
    if isinstance(v, _dt.date):
        return _dt.datetime(v.year, v.month, v.day).strftime("%Y-%m-%dT%H:%M:%SZ")
    if isinstance(v, list):
        return "[" + ", ".join(toml_val(x) for x in v) + "]"
    raise TypeError("unsupported TOML value")


def toml_dumps(obj):
    lines = []

    def emit_table(d, prefix=()):
        scalars = []
        tables = []
        arrays = []
        for k, v in d.items():
            if v is None:
                continue
            if isinstance(v, dict):
                tables.append((k, v))
            elif isinstance(v, list) and v and all(isinstance(x, dict) for x in v):
                arrays.append((k, v))
            else:
                scalars.append((k, v))
        for k, v in scalars:
            lines.append(f"{toml_key(k)} = {toml_val(v)}")
        for k, arr in arrays:
            for item in arr:
                if lines and lines[-1] != "":
                    lines.append("")
                lines.append("[[" + ".".join(toml_key(x) for x in prefix + (k,)) + "]]")
                emit_table(item, prefix + (k,))
        for k, v in tables:
            if lines and lines[-1] != "":
                lines.append("")
            lines.append("[" + ".".join(toml_key(x) for x in prefix + (k,)) + "]")
            emit_table(v, prefix + (k,))

    if isinstance(obj, dict):
        emit_table(obj)
    else:
        lines.append(toml_val(obj))
    return "\n".join(lines).rstrip()


def hcl_key(k):
    return json.dumps(str(k), ensure_ascii=False)


def hcl_val(v, indent=0):
    sp = " " * indent
    if isinstance(v, bool):
        return "true" if v else "false"
    if v is None:
        return "null"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return toml_val(v)
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False)
    if isinstance(v, list):
        if len(v) == 1 and isinstance(v[0], dict):
            return hcl_val(v[0], indent)
        return "[" + ", ".join(hcl_val(x, indent) for x in v) + "]"
    if isinstance(v, dict):
        inner = []
        for k, val in v.items():
            inner.append(" " * (indent + 2) + f"{hcl_key(k)} = {hcl_val(val, indent + 2)}")
        return "{\n" + "\n".join(inner) + "\n" + sp + "}"
    return json.dumps(str(v))


def hcl_dumps(obj):
    if not isinstance(obj, dict):
        return hcl_val(obj)
    chunks = []
    for k, v in obj.items():
        chunks.append(f"{hcl_key(k)} = {hcl_val(v, 0)}")
    return "\n\n".join(chunks)


TOKEN_RE = re.compile(r'''\s*(?:(//[^\n]*|#[^\n]*)|([A-Za-z_][A-Za-z0-9_-]*)|("([^"\\]|\\.)*")|([-+]?\d+(?:\.\d+)?)|([{}=\[\],]))''')


def split_commas(s):
    out, buf, quote, depth, esc = [], [], False, 0, False
    for ch in s:
        if quote:
            buf.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                quote = False
        else:
            if ch == '"':
                quote = True
                buf.append(ch)
            elif ch in "[{":
                depth += 1
                buf.append(ch)
            elif ch in "]}":
                depth -= 1
                buf.append(ch)
            elif ch == "," and depth == 0:
                out.append("".join(buf).strip())
                buf = []
            else:
                buf.append(ch)
    if buf or s.strip() == "":
        out.append("".join(buf).strip())
    return [x for x in out if x != ""]


def toml_parse_value(s):
    s = s.strip()
    if s.startswith('"') and s.endswith('"'):
        return json.loads(s)
    if s in ("true", "false"):
        return s == "true"
    if s in ("inf", "+inf"):
        return float("inf")
    if s == "-inf":
        return float("-inf")
    if s in ("nan", "+nan", "-nan"):
        return float("nan")
    if s.startswith("[") and s.endswith("]"):
        return [toml_parse_value(x) for x in split_commas(s[1:-1])]
    if s.startswith("{") and s.endswith("}"):
        d = {}
        for item in split_commas(s[1:-1]):
            if "=" in item:
                k, v = item.split("=", 1)
                d[k.strip().strip('"')] = toml_parse_value(v)
        return d
    if re.fullmatch(r"\d{4}-\d\d-\d\d(?:T\d\d:\d\d:\d\dZ?)?", s):
        try:
            if "T" in s:
                return _dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
            return _dt.date.fromisoformat(s)
        except Exception:
            pass
    if re.fullmatch(r"[-+]?\d+", s):
        return int(s)
    if re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+)(?:[eE][-+]?\d+)?", s) or re.fullmatch(r"[-+]?\d+[eE][-+]?\d+", s):
        return float(s)
    return s


def parse_toml(text):
    root = {}
    cur = root
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # Strip comments outside quoted strings.
        buf, quote, esc = [], False, False
        for ch in line:
            if quote:
                buf.append(ch)
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    quote = False
            elif ch == '"':
                quote = True
                buf.append(ch)
            elif ch == "#":
                break
            else:
                buf.append(ch)
        line = "".join(buf).strip()
        if line.startswith("[[") and line.endswith("]]"):
            path = [p.strip().strip('"') for p in line[2:-2].split(".")]
            cur = root
            for p in path[:-1]:
                cur = cur.setdefault(p, {})
            arr = cur.setdefault(path[-1], [])
            arr.append({})
            cur = arr[-1]
        elif line.startswith("[") and line.endswith("]"):
            path = [p.strip().strip('"') for p in line[1:-1].split(".")]
            cur = root
            for p in path:
                cur = cur.setdefault(p, {})
        elif "=" in line:
            k, v = line.split("=", 1)
            cur[k.strip().strip('"')] = toml_parse_value(v)
    return root


class HCLParser:
    def __init__(self, text):
        self.tokens = []
        for m in TOKEN_RE.finditer(text):
            if m.group(1):
                continue
            self.tokens.append(m.group(0).strip())
        self.i = 0

    def peek(self):
        return self.tokens[self.i] if self.i < len(self.tokens) else None

    def pop(self):
        t = self.peek()
        self.i += 1
        return t

    def parse(self):
        return self.body(until=None)

    def body(self, until):
        out = {}
        while self.peek() and self.peek() != until:
            name = self.atom_key()
            if self.peek() == "=":
                self.pop()
                out[name] = self.value()
            else:
                labels = []
                while self.peek() and self.peek() != "{":
                    labels.append(self.atom_key())
                if self.peek() == "{":
                    self.pop()
                body = self.body("}")
                if self.peek() == "}":
                    self.pop()
                val = body
                for lab in reversed(labels):
                    val = {lab: [val]}
                out.setdefault(name, []).append(val)
        return out

    def atom_key(self):
        t = self.pop()
        if t is None:
            return ""
        if t.startswith('"'):
            return json.loads(t)
        return t

    def value(self):
        t = self.pop()
        if t is None:
            return None
        if t == "{":
            v = self.body("}")
            if self.peek() == "}":
                self.pop()
            return v
        if t == "[":
            arr = []
            while self.peek() and self.peek() != "]":
                if self.peek() == ",":
                    self.pop()
                    continue
                arr.append(self.value())
            if self.peek() == "]":
                self.pop()
            return arr
        if t.startswith('"'):
            return json.loads(t)
        if t == "true":
            return True
        if t == "false":
            return False
        if t == "null":
            return None
        if re.fullmatch(r"[-+]?\d+", t):
            return int(t)
        if re.fullmatch(r"[-+]?\d+\.\d+", t):
            return float(t)
        return t


def main(argv):
    if any(a in ("--help", "-help") for a in argv):
        # The original treats long flags as compact short flags, but still prints help.
        print(HELP)
        extras = []
        for a in argv:
            if a == "--help":
                extras.extend(["l", "p"])
        if extras:
            print()
            print("Error: invalid flags specified: " + " ".join(extras))
            return 1
        return 0
    inf, outf, flags = parse_flags(argv)
    text = sys.stdin.read()
    data = parse_input(inf, text)
    if "n" not in flags and (inf in "yt" or outf in "ytj"):
        data = convert_specials(data, stringify=True)
    elif "n" in flags and outf == "j":
        data = convert_specials(data, stringify=False)
    if outf == "j":
        out = json_dumps(data, "i" in flags, "e" in flags)
    elif outf == "y":
        out = yaml_dumps(data, "k" in flags)
    elif outf == "t":
        out = toml_dumps(data)
    elif outf == "c":
        out = hcl_dumps(data)
    else:
        raise SystemExit(1)
    sys.stdout.write(out + "\n")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except Exception as e:
        print("Error: " + str(e), file=sys.stderr)
        raise SystemExit(1)
