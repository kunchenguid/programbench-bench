#!/usr/bin/env python3
import csv
import itertools
import json
import math
import os
import shlex
import statistics
import subprocess
import sys
import time
import resource

VERSION = "hyperfine 1.20.0"

HELP = """A command-line benchmarking tool.

Usage: executable [OPTIONS] <command>...

Arguments:
  <command>...
          The command to benchmark. This can be the name of an executable, a
          command line like "grep -i todo" or a shell command like "sleep 0.5 &&
          echo test". The latter is only available if the shell is not
          explicitly disabled via '--shell=none'. If multiple commands are
          given, hyperfine will show a comparison of the respective runtimes.

Options:
  -w, --warmup <NUM>              Perform NUM warmup runs before the actual benchmark.
  -m, --min-runs <NUM>            Perform at least NUM runs for each command (default: 10).
  -M, --max-runs <NUM>            Perform at most NUM runs for each command.
  -r, --runs <NUM>                Perform exactly NUM runs for each command.
  -s, --setup <CMD>               Execute CMD before each set of timing runs.
      --reference <CMD>           The reference command for relative comparison.
      --reference-name <CMD>      Give a meaningful name to the reference command.
  -p, --prepare <CMD>             Execute CMD before each timing run.
  -C, --conclude <CMD>            Execute CMD after each timing run.
  -c, --cleanup <CMD>             Execute CMD after all benchmarking runs for each command.
  -P, --parameter-scan <VAR> <MIN> <MAX>
                                  Perform benchmark runs for each value in MIN..MAX.
  -D, --parameter-step-size <DELTA>
                                  Traverse parameter scans in steps of DELTA.
  -L, --parameter-list <VAR> <VALUES>
                                  Perform runs for comma-separated parameter values.
  -S, --shell <SHELL>             Set the shell to use for executing benchmarked commands.
  -N                              An alias for '--shell=none'.
  -i, --ignore-failure[=<MODE>]   Ignore failures of the benchmarked programs.
      --style <TYPE>              Set output style type.
      --sort <METHOD>             Specify the sort order.
  -u, --time-unit <UNIT>          Set the time unit to be used.
      --export-asciidoc <FILE>    Export results as an AsciiDoc table.
      --export-csv <FILE>         Export results as CSV.
      --export-json <FILE>        Export detailed results as JSON.
      --export-markdown <FILE>    Export results as a Markdown table.
      --export-orgmode <FILE>     Export results as an Emacs org-mode table.
      --show-output               Print stdout and stderr of the benchmark.
      --output <WHERE>            Control where benchmark output is redirected.
      --input <WHERE>             Control where benchmark input comes from.
  -n, --command-name <NAME>       Give a meaningful name to a command.
  -h, --help                      Print help
  -V, --version                   Print version
"""


class UsageError(Exception):
    pass


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def parse(argv):
    opts = {
        "warmup": 0, "min_runs": 10, "max_runs": None, "runs": None,
        "setup": None, "prepare": [], "conclude": [], "cleanup": None,
        "param_scan": None, "step": None, "param_lists": [], "shell": "default",
        "ignore": None, "style": "auto", "sort": "auto", "time_unit": None,
        "exports": {}, "show_output": False, "outputs": [], "input": "null",
        "names": [], "reference": None, "reference_name": None, "commands": []
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        def need():
            nonlocal i
            if i + 1 >= len(argv):
                raise UsageError(f"error: a value is required for '{a}'")
            i += 1
            return argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        elif a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        elif a in ("-w", "--warmup"):
            opts["warmup"] = int(need())
        elif a in ("-m", "--min-runs"):
            opts["min_runs"] = int(need())
        elif a in ("-M", "--max-runs"):
            opts["max_runs"] = int(need())
        elif a in ("-r", "--runs"):
            opts["runs"] = int(need())
        elif a in ("-s", "--setup"):
            opts["setup"] = need()
        elif a == "--reference":
            opts["reference"] = need()
        elif a == "--reference-name":
            opts["reference_name"] = need()
        elif a in ("-p", "--prepare"):
            opts["prepare"].append(need())
        elif a in ("-C", "--conclude"):
            opts["conclude"].append(need())
        elif a in ("-c", "--cleanup"):
            opts["cleanup"] = need()
        elif a in ("-P", "--parameter-scan"):
            if i + 3 >= len(argv):
                raise UsageError(f"error: a value is required for '{a}'")
            opts["param_scan"] = (argv[i+1], argv[i+2], argv[i+3])
            i += 3
        elif a in ("-D", "--parameter-step-size"):
            opts["step"] = need()
        elif a in ("-L", "--parameter-list"):
            if i + 2 >= len(argv):
                raise UsageError(f"error: a value is required for '{a}'")
            opts["param_lists"].append((argv[i+1], argv[i+2]))
            i += 2
        elif a in ("-S", "--shell"):
            opts["shell"] = need()
        elif a == "-N":
            opts["shell"] = "none"
        elif a.startswith("--shell="):
            opts["shell"] = a.split("=", 1)[1]
        elif a in ("-i", "--ignore-failure"):
            opts["ignore"] = "all-non-zero"
        elif a.startswith("--ignore-failure="):
            opts["ignore"] = a.split("=", 1)[1] or "all-non-zero"
        elif a == "--style":
            opts["style"] = need()
        elif a.startswith("--style="):
            opts["style"] = a.split("=", 1)[1]
        elif a == "--sort":
            opts["sort"] = need()
        elif a in ("-u", "--time-unit"):
            opts["time_unit"] = need()
        elif a == "--export-asciidoc":
            opts["exports"]["asciidoc"] = need()
        elif a == "--export-csv":
            opts["exports"]["csv"] = need()
        elif a == "--export-json":
            opts["exports"]["json"] = need()
        elif a == "--export-markdown":
            opts["exports"]["markdown"] = need()
        elif a == "--export-orgmode":
            opts["exports"]["orgmode"] = need()
        elif a == "--show-output":
            opts["show_output"] = True
        elif a == "--output":
            opts["outputs"].append(need())
        elif a.startswith("--output="):
            opts["outputs"].append(a.split("=", 1)[1])
        elif a == "--input":
            opts["input"] = need()
        elif a.startswith("--input="):
            opts["input"] = a.split("=", 1)[1]
        elif a in ("-n", "--command-name"):
            opts["names"].append(need())
        elif a == "--":
            opts["commands"].extend(argv[i+1:])
            break
        elif a.startswith("-") and not opts["commands"]:
            raise UsageError(f"error: unexpected argument '{a}' found")
        else:
            opts["commands"].append(a)
        i += 1
    if opts["style"] != "auto" and opts["show_output"]:
        raise UsageError("error: the argument '--style <TYPE>' cannot be used with '--show-output'")
    if not opts["commands"]:
        raise UsageError("error: the following required arguments were not provided:\n  <command>...")
    if opts["runs"] is not None:
        opts["min_runs"] = opts["runs"]
        opts["max_runs"] = opts["runs"]
    return opts


def fmt_param(x):
    if abs(x - round(x)) < 1e-12:
        return str(int(round(x)))
    return ("%g" % x)


def expand_commands(opts):
    params = []
    if opts["param_scan"]:
        var, lo, hi = opts["param_scan"]
        step = float(opts["step"]) if opts["step"] is not None else 1.0
        start, end = float(lo), float(hi)
        vals = []
        x = start
        limit = 100000
        if step == 0:
            raise UsageError("error: parameter step size must not be zero")
        cmp = (lambda a, b: a <= b + 1e-12) if step > 0 else (lambda a, b: a >= b - 1e-12)
        while cmp(x, end) and limit > 0:
            vals.append(fmt_param(x))
            x += step
            limit -= 1
        params.append((var, vals))
    for var, values in opts["param_lists"]:
        params.append((var, values.split(",")))
    # hyperfine varies the first declared parameter fastest: -L x a,b -L y 1,2
    # yields x=a/y=1, x=b/y=1, x=a/y=2, ...
    if params:
        combos = (tuple(reversed(c)) for c in itertools.product(*reversed([v for _, v in params])))
    else:
        combos = [()]
    out = []
    for combo in combos:
        repl = dict(zip([p[0] for p in params], combo))
        for idx, cmd in enumerate(opts["commands"]):
            c = cmd
            for k, v in repl.items():
                c = c.replace("{" + k + "}", v)
            name = opts["names"][idx] if idx < len(opts["names"]) else c
            for k, v in repl.items():
                name = name.replace("{" + k + "}", v)
            out.append({"command": c, "name": name, "params": repl})
    return out


def subst(s, params):
    if s is None:
        return None
    for k, v in params.items():
        s = s.replace("{" + k + "}", v)
    return s


def shell_args(shell, cmd):
    if shell in ("default", "", None):
        return ["/bin/sh", "-c", cmd], False
    if shell == "none":
        return shlex.split(cmd), False
    parts = shlex.split(shell)
    prog = os.path.basename(parts[0])
    flag = "/C" if prog.lower().startswith("cmd") else "-c"
    return parts + [flag, cmd], False


def output_target(where, show):
    if show or where == "inherit":
        return None, None
    if where == "pipe":
        return subprocess.PIPE, None
    if where in ("", "null", None):
        return subprocess.DEVNULL, None
    f = open(where, "ab")
    return f, f


def input_target(where):
    if where in ("", "null", None):
        return subprocess.DEVNULL, None
    f = open(where, "rb")
    return f, f


def allowed_failure(code, mode):
    if code == 0:
        return True
    if not mode:
        return False
    if mode == "all-non-zero":
        return True
    try:
        return code in {int(x) for x in mode.split(",") if x != ""}
    except ValueError:
        return False


def run_once(cmd, opts, env_extra=None, timed=True, output_where=None):
    args, _ = shell_args(opts["shell"], cmd)
    env = os.environ.copy()
    if env_extra:
        env.update(env_extra)
    stdin, in_f = input_target(opts["input"])
    stdout, out_f = output_target(output_where or "null", opts["show_output"])
    stderr = None if opts["show_output"] else stdout
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    t0 = time.perf_counter()
    try:
        p = subprocess.run(args, stdin=stdin, stdout=stdout, stderr=stderr, env=env)
        rc = p.returncode
    finally:
        if in_f:
            in_f.close()
        if out_f:
            out_f.close()
    elapsed = time.perf_counter() - t0
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    user = max(0.0, after.ru_utime - before.ru_utime)
    system = max(0.0, after.ru_stime - before.ru_stime)
    mem = int(max(0, after.ru_maxrss) * 1024)
    return elapsed if timed else 0.0, user, system, mem, rc


def one_of(values, index):
    if not values:
        return None
    if len(values) == 1:
        return values[0]
    if index < len(values):
        return values[index]
    return values[-1]


def stats(times):
    mean = statistics.fmean(times) if times else 0.0
    std = statistics.stdev(times) if len(times) > 1 else None
    median = statistics.median(times) if times else 0.0
    return mean, std, median, min(times or [0.0]), max(times or [0.0])


def choose_unit(seconds, requested=None):
    if requested:
        if requested.startswith("micro"):
            return "µs", 1_000_000.0
        if requested.startswith("milli"):
            return "ms", 1000.0
        return "s", 1.0
    if seconds < 0.001:
        return "µs", 1_000_000.0
    if seconds < 1.0:
        return "ms", 1000.0
    return "s", 1.0


def num(x):
    ax = abs(x)
    if ax >= 100:
        return f"{x:.0f}"
    if ax >= 10:
        return f"{x:.1f}"
    if ax >= 1:
        return f"{x:.2f}"
    return f"{x:.3f}"


def print_result(res, opts):
    if opts["style"] == "none":
        return
    unit, factor = choose_unit(res["mean"], opts["time_unit"])
    mean = res["mean"] * factor
    std = None if res["stddev"] is None else res["stddev"] * factor
    user = res["user"] * factor
    system = res["system"] * factor
    if len(res["times"]) == 1:
        print(f"  Time (abs ≡):      {num(mean):>7} {unit:<2}              [User: {num(user)} {unit}, System: {num(system)} {unit}]")
    else:
        print(f"  Time (mean ± σ):   {num(mean):>7} {unit} ± {num(std or 0):>5} {unit}    [User: {num(user)} {unit}, System: {num(system)} {unit}]")
        print(f"  Range (min … max): {num(res['min']*factor):>7} {unit} … {num(res['max']*factor):>7} {unit}    {len(res['times'])} runs")
    print(" ")
    if res["mean"] < 0.005:
        print("  Warning: Command took less than 5 ms to complete. Note that the results might be inaccurate because hyperfine can not calibrate the shell startup time much more precise than this limit. You can try to use the `-N`/`--shell=none` option to disable the shell completely.")
        print(" ")
    if any(c != 0 for c in res["exit_codes"]):
        print("  Warning: Ignoring non-zero exit code.")


def benchmark(entry, idx, opts):
    if opts["style"] != "none":
        print(f"Benchmark {idx}: {entry['name']}")
        sys.stdout.flush()
    params = entry["params"]
    if opts["setup"]:
        rc = run_once(subst(opts["setup"], params), opts, timed=False)[4]
        if rc != 0:
            die(f"Error: Setup command terminated with non-zero exit code {rc}.", 1)
    for _ in range(opts["warmup"]):
        rc = run_once(entry["command"], opts, timed=False)[4]
        if not allowed_failure(rc, opts["ignore"]):
            die(f"Error: Command terminated with non-zero exit code {rc} during warmup.", 1)
    runs = opts["runs"] if opts["runs"] is not None else opts["min_runs"]
    if opts["max_runs"] is not None:
        runs = min(runs, opts["max_runs"])
    times = []
    users = []
    systems = []
    mems = []
    codes = []
    for n in range(1, runs + 1):
        env = {"HYPERFINE_ITERATION": str(n)}
        prep = subst(one_of(opts["prepare"], idx - 1), params)
        conc = subst(one_of(opts["conclude"], idx - 1), params)
        if prep:
            rc = run_once(prep, opts, env, timed=False)[4]
            if rc != 0:
                die(f"Error: Preparation command terminated with non-zero exit code {rc}.", 1)
        out_where = one_of(opts["outputs"], idx - 1) or "inherit" if opts["show_output"] else (one_of(opts["outputs"], idx - 1) or "null")
        elapsed, user, system, mem, rc = run_once(entry["command"], opts, env, True, out_where)
        if not allowed_failure(rc, opts["ignore"]):
            die(f"Error: Command terminated with non-zero exit code {rc} in the first benchmark run. Use the '-i'/'--ignore-failure' option if you want to ignore this. Alternatively, use the '--show-output' option to debug what went wrong.", 1)
        times.append(elapsed); users.append(user); systems.append(system); mems.append(mem); codes.append(rc)
        if conc:
            rc2 = run_once(conc, opts, env, timed=False)[4]
            if rc2 != 0:
                die(f"Error: Conclude command terminated with non-zero exit code {rc2}.", 1)
    if opts["cleanup"]:
        rc = run_once(subst(opts["cleanup"], params), opts, timed=False)[4]
        if rc != 0:
            die(f"Error: Cleanup command terminated with non-zero exit code {rc}.", 1)
    mean, std, median, mn, mx = stats(times)
    res = {
        "command": entry["name"], "mean": mean, "stddev": std, "median": median,
        "user": statistics.fmean(users) if users else 0.0,
        "system": statistics.fmean(systems) if systems else 0.0,
        "min": mn, "max": mx, "times": times,
        "memory_usage_byte": mems, "exit_codes": codes
    }
    print_result(res, opts)
    return res


def rel_text(res, base):
    if res is base:
        return "1.00"
    if not base or base["mean"] <= 0:
        return "1.00"
    ratio = res["mean"] / base["mean"]
    if ratio == 0:
        return "0.00"
    if res["stddev"] and base["stddev"]:
        err = ratio * math.sqrt((res["stddev"]/res["mean"])**2 + (base["stddev"]/base["mean"])**2)
        return f"{ratio:.2f} ± {err:.2f}"
    return f"{ratio:.2f}"


def ordered_for_markup(results, opts):
    if opts["sort"] == "mean-time":
        return sorted(results, key=lambda r: r["mean"])
    return results


def write_exports(results, opts):
    if "json" in opts["exports"]:
        with open(opts["exports"]["json"], "w") as f:
            json.dump({"results": results}, f, indent=2)
            f.write("\n")
    if "csv" in opts["exports"]:
        with open(opts["exports"]["csv"], "w", newline="") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(["command","mean","stddev","median","user","system","min","max"])
            for r in results:
                w.writerow([r["command"], r["mean"], r["stddev"], r["median"], r["user"], r["system"], r["min"], r["max"]])
    unit, factor = choose_unit(min((r["mean"] for r in results), default=0.0), opts["time_unit"])
    base = min(results, key=lambda r: r["mean"]) if results else None
    rows = []
    for r in ordered_for_markup(results, opts):
        sd = r["stddev"] or 0.0
        rows.append((r["command"], f"{r['mean']*factor:.1f} ± {sd*factor:.1f}", f"{r['min']*factor:.1f}", f"{r['max']*factor:.1f}", rel_text(r, base)))
    if "markdown" in opts["exports"]:
        with open(opts["exports"]["markdown"], "w") as f:
            f.write(f"| Command | Mean [{unit}] | Min [{unit}] | Max [{unit}] | Relative |\n")
            f.write("|:---|---:|---:|---:|---:|\n")
            for row in rows:
                f.write(f"| `{row[0]}` | {row[1]} | {row[2]} | {row[3]} | {row[4]} |\n")
    if "asciidoc" in opts["exports"]:
        with open(opts["exports"]["asciidoc"], "w") as f:
            f.write('[cols="<,>,>,>,>"]\n|===\n')
            for h in ("Command", f"Mean [{unit}]", f"Min [{unit}]", f"Max [{unit}]", "Relative"):
                f.write(f"| {h} \n")
            f.write("\n")
            for row in rows:
                f.write(f"| `{row[0]}` \n| {row[1]} \n| {row[2]} \n| {row[3]} \n| {row[4]} \n")
            f.write("|===\n")
    if "orgmode" in opts["exports"]:
        with open(opts["exports"]["orgmode"], "w") as f:
            f.write(f"| Command  |  Mean [{unit}] |  Min [{unit}] |  Max [{unit}] |  Relative |\n")
            f.write("|--+--+--+--+--|\n")
            for row in rows:
                f.write(f"| ={row[0]}=  |  {row[1]} |  {row[2]} |  {row[3]} |  {row[4]} |\n")


def print_summary(results, opts):
    if opts["style"] == "none" or len(results) < 2:
        return
    if any(r["mean"] <= 0 for r in results):
        print("Note: The benchmark comparison could not be computed as some benchmark times are zero.")
        return
    ordered = sorted(results, key=lambda r: r["mean"]) if opts["sort"] != "command" else results
    ref = None
    if opts["reference"]:
        for r in results:
            if r["command"] == opts["reference"]:
                ref = r
                break
    if ref is None:
        ref = min(results, key=lambda r: r["mean"])
    print("Summary")
    print(f"  {ref['command']} ran")
    for r in ordered:
        if r is ref:
            continue
        ratio = r["mean"] / ref["mean"]
        if r["stddev"] and ref["stddev"]:
            err = ratio * math.sqrt((r["stddev"]/r["mean"])**2 + (ref["stddev"]/ref["mean"])**2)
            print(f"    {ratio:.2f} ± {err:.2f} times faster than {r['command']}")
        else:
            print(f"    {ratio:.2f} times faster than {r['command']}")


def main(argv):
    try:
        opts = parse(argv)
    except (UsageError, ValueError) as e:
        print(str(e), file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        return 2
    entries = expand_commands(opts)
    results = []
    for idx, entry in enumerate(entries, 1):
        results.append(benchmark(entry, idx, opts))
    print_summary(results, opts)
    write_exports(results, opts)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
