#!/usr/bin/env python3
import html
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path


VERSION = "Cppcheck 2.19 dev"
SOURCE_EXTS = {".cpp", ".cxx", ".cc", ".c++", ".c", ".ipp", ".ixx", ".tpp", ".txx", ".h", ".hpp", ".hh", ".hxx"}


HELP = """Cppcheck - A tool for static C/C++ code analysis

Syntax:
    cppcheck [OPTIONS] [files or paths]

If a directory is given instead of a filename, *.cpp, *.cxx, *.cc, *.c++, *.c, *.ipp,
*.ixx, *.tpp, and *.txx files are checked recursively from the given directory.

Options:
    --addon=<addon>      Execute addon.
    --check-config       Check cppcheck configuration.
    --check-library      Show information messages when library files have incomplete info.
    --checkers-report=<file>
                         Write a report of all the active checkers to the given file.
    -D<ID>               Define preprocessor symbol.
    -E                   Print preprocessor output on stdout and don't do any further processing.
    --enable=<severity>  Enable additional checks. Severities: warning, performance,
                         portability, information, style, unusedFunction, missingInclude, all
    --disable=<severity> Disable checks with the given severity.
    --error-exitcode=<n> Return this code if errors are found.
    --errorlist          Print a list of all the error messages in XML format.
    --file-list=<file>   Specify files to check, one per line.
    --file-filter=<str>  Analyze only files matching the filter.
    -f, --force          Force checking of all configurations.
    -h, --help           Print this help.
    -I <dir>             Give path to search for include files.
    --include=<file>     Force inclusion of a file before the checked file.
    -i <str>             Ignore files that match <str>.
    --inline-suppr       Enable inline suppressions.
    -j <jobs>            Start <jobs> threads to do the checking simultaneously.
    --language=<language>, -x <language>
                         Forces cppcheck to check all files as c or c++.
    --library=<cfg>      Load library configuration.
    --max-configs=<n>    Maximum number of configurations to check.
    --output-file=<file> Write results to file, rather than standard error.
    --output-format=<format>
                         Specify output format: text, sarif, xml, xmlv2, xmlv3
    --platform=<type>    Specify platform.
    --project=<file>     Run Cppcheck on project/compile database.
    -q, --quiet          Do not show progress reports.
    --suppress=<spec>    Suppress warnings matching the specification.
    --template=<format>  Format error messages. Pre-defined templates: gcc, cppcheck1, vs, edit.
    -U<ID>               Undefine preprocessor symbol.
    -v, --verbose        Output more detailed error information.
    --version            Print out version number.
    --xml                Write results in xml format to error stream (stderr).

Example usage:
  cppcheck .
  cppcheck --quiet ../myproject/
  cppcheck --enable=all --inconclusive --library=posix test.cpp
"""


@dataclass
class Finding:
    file: str
    line: int
    severity: str
    msg: str
    id: str
    column: int = 1


def strip_comments_and_strings(text: str) -> str:
    out = []
    i = 0
    n = len(text)
    in_block = False
    in_line = False
    in_str = None
    while i < n:
        c = text[i]
        nxt = text[i + 1] if i + 1 < n else ""
        if in_line:
            if c == "\n":
                in_line = False
                out.append(c)
            else:
                out.append(" ")
            i += 1
        elif in_block:
            if c == "*" and nxt == "/":
                out.extend("  ")
                i += 2
                in_block = False
            else:
                out.append("\n" if c == "\n" else " ")
                i += 1
        elif in_str:
            if c == "\\":
                out.extend("  ")
                i += 2
            elif c == in_str:
                out.append(" ")
                i += 1
                in_str = None
            else:
                out.append("\n" if c == "\n" else " ")
                i += 1
        elif c == "/" and nxt == "/":
            out.extend("  ")
            i += 2
            in_line = True
        elif c == "/" and nxt == "*":
            out.extend("  ")
            i += 2
            in_block = True
        elif c in "\"'":
            out.append(" ")
            i += 1
            in_str = c
        else:
            out.append(c)
            i += 1
    return "".join(out)


def line_number(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


def is_suppressed(raw_lines, line, finding_id, inline_enabled, suppressions):
    if finding_id in suppressions or "all" in suppressions:
        return True
    if not inline_enabled:
        return False
    start = max(0, line - 3)
    nearby = "\n".join(raw_lines[start:line])
    return "cppcheck-suppress" in nearby and (finding_id in nearby or "all" in nearby)


def add(finds, raw_lines, inline_enabled, suppressions, finding):
    if not is_suppressed(raw_lines, finding.line, finding.id, inline_enabled, suppressions):
        finds.append(finding)


def analyze_file(path, opts):
    try:
        raw = Path(path).read_text(errors="replace")
    except OSError as e:
        return [Finding(path, 0, "error", str(e), "file")]
    code = strip_comments_and_strings(raw)
    raw_lines = raw.splitlines()
    findings = []

    arrays = {}
    array_decl_spans = []
    for m in re.finditer(r"\b(?:char|short|int|long|float|double|bool|unsigned|signed|size_t|[A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s*\[\s*(-?\d+)\s*\]", code):
        name, size_s = m.group(1), m.group(2)
        size = int(size_s)
        arrays[name] = size
        array_decl_spans.append((m.start(1), m.end(0)))
        if size < 0:
            add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, m.start()), "error", f"Declaration of array '{name}' with negative size is undefined behaviour", "negativeArraySize"))

    for name, size in arrays.items():
        for m in re.finditer(r"\b" + re.escape(name) + r"\s*\[\s*(-?\d+)\s*\]", code):
            if any(start <= m.start() < end for start, end in array_decl_spans):
                continue
            idx = int(m.group(1))
            if idx < 0:
                add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, m.start()), "error", "Negative array index", "negativeIndex"))
            elif size >= 0 and idx >= size:
                msg = f"Array '{name}[{size}]' accessed at index {idx}, which is out of bounds."
                add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, m.start()), "error", msg, "arrayIndexOutOfBounds"))

    for m in re.finditer(r"/\s*0(?:\D|$)", code):
        add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, m.start()), "error", "Division by zero.", "zerodiv"))

    null_vars = set()
    null_decl_spans = []
    for m in re.finditer(r"(?:\b[A-Za-z_]\w*\s*\*\s*|\b[A-Za-z_]\w*\s+\*\s*)([A-Za-z_]\w*)\s*=\s*(?:0|NULL|nullptr)\b", code):
        null_vars.add(m.group(1))
        null_decl_spans.append((m.start(), m.end()))
    for var in null_vars:
        for m in re.finditer(r"(?:\*" + re.escape(var) + r"\b|" + re.escape(var) + r"\s*->)", code):
            if any(start <= m.start() < end for start, end in null_decl_spans):
                continue
            add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, m.start()), "error", f"Null pointer dereference: {var}", "nullPointer"))

    init_vars = set(re.findall(r"\b(?:int|long|short|char|float|double|bool|size_t)\s+([A-Za-z_]\w*)\s*=", code))
    for m in re.finditer(r"\b(?:int|long|short|char|float|double|bool|size_t)\s+([A-Za-z_]\w*)\s*;", code):
        var = m.group(1)
        if var in init_vars:
            continue
        rest = code[m.end():]
        if re.search(r"\breturn\s+" + re.escape(var) + r"\b", rest) or re.search(r"[=,(]\s*" + re.escape(var) + r"\s*[,);]", rest):
            add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, m.start()), "error", f"Uninitialized variable: {var}", "uninitvar"))

    for m in re.finditer(r"\bif\s*\(([^()\n]+)\s*==\s*\1\s*\)", code):
        add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, m.start()), "style", "Same expression on both sides of '=='.", "duplicateExpression"))
    for m in re.finditer(r"\bif\s*\(([^()\n]+)\s*&&\s*\1\s*\)", code):
        add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, m.start()), "style", "Same expression on both sides of '&&'.", "duplicateExpression"))

    for m in re.finditer(r"\bmemset\s*\(\s*([^,]+),\s*([^,]+),\s*0\s*\)", code):
        add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, m.start()), "warning", "memset() called to fill 0 bytes.", "memsetZeroBytes"))

    for mm in re.finditer(r"\b([A-Za-z_]\w*)\s*=\s*(?:\([^)]+\)\s*)?(?:malloc|calloc|realloc)\s*\(", code):
        var = mm.group(1)
        if not re.search(r"\bfree\s*\(\s*" + re.escape(var) + r"\s*\)", code):
            add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, mm.start(1)), "error", f"Memory leak: {var}", "memleak"))

    for fm in re.finditer(r"\b(?:FILE\s*\*\s*)?([A-Za-z_]\w*)\s*=\s*fopen\s*\(", code):
        var = fm.group(1)
        if not re.search(r"\bfclose\s*\(\s*" + re.escape(var) + r"\s*\)", code):
            add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, fm.start(1)), "error", f"Resource leak: {var}", "resourceLeak"))

    for m in re.finditer(r"\bstrcpy\s*\(", code):
        add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, m.start()), "warning", "Dangerous usage of strcpy().", "bufferAccessOutOfBounds"))

    if opts.get("enable_all"):
        funcs = re.finditer(r"\b(?:int|long|short|char|float|double|bool|[A-Za-z_]\w+)\s+([A-Za-z_]\w*)\s*\([^;{}]*\)\s*\{([^{}]*)\}", code, re.S)
        for m in funcs:
            name, body = m.group(1), m.group(2)
            if name != "main" and "return" not in body:
                add(findings, raw_lines, opts["inline"], opts["suppressions"], Finding(path, line_number(code, m.start()), "error", "Found an exit path from function with non-void return type that has missing return statement", "missingReturn"))

    return findings


def discover(paths):
    result = []
    for p in paths:
        if p == "-":
            continue
        path = Path(p)
        if path.is_dir():
            for child in sorted(path.rglob("*")):
                if child.is_file() and child.suffix.lower() in SOURCE_EXTS:
                    result.append(str(child))
        else:
            result.append(str(path))
    return result


def parse_args(argv):
    opts = {
        "quiet": False, "xml": False, "sarif": False, "template": None, "output": None,
        "error_exit": None, "inline": False, "suppressions": set(), "enable_all": False,
        "preprocess": False, "checkers_report": None, "files": []
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a == "--version":
            print(VERSION)
            raise SystemExit(0)
        if a == "--errorlist":
            print_errorlist()
            raise SystemExit(0)
        if a in ("-q", "--quiet"):
            opts["quiet"] = True
        elif a == "--xml" or a.startswith("--xml-version") or a in ("--output-format=xml", "--output-format=xmlv2", "--output-format=xmlv3"):
            opts["xml"] = True
        elif a == "--output-format=sarif":
            opts["sarif"] = True
        elif a.startswith("--output-file="):
            opts["output"] = a.split("=", 1)[1]
        elif a == "--output-file":
            i += 1; opts["output"] = argv[i]
        elif a.startswith("--template="):
            opts["template"] = a.split("=", 1)[1].strip("'\"")
        elif a == "--template":
            i += 1; opts["template"] = argv[i]
        elif a.startswith("--error-exitcode="):
            opts["error_exit"] = int(a.split("=", 1)[1] or "0")
        elif a == "--error-exitcode":
            i += 1; opts["error_exit"] = int(argv[i])
        elif a in ("-E",):
            opts["preprocess"] = True
        elif a == "--inline-suppr":
            opts["inline"] = True
        elif a.startswith("--suppress="):
            opts["suppressions"].add(a.split("=", 1)[1].split(":")[0])
        elif a == "--suppress":
            i += 1; opts["suppressions"].add(argv[i].split(":")[0])
        elif a.startswith("--enable="):
            val = a.split("=", 1)[1]
            opts["enable_all"] = "all" in val or "style" in val
        elif a == "--enable":
            i += 1; opts["enable_all"] = "all" in argv[i] or "style" in argv[i]
        elif a.startswith("--checkers-report="):
            opts["checkers_report"] = a.split("=", 1)[1]
        elif a == "--checkers-report":
            i += 1; opts["checkers_report"] = argv[i]
        elif a.startswith("--file-list="):
            fl = a.split("=", 1)[1]
            opts["files"].extend(read_file_list(fl))
        elif a == "--file-list":
            i += 1; opts["files"].extend(read_file_list(argv[i]))
        elif a.startswith("--project="):
            opts["files"].extend(read_project(a.split("=", 1)[1]))
        elif a == "--project":
            i += 1; opts["files"].extend(read_project(argv[i]))
        elif a in ("-I", "-i", "-j", "-l", "-x", "--language", "--library", "--platform", "--include", "--max-configs", "--addon", "--addon-python", "--cppcheck-build-dir", "--config-exclude", "--config-excludes-file", "--includes-file", "--file-filter", "--plist-output", "--std"):
            i += 1
        elif a.startswith(("-I", "-D", "-U")) or a.startswith(("--language=", "--library=", "--platform=", "--include=", "--max-configs=", "--addon=", "--addon-python=", "--cppcheck-build-dir=", "--config-exclude=", "--config-excludes-file=", "--includes-file=", "--file-filter=", "--plist-output=", "--std=", "--disable=", "--check-level=")):
            pass
        elif a.startswith("--") and a not in ("--force", "--dump", "--check-config", "--check-library", "--inconclusive", "--verbose"):
            print(f'cppcheck: error: unrecognized command line option: "{a}".')
            raise SystemExit(1)
        elif a.startswith("-") and a not in ("-f", "-v"):
            print(f'cppcheck: error: unrecognized command line option: "{a}".')
            raise SystemExit(1)
        else:
            opts["files"].append(a)
        i += 1
    return opts


def read_file_list(path):
    try:
        data = sys.stdin.read().splitlines() if path == "-" else Path(path).read_text().splitlines()
        return [x.strip() for x in data if x.strip()]
    except OSError:
        return [path]


def read_project(path):
    try:
        data = json.loads(Path(path).read_text())
        if isinstance(data, list):
            return [str(Path(item.get("directory", ".")).joinpath(item.get("file", ""))) for item in data if item.get("file")]
    except Exception:
        pass
    return [path]


def render_text(finds, template=None):
    lines = []
    for f in finds:
        if template == "gcc":
            lines.append(f"{f.file}:{f.line}:{f.column}: {f.severity}: {f.msg} [{f.id}]")
        elif template == "vs":
            lines.append(f"{f.file}({f.line}): {f.severity}: {f.msg} [{f.id}]")
        elif template and "{" in template:
            s = template.replace("{file}", f.file).replace("{line}", str(f.line)).replace("{column}", str(f.column))
            s = s.replace("{severity}", f.severity).replace("{message}", f.msg).replace("{id}", f.id)
            s = s.replace("\\n", "\n").replace("\\t", "\t").replace("\\r", "\r")
            lines.append(s)
        else:
            lines.append(f"[{f.file}:{f.line}]: ({f.severity}) {f.msg}")
    return "\n".join(lines) + ("\n" if lines else "")


def render_xml(finds):
    out = ['<?xml version="1.0" encoding="UTF-8"?>', '<results version="2">', f'    <cppcheck version="{VERSION.split(" ", 1)[1]}"/>', '    <errors>']
    for f in finds:
        msg = xml_escape(f.msg)
        out.append(f'        <error id="{xml_escape(f.id)}" severity="{f.severity}" msg="{msg}" verbose="{msg}">')
        out.append(f'            <location file="{xml_escape(f.file)}" line="{f.line}" column="{f.column}"/>')
        out.append('        </error>')
    out += ['    </errors>', '</results>']
    return "\n".join(out) + "\n"


def xml_escape(s):
    return html.escape(str(s), quote=True).replace("&#x27;", "&apos;")


def render_sarif(finds):
    results = []
    for f in finds:
        results.append({"ruleId": f.id, "level": "error" if f.severity == "error" else "warning", "message": {"text": f.msg}, "locations": [{"physicalLocation": {"artifactLocation": {"uri": f.file}, "region": {"startLine": f.line, "startColumn": f.column}}}]})
    return json.dumps({"version": "2.1.0", "$schema": "https://json.schemastore.org/sarif-2.1.0.json", "runs": [{"tool": {"driver": {"name": "Cppcheck", "version": "2.19 dev"}}, "results": results}]}, indent=2) + "\n"


def print_errorlist():
    common = [
        ("arrayIndexOutOfBounds", "error", "Array 'arr[16]' accessed at index 16, which is out of bounds."),
        ("negativeIndex", "error", "Negative array index"),
        ("zerodiv", "error", "Division by zero."),
        ("nullPointer", "error", "Null pointer dereference"),
        ("uninitvar", "error", "Uninitialized variable: var"),
        ("memleak", "error", "Memory leak: var"),
        ("resourceLeak", "error", "Resource leak: var"),
        ("missingReturn", "error", "Found an exit path from function with non-void return type that has missing return statement"),
        ("duplicateExpression", "style", "Same expression on both sides of operator."),
        ("memsetZeroBytes", "warning", "memset() called to fill 0 bytes."),
    ]
    print('<?xml version="1.0" encoding="UTF-8"?>')
    print('<results version="2">')
    print('    <cppcheck version="2.19 dev"/>')
    print('    <errors>')
    for eid, sev, msg in common:
        print(f'        <error id="{eid}" severity="{sev}" msg="{html.escape(msg)}" verbose="{html.escape(msg)}"/>')
    print('    </errors>')
    print('</results>')


def main(argv):
    if not argv:
        print(HELP, end="")
        return 0
    try:
        opts = parse_args(argv)
    except (ValueError, IndexError):
        print("cppcheck: error: invalid command line")
        return 1

    if opts["checkers_report"]:
        Path(opts["checkers_report"]).write_text("Active checkers:\narrayIndexOutOfBounds\nnullPointer\nuninitvar\nzerodiv\n")

    files = discover(opts["files"])
    if opts["preprocess"]:
        for f in files:
            try:
                sys.stdout.write(Path(f).read_text(errors="replace"))
            except OSError as e:
                print(str(e), file=sys.stderr)
                return 1
        return 0
    if not files:
        print("cppcheck: error: no C or C++ source files found.")
        return 1

    missing = [f for f in files if not Path(f).exists()]
    if missing:
        for f in missing:
            print(f"cppcheck: error: could not find or open any of the paths given: {f}")
        return 1

    all_findings = []
    for idx, f in enumerate(files, 1):
        if not opts["quiet"]:
            print(f"Checking {f}...", file=sys.stderr)
            if len(files) > 1:
                print(f"{idx}/{len(files)} files checked {int(idx * 100 / len(files))}% done", file=sys.stderr)
        all_findings.extend(analyze_file(f, opts))

    if opts["sarif"]:
        rendered = render_sarif(all_findings)
    elif opts["xml"]:
        rendered = render_xml(all_findings)
    else:
        rendered = render_text(all_findings, opts["template"])

    if opts["output"]:
        Path(opts["output"]).write_text(rendered)
    else:
        stream = sys.stderr if (all_findings or opts["xml"]) else sys.stdout
        stream.write(rendered)

    if all_findings and opts["error_exit"] is not None:
        return opts["error_exit"]
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
