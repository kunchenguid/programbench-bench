#!/usr/bin/env python3
import curses
import datetime as _dt
import os
import shutil
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def _read_asset(name: str) -> str:
    return (ROOT / name).read_text(encoding="utf-8")


HELP = _read_asset("help_ref.txt")
INIT = _read_asset("init_ref.txt")


def data_home() -> Path:
    xdg = os.environ.get("XDG_DATA_HOME")
    if xdg:
        return Path(xdg)
    return Path.home() / ".local" / "share"


def log_start() -> None:
    log_dir = data_home() / "felix" / "log"
    log_dir.mkdir(parents=True, exist_ok=True)
    stamp = _dt.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    with (log_dir / f"{stamp}.log").open("a", encoding="utf-8") as fh:
        fh.write(f"{_dt.datetime.now().strftime('%H:%M:%S')} [INFO] ===START===\n")


def print_path_error(message: str) -> None:
    print(message, file=sys.stderr)
    print("`fx -h` shows help.", file=sys.stderr)


def parse_args(argv: list[str]) -> tuple[str, Path | None, bool]:
    if len(argv) == 0:
        return "run", Path.cwd(), False

    first = argv[0]
    if first in ("-h", "--help"):
        return "help", None, False
    if first == "--init" and len(argv) == 1:
        return "init", None, False
    if first in ("-l", "--log"):
        if len(argv) == 1:
            return "run", Path.cwd(), True
        if len(argv) == 2:
            return "run", Path(argv[1]), True
        return "help", None, False
    if len(argv) != 1:
        return "help", None, False
    return "run", Path(first), False


def sorted_items(path: Path, show_hidden: bool, by_mtime: bool) -> list[Path]:
    try:
        items = list(path.iterdir())
    except OSError:
        return []
    if not show_hidden:
        items = [p for p in items if not p.name.startswith(".")]
    if by_mtime:
        items.sort(key=lambda p: (p.stat().st_mtime if p.exists() else 0, p.name.lower()), reverse=True)
    else:
        items.sort(key=lambda p: (not p.is_dir(), p.name.lower()))
    return items


def open_item(path: Path) -> Path:
    if path.is_dir():
        return path.resolve()
    opener = os.environ.get("OPENER") or shutil.which("xdg-open") or shutil.which("open")
    if opener:
        os.spawnlp(os.P_NOWAIT, opener, opener, str(path))
    return path.parent.resolve()


def draw(stdscr, cwd: Path, items: list[Path], cursor: int, show_hidden: bool, by_mtime: bool, message: str) -> None:
    stdscr.erase()
    rows, cols = stdscr.getmaxyx()
    title = f" {cwd} "
    stdscr.addnstr(0, 0, title, max(0, cols - 1), curses.A_REVERSE)
    mode = "mtime" if by_mtime else "name"
    flags = f" {len(items)} items  sort:{mode}  hidden:{'on' if show_hidden else 'off'} "
    stdscr.addnstr(0, max(0, cols - len(flags) - 1), flags, max(0, len(flags)), curses.A_REVERSE)
    top = max(0, cursor - max(1, rows - 4) + 1)
    for line, item in enumerate(items[top : top + max(0, rows - 2)], start=1):
        idx = top + line - 1
        name = item.name + ("/" if item.is_dir() else "")
        attr = curses.A_REVERSE if idx == cursor else curses.A_NORMAL
        stdscr.addnstr(line, 0, name, max(0, cols - 1), attr)
    footer = message or "j/k move  h parent  l/Enter open  Backspace hidden  t sort  q/:q quit"
    stdscr.addnstr(rows - 1, 0, footer.ljust(cols), max(0, cols - 1), curses.A_REVERSE)
    stdscr.refresh()


def command_line(stdscr, prompt: str) -> str:
    rows, cols = stdscr.getmaxyx()
    curses.echo()
    curses.curs_set(1)
    stdscr.addnstr(rows - 1, 0, prompt.ljust(cols), max(0, cols - 1), curses.A_REVERSE)
    stdscr.move(rows - 1, len(prompt))
    try:
        data = stdscr.getstr(rows - 1, len(prompt), max(1, cols - len(prompt) - 1))
        return data.decode(errors="ignore")
    finally:
        curses.noecho()
        curses.curs_set(0)


def curses_main(stdscr, start: Path) -> None:
    curses.curs_set(0)
    stdscr.keypad(True)
    cwd = start.resolve()
    cursor = 0
    show_hidden = False
    by_mtime = False
    message = ""
    while True:
        items = sorted_items(cwd, show_hidden, by_mtime)
        if items:
            cursor = max(0, min(cursor, len(items) - 1))
        else:
            cursor = 0
        draw(stdscr, cwd, items, cursor, show_hidden, by_mtime, message)
        message = ""
        ch = stdscr.getch()
        if ch in (ord("q"), 27):
            return
        if ch == ord(":"):
            cmd = command_line(stdscr, ":")
            if cmd in ("q", "quit"):
                return
            if cmd == "h":
                message = "felix v2.16.1"
            elif cmd == "e":
                continue
            elif cmd == "cd":
                cwd = Path.home().resolve()
                cursor = 0
            elif cmd.startswith("cd "):
                target = (cwd / cmd[3:].strip()).expanduser()
                if target.is_dir():
                    cwd = target.resolve()
                    cursor = 0
                else:
                    message = "Invalid path"
            else:
                os.system(cmd)
            continue
        if ch in (curses.KEY_DOWN, ord("j")):
            cursor += 1
        elif ch in (curses.KEY_UP, ord("k")):
            cursor -= 1
        elif ch in (ord("g"),):
            nxt = stdscr.getch()
            if nxt == ord("g"):
                cursor = 0
        elif ch == ord("G"):
            cursor = max(0, len(items) - 1)
        elif ch in (curses.KEY_LEFT, ord("h")):
            parent = cwd.parent
            if parent != cwd:
                cwd = parent.resolve()
                cursor = 0
        elif ch in (curses.KEY_RIGHT, ord("l"), ord("\n"), ord("\r")) and items:
            cwd = open_item(items[cursor])
            cursor = 0
        elif ch in (curses.KEY_BACKSPACE, 127, 8):
            show_hidden = not show_hidden
        elif ch == ord("t"):
            by_mtime = not by_mtime
        elif ch == ord("Z"):
            nxt = stdscr.getch()
            if nxt in (ord("Z"), ord("Q")):
                return
        elif ch == ord("i"):
            name = command_line(stdscr, "i")
            if name:
                (cwd / name).touch(exist_ok=True)
        elif ch == ord("I"):
            name = command_line(stdscr, "I")
            if name:
                (cwd / name).mkdir(exist_ok=True)


def run_tui(path: Path) -> int:
    if not path.exists():
        print_path_error(f"Invalid path: {path}")
        return 0
    if not path.is_dir():
        print_path_error("Path should be directory.")
        return 0
    try:
        size = os.get_terminal_size()
    except OSError:
        print("Error: Cannot detect terminal size", file=sys.stderr)
        return 0
    if size.columns < 10 or size.lines < 10:
        print("Error: Too small window size", file=sys.stderr)
        return 0
    try:
        curses.wrapper(curses_main, path)
    except curses.error:
        print("Error: Cannot detect terminal size", file=sys.stderr)
    return 0


def main(argv: list[str]) -> int:
    mode, path, logging = parse_args(argv)
    if mode == "help":
        print(HELP, end="")
        return 0
    if mode == "init":
        print(INIT, end="")
        return 0
    if logging:
        log_start()
    assert path is not None
    return run_tui(path)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
