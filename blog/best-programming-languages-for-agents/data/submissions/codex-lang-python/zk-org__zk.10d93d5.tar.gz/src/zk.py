#!/usr/bin/env python3
import argparse
import datetime as _dt
import fnmatch
import json
import os
import random
import re
import shutil
import string
import subprocess
import sys
from pathlib import Path


TOP_HELP = """Usage: zk <command>

Commands:

NOTEBOOK
  A notebook is a directory containing a collection of notes

  init     Create a new notebook in the given directory.
  index    Index the notes to be searchable.

NOTES
  Edit or browse your notes

  new      Create a new note in the given notebook directory.
  list     List notes matching the given criteria.
  graph    Produce a graph of the notes matching the given criteria.
  edit     Edit notes matching the given criteria.
  tag      Manage the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Run "zk <command> --help" for more information on a command."""


CONFIG = """# zk configuration file
#
# Uncomment the properties you want to customize.

[note]
template = "default.md"

[extra]

[format.markdown]
link-format = "wiki"
hashtags = true
colon-tags = false
multiword-tags = false

[tool]

[lsp]

[lsp.diagnostics]
dead-link = "error"

[lsp.completion]

[filter]

[alias]
"""


DEFAULT_TEMPLATE = "# {{title}}\n\n{{content}}\n"


class ZkError(Exception):
    pass


def eprint(*args):
    print(*args, file=sys.stderr)


def split_csv(values):
    out = []
    for val in values or []:
        if val is None:
            continue
        out.extend([x for x in str(val).split(",") if x != ""])
    return out


def parse_global(argv):
    cwd = Path.cwd()
    notebook_dir = None
    no_input = False
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help") and not rest:
            print(TOP_HELP)
            raise SystemExit(0)
        if a == "--no-input":
            no_input = True
        elif a in ("-W", "--working-dir"):
            i += 1
            if i >= len(argv):
                raise ZkError("expected path after " + a)
            cwd = Path(argv[i]).expanduser()
        elif a.startswith("--working-dir="):
            cwd = Path(a.split("=", 1)[1]).expanduser()
        elif a == "--notebook-dir":
            i += 1
            if i >= len(argv):
                raise ZkError("expected path after " + a)
            notebook_dir = Path(argv[i]).expanduser()
        elif a.startswith("--notebook-dir="):
            notebook_dir = Path(a.split("=", 1)[1]).expanduser()
        else:
            rest.append(a)
        i += 1
    cwd = cwd.resolve()
    if notebook_dir is not None and not notebook_dir.is_absolute():
        notebook_dir = (cwd / notebook_dir).resolve()
    return cwd, notebook_dir, no_input, rest


def find_notebook(cwd, explicit=None):
    if explicit:
        return explicit
    p = cwd
    while True:
        if (p / ".zk").is_dir():
            return p
        if p.parent == p:
            return cwd
        p = p.parent


def ensure_notebook(root):
    root.mkdir(parents=True, exist_ok=True)
    (root / ".zk" / "templates").mkdir(parents=True, exist_ok=True)
    cfg = root / ".zk" / "config.toml"
    tpl = root / ".zk" / "templates" / "default.md"
    if not cfg.exists():
        cfg.write_text(CONFIG, encoding="utf-8")
    if not tpl.exists():
        tpl.write_text(DEFAULT_TEMPLATE, encoding="utf-8")


def load_config(root):
    cfg = root / ".zk" / "config.toml"
    data = {}
    if cfg.exists():
        text = cfg.read_text(encoding="utf-8", errors="replace")
        for key, val in re.findall(r'^\s*([A-Za-z0-9_.-]+)\s*=\s*"([^"]*)"', text, re.M):
            data[key] = val
        m = re.search(r'^\s*template\s*=\s*"([^"]*)"', text, re.M)
        if m:
            data["template"] = m.group(1)
        m = re.search(r'^\s*filename\s*=\s*"([^"]*)"', text, re.M)
        if m:
            data["filename"] = m.group(1)
        m = re.search(r'^\s*extension\s*=\s*"([^"]*)"', text, re.M)
        if m:
            data["extension"] = m.group(1)
    return data


def slugify(title):
    s = title.lower()
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s or "untitled"


def rand_id(n=4):
    return "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(n))


def render_template(template, vals):
    now = vals.get("now", _dt.datetime.now())
    text = template
    replacements = {
        "title": vals.get("title", ""),
        "content": vals.get("content", ""),
        "id": vals.get("id", ""),
        "slug": vals.get("slug", ""),
        "date": vals.get("date", now.date().isoformat() if hasattr(now, "date") else str(now)),
    }
    for k, v in replacements.items():
        text = text.replace("{{" + k + "}}", str(v))
        text = text.replace("{{ " + k + " }}", str(v))
    def fmt_date(m):
        fmt = m.group(1).strip().strip('"')
        try:
            return now.strftime(fmt)
        except Exception:
            return now.date().isoformat()
    text = re.sub(r"{{\s*format-date\s+now\s+([^}]+)\s*}}", fmt_date, text)
    text = re.sub(r"{{\s*extra\.([A-Za-z0-9_-]+)\s*}}", lambda m: vals.get("extra", {}).get(m.group(1), ""), text)
    return text


def note_files(root):
    skip = {".git", ".zk"}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in skip and not d.startswith(".zk")]
        for name in filenames:
            if name.lower().endswith((".md", ".markdown", ".txt")):
                p = Path(dirpath) / name
                if p.name == "README.md" and p.parent == root:
                    continue
                yield p


def strip_frontmatter(text):
    if text.startswith("---\n"):
        end = text.find("\n---", 4)
        if end != -1:
            fm = text[4:end]
            return fm, text[end + 4 :].lstrip("\n")
    return "", text


def parse_note(root, path):
    text = path.read_text(encoding="utf-8", errors="replace")
    fm, body = strip_frontmatter(text)
    title = ""
    m = re.search(r"^\s*title\s*:\s*(.+?)\s*$", fm, re.M)
    if m:
        title = m.group(1).strip().strip('"')
    if not title:
        m = re.search(r"^#\s+(.+?)\s*$", body, re.M)
        if m:
            title = m.group(1).strip()
    if not title:
        title = path.stem
    tags = set()
    for m in re.finditer(r"(?<!\w)#([A-Za-z0-9_/-]+)", text):
        tags.add(m.group(1))
    for m in re.finditer(r"tags\s*:\s*\[([^\]]*)\]", fm):
        for t in re.split(r"[, ]+", m.group(1).replace('"', "").replace("'", "")):
            if t:
                tags.add(t.strip("#"))
    links = []
    for m in re.finditer(r"\[\[([^\]|#]+)(?:#[^\]|]*)?(?:\|[^\]]*)?\]\]", text):
        links.append(m.group(1).strip())
    for m in re.finditer(r"\[[^\]]+\]\(([^)#]+)(?:#[^)]*)?\)", text):
        links.append(m.group(1).strip())
    st = path.stat()
    rel = path.relative_to(root).as_posix()
    return {
        "path": rel,
        "abs_path": str(path),
        "filename": path.name,
        "filename-stem": path.stem,
        "title": title,
        "title-or-path": title or rel,
        "content": body,
        "raw": text,
        "tags": sorted(tags),
        "links": links,
        "created": _dt.datetime.fromtimestamp(st.st_ctime).isoformat(timespec="seconds"),
        "modified": _dt.datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
        "word-count": len(re.findall(r"\w+", body)),
    }


def collect(root):
    return [parse_note(root, p) for p in note_files(root)]


def normalize_target(root, target):
    t = target.strip()
    if not t:
        return t
    p = Path(t)
    if p.is_absolute():
        try:
            return p.resolve().relative_to(root).as_posix()
        except Exception:
            return p.name
    return p.as_posix()


def matches_path(note, paths):
    if not paths:
        return True
    p = note["path"]
    for q in paths:
        q = q.rstrip("/")
        if p == q or p.startswith(q + "/") or fnmatch.fnmatch(p, q) or p.startswith(q):
            return True
    return False


def apply_filters(root, notes, args):
    paths = [normalize_target(root, p) for p in getattr(args, "paths", [])]
    notes = [n for n in notes if matches_path(n, paths)]
    excludes = split_csv(getattr(args, "exclude", []))
    if excludes:
        notes = [n for n in notes if not matches_path(n, excludes)]
    tags = [t.strip("#") for t in split_csv(getattr(args, "tag", []))]
    for t in tags:
        notes = [n for n in notes if t in n["tags"]]
    if getattr(args, "tagless", False):
        notes = [n for n in notes if not n["tags"]]
    queries = split_csv(getattr(args, "match", []))
    strategy = getattr(args, "match_strategy", None) or "fts"
    for q in queries:
        if strategy == "re":
            rx = re.compile(q, re.I)
            notes = [n for n in notes if rx.search(n["raw"]) or rx.search(n["title"])]
        elif strategy == "exact":
            notes = [n for n in notes if q in n["raw"] or q in n["title"]]
        else:
            terms = [x.lower() for x in q.split()]
            notes = [n for n in notes if all(t in (n["raw"] + " " + n["title"]).lower() for t in terms)]
    link_to = split_csv(getattr(args, "link_to", []))
    if link_to:
        wanted = {Path(normalize_target(root, x)).stem.lower() for x in link_to}
        notes = [n for n in notes if any(Path(l).stem.lower() in wanted or l.lower() in wanted for l in n["links"])]
    if getattr(args, "orphan", False):
        linked = {Path(l).stem.lower() for n in notes for l in n["links"]}
        notes = [n for n in notes if Path(n["path"]).stem.lower() not in linked and n["title"].lower() not in linked]
    sort_terms = split_csv(getattr(args, "sort", []))
    for term in reversed(sort_terms):
        desc = term.endswith("-")
        key = term.rstrip("+-")
        if key == "random":
            random.shuffle(notes)
            continue
        notes.sort(key=lambda n: str(n.get(key, n.get(key.replace("_", "-"), ""))).lower(), reverse=desc)
    if not sort_terms:
        notes.sort(key=lambda n: n["path"].lower())
    lim = getattr(args, "limit", None)
    if lim is not None:
        try:
            notes = notes[: int(lim)]
        except ValueError:
            pass
    return notes


def format_template(tpl, note):
    aliases = {"path": note["path"], "abs-path": note["abs_path"], "title": note["title"], "title-or-path": note["title-or-path"], "filename": note["filename"], "filename-stem": note["filename-stem"]}
    out = tpl
    for k, v in aliases.items():
        out = out.replace("{{" + k + "}}", str(v)).replace("{{ " + k + " }}", str(v))
    out = out.replace("{{tags}}", " ".join(note["tags"]))
    return out


def format_note(fmt, note):
    if fmt in (None, "oneline"):
        return f"{note['path']} {note['title']}".rstrip()
    if fmt in ("path", "{{path}}"):
        return note["path"]
    if fmt == "short":
        return f"{note['title']}\n{note['path']}"
    if fmt == "medium":
        return f"# {note['title']}\n\n{note['path']}"
    if fmt in ("long", "full"):
        return note["raw"].rstrip("\n")
    if fmt == "json":
        return json.dumps(public_note(note), ensure_ascii=False)
    if fmt == "jsonl":
        return json.dumps(public_note(note), ensure_ascii=False)
    return format_template(fmt, note)


def public_note(n):
    return {k: n[k] for k in ("path", "title", "tags", "links", "created", "modified", "word-count")}


def add_filter_args(p):
    p.add_argument("paths", nargs="*")
    p.add_argument("-i", "--interactive", action="store_true")
    p.add_argument("-n", "--limit")
    p.add_argument("-m", "--match", action="append")
    p.add_argument("-M", "--match-strategy", dest="match_strategy")
    p.add_argument("-x", "--exclude", action="append")
    p.add_argument("-t", "--tag", action="append")
    p.add_argument("--mention", action="append")
    p.add_argument("--mentioned-by", action="append")
    p.add_argument("-l", "--link-to", action="append")
    p.add_argument("--no-link-to", action="append")
    p.add_argument("-L", "--linked-by", action="append")
    p.add_argument("--no-linked-by", action="append")
    p.add_argument("--orphan", action="store_true")
    p.add_argument("--tagless", action="store_true")
    p.add_argument("--missing-backlink", action="store_true")
    p.add_argument("--related", action="append")
    p.add_argument("--max-distance")
    p.add_argument("-r", "--recursive", action="store_true")
    p.add_argument("--created")
    p.add_argument("--created-before")
    p.add_argument("--created-after")
    p.add_argument("--modified")
    p.add_argument("--modified-before")
    p.add_argument("--modified-after")
    p.add_argument("-s", "--sort", action="append")


def cmd_init(root, cwd, argv, no_input):
    p = argparse.ArgumentParser(prog="zk init", description="Create a new notebook in the given directory.")
    p.add_argument("directory", nargs="?", default=".")
    ns = p.parse_args(argv)
    d = Path(ns.directory)
    if not d.is_absolute():
        d = cwd / d
    ensure_notebook(d.resolve())
    return 0


def cmd_index(root, argv):
    p = argparse.ArgumentParser(prog="zk index", description="Index the notes to be searchable.")
    p.add_argument("-f", "--force", action="store_true")
    p.add_argument("-v", "--verbose", action="store_true")
    p.add_argument("-q", "--quiet", action="store_true")
    ns = p.parse_args(argv)
    count = len(collect(root))
    if not ns.quiet:
        print(f"Indexed {count} notes")
    return 0


def cmd_new(root, cwd, argv):
    p = argparse.ArgumentParser(prog="zk new", description="Create a new note in the given notebook directory.")
    p.add_argument("directory", nargs="?", default=".")
    p.add_argument("-i", "--interactive", action="store_true")
    p.add_argument("-t", "--title")
    p.add_argument("--date")
    p.add_argument("-g", "--group")
    p.add_argument("--extra", action="append")
    p.add_argument("--template")
    p.add_argument("-p", "--print-path", action="store_true")
    p.add_argument("-n", "--dry-run", action="store_true")
    p.add_argument("--id")
    ns = p.parse_args(argv)
    ensure_notebook(root)
    cfg = load_config(root)
    title = ns.title or "Untitled"
    content = sys.stdin.read() if ns.interactive or not sys.stdin.isatty() else ""
    note_id = ns.id or rand_id()
    vals = {
        "title": title,
        "content": content.rstrip("\n"),
        "id": note_id,
        "slug": slugify(title),
        "date": ns.date or _dt.date.today().isoformat(),
        "extra": {},
    }
    for item in split_csv(ns.extra):
        if "=" in item:
            k, v = item.split("=", 1)
            vals["extra"][k] = v
    template_path = ns.template or cfg.get("template", "default.md")
    tp = Path(template_path)
    if not tp.is_absolute():
        tp = root / ".zk" / "templates" / template_path
    template = tp.read_text(encoding="utf-8", errors="replace") if tp.exists() else DEFAULT_TEMPLATE
    body = render_template(template, vals)
    fname_tpl = cfg.get("filename", "{{id}}")
    stem = render_template(fname_tpl, vals).strip() or note_id
    ext = cfg.get("extension", "md").lstrip(".")
    target_dir = Path(ns.directory)
    if not target_dir.is_absolute():
        target_dir = cwd / target_dir
    target_dir.mkdir(parents=True, exist_ok=True)
    path = target_dir / f"{stem}.{ext}"
    i = 1
    while path.exists() and not ns.dry_run:
        path = target_dir / f"{stem}-{i}.{ext}"
        i += 1
    rel = path.resolve().relative_to(root).as_posix() if str(path.resolve()).startswith(str(root)) else str(path)
    if ns.dry_run:
        print(body, end="" if body.endswith("\n") else "\n")
        eprint(rel)
    else:
        path.write_text(body, encoding="utf-8")
        if ns.print_path:
            print(rel)
        else:
            edit_paths([path])
    return 0


def cmd_list(root, argv):
    p = argparse.ArgumentParser(prog="zk list", description="List notes matching the given criteria.")
    p.add_argument("-f", "--format", default="oneline")
    p.add_argument("--header", default="")
    p.add_argument("--footer", default="")
    p.add_argument("-d", "--delimiter", default="\n")
    p.add_argument("-0", "--delimiter0", action="store_true")
    p.add_argument("-P", "--no-pager", action="store_true")
    p.add_argument("-q", "--quiet", action="store_true")
    add_filter_args(p)
    ns = p.parse_args(argv)
    notes = apply_filters(root, collect(root), ns)
    if ns.format == "json":
        print(json.dumps([public_note(n) for n in notes], ensure_ascii=False))
    else:
        delim = "\0" if ns.delimiter0 else ns.delimiter.encode("utf-8").decode("unicode_escape")
        pieces = [format_note(ns.format, n) for n in notes]
        sys.stdout.write(ns.header.encode("utf-8").decode("unicode_escape"))
        sys.stdout.write(delim.join(pieces))
        if pieces:
            sys.stdout.write(delim if delim != "\0" else "")
        sys.stdout.write(ns.footer.encode("utf-8").decode("unicode_escape"))
    if not ns.quiet:
        eprint(f"{len(notes)} notes")
    return 0


def cmd_graph(root, argv):
    p = argparse.ArgumentParser(prog="zk graph", description="Produce a graph of the notes matching the given criteria.")
    p.add_argument("-f", "--format", required=True)
    p.add_argument("-q", "--quiet", action="store_true")
    add_filter_args(p)
    ns = p.parse_args(argv)
    notes = apply_filters(root, collect(root), ns)
    if ns.format != "json":
        raise ZkError("invalid graph format: " + ns.format)
    stems = {Path(n["path"]).stem.lower(): n for n in notes}
    links = []
    for n in notes:
        for l in n["links"]:
            target = stems.get(Path(l).stem.lower())
            if target:
                links.append({"source": n["path"], "target": target["path"]})
    print(json.dumps({"notes": [public_note(n) for n in notes], "links": links}, ensure_ascii=False))
    if not ns.quiet:
        eprint(f"{len(notes)} notes")
    return 0


def edit_paths(paths):
    editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not editor:
        return 0
    return subprocess.call(editor.split() + [str(p) for p in paths])


def cmd_edit(root, argv):
    p = argparse.ArgumentParser(prog="zk edit", description="Edit notes matching the given criteria.")
    p.add_argument("-f", "--force", action="store_true")
    add_filter_args(p)
    ns = p.parse_args(argv)
    notes = apply_filters(root, collect(root), ns)
    return edit_paths([root / n["path"] for n in notes])


def cmd_tag(root, argv):
    if not argv or argv[0] in ("-h", "--help"):
        print("""Usage: zk tag <command>

Manage the note tags.

Commands:
  tag list    List all the note tags.""")
        return 0
    if argv[0] != "list":
        raise ZkError("unknown command: " + argv[0])
    p = argparse.ArgumentParser(prog="zk tag list", description="List all the note tags.")
    p.add_argument("-q", "--quiet", action="store_true")
    ns = p.parse_args(argv[1:])
    tags = sorted({t for n in collect(root) for t in n["tags"]})
    for t in tags:
        print(t)
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    try:
        cwd, nb, no_input, rest = parse_global(argv)
        if not rest:
            print(TOP_HELP)
            return 0
        cmd, args = rest[0], rest[1:]
        root = find_notebook(cwd, nb).resolve()
        os.chdir(cwd)
        if cmd == "init":
            return cmd_init(root, cwd, args, no_input)
        if cmd == "index":
            return cmd_index(root, args)
        if cmd == "new":
            return cmd_new(root, cwd, args)
        if cmd == "list":
            return cmd_list(root, args)
        if cmd == "graph":
            return cmd_graph(root, args)
        if cmd == "edit":
            return cmd_edit(root, args)
        if cmd == "tag":
            return cmd_tag(root, args)
        raise ZkError("unknown command: " + cmd)
    except BrokenPipeError:
        return 0
    except ZkError as exc:
        eprint("zk: error:", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
