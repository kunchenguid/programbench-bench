#!/usr/bin/env python3
import sys, re, math, random, colorsys, os
from dataclasses import dataclass

VERSION='pastel 0.11.0'

CSS = {
'aliceblue':'#f0f8ff','antiquewhite':'#faebd7','aqua':'#00ffff','aquamarine':'#7fffd4','azure':'#f0ffff','beige':'#f5f5dc','bisque':'#ffe4c4','black':'#000000','blanchedalmond':'#ffebcd','blue':'#0000ff','blueviolet':'#8a2be2','brown':'#a52a2a','burlywood':'#deb887','cadetblue':'#5f9ea0','chartreuse':'#7fff00','chocolate':'#d2691e','coral':'#ff7f50','cornflowerblue':'#6495ed','cornsilk':'#fff8dc','crimson':'#dc143c','cyan':'#00ffff','darkblue':'#00008b','darkcyan':'#008b8b','darkgoldenrod':'#b8860b','darkgray':'#a9a9a9','darkgreen':'#006400','darkgrey':'#a9a9a9','darkkhaki':'#bdb76b','darkmagenta':'#8b008b','darkolivegreen':'#556b2f','darkorange':'#ff8c00','darkorchid':'#9932cc','darkred':'#8b0000','darksalmon':'#e9967a','darkseagreen':'#8fbc8f','darkslateblue':'#483d8b','darkslategray':'#2f4f4f','darkslategrey':'#2f4f4f','darkturquoise':'#00ced1','darkviolet':'#9400d3','deeppink':'#ff1493','deepskyblue':'#00bfff','dimgray':'#696969','dimgrey':'#696969','dodgerblue':'#1e90ff','firebrick':'#b22222','floralwhite':'#fffaf0','forestgreen':'#228b22','fuchsia':'#ff00ff','gainsboro':'#dcdcdc','ghostwhite':'#f8f8ff','gold':'#ffd700','goldenrod':'#daa520','gray':'#808080','green':'#008000','greenyellow':'#adff2f','grey':'#808080','honeydew':'#f0fff0','hotpink':'#ff69b4','indianred':'#cd5c5c','indigo':'#4b0082','ivory':'#fffff0','khaki':'#f0e68c','lavender':'#e6e6fa','lavenderblush':'#fff0f5','lawngreen':'#7cfc00','lemonchiffon':'#fffacd','lightblue':'#add8e6','lightcoral':'#f08080','lightcyan':'#e0ffff','lightgoldenrodyellow':'#fafad2','lightgray':'#d3d3d3','lightgreen':'#90ee90','lightgrey':'#d3d3d3','lightpink':'#ffb6c1','lightsalmon':'#ffa07a','lightseagreen':'#20b2aa','lightskyblue':'#87cefa','lightslategray':'#778899','lightslategrey':'#778899','lightsteelblue':'#b0c4de','lightyellow':'#ffffe0','lime':'#00ff00','limegreen':'#32cd32','linen':'#faf0e6','magenta':'#ff00ff','maroon':'#800000','mediumaquamarine':'#66cdaa','mediumblue':'#0000cd','mediumorchid':'#ba55d3','mediumpurple':'#9370db','mediumseagreen':'#3cb371','mediumslateblue':'#7b68ee','mediumspringgreen':'#00fa9a','mediumturquoise':'#48d1cc','mediumvioletred':'#c71585','midnightblue':'#191970','mintcream':'#f5fffa','mistyrose':'#ffe4e1','moccasin':'#ffe4b5','navajowhite':'#ffdead','navy':'#000080','oldlace':'#fdf5e6','olive':'#808000','olivedrab':'#6b8e23','orange':'#ffa500','orangered':'#ff4500','orchid':'#da70d6','palegoldenrod':'#eee8aa','palegreen':'#98fb98','paleturquoise':'#afeeee','palevioletred':'#db7093','papayawhip':'#ffefd5','peachpuff':'#ffdab9','peru':'#cd853f','pink':'#ffc0cb','plum':'#dda0dd','powderblue':'#b0e0e6','purple':'#800080','rebeccapurple':'#663399','red':'#ff0000','rosybrown':'#bc8f8f','royalblue':'#4169e1','saddlebrown':'#8b4513','salmon':'#fa8072','sandybrown':'#f4a460','seagreen':'#2e8b57','seashell':'#fff5ee','sienna':'#a0522d','silver':'#c0c0c0','skyblue':'#87ceeb','slateblue':'#6a5acd','slategray':'#708090','slategrey':'#708090','snow':'#fffafa','springgreen':'#00ff7f','steelblue':'#4682b4','tan':'#d2b48c','teal':'#008080','thistle':'#d8bfd8','tomato':'#ff6347','turquoise':'#40e0d0','violet':'#ee82ee','wheat':'#f5deb3','white':'#ffffff','whitesmoke':'#f5f5f5','yellow':'#ffff00','yellowgreen':'#9acd32'
}

@dataclass
class Color:
    r: float; g: float; b: float; a: float=1.0
    def clamp(self):
        self.r=min(1,max(0,self.r)); self.g=min(1,max(0,self.g)); self.b=min(1,max(0,self.b)); self.a=min(1,max(0,self.a)); return self
    def rgb8(self):
        return tuple(int(round(min(1,max(0,x))*255)) for x in (self.r,self.g,self.b))

def die(msg, code=1):
    print(f"[pastel error]: {msg}", file=sys.stderr); sys.exit(code)

def pctnum(s):
    s=s.strip();
    if s.endswith('%'): return float(s[:-1])/100.0
    v=float(s); return v/255.0 if v>1 else v

def alpha_num(s):
    s=s.strip(); return float(s[:-1])/100.0 if s.endswith('%') else float(s)

def parse_color(s):
    orig=s; s=s.strip().lower()
    if s in CSS: s=CSS[s]
    m=re.fullmatch(r'#?([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})', s)
    if m:
        h=m.group(1)
        if len(h) in (3,4):
            vals=[int(ch*2,16) for ch in h]
        else:
            vals=[int(h[i:i+2],16) for i in range(0,len(h),2)]
        a=vals[3]/255 if len(vals)==4 else 1
        return Color(vals[0]/255, vals[1]/255, vals[2]/255, a)
    m=re.fullmatch(r'rgba?\((.*)\)', s)
    if m:
        parts=[p.strip() for p in re.split(r'\s*,\s*',m.group(1))]
        if len(parts) not in (3,4): die(f"Could not parse color '{orig}'")
        vals=[]
        for p in parts[:3]:
            vals.append(float(p[:-1])/100 if p.endswith('%') else float(p)/255)
        return Color(vals[0],vals[1],vals[2], alpha_num(parts[3]) if len(parts)==4 else 1).clamp()
    m=re.fullmatch(r'hsla?\((.*)\)', s)
    if m:
        parts=[p.strip() for p in re.split(r'\s*,\s*',m.group(1))]
        if len(parts) not in (3,4): die(f"Could not parse color '{orig}'")
        h=float(parts[0])%360/360; sat=pctnum(parts[1]); l=pctnum(parts[2])
        r,g,b=colorsys.hls_to_rgb(h,l,sat)
        return Color(r,g,b, alpha_num(parts[3]) if len(parts)==4 else 1).clamp()
    m=re.fullmatch(r'hsva?\((.*)\)', s)
    if m:
        parts=[p.strip() for p in re.split(r'\s*,\s*',m.group(1))]
        h=float(parts[0])%360/360; sat=pctnum(parts[1]); v=pctnum(parts[2])
        r,g,b=colorsys.hsv_to_rgb(h,sat,v)
        return Color(r,g,b, alpha_num(parts[3]) if len(parts)>3 else 1).clamp()
    m=re.fullmatch(r'graya?\((.*)\)', s)
    if m:
        parts=[p.strip() for p in re.split(r'\s*,\s*',m.group(1))]
        g=pctnum(parts[0]); a=alpha_num(parts[1]) if len(parts)>1 else 1
        return Color(g,g,g,a).clamp()
    if ',' in s:
        parts=[p.strip() for p in s.split(',')]
        if len(parts) in (3,4):
            vals=[float(p)/255 for p in parts[:3]]; return Color(vals[0],vals[1],vals[2], alpha_num(parts[3]) if len(parts)==4 else 1).clamp()
    die(f"Could not parse color '{orig}'")

def hsl(c):
    h,l,s=colorsys.rgb_to_hls(c.r,c.g,c.b); return (h*360,s,l)
def hsv(c):
    h,s,v=colorsys.rgb_to_hsv(c.r,c.g,c.b); return (h*360,s,v)
def fmt_angle(x):
    x=(x%360+360)%360
    if abs(x-360)<1e-9: x=0
    return str(int(round(x)))
def fmt_pct(x): return f"{x*100:.1f}%"
def fmt_alpha(a): return f"{a:.3f}"
def out_hsl(c, spaced=False):
    h,s,l=hsl(c); sep=', ' if spaced else ','; pre='hsla' if c.a<0.9995 else 'hsl'
    vals=[fmt_angle(h), fmt_pct(s), fmt_pct(l)]
    if c.a<0.9995: vals.append(fmt_alpha(c.a))
    return pre+'('+sep.join(vals)+')'
def hexout(c):
    r,g,b=c.rgb8(); base=f"#{r:02x}{g:02x}{b:02x}"; 
    return base+(f"{int(round(c.a*255)):02x}" if c.a<0.9995 else '')

def srgb_lin(x): return x/12.92 if x<=0.04045 else ((x+0.055)/1.055)**2.4
def lin_srgb(x): return 12.92*x if x<=0.0031308 else 1.055*(x**(1/2.4))-0.055
def xyz(c):
    r,g,b=[srgb_lin(x) for x in (c.r,c.g,c.b)]
    return (r*0.4124564+g*0.3575761+b*0.1804375, r*0.2126729+g*0.7151522+b*0.0721750, r*0.0193339+g*0.1191920+b*0.9503041)
def lab(c):
    X,Y,Z=xyz(c); X/=0.95047; Z/=1.08883
    def f(t): return t**(1/3) if t>0.008856 else 7.787*t+16/116
    fx,fy,fz=f(X),f(Y),f(Z); return (116*fy-16, 500*(fx-fy), 200*(fy-fz))
def oklab(c):
    r,g,b=[srgb_lin(x) for x in (c.r,c.g,c.b)]
    l=0.4122214708*r+0.5363325363*g+0.0514459929*b
    m=0.2119034982*r+0.6806995451*g+0.1073969566*b
    s=0.0883024619*r+0.2817188376*g+0.6299787005*b
    l_,m_,s_=math.copysign(abs(l)**(1/3),l),math.copysign(abs(m)**(1/3),m),math.copysign(abs(s)**(1/3),s)
    return (0.2104542553*l_+0.7936177850*m_-0.0040720468*s_, 1.9779984951*l_-2.4285922050*m_+0.4505937099*s_, 0.0259040371*l_+0.7827717662*m_-0.8086757660*s_)
def lum(c):
    r,g,b=[srgb_lin(x) for x in (c.r,c.g,c.b)]; return 0.2126*r+0.7152*g+0.0722*b
def brightness(c): return 0.299*c.r+0.587*c.g+0.114*c.b

def fmt_format(t,c):
    r,g,b=c.rgb8()
    if t=='hex': return hexout(c)
    if t=='rgb': return (f"rgba({r}, {g}, {b}, {fmt_alpha(c.a)})" if c.a<0.9995 else f"rgb({r}, {g}, {b})")
    if t=='rgb-float': return (f"rgba({c.r:.3f}, {c.g:.3f}, {c.b:.3f}, {fmt_alpha(c.a)})" if c.a<0.9995 else f"rgb({c.r:.3f}, {c.g:.3f}, {c.b:.3f})")
    if t=='rgb-r': return str(r)
    if t=='rgb-g': return str(g)
    if t=='rgb-b': return str(b)
    if t=='hsl': return out_hsl(c, True)
    if t.startswith('hsl-'):
        h,s,l=hsl(c); return {'hsl-hue':fmt_angle(h),'hsl-saturation':f'{s:.3f}','hsl-lightness':f'{l:.3f}'}[t]
    if t=='hsv':
        h,s,v=hsv(c); vals=[fmt_angle(h),fmt_pct(s),fmt_pct(v)];
        return ('hsva' if c.a<0.9995 else 'hsv')+'('+', '.join(vals+([fmt_alpha(c.a)] if c.a<0.9995 else []))+')'
    if t.startswith('hsv-'):
        h,s,v=hsv(c); return {'hsv-hue':fmt_angle(h),'hsv-saturation':f'{s:.3f}','hsv-value':f'{v:.3f}'}[t]
    if t=='luminance': return f"{lum(c):.3f}"
    if t=='brightness': return f"{brightness(c):.3f}"
    if t=='lab':
        L,a,bv=lab(c); return f"Lab({round(L):.0f}, {round(a):.0f}, {round(bv):.0f})"
    if t in ('lab-a','lab-b'):
        L,a,bv=lab(c); return f"{(a if t=='lab-a' else bv):.3f}"
    if t=='lch':
        L,a,bv=lab(c); C=math.hypot(a,bv); H=(math.degrees(math.atan2(bv,a))+360)%360; return f"LCh({round(L):.0f}, {round(C):.0f}, {round(H):.0f})"
    if t.startswith('lch-'):
        L,a,bv=lab(c); C=math.hypot(a,bv); H=(math.degrees(math.atan2(bv,a))+360)%360; return {'lch-lightness':f'{L:.3f}','lch-chroma':f'{C:.3f}','lch-hue':f'{H:.3f}'}[t]
    if t=='oklab':
        L,a,bv=oklab(c); return f"OkLab({L:.4f}, {a:.4f}, {bv:.4f})"
    if t=='oklch':
        L,a,bv=oklab(c); C=math.hypot(a,bv); H=(math.degrees(math.atan2(bv,a))+360)%360; return f"OkLCh({L:.4f}, {C:.4f}, {H:.4f})"
    if t.startswith('oklab-'):
        L,a,bv=oklab(c); return {'oklab-l':f'{L:.4f}','oklab-a':f'{a:.4f}','oklab-b':f'{bv:.4f}'}[t]
    if t.startswith('oklch-'):
        L,a,bv=oklab(c); C=math.hypot(a,bv); H=(math.degrees(math.atan2(bv,a))+360)%360; return {'oklch-lightness':f'{L:.4f}','oklch-chroma':f'{C:.4f}','oklch-hue':f'{H:.4f}'}[t]
    if t=='cmyk':
        k=1-max(c.r,c.g,c.b)
        if k>=.999999: return 'cmyk(0, 0, 0, 100)'
        cy=(1-c.r-k)/(1-k); ma=(1-c.g-k)/(1-k); ye=(1-c.b-k)/(1-k)
        return f"cmyk({round(cy*100):.0f}, {round(ma*100):.0f}, {round(ye*100):.0f}, {round(k*100):.0f})"
    if t=='name':
        hx=hexout(c)[:7];
        for n,h in CSS.items():
            if h==hx and n not in ('aqua','cyan','fuchsia','magenta','grey','darkgrey','lightgrey','darkslategrey','lightslategrey','slategrey'):
                return n
        return hx
    if t.startswith('ansi-'):
        code=ansi256(c)
        if t=='ansi-8bit-value': return str(code)
        if t in ('ansi-8bit','ansi-8bit-escapecode'): return f"\033[38;5;{code}m"
        if t in ('ansi-24bit','ansi-24bit-escapecode'): return f"\033[38;2;{r};{g};{b}m"
    return hexout(c)

def ansi256(c):
    r,g,b=c.rgb8()
    if r==g==b:
        if r<8: return 16
        if r>248: return 231
        return round((r-8)/247*24)+232
    vals=[0,95,135,175,215,255]
    ri=min(range(6), key=lambda i:abs(vals[i]-r)); gi=min(range(6), key=lambda i:abs(vals[i]-g)); bi=min(range(6), key=lambda i:abs(vals[i]-b))
    return 16+36*ri+6*gi+bi

def get_colors(args):
    if not args:
        return [parse_color(line.rstrip('\n')) for line in sys.stdin if line.strip()]
    res=[]
    for a in args:
        if a=='-':
            line=sys.stdin.readline(); res.append(parse_color(line))
        else: res.append(parse_color(a))
    return res

def print_colors(colors):
    for c in colors: print(out_hsl(c, False))

def set_hsl(c, dh=0, ds=0, dl=0, abs_h=None, abs_s=None, abs_l=None):
    h,s,l=hsl(c); h=(h+dh)%360 if abs_h is None else abs_h%360; s=min(1,max(0,s+ds if abs_s is None else abs_s)); l=min(1,max(0,l+dl if abs_l is None else abs_l))
    r,g,b=colorsys.hls_to_rgb(h/360,l,s); return Color(r,g,b,c.a)

def mix_rgb(c1,c2,f=0.5):
    c=Color(c1.r*f+c2.r*(1-f), c1.g*f+c2.g*(1-f), c1.b*f+c2.b*(1-f), c1.a*f+c2.a*(1-f)).clamp()
    r,g,b=c.rgb8()
    return Color(r/255,g/255,b/255,c.a)

def usage():
    print('A command-line tool to generate, analyze, convert and manipulate colors\n')
    print('Usage: executable [OPTIONS] <COMMAND>\n')
    print('Commands:\n  color       Display information about the given color\n  format      Convert a color to the given format\n  random      Generate a list of random colors\n  help        Print this message or the help of the given subcommand(s)')

def main(argv):
    if not argv or argv[0] in ('-h','--help','help'):
        if argv and argv[0]=='help' and len(argv)>1:
            print(f'Usage: executable {argv[1]} [OPTIONS] [color]...')
        else: usage()
        return 0
    if argv[0]=='--version' or argv[0]=='-V': print(VERSION); return 0
    # strip global options
    a=[]; i=0
    while i<len(argv):
        if argv[i] in ('--color-mode','-m','--color-picker') and i+1<len(argv): i+=2
        elif argv[i].startswith('--color-mode=') or argv[i].startswith('--color-picker=') or argv[i] in ('--force-color','-f'): i+=1
        else: a.append(argv[i]); i+=1
    if not a: usage(); return 0
    cmd=a[0]; args=a[1:]
    try:
        if cmd in ('color','format'):
            typ='hex' if cmd=='format' else None
            if cmd=='format' and args and not looks_color(args[0]): typ=args.pop(0)
            cs=get_colors(args)
            for c in cs: print(fmt_format(typ,c) if cmd=='format' else out_hsl(c,False))
        elif cmd in ('lighten','darken','saturate','desaturate','rotate'):
            if not args: die('Missing required argument')
            amt=float(args[0]); cs=get_colors(args[1:])
            if cmd=='lighten': print_colors([set_hsl(c,dl=amt) for c in cs])
            elif cmd=='darken': print_colors([set_hsl(c,dl=-amt) for c in cs])
            elif cmd=='saturate': print_colors([set_hsl(c,ds=amt) for c in cs])
            elif cmd=='desaturate': print_colors([set_hsl(c,ds=-amt) for c in cs])
            else: print_colors([set_hsl(c,dh=amt) for c in cs])
        elif cmd=='complement': print_colors([set_hsl(c,dh=180) for c in get_colors(args)])
        elif cmd=='gray':
            if not args: die('Missing required argument')
            l=float(args[0]); print(out_hsl(Color(l,l,l),False))
        elif cmd=='to-gray':
            for c in get_colors(args):
                y=lum(c)
                lo,hi=0,1
                for _ in range(30):
                    mid=(lo+hi)/2
                    if lum(Color(mid,mid,mid))<y: lo=mid
                    else: hi=mid
                v=int(round(((lo+hi)/2)*255))/255
                print(out_hsl(Color(v,v,v,c.a),False))
        elif cmd=='textcolor':
            for c in get_colors(args): print(out_hsl(Color(0,0,0) if lum(c)>0.179 else Color(1,1,1),False))
        elif cmd=='mix':
            f=.5; space='Lab'; rem=[]; i=0
            while i<len(args):
                if args[i] in ('-f','--fraction'): f=float(args[i+1]); i+=2
                elif args[i].startswith('--fraction='): f=float(args[i].split('=',1)[1]); i+=1
                elif args[i] in ('-s','--colorspace'): space=args[i+1]; i+=2
                elif args[i].startswith('--colorspace='): space=args[i].split('=',1)[1]; i+=1
                else: rem.append(args[i]); i+=1
            if not rem: die('Missing required argument')
            base=parse_color(rem[0]); others=get_colors(rem[1:])
            for c in others: print(out_hsl(mix_rgb(base,c,f),False))
        elif cmd=='gradient':
            n=10; rem=[]; i=0
            while i<len(args):
                if args[i] in ('-n','--number'): n=int(args[i+1]); i+=2
                elif args[i].startswith('--number='): n=int(args[i].split('=',1)[1]); i+=1
                elif args[i] in ('-s','--colorspace'): i+=2
                elif args[i].startswith('--colorspace='): i+=1
                else: rem.append(args[i]); i+=1
            stops=[parse_color(x) for x in rem]
            if len(stops)<2: die('At least two colors required')
            for j in range(n):
                t=j/(n-1) if n>1 else 0; seg=min(int(t*(len(stops)-1)),len(stops)-2); local=t*(len(stops)-1)-seg
                print(out_hsl(mix_rgb(stops[seg+1],stops[seg],local),False))
        elif cmd=='random':
            n=10; strat='vivid'; i=0
            while i<len(args):
                if args[i] in ('-n','--number'): n=int(args[i+1]); i+=2
                elif args[i].startswith('--number='): n=int(args[i].split('=',1)[1]); i+=1
                elif args[i] in ('-s','--strategy'): strat=args[i+1]; i+=2
                elif args[i].startswith('--strategy='): strat=args[i].split('=',1)[1]; i+=1
                else: i+=1
            for _ in range(n):
                if strat=='gray': v=random.random(); c=Color(v,v,v)
                elif strat=='rgb': c=Color(random.random(),random.random(),random.random())
                else:
                    h=random.random(); s=random.uniform(.5,1); l=random.uniform(.35,.75); r,g,b=colorsys.hls_to_rgb(h,l,s); c=Color(r,g,b)
                print(out_hsl(c,False))
        elif cmd=='distinct':
            n=10
            if args and re.fullmatch(r'\d+',args[0]): n=int(args[0])
            for k in range(n):
                r,g,b=colorsys.hls_to_rgb((k*0.61803398875)%1,.55,.8); print(out_hsl(Color(r,g,b),False))
        elif cmd=='list':
            names=list(dict.fromkeys(CSS.keys()))
            for n in sorted(names, key=lambda x: hsl(parse_color(x))[0]): print(n)
        elif cmd=='sort-by':
            reverse='-r' in args or '--reverse' in args; unique='-u' in args or '--unique' in args
            rem=[x for x in args if x not in ('-r','--reverse','-u','--unique')]
            order='hue'
            if rem and rem[0] in ('brightness','luminance','hue','chroma','random'): order=rem.pop(0)
            cs=get_colors(rem)
            if unique:
                seen=set(); out=[]
                for c in cs:
                    if c.rgb8() not in seen: seen.add(c.rgb8()); out.append(c)
                cs=out
            key=lambda c: {'brightness':brightness(c),'luminance':lum(c),'hue':hsl(c)[0],'chroma':lab_chroma(c),'random':random.random()}[order]
            print_colors(sorted(cs,key=key, reverse=reverse))
        elif cmd=='set':
            prop,val=args[0],float(args[1]); cs=get_colors(args[2:]); out=[]
            for c in cs:
                if prop in ('hsl-hue','hue'): out.append(set_hsl(c,abs_h=val))
                elif prop in ('hsl-saturation','chroma'): out.append(set_hsl(c,abs_s=val))
                elif prop in ('hsl-lightness','lightness'): out.append(set_hsl(c,abs_l=val))
                elif prop=='red': out.append(Color(val/255,c.g,c.b,c.a).clamp())
                elif prop=='green': out.append(Color(c.r,val/255,c.b,c.a).clamp())
                elif prop=='blue': out.append(Color(c.r,c.g,val/255,c.a).clamp())
                elif prop=='alpha': out.append(Color(c.r,c.g,c.b,val).clamp())
                else: out.append(c)
            print_colors(out)
        elif cmd=='paint':
            # keep visible behavior useful; emit ANSI only when color is forced or stdout is tty
            bg=None; styles=[]; no_nl=False; rem=[]; i=0
            while i<len(args):
                if args[i] in ('-o','--on'): bg=args[i+1]; i+=2
                elif args[i] in ('-b','--bold'): styles.append('1'); i+=1
                elif args[i] in ('-i','--italic'): styles.append('3'); i+=1
                elif args[i] in ('-u','--underline'): styles.append('4'); i+=1
                elif args[i] in ('-n','--no-newline'): no_nl=True; i+=1
                else: rem.append(args[i]); i+=1
            if not rem: die('Missing color')
            fg=parse_color(sys.stdin.readline() if rem[0]=='-' else rem[0]); text=' '.join(rem[1:]) if len(rem)>1 else sys.stdin.read()
            if sys.stdout.isatty() or os.environ.get('CLICOLOR_FORCE'):
                r,g,b=fg.rgb8(); seq=styles+[f'38;2;{r};{g};{b}']
                if bg: br,bg2,bb=parse_color(bg).rgb8(); seq.append(f'48;2;{br};{bg2};{bb}')
                text='\033['+';'.join(seq)+'m'+text+'\033[0m'
            print(text, end='' if no_nl else '\n')
        elif cmd=='colorcheck': print('Your terminal supports 24-bit colors.' if sys.stdout.isatty() else 'This script should display smooth color gradients if your terminal supports truecolor.')
        elif cmd=='colorblind':
            typ=args[0];
            for c in get_colors(args[1:]): print(out_hsl(colorblind(c,typ),False))
        else: die(f"unrecognized subcommand '{cmd}'")
    except ValueError as e:
        die(str(e))
    return 0

def looks_color(x):
    if x.lower() in CSS or x=='-': return True
    return bool(re.match(r'#?[0-9a-fA-F]{3,8}$|rgba?\(|hsla?\(|hsva?\(|graya?\(|.*,.*,', x))
def lab_chroma(c):
    L,a,b=lab(c); return math.hypot(a,b)
def colorblind(c,typ):
    r,g,b=c.r,c.g,c.b
    mats={
        'prot':((.567,.433,0),(.558,.442,0),(0,.242,.758)),
        'deuter':((.625,.375,0),(.7,.3,0),(0,.3,.7)),
        'trit':((.95,.05,0),(0,.433,.567),(0,.475,.525)),
    }; m=mats.get(typ,mats.get(typ[:4],mats['deuter']))
    return Color(r*m[0][0]+g*m[0][1]+b*m[0][2], r*m[1][0]+g*m[1][1]+b*m[1][2], r*m[2][0]+g*m[2][1]+b*m[2][2], c.a).clamp()

if __name__=='__main__': sys.exit(main(sys.argv[1:]))
