#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
from collections import defaultdict

HELP = """Usage:
    go test ./... -json | tparse [options...]
    go test [packages...] -json | tparse [options...]
    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out

Options:
    -h                 Show help.
    -v                 Show version.
    -all               Display table event for pass and skip. (Failed items always displayed)
    -pass              Display table for passed tests.
    -skip              Display table for skipped tests.
    -notests           Display packages containing no test files or empty test files.
    -smallscreen       Split subtest names vertically to fit on smaller screens.
    -slow              Number of slowest tests to display. Default is 0, display all.
    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.
    -nocolor           Disable all colors. (NO_COLOR also supported)
    -format            The output format for tables [basic, plain, markdown]. Default is basic.
    -file              Read test output from a file.
    -follow            Follow raw output from go test to stdout.
    -follow-output     Write raw output from go test to a file (takes precedence over -follow).
    -include-timestamp Include timestamps in follow output. 
    -progress          Print a single summary line for each package. Useful for long running test suites.
    -compare           Compare against a previous test output file. (experimental)
    -trimpath          Remove path prefix from package names in output, simplifying their display.
"""

ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
COVER_RE = re.compile(r"coverage:\s+([0-9.]+%)")


class Parser(argparse.ArgumentParser):
    def error(self, message):
        sys.stderr.write(f"error: {message}\n")
        sys.exit(2)


def parse_args(argv):
    p = Parser(add_help=False)
    p.add_argument("--help", dest="h", action="store_true")
    p.add_argument("--version", dest="v", action="store_true")
    p.add_argument("-h", action="store_true")
    p.add_argument("-v", action="store_true")
    p.add_argument("-all", action="store_true")
    p.add_argument("-pass", dest="show_pass", action="store_true")
    p.add_argument("-skip", dest="show_skip", action="store_true")
    p.add_argument("-notests", action="store_true")
    p.add_argument("-smallscreen", action="store_true")
    p.add_argument("-slow", type=int, default=0)
    p.add_argument("-sort", choices=["name", "elapsed", "cover"], default="name")
    p.add_argument("-nocolor", action="store_true")
    p.add_argument("-format", choices=["basic", "plain", "markdown"], default="basic")
    p.add_argument("-file")
    p.add_argument("-follow", action="store_true")
    p.add_argument("-follow-output")
    p.add_argument("-include-timestamp", action="store_true")
    p.add_argument("-progress", action="store_true")
    p.add_argument("-compare")
    p.add_argument("-trimpath", action="store_true")
    ns, rest = p.parse_known_args(argv)
    if rest:
        p.error("unknown arguments: " + " ".join(rest))
    return ns


def strip_ansi(s):
    return ANSI_RE.sub("", s)


def disp_pkg(pkg, opts):
    if not pkg:
        return ""
    if opts.trimpath or opts.smallscreen:
        return pkg.rstrip("/").split("/")[-1]
    return pkg


def read_events(opts):
    if opts.file:
        fh = open(opts.file, "r", encoding="utf-8", errors="replace")
    else:
        fh = sys.stdin
    outfh = None
    if opts.follow_output:
        outfh = open(opts.follow_output, "w", encoding="utf-8")
    events = []
    parse_errors = 0
    try:
        for line in fh:
            if not line.strip():
                continue
            try:
                ev = json.loads(line)
            except Exception:
                parse_errors += 1
                continue
            events.append(ev)
            if ev.get("Action") == "output":
                text = ev.get("Output", "")
                if opts.include_timestamp and ev.get("Time"):
                    text = ev.get("Time") + " " + text
                if opts.follow_output:
                    outfh.write(text)
                elif opts.follow:
                    sys.stdout.write(text)
        if outfh:
            outfh.close()
    finally:
        if opts.file and fh:
            fh.close()
    return events, parse_errors


def status_of(action):
    return {"pass": "PASS", "fail": "FAIL", "skip": "SKIP"}.get(action, "")


def elapsed_test(v):
    try:
        return f"{float(v):.2f}"
    except Exception:
        return "0.00"


def elapsed_pkg(v):
    try:
        return f"{float(v):.2f}s"
    except Exception:
        return "0.00s"


def center(s, w):
    s = str(s)
    pad = max(0, w - len(s))
    return " " * (pad // 2) + s + " " * (pad - pad // 2)


def basic_table(headers, rows):
    if not rows:
        return ""
    widths = [len(h) for h in headers]
    for r in rows:
        for i, c in enumerate(r):
            for part in str(c).splitlines() or [""]:
                widths[i] = max(widths[i], len(part))
    top = "╭" + "┬".join("─" * (w + 2) for w in widths) + "╮"
    sep = "├" + "┼".join("─" * (w + 2) for w in widths) + "┤"
    bot = "╰" + "┴".join("─" * (w + 2) for w in widths) + "╯"
    lines = [top, "│ " + " │ ".join(center(h, widths[i]) for i, h in enumerate(headers)) + " │", sep]
    for r in rows:
        cells = [str(x).splitlines() or [""] for x in r]
        height = max(len(c) for c in cells)
        for j in range(height):
            vals = [center(cells[i][j] if j < len(cells[i]) else "", widths[i]) for i in range(len(headers))]
            lines.append("│ " + " │ ".join(vals) + " │")
    lines.append(bot)
    return "\n".join(lines)


def plain_table(headers, rows):
    if not rows:
        return ""
    widths = [len(h) for h in headers]
    for r in rows:
        for i, c in enumerate(r):
            widths[i] = max(widths[i], len(str(c)))
    lines = ["  " + "   ".join(center(h, widths[i]) for i, h in enumerate(headers)) + "  "]
    lines.append("  " + "   ".join(" " * widths[i] for i in range(len(headers))) + "  ")
    for r in rows:
        lines.append("  " + "   ".join(center(str(c), widths[i]) for i, c in enumerate(r)) + "  ")
    return "\n".join(lines)


def markdown_table(headers, rows):
    if not rows:
        return ""
    widths = [len(h) for h in headers]
    for r in rows:
        for i, c in enumerate(r):
            widths[i] = max(widths[i], len(str(c)))
    lines = ["| " + " | ".join(center(h, widths[i]) for i, h in enumerate(headers)) + " |"]
    lines.append("|" + "|".join("-" * (w + 2) for w in widths) + "|")
    for r in rows:
        lines.append("| " + " | ".join(center(str(c), widths[i]) for i, c in enumerate(r)) + " |")
    return "\n".join(lines)


def render_table(headers, rows, opts):
    if opts.format == "plain":
        return plain_table(headers, rows)
    if opts.format == "markdown":
        return markdown_table(headers, rows)
    return basic_table(headers, rows)


def fail_banner(pkg, opts):
    if opts.format == "markdown":
        return f"## FAIL • {disp_pkg(pkg, opts)}"
    text = f"   FAIL  package: {disp_pkg(pkg, opts)}   "
    return "┏" + "━" * len(text) + "┓\n┃" + text + "┃\n┗" + "━" * len(text) + "┛"


def build_model(events, opts):
    packages = {}
    tests = {}
    outputs = defaultdict(list)
    pkg_outputs = defaultdict(list)
    parsable = False
    for ev in events:
        action = ev.get("Action", "")
        pkg = ev.get("Package", "")
        test = ev.get("Test", "")
        if action:
            parsable = True
        packages.setdefault(pkg, {"package": pkg, "status": "", "elapsed": 0.0, "cover": "--", "pass": 0, "fail": 0, "skip": 0, "notests": False})
        if action == "output":
            out = ev.get("Output", "")
            if test:
                outputs[(pkg, test)].append(out)
            else:
                pkg_outputs[pkg].append(out)
            m = COVER_RE.search(out)
            if m:
                packages[pkg]["cover"] = m.group(1)
            if "[no test files]" in out or "[no tests to run]" in out:
                packages[pkg]["notests"] = True
            continue
        if test and action in ("pass", "fail", "skip"):
            tests[(pkg, test)] = {"package": pkg, "test": test, "status": status_of(action), "action": action, "elapsed": float(ev.get("Elapsed") or 0), "idx": len(tests)}
        elif not test and action in ("pass", "fail", "skip"):
            packages[pkg]["status"] = status_of(action)
            packages[pkg]["elapsed"] = float(ev.get("Elapsed") or 0)
    for t in tests.values():
        key = t["action"]
        if key in packages[t["package"]]:
            packages[t["package"]][key] += 1
    for pkg, p in packages.items():
        if not p["status"] and p["notests"]:
            p["status"] = ""
        if p["notests"] and p["skip"] == 0 and not any(t["package"] == pkg for t in tests.values()):
            p["skip"] = 1
    return parsable, list(packages.values()), list(tests.values()), outputs, pkg_outputs


def sort_key(kind, item):
    if kind == "elapsed":
        return (-float(item.get("elapsed", 0)), item.get("package", ""), item.get("test", ""))
    if kind == "cover":
        c = item.get("cover", "--")
        try:
            cv = -float(str(c).rstrip("%"))
        except Exception:
            cv = 999999
        return (cv, item.get("package", ""), item.get("test", ""))
    return (item.get("idx", 0),)


def package_rows(packages, opts):
    rows = []
    items = list(packages)
    if opts.sort in ("elapsed", "cover"):
        items = sorted(items, key=lambda x: sort_key(opts.sort, x))
    for p in items:
        if p.get("notests") and not opts.notests and p["status"] == "":
            pass
        rows.append([p["status"], elapsed_pkg(p["elapsed"]), disp_pkg(p["package"], opts), p["cover"], str(p["pass"]), str(p["fail"]), str(p["skip"])])
    return rows


def selected_tests(tests, opts):
    out = []
    for t in tests:
        if t["status"] == "FAIL" or opts.all or (opts.show_pass and t["status"] == "PASS") or (opts.show_skip and t["status"] == "SKIP"):
            out.append(t)
    if opts.sort in ("elapsed", "cover"):
        out.sort(key=lambda x: sort_key(opts.sort, x))
    if opts.slow and opts.sort == "elapsed":
        out = out[: opts.slow]
    return out


def test_rows(tests, opts):
    return [[t["status"], elapsed_test(t["elapsed"]), t["test"], disp_pkg(t["package"], opts)] for t in tests]


def failure_output(pkg, tests, outputs, pkg_outputs):
    chunks = []
    for t in tests:
        if t["package"] == pkg and t["status"] == "FAIL":
            lines = outputs.get((pkg, t["test"]), [])
            filtered = []
            for line in lines:
                if line.startswith("=== RUN") or line.startswith("--- FAIL") or line.startswith("--- PASS") or line.startswith("--- SKIP"):
                    continue
                filtered.append(line)
            chunks.append("".join(filtered).rstrip("\n"))
    if not chunks:
        filtered = []
        for line in pkg_outputs.get(pkg, []):
            if not line.startswith("FAIL\t") and not line.startswith("ok  \t") and not line.startswith("?   \t"):
                filtered.append(line)
        if filtered:
            chunks.append("".join(filtered).rstrip("\n"))
    return "\n".join(c for c in chunks if c)


def compare_summary(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            count = sum(1 for line in f if line.strip().startswith("{"))
        return f"\nCompared against {path} ({count} events)\n"
    except Exception as e:
        return f"\nUnable to compare against {path}: {e}\n"


def main(argv):
    opts = parse_args(argv)
    if opts.h:
        sys.stdout.write(HELP)
        return 0
    if opts.v:
        print("tparse version: (devel)")
        return 0
    events, parse_errors = read_events(opts)
    parsable, packages, tests, outputs, pkg_outputs = build_model(events, opts)
    if not parsable:
        print("no parsable events: Make sure to run go test with -json flag")
        return 1
    failed = any(p["status"] == "FAIL" for p in packages) or any(t["status"] == "FAIL" for t in tests)
    if opts.progress:
        for p in sorted(packages, key=lambda x: x["package"]):
            st = p["status"] or "SKIP"
            print(f"[{st}]\t{elapsed_pkg(p['elapsed']):>9}\t{disp_pkg(p['package'], opts)}")
    selected = selected_tests(tests, opts)
    if selected:
        if opts.format == "markdown":
            bypkg = defaultdict(list)
            for t in selected:
                bypkg[t["package"]].append(t)
            for pkg in sorted(bypkg):
                ts = bypkg[pkg]
                passed = sum(1 for t in ts if t["status"] == "PASS")
                skipped = sum(1 for t in ts if t["status"] == "SKIP")
                failedn = sum(1 for t in ts if t["status"] == "FAIL")
                print(f"## 📦 Package **`{disp_pkg(pkg, opts)}`**\n")
                print(f"Tests: ✓ {passed} passed | {skipped} skipped | {failedn} failed\n")
                print("<details>\n\n<summary>Click for test summary</summary>\n")
                print(render_table(["Status", "Elapsed", "Test"], [[t["status"], elapsed_test(t["elapsed"]), t["test"]] for t in ts], opts))
                print("</details>\n")
        else:
            print(render_table(["Status", "Elapsed", "Test", "Package"], test_rows(selected, opts), opts))
    for p in sorted(packages, key=lambda x: x["package"]):
        if p["status"] == "FAIL":
            print(fail_banner(p["package"], opts))
            body = failure_output(p["package"], tests, outputs, pkg_outputs)
            if opts.format == "markdown":
                print("\n```\n")
                if body:
                    print(body)
                print("\n```")
            else:
                print("\n")
                if body:
                    print(body)
                print()
    rows = package_rows(packages, opts)
    if rows:
        print(render_table(["Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"], rows, opts))
    if opts.compare:
        sys.stdout.write(compare_summary(opts.compare))
    if parse_errors and not events:
        return 1
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
