#!/usr/bin/env python3
import csv
import datetime as _dt
import json
import os
import re
import shlex
import sqlite3
import sys
import zipfile
import xml.etree.ElementTree as ET


HELP = """dsq (Version latest) - commandline SQL engine for data files

Usage:  dsq [file...] $query
        dsq $file [query]
        cat $file | dsq -s $filetype [query]
        dsq $file -f $queryfile

dsq is a tool for running SQL on one or more data files. It uses
SQLite's SQL dialect. Files as tables are accessible via "{N}" where N
is the 0-based index of the file in the commandline.

The shorthand "{}" is replaced with "{0}".

Examples:

    # This simply dumps the CSV as JSON
    $ dsq test.csv

    # This dumps the first 10 rows of the parquet file as JSON.
    $ dsq data.parquet "SELECT * FROM {} LIMIT 10"

    # This joins two datasets of differing origin types (CSV and JSON).
    $ dsq testdata/join/users.csv testdata/join/ages.json \\
          "select {0}.name, {1}.age from {0} join {1} on {0}.id = {1}.id"

See the repo for more details: https://github.com/multiprocessio/dsq"""


def die(msg, code=1):
    print(msg, file=sys.stderr if msg.startswith("sqlite") else sys.stdout)
    raise SystemExit(code)


def mimetype(path, forced=None):
    if forced:
        return forced.lower()
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    if ext in ("jsonl", "ndjson"):
        return "ndjson"
    if ext in ("tsv", "tab"):
        return "tsv"
    if ext in ("csv", "json", "parquet", "xlsx", "ods", "logfmt"):
        return ext
    die(f"Unknown mimetype for file: {path}.")


def read_text(path):
    if path == "-":
        return sys.stdin.read()
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return f.read()


def load_csv_text(text, delimiter=","):
    rows = list(csv.reader(text.splitlines(), delimiter=delimiter))
    if not rows:
        return []
    headers = [h if h != "" else f"column{idx+1}" for idx, h in enumerate(rows[0])]
    out = []
    for row in rows[1:]:
        if not row:
            continue
        if len(row) < len(headers):
            row = row + [""] * (len(headers) - len(row))
        out.append({headers[i]: row[i] if i < len(row) else "" for i in range(len(headers))})
    return out


def load_json_text(text):
    if not text.strip():
        return []
    return json.loads(text)


def load_ndjson_text(text):
    return [json.loads(line) for line in text.splitlines() if line.strip()]


def load_logfmt_text(text):
    out = []
    for line in text.splitlines():
        if not line.strip():
            continue
        row = {}
        for part in shlex.split(line, posix=True):
            if "=" in part:
                k, v = part.split("=", 1)
                row[k] = v
        out.append(row)
    return out


def xlsx_col(cell_ref):
    m = re.match(r"([A-Z]+)", cell_ref or "")
    if not m:
        return 0
    n = 0
    for ch in m.group(1):
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def parse_xlsx(path):
    ns = {"a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
          "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
    relns = {"pr": "http://schemas.openxmlformats.org/package/2006/relationships"}
    with zipfile.ZipFile(path) as z:
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall("a:si", ns):
                shared.append("".join(t.text or "" for t in si.findall(".//a:t", ns)))
        date_styles = set()
        if "xl/styles.xml" in z.namelist():
            styles = ET.fromstring(z.read("xl/styles.xml"))
            custom = {}
            for n in styles.findall("a:numFmts/a:numFmt", ns):
                custom[n.get("numFmtId")] = n.get("formatCode", "").lower()
            builtin_dates = {14, 15, 16, 17, 22, 27, 30, 36, 50, 57}
            for idx, xf in enumerate(styles.findall("a:cellXfs/a:xf", ns)):
                nf = xf.get("numFmtId")
                if nf and (int(nf) in builtin_dates or any(s in custom.get(nf, "") for s in ("yy", "dd", "mm"))):
                    date_styles.add(str(idx))
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        relroot = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        rels = {r.get("Id"): r.get("Target") for r in relroot.findall("pr:Relationship", relns)}
        result = {}
        for sheet in wb.findall("a:sheets/a:sheet", ns):
            name = sheet.get("name")
            target = rels.get(sheet.get("{%s}id" % ns["r"]), "")
            spath = "xl/" + target.lstrip("/")
            root = ET.fromstring(z.read(spath))
            matrix = []
            for row in root.findall(".//a:sheetData/a:row", ns):
                vals = []
                for c in row.findall("a:c", ns):
                    idx = xlsx_col(c.get("r"))
                    while len(vals) <= idx:
                        vals.append("")
                    typ = c.get("t")
                    v = c.find("a:v", ns)
                    if typ == "inlineStr":
                        val = "".join(t.text or "" for t in c.findall(".//a:t", ns))
                    elif v is None:
                        val = ""
                    elif typ == "s":
                        val = shared[int(v.text)]
                    elif typ == "b":
                        val = "TRUE" if v.text == "1" else "FALSE"
                    else:
                        val = v.text or ""
                        if c.get("s") in date_styles:
                            try:
                                base = _dt.datetime(1899, 12, 30)
                                d = base + _dt.timedelta(days=float(val))
                                val = f"{d.month:02d}-{d.day:02d}-{str(d.year)[2:]}"
                            except Exception:
                                pass
                    vals[idx] = str(val)
                matrix.append(vals)
            if not matrix:
                result[name] = []
                continue
            headers = [str(x) for x in matrix[0]]
            rows = []
            for vals in matrix[1:]:
                if not any(str(v) for v in vals):
                    continue
                vals += [""] * (len(headers) - len(vals))
                rows.append({headers[i]: vals[i] if i < len(vals) else "" for i in range(len(headers))})
            result[name] = rows
        return next(iter(result.values())) if len(result) == 1 else result


def load_parquet(path):
    try:
        import pyarrow.parquet as pq
        import pyarrow as pa
    except Exception as e:
        die(f"parquet support unavailable: {e}")
    table = pq.read_table(path)
    cols = {}
    for field, col in zip(table.schema, table.itercolumns()):
        if pa.types.is_timestamp(field.type):
            vals = col.cast(pa.int64()).to_pylist()
            unit = field.type.unit
            if unit == "s":
                vals = [None if v is None else v * 1000 for v in vals]
            elif unit == "us":
                vals = [None if v is None else v // 1000 for v in vals]
            elif unit == "ns":
                vals = [None if v is None else v // 1000000 for v in vals]
            cols[field.name] = vals
        else:
            cols[field.name] = col.to_pylist()
    names = table.schema.names
    return [{name: cols[name][i] for name in names} for i in range(table.num_rows)]


def load_ods(path):
    ns = {"office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
          "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
          "text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0"}
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("content.xml"))
    sheets = {}
    for table in root.findall(".//table:table", ns):
        matrix = []
        for tr in table.findall("table:table-row", ns):
            vals = []
            for tc in tr.findall("table:table-cell", ns):
                repeat = int(tc.get("{%s}number-columns-repeated" % ns["table"], "1"))
                text = " ".join("".join(p.itertext()) for p in tc.findall("text:p", ns))
                vals.extend([text] * min(repeat, 50))
            if any(vals):
                matrix.append(vals)
        if matrix:
            headers = matrix[0]
            sheets[table.get("{%s}name" % ns["table"], "Sheet")] = [
                {headers[i]: (r[i] if i < len(r) else "") for i in range(len(headers))}
                for r in matrix[1:] if any(r)
            ]
    return next(iter(sheets.values())) if len(sheets) == 1 else sheets


def load_path(path, forced=None):
    fmt = mimetype(path, forced)
    if path == "-":
        text = sys.stdin.read()
    if fmt == "csv":
        return load_csv_text(text if path == "-" else read_text(path), ",")
    if fmt == "tsv":
        return load_csv_text(text if path == "-" else read_text(path), "\t")
    if fmt == "json":
        return load_json_text(text if path == "-" else read_text(path))
    if fmt == "ndjson":
        return load_ndjson_text(text if path == "-" else read_text(path))
    if fmt == "logfmt":
        return load_logfmt_text(read_text(path))
    if fmt == "parquet":
        if path == "-":
            die("parquet from stdin is not supported.")
        return load_parquet(path)
    if fmt == "xlsx":
        return parse_xlsx(path)
    if fmt == "ods":
        return load_ods(path)
    die(f"Unknown mimetype for file: {path}.")


def json_type(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return "number"
    if isinstance(v, list):
        return "array"
    if isinstance(v, dict):
        return "object"
    return "string"


def scalar_shape(t):
    return {"kind": "scalar", "scalar": t}


def infer_shape(obj):
    if isinstance(obj, list):
        keys = []
        seen = set()
        for row in obj:
            if isinstance(row, dict):
                for k in row:
                    if k not in seen:
                        seen.add(k); keys.append(k)
        fields = {}
        for k in keys:
            types = []
            for row in obj:
                t = json_type(row.get(k) if isinstance(row, dict) else None)
                if t not in types:
                    types.append(t)
            if len(types) == 1:
                fields[k] = scalar_shape(types[0])
            else:
                non_null = [t for t in types if t != "null"]
                order = non_null + (["null"] if "null" in types else [])
                fields[k] = {"kind": "varied", "varied": [scalar_shape(t) for t in order]}
        return {"kind": "array", "array": {"kind": "object", "object": fields}}
    if isinstance(obj, dict):
        return {"kind": "object", "object": {k: infer_shape(v) for k, v in obj.items()}}
    return scalar_shape(json_type(obj))


def ensure_rows(data, name):
    if not isinstance(data, list) or any(not isinstance(x, dict) for x in data):
        die(f"Input is not an array of objects: {name}.")
    return data


def create_table(conn, table, rows, text_affinity=False):
    keys, seen = [], set()
    for row in rows:
        for k in row:
            if k not in seen:
                seen.add(k); keys.append(k)
    if not keys:
        keys = ["value"]
    decl = " TEXT" if text_affinity else ""
    qcols = ", ".join('"%s"%s' % (k.replace('"', '""'), decl) for k in keys)
    conn.execute(f'CREATE TABLE "{table}" ({qcols})')
    ph = ",".join("?" for _ in keys)
    conn.executemany(
        f'INSERT INTO "{table}" VALUES ({ph})',
        [[normalize_sql_value(row.get(k)) for k in keys] for row in rows],
    )


def normalize_sql_value(v):
    if isinstance(v, (dict, list)):
        return json.dumps(v, separators=(",", ":"))
    return v


def rewrite_query(q, count):
    q = q.replace("{}", "{0}")
    for i in range(count):
        q = q.replace(f"{{{i}}}", f'"t{i}"')
    return q


def string_format(path, forced=None):
    try:
        return mimetype(path, forced) in {"csv", "tsv", "logfmt", "xlsx", "ods"}
    except SystemExit:
        return False


def run_query(files, forced, query):
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    for i, f in enumerate(files):
        fforced = forced if f == "-" else None
        create_table(conn, f"t{i}", ensure_rows(load_path(f, fforced), f), string_format(f, fforced))
    try:
        cur = conn.execute(rewrite_query(query, len(files)))
    except Exception as e:
        die(f"sqlite error: {e}")
    rows = [dict(r) for r in cur.fetchall()]
    return rows


def dumps_rows(rows):
    if not rows:
        return "[]"
    return "[" + ",\n".join(json.dumps(r, ensure_ascii=False, separators=(",", ":")) for r in rows) + "]"


def pretty(rows):
    if not rows:
        print("(0 rows)")
        return
    keys = list(rows[0].keys())
    widths = {k: len(str(k)) for k in keys}
    vals = []
    for r in rows:
        line = []
        for k in keys:
            v = "" if r.get(k) is None else str(r.get(k))
            line.append(v); widths[k] = max(widths[k], len(v))
        vals.append(line)
    sep = "+" + "+".join("-" * (widths[k] + 2) for k in keys) + "+"
    print(sep)
    print("| " + " | ".join(str(k).ljust(widths[k]) for k in keys) + " |")
    print(sep)
    for line in vals:
        cells = []
        for k, v in zip(keys, line):
            cells.append(v.rjust(widths[k]) if re.fullmatch(r"-?\d+(\.\d+)?", v) or v == "" else v.ljust(widths[k]))
        print("| " + " | ".join(cells) + " |")
    print(sep)
    print(f"({len(rows)} {'row' if len(rows)==1 else 'rows'})")


def parse_args(argv):
    opts = {"pretty": False, "schema": False, "stdin_fmt": None, "query_file": None}
    pos = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP); raise SystemExit(0)
        if a in ("-v", "--version"):
            print("dsq latest"); raise SystemExit(0)
        if a in ("-p", "--pretty"):
            opts["pretty"] = True
        elif a == "--schema":
            opts["schema"] = True
        elif a == "-C":
            pass
        elif a in ("-s", "--source"):
            i += 1
            if i >= len(argv):
                die("Must specify stdin mimetype.")
            opts["stdin_fmt"] = argv[i]
        elif a in ("-f", "--file"):
            i += 1
            if i >= len(argv):
                die("Must specify query file.")
            opts["query_file"] = argv[i]
        elif a == "-i" or a == "--interactive":
            die("Interactive mode is not supported in this build.")
        else:
            pos.append(a)
        i += 1
    return opts, pos


def main(argv):
    opts, pos = parse_args(argv)
    if opts["stdin_fmt"]:
        files = ["-"]
        query = " ".join(pos) if pos else None
    else:
        if not pos:
            die("No input files.")
        if opts["query_file"]:
            files, query = pos, None
        elif len(pos) >= 2 and not os.path.exists(pos[-1]):
            files, query = pos[:-1], pos[-1]
        else:
            files, query = pos, None
    if opts["query_file"]:
        with open(opts["query_file"], "r", encoding="utf-8") as f:
            query = f.read()
    if not files:
        die("No input files.")
    if opts["schema"]:
        data = load_path(files[0], opts["stdin_fmt"] if files[0] == "-" else None)
        print(json.dumps(infer_shape(data), indent=2, ensure_ascii=False))
        return 0
    if query:
        rows = run_query(files, opts["stdin_fmt"], query)
        if opts["pretty"]:
            pretty(rows)
        else:
            print(dumps_rows(rows))
    else:
        data = load_path(files[0], opts["stdin_fmt"] if files[0] == "-" else None)
        if isinstance(data, dict):
            die(f"Input is not an array of objects: {files[0]}.")
        rows = ensure_rows(data, files[0])
        if opts["pretty"]:
            pretty(rows)
        else:
            print(dumps_rows(rows))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
