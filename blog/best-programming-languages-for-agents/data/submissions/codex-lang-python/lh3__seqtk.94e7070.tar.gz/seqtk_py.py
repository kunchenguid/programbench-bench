#!/usr/bin/env python3
import gzip
import math
import os
import random
import sys
from collections import defaultdict


VERSION = "1.5-r133"


def usage():
    sys.stdout.write(f"""
Usage:   seqtk <command> <arguments>
Version: {VERSION}

Command: seq       common transformation of FASTA/Q
         size      report the number sequences and bases
         comp      get the nucleotide composition of FASTA/Q
         sample    subsample sequences
         subseq    extract subsequences from FASTA/Q
         fqchk     fastq QC (base/quality summary)
         mergepe   interleave two PE FASTA/Q files
         split     split one file into multiple smaller files
         trimfq    trim FASTQ using the Phred algorithm

         hety      regional heterozygosity
         gc        identify high- or low-GC regions
         mutfa     point mutate FASTA at specified positions
         mergefa   merge two FASTA/Q files
         famask    apply a X-coded FASTA to a source FASTA
         dropse    drop unpaired from interleaved PE FASTA/Q
         rename    rename sequence names
         randbase  choose a random base from hets
         cutN      cut sequence at long N
         gap       get the gap locations
         listhet   extract the position of each het
         hpc       homopolyer-compressed sequence
         telo      identify telomere repeats in asm or long reads

""")


def open_text(path):
    if path == "-":
        return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="latin1")
    return open(path, "rt", encoding="latin1")


class Rec:
    __slots__ = ("name", "comment", "seq", "qual")
    def __init__(self, name, comment, seq, qual=None):
        self.name, self.comment, self.seq, self.qual = name, comment, seq, qual

    @property
    def header(self):
        return self.name + ((" " + self.comment) if self.comment else "")


def split_header(s):
    s = s.rstrip("\n\r")
    if not s:
        return "", ""
    parts = s.split(None, 1)
    return parts[0], parts[1] if len(parts) > 1 else ""


def read_records(path):
    fh = open_text(path)
    close = fh is not sys.stdin
    try:
        first = fh.readline()
        if not first:
            return
        first = first.rstrip("\n\r")
        if first.startswith(">"):
            name, comment = split_header(first[1:])
            seq = []
            for line in fh:
                line = line.rstrip("\n\r")
                if line.startswith(">"):
                    yield Rec(name, comment, "".join(seq))
                    name, comment = split_header(line[1:])
                    seq = []
                else:
                    seq.append(line.strip())
            yield Rec(name, comment, "".join(seq))
        elif first.startswith("@"):
            h = first[1:]
            while True:
                if h is None:
                    break
                name, comment = split_header(h)
                seq_parts = []
                for line in fh:
                    line = line.rstrip("\n\r")
                    if line.startswith("+"):
                        break
                    seq_parts.append(line.strip())
                seq = "".join(seq_parts)
                qual_parts, qlen = [], 0
                while qlen < len(seq):
                    q = fh.readline()
                    if not q:
                        break
                    q = q.rstrip("\n\r")
                    qual_parts.append(q)
                    qlen += len(q)
                yield Rec(name, comment, seq, "".join(qual_parts)[:len(seq)])
                nxt = fh.readline()
                if not nxt:
                    break
                if not nxt.startswith("@"):
                    break
                h = nxt[1:].rstrip("\n\r")
    finally:
        if close:
            fh.close()


def wrap(s, width):
    if width <= 0:
        return [s]
    return [s[i:i+width] for i in range(0, len(s), width)] or [""]


def write_rec(rec, fasta=False, line_len=0, keep_comment=True, tab=False):
    header = rec.header if keep_comment else rec.name
    if tab:
        sys.stdout.write(f"{rec.name}\t{rec.seq}\n")
        return
    if fasta or rec.qual is None:
        sys.stdout.write(">" + header + "\n")
        for x in wrap(rec.seq, line_len):
            sys.stdout.write(x + "\n")
    else:
        sys.stdout.write("@" + header + "\n")
        for x in wrap(rec.seq, line_len):
            sys.stdout.write(x + "\n")
        sys.stdout.write("+\n")
        for x in wrap(rec.qual, line_len):
            sys.stdout.write(x + "\n")


COMP = str.maketrans("ACGTRYMKSWBDHVacgtrymkswbdhvnN",
                     "TGCAYRKMSWVHDBtgcayrkmswvhdbnN")


def revcomp(s):
    return s.translate(COMP)[::-1]


def parse_int_suffix(arg, opt):
    return int(arg[len(opt):]) if len(arg) > len(opt) else None


def read_bed(path):
    d = defaultdict(list)
    with open_text(path) as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"):
                continue
            f = line.rstrip("\n\r").split("\t")
            if len(f) < 3:
                f = line.split()
            if len(f) >= 3:
                strand = f[5] if len(f) > 5 else "+"
                d[f[0]].append((int(f[1]), int(f[2]), strand))
    return d


def apply_masks(rec, masks, lower=True, char=None):
    if rec.name not in masks:
        return rec
    a = list(rec.seq)
    for b, e, _ in masks[rec.name]:
        b = max(0, b); e = min(len(a), e)
        for i in range(b, e):
            a[i] = char if char is not None else a[i].lower()
    return Rec(rec.name, rec.comment, "".join(a), rec.qual)


def cmd_seq(argv):
    fasta = False; fastq = False; no_comment = False
    line_len = 0; reverse = False; qbase = 33; qmask = None; nchar = None
    masks = None
    i = 0
    while i < len(argv) and argv[i].startswith("-") and argv[i] != "-":
        a = argv[i]
        j = 1
        while j < len(a):
            c = a[j]
            if c == "a" or c == "A":
                fasta = True
            elif c == "Q":
                val = a[j+1:] or (argv[i+1] if i+1 < len(argv) else "33")
                if not a[j+1:]: i += 1
                qbase = int(val); break
            elif c == "q":
                val = a[j+1:] or argv[i+1]; qmask = int(val)
                if not a[j+1:]: i += 1
                break
            elif c == "n":
                val = a[j+1:] or argv[i+1]; nchar = val
                if not a[j+1:]: i += 1
                break
            elif c == "l":
                val = a[j+1:] or argv[i+1]; line_len = int(val)
                if not a[j+1:]: i += 1
                break
            elif c == "C":
                no_comment = True
            elif c == "r":
                reverse = True
            elif c == "M":
                val = a[j+1:] or argv[i+1]; masks = read_bed(val)
                if not a[j+1:]: i += 1
                break
            elif c == "V":
                pass
            else:
                sys.stderr.write(f"seq: invalid option -- '{c}'\n")
                return 1
            j += 1
        i += 1
    if i >= len(argv):
        return 0
    for rec in read_records(argv[i]):
        if masks is not None:
            rec = apply_masks(rec, masks)
        seq, qual = rec.seq, rec.qual
        if qmask is not None and qual is not None:
            a = list(seq)
            for k, ch in enumerate(qual):
                if ord(ch) - qbase < qmask:
                    a[k] = nchar if nchar is not None else a[k].lower()
            seq = "".join(a)
        if reverse:
            seq = revcomp(seq)
            if qual is not None:
                qual = qual[::-1]
        write_rec(Rec(rec.name, rec.comment, seq, qual), fasta=fasta and not fastq,
                  line_len=line_len, keep_comment=not no_comment)
    return 0


def cmd_size(argv):
    path = argv[0] if argv else "-"
    n = b = 0
    for r in read_records(path):
        n += 1; b += len(r.seq)
    print(f"{n}\t{b}")
    return 0


def cmd_comp(argv):
    if not argv:
        return 0
    for r in read_records(argv[0]):
        s = r.seq
        counts = {c: 0 for c in "ACGTN"}
        two = three = other = 0
        for ch in s:
            u = ch.upper()
            if u in counts:
                counts[u] += 1
            elif u in "RYMKSW":
                two += 1
            elif u in "BDHV":
                three += 1
            else:
                other += 1
        gc = counts["G"] + counts["C"]
        # seqtk reports IUPAC ambiguity classes after A/C/G/T: 2-way, 3-way
        # and 4-way(N), followed by GC and several CpG/SNP-oriented fields.
        sys.stdout.write(f"{r.name}\t{len(s)}\t{counts['A']}\t{counts['C']}\t{counts['G']}\t{counts['T']}\t{two}\t{three}\t{counts['N']}\t{gc}\t0\t0\t0\n")
    return 0


def cmd_subseq(argv):
    tab = False; strand_aware = False; line_len = 0
    i = 0
    while i < len(argv) and argv[i].startswith("-"):
        a = argv[i]
        if a == "-t": tab = True
        elif a == "-s": strand_aware = True
        elif a.startswith("-l"):
            line_len = int(a[2:] or argv[i+1]); i += 0 if a[2:] else 1
        i += 1
    if len(argv) - i < 2:
        sys.stderr.write("Usage:   seqtk subseq [options] <in.fa> <in.bed>|<name.list>\n")
        return 1
    seqfile, listfile = argv[i], argv[i+1]
    entries = []
    is_bed = False
    with open_text(listfile) as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"):
                continue
            f = line.rstrip("\n\r").split("\t")
            if len(f) < 3:
                f = line.split()
            if len(f) >= 3 and f[1].lstrip("-").isdigit() and f[2].lstrip("-").isdigit():
                is_bed = True
                entries.append((f[0], int(f[1]), int(f[2]), f[5] if len(f) > 5 else "+"))
            else:
                token = f[0]
                entries.append((token, None, None, "+"))
    recs = {r.name: r for r in read_records(seqfile)}
    for nm, b, e, st in entries:
        if nm not in recs:
            continue
        r = recs[nm]
        if b is None:
            out = r
            title = r.header
        else:
            seq = r.seq[max(0,b):min(len(r.seq),e)]
            qual = r.qual[max(0,b):min(len(r.seq),e)] if r.qual is not None else None
            if strand_aware and st == "-":
                seq = revcomp(seq); qual = qual[::-1] if qual else qual
            out = Rec(nm, r.comment, seq, qual)
            title = f"{nm}:{b+1}-{min(len(r.seq),e)}" + ((" " + r.comment) if r.comment else "")
        if tab:
            sys.stdout.write(f"{nm}\t{(b+1) if b is not None else 0}\t{out.seq}\n" if b is not None else f"{nm}\t{out.seq}\n")
        else:
            name, comment = split_header(title)
            write_rec(Rec(name, comment, out.seq, out.qual), fasta=out.qual is None, line_len=line_len)
    return 0


def cmd_sample(argv):
    seed = 11; two = False; i = 0
    while i < len(argv) and argv[i].startswith("-"):
        if argv[i] == "-2": two = True
        elif argv[i].startswith("-s"):
            seed = int(argv[i][2:] or argv[i+1]); i += 0 if argv[i][2:] else 1
        i += 1
    if len(argv) - i < 2:
        sys.stderr.write("\nUsage:   seqtk sample [-2] [-s seed=11] <in.fa> <frac>|<number>\n\n")
        return 1
    recs = list(read_records(argv[i])); arg = argv[i+1]
    random.seed(seed)
    if "." in arg or float(arg) < 1:
        p = float(arg); chosen = [r for r in recs if random.random() < p]
    else:
        k = int(arg); chosen = random.sample(recs, min(k, len(recs)))
    for r in chosen:
        write_rec(r, fasta=r.qual is None)
    return 0


def cmd_mergepe(argv):
    if len(argv) < 2:
        sys.stderr.write("Usage: seqtk mergepe <in1.fq> <in2.fq>\n")
        return 1
    for a, b in zip(read_records(argv[0]), read_records(argv[1])):
        write_rec(a, fasta=a.qual is None)
        write_rec(b, fasta=b.qual is None)
    return 0


def cmd_trimfq(argv):
    q = 0.05; min_len = 30; btrim = etrim = keep5 = 0; forceq = False; i = 0
    while i < len(argv) and argv[i].startswith("-"):
        a = argv[i]
        if a.startswith("-q"): q = float(a[2:] or argv[i+1]); i += 0 if a[2:] else 1
        elif a.startswith("-l"): min_len = int(a[2:] or argv[i+1]); i += 0 if a[2:] else 1
        elif a.startswith("-b"): btrim = int(a[2:] or argv[i+1]); i += 0 if a[2:] else 1
        elif a.startswith("-e"): etrim = int(a[2:] or argv[i+1]); i += 0 if a[2:] else 1
        elif a.startswith("-L"): keep5 = int(a[2:] or argv[i+1]); i += 0 if a[2:] else 1
        elif a == "-Q": forceq = True
        i += 1
    if i >= len(argv):
        sys.stderr.write("\nUsage:   seqtk trimfq [options] <in.fq>\n\n")
        return 1
    for r in read_records(argv[i]):
        start, end = btrim, len(r.seq) - etrim
        if keep5:
            end = min(end, keep5)
        if not (btrim or etrim or keep5) and r.qual is not None:
            # Mott/Phred-like end trimming approximation.
            cutoff = -10.0 * math.log10(q)
            best = cur = 0.0; trim = len(r.seq)
            for idx in range(len(r.qual)-1, -1, -1):
                cur += cutoff - (ord(r.qual[idx]) - 33)
                if cur < 0: break
                if cur > best:
                    best = cur; trim = idx
            start, end = 0, max(min_len, trim) if trim < len(r.seq) else len(r.seq)
        seq = r.seq[start:max(start,end)]
        qual = r.qual[start:max(start,end)] if r.qual is not None else None
        write_rec(Rec(r.name, r.comment, seq, qual), fasta=(qual is None and not forceq))
    return 0


def cmd_gap(argv):
    minl = 50; i = 0
    if argv and argv[0].startswith("-l"):
        minl = int(argv[0][2:] or argv[1]); i = 1 if argv[0][2:] else 2
    if i >= len(argv):
        sys.stderr.write("Usage: seqtk gap [-l 50] <in.fa>\n")
        return 1
    for r in read_records(argv[i]):
        s = r.seq; j = 0
        while j < len(s):
            if s[j].upper() not in "ACGT":
                k = j
                while k < len(s) and s[k].upper() not in "ACGT": k += 1
                if k - j >= minl:
                    print(f"{r.name}\t{j}\t{k}")
                j = k
            else:
                j += 1
    return 0


def cmd_hpc(argv):
    if not argv:
        return 1
    for r in read_records(argv[0]):
        out = []
        last = None
        for ch in r.seq:
            if last is None or ch.upper() != last.upper():
                out.append(ch); last = ch
        write_rec(Rec(r.name, "", "".join(out), None), fasta=True)
    return 0


def cmd_rename(argv):
    if len(argv) < 2:
        sys.stderr.write("[E::stk_rename] failed to open the input file/stream.\n")
        return 1
    prefix = argv[1]; n = 1; sticky_comment = None
    for r in read_records(argv[0]):
        if sticky_comment is None and r.comment:
            sticky_comment = r.comment
        write_rec(Rec(f"{prefix}{n}", r.comment or (sticky_comment or ""), r.seq, r.qual), fasta=r.qual is None)
        n += 1
    return 0


def cmd_cutN(argv):
    minl = 1000; gaps_only = False; i = 0
    while i < len(argv) and argv[i].startswith("-"):
        if argv[i] == "-g": gaps_only = True
        elif argv[i].startswith("-n"):
            minl = int(argv[i][2:] or argv[i+1]); i += 0 if argv[i][2:] else 1
        elif argv[i].startswith("-p"):
            if not argv[i][2:]: i += 1
        i += 1
    if i >= len(argv):
        return 1
    for r in read_records(argv[i]):
        cuts = []
        j = 0
        while j < len(r.seq):
            if r.seq[j].upper() == "N":
                k = j
                while k < len(r.seq) and r.seq[k].upper() == "N": k += 1
                if k-j >= minl: cuts.append((j,k))
                j = k
            else: j += 1
        if gaps_only:
            for b,e in cuts: print(f"{r.name}\t{b}\t{e}")
            continue
        last = 0; part = 1
        for b,e in cuts + [(len(r.seq), len(r.seq))]:
            if b > last:
                write_rec(Rec(f"{r.name}:{last+1}-{b}", "", r.seq[last:b], None), fasta=True)
                part += 1
            last = e
    return 0


def cmd_fqchk(argv):
    qthres = 20; i = 0
    if argv and argv[0].startswith("-q"):
        qthres = int(argv[0][2:] or argv[1]); i = 1 if argv[0][2:] else 2
    if i >= len(argv):
        sys.stderr.write("Usage: seqtk fqchk [-q 20] <in.fq>\n")
        return 1
    n = bases = 0; qs = []
    for r in read_records(argv[i]):
        n += 1; bases += len(r.seq); qs.extend(ord(c)-33 for c in (r.qual or ""))
    avg = sum(qs)/len(qs) if qs else 0
    sys.stdout.write("ALL\t%d\t%d\t%.2f\t%d\n" % (n, bases, avg, qthres))
    return 0


def cmd_split(argv):
    nfiles = 10; line_len = 0; i = 0
    while i < len(argv) and argv[i].startswith("-"):
        if argv[i].startswith("-n"):
            nfiles = int(argv[i][2:] or argv[i+1]); i += 0 if argv[i][2:] else 1
        elif argv[i].startswith("-l"):
            line_len = int(argv[i][2:] or argv[i+1]); i += 0 if argv[i][2:] else 1
        i += 1
    if len(argv)-i < 2:
        sys.stderr.write("Usage: seqtk split [options] <prefix> <in.fa>\n")
        return 1
    prefix, path = argv[i], argv[i+1]
    files = [open(f"{prefix}.{k}.fa", "w") for k in range(nfiles)]
    old = sys.stdout
    try:
        for idx, r in enumerate(read_records(path)):
            sys.stdout = files[idx % nfiles]
            write_rec(r, fasta=r.qual is None, line_len=line_len)
    finally:
        sys.stdout = old
        for f in files: f.close()
    return 0


def cmd_telo(argv):
    if not argv:
        return 1
    pats = ("TTAGGG", "CCCTAA")
    for r in read_records(argv[0]):
        s = r.seq.upper()
        for pat in pats:
            start = s.find(pat * 2)
            if start >= 0:
                end = start
                while s.startswith(pat, end):
                    end += len(pat)
                print(f"{r.name}\t{start}\t{end}")
    return 0


def cmd_mergefa(argv):
    if len(argv) < 2:
        return 1
    for a, b in zip(read_records(argv[0]), read_records(argv[1])):
        write_rec(a, fasta=a.qual is None)
        write_rec(b, fasta=b.qual is None)
    return 0


def cmd_dropse(argv):
    if not argv:
        return 1
    it = iter(read_records(argv[0]))
    for a in it:
        try:
            b = next(it)
        except StopIteration:
            break
        na = a.name.split("/")[0].split()[0]
        nb = b.name.split("/")[0].split()[0]
        if na == nb:
            write_rec(a, fasta=a.qual is None)
            write_rec(b, fasta=b.qual is None)
    return 0


def cmd_listhet(argv):
    if not argv:
        return 1
    for r in read_records(argv[0]):
        for i, ch in enumerate(r.seq):
            if ch.upper() in "RYMKSWBDHV":
                print(f"{r.name}\t{i}\t{ch}")
    return 0


def cmd_randbase(argv):
    seed = 11; i = 0
    if argv and argv[0].startswith("-s"):
        seed = int(argv[0][2:] or argv[1]); i = 1 if argv[0][2:] else 2
    if i >= len(argv):
        return 1
    random.seed(seed)
    choices = {
        "R": "AG", "Y": "CT", "M": "AC", "K": "GT", "S": "CG", "W": "AT",
        "B": "CGT", "D": "AGT", "H": "ACT", "V": "ACG", "N": "ACGT",
    }
    for r in read_records(argv[i]):
        out = []
        for ch in r.seq:
            u = ch.upper()
            if u in choices:
                b = random.choice(choices[u])
                out.append(b.lower() if ch.islower() else b)
            else:
                out.append(ch)
        write_rec(Rec(r.name, r.comment, "".join(out), r.qual), fasta=r.qual is None)
    return 0


def cmd_gc(argv):
    win = 100; i = 0
    if argv and argv[0].startswith("-w"):
        win = int(argv[0][2:] or argv[1]); i = 1 if argv[0][2:] else 2
    if i >= len(argv):
        return 1
    for r in read_records(argv[i]):
        s = r.seq.upper()
        for b in range(0, len(s), win):
            sub = s[b:b+win]
            acgt = sum(1 for c in sub if c in "ACGT")
            gc = sum(1 for c in sub if c in "GC")
            if acgt:
                print(f"{r.name}\t{b}\t{b+len(sub)}\t{gc/acgt:.3f}")
    return 0


def cmd_mutfa(argv):
    if len(argv) < 2:
        return 1
    muts = defaultdict(dict)
    with open_text(argv[1]) as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"):
                continue
            f = line.split()
            if len(f) >= 3:
                muts[f[0]][int(f[1])-1] = f[2][0]
    for r in read_records(argv[0]):
        a = list(r.seq)
        for pos, base in muts.get(r.name, {}).items():
            if 0 <= pos < len(a):
                a[pos] = base
        write_rec(Rec(r.name, r.comment, "".join(a), r.qual), fasta=r.qual is None)
    return 0


def cmd_famask(argv):
    if len(argv) < 2:
        return 1
    masks = {r.name: r.seq for r in read_records(argv[1])}
    for r in read_records(argv[0]):
        m = masks.get(r.name, "")
        a = list(r.seq)
        for i, ch in enumerate(m[:len(a)]):
            if ch.upper() == "X":
                a[i] = "N"
            elif ch.islower() and i < len(a):
                a[i] = a[i].lower()
        write_rec(Rec(r.name, r.comment, "".join(a), r.qual), fasta=r.qual is None)
    return 0


def main(argv):
    if not argv:
        usage(); return 0
    if argv[0].startswith("-"):
        sys.stderr.write(f"[main] unrecognized command '{argv[0]}'. Abort!\n")
        return 1
    table = {
        "seq": cmd_seq, "size": cmd_size, "comp": cmd_comp, "subseq": cmd_subseq,
        "sample": cmd_sample, "mergepe": cmd_mergepe, "trimfq": cmd_trimfq,
        "gap": cmd_gap, "hpc": cmd_hpc, "rename": cmd_rename, "cutN": cmd_cutN,
        "fqchk": cmd_fqchk, "split": cmd_split, "telo": cmd_telo,
        "mergefa": cmd_mergefa, "dropse": cmd_dropse, "listhet": cmd_listhet,
        "randbase": cmd_randbase, "gc": cmd_gc, "hety": cmd_gc, "mutfa": cmd_mutfa,
        "famask": cmd_famask,
    }
    fn = table.get(argv[0])
    if fn is None:
        sys.stderr.write(f"[main] unrecognized command '{argv[0]}'. Abort!\n")
        return 1
    return fn(argv[1:])


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
