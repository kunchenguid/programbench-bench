#!/usr/bin/env python3
import argparse
import glob
import os
import re
import sys
from html.parser import HTMLParser
from urllib.parse import urljoin


VERSION = """html2markdown

GitVersion:  dev
GitCommit:   none
BuildDate:   unknown
"""


BLOCK_TAGS = {
    "address", "article", "aside", "blockquote", "div", "dl", "fieldset",
    "figcaption", "figure", "footer", "form", "header", "hr", "main", "nav",
    "ol", "p", "pre", "section", "table", "ul",
}


def attrs_dict(attrs):
    return {k.lower(): (v if v is not None else "") for k, v in attrs}


def collapse_ws(s):
    return re.sub(r"\s+", " ", s)


def esc_text(s):
    # Match the reference's smart escaping for the most destructive constructs.
    s = s.replace("\\", "\\\\")
    s = s.replace("*", "\\*")
    s = s.replace("_", "\\_")
    s = s.replace("[", "\\[")
    s = s.replace("]", "\\]")
    s = s.replace("`", "\\`")
    s = re.sub(r"(?m)^([ \t]*)(#{1,6})(\s)", r"\1\\\2\3", s)
    s = re.sub(r"(?m)^([ \t]*)([-+])(\s|$)", r"\1\\\2\3", s)
    s = re.sub(r"(?m)^([ \t]*)(\d+)\.(\s)", r"\1\2\\.\3", s)
    return s


class Node:
    def __init__(self, tag="#document", attrs=None, parent=None):
        self.tag = tag.lower()
        self.attrs = attrs or {}
        self.children = []
        self.parent = parent


class TreeParser(HTMLParser):
    VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node()
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        node = Node(tag, attrs_dict(attrs), self.stack[-1])
        self.stack[-1].children.append(node)
        if tag not in self.VOID:
            self.stack.append(node)

    def handle_endtag(self, tag):
        tag = tag.lower()
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                return

    def handle_data(self, data):
        if data:
            self.stack[-1].children.append(data)

    def handle_entityref(self, name):
        self.handle_data("&" + name + ";")

    def handle_charref(self, name):
        self.handle_data("&#" + name + ";")


def match_selector(node, selector):
    selector = selector.strip()
    if not selector or not isinstance(node, Node):
        return False
    if selector.startswith("."):
        return selector[1:] in node.attrs.get("class", "").split()
    if selector.startswith("#"):
        return node.attrs.get("id") == selector[1:]
    m = re.match(r"^([a-zA-Z0-9_-]+)?(?:\.([a-zA-Z0-9_-]+))?(?:#([a-zA-Z0-9_-]+))?$", selector)
    if m:
        tag, cls, ident = m.groups()
        if tag and node.tag != tag.lower():
            return False
        if cls and cls not in node.attrs.get("class", "").split():
            return False
        if ident and node.attrs.get("id") != ident:
            return False
        return bool(tag or cls or ident)
    return node.tag == selector.lower()


def find_matching(node, selector, out):
    if isinstance(node, Node):
        if match_selector(node, selector):
            out.append(node)
        for ch in node.children:
            find_matching(ch, selector, out)


class Renderer:
    def __init__(self, opts):
        self.opts = opts
        self.list_stack = []

    def url(self, value):
        if self.opts.domain and value:
            return urljoin(self.opts.domain, value)
        return value or ""

    def render_children(self, node, inline=False):
        if not inline:
            blocks = []
            buf = []
            def flush():
                if buf:
                    text = normalize_inline("".join(buf)).strip()
                    if text:
                        blocks.append(text)
                    buf.clear()
            for ch in node.children:
                is_block = isinstance(ch, Node) and (ch.tag in BLOCK_TAGS or ch.tag in ("h1", "h2", "h3", "h4", "h5", "h6"))
                if is_block and ch.tag != "br":
                    flush()
                    blocks.append(self.render(ch, inline=False))
                else:
                    buf.append(self.render(ch, inline=True))
            flush()
            return join_blocks(blocks)
        parts = []
        for ch in node.children:
            parts.append(self.render(ch, inline=inline))
        return "".join(parts)

    def render_inline_children(self, node):
        return normalize_inline(self.render_children(node, inline=True))

    def render(self, node, inline=False):
        if isinstance(node, str):
            return esc_text(collapse_ws(node) if inline else node)
        tag = node.tag
        if tag == "#document":
            return self.render_children(node)
        if tag in ("script", "style", "noscript", "template", "head"):
            return ""
        if inline:
            return self.render_inline_node(node)
        if tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
            return "#" * int(tag[1]) + " " + self.render_inline_children(node)
        if tag == "p":
            return self.render_inline_children(node)
        if tag == "br":
            return "\x00BR\x00"
        if tag == "hr":
            return "* * *"
        if tag in ("ul", "ol"):
            return self.render_list(node, ordered=(tag == "ol"))
        if tag == "li":
            return self.render_inline_children(node)
        if tag == "blockquote":
            body = self.render_children(node).strip()
            return "\n".join("> " + line if line else "> " for line in body.splitlines())
        if tag == "pre":
            code = text_content(node).strip("\n")
            return "```\n" + code + "\n```"
        if tag == "table" and self.opts.plugin_table:
            return self.render_table(node)
        if tag == "table":
            return self.render_inline_children(node)
        if tag in BLOCK_TAGS:
            return self.render_children(node)
        return self.render_inline_node(node)

    def render_inline_node(self, node):
        tag = node.tag
        if tag in ("strong", "b"):
            d = self.opts.strong_delimiter
            return d + self.render_inline_children(node) + d
        if tag in ("em", "i"):
            return "*" + self.render_inline_children(node) + "*"
        if tag in ("del", "s", "strike"):
            inner = self.render_inline_children(node)
            return "~~" + inner + "~~" if self.opts.plugin_strikethrough else inner
        if tag == "code":
            return "`" + text_content(node).strip() + "`"
        if tag == "a":
            text = self.render_inline_children(node) or self.url(node.attrs.get("href", ""))
            href = self.url(node.attrs.get("href", ""))
            title = node.attrs.get("title")
            if not href:
                return text
            return "[" + text + "](" + href + (f' "{title}"' if title else "") + ")"
        if tag == "img":
            alt = esc_text(node.attrs.get("alt", ""))
            src = self.url(node.attrs.get("src", ""))
            title = node.attrs.get("title")
            return "![" + alt + "](" + src + (f' "{title}"' if title else "") + ")"
        if tag == "br":
            return "\x00BR\x00"
        if tag == "pre":
            return text_content(node)
        return self.render_children(node, inline=True)

    def render_list(self, node, ordered=False):
        items = [ch for ch in node.children if isinstance(ch, Node) and ch.tag == "li"]
        lines = []
        for idx, li in enumerate(items, 1):
            marker = f"{idx}. " if ordered else "- "
            direct = []
            nested = []
            for ch in li.children:
                if isinstance(ch, Node) and ch.tag in ("ul", "ol"):
                    nested.append(self.render(ch).strip())
                else:
                    direct.append(self.render(ch, inline=True) if not (isinstance(ch, Node) and ch.tag in BLOCK_TAGS) else self.render(ch))
            first = normalize_inline("".join(direct)).strip()
            if not first and nested:
                first = ""
            lines.append(marker + first)
            for block in nested:
                lines.append("  ")
                for ln in block.splitlines():
                    lines.append("  " + ln if ln else "")
        return "\n".join(lines)

    def render_table(self, node):
        rows = []
        for tr in iter_tag(node, "tr"):
            cells = []
            header = False
            for cell in [c for c in tr.children if isinstance(c, Node) and c.tag in ("th", "td")]:
                if cell.tag == "th":
                    header = True
                txt = normalize_inline(self.render_inline_children(cell)).replace("\n", " ")
                cells.append(txt)
            if cells or not self.opts.table_skip_empty_rows:
                rows.append((cells, header))
        if not rows:
            return ""
        promote = self.opts.table_header_promotion or rows[0][1]
        width = max(len(r[0]) for r in rows)
        for r, _ in rows:
            while len(r) < width:
                r.append("")
        if not promote:
            rows.insert(0, ([""] * width, True))
        colw = [0] * width
        if self.opts.table_padding == "aligned":
            for r, _ in rows:
                for i, c in enumerate(r):
                    colw[i] = max(colw[i], len(c))
        else:
            colw = [max(3, len(rows[0][0][i]) if rows else 3) for i in range(width)]
        def fmt(row):
            if self.opts.table_padding == "none":
                return "|" + "|".join(row) + "|"
            return "| " + " | ".join(row[i].ljust(colw[i]) for i in range(width)) + " |"
        sep = "|" + "|".join("-" * max(3, colw[i] + (2 if self.opts.table_padding != "none" else 0)) for i in range(width)) + "|"
        return "\n".join([fmt(rows[0][0]), sep] + [fmt(r) for r, _ in rows[1:]])


def text_content(node):
    if isinstance(node, str):
        return node
    return "".join(text_content(ch) for ch in node.children)


def iter_tag(node, tag):
    if isinstance(node, Node):
        if node.tag == tag:
            yield node
        for ch in node.children:
            yield from iter_tag(ch, tag)


def normalize_inline(s):
    s = s.replace("\x00BR\x00", "\x00BRNL\x00")
    s = re.sub(r"(?<!  )[ \t]*\n[ \t]*", "\n", s)
    s = re.sub(r"[ \t]+", " ", s)
    s = s.replace("\x00BRNL\x00", "  \n")
    s = s.replace("~~~~", "")
    return s.strip(" ")


def join_blocks(parts):
    out = []
    for p in parts:
        p = p.strip()
        if not p:
            continue
        out.append(p)
    return "\n\n".join(out)


def prune_excluded(node, selector):
    if not isinstance(node, Node):
        return node
    kept = []
    for ch in node.children:
        if isinstance(ch, Node) and match_selector(ch, selector):
            continue
        kept.append(prune_excluded(ch, selector))
    node.children = kept
    return node


def convert(html, opts):
    parser = TreeParser()
    parser.feed(html)
    root = parser.root
    if opts.exclude_selector:
        prune_excluded(root, opts.exclude_selector)
    if opts.include_selector:
        matches = []
        find_matching(root, opts.include_selector, matches)
        newroot = Node()
        newroot.children = matches
        root = newroot
    md = Renderer(opts).render(root).strip()
    return md + "\n" if md else ""


def expand_inputs(pattern):
    if os.path.isdir(pattern):
        return sorted(glob.glob(os.path.join(pattern, "*")))
    matches = sorted(glob.glob(pattern))
    return [m for m in matches if os.path.isfile(m)]


def build_parser():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-v", "--version", action="store_true")
    p.add_argument("--help", action="store_true", dest="help_flag")
    p.add_argument("--input")
    p.add_argument("--output")
    p.add_argument("--output-overwrite", action="store_true")
    p.add_argument("--domain")
    p.add_argument("--exclude-selector")
    p.add_argument("--include-selector")
    p.add_argument("--opt-strong-delimiter", default="**")
    p.add_argument("--opt-table-cell-padding-behavior", default="aligned", dest="table_padding")
    p.add_argument("--opt-table-header-promotion", action="store_true", dest="table_header_promotion")
    p.add_argument("--opt-table-newline-behavior", default="skip")
    p.add_argument("--opt-table-presentation-tables", action="store_true")
    p.add_argument("--opt-table-skip-empty-rows", action="store_true", dest="table_skip_empty_rows")
    p.add_argument("--opt-table-span-cell-behavior", default="empty")
    p.add_argument("--plugin-strikethrough", action="store_true")
    p.add_argument("--plugin-table", action="store_true")
    return p


HELP = """
# html2markdown - convert html to markdown [version dev]

Convert HTML to Markdown. Even works with entire websites!

## Flags

    -v, --version
        show the version of html2markdown and exit

    --help

    --input PATH
        Input file, directory, or glob pattern (instead of stdin)

    --output PATH
        Output file or directory (instead of stdout)

    --output-overwrite
        Replace existing files

    --domain
        The url of the web page, used to convert relative links to absolute links.

    --exclude-selector
        css query selector to exclude parts of the input

    --include-selector
        css query selector to only include parts of the input

    --opt-strong-delimiter
        "**" or "__" (default: "**")

    --plugin-strikethrough
        enable the plugin ~~strikethrough~~

    --plugin-table
        enable the plugin table
""".strip() + "\n"


def main(argv=None):
    opts, extras = build_parser().parse_known_args(argv)
    if opts.help_flag:
        sys.stdout.write(HELP)
        return 0
    if opts.version:
        sys.stdout.write(VERSION)
        return 0
    if opts.opt_strong_delimiter not in ("**", "__"):
        opts.strong_delimiter = opts.opt_strong_delimiter
    else:
        opts.strong_delimiter = opts.opt_strong_delimiter

    if opts.input:
        files = expand_inputs(opts.input)
        if not files:
            sys.stderr.write(f'\nerror: no files found matching pattern "{opts.input}"\n\nHere is how you can use a glob to match multiple files:\n\n    html2markdown --input "src/*.html" --output "dist/"\n\n')
            return 1
        outputs = []
        for path in files:
            with open(path, encoding="utf-8", errors="replace") as f:
                outputs.append((path, convert(f.read(), opts).rstrip("\n")))
        if opts.output:
            if len(outputs) > 1 or os.path.isdir(opts.output):
                os.makedirs(opts.output, exist_ok=True)
                for path, data in outputs:
                    base = os.path.splitext(os.path.basename(path))[0] + ".md"
                    outp = os.path.join(opts.output, base)
                    if os.path.exists(outp) and not opts.output_overwrite:
                        sys.stderr.write(f'\nerror: output file "{outp}" already exists\n\n')
                        return 1
                    with open(outp, "w", encoding="utf-8") as f:
                        f.write(data)
                return 0
            if os.path.exists(opts.output) and not opts.output_overwrite:
                sys.stderr.write(f'\nerror: output file "{opts.output}" already exists\n\n')
                return 1
            with open(opts.output, "w", encoding="utf-8") as f:
                f.write(outputs[0][1])
            return 0
        sys.stdout.write("\n\n".join(data for _, data in outputs))
        if outputs:
            sys.stdout.write("\n")
        return 0

    data = sys.stdin.read()
    if data == "":
        sys.stderr.write("\nerror: the html input should be piped into the cli\n\nHere is how you can use the CLI:\n\n    echo \"<strong>important</strong>\" | html2markdown\n\n")
        return 1
    sys.stdout.write(convert(data, opts))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
